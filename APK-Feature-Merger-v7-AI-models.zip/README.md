# Feature Merger

## What changed in 1.1

* **Every APK is added, no import errors.** If part of an APK cannot be read (odd manifest, broken class, unusual
  resources), that part is skipped, the APK still appears in the list and the reason is shown in its **Notes** and in
  the **Log** tab (with the exact place in the code). An APK is never deleted because of a read problem.
* **New "Add app" sheet** (Add APK button, and the new **Add VPN app** / **Add game / app** buttons on the VPN tab):
  * **Installed**: all apps on the phone, search box, VPN apps are marked and listed first for the VPN slot,
    "System" chip for system apps.
  * **Files**: every `.apk` in Download and your other folders (asks for file access right there).
  * **Browse**: the normal file picker, needs no permission.
  * Picking from the VPN / game buttons puts the app straight into that slot.
* The VPN / game dropdowns always end with "+ Add app", so they are never empty.
* "Open with" / "Share" an APK from any file manager now sends it to this app.

## VPN transplant (new, main feature)

Makes a VPN app that works for some games (for example Free Fire and Free Fire MAX) work for one more game
(for example Free Fire India), without touching the VPN's servers, engine or screens.

1. **Apps** tab: Add the VPN APK and the game APK (Free Fire India).
2. **VPN** tab: choose the VPN app, tap **Scan VPN** (shows how the VPN picks its games), tick the games it
   already supports (the new game copies those), choose the new game, tap **Transplant, scan and save**.
3. The app patches the VPN, then scans the new APK again and prints a PASS/FAIL report.
   * FAIL or crash: tap **Copy report** and paste it to Claude.
4. **Save as...** (or Share). The file is saved **unsigned** on purpose; sign it with MT Manager,
   uninstall the old VPN, install the signed one.

How it works: every `VpnService.Builder.addAllowedApplication(pkg)` call in the VPN is redirected to a small helper
(`FmVpn.add`). It does the original call and, when `pkg` is one of the ticked games, also allows the new package
(a missing/uninstalled target never breaks the VPN). Package lists in plain config files (JSON arrays, one-per-line
lists) get the new package too. If the VPN has no per-app list (routes all apps, or only excludes some), the scan says
so: the new game is then already covered and nothing is patched.

**VPN has no addAllowedApplication call (new):** switch **Add a per-app list if missing** (VPN tab, on by default).
Then every `Builder.establish()` call goes through `FmVpn.establish`, which injects `addAllowedApplication(pkg)` for the
ticked games and the new game(s) right before the tunnel starts. The VPN then routes ONLY those games. Games that are
not listed in the scan (because the VPN had no list) can be typed into **Extra package names**
(for example Free Fire + Free Fire MAX + Free Fire India = three games). If the VPN only excludes apps
(`addDisallowedApplication`), those calls are switched off, because Android does not allow an exclude list and an allow
list together. A package that is not installed is skipped; if none is installed the VPN simply routes all apps.
Switch it off to keep the old behaviour ("nothing to patch" for such VPNs).

Limits: VPNs that decide the game some other way (server side, usage-stats checks, encrypted lists) are reported,
not patched. Apps that check their own signature may refuse to start after patching.

The old "move features between apps" Merge tab was removed. The Record tab was replaced by the Enhance tab.

---

Android app that reads APKs on the phone and

* lists every **overlay feature** inside them (floating menus, switches, sliders) with a traffic light:
  green = should work the same after the move, amber = check first, red = probably will not work
* lists everything the developer **switched off** (controls hidden with `visibility=gone/invisible`, disabled
  controls, disabled services/activities/receivers) and lets you **activate** it
* moves chosen features from one APK into another (the **base app**) and, if the base app has a switch menu,
  **adds a matching switch row** to that menu by cloning its last row, so it looks like every other option
* can turn off whole base-app features or hide single controls
* signs the result (v1 + v2) with a key generated on first use and offers Install / Share

Everything runs on the phone, pure Java (no native code, fine on armv7a), no internet needed.

## Build on GitHub

1. Use your existing repo. Upload this zip into the repo root (or the extracted files). The workflow
   `.github/workflows/build.yml` (same file as the TraceLock/iLauncher repo) unpacks the newest zip and builds it.
2. Open the **Actions** tab: it runs on every push (or run it by hand).
3. Download the `iLauncher-APK-run<N>` artifact: `iLauncher-debug.apk` (and `iLauncher-release.apk`).
   The artifact keeps the old iLauncher name on purpose, the workflow is unchanged. The Android Gradle plugin is 8.3.2
   because that workflow uses Gradle 8.4.

## Use

1. **Apps** tab: Add APK (one or more). Tap **Details** to see features, risk colours and switched-off items.
2. **Merge** tab: pick the base app, tick what to activate / turn off / bring in, press **Build merged APK**.
3. Uninstall the original base app, then Install the merged APK (it is signed with your own key).

## How a moved feature works

The source APK is embedded unchanged in the base APK. A small bridge (extracted from this app's own dex)
loads it with its own code and resources, so the feature behaves like in the original app. A manifest
provider boots the bridge, shim services host the feature's overlay Service, and the cloned menu switch
(found at runtime through its `android:tag`) starts/stops it.

## VPN enhancer / feature rewriter (new, replaces the Record tab)

Improves the features of a VPN app and puts the better version in place of the original one. No AI and no internet
inside the app: the improvements are ready-made recipes, based on research (see below). Your own short words are read
with plain keywords.

1. **Enhance** tab -> pick the VPN -> **Scan features**. You get a vertical list:
   * **VPN engine**: DNS servers, packet size (MTU), IPv6 handling, metered flag, always-on / kill switch support,
     tunnel start, per-app list. Each shows how many places in the code use it.
   * **Windows / dialogs / screens** of the VPN with every clickable control (buttons, switches, checkboxes, spinners).
2. Tap a feature. Choose a ready-made improvement, or type what you want (for example `dns google, mtu 1350`,
   `default on`, `hide`). The app tells you what it understood. Anything it cannot do is kept for the **brief**.
3. **Build enhanced APK**. The result is written unsigned (sign with MT Manager) or signed with the FM key (tick the box),
   then scanned again and a PASS/FAIL report is shown. FAIL: **Copy report** and paste it to Claude.
4. **Copy brief for Claude**: a text with the VPN's feature list and your instructions. Paste it in the chat, and a new
   improvement is added to the enhancer for that feature (this is the "research and write the best code" step; it is
   done by Claude in the chat, not inside the app).

### AI helper (optional, your own key)

Tap **AI setup** on the Enhance tab and paste a key once:

* **Gemini (free):** get a key at aistudio.google.com/apikey (no card). It stops by itself when the free limit is used up.
  The app asks the API which models your key can use and picks the newest stable Flash / Flash-Lite (3.8 Flash, 3.5 Flash-Lite ...),
  so an old model name can never break it. Gemini 2.5 is skipped: Google now serves it only to projects that used it before (new keys get 404).
  A free key cannot use Google Search, so the AI answers from its own knowledge and the answer says "Web research: no".
* **Claude (paid):** paste a Claude API key and set a spend limit in the Anthropic console, then it stops at that limit.

Then, on any feature, tap **Ask AI**, or just type your own words: whatever the keyword reader cannot handle goes to the AI.
The AI researches the web (if the provider allows it for your key; otherwise it answers from its own knowledge and says so)
and returns SETTINGS from the fixed list in the table below. It never puts code into the APK. You see its answer (summary,
changes, sources) and press **Add to plan** or Cancel. A daily cap (default 20 asks) is counted inside the app; the key
is stored in the app's private no-backup folder.

What each improvement does (inside the VPN, its servers / engine / screens stay the same):

| Feature | Improvement |
|---|---|
| DNS | Replaces the VPN's DNS (or adds one if it has none) with Cloudflare / Google / Quad9 / AdGuard or your own IPs. If a VPN sets no DNS, Android uses the DNS of the normal network, which can leak to your provider. |
| MTU | 1420 (fast), 1380 (mobile safe, what Mullvad ships), 1280 (IPv6 minimum, fallback when connections stall), or your own number 1200-1500. |
| IPv6 | Sends IPv6 into the tunnel too, so it cannot go around an IPv4-only VPN. |
| Metered | Marks the VPN as not metered (Android 10+). |
| Always-on | Corrects the manifest if the developer switched always-on support off. The kill switch itself is Android's own setting: Settings > VPN > gear > Always-on VPN + "Block connections without VPN". |
| Controls | Default ON / OFF for a switch, hide, show / enable (edits the screen layout). |

How it works: every `VpnService.Builder.establish / addDnsServer / setMtu` call in the VPN is redirected to a small helper
(`FmEnh`). It does the better version and then the normal call, and any problem in the helper falls back to the original
behaviour. It stacks with the VPN transplant (the transplant helper's own calls are redirected too).

Limits: VPNs that start the tunnel in native code (no `Builder.establish()` in Java) cannot be changed this way, the scan
says so. A VPN that already has an enhancement must be enhanced again from the original APK. Apps that check their own
signature may refuse to start after patching. Not built or run by the author's tools (no Android SDK there): the first
GitHub build may report small compile errors, send them back.

## Known limits

* Features that drive their own app's VPN engine are marked red; the engine cannot be moved.
* Overlays built inside an Activity (not a Service) are listed but cannot be moved yet.
* Only hidden/disabled items that exist in layouts or the manifest are found; flags inside code are not.
* Menus built entirely in code (no layout XML) cannot get a cloned switch; the feature then starts automatically.
