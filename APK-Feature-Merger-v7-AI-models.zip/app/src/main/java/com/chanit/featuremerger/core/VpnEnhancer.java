package com.chanit.featuremerger.core;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction35c;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction3rc;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.android.tools.smali.dexlib2.iface.reference.Reference;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction35c;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction3rc;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableMethodReference;
import com.android.tools.smali.dexlib2.rewriter.DexRewriter;
import com.android.tools.smali.dexlib2.rewriter.Rewriter;
import com.android.tools.smali.dexlib2.rewriter.RewriterModule;
import com.android.tools.smali.dexlib2.rewriter.Rewriters;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.Adler32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * "Feature rewriter" for VPN apps. The user picks a feature of the VPN (DNS, MTU, IPv6, always-on, or a switch /
 * button on one of its screens) and a ready-made improvement for it. The improved version REPLACES the original
 * behaviour inside the VPN app:
 *  - engine features: calls of VpnService.Builder are redirected to the small helper FmEnh, which does the better
 *    version and then the normal call (servers, engine and screens of the VPN stay untouched),
 *  - always-on: the manifest meta-data that switches Android's always-on / kill switch support off is corrected,
 *  - controls: the screen layout is edited (default ON / OFF, hidden, shown / enabled).
 * The result is written UNSIGNED on purpose (sign it with MT Manager), or signed with the FM key if asked.
 */
public final class VpnEnhancer {
    private VpnEnhancer() {}

    static final String SHIM_PREFIX = "Lcom/chanit/featuremerger/vpnenh/";
    static final String SHIM_TYPE = "Lcom/chanit/featuremerger/vpnenh/FmEnh;";
    static final String PFD = "Landroid/os/ParcelFileDescriptor;";
    static final String INET = "Ljava/net/InetAddress;";
    static final String OPEN = "@FME{", CLOSE = "}@";
    static final int CFG_LEN = 240;
    private static final int A_ENABLED = 0x0101000e, A_VIS = 0x010100dc, A_CHECKED = 0x01010106, A_VALUE = 0x01010024;

    public static final String DNS = "DNS", MTU = "MTU", V6 = "V6", MET = "MET", AON = "AON",
            CHECK_ON = "CHECK_ON", CHECK_OFF = "CHECK_OFF", HIDE = "HIDE", SHOW = "SHOW";

    /** One change the user asked for. */
    public static final class Op {
        public String kind;           // DNS MTU V6 MET AON CHECK_ON CHECK_OFF HIDE SHOW
        public String arg;            // DNS: "1.1.1.1,1.0.0.1"   MTU: "1380"
        public String label;          // text for the plan list
        public VpnFeatures.Feat ctl;  // controls only

        public Op(String kind, String arg, String label) {
            this.kind = kind;
            this.arg = arg;
            this.label = label;
        }

        boolean engine() { return DNS.equals(kind) || MTU.equals(kind) || V6.equals(kind) || MET.equals(kind); }

        boolean control() { return ctl != null; }
    }

    public static final class Plan {
        public Model.Apk vpn;
        public final List<Op> ops = new ArrayList<>();
        public boolean sign;
    }

    public static final class Result {
        public File out;
        public boolean ok;
        public String report = "";
    }

    // ------------------------------------------------------------------ run
    public static Result run(Context ctx, Plan plan, Merger.Sink s) throws Exception {
        Result res = new Result();
        StringBuilder rp = new StringBuilder();
        rp.append("[VPN ENHANCER] ").append(plan.vpn.label).append("  (").append(plan.vpn.pkg).append(")\n");
        rp.append("Changes:\n");
        for (Op o : plan.ops) rp.append("- ").append(o.label).append('\n');
        File work = new File(ctx.getCacheDir(), "vpnenh");
        VpnTransplant.deleteTree(work);
        //noinspection ResultOfMethodCallIgnored
        work.mkdirs();
        File src = new File(plan.vpn.path);
        if (plan.ops.isEmpty()) throw new IOException("Nothing chosen yet.");

        s.step(5, "Scanning " + plan.vpn.label);
        VpnFeatures.Result sc = VpnFeatures.scan(ctx, src);
        if (sc.alreadyEnhanced) throw new IOException("This VPN already contains an enhancement. Use the original APK, add your changes again, and build once.");

        boolean engine = false, aon = false;
        for (Op o : plan.ops) {
            if (o.engine()) engine = true;
            if (AON.equals(o.kind)) aon = true;
        }
        if (engine && sc.calls("establish") == 0)
            throw new IOException("This VPN never calls Builder.establish() in its own code (the tunnel is started somewhere else, for example in native code), so DNS / MTU / IPv6 / metered cannot be changed here.");

        // ---------- manifest + layout edits
        Map<String, byte[]> repBytes = new LinkedHashMap<>();
        try (ZipFile zf = new ZipFile(src)) {
            Axml mf = null;
            ZipEntry me = zf.getEntry("AndroidManifest.xml");
            if (me == null) throw new IOException("No AndroidManifest.xml");
            if (aon) {
                s.step(15, "Editing manifest (always-on)");
                mf = Axml.parse(ApkZip.readAll(zf, me));
                int n = alwaysOn(mf);
                rp.append("Always-on: ").append(n > 0 ? "switched ON in " + n + " place(s)" : "was not switched off, nothing to change").append('\n');
                if (n > 0) repBytes.put("AndroidManifest.xml", mf.build());
            }
            Map<String, Axml> layouts = new LinkedHashMap<>();
            for (Op o : plan.ops) {
                if (!o.control()) continue;
                int n = 0;
                for (String p : o.ctl.layoutPaths) n += editLayout(zf, layouts, p, o.ctl.viewId, o.kind);
                rp.append("Control \"").append(o.ctl.title).append("\": ").append(o.kind).append(" in ").append(n).append(" place(s)\n");
                if (n == 0) rp.append("WARN  control not found in its layout file\n");
            }
            for (Map.Entry<String, Axml> e : layouts.entrySet()) repBytes.put(e.getKey(), e.getValue().build());
        }

        // ---------- dex rewrite
        Map<String, File> repFiles = new LinkedHashMap<>();
        List<String> dexNames;
        String cfg = engine ? buildCfg(plan) : null;
        int rewrittenCalls = 0;
        try (ZipFile zf = new ZipFile(src)) {
            dexNames = VpnTransplant.dexNames(zf);
            if (engine) {
                final boolean dns = has(plan, DNS), mtu = has(plan, MTU);
                int idx = 0, total = Math.max(1, dexNames.size());
                for (String dn : dexNames) {
                    s.step(25 + 35 * idx / total, "Rewriting " + dn);
                    File in = new File(work, "in_" + idx + ".dex");
                    File out = new File(work, "out_" + idx + ".dex");
                    VpnTransplant.extract(zf, dn, in);
                    int[] cnt = {0};
                    rewriteDex(in, out, dns, mtu, cnt);
                    //noinspection ResultOfMethodCallIgnored
                    in.delete();
                    if (cnt[0] > 0) {
                        repFiles.put(dn, out);
                        rewrittenCalls += cnt[0];
                    } else {
                        //noinspection ResultOfMethodCallIgnored
                        out.delete();
                    }
                    idx++;
                }
            }
        }
        if (engine && repFiles.isEmpty()) throw new IOException("No Builder call could be redirected.");

        // ---------- helper dex
        File shim = null;
        if (engine) {
            s.step(62, "Building helper code");
            if (cfg.length() > CFG_LEN) throw new IOException("Settings too long.");
            File raw = new File(work, "shim_raw.dex");
            int n = BridgeDex.extract(ctx, raw, SHIM_PREFIX);
            s.log("Helper: " + n + " class(es)");
            byte[] bytes = ApkZip.readFile(raw);
            patchCfg(bytes, cfg);
            File patched = new File(work, "shim_patched.dex");
            try (FileOutputStream o = new FileOutputStream(patched)) { o.write(bytes); }
            DexFile hf = DexFileFactory.loadDexFile(patched, Opcodes.getDefault());
            DexPool pool = new DexPool(Opcodes.forApi(23));
            for (ClassDef cd : hf.getClasses()) pool.internClass(cd);
            shim = new File(work, "shim.dex");
            pool.writeTo(new FileDataStore(shim));
        }

        // ---------- write the apk
        s.step(72, "Writing new APK");
        File outDir = ctx.getExternalFilesDir("Output");
        if (outDir == null) outDir = new File(ctx.getFilesDir(), "Output");
        //noinspection ResultOfMethodCallIgnored
        outDir.mkdirs();
        String safe = plan.vpn.label.replaceAll("[^A-Za-z0-9._-]", "_");
        File unsigned = new File(plan.sign ? work : outDir, safe + "_ENHANCED_UNSIGNED.apk");
        try (ApkZip.Writer w = new ApkZip.Writer(unsigned)) {
            w.copy(src, repBytes, repFiles, true);
            if (shim != null) w.put("classes" + (dexNames.size() + 1) + ".dex", ApkZip.readFile(shim), false);
        }
        File out = unsigned;
        if (plan.sign) {
            s.step(82, "Signing with the FM key");
            out = new File(outDir, safe + "_ENHANCED.apk");
            Signer.sign(new File(ctx.getFilesDir(), "keys"), unsigned, out);
        }
        if (engine) {
            rp.append("Builder calls redirected: ").append(rewrittenCalls).append(" in ").append(repFiles.keySet()).append('\n');
            if (has(plan, DNS) && sc.calls("addDnsServer") == 0) rp.append("DNS: the VPN sets none, so the chosen DNS is added when the tunnel starts.\n");
            if (has(plan, MTU) && sc.calls("setMtu") == 0) rp.append("MTU: the VPN sets none, so the chosen MTU is added when the tunnel starts.\n");
            rp.append("Settings written into the helper: ").append(cfg).append('\n');
        }

        // ---------- verify
        s.step(90, "Scanning the new APK");
        List<String> fails = new ArrayList<>();
        rp.append("\n[VERIFY]\n");
        verify(ctx, out, plan, engine, fails, rp);
        VpnTransplant.deleteTree(work);

        res.out = out;
        res.ok = fails.isEmpty();
        rp.append('\n').append(res.ok ? "[RESULT] OK" : "[RESULT] FAILED (" + fails.size() + " check(s)). Copy this report and send it to Claude.").append('\n');
        if (res.ok) rp.append(plan.sign ? "Next: uninstall the old VPN app, install this one.\n"
                : "Next: sign this APK with MT Manager, uninstall the old VPN app, install the signed one.\n");
        res.report = rp.toString();
        s.step(100, res.ok ? "Done" : "Done, with problems");
        return res;
    }

    private static boolean has(Plan p, String kind) {
        for (Op o : p.ops) if (kind.equals(o.kind)) return true;
        return false;
    }

    private static String arg(Plan p, String kind) {
        for (Op o : p.ops) if (kind.equals(o.kind)) return o.arg;
        return null;
    }

    private static String buildCfg(Plan p) {
        StringBuilder sb = new StringBuilder();
        if (has(p, DNS)) sb.append("dns=").append(arg(p, DNS)).append(';');
        if (has(p, MTU)) sb.append("mtu=").append(arg(p, MTU)).append(';');
        if (has(p, V6)) sb.append("v6=1;");
        if (has(p, MET)) sb.append("met=0;");
        return sb.toString();
    }

    // ------------------------------------------------------------------ verify
    private static void verify(Context ctx, File out, Plan plan, boolean engine, List<String> fails, StringBuilder rp) {
        try {
            PackageInfo pi = ctx.getPackageManager().getPackageArchiveInfo(out.getAbsolutePath(), PackageManager.GET_SERVICES);
            if (pi == null) {
                fails.add("Android cannot read the new APK");
                rp.append("FAIL  Android cannot read the new APK (manifest problem)\n");
            } else {
                rp.append("PASS  Android reads the new APK: ").append(pi.packageName).append(" ").append(pi.versionName).append('\n');
            }
        } catch (Throwable t) {
            rp.append("WARN  package check skipped: ").append(VpnTransplant.shortErr(t)).append('\n');
        }
        if (!engine) return;
        VpnFeatures.Result r = VpnFeatures.scan(ctx, out);
        if (!r.alreadyEnhanced) {
            fails.add("helper class missing");
            rp.append("FAIL  helper class FmEnh is not inside the new APK\n");
        } else {
            rp.append("PASS  helper class FmEnh is inside the new APK\n");
        }
        int left = r.calls("establish");
        // the helper itself calls establish() once; it is skipped by the scan, so any call left is a missed one
        if (left > 0) {
            fails.add("establish calls left");
            rp.append("FAIL  ").append(left).append(" Builder.establish() call(s) were not redirected\n");
        } else {
            rp.append("PASS  every Builder.establish() call goes through the helper\n");
        }
        if (has(plan, DNS) && r.calls("addDnsServer") > 0) {
            fails.add("dns calls left");
            rp.append("FAIL  ").append(r.calls("addDnsServer")).append(" addDnsServer call(s) were not redirected\n");
        }
        if (has(plan, MTU) && r.calls("setMtu") > 0) {
            fails.add("mtu calls left");
            rp.append("FAIL  ").append(r.calls("setMtu")).append(" setMtu call(s) were not redirected\n");
        }
    }

    // ------------------------------------------------------------------ dex rewrite
    private static void rewriteDex(File in, File out, final boolean dns, final boolean mtu, final int[] count) throws IOException {
        DexFile df = DexFileFactory.loadDexFile(in, Opcodes.getDefault());
        DexRewriter rw = new DexRewriter(new RewriterModule() {
            @Override public Rewriter<Instruction> getInstructionRewriter(Rewriters rewriters) {
                return ins -> {
                    Instruction x = swap(ins, dns, mtu);
                    if (x != null) {
                        count[0]++;
                        return x;
                    }
                    return ins;
                };
            }
        });
        DexFile done = rw.getDexFileRewriter().rewrite(df);
        DexPool pool = new DexPool(df.getOpcodes());
        for (ClassDef cd : done.getClasses()) pool.internClass(cd);
        pool.writeTo(new FileDataStore(out));
    }

    /**
     * establish() -> FmEnh.establish(builder); addDnsServer(x) -> FmEnh.addDnsServer(builder, x); setMtu(n) -> FmEnh.setMtu(builder, n).
     * The register layout stays the same, only invoke-virtual becomes invoke-static.
     */
    private static Instruction swap(Instruction i, boolean dns, boolean mtu) {
        if (!(i instanceof ReferenceInstruction)) return null;
        Reference r = ((ReferenceInstruction) i).getReference();
        if (!(r instanceof MethodReference)) return null;
        MethodReference mr = (MethodReference) r;
        if (!VpnFeatures.BUILDER.equals(mr.getDefiningClass())) return null;
        String name = mr.getName();
        List<? extends CharSequence> pt = mr.getParameterTypes();
        MethodReference nr;
        if ("establish".equals(name) && pt.isEmpty()) {
            nr = new ImmutableMethodReference(SHIM_TYPE, "establish", Arrays.asList(VpnFeatures.BUILDER), PFD);
        } else if (dns && "addDnsServer".equals(name) && pt.size() == 1 && INET.contentEquals(pt.get(0))) {
            nr = new ImmutableMethodReference(SHIM_TYPE, "addDnsServer", Arrays.asList(VpnFeatures.BUILDER, INET), VpnFeatures.BUILDER);
        } else if (dns && "addDnsServer".equals(name) && pt.size() == 1 && "Ljava/lang/String;".contentEquals(pt.get(0))) {
            nr = new ImmutableMethodReference(SHIM_TYPE, "addDnsServer", Arrays.asList(VpnFeatures.BUILDER, "Ljava/lang/String;"), VpnFeatures.BUILDER);
        } else if (mtu && "setMtu".equals(name) && pt.size() == 1 && "I".contentEquals(pt.get(0))) {
            nr = new ImmutableMethodReference(SHIM_TYPE, "setMtu", Arrays.asList(VpnFeatures.BUILDER, "I"), VpnFeatures.BUILDER);
        } else {
            return null;
        }
        Opcode op = i.getOpcode();
        if (op == Opcode.INVOKE_VIRTUAL && i instanceof Instruction35c) {
            Instruction35c c = (Instruction35c) i;
            return new ImmutableInstruction35c(Opcode.INVOKE_STATIC, c.getRegisterCount(), c.getRegisterC(),
                    c.getRegisterD(), c.getRegisterE(), c.getRegisterF(), c.getRegisterG(), nr);
        }
        if (op == Opcode.INVOKE_VIRTUAL_RANGE && i instanceof Instruction3rc) {
            Instruction3rc c = (Instruction3rc) i;
            return new ImmutableInstruction3rc(Opcode.INVOKE_STATIC_RANGE, c.getStartRegister(), c.getRegisterCount(), nr);
        }
        return null;
    }

    /** Writes the settings text into the placeholder of the helper dex (same length) and fixes the dex header. */
    private static void patchCfg(byte[] dex, String payload) throws Exception {
        StringBuilder mk = new StringBuilder(OPEN);
        for (int i = 0; i < CFG_LEN; i++) mk.append('#');
        mk.append(CLOSE);
        byte[] mark = mk.toString().getBytes(StandardCharsets.US_ASCII);
        int at = -1, found = 0;
        for (int i = 0; i + mark.length <= dex.length; i++) {
            if (dex[i] != mark[0]) continue;
            boolean eq = true;
            for (int k = 1; k < mark.length; k++) if (dex[i + k] != mark[k]) { eq = false; break; }
            if (eq) {
                if (at < 0) at = i;
                found++;
            }
        }
        if (at < 0) throw new IOException("Helper settings text not found inside the helper dex");
        if (found != 1) throw new IOException("Helper settings text found " + found + " times");
        StringBuilder nw = new StringBuilder(OPEN).append(payload);
        while (nw.length() < OPEN.length() + CFG_LEN) nw.append('#');
        nw.append(CLOSE);
        byte[] nb = nw.toString().getBytes(StandardCharsets.US_ASCII);
        if (nb.length != mark.length) throw new IOException("Helper settings length mismatch");
        System.arraycopy(nb, 0, dex, at, nb.length);
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        md.update(dex, 32, dex.length - 32);
        System.arraycopy(md.digest(), 0, dex, 12, 20);
        Adler32 ad = new Adler32();
        ad.update(dex, 12, dex.length - 12);
        long v = ad.getValue();
        dex[8] = (byte) v;
        dex[9] = (byte) (v >> 8);
        dex[10] = (byte) (v >> 16);
        dex[11] = (byte) (v >> 24);
    }

    // ------------------------------------------------------------------ manifest: always-on
    private static int alwaysOn(Axml mf) {
        final int[] n = {0};
        mf.root.walk(e -> {
            if (!"meta-data".equals(e.name)) return;
            if ("android.net.VpnService.SUPPORTS_ALWAYS_ON".equals(e.text("name")) && "false".equals(e.text("value"))) {
                e.put(Axml.bool("value", A_VALUE, true));
                n[0]++;
            }
        });
        return n[0];
    }

    // ------------------------------------------------------------------ layouts: controls
    private static int editLayout(ZipFile zf, Map<String, Axml> cache, String path, int viewId, String op) throws IOException {
        Axml x = cache.get(path);
        if (x == null) {
            ZipEntry ze = zf.getEntry(path);
            if (ze == null) return 0;
            x = Axml.parse(ApkZip.readAll(zf, ze));
            cache.put(path, x);
        }
        return apply(x.root, viewId, op);
    }

    private static int apply(Axml.Elem e, int id, String op) {
        int n = 0;
        Axml.Attr a = e.attr("id");
        if (a != null && a.type == Axml.T_REF && a.data == id) {
            if (HIDE.equals(op)) {
                e.put(Axml.hex("visibility", A_VIS, 2));
            } else if (SHOW.equals(op)) {
                e.put(Axml.hex("visibility", A_VIS, 0));
                e.put(Axml.bool("enabled", A_ENABLED, true));
            } else if (CHECK_ON.equals(op)) {
                e.put(Axml.bool("checked", A_CHECKED, true));
            } else if (CHECK_OFF.equals(op)) {
                e.put(Axml.bool("checked", A_CHECKED, false));
            }
            n++;
        }
        for (Axml.Elem k : e.kids) n += apply(k, id, op);
        return n;
    }
}
