package com.chanit.featuremerger;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.InputType;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.chanit.featuremerger.core.AiHelper;
import com.chanit.featuremerger.core.Instruct;
import com.chanit.featuremerger.core.Merger;
import com.chanit.featuremerger.core.Model;
import com.chanit.featuremerger.core.Store;
import com.chanit.featuremerger.core.VpnEnhancer;
import com.chanit.featuremerger.core.VpnFeatures;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * VPN enhancer + feature rewriter. Pick a VPN, see its features as a list (engine items and every screen with its
 * clickable controls), tap one, choose a ready-made improvement or write a short instruction, then build. The improved
 * version replaces the original behaviour inside the VPN app.
 */
public class EnhanceActivity extends AppCompatActivity {
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Store store;
    private final List<Model.Apk> vpns = new ArrayList<>();
    private Model.Apk cur;
    private VpnFeatures.Result scan;
    private final VpnEnhancer.Plan plan = new VpnEnhancer.Plan();
    private final List<String> notes = new ArrayList<>();
    private LinearLayout featBox, planBox, outBox;
    private Spinner spin;
    private LinearProgressIndicator bar;
    private TextView status, report, aiLine;
    private CheckBox signBox;
    private MaterialButton btnBuild;
    private File built;
    private String lastReport = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);
        ScrollView sv = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(20), dp(16), dp(40));
        sv.addView(page);
        setContentView(sv);

        page.addView(text("VPN enhancer", 22, true));
        page.addView(text("1. Pick the VPN and press Scan.\n2. Tap a feature in the list and choose how to improve it (or write a short instruction).\n"
                + "3. Press Build: the improved version replaces the original behaviour inside the VPN.", 13, false));

        aiLine = text("", 12, true);
        page.addView(aiLine);
        page.addView(btn("AI setup", v -> aiSetup()));
        refreshAi();

        loadVpns();
        spin = new Spinner(this);
        List<String> names = new ArrayList<>();
        for (Model.Apk a : vpns) names.add(a.label + (a.vpn ? "  (VPN)" : ""));
        spin.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        page.addView(spin);
        MaterialButton scanBtn = btn("Scan features", v -> doScan());
        page.addView(scanBtn);
        if (vpns.isEmpty()) page.addView(text("No apps yet. Add the VPN APK in the Apps tab first.", 13, false));

        status = text("", 12, false);
        page.addView(status);
        bar = new LinearProgressIndicator(this);
        bar.setMax(100);
        bar.setVisibility(View.GONE);
        page.addView(bar);

        featBox = box();
        page.addView(featBox);

        page.addView(text("Your changes", 16, true));
        planBox = box();
        page.addView(planBox);
        signBox = new CheckBox(this);
        signBox.setText("Sign with the FM key (leave off if you sign with MT Manager)");
        page.addView(signBox);
        btnBuild = btn("Build enhanced APK", v -> build());
        page.addView(btnBuild);
        page.addView(btn("Copy brief for Claude", v -> copy("brief", brief(), "Brief copied. Paste it in the chat.")));

        outBox = box();
        page.addView(outBox);
        report = text("", 11, false);
        report.setTypeface(Typeface.MONOSPACE);
        report.setTextIsSelectable(true);
        page.addView(report);
        renderPlan();
    }

    private void loadVpns() {
        List<Model.Apk> all = new ArrayList<>();
        for (File f : store.listApks()) {
            Model.Apk a = store.loadCached(f);
            if (a != null) all.add(a);
        }
        for (Model.Apk a : all) if (a.vpn) vpns.add(a);
        for (Model.Apk a : all) if (!a.vpn) vpns.add(a);
    }

    // ------------------------------------------------------------------ scan + list
    private void doScan() {
        if (vpns.isEmpty()) return;
        cur = vpns.get(Math.max(0, spin.getSelectedItemPosition()));
        plan.vpn = cur;
        plan.ops.clear();
        notes.clear();
        renderPlan();
        outBox.removeAllViews();
        report.setText("");
        featBox.removeAllViews();
        bar.setVisibility(View.VISIBLE);
        bar.setIndeterminate(true);
        status.setText("Reading " + cur.label + " ...");
        final Model.Apk target = cur;
        exec.execute(() -> {
            VpnFeatures.Result r = VpnFeatures.scan(this, new File(target.path));
            ui.post(() -> {
                scan = r;
                bar.setVisibility(View.GONE);
                bar.setIndeterminate(false);
                status.setText(r.engine.size() + " engine items, " + r.controls.size() + " clickable controls found."
                        + (r.alreadyEnhanced ? "\nThis APK already contains an enhancement: use the original APK." : "")
                        + (r.notes.isEmpty() ? "" : "\n" + join(r.notes)));
                renderFeatures();
            });
        });
    }

    private void renderFeatures() {
        featBox.removeAllViews();
        if (scan == null) return;
        featBox.addView(text("VPN engine", 16, true));
        for (VpnFeatures.Feat f : scan.engine) featBox.addView(row(f));
        String g = "";
        for (VpnFeatures.Feat f : scan.controls) {
            if (!f.group.equals(g)) {
                g = f.group;
                featBox.addView(text(g, 15, true));
            }
            featBox.addView(row(f));
        }
        if (scan.controls.isEmpty()) featBox.addView(text("No screens with clickable controls were found in the resources.", 12, false));
    }

    private View row(final VpnFeatures.Feat f) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(8), dp(8), dp(8), dp(8));
        TypedValue tv = new TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) r.setBackgroundResource(tv.resourceId);
        r.addView(text(f.title, 14, true));
        TextView d = text(f.detail, 12, false);
        d.setAlpha(0.75f);
        r.addView(d);
        r.setOnClickListener(v -> openFeature(f));
        return r;
    }

    // ------------------------------------------------------------------ one feature: recipes + own words
    private void openFeature(final VpnFeatures.Feat f) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(text(f.detail, 12, false));
        final AlertDialog[] dlg = new AlertDialog[1];
        List<Instruct.Recipe> rs = Instruct.recipes(f);
        if (rs.isEmpty()) box.addView(text("No ready-made improvement for this one. Write what you want below, it goes into the brief.", 12, true));
        for (final Instruct.Recipe r : rs) {
            box.addView(btn(r.label, v -> {
                addOps(r.ops);
                dlg[0].dismiss();
            }));
        }
        final EditText et = new EditText(this);
        et.setHint("Or write it, e.g. \"dns google, mtu 1350\"");
        et.setMinLines(2);
        box.addView(et);
        box.addView(btn("Ask AI (researches, picks best settings)", v -> {
            askAi(f, et.getText().toString());
            dlg[0].dismiss();
        }));
        dlg[0] = new MaterialAlertDialogBuilder(this)
                .setTitle(f.title)
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add my words", (d, w) -> {
                    Instruct.Out o = Instruct.parse(f, et.getText().toString());
                    if (!o.ops.isEmpty()) {
                        addOps(o.ops);
                        Toast.makeText(this, "Understood: " + join(o.understood), Toast.LENGTH_LONG).show();
                    } else if (!o.leftover.isEmpty()) {
                        if (AiHelper.load(this).ready()) {
                            askAi(f, o.leftover);
                        } else {
                            notes.add(f.title + ": " + o.leftover);
                            Toast.makeText(this, "Not a ready-made improvement. Saved in the brief. Set up the AI helper to let it handle this.", Toast.LENGTH_LONG).show();
                        }
                    }
                    renderPlan();
                }).create();
        dlg[0].show();
    }

    private void addOps(List<VpnEnhancer.Op> ops) {
        for (VpnEnhancer.Op n : ops) {
            for (int i = plan.ops.size() - 1; i >= 0; i--) {
                VpnEnhancer.Op o = plan.ops.get(i);
                boolean same = n.ctl == null ? (o.ctl == null && o.kind.equals(n.kind))
                        : (o.ctl != null && o.ctl.viewId == n.ctl.viewId && o.ctl.layout.equals(n.ctl.layout));
                if (same) plan.ops.remove(i);
            }
            plan.ops.add(n);
        }
        renderPlan();
    }

    private void renderPlan() {
        planBox.removeAllViews();
        if (plan.ops.isEmpty()) planBox.addView(text("Nothing chosen yet.", 12, false));
        for (final VpnEnhancer.Op o : new ArrayList<>(plan.ops)) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            TextView t = text(o.label, 13, false);
            r.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            r.addView(btn("\u2715", v -> {
                plan.ops.remove(o);
                renderPlan();
            }));
            planBox.addView(r);
        }
        for (String n : notes) planBox.addView(text("For Claude: " + n, 12, false));
        if (btnBuild != null) btnBuild.setEnabled(!plan.ops.isEmpty() && cur != null);
    }

    // ------------------------------------------------------------------ AI helper
    private void refreshAi() {
        AiHelper.Config c = AiHelper.load(this);
        if (!c.ready()) {
            aiLine.setText("AI helper: not set up (tap AI setup, a free key takes 1 minute)");
        } else {
            aiLine.setText("AI helper: " + (AiHelper.CLAUDE.equals(c.provider) ? "Claude" : "Gemini (free)")
                    + "  \u00B7  " + AiHelper.usedToday(this) + "/" + c.cap + " asks today");
        }
    }

    private void aiSetup() {
        final AiHelper.Config cur = AiHelper.load(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(text("Free: Google Gemini key (no card, stops when the free limit is used up). A free key cannot search the web, the AI answers from its own knowledge. The newest working model is picked automatically.\nOr paste a Claude API key (paid, can search the web; set a spend limit in the Anthropic console).", 12, false));
        final RadioGroup rg = new RadioGroup(this);
        final RadioButton g = new RadioButton(this);
        g.setText("Gemini (free key)");
        final RadioButton cl = new RadioButton(this);
        cl.setText("Claude (paid key)");
        rg.addView(g);
        rg.addView(cl);
        (AiHelper.CLAUDE.equals(cur.provider) ? cl : g).setChecked(true);
        box.addView(rg);
        box.addView(btn("Get a free Gemini key", v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))));
        final EditText key = new EditText(this);
        key.setHint(cur.ready() ? "Key saved. Leave empty to keep it." : "Paste the API key here");
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(key);
        final EditText model = new EditText(this);
        model.setHint("Model name (leave empty = automatic)");
        model.setText(cur.model);
        box.addView(model);
        final EditText cap = new EditText(this);
        cap.setHint("Asks per day (default 20)");
        cap.setText(String.valueOf(cur.cap));
        cap.setInputType(InputType.TYPE_CLASS_NUMBER);
        box.addView(cap);
        new MaterialAlertDialogBuilder(this)
                .setTitle("AI helper")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    try {
                        AiHelper.Config n = new AiHelper.Config();
                        n.provider = cl.isChecked() ? AiHelper.CLAUDE : AiHelper.GEMINI;
                        String k = key.getText().toString().trim();
                        n.key = k.isEmpty() && n.provider.equals(cur.provider) ? cur.key : k;
                        n.model = model.getText().toString().trim();
                        try {
                            n.cap = Math.max(1, Math.min(500, Integer.parseInt(cap.getText().toString().trim())));
                        } catch (Exception e) {
                            n.cap = 20;
                        }
                        AiHelper.save(this, n);
                        Toast.makeText(this, n.ready() ? "AI helper saved" : "Key is missing", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Could not save: " + e, Toast.LENGTH_LONG).show();
                    }
                    refreshAi();
                }).show();
    }

    private void askAi(final VpnFeatures.Feat f, final String words) {
        if (!AiHelper.load(this).ready()) {
            aiSetup();
            return;
        }
        bar.setVisibility(View.VISIBLE);
        bar.setIndeterminate(true);
        status.setText("AI is thinking (and searching the web if allowed) ...");
        final Model.Apk apk = cur;
        final VpnFeatures.Result sc = scan;
        exec.execute(() -> {
            try {
                AiHelper.Answer a = AiHelper.ask(this, apk, f, sc, words);
                ui.post(() -> {
                    bar.setVisibility(View.GONE);
                    bar.setIndeterminate(false);
                    status.setText("AI answered.");
                    refreshAi();
                    showAnswer(f, a);
                });
            } catch (AiHelper.AiException e) {
                ui.post(() -> {
                    bar.setVisibility(View.GONE);
                    bar.setIndeterminate(false);
                    status.setText(e.getMessage());
                    refreshAi();
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } catch (Throwable t) {
                ui.post(() -> {
                    bar.setVisibility(View.GONE);
                    bar.setIndeterminate(false);
                    status.setText("AI error: " + t);
                });
            }
        });
    }

    private void showAnswer(final VpnFeatures.Feat f, final AiHelper.Answer a) {
        StringBuilder sb = new StringBuilder();
        if (!a.summary.isEmpty()) sb.append(a.summary).append("\n\n");
        if (a.ops.isEmpty()) sb.append("No setting could be made from this.\n");
        else {
            sb.append("Changes:\n");
            for (VpnEnhancer.Op o : a.ops) sb.append("\u2022 ").append(o.label).append('\n');
        }
        sb.append("\nWeb research: ").append(a.searched ? "yes" : "no (the AI answered from its own knowledge)");
        for (String s : a.sources) sb.append("\n  ").append(s);
        if (!a.dropped.isEmpty()) sb.append("\nIgnored: ").append(join(a.dropped));
        sb.append("\n(model: ").append(a.model).append(")");
        MaterialAlertDialogBuilder d = new MaterialAlertDialogBuilder(this).setTitle("AI suggestion: " + f.title)
                .setMessage(sb.toString()).setNegativeButton("Cancel", null);
        if (!a.ops.isEmpty()) d.setPositiveButton("Add to plan", (x, w) -> addOps(a.ops));
        d.show();
    }

    // ------------------------------------------------------------------ build
    private void build() {
        if (cur == null || plan.ops.isEmpty()) return;
        plan.vpn = cur;
        plan.sign = signBox.isChecked();
        btnBuild.setEnabled(false);
        bar.setVisibility(View.VISIBLE);
        bar.setProgress(0);
        outBox.removeAllViews();
        report.setText("");
        exec.execute(() -> {
            try {
                VpnEnhancer.Result r = VpnEnhancer.run(this, plan, new Merger.Sink() {
                    @Override public void step(int pct, String msg) {
                        ui.post(() -> {
                            bar.setProgress(pct);
                            status.setText(msg);
                        });
                    }

                    @Override public void log(String line) { }
                });
                ui.post(() -> done(r.ok, r.out, r.report));
            } catch (Throwable t) {
                StringBuilder sb = new StringBuilder("[RESULT] FAILED\n").append(t).append('\n');
                for (StackTraceElement e : t.getStackTrace()) {
                    sb.append("  at ").append(e).append('\n');
                    if (sb.length() > 1800) break;
                }
                ui.post(() -> done(false, null, sb.toString()));
            }
        });
    }

    private void done(boolean ok, File out, String rep) {
        bar.setVisibility(View.GONE);
        btnBuild.setEnabled(true);
        built = out;
        lastReport = rep;
        status.setText(ok ? "Done." : "Problem, see the report.");
        report.setText(rep);
        outBox.removeAllViews();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(btn("Copy report", v -> copy("report", lastReport, "Report copied. Paste it in the chat.")));
        if (out != null) row.addView(btn("Share / save APK", v -> share()));
        outBox.addView(row);
        if (out != null) outBox.addView(text("File: " + out.getAbsolutePath(), 11, false));
    }

    private void share() {
        if (built == null) return;
        Uri u = FileProvider.getUriForFile(this, getPackageName() + ".files", built);
        Intent i = new Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive")
                .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share enhanced APK"));
    }

    // ------------------------------------------------------------------ brief for Claude
    private String brief() {
        StringBuilder sb = new StringBuilder();
        sb.append("VPN ENHANCER BRIEF\n");
        if (cur != null) sb.append("App: ").append(cur.label).append(" (").append(cur.pkg).append(")\n");
        if (scan != null) sb.append(VpnFeatures.text(scan));
        sb.append("\nChanges chosen:\n");
        if (plan.ops.isEmpty()) sb.append("(none)\n");
        for (VpnEnhancer.Op o : plan.ops) sb.append("- ").append(o.label).append('\n');
        sb.append("\nMy instructions (not covered by the ready-made improvements):\n");
        if (notes.isEmpty()) sb.append("(none)\n");
        for (String n : notes) sb.append("- ").append(n).append('\n');
        sb.append("\nTask: research the best way to do this, and add it to the enhancer as a new improvement for this feature.\n");
        return sb.toString();
    }

    private void copy(String label, String s, String msg) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, s));
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ view helpers
    private static String join(List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String s : l) b.append(b.length() > 0 ? "; " : "").append(s);
        return b.toString();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, dp(6), 0, dp(2));
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    private LinearLayout box() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private MaterialButton btn(String label, View.OnClickListener l) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
    }
}
