package com.chanit.featuremerger.core;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Optional AI helper of the enhancer. The user pastes their own API key once. The AI reads the chosen VPN feature and
 * the user's words, researches the web when the provider allows it, and answers with a small JSON of SETTINGS from a fixed
 * list (DNS, MTU, IPv6, metered, always-on, control actions). It never writes code that is put into the APK: every answer
 * is checked here against the fixed list, shown to the user, and only then added to the plan.
 *
 * Limits: a daily cap counted inside the app (default 20 asks) plus the provider's own limit. When either is used up the
 * helper stops and says so; nothing is charged by this app.
 */
public final class AiHelper {
    private AiHelper() {}

    public static final String GEMINI = "gemini", CLAUDE = "claude";
    /**
     * Fallback list (stable, free-tier text models, checked Nov 2026) used only when the list of models cannot be read from
     * the API. The 2.5 models are NOT here: Google now serves them only to projects that used them before, so new keys get 404.
     */
    public static final String[] GEMINI_MODELS = {"gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-3.6-flash", "gemini-3.1-flash-lite"};
    public static final String CLAUDE_MODEL = "claude-haiku-5-5";

    public static final class Config {
        public String provider = GEMINI, key = "", model = "";
        public int cap = 20;

        public boolean ready() { return key != null && key.trim().length() >= 10; }
    }

    public static final class Answer {
        public String summary = "";
        public boolean searched;
        public String model = "";
        public final List<VpnEnhancer.Op> ops = new ArrayList<>();
        public final List<String> sources = new ArrayList<>();
        public final List<String> dropped = new ArrayList<>();
    }

    /** message is meant to be shown to the user as it is */
    public static final class AiException extends Exception {
        public AiException(String m) { super(m); }
    }

    // ------------------------------------------------------------------ storage (not part of Android backups)
    private static File dir(Context c) {
        File d = c.getNoBackupFilesDir();
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    public static Config load(Context c) {
        Config cfg = new Config();
        try {
            JSONObject o = new JSONObject(readFile(new File(dir(c), "ai_config.json")));
            cfg.provider = o.optString("provider", GEMINI);
            cfg.key = o.optString("key", "");
            cfg.model = o.optString("model", "");
            cfg.cap = Math.max(1, Math.min(500, o.optInt("cap", 20)));
        } catch (Throwable ignored) { }
        return cfg;
    }

    public static void save(Context c, Config cfg) throws Exception {
        JSONObject o = new JSONObject();
        o.put("provider", cfg.provider);
        o.put("key", cfg.key);
        o.put("model", cfg.model);
        o.put("cap", cfg.cap);
        try (FileOutputStream f = new FileOutputStream(new File(dir(c), "ai_config.json"))) {
            f.write(o.toString().getBytes("UTF-8"));
        }
    }

    private static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    public static int usedToday(Context c) {
        try {
            JSONObject o = new JSONObject(readFile(new File(dir(c), "ai_usage.json")));
            return today().equals(o.optString("d")) ? o.optInt("n") : 0;
        } catch (Throwable t) {
            return 0;
        }
    }

    private static void bump(Context c) {
        try {
            JSONObject o = new JSONObject();
            o.put("d", today());
            o.put("n", usedToday(c) + 1);
            try (FileOutputStream f = new FileOutputStream(new File(dir(c), "ai_usage.json"))) {
                f.write(o.toString().getBytes("UTF-8"));
            }
        } catch (Throwable ignored) { }
    }

    private static String readFile(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) {
            return new String(readAll(in), "UTF-8");
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[1 << 14];
        int r;
        while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
        return bo.toByteArray();
    }

    // ------------------------------------------------------------------ prompt
    private static final String SYSTEM =
            "You are the settings engine of an Android VPN patcher. The user picked ONE feature of a VPN app and wrote what they want "
                    + "(Hindi, Hinglish or English). Decide the best settings for it. Use web research when it helps, for example to find the best DNS "
                    + "or MTU for the user's network, country or game.\n"
                    + "Reply with ONE JSON object and nothing else:\n"
                    + "{\"summary\":\"1-3 short sentences in the user's own language (Hinglish in Roman letters if they wrote Hinglish)\","
                    + "\"ops\":[...],\"sources\":[\"https://...\"]}\n"
                    + "Allowed ops. Nothing else exists:\n"
                    + "{\"op\":\"DNS\",\"servers\":[\"1.1.1.1\",\"1.0.0.1\"]}  (1-4 public DNS servers, IP addresses only)\n"
                    + "{\"op\":\"MTU\",\"value\":1380}  (whole number 1200-1500)\n"
                    + "{\"op\":\"V6\"}  (send IPv6 into the tunnel so it cannot leak)\n"
                    + "{\"op\":\"MET\"}  (mark the VPN as not metered)\n"
                    + "{\"op\":\"AON\"}  (switch on always-on / kill switch support)\n"
                    + "{\"op\":\"CTL\",\"action\":\"CHECK_ON|CHECK_OFF|HIDE|SHOW\"}  (only when the chosen feature is a control on a screen)\n"
                    + "If the request cannot be done with these ops, answer \"ops\":[] and explain why in the summary. "
                    + "Never invent other ops and never output code.";

    private static String userPrompt(Model.Apk apk, VpnFeatures.Feat f, VpnFeatures.Result scan, String instruction) {
        StringBuilder sb = new StringBuilder();
        sb.append("VPN app: ").append(apk == null ? "?" : apk.label + " (" + apk.pkg + ")").append('\n');
        sb.append("Chosen feature: ").append(f.title).append("  [").append(f.kind).append("]\n");
        sb.append("Feature details: ").append(f.detail == null ? "" : f.detail).append('\n');
        if (VpnFeatures.C_CTL.equals(f.kind)) sb.append("It is a ").append(f.tag).append(f.checkable ? " that can be switched ON or OFF" : "").append(" on screen \"").append(f.group).append("\".\n");
        if (scan != null) {
            sb.append("Code facts: addDnsServer ").append(scan.calls("addDnsServer")).append(", setMtu ").append(scan.calls("setMtu"))
                    .append(", addRoute ").append(scan.calls("addRoute")).append(", setMetered ").append(scan.calls("setMetered"))
                    .append(", establish ").append(scan.calls("establish")).append(", always-on opt-out ").append(scan.alwaysOnOptOut).append('\n');
        }
        sb.append("User request: ").append(instruction == null || instruction.trim().isEmpty() ? "Improve this feature in the best way." : instruction.trim()).append('\n');
        return sb.toString();
    }

    // ------------------------------------------------------------------ ask
    public static Answer ask(Context c, Model.Apk apk, VpnFeatures.Feat f, VpnFeatures.Result scan, String instruction) throws AiException {
        Config cfg = load(c);
        if (!cfg.ready()) throw new AiException("AI key abhi set nahi hai. \"AI setup\" me key paste karo.");
        int used = usedToday(c);
        if (used >= cfg.cap) throw new AiException("Aaj ki AI limit puri ho gayi (" + used + "/" + cfg.cap + "). Kal try karo, ya AI setup me limit badhao.");
        String prompt = userPrompt(apk, f, scan, instruction);
        Raw raw = CLAUDE.equals(cfg.provider) ? askClaude(cfg, prompt) : askGemini(cfg, prompt);
        Answer a = parse(raw, f);
        a.searched = raw.searched;
        a.model = raw.model;
        bump(c);
        return a;
    }

    private static final class Raw {
        String text = "", model = "";
        boolean searched;
        final Set<String> sources = new LinkedHashSet<>();
    }

    private static final class Http {
        int code;
        String body = "";
    }

    private static Http post(String url, String[][] headers, String body) throws AiException {
        HttpURLConnection h = null;
        Http r = new Http();
        try {
            h = (HttpURLConnection) new URL(url).openConnection();
            h.setConnectTimeout(20000);
            h.setReadTimeout(90000);
            h.setRequestMethod("POST");
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/json");
            for (String[] kv : headers) h.setRequestProperty(kv[0], kv[1]);
            try (OutputStream o = h.getOutputStream()) {
                o.write(body.getBytes("UTF-8"));
            }
            r.code = h.getResponseCode();
            InputStream in = r.code >= 400 ? h.getErrorStream() : h.getInputStream();
            if (in != null) r.body = new String(readAll(in), "UTF-8");
            return r;
        } catch (java.io.IOException e) {
            throw new AiException("Internet / server se connect nahi hua (" + e.getClass().getSimpleName() + "). Net check karo.");
        } catch (Exception e) {
            throw new AiException("Request fail: " + e);
        } finally {
            if (h != null) h.disconnect();
        }
    }

    private static String errMsg(String body) {
        try {
            JSONObject e = new JSONObject(body).optJSONObject("error");
            if (e != null) return e.optString("message", "");
        } catch (Throwable ignored) { }
        return body.length() > 200 ? body.substring(0, 200) : body;
    }

    private static boolean mentions(String s, String... w) {
        String l = s.toLowerCase(Locale.ROOT);
        for (String x : w) if (l.contains(x)) return true;
        return false;
    }

    // ---- Gemini (free key from Google AI Studio)
    private static List<String> discovered;
    private static long discoveredAt;
    /** Free keys cannot use Google Search grounding, so after one refusal the helper stops trying it until the app restarts. */
    private static boolean searchRefused;
    private static final Pattern STABLE = Pattern.compile("^gemini-(\\d+(?:\\.\\d+)?)-flash(-lite)?$");

    private static Http get(String url, String[][] headers) throws AiException {
        HttpURLConnection h = null;
        Http r = new Http();
        try {
            h = (HttpURLConnection) new URL(url).openConnection();
            h.setConnectTimeout(15000);
            h.setReadTimeout(30000);
            for (String[] kv : headers) h.setRequestProperty(kv[0], kv[1]);
            r.code = h.getResponseCode();
            InputStream in = r.code >= 400 ? h.getErrorStream() : h.getInputStream();
            if (in != null) r.body = new String(readAll(in), "UTF-8");
            return r;
        } catch (Exception e) {
            throw new AiException("models list: " + e.getClass().getSimpleName());
        } finally {
            if (h != null) h.disconnect();
        }
    }

    /** Models this key can really call right now: newest stable Flash / Flash-Lite first. Never relies on an old hard-coded name. */
    private static synchronized List<String> geminiCandidates(Config cfg) {
        List<String> out = new ArrayList<>();
        if (cfg.model != null && cfg.model.trim().length() > 0) {
            out.add(cfg.model.trim());
            return out;
        }
        if (discovered != null && System.currentTimeMillis() - discoveredAt < 6L * 3600 * 1000) return discovered;
        try {
            Http h = get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", new String[][]{{"x-goog-api-key", cfg.key.trim()}});
            if (h.code == 200) {
                JSONArray ms = new JSONObject(h.body).optJSONArray("models");
                final java.util.Map<String, double[]> rank = new java.util.HashMap<>();
                if (ms != null) for (int i = 0; i < ms.length(); i++) {
                    JSONObject m = ms.getJSONObject(i);
                    String name = m.optString("name", "").replace("models/", "");
                    java.util.regex.Matcher mt = STABLE.matcher(name);
                    if (!mt.matches()) continue;
                    JSONArray meth = m.optJSONArray("supportedGenerationMethods");
                    boolean gen = false;
                    if (meth != null) for (int k = 0; k < meth.length(); k++) if ("generateContent".equals(meth.optString(k))) gen = true;
                    if (!gen) continue;
                    double ver = Double.parseDouble(mt.group(1));
                    if (ver < 3) continue; // 2.x is closed to new projects
                    rank.put(name, new double[]{ver, mt.group(2) == null ? 1 : 0});
                    out.add(name);
                }
                java.util.Collections.sort(out, new java.util.Comparator<String>() {
                    @Override public int compare(String x, String y) {
                        double[] a = rank.get(x), b = rank.get(y);
                        if (a[0] != b[0]) return a[0] > b[0] ? -1 : 1;
                        return Double.compare(b[1], a[1]); // Flash before Flash-Lite at the same version
                    }
                });
            }
        } catch (Throwable ignored) { }
        if (out.isEmpty()) for (String m : GEMINI_MODELS) out.add(m);
        if (out.size() > 4) out = new ArrayList<>(out.subList(0, 4));
        discovered = out;
        discoveredAt = System.currentTimeMillis();
        return out;
    }

    private static Raw askGemini(Config cfg, String prompt) throws AiException {
        List<String> models = geminiCandidates(cfg);
        AiException last = null;
        boolean limited = false;
        List<String> missing = new ArrayList<>();
        for (String model : models) {
            for (int pass = 0; pass < 2; pass++) {
                boolean search = pass == 0 && !searchRefused;
                if (pass == 0 && !search) continue; // search already known to be refused: go straight to the plain call
                try {
                    JSONObject body = new JSONObject();
                    body.put("system_instruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", SYSTEM))));
                    body.put("contents", new JSONArray().put(new JSONObject().put("role", "user")
                            .put("parts", new JSONArray().put(new JSONObject().put("text", prompt)))));
                    body.put("generationConfig", new JSONObject().put("temperature", 0.2));
                    if (search) body.put("tools", new JSONArray().put(new JSONObject().put("google_search", new JSONObject())));
                    Http h = post("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent",
                            new String[][]{{"x-goog-api-key", cfg.key.trim()}}, body.toString());
                    if (h.code == 200) {
                        Raw r = new Raw();
                        r.model = model;
                        JSONObject root = new JSONObject(h.body);
                        JSONArray cands = root.optJSONArray("candidates");
                        if (cands == null || cands.length() == 0) throw new AiException("AI ne jawab nahi diya (blocked ya khali). Dobara try karo.");
                        JSONObject cand = cands.getJSONObject(0);
                        JSONObject content = cand.optJSONObject("content");
                        JSONArray parts = content == null ? null : content.optJSONArray("parts");
                        StringBuilder sb = new StringBuilder();
                        if (parts != null) for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text", ""));
                        r.text = sb.toString();
                        JSONObject gm = cand.optJSONObject("groundingMetadata");
                        if (gm != null) {
                            r.searched = true;
                            JSONArray ch = gm.optJSONArray("groundingChunks");
                            if (ch != null) for (int i = 0; i < ch.length() && r.sources.size() < 4; i++) {
                                JSONObject w = ch.getJSONObject(i).optJSONObject("web");
                                if (w != null && w.optString("uri").length() > 0) r.sources.add(w.optString("title", "") + " " + w.optString("uri"));
                            }
                        }
                        return r;
                    }
                    String m = errMsg(h.body);
                    if (h.code == 400 && mentions(m, "api key not valid", "api_key_invalid")) throw new AiException("API key galat hai. AI setup me dobara paste karo.");
                    if (h.code == 404 || (h.code == 400 && mentions(m, "not found", "not supported for generatecontent", "no longer available", "no longer accessible"))
                            || (h.code == 403 && mentions(m, "no longer", "not available", "access to"))) {
                        missing.add(model);
                        last = new AiException("Model \"" + model + "\" ab is key ke liye available nahi hai.");
                        break; // next model
                    }
                    if (search) {
                        // the search tool was refused (normal on a free key): remember it and repeat without the tool
                        if (h.code == 400 || h.code == 403 || h.code == 429) searchRefused = true;
                        continue;
                    }
                    if (h.code == 401 || (h.code == 403 && mentions(m, "api key", "permission", "denied", "leaked")))
                        throw new AiException("Key ne kaam nahi kiya (" + h.code + "): " + m);
                    if (h.code == 429) {
                        limited = true;
                        break; // this model's free limit is used up: try the next one
                    }
                    throw new AiException("Gemini error " + h.code + ": " + m);
                } catch (AiException e) {
                    throw e;
                } catch (Exception e) {
                    throw new AiException("Gemini ka jawab samajh nahi aaya: " + e);
                }
            }
        }
        synchronized (AiHelper.class) {
            discovered = null; // look the list up again next time
        }
        if (limited) throw new AiException("Gemini ki free limit puri ho gayi. Thodi der / kal try karo.");
        if (!missing.isEmpty()) throw new AiException("Ye models is key se nahi chale: " + missing + ". AI setup me \"Model\" me koi chalne wala naam daal do (jaise gemini-3.8-flash).");
        throw last != null ? last : new AiException("Gemini se jawab nahi mila.");
    }

    // ---- Claude (paid API key; set a spend limit in the Anthropic console)
    private static Raw askClaude(Config cfg, String prompt) throws AiException {
        String model = cfg.model != null && cfg.model.trim().length() > 0 ? cfg.model.trim() : CLAUDE_MODEL;
        for (int pass = 0; pass < 2; pass++) {
            boolean search = pass == 0;
            try {
                JSONObject body = new JSONObject();
                body.put("model", model);
                body.put("max_tokens", 1500);
                body.put("system", SYSTEM);
                body.put("messages", new JSONArray().put(new JSONObject().put("role", "user").put("content", prompt)));
                if (search) body.put("tools", new JSONArray().put(new JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)));
                Http h = post("https://api.anthropic.com/v1/messages",
                        new String[][]{{"x-api-key", cfg.key.trim()}, {"anthropic-version", "2023-06-01"}}, body.toString());
                if (h.code == 200) {
                    Raw r = new Raw();
                    r.model = model;
                    JSONArray content = new JSONObject(h.body).optJSONArray("content");
                    StringBuilder sb = new StringBuilder();
                    if (content != null) for (int i = 0; i < content.length(); i++) {
                        JSONObject b = content.getJSONObject(i);
                        String t = b.optString("type");
                        if ("text".equals(t)) sb.append(b.optString("text", ""));
                        if ("web_search_tool_result".equals(t)) {
                            r.searched = true;
                            JSONArray res = b.optJSONArray("content");
                            if (res != null) for (int k = 0; k < res.length() && r.sources.size() < 4; k++) {
                                JSONObject w = res.optJSONObject(k);
                                if (w != null && w.optString("url").length() > 0) r.sources.add(w.optString("title", "") + " " + w.optString("url"));
                            }
                        }
                    }
                    r.text = sb.toString();
                    return r;
                }
                String m = errMsg(h.body);
                if (h.code == 401) throw new AiException("Claude API key galat hai. AI setup me dobara paste karo.");
                if (h.code == 429) throw new AiException("Claude ki limit puri ho gayi (rate / spend limit). Thodi der baad ya limit badhakar try karo.");
                if (h.code == 400 && mentions(m, "credit", "balance", "billing", "spend")) throw new AiException("Claude credit / spend limit khatam: " + m);
                if (h.code == 404) throw new AiException("Model \"" + model + "\" nahi mila. AI setup me sahi model naam daalo.");
                if (search && (h.code == 400 || h.code == 403)) continue; // web search not enabled for this account: retry without it
                throw new AiException("Claude error " + h.code + ": " + m);
            } catch (AiException e) {
                throw e;
            } catch (Exception e) {
                throw new AiException("Claude ka jawab samajh nahi aaya: " + e);
            }
        }
        throw new AiException("Claude se jawab nahi mila.");
    }

    // ------------------------------------------------------------------ check the answer against the fixed list
    private static final Pattern V4 = Pattern.compile("^(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)$");
    private static final Pattern V6 = Pattern.compile("^[0-9a-fA-F:]{2,39}$");

    private static Answer parse(Raw raw, VpnFeatures.Feat f) throws AiException {
        String t = raw.text == null ? "" : raw.text;
        int s = t.indexOf('{'), e = t.lastIndexOf('}');
        if (s < 0 || e <= s) throw new AiException("AI ne sahi format me jawab nahi diya. Dobara try karo.");
        Answer a = new Answer();
        try {
            JSONObject o = new JSONObject(t.substring(s, e + 1));
            a.summary = o.optString("summary", "").trim();
            for (String src : raw.sources) a.sources.add(src);
            JSONArray srcs = o.optJSONArray("sources");
            if (srcs != null) for (int i = 0; i < srcs.length() && a.sources.size() < 4; i++) {
                String u = srcs.optString(i, "");
                if (u.startsWith("http") && !a.sources.contains(u)) a.sources.add(u);
            }
            JSONArray ops = o.optJSONArray("ops");
            boolean isCtl = VpnFeatures.C_CTL.equals(f.kind);
            Set<String> seen = new LinkedHashSet<>();
            if (ops != null) for (int i = 0; i < ops.length() && i < 12; i++) {
                JSONObject op = ops.optJSONObject(i);
                if (op == null) continue;
                String name = op.optString("op", "").toUpperCase(Locale.ROOT);
                if (isCtl && !"CTL".equals(name)) {
                    a.dropped.add(name + " (not for a screen control)");
                    continue;
                }
                if (!isCtl && "CTL".equals(name)) {
                    a.dropped.add("CTL (this feature is not a screen control)");
                    continue;
                }
                if (!seen.add(name)) continue;
                switch (name) {
                    case "DNS": {
                        JSONArray sv = op.optJSONArray("servers");
                        List<String> ok = new ArrayList<>();
                        if (sv != null) for (int k = 0; k < sv.length() && ok.size() < 4; k++) {
                            String x = sv.optString(k, "").trim();
                            boolean v6 = x.indexOf(':') >= 0 && V6.matcher(x).matches();
                            if ((V4.matcher(x).matches() || v6) && !ok.contains(x)) ok.add(x);
                        }
                        if (ok.isEmpty()) {
                            a.dropped.add("DNS (no valid address)");
                            break;
                        }
                        StringBuilder ips = new StringBuilder();
                        for (String x : ok) ips.append(ips.length() > 0 ? "," : "").append(x);
                        a.ops.add(Instruct.dns("AI pick", ips.toString()));
                        break;
                    }
                    case "MTU": {
                        int v = op.optInt("value", 0);
                        if (v < 1200 || v > 1500) {
                            a.dropped.add("MTU " + v + " (must be 1200-1500)");
                            break;
                        }
                        a.ops.add(Instruct.mtu("", String.valueOf(v)));
                        break;
                    }
                    case "V6":
                        a.ops.add(Instruct.v6());
                        break;
                    case "MET":
                        a.ops.add(Instruct.met());
                        break;
                    case "AON":
                        a.ops.add(Instruct.aon());
                        break;
                    case "CTL": {
                        String act = op.optString("action", "").toUpperCase(Locale.ROOT);
                        if ((act.equals("CHECK_ON") || act.equals("CHECK_OFF")) && !f.checkable) {
                            a.dropped.add(act + " (not a switch)");
                            break;
                        }
                        if (act.equals("CHECK_ON") || act.equals("CHECK_OFF") || act.equals("HIDE") || act.equals("SHOW"))
                            a.ops.add(Instruct.ctl(f, act, act.equals("HIDE") ? "hidden" : act.equals("SHOW") ? "shown and enabled" : act.equals("CHECK_ON") ? "ON by default" : "OFF by default"));
                        else a.dropped.add("CTL " + act);
                        break;
                    }
                    default:
                        a.dropped.add(name);
                        break;
                }
            }
        } catch (Exception ex) {
            throw new AiException("AI ka jawab padh nahi paya: " + ex.getMessage());
        }
        return a;
    }
}
