package com.chanit.featuremerger.core;

import android.content.Context;

import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.MethodImplementation;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.android.tools.smali.dexlib2.iface.reference.Reference;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Lists what a VPN app is made of, as a vertical list the user can pick from:
 *  - "VPN engine" items (DNS, MTU, IPv6, metered flag, always-on / kill switch, tunnel start, per-app list)
 *    with the number of places in the code that use them,
 *  - every screen / dialog (layout) with its clickable controls (buttons, switches, checkboxes, spinners ...).
 */
public final class VpnFeatures {
    private VpnFeatures() {}

    public static final String BUILDER = "Landroid/net/VpnService$Builder;";
    public static final String E_DNS = "dns", E_MTU = "mtu", E_V6 = "v6", E_MET = "met", E_AON = "aon", E_START = "start", E_APPS = "apps", C_CTL = "ctl";

    public static final class Feat {
        public String group, title, detail, kind;
        public int count;
        // control only
        public int viewId;
        public String layout, idName, tag;
        public boolean checkable;
        public List<String> layoutPaths = new ArrayList<>();
    }

    public static final class Result {
        public String vpnService;
        public int targetSdk;
        public boolean alwaysOnOptOut, alreadyEnhanced;
        public final Map<String, Integer> calls = new LinkedHashMap<>();
        public final Map<String, Integer> callsByDex = new LinkedHashMap<>();
        public final List<Feat> engine = new ArrayList<>();
        public final List<Feat> controls = new ArrayList<>();
        public final List<String> notes = new ArrayList<>();

        public int calls(String name) {
            Integer n = calls.get(name);
            return n == null ? 0 : n;
        }
    }

    private static final String[] LIB_LAYOUT = {"abc_", "mtrl_", "material_", "design_", "m3_", "notification_", "support_",
            "select_dialog", "custom_dialog", "browser_actions", "ime_", "preference", "expand_button", "image_frame",
            "test_", "language_", "oss_", "common_", "fb_", "ad_", "admob", "gms_", "googlesignin", "auth_", "play_"};

    /** Never throws: whatever cannot be read is skipped and mentioned in notes. */
    public static Result scan(Context ctx, File apk) {
        Result r = new Result();
        Arsc arsc = null;
        try (ZipFile zf = new ZipFile(apk)) {
            ZipEntry me = zf.getEntry("AndroidManifest.xml");
            if (me != null) readManifest(Axml.parse(ApkZip.readAll(zf, me)), r);
            ZipEntry ae = zf.getEntry("resources.arsc");
            if (ae != null) {
                try {
                    arsc = Arsc.parse(ApkZip.readAll(zf, ae));
                } catch (Throwable t) {
                    r.notes.add("Resources not readable: " + t.getMessage());
                }
            }
            countCalls(ctx, zf, r);
            if (arsc != null) controls(zf, arsc, r);
        } catch (Throwable t) {
            r.notes.add("Could not read the APK fully: " + t);
        }
        engine(r);
        return r;
    }

    // ------------------------------------------------------------------ manifest
    private static void readManifest(Axml mf, Result r) {
        String pkg = mf.root.plain("package") == null ? "" : mf.root.plain("package").text();
        Axml.Elem uses = mf.root.child("uses-sdk");
        if (uses != null && uses.text("targetSdkVersion") != null) {
            try {
                r.targetSdk = Integer.parseInt(uses.text("targetSdkVersion"));
            } catch (Exception ignored) { }
        }
        Axml.Elem app = mf.root.child("application");
        if (app == null) return;
        for (Axml.Elem k : app.kids) {
            if (!"service".equals(k.name)) continue;
            String perm = k.text("permission");
            if (perm == null || !perm.contains("BIND_VPN_SERVICE")) continue;
            String n = k.text("name");
            if (n == null) continue;
            r.vpnService = n.startsWith(".") ? pkg + n : (n.indexOf('.') < 0 ? pkg + "." + n : n);
            for (Axml.Elem m : k.kids) {
                if (!"meta-data".equals(m.name)) continue;
                if ("android.net.VpnService.SUPPORTS_ALWAYS_ON".equals(m.text("name")) && "false".equals(m.text("value"))) r.alwaysOnOptOut = true;
            }
        }
    }

    // ------------------------------------------------------------------ calls of VpnService.Builder in the code
    private static void countCalls(Context ctx, ZipFile zf, Result r) throws Exception {
        List<String> dexes = VpnTransplant.dexNames(zf);
        int i = 0;
        for (String dn : dexes) {
            File tmp = new File(ctx.getCacheDir(), "fmenh_scan_" + (i++) + ".dex");
            try {
                VpnTransplant.extract(zf, dn, tmp);
                DexFile df = DexFileFactory.loadDexFile(tmp, Opcodes.getDefault());
                int here = 0;
                for (ClassDef cd : df.getClasses()) {
                    if (cd.getType().startsWith("Lcom/chanit/featuremerger/vpnenh/")) {
                        r.alreadyEnhanced = true;
                        continue;
                    }
                    for (Method m : cd.getMethods()) {
                        MethodImplementation mi = m.getImplementation();
                        if (mi == null) continue;
                        for (Instruction ins : mi.getInstructions()) {
                            if (!(ins instanceof ReferenceInstruction)) continue;
                            Reference ref = ((ReferenceInstruction) ins).getReference();
                            if (!(ref instanceof MethodReference)) continue;
                            MethodReference mr = (MethodReference) ref;
                            if (!BUILDER.equals(mr.getDefiningClass())) continue;
                            Integer c = r.calls.get(mr.getName());
                            r.calls.put(mr.getName(), c == null ? 1 : c + 1);
                            here++;
                        }
                    }
                }
                r.callsByDex.put(dn, here);
            } catch (Throwable t) {
                r.notes.add(dn + " skipped: " + VpnTransplant.shortErr(t));
            } finally {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }
    }

    // ------------------------------------------------------------------ engine items
    private static void engine(Result r) {
        add(r, E_DNS, "DNS servers", r.calls("addDnsServer"),
                "Which DNS the VPN uses. Without one, the phone's normal DNS is used and can leak to your provider.");
        add(r, E_MTU, "Packet size (MTU)", r.calls("setMtu"),
                "Too big = slow / dropped connections on mobile data, too small = lower speed.");
        add(r, E_V6, "IPv6 handling", r.calls("addRoute") + r.calls("addAddress"),
                "IPv6 traffic can go around a VPN that only handles IPv4.");
        add(r, E_MET, "Metered flag", r.calls("setMetered"),
                "Whether Android treats the VPN as metered data (some apps then refuse big downloads).");
        Feat a = new Feat();
        a.group = "VPN engine";
        a.kind = E_AON;
        a.title = "Always-on / kill switch support";
        a.detail = r.vpnService == null ? "No VPN service declared in the manifest."
                : (r.alwaysOnOptOut ? "Switched OFF by the developer (meta-data false)." : "Declared as supported.")
                + " Kill switch = Android's \"Block connections without VPN\".";
        a.count = r.alwaysOnOptOut ? 0 : 1;
        r.engine.add(a);
        add(r, E_START, "Tunnel start (establish)", r.calls("establish"), "The moment the VPN interface is created.");
        add(r, E_APPS, "Per-app list (which apps use the VPN)", r.calls("addAllowedApplication") + r.calls("addDisallowedApplication"),
                "Edit the game list on the VPN tab.");
    }

    private static void add(Result r, String kind, String title, int n, String why) {
        Feat f = new Feat();
        f.group = "VPN engine";
        f.kind = kind;
        f.title = title;
        f.count = n;
        f.detail = (n > 0 ? n + " place" + (n == 1 ? "" : "s") + " in the code. " : "Not set by the VPN. ") + why;
        r.engine.add(f);
    }

    // ------------------------------------------------------------------ screens and controls
    private static void controls(ZipFile zf, Arsc arsc, Result r) {
        Set<String> seenLayouts = new HashSet<>();
        for (Arsc.Entry le : arsc.byId.values()) {
            if (!"layout".equals(le.type) || le.name == null) continue;
            if (!seenLayouts.add(le.name)) continue;
            if (isLibLayout(le.name)) continue;
            ArrayList<String> paths = new ArrayList<>();
            for (String s : le.strings) if (s.endsWith(".xml")) paths.add(s);
            if (paths.isEmpty()) continue;
            if (r.controls.size() > 250) break;
            try {
                ZipEntry ze = zf.getEntry(paths.get(0));
                if (ze == null) continue;
                Axml x = Axml.parse(ApkZip.readAll(zf, ze));
                final String lname = le.name;
                final ArrayList<String> lp = paths;
                final Set<Integer> got = new HashSet<>();
                x.root.walk(el -> {
                    Axml.Attr ida = el.attr("id");
                    if (ida == null || ida.type != Axml.T_REF) return;
                    boolean click = el.attr("onClick") != null || "true".equals(el.text("clickable"));
                    if (!ApkAnalyzer.isInteractiveTag(el.name) && !click) return;
                    if (!got.add(ida.data)) return;
                    Feat f = new Feat();
                    f.kind = C_CTL;
                    f.group = kindOfLayout(lname) + ": " + pretty(lname);
                    f.viewId = ida.data;
                    f.idName = arsc.nameOf(ida.data);
                    f.tag = ApkAnalyzer.simple(el.name);
                    f.layout = lname;
                    f.layoutPaths = lp;
                    f.checkable = ApkAnalyzer.isToggle(el.name);
                    f.title = ApkAnalyzer.labelOf(el, arsc);
                    String st = el.text("checked");
                    f.detail = f.tag + (f.checkable ? (", now " + ("true".equals(st) ? "ON" : "OFF") + " by default") : "") + "  \u00B7 id " + f.idName;
                    r.controls.add(f);
                });
            } catch (Throwable ignored) { }
        }
    }

    private static boolean isLibLayout(String n) {
        String l = n.toLowerCase();
        for (String p : LIB_LAYOUT) if (l.startsWith(p)) return true;
        return false;
    }

    private static String kindOfLayout(String n) {
        String l = n.toLowerCase();
        if (l.startsWith("activity")) return "Window";
        if (l.contains("dialog") || l.contains("sheet") || l.contains("popup")) return "Dialog";
        if (l.startsWith("item") || l.startsWith("row") || l.contains("_item")) return "List item";
        if (l.startsWith("fragment")) return "Tab / page";
        return "Screen";
    }

    private static String pretty(String n) {
        return n.replace('_', ' ');
    }

    // ------------------------------------------------------------------ text for the brief
    public static String text(Result r) {
        StringBuilder sb = new StringBuilder();
        sb.append("VPN service: ").append(r.vpnService == null ? "?" : r.vpnService).append('\n');
        for (Feat f : r.engine) sb.append("- ").append(f.title).append(": ").append(f.count).append(" call(s)\n");
        String g = "";
        for (Feat f : r.controls) {
            if (!f.group.equals(g)) {
                g = f.group;
                sb.append(g).append('\n');
            }
            sb.append("   * ").append(f.title).append(" (").append(f.tag).append(", ").append(f.idName).append(")\n");
        }
        return sb.toString();
    }
}
