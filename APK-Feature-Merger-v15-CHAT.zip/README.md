# Feature Merger

## What changed in 1.1

* **Every APK is added, no import errors.** If part of an APK cannot be read (odd manifest, broken class, unusual
  resources), that part is skipped, the APK still appears in the list and the reason is shown in its **Notes** and in
  the **Log** tab (with the exact place in the code). An APK is never deleted because of a read problem.
* **New "Add app" sheet** (Add APK button, and the new **Add VPN app** / **Add game / app** buttons on the VPN tab):
  * **Installed**: all apps on the phone, search box, VPN apps are marked and listed first for the VPN slot,
    "System" chip for system apps.
  * **Files**: every `.apk` in Download and your other folders (asks for file access right there).
  * **Browse**: the normal file picker, needs no permission.
  * Picking from the VPN / game buttons puts the app straight into that slot.
* The VPN / game dropdowns always end with "+ Add app", so they are never empty.
* "Open with" / "Share" an APK from any file manager now sends it to this app.

## VPN transplant (new, main feature)

Makes a VPN app that works for some games (for example Free Fire and Free Fire MAX) work for one more game
(for example Free Fire India), without touching the VPN's servers, engine or screens.

1. **Apps** tab: Add the VPN APK and the game APK (Free Fire India).
2. **VPN** tab: choose the VPN app, tap **Scan VPN** (shows how the VPN picks its games), tick the games it
   already supports (the new game copies those), choose the new game, tap **Transplant, scan and save**.
3. The app patches the VPN, then scans the new APK again and prints a PASS/FAIL report.
   * FAIL or crash: tap **Copy report** and paste it to Claude.
4. **Save as...** (or Share). The file is saved **unsigned** on purpose; sign it with MT Manager,
   uninstall the old VPN, install the signed one.

How it works: every `VpnService.Builder.addAllowedApplication(pkg)` call in the VPN is redirected to a small helper
(`FmVpn.add`). It does the original call and, when `pkg` is one of the ticked games, also allows the new package
(a missing/uninstalled target never breaks the VPN). Package lists in plain config files (JSON arrays, one-per-line
lists) get the new package too. If the VPN has no per-app list (routes all apps, or only excludes some), the scan says
so: the new game is then already covered and nothing is patched.

**VPN has no addAllowedApplication call (new):** switch **Add a per-app list if missing** (VPN tab, on by default).
Then every `Builder.establish()` call goes through `FmVpn.establish`, which injects `addAllowedApplication(pkg)` for the
ticked games and the new game(s) right before the tunnel starts. The VPN then routes ONLY those games. Games that are
not listed in the scan (because the VPN had no list) can be typed into **Extra package names**
(for example Free Fire + Free Fire MAX + Free Fire India = three games). If the VPN only excludes apps
(`addDisallowedApplication`), those calls are switched off, because Android does not allow an exclude list and an allow
list together. A package that is not installed is skipped; if none is installed the VPN simply routes all apps.
Switch it off to keep the old behaviour ("nothing to patch" for such VPNs).

Limits: VPNs that decide the game some other way (server side, usage-stats checks, encrypted lists) are reported,
not patched. Apps that check their own signature may refuse to start after patching.

The old "move features between apps" Merge tab was removed. The Record tab was replaced by the Enhance tab.

---

Android app that reads APKs on the phone and

* lists every **overlay feature** inside them (floating menus, switches, sliders) with a traffic light:
  green = should work the same after the move, amber = check first, red = probably will not work
* lists everything the developer **switched off** (controls hidden with `visibility=gone/invisible`, disabled
  controls, disabled services/activities/receivers) and lets you **activate** it
* moves chosen features from one APK into another (the **base app**) and, if the base app has a switch menu,
  **adds a matching switch row** to that menu by cloning its last row, so it looks like every other option
* can turn off whole base-app features or hide single controls
* signs the result (v1 + v2) with a key generated on first use and offers Install / Share

Everything runs on the phone, pure Java (no native code, fine on armv7a), no internet needed.

## Build on GitHub

1. Use your existing repo. Upload this zip into the repo root (or the extracted files). The workflow
   `.github/workflows/build.yml` (same file as the TraceLock/iLauncher repo) unpacks the newest zip and builds it.
2. Open the **Actions** tab: it runs on every push (or run it by hand).
3. Download the `iLauncher-APK-run<N>` artifact: `iLauncher-debug.apk` (and `iLauncher-release.apk`).
   The artifact keeps the old iLauncher name on purpose, the workflow is unchanged. The Android Gradle plugin is 8.3.2
   because that workflow uses Gradle 8.4.

## Use

1. **Apps** tab: Add APK (one or more). Tap **Details** to see features, risk colours and switched-off items.
2. **Merge** tab: pick the base app, tick what to activate / turn off / bring in, press **Build merged APK**.
3. Uninstall the original base app, then Install the merged APK (it is signed with your own key).

## How a moved feature works

The source APK is embedded unchanged in the base APK. A small bridge (extracted from this app's own dex)
loads it with its own code and resources, so the feature behaves like in the original app. A manifest
provider boots the bridge, shim services host the feature's overlay Service, and the cloned menu switch
(found at runtime through its `android:tag`) starts/stops it.

## VPN enhancer / feature rewriter (new, replaces the Record tab)

Improves the features of a VPN app and puts the better version in place of the original one. No AI and no internet
inside the app: the improvements are ready-made recipes, based on research (see below). Your own short words are read
with plain keywords.

1. **Enhance** tab -> pick the VPN -> **Scan features**. You get a vertical list:
   * **VPN engine**: DNS servers, packet size (MTU), IPv6 handling, metered flag, always-on / kill switch support,
     tunnel start, per-app list. Each shows how many places in the code use it.
   * **Windows / dialogs / screens** of the VPN with every clickable control (buttons, switches, checkboxes, spinners).
2. Tap a feature. Choose a ready-made improvement, or type what you want (for example `dns google, mtu 1350`,
   `default on`, `hide`). The app tells you what it understood. Anything it cannot do is kept for the **brief**.
3. **Build enhanced APK**. The result is written unsigned (sign with MT Manager) or signed with the FM key (tick the box),
   then scanned again and a PASS/FAIL report is shown. FAIL: **Copy report** and paste it to Claude.
4. **Copy brief for Claude**: a text with the VPN's feature list and your instructions. Paste it in the chat, and a new
   improvement is added to the enhancer for that feature (this is the "research and write the best code" step; it is
   done by Claude in the chat, not inside the app).

### AI helper (optional, your own key)

Tap **AI setup** on the Enhance tab and paste a key once:

* **Gemini (free):** get a key at aistudio.google.com/apikey (no card). It stops by itself when the free limit is used up.
  The app asks the API which models your key can use and picks the newest stable Flash / Flash-Lite (3.8 Flash, 3.5 Flash-Lite ...),
  so an old model name can never break it. Gemini 2.5 is skipped: Google now serves it only to projects that used it before (new keys get 404).
  A free key cannot use Google Search, so the AI answers from its own knowledge and the answer says "Web research: no".
* **Claude (paid):** paste a Claude API key and set a spend limit in the Anthropic console, then it stops at that limit.

Then, on any feature, tap **Ask AI**, or just type your own words: whatever the keyword reader cannot handle goes to the AI.
The AI researches the web (if the provider allows it for your key; otherwise it answers from its own knowledge and says so)
and returns SETTINGS from the fixed list in the table below. It never puts code into the APK. You see its answer (summary,
changes, sources) and press **Add to plan** or Cancel. A daily cap (default 20 asks) is counted inside the app; the key
is stored in the app's private no-backup folder.

### Games, private servers and "select it again = rewrite"

* **VPN tab:** if the VPN was already patched, pressing Patch again REWRITES the game list inside it in place. The new
  selection replaces the old one (nothing is added twice), the report shows Before / After, and the original APK is not needed.
* **Enhance tab -> "Games"**: pick your game(s) from the apps installed on the phone (a private-server client or another
  version often has a different package name), or type package names. They are allowed whenever the VPN allows an app.
  Picking a game that is already there rewrites it. Enhancing an already enhanced VPN also rewrites the old settings
  (same keys replaced, other keys stay).
* **Enhance tab -> "Game server routes"**: type the private server's IP address (or a range like 203.0.113.0/24). It is
  sent through the VPN when the tunnel starts.
* Honest limit: this fixes "the VPN does not carry my game / my server's traffic". If the VPN's own server refuses
  traffic to your private server, nothing on the phone can change that. The build report tells you what was changed, the real
  test is on the phone.

### Auto adapt (AI autopilot, new in 1.3)

**Enhance tab -> Auto adapt everything (AI).** One tap, no questions:

1. The app scans the chosen VPN (features, connection settings, how its code uses routes / allowed apps / MTU / DNS).
2. The AI gets the scan and the list of apps installed on the phone, picks the game package(s) itself (the old version, a private-server
   client, other clients of the same game) and chooses the settings from the fixed list (APPS, ROUTE, MTU, V6, DNS, MET, AON).
3. The standard old-version fix (route everything of the game, MTU 1380) is always included, even if the AI forgot it.
4. The app builds the APK and runs its own checks. If the build or the checks FAIL, the report goes back to the AI and it gets one more
   try with that report. If the AI itself is not available (no key, daily limit, no internet), the standard fix is built instead.
5. The log shows every step, and the AI's own summary says honestly what these settings cannot fix.

**Fix: old game version** (same tab) is the same one-tap flow without the AI: scan, standard old-version fix, build, check. It needs no key.

Limit that no phone-side patch can change: if the game's own servers refuse the old client version, the match will not start whatever
the VPN does. The app and the AI report that, they do not hide it. Not compiled by the author's tools (no Android SDK there): the first
GitHub build may report a small compile error, send it back.

### AI providers (free key links are inside AI setup)

Gemini, Groq, OpenRouter, Mistral, Cerebras (free) and Claude (paid). Each row has its own **Get key** button that opens the
page where the key is made. Keys are kept one per provider, models are looked up live from each provider (never a hard-coded
name), and a **What is happening** panel shows every step (key checked, models found, asking model X, answer checked) and
ends with a Done / Next summary, also for scan and build.

### Features list, game adaptation and AI chat

* **Features list** (Enhance tab): the top of the list is what you see and tap in the VPN: every clickable component of every
  window, dialog, menu and settings screen, with its name as shown on screen (a component with no text gets its id turned into words,
  e.g. `btn_freeze` becomes "Freeze"). For each one the scan shows whether it has click code and which class / method uses it.
  The connection settings (DNS, MTU, routes ...) are at the end under "Connection settings (advanced)". There is a search box.
  A floating menu that is drawn in code (no layout file) is not found by this scan; ask the AI chat about it.
* **Game adaptation** (VPN tab, runs with Patch): besides the allow list, the new game gets what the VPN keeps for its reference
  game: (1) JSON config profiles are copied (list entries, entries keyed by the package, objects that name the package),
  (2) the new package is made visible to the VPN on Android 11+ (manifest queries), (3) game alias: the VPN's own
  launch / installed / app-in-front checks of the reference game also work for the new game. Tick a reference game for (3).
* **Older game version: lobby works, match does not start** (the VPN is current and fine with the current game, but a 2022-style
  client uses other match servers and UDP ports): the recipe **Fix: old game version, lobby works but no match** (on "Tunnel start"
  and "Game server routes") routes everything of the allowed games through the VPN (0.0.0.0/0) and sets MTU 1380. Say "lobby" or
  "match" in your own words and it is understood too. If the old version has the same package name as the current one, nothing
  has to be added to the game list; only the routing differs.
* **AI chat** (Enhance tab > Chat with AI, or from any feature): a conversation like this one. The AI knows the VPN's features,
  their code locations and your planned changes, asks a question when it needs more, and offers settings with **Add to plan**.
  It changes settings from the fixed list only; it does not write new feature code into the APK.

What each improvement does (inside the VPN, its servers / engine / screens stay the same):

| Feature | Improvement |
|---|---|
| DNS | Replaces the VPN's DNS (or adds one if it has none) with Cloudflare / Google / Quad9 / AdGuard or your own IPs. If a VPN sets no DNS, Android uses the DNS of the normal network, which can leak to your provider. |
| MTU | 1420 (fast), 1380 (mobile safe, what Mullvad ships), 1280 (IPv6 minimum, fallback when connections stall), or your own number 1200-1500. |
| IPv6 | Sends IPv6 into the tunnel too, so it cannot go around an IPv4-only VPN. |
| Metered | Marks the VPN as not metered (Android 10+). |
| Always-on | Corrects the manifest if the developer switched always-on support off. The kill switch itself is Android's own setting: Settings > VPN > gear > Always-on VPN + "Block connections without VPN". |
| Games | Adds the games you pick to the VPN's per-app list (same game again = rewritten). |
| Server routes | Adds your private server's IP / range to the tunnel at start. |
| Controls | Default ON / OFF for a switch, hide, show / enable (edits the screen layout). |

How it works: every `VpnService.Builder.establish / addDnsServer / setMtu` call in the VPN is redirected to a small helper
(`FmEnh`). It does the better version and then the normal call, and any problem in the helper falls back to the original
behaviour. It stacks with the VPN transplant (the transplant helper's own calls are redirected too).

Limits: VPNs that start the tunnel in native code (no `Builder.establish()` in Java) cannot be changed this way, the scan
says so. A VPN that already has an enhancement must be enhanced again from the original APK. Apps that check their own
signature may refuse to start after patching. Not built or run by the author's tools (no Android SDK there): the first
GitHub build may report small compile errors, send them back.

## Known limits

* Features that drive their own app's VPN engine are marked red; the engine cannot be moved.
* Overlays built inside an Activity (not a Service) are listed but cannot be moved yet.
* Only hidden/disabled items that exist in layouts or the manifest are found; flags inside code are not.
* Menus built entirely in code (no layout XML) cannot get a cloned switch; the feature then starts automatically.

## v15 - Chat tab (replaces the Log tab)

* **Chat tab** opens a Claude-style chat (no terminal look). Use **+** to upload APK, XAPK / APKS / APKM, screenshots and any file.
  APK / XAPK uploads also show up in the Apps tab. Screenshots are sent to the AI as images (Gemini / Claude; other providers get text only).
* The assistant knows every uploaded APK and works with tools: read manifest / layouts (binary XML shown as text), resources, smali of any class,
  search in code, edit smali (re-assembled and checked), edit manifest attributes, replace files (icons...), delete files, **extract source**
  (smali + decoded XML zip) and **build + sign** the APK. The result comes back as a file card (Save / Share / Install) right in the chat.
* XAPK: the base APK is edited, every split is re-signed with the same key and the bundle is packed again (.xapk).
* Menu (three dots): New chat, Copy chat, **Copy app log** (the old Log tab), AI setup.
* Fixed: after sending a message the keyboard closed. Cause: `fullScroll(FOCUS_DOWN)` moved focus away from the input. Now it only scrolls.
* The daily AI limit now counts one per chat message (default 60).
* New libraries: smali-baksmali + smali (source extractor / smali editor). Guava is forced to the Android flavour.

Not included: Java decompiling like jadx (too heavy for a phone). Smali is the exact code and can be edited and put back.
Not compiled by the author's tools (no Android SDK / network there): if the GitHub build shows an error, send the error text back.
