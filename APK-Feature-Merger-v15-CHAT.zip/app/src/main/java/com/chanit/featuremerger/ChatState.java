package com.chanit.featuremerger;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;

import com.chanit.featuremerger.core.AiChat;
import com.chanit.featuremerger.core.ApkTools;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Everything the chat screen keeps while the app lives (the screen itself can be recreated at any time). */
final class ChatState {
    private ChatState() {}

    static final int USER = 0, AI = 1, STEP = 2, FILE = 3, ERROR = 4;

    static final class Att {
        String name, kind, note, mime, b64;   // kind: apk | bundle | image | file
        File file;
        Bitmap thumb;
    }

    static final class Item {
        int type;
        String text, detail;
        boolean ok = true;
        List<Att> atts;
        File file;
    }

    interface Ui {
        void item(Item it);

        void status(String s);

        void busy(boolean b);
    }

    static final List<Item> items = new ArrayList<>();
    static final List<AiChat.Msg> convo = new ArrayList<>();
    static final List<Att> pending = new ArrayList<>();
    static final Map<String, File> files = new LinkedHashMap<>();
    static final Handler main = new Handler(Looper.getMainLooper());
    static final ExecutorService exec = Executors.newSingleThreadExecutor();
    static final ExecutorService io = Executors.newSingleThreadExecutor();
    static final AtomicBoolean stop = new AtomicBoolean();
    static boolean busy;
    static String status = "";
    static Ui ui;
    private static ApkTools tools;

    static synchronized ApkTools tools(Context c) {
        if (tools == null) tools = new ApkTools(c.getApplicationContext());
        return tools;
    }

    static void add(final Item it) {
        main.post(() -> {
            items.add(it);
            if (ui != null) ui.item(it);
        });
    }

    static void say(String type, String text) {
        Item it = new Item();
        it.type = type.equals("ai") ? AI : ERROR;
        it.text = text;
        add(it);
    }

    static void setStatus(final String s) {
        main.post(() -> {
            status = s == null ? "" : s;
            if (ui != null) ui.status(status);
        });
    }

    static void setBusy(final boolean b) {
        main.post(() -> {
            busy = b;
            if (!b) status = "";
            if (ui != null) {
                ui.busy(b);
                ui.status(status);
            }
        });
    }

    /** Shows a status line for a short job (upload) even when no AI turn is running. */
    static void setBusyStatus(ChatActivity a, String s) {
        status = s;
        if (ui != null) ui.status(s);
        if (a != null && !busy) a.showUploading(s);
    }

    static File attachment(String name) {
        if (name == null) return null;
        File f = files.get(name);
        if (f != null) return f;
        for (Map.Entry<String, File> e : files.entrySet()) if (e.getKey().equalsIgnoreCase(name.trim())) return e.getValue();
        return null;
    }

    static void reset(Context c) {
        items.clear();
        convo.clear();
        pending.clear();
        tools(c).clearSessions();
    }
}
