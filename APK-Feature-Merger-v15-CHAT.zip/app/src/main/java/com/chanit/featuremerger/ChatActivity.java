package com.chanit.featuremerger;

import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.InputType;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.chanit.featuremerger.core.AiChat;
import com.chanit.featuremerger.core.AiHelper;
import com.chanit.featuremerger.core.ApkAnalyzer;
import com.chanit.featuremerger.core.ApkTools;
import com.chanit.featuremerger.core.ChatAgent;
import com.chanit.featuremerger.core.Model;
import com.chanit.featuremerger.core.Store;
import com.chanit.featuremerger.core.Xapk;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipFile;

/**
 * The chat: Claude-style screen (no terminal look). Upload APK / XAPK / screenshots / files with +, ask for changes, and the
 * assistant reads, edits, builds and hands back the APK right here.
 */
public class ChatActivity extends AppCompatActivity implements ChatState.Ui {
    private LinearLayout list, welcome, pendingRow;
    private ScrollView scroll;
    private HorizontalScrollView pendingScroll;
    private EditText input;
    private TextView sendBtn, statusLine, subtitle;
    private ValueAnimator pulse;
    private File pendingSave;

    private final ActivityResultLauncher<String[]> picker =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), this::onPicked);
    private final ActivityResultLauncher<String> saver =
            registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"), this::onSaveTarget);

    // ------------------------------------------------------------------ theme helpers
    private int col(int attr) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(attr, tv, true);
        return tv.data;
    }

    private int onSurface() { return col(com.google.android.material.R.attr.colorOnSurface); }
    private int variant() { return col(com.google.android.material.R.attr.colorOnSurfaceVariant); }
    private int primary() { return col(com.google.android.material.R.attr.colorPrimary); }
    private int onPrimary() { return col(com.google.android.material.R.attr.colorOnPrimary); }
    private int high() { return col(com.google.android.material.R.attr.colorSurfaceContainerHigh); }
    private int mid() { return col(com.google.android.material.R.attr.colorSurfaceContainer); }
    private int outline() { return (col(com.google.android.material.R.attr.colorOutline) & 0x00FFFFFF) | 0x66000000; }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable round(int color, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }

    // ------------------------------------------------------------------ screen
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(true);
        root.setBackgroundColor(col(android.R.attr.colorBackground));

        // header
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(18), dp(10), dp(8), dp(6));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("APK Chat", 20, onSurface(), true));
        subtitle = text("", 11, variant(), false);
        titles.addView(subtitle);
        head.addView(titles, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT));
        ((LinearLayout.LayoutParams) titles.getLayoutParams()).weight = 1f;
        TextView menu = text("\u22EE", 24, onSurface(), true);
        menu.setGravity(Gravity.CENTER);
        menu.setPadding(dp(14), dp(6), dp(14), dp(6));
        menu.setOnClickListener(v -> showMenu(v));
        head.addView(menu);
        root.addView(head);

        // messages
        scroll = new ScrollView(this);
        scroll.setClipToPadding(false);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), dp(8), dp(16), dp(12));
        scroll.addView(list);
        LinearLayout.LayoutParams slp = lp(ViewGroup.LayoutParams.MATCH_PARENT, 0);
        slp.weight = 1f;
        root.addView(scroll, slp);
        // when the keyboard opens the list gets shorter: keep the end of the chat in view (no focus change!)
        scroll.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, or, ob) -> {
            if (bt - t < ob - ot) scrollDown();
        });

        welcome = buildWelcome();
        list.addView(welcome);

        // status line (what the assistant is doing right now)
        statusLine = text("", 12, variant(), false);
        statusLine.setPadding(dp(20), dp(2), dp(20), dp(4));
        statusLine.setVisibility(View.GONE);
        root.addView(statusLine);

        root.addView(buildInput());
        setContentView(root);

        pulse = ValueAnimator.ofFloat(0.35f, 1f);
        pulse.setDuration(700);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.addUpdateListener(a -> statusLine.setAlpha((Float) a.getAnimatedValue()));

        ChatState.tools(this).setHost(new ApkTools.Host() {
            @Override public File attachment(String name) { return ChatState.attachment(name); }

            @Override public void card(File file, String label) {
                ChatState.Item it = new ChatState.Item();
                it.type = ChatState.FILE;
                it.file = file;
                it.text = label;
                ChatState.add(it);
            }

            @Override public void progress(String msg) { ChatState.setStatus(msg); }
        });

        for (ChatState.Item it : ChatState.items) addItemView(it);
        welcome.setVisibility(ChatState.items.isEmpty() ? View.VISIBLE : View.GONE);
        refreshPending();
        busy(ChatState.busy);
        status(ChatState.status);
        refreshSubtitle();
        scrollDown();
    }

    @Override protected void onStart() {
        super.onStart();
        ChatState.ui = this;
        busy(ChatState.busy);
        status(ChatState.status);
        refreshSubtitle();
    }

    @Override protected void onStop() {
        super.onStop();
        if (ChatState.ui == this) ChatState.ui = null;
    }

    private void refreshSubtitle() {
        AiHelper.Config c = AiHelper.load(this);
        AiHelper.Prov pv = AiHelper.prov(c.provider);
        subtitle.setText(c.ready() ? pv.label + "  \u00B7  " + AiHelper.usedToday(this) + "/" + c.cap + " messages today" : "AI key not set (menu > AI setup)");
    }

    private LinearLayout buildWelcome() {
        LinearLayout w = new LinearLayout(this);
        w.setOrientation(LinearLayout.VERTICAL);
        w.setPadding(dp(6), dp(40), dp(6), dp(10));
        w.addView(text("Kya edit karna hai?", 26, onSurface(), true));
        TextView sub = text("APK ya XAPK upload karo (+ button), screenshot bhejo aur batao kya badalna hai. Main manifest, code aur resources padh kar edit karunga "
                + "aur signed APK yahin chat me de dunga. Source (smali + XML) bhi nikal deta hun.", 14, variant(), false);
        sub.setPadding(0, dp(8), 0, dp(16));
        sub.setLineSpacing(0, 1.2f);
        w.addView(sub);
        String[] tips = {"Is APK ka source extract karo", "App ka naam badlo aur pop-ups hata do", "Is APK ko samjhao, kya kya hai isme"};
        for (final String tip : tips) {
            MaterialButton btn = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
            btn.setText(tip);
            btn.setAllCaps(false);
            btn.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            btn.setOnClickListener(v -> {
                input.setText(tip);
                input.setSelection(input.length());
                input.requestFocus();
            });
            LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            p.topMargin = dp(6);
            w.addView(btn, p);
        }
        return w;
    }

    private View buildInput() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(round(col(com.google.android.material.R.attr.colorSurface), 26, outline()));
        card.setPadding(dp(6), dp(6), dp(6), dp(4));
        LinearLayout.LayoutParams clp = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.setMargins(dp(10), dp(4), dp(10), dp(8));
        card.setLayoutParams(clp);

        pendingScroll = new HorizontalScrollView(this);
        pendingScroll.setHorizontalScrollBarEnabled(false);
        pendingRow = new LinearLayout(this);
        pendingRow.setOrientation(LinearLayout.HORIZONTAL);
        pendingRow.setPadding(dp(6), dp(4), dp(6), dp(4));
        pendingScroll.addView(pendingRow);
        pendingScroll.setVisibility(View.GONE);
        card.addView(pendingScroll);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.BOTTOM);

        TextView plus = text("+", 26, onSurface(), false);
        plus.setGravity(Gravity.CENTER);
        plus.setBackground(round(high(), 22, 0));
        plus.setFocusable(false);
        plus.setOnClickListener(v -> picker.launch(new String[]{"*/*"}));
        LinearLayout.LayoutParams plp = lp(dp(44), dp(44));
        row.addView(plus, plp);

        input = new EditText(this);
        input.setHint("Kuch bhi poochho ya APK edit karwao");
        input.setBackground(null);
        input.setTextSize(15);
        input.setTextColor(onSurface());
        input.setHintTextColor(variant());
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setMinLines(1);
        input.setMaxLines(6);
        input.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams ilp = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        ilp.weight = 1f;
        row.addView(input, ilp);

        sendBtn = text("\u2191", 22, onPrimary(), true);
        sendBtn.setGravity(Gravity.CENTER);
        sendBtn.setBackground(round(primary(), 22, 0));
        sendBtn.setFocusable(false);
        sendBtn.setFocusableInTouchMode(false);
        sendBtn.setOnClickListener(v -> send());
        row.addView(sendBtn, lp(dp(44), dp(44)));
        card.addView(row);
        return card;
    }

    // ------------------------------------------------------------------ ChatState.Ui
    @Override public void item(ChatState.Item it) {
        welcome.setVisibility(View.GONE);
        addItemView(it);
        scrollDown();
    }

    @Override public void status(String s) {
        boolean show = s != null && !s.isEmpty() && ChatState.busy;
        statusLine.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            statusLine.setText("\u25CF  " + s);
            if (!pulse.isRunning()) pulse.start();
        } else {
            pulse.cancel();
            statusLine.setAlpha(1f);
        }
    }

    @Override public void busy(boolean b) {
        sendBtn.setText(b ? "\u25A0" : "\u2191");
        sendBtn.setTextSize(b ? 16 : 22);
        if (!b) refreshSubtitle();
    }

    void showUploading(String s) {
        statusLine.setText("\u25CF  " + s);
        statusLine.setVisibility(View.VISIBLE);
    }

    private void scrollDown() {
        scroll.post(() -> {
            View child = scroll.getChildAt(0);
            if (child == null) return;
            // never fullScroll(FOCUS_DOWN): it moves focus away from the input and the keyboard closes
            int dy = child.getBottom() + scroll.getPaddingBottom() - (scroll.getScrollY() + scroll.getHeight());
            if (dy > 0) scroll.scrollBy(0, dy);
        });
    }

    // ------------------------------------------------------------------ item views
    private void addItemView(ChatState.Item it) {
        switch (it.type) {
            case ChatState.USER: list.addView(userView(it)); break;
            case ChatState.AI: addAi(it.text); break;
            case ChatState.STEP: list.addView(stepView(it)); break;
            case ChatState.FILE: list.addView(fileView(it)); break;
            default: list.addView(errorView(it)); break;
        }
    }

    private View userView(ChatState.Item it) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(round(high(), 20, 0));
        box.setPadding(dp(14), dp(10), dp(14), dp(10));
        if (it.atts != null) {
            for (ChatState.Att a : it.atts) {
                if (a.thumb != null) {
                    ImageView iv = new ImageView(this);
                    iv.setImageBitmap(a.thumb);
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    iv.setBackground(round(mid(), 12, 0));
                    iv.setClipToOutline(true);
                    LinearLayout.LayoutParams ip = lp(dp(140), dp(140));
                    ip.bottomMargin = dp(6);
                    box.addView(iv, ip);
                } else {
                    TextView chip = text("\uD83D\uDCCE  " + a.name, 13, variant(), false);
                    chip.setPadding(0, dp(2), 0, dp(4));
                    box.addView(chip);
                }
            }
        }
        if (it.text != null && !it.text.isEmpty()) {
            TextView t = text(it.text, 15, onSurface(), false);
            t.setTextIsSelectable(true);
            box.addView(t);
        }
        LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.gravity = Gravity.END;
        p.topMargin = dp(14);
        p.leftMargin = dp(48);
        box.setLayoutParams(p);
        return box;
    }

    private void addAi(String s) {
        for (Md.Part part : Md.split(s)) {
            if (part.text.trim().isEmpty()) continue;
            if (part.code) {
                list.addView(codeView(part.text));
            } else {
                TextView t = new TextView(this);
                t.setText(Md.render(part.text.trim(), mid()));
                t.setTextSize(15);
                t.setTextColor(onSurface());
                t.setLineSpacing(0, 1.25f);
                t.setTextIsSelectable(true);
                LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                p.topMargin = dp(12);
                list.addView(t, p);
            }
        }
    }

    private View codeView(final String code) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(round(mid(), 12, 0));
        box.setPadding(dp(12), dp(6), dp(12), dp(10));
        TextView copy = text("Copy", 12, primary(), true);
        copy.setGravity(Gravity.END);
        copy.setPadding(0, dp(2), 0, dp(4));
        copy.setOnClickListener(v -> copyText("code", code, "Code copied"));
        box.addView(copy);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        TextView t = text(code, 12, onSurface(), false);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextIsSelectable(true);
        hs.addView(t);
        box.addView(hs);
        LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(10);
        box.setLayoutParams(p);
        return box;
    }

    private View stepView(final ChatState.Item it) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(2), dp(5), dp(2), dp(2));
        final TextView head = text((it.ok ? "\u2713   " : "\u2717   ") + it.text, 13, it.ok ? variant() : col(com.google.android.material.R.attr.colorError), false);
        head.setMaxLines(1);
        head.setEllipsize(android.text.TextUtils.TruncateAt.END);
        final TextView detail = text(it.detail == null ? "" : it.detail, 11, variant(), false);
        detail.setTypeface(Typeface.MONOSPACE);
        detail.setTextIsSelectable(true);
        detail.setVisibility(View.GONE);
        detail.setBackground(round(mid(), 10, 0));
        detail.setPadding(dp(10), dp(8), dp(10), dp(8));
        head.setOnClickListener(v -> {
            boolean open = detail.getVisibility() == View.VISIBLE;
            detail.setVisibility(open ? View.GONE : View.VISIBLE);
            head.setMaxLines(open ? 1 : 4);
        });
        row.addView(head);
        row.addView(detail);
        return row;
    }

    private View errorView(ChatState.Item it) {
        TextView t = text("\u26A0  " + it.text, 14, col(com.google.android.material.R.attr.colorError), false);
        t.setTextIsSelectable(true);
        t.setBackground(round(mid(), 14, 0));
        t.setPadding(dp(14), dp(10), dp(14), dp(10));
        LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(12);
        t.setLayoutParams(p);
        return t;
    }

    private View fileView(final ChatState.Item it) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(round(col(com.google.android.material.R.attr.colorSurface), 16, outline()));
        card.setPadding(dp(14), dp(12), dp(14), dp(8));
        card.addView(text(it.file.getName(), 15, onSurface(), true));
        String ext = it.file.getName().toLowerCase(Locale.ROOT);
        String kind = ext.endsWith(".apk") ? "APK" : ext.endsWith(".xapk") ? "XAPK bundle" : "Zip";
        card.addView(text(kind + "  \u00B7  " + (it.file.length() > 1048576 ? String.format(Locale.US, "%.1f MB", it.file.length() / 1048576.0) : (it.file.length() / 1024) + " KB"), 12, variant(), false));
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.addView(smallBtn("Save", v -> {
            pendingSave = it.file;
            try {
                saver.launch(it.file.getName());
            } catch (Throwable t) {
                Toast.makeText(this, "Save dialog nahi khula", Toast.LENGTH_SHORT).show();
            }
        }));
        btns.addView(smallBtn("Share", v -> shareFile(it.file)));
        if (ext.endsWith(".apk")) btns.addView(smallBtn("Install", v -> installApk(it.file)));
        card.addView(btns);
        LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(12);
        card.setLayoutParams(p);
        return card;
    }

    private MaterialButton smallBtn(String label, View.OnClickListener l) {
        MaterialButton b = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.rightMargin = dp(8);
        p.topMargin = dp(8);
        b.setLayoutParams(p);
        return b;
    }

    // ------------------------------------------------------------------ send
    private void send() {
        if (ChatState.busy) {
            ChatState.stop.set(true);
            ChatState.setStatus("Rok raha hun...");
            return;
        }
        final String typed = input.getText().toString().trim();
        if (typed.isEmpty() && ChatState.pending.isEmpty()) return;
        final List<ChatState.Att> atts = new ArrayList<>(ChatState.pending);
        ChatState.pending.clear();
        refreshPending();
        input.setText("");   // the keyboard stays open: focus never leaves the input

        ChatState.Item mine = new ChatState.Item();
        mine.type = ChatState.USER;
        mine.text = typed;
        mine.atts = atts;
        ChatState.add(mine);

        ChatState.stop.set(false);
        ChatState.setBusy(true);
        ChatState.setStatus("Soch raha hun");
        final Context app = getApplicationContext();
        ChatState.exec.execute(() -> {
            try {
                ApkTools tools = ChatState.tools(app);
                StringBuilder sb = new StringBuilder();
                sb.append('[').append(tools.context().trim()).append("]\n");
                AiChat.Msg m = new AiChat.Msg("user", "");
                if (!atts.isEmpty()) {
                    sb.append("[Attached to this message: ");
                    for (int i = 0; i < atts.size(); i++) {
                        ChatState.Att a = atts.get(i);
                        sb.append(i > 0 ? "; " : "").append(a.name).append(" (").append(a.note).append(')');
                        if (a.b64 != null) m.images.add(new AiChat.Img(a.mime, a.b64));
                    }
                    sb.append("]\n");
                }
                sb.append(typed.isEmpty() ? "Ye attach kiya hai, dekho aur batao kya kar sakte hain." : typed);
                m.text = sb.toString();
                ChatState.convo.add(m);
                ChatAgent.run(app, tools, ChatState.convo, new ChatAgent.Sink() {
                    @Override public void say(String t) { ChatState.say("ai", t); }

                    @Override public void step(String label, String result, boolean ok) {
                        ChatState.Item it = new ChatState.Item();
                        it.type = ChatState.STEP;
                        it.text = label;
                        it.detail = result.length() > 1500 ? result.substring(0, 1500) + "\n..." : result;
                        it.ok = ok;
                        ChatState.add(it);
                    }

                    @Override public void working(String label) { ChatState.setStatus(label); }
                }, ChatState.stop);
            } catch (ChatAgent.AiAbort e) {
                ChatState.say("error", e.getMessage());
            } catch (Throwable t) {
                ChatState.say("error", "Error: " + ApkAnalyzer.brief(t));
            } finally {
                ChatState.setBusy(false);
            }
        });
    }

    // ------------------------------------------------------------------ attachments
    private void refreshPending() {
        pendingRow.removeAllViews();
        pendingScroll.setVisibility(ChatState.pending.isEmpty() ? View.GONE : View.VISIBLE);
        for (final ChatState.Att a : new ArrayList<>(ChatState.pending)) {
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setBackground(round(high(), 14, 0));
            chip.setPadding(dp(8), dp(6), dp(4), dp(6));
            if (a.thumb != null) {
                ImageView iv = new ImageView(this);
                iv.setImageBitmap(a.thumb);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                chip.addView(iv, lp(dp(32), dp(32)));
            }
            String n = a.name.length() > 22 ? a.name.substring(0, 20) + "..." : a.name;
            TextView label = text((a.thumb == null ? "\uD83D\uDCCE " : "  ") + n, 13, onSurface(), false);
            chip.addView(label);
            TextView x = text("\u2715", 14, variant(), false);
            x.setPadding(dp(10), dp(4), dp(8), dp(4));
            x.setOnClickListener(v -> {
                ChatState.pending.remove(a);
                refreshPending();
            });
            chip.addView(x);
            LinearLayout.LayoutParams p = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            p.rightMargin = dp(6);
            pendingRow.addView(chip, p);
        }
    }

    private void onPicked(final List<Uri> uris) {
        if (uris == null || uris.isEmpty()) return;
        ChatState.setBusyStatus(this, "Upload ho raha hai...");
        ChatState.io.execute(() -> {
            for (Uri u : uris) {
                try {
                    final ChatState.Att a = importOne(u);
                    ChatState.main.post(() -> {
                        ChatState.pending.add(a);
                        refreshPending();
                    });
                } catch (Throwable t) {
                    ChatState.say("error", "Upload fail: " + ApkAnalyzer.brief(t));
                }
            }
            ChatState.main.post(() -> {
                ChatState.status = "";
                statusLine.setVisibility(View.GONE);
            });
        });
    }

    private String displayName(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) {
                    String n = c.getString(i);
                    if (n != null && !n.isEmpty()) return n;
                }
            }
        } catch (Exception ignored) { }
        String last = u.getLastPathSegment();
        return last != null && !last.isEmpty() ? last : "file";
    }

    private static File unique(File dir, String name) {
        String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
        File f = new File(dir, safe);
        int dot = safe.lastIndexOf('.');
        String stem = dot > 0 ? safe.substring(0, dot) : safe, ext = dot > 0 ? safe.substring(dot) : "";
        int i = 2;
        while (f.exists()) f = new File(dir, stem + "_" + (i++) + ext);
        return f;
    }

    private static void copy(InputStream in, OutputStream o) throws java.io.IOException {
        byte[] buf = new byte[1 << 16];
        int r;
        while ((r = in.read(buf)) != -1) if (r > 0) o.write(buf, 0, r);
    }

    private ChatState.Att importOne(Uri u) throws Exception {
        String name = displayName(u);
        String lower = name.toLowerCase(Locale.ROOT);
        File dir = new File(getFilesDir(), "chat_files");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File f = unique(dir, name);
        try (InputStream in = getContentResolver().openInputStream(u); FileOutputStream o = new FileOutputStream(f)) {
            if (in == null) throw new java.io.IOException("cannot open " + name);
            copy(in, o);
        }
        ChatState.Att a = new ChatState.Att();
        a.name = f.getName();
        a.file = f;
        String mime = getContentResolver().getType(u);
        Store store = ChatState.tools(this).store();
        if (lower.endsWith(".apk") && isApk(f)) {
            File dst = store.uniqueFile(f.getName());
            if (!f.renameTo(dst)) {
                try (InputStream in = new FileInputStream(f); FileOutputStream o = new FileOutputStream(dst)) { copy(in, o); }
                //noinspection ResultOfMethodCallIgnored
                f.delete();
            }
            Model.Apk m = ApkAnalyzer.analyze(this, dst, null);
            store.save(m);
            a.kind = "apk";
            a.file = dst;
            a.name = dst.getName();
            a.note = "APK uploaded, id \"" + ApkTools.idOf(dst) + "\", " + m.label + ", " + m.pkg;
        } else if (Xapk.isBundleName(lower)) {
            String base = name.substring(0, name.lastIndexOf('.'));
            File apkTarget = store.uniqueFile(base + ".apk");
            File dir2 = Xapk.dir(getFilesDir(), ApkTools.idOf(apkTarget));
            File baseApk = Xapk.unpack(f, dir2);
            try (InputStream in = new FileInputStream(baseApk); FileOutputStream o = new FileOutputStream(apkTarget)) { copy(in, o); }
            Model.Apk m = ApkAnalyzer.analyze(this, apkTarget, null);
            store.save(m);
            a.kind = "bundle";
            a.note = "XAPK bundle uploaded, id \"" + ApkTools.idOf(apkTarget) + "\", " + m.label + ", " + m.pkg + "; " + Xapk.describe(dir2);
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        } else if (isImage(lower, mime) && imageFor(a, f)) {
            a.kind = "image";
        } else {
            a.kind = "file";
            a.note = (looksText(f) ? "text file" : "binary file") + ", " + (f.length() / 1024) + " KB, read it with read_attachment, or use it with replace_file";
        }
        ChatState.files.put(a.name, a.file);
        return a;
    }

    private static boolean isApk(File f) {
        try (ZipFile z = new ZipFile(f)) {
            return z.getEntry("AndroidManifest.xml") != null;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean isImage(String lower, String mime) {
        return (mime != null && mime.startsWith("image/")) || lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg")
                || lower.endsWith(".webp") || lower.endsWith(".bmp") || lower.endsWith(".gif");
    }

    private static boolean looksText(File f) {
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[2048];
            int n = in.read(b);
            for (int i = 0; i < n; i++) if (b[i] == 0) return false;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Downsized copy for the AI (max 1280 px, JPEG) and a small thumbnail for the screen. */
    private boolean imageFor(ChatState.Att a, File f) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            if (o.outWidth <= 0) return false;
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 1280) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap bm = BitmapFactory.decodeFile(f.getPath(), o2);
            if (bm == null) return false;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 82, bo);
            a.mime = "image/jpeg";
            a.b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
            int side = 160;
            float k = Math.min(1f, (float) side / Math.max(bm.getWidth(), bm.getHeight()));
            a.thumb = Bitmap.createScaledBitmap(bm, Math.max(1, Math.round(bm.getWidth() * k)), Math.max(1, Math.round(bm.getHeight() * k)), true);
            a.note = "image " + o.outWidth + "x" + o.outHeight + ", shown to you";
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------ files out
    private void onSaveTarget(Uri u) {
        final File f = pendingSave;
        if (u == null || f == null) return;
        ChatState.io.execute(() -> {
            try (InputStream in = new FileInputStream(f); OutputStream o = getContentResolver().openOutputStream(u)) {
                if (o == null) throw new java.io.IOException("cannot write");
                copy(in, o);
                ChatState.main.post(() -> Toast.makeText(this, "Saved: " + f.getName(), Toast.LENGTH_LONG).show());
            } catch (Throwable t) {
                ChatState.main.post(() -> Toast.makeText(this, "Save fail: " + t.getMessage(), Toast.LENGTH_LONG).show());
            }
        });
    }

    private String mimeOf(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        return n.endsWith(".apk") ? "application/vnd.android.package-archive" : n.endsWith(".zip") ? "application/zip" : "application/octet-stream";
    }

    private void shareFile(File f) {
        Uri u = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
        Intent i = new Intent(Intent.ACTION_SEND).setType(mimeOf(f)).putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share " + f.getName()));
    }

    private void installApk(File f) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Pehle \"Install unknown apps\" allow karo", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            return;
        }
        Uri u = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Throwable t) {
            Toast.makeText(this, "Installer nahi khula. Save karke file manager se install karo.", Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------ menu
    private void copyText(String label, String s, String msg) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, s));
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        pm.getMenu().add(0, 1, 0, "Nayi chat");
        pm.getMenu().add(0, 2, 1, "Chat copy karo");
        pm.getMenu().add(0, 3, 2, "App log copy karo");
        pm.getMenu().add(0, 4, 3, "AI setup");
        pm.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1:
                    new MaterialAlertDialogBuilder(this).setTitle("Nayi chat?")
                            .setMessage("Chat saaf hogi aur abhi tak ke staged (build nahi hue) edits bhool jayenge. Upload kiye APK Apps tab me rehte hain.")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Nayi chat", (d, w) -> {
                                if (ChatState.busy) ChatState.stop.set(true);
                                ChatState.reset(this);
                                list.removeAllViews();
                                list.addView(welcome);
                                welcome.setVisibility(View.VISIBLE);
                                refreshPending();
                            }).show();
                    return true;
                case 2: {
                    StringBuilder sb = new StringBuilder();
                    for (ChatState.Item it : ChatState.items) {
                        if (it.type == ChatState.USER) sb.append("You: ").append(it.text).append("\n\n");
                        else if (it.type == ChatState.AI) sb.append("AI: ").append(it.text).append("\n\n");
                        else if (it.type == ChatState.ERROR) sb.append("Error: ").append(it.text).append("\n\n");
                    }
                    copyText("chat", sb.toString(), "Chat copied");
                    return true;
                }
                case 3:
                    copyText("log", MainActivity.logSnapshot(), "Log copied");
                    return true;
                case 4:
                    startActivity(new Intent(this, EnhanceActivity.class).putExtra("ai_setup", true));
                    return true;
                default:
                    return false;
            }
        });
        pm.show();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshSubtitle();
    }
}
