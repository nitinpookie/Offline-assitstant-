package com.chanit.featuremerger;

import android.graphics.Typeface;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small markdown reader for the chat: headings, **bold**, `code`, bullets and ``` code blocks. */
final class Md {
    private Md() {}

    static final class Part {
        final boolean code;
        final String text;

        Part(boolean code, String text) {
            this.code = code;
            this.text = text;
        }
    }

    static List<Part> split(String s) {
        List<Part> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean in = false;
        for (String line : s.split("\n", -1)) {
            if (line.trim().startsWith("```")) {
                if (cur.length() > 0 || in) out.add(new Part(in, trimEnd(cur.toString())));
                cur.setLength(0);
                in = !in;
                continue;
            }
            cur.append(line).append('\n');
        }
        if (cur.length() > 0) out.add(new Part(in, trimEnd(cur.toString())));
        return out;
    }

    private static String trimEnd(String s) {
        int e = s.length();
        while (e > 0 && (s.charAt(e - 1) == '\n' || s.charAt(e - 1) == ' ')) e--;
        return s.substring(0, e);
    }

    private static final Pattern INLINE = Pattern.compile("\\*\\*(.+?)\\*\\*|`([^`]+)`");

    static CharSequence render(String text, int codeBg) {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        String[] lines = text.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            float size = 1f;
            boolean head = false;
            if (line.startsWith("### ")) { line = line.substring(4); size = 1.05f; head = true; }
            else if (line.startsWith("## ")) { line = line.substring(3); size = 1.1f; head = true; }
            else if (line.startsWith("# ")) { line = line.substring(2); size = 1.2f; head = true; }
            String t = line.trim();
            if (t.startsWith("- ") || t.startsWith("* ") || t.startsWith("\u2022 ")) line = "  \u2022  " + t.substring(2);
            int start = sb.length();
            Matcher m = INLINE.matcher(line);
            int pos = 0;
            while (m.find()) {
                sb.append(line, pos, m.start());
                int a = sb.length();
                if (m.group(1) != null) {
                    sb.append(m.group(1));
                    sb.setSpan(new StyleSpan(Typeface.BOLD), a, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                } else {
                    sb.append(m.group(2));
                    sb.setSpan(new TypefaceSpan("monospace"), a, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    sb.setSpan(new BackgroundColorSpan(codeBg), a, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                pos = m.end();
            }
            sb.append(line, pos, line.length());
            if (head) {
                sb.setSpan(new StyleSpan(Typeface.BOLD), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                sb.setSpan(new RelativeSizeSpan(size), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (i < lines.length - 1) sb.append('\n');
        }
        return sb;
    }
}
