package com.chanit.featuremerger.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Binary XML (AndroidManifest.xml, res/layout/*.xml ...) as readable text, plus a few safe edits done on the parsed tree
 * (the tree is written back as binary XML by {@link Axml#build()}).
 */
public final class AxmlText {
    private AxmlText() {}

    private static final Object[][] KNOWN = {
            {"name", 0x01010003, "s"}, {"label", 0x01010001, "s"}, {"icon", 0x01010002, "r"}, {"roundIcon", 0x0101052c, "r"},
            {"theme", 0x01010000, "r"}, {"enabled", 0x0101000e, "b"}, {"exported", 0x01010010, "b"}, {"debuggable", 0x0101000f, "b"},
            {"persistent", 0x0101000d, "b"}, {"process", 0x01010011, "s"}, {"permission", 0x01010006, "s"}, {"allowBackup", 0x01010280, "b"},
            {"usesCleartextTraffic", 0x010104ec, "b"}, {"requestLegacyExternalStorage", 0x01010603, "b"}, {"largeHeap", 0x0101035a, "b"},
            {"hardwareAccelerated", 0x010102d3, "b"}, {"value", 0x01010024, "s"}, {"resource", 0x01010025, "r"},
            {"maxSdkVersion", 0x01010271, "d"}, {"minSdkVersion", 0x0101020c, "d"}, {"targetSdkVersion", 0x01010270, "d"},
            {"versionCode", 0x0101021b, "d"}, {"versionName", 0x0101021c, "s"}, {"launchMode", 0x0101001d, "d"},
            {"screenOrientation", 0x0101001e, "d"}, {"foregroundServiceType", 0x01010599, "x"}};

    /** Names of the attributes that op "set_attr" can create. */
    public static String knownNames() {
        StringBuilder sb = new StringBuilder();
        for (Object[] k : KNOWN) sb.append(sb.length() > 0 ? ", " : "").append(k[0]);
        return sb.toString();
    }

    // ------------------------------------------------------------------ binary -> text
    public static String toXml(byte[] bin, Arsc arsc) {
        Axml a = Axml.parse(bin);
        Map<String, String> pfx = new HashMap<>();
        for (String[] n : a.namespaces) pfx.put(n[1], n[0]);
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        elem(a.root, 0, sb, pfx, a.namespaces, arsc);
        return sb.toString();
    }

    private static void elem(Axml.Elem e, int depth, StringBuilder sb, Map<String, String> pfx, List<String[]> nss, Arsc arsc) {
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append('<').append(e.name);
        if (depth == 0) for (String[] n : nss) sb.append(" xmlns:").append(n[0]).append("=\"").append(esc(n[1])).append('"');
        for (Axml.Attr at : e.attrs) {
            String p = at.ns == null ? null : pfx.get(at.ns);
            sb.append(' ').append(p == null ? "" : p + ":").append(at.name).append("=\"").append(esc(val(at, arsc))).append('"');
        }
        if (e.kids.isEmpty()) {
            sb.append("/>\n");
            return;
        }
        sb.append(">\n");
        for (Axml.Elem k : e.kids) elem(k, depth + 1, sb, pfx, nss, arsc);
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append("</").append(e.name).append(">\n");
    }

    private static String val(Axml.Attr at, Arsc arsc) {
        if (at.type == Axml.T_STRING) return at.str == null ? "" : at.str;
        if (at.type == Axml.T_REF && arsc != null) {
            try {
                Arsc.Entry en = arsc.get(at.data);
                if (en != null && en.type != null && en.name != null) return "@" + en.type + "/" + en.name;
            } catch (RuntimeException ignored) { }
        }
        return at.text();
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("\n", "&#10;");
    }

    // ------------------------------------------------------------------ edits
    public static final class Result {
        public int changed;
        public byte[] out;
        public String note = "";
    }

    /**
     * ops: set_attr (tag, match, attr, value), remove_attr (tag, match, attr), remove_element (tag, match),
     * replace_text (attr = old text, value = new text; every string value in the file).
     * tag "*" = any element, match = text that the element's android:name (or any attribute value) must contain.
     */
    public static Result apply(byte[] bin, String op, String tag, String match, String attr, String value) {
        Axml a = Axml.parse(bin);
        Result r = new Result();
        if ("replace_text".equals(op)) {
            if (attr == null || attr.isEmpty()) throw new IllegalArgumentException("attr must hold the old text");
            final String old = attr, nw = value == null ? "" : value;
            final int[] n = {0};
            a.root.walk(new Axml.Visitor() {
                @Override public void visit(Axml.Elem e) {
                    for (Axml.Attr at : e.attrs) {
                        if (at.type == Axml.T_STRING && at.str != null && at.str.contains(old)) {
                            at.str = at.str.replace(old, nw);
                            at.raw = at.str;
                            n[0]++;
                        }
                    }
                }
            });
            r.changed = n[0];
        } else {
            final String t = tag == null || tag.isEmpty() ? "*" : tag;
            final String m = match == null ? "" : match;
            final java.util.List<Axml.Elem> hits = new java.util.ArrayList<>();
            a.root.walk(new Axml.Visitor() {
                @Override public void visit(Axml.Elem e) {
                    if (!"*".equals(t) && !t.equals(e.name)) return;
                    if (m.isEmpty() || matches(e, m)) hits.add(e);
                }
            });
            for (Axml.Elem e : hits) {
                if ("set_attr".equals(op)) {
                    e.put(make(attr, value));
                    r.changed++;
                } else if ("remove_attr".equals(op)) {
                    int before = e.attrs.size();
                    for (int i = e.attrs.size() - 1; i >= 0; i--) if (attr.equals(e.attrs.get(i).name)) e.attrs.remove(i);
                    if (e.attrs.size() < before) r.changed++;
                } else if ("remove_element".equals(op)) {
                    if (e == a.root) {
                        r.note += "root element cannot be removed; ";
                        continue;
                    }
                    Axml.Elem parent = Axml.parentOf(a.root, e);
                    if (parent != null) {
                        parent.kids.remove(e);
                        r.changed++;
                    }
                } else {
                    throw new IllegalArgumentException("unknown op " + op + " (set_attr, remove_attr, remove_element, replace_text)");
                }
            }
        }
        if (r.changed > 0) r.out = a.build();
        return r;
    }

    private static boolean matches(Axml.Elem e, String m) {
        String nm = e.text("name");
        if (nm != null && nm.contains(m)) return true;
        for (Axml.Attr at : e.attrs) {
            String v = at.text();
            if (v != null && v.contains(m)) return true;
        }
        return false;
    }

    private static Axml.Attr make(String name, String value) {
        if (name == null || name.isEmpty()) throw new IllegalArgumentException("attr is empty");
        for (Object[] k : KNOWN) {
            if (!k[0].equals(name)) continue;
            int id = (Integer) k[1];
            String kind = (String) k[2];
            if ("b".equals(kind)) return Axml.bool(name, id, "true".equalsIgnoreCase(value) || "1".equals(value));
            if ("d".equals(kind) || "x".equals(kind)) {
                Axml.Attr at = Axml.hex(name, id, parseInt(value));
                if ("d".equals(kind)) at.type = Axml.T_DEC;
                return at;
            }
            if ("r".equals(kind) && value != null && value.startsWith("@0x")) {
                Axml.Attr at = Axml.hex(name, id, parseInt(value.substring(1)));
                at.type = Axml.T_REF;
                return at;
            }
            return Axml.str(name, id, value == null ? "" : value);
        }
        throw new IllegalArgumentException("attribute \"" + name + "\" is not supported by set_attr. Supported: " + knownNames());
    }

    private static int parseInt(String v) {
        String s = v == null ? "0" : v.trim();
        if (s.startsWith("0x") || s.startsWith("0X")) return (int) Long.parseLong(s.substring(2), 16);
        return Integer.parseInt(s);
    }
}
