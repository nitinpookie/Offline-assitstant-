package com.chanit.featuremerger.core;

import android.content.Context;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Runs one user message: the AI answers, its tool calls are executed with {@link ApkTools}, the results go back to the AI,
 * until it answers without a tool call. The protocol is plain text (works with every provider, no JSON escaping of smali):
 * <pre>&lt;call tool="read_file"&gt;&lt;arg name="apk"&gt;x&lt;/arg&gt;&lt;arg name="path"&gt;AndroidManifest.xml&lt;/arg&gt;&lt;/call&gt;</pre>
 */
public final class ChatAgent {
    private ChatAgent() {}

    public interface Sink {
        /** Assistant text (markdown-lite). */
        void say(String text);

        /** A tool call that finished. */
        void step(String label, String result, boolean ok);

        /** Something is running (shown as a small status line). */
        void working(String label);
    }

    private static final int MAX_STEPS = 14, MAX_CALLS = 6;

    private static final Pattern CALL = Pattern.compile("(?s)<call\\s+([^>]*?)\\s*(?:/>|>(.*?)</call>)");
    private static final Pattern ARG = Pattern.compile("(?s)<arg\\s+name\\s*=\\s*\"([A-Za-z_]+)\"\\s*>(.*?)</arg>");
    private static final Pattern ATTR = Pattern.compile("([A-Za-z_]+)\\s*=\\s*\"([^\"]*)\"");
    private static final Pattern FAKE_RESULT = Pattern.compile("(?s)<result\\b.*?(</result>|$)");

    public static final String SYSTEM =
            "You are the editing assistant inside \"Feature Merger\", an Android app on the user's phone. The user uploads APK / XAPK files and attaches "
                    + "files and screenshots in this chat, and asks you to understand, change and rebuild apps (VPN apps, games, any app they have the right to modify).\n"
                    + "Answer in the user's language (Hinglish in Roman letters when they write Hinglish). Write like a good chat assistant: short, clear, no filler. "
                    + "Say what you found or did first, then what comes next. Use **bold** for key words, `code` for names, and short lists with \"- \". Never paste long code in the reply unless asked.\n\n"
                    + "You work by calling tools. To call one, write exactly this (arguments are raw text: no quotes or escaping, they may span several lines):\n"
                    + "<call tool=\"read_file\">\n<arg name=\"apk\">myapp</arg>\n<arg name=\"path\">AndroidManifest.xml</arg>\n</call>\n"
                    + "Write at most one short sentence before the calls, then STOP. The results come back in the next message as <result tool=\"...\">. "
                    + "Up to " + MAX_CALLS + " calls per message. When you need no more tools, answer the user with no <call> in the message.\n\n"
                    + "Rules:\n"
                    + "- Look before you edit: read the manifest, find the code with find_code / list_classes, read it with smali_view. Never guess class or method names.\n"
                    + "- Make the smallest change that does the job. smali_replace `find` must be copied exactly from smali_view (leading spaces too). Keep .locals / .registers valid. "
                    + "A failed edit returns the assembler's error: read it, fix, retry.\n"
                    + "- When the edits are done call build_apk. Never say a file was built unless build_apk returned \"Built\". Read its report and pass on the important parts "
                    + "(signature differs, uninstall the original first, test on the phone).\n"
                    + "- A screenshot or attached file is context: describe what you see in it and use it (for example the text of a pop-up becomes a find_code search).\n"
                    + "- Be honest about limits: native code (.so), encrypted or obfuscated logic, server-side checks and apps that verify their own signature cannot always be changed. "
                    + "You cannot run the app; the user has to test it.\n"
                    + "- Do not help with malware, spyware, stealing data or anything that harms other people. Say so briefly and offer what you can do instead.\n\n"
                    + ApkTools.DOCS;

    private static final class Call {
        String tool;
        final Map<String, String> args = new LinkedHashMap<>();
    }

    private static List<Call> parse(String raw) {
        List<Call> out = new ArrayList<>();
        Matcher m = CALL.matcher(raw);
        while (m.find()) {
            Call c = new Call();
            String attrs = m.group(1) == null ? "" : m.group(1);
            Matcher am = ATTR.matcher(attrs);
            while (am.find()) {
                if (am.group(1).equals("tool")) c.tool = am.group(2).trim();
                else c.args.put(am.group(1), am.group(2));
            }
            String body = m.group(2);
            if (body != null) {
                Matcher bm = ARG.matcher(body);
                while (bm.find()) c.args.put(bm.group(1), unwrap(bm.group(2)));
            }
            if (c.tool != null && !c.tool.isEmpty()) out.add(c);
        }
        return out;
    }

    /** Removes exactly one newline at the start and one at the end (the layout of the call), keeps all other spaces. */
    private static String unwrap(String s) {
        String t = s;
        if (t.startsWith("\r\n")) t = t.substring(2);
        else if (t.startsWith("\n")) t = t.substring(1);
        if (t.endsWith("\r\n")) t = t.substring(0, t.length() - 2);
        else if (t.endsWith("\n")) t = t.substring(0, t.length() - 1);
        return t;
    }

    private static String prose(String raw) {
        String t = CALL.matcher(raw).replaceAll("");
        t = FAKE_RESULT.matcher(t).replaceAll("");
        int cut = t.indexOf("<call");
        if (cut >= 0) t = t.substring(0, cut);
        return t.trim();
    }

    /** What is sent to the provider: recent messages in full, old tool output shortened, old images dropped. */
    private static List<AiChat.Msg> view(List<AiChat.Msg> convo) {
        int from = Math.max(0, convo.size() - 36);
        List<AiChat.Msg> out = new ArrayList<>();
        for (int i = from; i < convo.size(); i++) {
            AiChat.Msg m = convo.get(i);
            AiChat.Msg c = new AiChat.Msg(m.role, m.text);
            boolean recent = i >= convo.size() - 4;
            if (!recent && m.text.startsWith("<result") && c.text.length() > 500) c.text = c.text.substring(0, 500) + "\n...[old output removed]";
            if (i >= convo.size() - 6) c.images = m.images;
            out.add(c);
        }
        return out;
    }

    /** convo already ends with the new user message. Everything the AI says and does is reported to sink. */
    public static void run(Context c, ApkTools tools, List<AiChat.Msg> convo, Sink sink, AtomicBoolean stop) throws AiAbort {
        try {
            AiChat.startTurn(c);
            final AiChat.Note note = new AiChat.Note() {
                @Override public void say(String s) { sink.working(s); }
            };
            for (int it = 0; it < MAX_STEPS; it++) {
                if (stop.get()) {
                    sink.say("_Roka gaya._");
                    return;
                }
                sink.working(it == 0 ? "Soch raha hun" : "Agla step soch raha hun");
                AiChat.Reply r = AiChat.complete(c, SYSTEM, view(convo), note);
                if (r.visionDropped) sink.working("Ye model image nahi dekh sakta, sirf text se kaam kar raha hun");
                String raw = r.text == null ? "" : r.text;
                convo.add(new AiChat.Msg("assistant", raw));
                List<Call> calls = parse(raw);
                String p = prose(raw);
                if (!p.isEmpty()) sink.say(p);
                if (calls.isEmpty()) {
                    if (raw.contains("<call")) { // the answer was cut off inside a call
                        convo.add(new AiChat.Msg("user", "Your last message was cut off inside a tool call. Send the call again, shorter (one call per message)."));
                        continue;
                    }
                    return;
                }
                StringBuilder res = new StringBuilder();
                int n = 0;
                for (Call cl : calls) {
                    if (stop.get()) break;
                    if (n++ >= MAX_CALLS) {
                        res.append("<result tool=\"").append(cl.tool).append("\">\nskipped: at most ").append(MAX_CALLS).append(" calls per message\n</result>\n");
                        continue;
                    }
                    String label = ApkTools.label(cl.tool, cl.args);
                    sink.working(label);
                    String out = tools.run(cl.tool, cl.args);
                    boolean ok = !out.startsWith("ERROR:");
                    sink.step(label, out, ok);
                    res.append("<result tool=\"").append(cl.tool).append("\">\n").append(out).append("\n</result>\n");
                }
                convo.add(new AiChat.Msg("user", res.length() == 0 ? "(stopped)" : res.toString()));
            }
            convo.add(new AiChat.Msg("user", "Step limit reached. Do not call tools now. Tell the user in a few lines what is done and what is left."));
            AiChat.Reply fin = AiChat.complete(c, SYSTEM, view(convo), note);
            convo.add(new AiChat.Msg("assistant", fin.text));
            String p = prose(fin.text);
            if (!p.isEmpty()) sink.say(p);
        } catch (AiHelper.AiException e) {
            throw new AiAbort(e.getMessage());
        }
    }

    /** The turn stopped because of an error the user should read (limit, key, network). */
    public static final class AiAbort extends Exception {
        public AiAbort(String m) { super(m); }
    }
}
