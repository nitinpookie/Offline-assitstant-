package com.chanit.featuremerger;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.chanit.featuremerger.core.AiHelper;
import com.chanit.featuremerger.core.VpnEnhancer;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Chat with the AI helper about the scanned VPN. The AI knows the VPN's features, where they are wired in the code and what is
 * already planned. It answers in text and, when it is sure, with settings you can add to the plan with one tap.
 */
public class AiChatActivity extends AppCompatActivity {
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout list;
    private ScrollView scroll;
    private EditText input;
    private MaterialButton sendBtn;
    private TextView head;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(16), dp(12), dp(8));
        setContentView(root);

        TextView title = text("AI chat", 20, true);
        root.addView(title);
        head = text("", 11, false);
        root.addView(head);

        HorizontalScrollView chips = new HorizontalScrollView(this);
        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        chips.addView(chipRow);
        chipRow.addView(chip("Purana game: lobby ok, match nahi aa raha"));
        chipRow.addView(chip("Mere game ko poora route karo"));
        chipRow.addView(chip("Is VPN ke features samjhao"));
        root.addView(chips);

        scroll = new ScrollView(this);
        scroll.setDescendantFocusability(android.view.ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(8), 0, dp(8));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setHint("Apni baat likho ...");
        input.setMinLines(1);
        input.setMaxLines(4);
        row.addView(input, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        sendBtn = new MaterialButton(this);
        sendBtn.setText("Send");
        sendBtn.setOnClickListener(v -> send(input.getText().toString()));
        row.addView(sendBtn);
        root.addView(row);

        refreshHead();
        if (EnhanceState.chat.isEmpty()) {
            String greet = EnhanceState.scan == null
                    ? "Pehle Enhance screen par VPN ko Scan karo, tab main uske features dekh kar madad kar paunga. Chaho to abhi bhi sawal pooch lo."
                    : "Maine " + (EnhanceState.apk == null ? "VPN" : EnhanceState.apk.label) + " ke " + EnhanceState.scan.controls.size()
                    + " features dekh liye. Batao kya dikkat hai ya kya chahiye (jaise: \"VPN naye game pe sahi hai, par 2022 wale version me lobby ke baad match nahi aata\").";
            bubble(false, greet);
        } else {
            for (String[] t : EnhanceState.chat) bubble("user".equals(t[0]), t[1]);
        }
    }

    private void refreshHead() {
        AiHelper.Config c = AiHelper.load(this);
        AiHelper.Prov pv = AiHelper.prov(c.provider);
        head.setText((c.ready() ? pv.label + "  \u00B7  " + AiHelper.usedToday(this) + "/" + c.cap + " asks today" : "AI not set up (Enhance screen > AI setup)")
                + (EnhanceState.focus == null ? "" : "\nLooking at: " + EnhanceState.focus.title));
    }

    private MaterialButton chip(final String label) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setOnClickListener(v -> send(label));
        return b;
    }

    // ------------------------------------------------------------------ one turn
    private void send(String raw) {
        final String text = raw == null ? "" : raw.trim();
        if (text.isEmpty() || !sendBtn.isEnabled()) return;
        EnhanceState.chat.add(new String[]{"user", text});
        bubble(true, text);
        input.setText("");
        input.requestFocus();
        sendBtn.setEnabled(false);
        final TextView live = text("", 11, false);
        live.setTypeface(Typeface.MONOSPACE);
        live.setAlpha(0.8f);
        list.addView(live);
        scrollDown();
        exec.execute(() -> {
            try {
                final AiHelper.Answer a = AiHelper.chat(this, EnhanceState.context(), new ArrayList<>(EnhanceState.chat), EnhanceState.focus,
                        line -> ui.post(() -> {
                            live.append(live.length() > 0 ? "\n" + line : line);
                            scrollDown();
                        }));
                ui.post(() -> {
                    list.removeView(live);
                    String reply = a.summary.isEmpty() ? "(AI ne text nahi diya)" : a.summary;
                    EnhanceState.chat.add(new String[]{"ai", reply});
                    bubble(false, reply);
                    TextView meta = text("model: " + a.model + "  \u00B7  web: " + (a.searched ? "yes" : "no"), 10, false);
                    meta.setAlpha(0.6f);
                    list.addView(meta);
                    if (!a.ops.isEmpty()) opsCard(a);
                    sendBtn.setEnabled(true);
                    refreshHead();
                    scrollDown();
                });
            } catch (AiHelper.AiException e) {
                ui.post(() -> {
                    list.removeView(live);
                    EnhanceState.chat.remove(EnhanceState.chat.size() - 1); // the failed question is not part of the conversation
                    bubble(false, "\u2718 " + e.getMessage());
                    sendBtn.setEnabled(true);
                    refreshHead();
                });
            } catch (Throwable t) {
                ui.post(() -> {
                    list.removeView(live);
                    bubble(false, "\u2718 Error: " + t);
                    sendBtn.setEnabled(true);
                });
            }
        });
    }

    private void opsCard(final AiHelper.Answer a) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), 0x66888888);
        card.setBackground(bg);
        card.addView(text("Suggested changes", 12, true));
        StringBuilder sb = new StringBuilder();
        for (VpnEnhancer.Op o : a.ops) sb.append("\u2022 ").append(o.label).append('\n');
        card.addView(text(sb.toString().trim(), 12, false));
        final MaterialButton add = new MaterialButton(this);
        add.setText("Add to plan");
        add.setOnClickListener(v -> {
            EnhanceState.addOps(a.ops);
            add.setEnabled(false);
            add.setText("Added");
            Toast.makeText(this, "Added. Go back to the Enhance screen and press Build.", Toast.LENGTH_LONG).show();
        });
        card.addView(add);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        list.addView(card, lp);
        if (!a.dropped.isEmpty()) list.addView(text("Ignored: " + a.dropped, 10, false));
    }

    // ------------------------------------------------------------------ views
    private void bubble(boolean mine, String s) {
        TextView t = text(s, 14, false);
        t.setTextIsSelectable(true);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        bg.setColor(mine ? 0x334F8CFF : 0x22888888);
        t.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        lp.gravity = mine ? Gravity.END : Gravity.START;
        if (mine) lp.leftMargin = dp(48); else lp.rightMargin = dp(48);
        list.addView(t, lp);
        scrollDown();
    }

    private void scrollDown() {
        // NOT fullScroll(FOCUS_DOWN): that moves focus to a selectable bubble, the EditText loses focus and the keyboard closes
        scroll.post(() -> scroll.scrollTo(0, Math.max(0, list.getHeight() - scroll.getHeight() + scroll.getPaddingBottom() + list.getPaddingBottom())));
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, dp(4), 0, dp(2));
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
    }
}
