package com.liveedit.patcher;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class MainActivity extends Activity {

    private static final int REQ_PICK = 42;
    private static final int REQ_SAVE = 43;
    private static final String INTERNET = "android.permission.INTERNET";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Opts opts = new Opts();
    private final List<Runnable> syncers = new ArrayList<Runnable>();
    private final StringBuilder logText = new StringBuilder();
    private final List<String> bootComps = new ArrayList<String>();
    private final List<String> privPerms = new ArrayList<String>();

    private FrameLayout root;
    private TextView barInfo;
    private TextView workLog;
    private ScrollView workScroll;
    private ProgressBar workBar;
    private ScrollView optScroll;

    private Patcher.Analysis an;
    private Patcher.Result last;
    private boolean busy;
    private boolean syncing;
    private int screen; // 0 home, 1 options, 2 working, 3 done / error
    private int scrollY;
    private String phoneAbi = "";

    // =======================================================================================
    // lifecycle
    // =======================================================================================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        if (Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0) phoneAbi = Build.SUPPORTED_ABIS[0];
        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        setContentView(root);
        showHome();
    }

    @Override
    public void onBackPressed() {
        if (screen == 2) return; // working: wait
        if (screen == 1) {
            Ui.dialog(this).setTitle("Leave this app?")
                    .setMessage("Your selected options will be lost.")
                    .setPositiveButton("Leave", (d, w) -> showHome())
                    .setNegativeButton("Stay", null).show();
            return;
        }
        if (screen == 3 && an != null) {
            showOptions();
            return;
        }
        if (screen == 3) {
            showHome();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (req == REQ_PICK) {
            load(() -> {
                File f = newInputFile();
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open that file");
                Patcher.copy(is, f);
                return f;
            }, false);
        } else if (req == REQ_SAVE) {
            saveCopy(uri);
        }
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private void show(View v) {
        root.removeAllViews();
        root.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    // =======================================================================================
    // 1. home
    // =======================================================================================

    private void showHome() {
        screen = 0;
        an = null;
        ScrollView sv = new ScrollView(this);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(40), dp(18), dp(28));
        sv.addView(col);

        col.addView(Ui.text(this, "Live Editor", 32, Ui.TEXT, true));
        TextView sub = Ui.text(this, "Pro APK patcher. Pick an app, tick what you want changed, tap Patch. "
                + "No coding, no PC.", 14, Ui.SUB, false);
        sub.setPadding(0, dp(6), 0, dp(22));
        col.addView(sub);

        bigCard(col, "Choose an APK file", "From your phone storage or downloads", this::pickFile);
        bigCard(col, "Pick an installed app", "Takes the APK straight from an app on this phone", this::pickInstalled);

        LinearLayout info = Ui.card(this);
        info.setPadding(dp(16), dp(14), dp(16), dp(14));
        info.addView(Ui.text(this, "What you can change", 15, Ui.TEXT, true));
        String[] lines = {
                "App name and version",
                "Remove permissions (internet, location, contacts, camera...)",
                "Switch off parts of the app (auto-start after boot, services)",
                "Block ad, tracker or any other server the app talks to",
                "Hide ad banners, mute click sounds, fullscreen, keep screen on",
                "Lock rotation, allow screenshots, faster or no animations",
                "Resize or fade floating overlay buttons",
                "Keep only your phone's CPU type (smaller APK)"
        };
        for (String l : lines) {
            TextView t = Ui.text(this, "•  " + l, 13.5f, Ui.SUB, false);
            t.setPadding(0, dp(6), 0, 0);
            info.addView(t);
        }
        Ui.add(col, info, 14);

        TextView note = Ui.text(this, "Everything is chosen here, before patching. The patched app gets no editor, "
                + "no button and no menu. Changes work on the phone side only: they cannot change what a server "
                + "sends back.", 12.5f, Ui.SUB, false);
        note.setPadding(dp(4), dp(16), dp(4), 0);
        col.addView(note);
        show(sv);
    }

    private void bigCard(LinearLayout col, String title, String sub, final Runnable click) {
        LinearLayout c = Ui.vbox(this);
        c.setBackground(Ui.ripple(this, Ui.CARD, 18));
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setClickable(true);
        c.addView(Ui.text(this, title, 18, Ui.TEXT, true));
        TextView s = Ui.text(this, sub, 13, Ui.SUB, false);
        s.setPadding(0, dp(4), 0, 0);
        c.addView(s);
        c.setOnClickListener(v -> click.run());
        Ui.add(col, c, 12);
    }

    private void pickFile() {
        if (busy) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK);
    }

    private void pickInstalled() {
        if (busy) return;
        Toast.makeText(this, "Loading apps...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            final List<Ui.Item> user = new ArrayList<Ui.Item>();
            final List<Ui.Item> sys = new ArrayList<Ui.Item>();
            final Map<String, ApplicationInfo> byPkg = new HashMap<String, ApplicationInfo>();
            for (ApplicationInfo ai : apps) {
                if (ai.sourceDir == null || ai.packageName.equals(getPackageName())) continue;
                boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                boolean split = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
                String sub = ai.packageName + (split ? "  •  split app" : "") + (system ? "  •  system" : "");
                Ui.Item it = new Ui.Item(ai.packageName, String.valueOf(ai.loadLabel(pm)), sub, ai.loadIcon(pm));
                byPkg.put(ai.packageName, ai);
                (system ? sys : user).add(it);
            }
            Collections.sort(user, (x, y) -> x.title.compareToIgnoreCase(y.title));
            Collections.sort(sys, (x, y) -> x.title.compareToIgnoreCase(y.title));
            final List<Ui.Item> items = new ArrayList<Ui.Item>(user);
            items.addAll(sys);
            runOnUiThread(() -> Ui.list(this, "Pick an app", items, null, it -> {
                final ApplicationInfo ai = byPkg.get(it.key);
                if (ai == null) return;
                final boolean split = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
                load(() -> {
                    File f = newInputFile();
                    Patcher.copy(new FileInputStream(ai.sourceDir), f);
                    return f;
                }, split);
            }, null));
        }).start();
    }

    private File newInputFile() {
        File d = new File(getCacheDir(), "work");
        Patcher.deleteTree(d);
        if (!d.mkdirs()) throw new IllegalStateException("Cannot create cache folder (storage full?)");
        return new File(d, "input.apk");
    }

    // =======================================================================================
    // loading and patching (background work)
    // =======================================================================================

    private void load(final Callable<File> getFile, final boolean split) {
        if (busy) return;
        busy = true;
        synchronized (logText) {
            logText.setLength(0);
        }
        showWorking("Reading the app...");
        new Thread(() -> {
            try {
                line("Copying the APK...");
                File f = getFile.call();
                line("Looking inside (manifest, code, servers)...");
                final Patcher.Analysis a = Patcher.analyze(this, f);
                a.split = split;
                runOnUiThread(() -> {
                    busy = false;
                    an = a;
                    opts.reset();
                    prepareDerived();
                    scrollY = 0;
                    showOptions();
                });
            } catch (final Throwable t) {
                line("ERROR: " + t);
                runOnUiThread(() -> {
                    busy = false;
                    showError(t);
                });
            }
        }).start();
    }

    private void startPatch() {
        if (busy || an == null) return;
        if (opts.changeCount() == 0) {
            Toast.makeText(this, "Select at least one option first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (an.alreadyPatched && opts.needsEngine()) {
            Ui.info(this, "Already has an engine",
                    "This APK already contains an older Live Editor. Pick the original app again.");
            return;
        }
        busy = true;
        synchronized (logText) {
            logText.setLength(0);
        }
        showWorking("Patching...");
        final Patcher.Analysis a = an;
        new Thread(() -> {
            try {
                final Patcher.Result r = Patcher.run(this, a, opts, new Patcher.Log() {
                    @Override
                    public void line(String s) {
                        MainActivity.this.line(s);
                    }

                    @Override
                    public void progress(final int p) {
                        runOnUiThread(() -> {
                            if (workBar != null) {
                                workBar.setIndeterminate(false);
                                workBar.setProgress(p);
                            }
                        });
                    }
                });
                runOnUiThread(() -> {
                    busy = false;
                    last = r;
                    showDone();
                });
            } catch (final Throwable t) {
                line("ERROR: " + t);
                runOnUiThread(() -> {
                    busy = false;
                    showError(t);
                });
            }
        }).start();
    }

    private void line(final String s) {
        synchronized (logText) {
            logText.append(s).append('\n');
        }
        runOnUiThread(() -> {
            if (workLog != null) {
                workLog.append(s + "\n");
                if (workScroll != null) workScroll.post(() -> workScroll.fullScroll(View.FOCUS_DOWN));
            }
        });
    }

    private void prepareDerived() {
        bootComps.clear();
        privPerms.clear();
        for (Axml.Comp c : an.info.comps) {
            if (!"receiver".equals(c.type)) continue;
            for (String a : c.actions) {
                if (a.equals("android.intent.action.BOOT_COMPLETED")
                        || a.equals("android.intent.action.LOCKED_BOOT_COMPLETED")
                        || a.endsWith("QUICKBOOT_POWERON")) {
                    bootComps.add(c.name);
                    break;
                }
            }
        }
        for (String p : Presets.PRIVATE_PERMS) {
            if (an.info.perms.contains(p)) privPerms.add(p);
        }
    }

    // =======================================================================================
    // 2. options
    // =======================================================================================

    private void showOptions() {
        screen = 1;
        syncers.clear();
        LinearLayout page = Ui.vbox(this);

        optScroll = new ScrollView(this);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(14), dp(16), dp(14), dp(24));
        optScroll.addView(col);

        col.addView(appCard());
        col.addView(presetRow());

        // ---- identity
        LinearLayout c = card(col, "App identity");
        inputRow(c, "App name", "Keep: " + an.label, () -> opts.appName, v -> opts.appName = v,
                InputType.TYPE_CLASS_TEXT);
        inputRow(c, "Version name", "Keep: " + (an.info.versionName == null ? "unknown" : an.info.versionName),
                () -> opts.versionName, v -> opts.versionName = v, InputType.TYPE_CLASS_TEXT);
        inputRow(c, "Version code", "Keep: " + an.info.versionCode, () -> opts.versionCode,
                v -> opts.versionCode = v, InputType.TYPE_CLASS_NUMBER);

        // ---- permissions
        c = card(col, "Permissions");
        if (an.info.perms.isEmpty()) {
            c.addView(note("This app asks for no permissions."));
        } else {
            if (an.info.perms.contains(INTERNET)) {
                switchRow(c, "Remove internet access",
                        "App works offline. Anything that needs a server stops loading.",
                        () -> opts.removePerms.contains(INTERNET),
                        v -> setIn(opts.removePerms, INTERNET, v));
            }
            if (!privPerms.isEmpty()) {
                switchRow(c, "Remove private-data permissions",
                        privPerms.size() + " found: location, contacts, calls, SMS, camera, microphone, calendar",
                        () -> opts.removePerms.containsAll(privPerms),
                        v -> {
                            if (v) opts.removePerms.addAll(privPerms);
                            else opts.removePerms.removeAll(privPerms);
                        });
            }
            actionRow(c, "Choose permissions to remove",
                    () -> opts.removePerms.size() + " selected of " + an.info.perms.size(), this::pickPerms);
        }

        // ---- parts of the app
        c = card(col, "Parts of the app");
        if (!bootComps.isEmpty()) {
            switchRow(c, "Stop auto-start after phone boot",
                    bootComps.size() + " boot receiver" + (bootComps.size() == 1 ? "" : "s") + " found",
                    () -> opts.disableComps.containsAll(bootComps),
                    v -> {
                        if (v) opts.disableComps.addAll(bootComps);
                        else opts.disableComps.removeAll(bootComps);
                    });
        }
        actionRow(c, "Switch off parts of the app",
                () -> opts.disableComps.size() + " selected of " + an.info.comps.size()
                        + " (screens, services, receivers)", this::pickComps);

        // ---- screen & system
        c = card(col, "Screen and behaviour");
        choiceRow(c, "Screen rotation", new String[]{"Keep original", "Lock portrait", "Lock landscape",
                        "Auto-rotate always", "Follow phone setting"},
                () -> opts.orientation, v -> opts.orientation = v);
        switchRow(c, "Keep screen on", "Screen never turns off while the app is open",
                () -> opts.keepOn, v -> opts.keepOn = v);
        switchRow(c, "Allow screenshots", "Removes the \"can't take screenshot\" block",
                () -> opts.allowShot, v -> opts.allowShot = v);
        switchRow(c, "Fullscreen", "Hides status and navigation bars (swipe to show)",
                () -> opts.immersive, v -> opts.immersive = v);
        choiceRow(c, "Animations", new String[]{"Normal", "Faster", "Off"}, () -> opts.anim, v -> opts.anim = v);
        switchRow(c, "Mute click sounds", "Turns off the tap sound of buttons and lists",
                () -> opts.mute, v -> opts.mute = v);

        // ---- servers & ads
        c = card(col, "Servers and ads");
        switchRow(c, "Block ad servers", Presets.AD_HOSTS.length + " known ad networks",
                () -> opts.blockAds, v -> opts.blockAds = v);
        switchRow(c, "Block tracking and analytics servers", Presets.TRACKER_HOSTS.length + " known trackers",
                () -> opts.blockTrackers, v -> opts.blockTrackers = v);
        switchRow(c, "Hide ad banners", "Hides banner and native ad views from common ad SDKs",
                () -> opts.hideAds, v -> opts.hideAds = v);
        if (an.scan.hosts.isEmpty()) {
            c.addView(note("No server addresses were found written inside this app's code."));
        } else {
            actionRow(c, "Servers found in this app",
                    () -> an.scan.hosts.size() + " found, " + opts.allHosts().size() + " blocked in total",
                    this::pickHosts);
        }
        inputRow(c, "Block other servers", "ads.example.com, tracker.site.net",
                () -> opts.customHosts, v -> opts.customHosts = v, InputType.TYPE_CLASS_TEXT);
        c.addView(note("Blocking stops the app from reaching a server. It cannot change what a server sends. "
                + "WebView pages and apps that use their own network code may still connect."));

        // ---- overlay buttons
        c = card(col, "Floating overlay buttons");
        sliderRow(c, "Size", 30, 250, () -> opts.scale, v -> opts.scale = v);
        sliderRow(c, "Opacity", 10, 100, () -> opts.alpha, v -> opts.alpha = v);
        c.addView(note("For apps that draw floating buttons on top of other apps. 100% = unchanged."));

        // ---- app flags
        c = card(col, "Advanced app flags");
        String[] tri = {"Keep", "On", "Off"};
        choiceRow(c, "Debuggable", tri, () -> opts.debuggable, v -> opts.debuggable = v);
        choiceRow(c, "Allow backup", tri, () -> opts.backup, v -> opts.backup = v);
        choiceRow(c, "Allow plain HTTP", tri, () -> opts.cleartext, v -> opts.cleartext = v);
        choiceRow(c, "Large memory heap", tri, () -> opts.largeHeap, v -> opts.largeHeap = v);

        // ---- size
        if (an.scan.abis.size() > 1) {
            c = card(col, "APK size");
            final List<String> abis = new ArrayList<String>(an.scan.abis);
            String[] names = new String[abis.size() + 1];
            names[0] = "Keep all CPU types";
            for (int i = 0; i < abis.size(); i++) {
                names[i + 1] = "Only " + abis.get(i) + (abis.get(i).equals(phoneAbi) ? " (this phone)" : "");
            }
            choiceRow(c, "CPU types", names,
                    () -> opts.keepAbi == null ? 0 : abis.indexOf(opts.keepAbi) + 1,
                    v -> opts.keepAbi = v == 0 ? null : abis.get(v - 1));
            c.addView(note("A CPU type your phone does not use makes the app crash. Pick the one marked \"this phone\"."));
        }

        TextView foot = note("The patched app is signed with the Live Editor key, so Android treats it as a "
                + "different app: uninstall the original first (its data is lost), then install.");
        foot.setPadding(dp(4), dp(18), dp(4), 0);
        col.addView(foot);

        page.addView(optScroll, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout bottom = Ui.hbox(this);
        bottom.setBackgroundColor(Ui.CARD);
        bottom.setPadding(dp(16), dp(10), dp(16), dp(10));
        barInfo = Ui.text(this, "", 13.5f, Ui.TEXT, false);
        bottom.addView(barInfo, new LinearLayout.LayoutParams(0, WRAP, 1f));
        Button go = Ui.button(this, "Patch", true);
        go.setOnClickListener(v -> startPatch());
        bottom.addView(go);
        page.addView(bottom, new LinearLayout.LayoutParams(MATCH, WRAP));

        show(page);
        final int y = scrollY;
        optScroll.post(() -> optScroll.scrollTo(0, y));
        updateBar();
    }

    private void rerender() {
        scrollY = optScroll != null ? optScroll.getScrollY() : 0;
        showOptions();
    }

    private View appCard() {
        LinearLayout card = Ui.card(this);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout row = Ui.hbox(this);
        if (an.icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(an.icon);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(52), dp(52));
            lp.rightMargin = dp(14);
            row.addView(iv, lp);
        }
        LinearLayout tx = Ui.vbox(this);
        tx.addView(Ui.text(this, an.label, 19, Ui.TEXT, true));
        tx.addView(Ui.text(this, an.info.pkg == null ? "" : an.info.pkg, 12, Ui.SUB, false));
        row.addView(tx, new LinearLayout.LayoutParams(0, WRAP, 1f));
        card.addView(row);

        StringBuilder d = new StringBuilder();
        if (an.info.versionName != null) d.append("v").append(an.info.versionName).append(" (").append(an.info.versionCode).append(")  •  ");
        d.append(String.format(Locale.US, "%.1f MB", an.size / 1048576.0));
        if (!an.scan.abis.isEmpty()) d.append("  •  ").append(join(an.scan.abis));
        d.append("  •  ").append(an.scan.dexCount).append(" code file").append(an.scan.dexCount == 1 ? "" : "s");
        TextView det = Ui.text(this, d.toString(), 12.5f, Ui.SUB, false);
        det.setPadding(0, dp(10), 0, 0);
        card.addView(det);

        if (an.split) {
            card.addView(warn("Split app: only the base APK was taken. It may not install or run without its other parts."));
        }
        if (an.alreadyPatched) {
            card.addView(warn("This APK already holds an older Live Editor engine. Engine options are blocked; pick the original app."));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        card.setLayoutParams(lp);
        return card;
    }

    private View presetRow() {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, dp(14), 0, 0);
        String[] names = {"Privacy", "Ads off", "Smaller", "Faster UI", "Reset all"};
        for (int i = 0; i < names.length; i++) {
            final int which = i;
            TextView chip = Ui.chip(this, names[i]);
            chip.setOnClickListener(v -> applyPreset(which));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.rightMargin = dp(8);
            row.addView(chip, lp);
        }
        hs.addView(row);
        return hs;
    }

    private void applyPreset(int which) {
        String msg = "";
        if (which == 0) {
            opts.removePerms.addAll(privPerms);
            opts.blockTrackers = true;
            msg = "Privacy: private permissions removed, trackers blocked";
        } else if (which == 1) {
            opts.blockAds = true;
            opts.hideAds = true;
            msg = "Ads off: ad servers blocked, banners hidden";
        } else if (which == 2) {
            if (an.scan.abis.size() > 1 && an.scan.abis.contains(phoneAbi)) {
                opts.keepAbi = phoneAbi;
                msg = "Smaller: only " + phoneAbi + " kept";
            } else {
                msg = "Nothing to shrink: no other CPU types in this APK";
            }
        } else if (which == 3) {
            opts.anim = 1;
            opts.mute = true;
            msg = "Faster UI: quicker animations, no click sounds";
        } else {
            opts.reset();
            msg = "All options cleared";
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        rerender();
    }

    // ---- pick dialogs -----------------------------------------------------------------------

    private void pickPerms() {
        List<String> sorted = new ArrayList<String>(an.info.perms);
        Collections.sort(sorted);
        List<Ui.Item> items = new ArrayList<Ui.Item>();
        for (String p : sorted) {
            boolean priv = privPerms.contains(p);
            items.add(new Ui.Item(p, Presets.niceName(p), (priv ? "private data  •  " : "") + p, null));
        }
        Ui.list(this, "Remove permissions", items, opts.removePerms, null, this::afterChange);
    }

    private void pickComps() {
        List<Ui.Item> items = new ArrayList<Ui.Item>();
        for (Axml.Comp c : an.info.comps) {
            String shortName = c.name.substring(c.name.lastIndexOf('.') + 1);
            String flags = c.type + (c.launcher ? "  •  app icon entry" : "") + (!c.enabled ? "  •  already off" : "");
            items.add(new Ui.Item(c.name, shortName, flags + "\n" + c.name, null));
        }
        Ui.list(this, "Switch off parts of the app", items, opts.disableComps, null, () -> {
            for (Axml.Comp c : an.info.comps) {
                if (c.launcher && opts.disableComps.contains(c.name)) {
                    Toast.makeText(this, "You switched off the app's main screen: it will not open.",
                            Toast.LENGTH_LONG).show();
                    break;
                }
            }
            afterChange();
        });
    }

    private void pickHosts() {
        List<Ui.Item> items = new ArrayList<Ui.Item>();
        for (String h : an.scan.hosts) {
            Integer n = an.scan.hostCount.get(h);
            items.add(new Ui.Item(h, h, "found " + (n == null ? 1 : n.intValue()) + "x in the app", null));
        }
        Ui.list(this, "Servers found in this app", items, opts.blockHosts, null, this::afterChange);
    }

    // ---- row builders -----------------------------------------------------------------------

    private LinearLayout card(LinearLayout col, String title) {
        col.addView(Ui.section(this, title));
        LinearLayout c = Ui.card(this);
        col.addView(c, new LinearLayout.LayoutParams(MATCH, WRAP));
        return c;
    }

    private void addRow(LinearLayout card, View row) {
        if (card.getChildCount() > 0) card.addView(Ui.divider(this));
        card.addView(row);
    }

    private TextView note(String s) {
        TextView t = Ui.text(this, s, 12, Ui.SUB, false);
        t.setPadding(0, dp(10), 0, dp(10));
        return t;
    }

    private TextView warn(String s) {
        TextView t = Ui.text(this, s, 12.5f, Ui.WARN, false);
        t.setPadding(0, dp(10), 0, 0);
        return t;
    }

    private static String join(java.util.Collection<String> c) {
        StringBuilder b = new StringBuilder();
        for (String s : c) {
            if (b.length() > 0) b.append(", ");
            b.append(s);
        }
        return b.toString();
    }

    private static void setIn(java.util.Set<String> set, String v, boolean on) {
        if (on) set.add(v);
        else set.remove(v);
    }

    private void switchRow(LinearLayout card, String title, String sub,
                           final Supplier<Boolean> g, final Consumer<Boolean> s) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, dp(10), 0, dp(10));
        LinearLayout tx = Ui.vbox(this);
        tx.addView(Ui.text(this, title, 15, Ui.TEXT, false));
        if (sub != null) {
            TextView st = Ui.text(this, sub, 12.5f, Ui.SUB, false);
            st.setPadding(0, dp(2), dp(8), 0);
            tx.addView(st);
        }
        row.addView(tx, new LinearLayout.LayoutParams(0, WRAP, 1f));
        final Switch sw = new Switch(this);
        sw.setChecked(g.get());
        sw.setOnCheckedChangeListener((b, checked) -> {
            if (syncing) return;
            s.accept(checked);
            afterChange();
        });
        row.addView(sw);
        row.setOnClickListener(v -> sw.toggle());
        syncers.add(() -> {
            boolean want = g.get();
            if (sw.isChecked() != want) sw.setChecked(want);
        });
        addRow(card, row);
    }

    private void actionRow(LinearLayout card, String title, final Supplier<String> sub, final Runnable click) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, dp(12), 0, dp(12));
        LinearLayout tx = Ui.vbox(this);
        tx.addView(Ui.text(this, title, 15, Ui.TEXT, false));
        final TextView st = Ui.text(this, sub.get(), 12.5f, Ui.SUB, false);
        st.setPadding(0, dp(2), 0, 0);
        tx.addView(st);
        row.addView(tx, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(Ui.text(this, "›", 24, Ui.SUB, false));
        row.setOnClickListener(v -> click.run());
        syncers.add(() -> st.setText(sub.get()));
        addRow(card, row);
    }

    private void choiceRow(LinearLayout card, String title, String[] items,
                           final Supplier<Integer> g, final Consumer<Integer> s) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, dp(6), 0, dp(6));
        row.addView(Ui.text(this, title, 15, Ui.TEXT, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        final Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items));
        sp.setSelection(g.get(), false);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (syncing || pos == g.get().intValue()) return;
                s.accept(pos);
                afterChange();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {}
        });
        row.addView(sp);
        syncers.add(() -> {
            int want = g.get();
            if (sp.getSelectedItemPosition() != want) sp.setSelection(want, false);
        });
        addRow(card, row);
    }

    private void inputRow(LinearLayout card, String title, String hint,
                          Supplier<String> g, final Consumer<String> s, int inputType) {
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, dp(10), 0, dp(12));
        row.addView(Ui.text(this, title, 15, Ui.TEXT, false));
        EditText e = Ui.edit(this, hint);
        e.setInputType(inputType);
        e.setText(g.get());
        Ui.onText(e, v -> {
            s.accept(v);
            updateBar();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(6);
        row.addView(e, lp);
        addRow(card, row);
    }

    private void sliderRow(LinearLayout card, String title, final int lo, final int hi,
                           Supplier<Integer> g, final Consumer<Integer> s) {
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, dp(10), 0, dp(8));
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, title, 15, Ui.TEXT, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        final TextView val = Ui.text(this, g.get() + "%", 14, Ui.ACCENT, true);
        head.addView(val);
        row.addView(head);
        SeekBar sb = new SeekBar(this);
        sb.setMax(hi - lo);
        sb.setProgress(g.get() - lo);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                int v = lo + p;
                s.accept(v);
                val.setText(v + "%");
                updateBar();
            }

            @Override
            public void onStartTrackingTouch(SeekBar b) {}

            @Override
            public void onStopTrackingTouch(SeekBar b) {}
        });
        row.addView(sb, new LinearLayout.LayoutParams(MATCH, WRAP));
        addRow(card, row);
    }

    private void afterChange() {
        syncing = true;
        try {
            for (Runnable r : syncers) r.run();
        } finally {
            syncing = false;
        }
        updateBar();
    }

    private void updateBar() {
        if (barInfo == null) return;
        int n = opts.changeCount();
        String s = n == 0 ? "Nothing selected yet" : n + " change" + (n == 1 ? "" : "s") + " selected";
        if (n > 0 && opts.needsEngine()) s += "\n+ silent engine inside the app";
        barInfo.setText(s);
    }

    // =======================================================================================
    // 3. working / error / done
    // =======================================================================================

    private void showWorking(String title) {
        screen = 2;
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(44), dp(18), dp(18));
        col.addView(Ui.text(this, title, 24, Ui.TEXT, true));
        workBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        workBar.setMax(100);
        workBar.setIndeterminate(true);
        Ui.add(col, workBar, 16);

        workLog = Ui.text(this, "", 12.5f, Ui.SUB, false);
        workLog.setTypeface(Typeface.MONOSPACE);
        workLog.setPadding(dp(14), dp(12), dp(14), dp(12));
        workLog.setBackground(Ui.round(this, Ui.CARD, 14));
        workScroll = new ScrollView(this);
        workScroll.addView(workLog);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
        lp.topMargin = dp(16);
        col.addView(workScroll, lp);
        show(col);
        synchronized (logText) {
            workLog.setText(logText.toString());
        }
    }

    private void showError(Throwable t) {
        screen = 3;
        ScrollView sv = new ScrollView(this);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(40), dp(18), dp(24));
        sv.addView(col);
        col.addView(Ui.text(this, "That did not work", 26, Ui.BAD, true));
        String m = t.getMessage() != null ? t.getMessage() : t.toString();
        TextView msg = Ui.text(this, m, 14.5f, Ui.TEXT, false);
        msg.setPadding(0, dp(10), 0, dp(6));
        col.addView(msg);
        TextView log = Ui.text(this, logSnapshot(), 12, Ui.SUB, false);
        log.setTypeface(Typeface.MONOSPACE);
        log.setPadding(dp(14), dp(12), dp(14), dp(12));
        log.setBackground(Ui.round(this, Ui.CARD, 14));
        Ui.add(col, log, 12);
        actionButton(col, "Copy log", false, v -> copyLog());
        if (an != null) actionButton(col, "Back to options", true, v -> showOptions());
        else actionButton(col, "Back", true, v -> showHome());
        show(sv);
    }

    private void showDone() {
        screen = 3;
        ScrollView sv = new ScrollView(this);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(40), dp(18), dp(24));
        sv.addView(col);
        col.addView(Ui.text(this, "Patched", 30, Ui.GOOD, true));
        TextView sub = Ui.text(this, last.label + "  •  " + String.format(Locale.US, "%.1f MB", last.size / 1048576.0),
                14, Ui.SUB, false);
        sub.setPadding(0, dp(4), 0, dp(14));
        col.addView(sub);

        LinearLayout card = Ui.card(this);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.addView(Ui.text(this, "What changed", 13, Ui.SUB, true));
        if (last.applied.isEmpty()) {
            card.addView(Ui.text(this, "Nothing visible; the APK was only re-signed.", 14, Ui.TEXT, false));
        }
        for (String s : last.applied) {
            TextView t = Ui.text(this, "•  " + s, 14.5f, Ui.TEXT, false);
            t.setPadding(0, dp(6), 0, 0);
            card.addView(t);
        }
        col.addView(card, new LinearLayout.LayoutParams(MATCH, WRAP));

        actionButton(col, "Install", true, v -> install());
        actionButton(col, "Uninstall the original first", false, v -> uninstallOriginal());
        actionButton(col, "Save a copy...", false, v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/vnd.android.package-archive");
            i.putExtra(Intent.EXTRA_TITLE, safeName(last.label) + "_patched.apk");
            startActivityForResult(i, REQ_SAVE);
        });
        actionButton(col, "Share", false, v -> share());
        actionButton(col, "Change options and patch again", false, v -> showOptions());
        actionButton(col, "Start with another app", false, v -> showHome());
        actionButton(col, "Copy log", false, v -> copyLog());
        show(sv);
    }

    private void actionButton(LinearLayout col, String text, boolean primary, View.OnClickListener l) {
        Button b = Ui.button(this, text, primary);
        b.setOnClickListener(l);
        Ui.add(col, b, 10);
    }

    // ---- actions on the finished APK ----------------------------------------------------------

    private Uri apkUri() {
        return FileProvider.getUriForFile(this, getPackageName() + ".files", last.apk);
    }

    private void install() {
        if (!getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Allow \"Install unknown apps\" for Live Editor, then tap Install again",
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(apkUri(), "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }

    private void uninstallOriginal() {
        startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + last.packageName)));
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_STREAM, apkUri());
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share APK"));
    }

    private void saveCopy(final Uri to) {
        final File src = last.apk;
        new Thread(() -> {
            try {
                OutputStream os = getContentResolver().openOutputStream(to);
                if (os == null) throw new IOException("Cannot write there");
                InputStream is = new FileInputStream(src);
                try {
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                } finally {
                    is.close();
                    os.close();
                }
                runOnUiThread(() -> Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show());
            } catch (final Throwable t) {
                runOnUiThread(() -> Toast.makeText(this, "Could not save: " + t.getMessage(),
                        Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private String logSnapshot() {
        synchronized (logText) {
            return logText.toString();
        }
    }

    private void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("Live Editor log", logSnapshot()));
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show();
        }
    }

    private static String safeName(String s) {
        String n = s == null ? "app" : s.replaceAll("[^A-Za-z0-9._-]+", "_");
        return n.length() == 0 ? "app" : n;
    }
}
