package com.liveedit.patcher;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Builds one plain-text report of an APK (structure, manifest, resources, code) so it can be shared and read. */
final class NixuExport {

    interface Source {
        List<NixuZip.E> list();

        byte[] read(String name) throws IOException;

        boolean changed(String name);
    }

    static final class Options {
        boolean entries = true;
        boolean manifest = true;
        boolean arsc = true;
        boolean dexClasses = true;
        boolean dexMethods = false;
        /** Class-name filter (dotted or slashed, case-insensitive) for full smali text; null = no smali. */
        String smaliFilter;
        int arscLimit = 4000;
    }

    private NixuExport() {}

    static String size(long n) {
        if (n < 1024) return n + "B";
        if (n < 1048576) return String.format(Locale.US, "%.2fK", n / 1024.0);
        return String.format(Locale.US, "%.2fM", n / 1048576.0);
    }

    static String build(Source src, Options o, String title) {
        StringBuilder sb = new StringBuilder(1 << 16);
        sb.append("# nixu cn export\n# ").append(title).append("\n\n");
        List<NixuZip.E> es = src.list();
        List<String> dexNames = new ArrayList<String>();
        for (NixuZip.E e : es) {
            if (e.name.matches("classes\\d*\\.dex")) dexNames.add(e.name);
        }
        if (o.entries) {
            sb.append("=== FILES (").append(es.size()).append(" entries, nothing hidden) ===\n");
            sb.append("path | size | packed | method | crc | flags\n");
            for (NixuZip.E e : es) {
                sb.append(e.name).append(" | ").append(e.size).append(" | ").append(e.compSize).append(" | ")
                        .append(e.method == 0 ? "stored" : e.method == 8 ? "deflate" : "method" + e.method)
                        .append(" | ").append(String.format(Locale.US, "%08x", e.crc)).append(" | ")
                        .append(String.format(Locale.US, "0x%04x", e.flags));
                if ((e.flags & 1) != 0) sb.append(" ENCRYPTED-FLAG");
                if (src.changed(e.name)) sb.append(" CHANGED");
                sb.append('\n');
            }
            sb.append('\n');
        }
        if (o.manifest) {
            sb.append("=== AndroidManifest.xml ===\n");
            try {
                byte[] m = src.read("AndroidManifest.xml");
                if (m == null) sb.append("(not found)\n");
                else if (NixuAxml.isBinary(m)) sb.append(NixuAxml.toXml(m));
                else sb.append(new String(m, "UTF-8"));
            } catch (Exception e) {
                sb.append("(cannot read: ").append(e.getMessage()).append(")\n");
            }
            sb.append('\n');
        }
        if (o.arsc) {
            sb.append("=== resources.arsc ===\n");
            try {
                byte[] a = src.read("resources.arsc");
                if (a == null) sb.append("(not found)\n");
                else NixuArsc.parse(a).dump(sb, o.arscLimit);
            } catch (Exception e) {
                sb.append("(cannot read: ").append(e.getMessage()).append(")\n");
            }
            sb.append('\n');
        }
        if (o.dexClasses || o.dexMethods || o.smaliFilter != null) {
            for (String dn : dexNames) {
                sb.append("=== ").append(dn).append(" ===\n");
                try {
                    NixuDex dex = NixuDex.parse(src.read(dn));
                    sb.append(dex.summary()).append('\n');
                    String f = o.smaliFilter == null ? null : o.smaliFilter.toLowerCase(Locale.US).replace('.', '/');
                    for (int i = 0; i < dex.classCount; i++) {
                        String cn = dex.className(i);
                        boolean wantSmali = f != null && cn.toLowerCase(Locale.US).contains(f);
                        if (wantSmali) {
                            NixuDex.ClassInfo ci = dex.classInfo(i);
                            sb.append("\n# ---- ").append(cn).append(" ----\n");
                            dex.smali(ci, sb);
                            continue;
                        }
                        if (!o.dexClasses && !o.dexMethods) continue;
                        if (f != null && !o.dexClasses) continue;
                        sb.append(cn);
                        if (o.dexMethods) {
                            NixuDex.ClassInfo ci = dex.classInfo(i);
                            sb.append("  (").append(ci.fields.size()).append(" fields, ").append(ci.methods.size()).append(" methods)\n");
                            for (NixuDex.Method m : ci.methods) {
                                sb.append("    ").append(NixuDex.flags(m.access, true, false)).append(dex.methodName(m.idx))
                                        .append(dex.methodProto(m.idx)).append('\n');
                            }
                        } else {
                            sb.append('\n');
                        }
                    }
                } catch (Exception e) {
                    sb.append("(cannot read: ").append(e.getMessage()).append(")\n");
                }
                sb.append('\n');
            }
        }
        return sb.toString();
    }
}
