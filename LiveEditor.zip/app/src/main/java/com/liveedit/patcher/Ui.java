package com.liveedit.patcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Small kit of ready-made views so the screens stay short and look the same everywhere. */
final class Ui {

    static final int BG = 0xFF0E1013;
    static final int CARD = 0xFF171A21;
    static final int CARD2 = 0xFF222733;
    static final int LINE = 0xFF2A2F3A;
    static final int TEXT = 0xFFECEFF4;
    static final int SUB = 0xFF9AA3B2;
    static final int ACCENT = 0xFF7C5CFF;
    static final int GOOD = 0xFF34D399;
    static final int WARN = 0xFFFBBF24;
    static final int BAD = 0xFFF87171;

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static Drawable ripple(Context c, int color, float radiusDp) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), round(c, color, radiusDp),
                round(c, Color.WHITE, radiusDp));
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(round(c, CARD, 16));
        l.setPadding(dp(c, 16), dp(c, 6), dp(c, 16), dp(c, 6));
        return l;
    }

    /** Adds the view full width with a gap above it. */
    static void add(LinearLayout parent, View v, float topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(parent.getContext(), topDp);
        parent.addView(v, lp);
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, Math.max(1, dp(c, 1))));
        return v;
    }

    static TextView section(Context c, String s) {
        TextView t = text(c, s.toUpperCase(Locale.US), 12, ACCENT, true);
        t.setLetterSpacing(0.08f);
        t.setPadding(dp(c, 4), dp(c, 22), 0, dp(c, 8));
        return t;
    }

    static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(primary ? Color.WHITE : TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setBackground(ripple(c, primary ? ACCENT : CARD2, 14));
        b.setPadding(dp(c, 18), dp(c, 12), dp(c, 18), dp(c, 12));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    static TextView chip(Context c, String s) {
        TextView t = text(c, s, 13.5f, TEXT, false);
        t.setBackground(ripple(c, CARD2, 20));
        t.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
        t.setClickable(true);
        return t;
    }

    static EditText edit(Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(0xFF6B7385);
        e.setTextColor(TEXT);
        e.setTextSize(14.5f);
        e.setSingleLine(true);
        e.setBackground(round(c, CARD2, 10));
        e.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        return e;
    }

    interface OnText {
        void on(String s);
    }

    static void onText(EditText e, final OnText cb) {
        e.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void afterTextChanged(Editable e) {
                cb.on(e.toString());
            }
        });
    }

    static AlertDialog.Builder dialog(Context c) {
        return new AlertDialog.Builder(c, android.R.style.Theme_Material_Dialog_Alert);
    }

    static void info(Activity a, String title, String msg) {
        AlertDialog d = dialog(a).setTitle(title).setMessage(msg).setPositiveButton("OK", null).create();
        d.getWindow().setBackgroundDrawable(round(a, CARD, 18));
        d.show();
    }

    // ---- searchable list dialog ----------------------------------------------------------------

    static final class Item {
        final String key;
        final String title;
        final String sub;
        final Drawable icon;

        Item(String key, String title, String sub, Drawable icon) {
            this.key = key;
            this.title = title;
            this.sub = sub == null ? "" : sub;
            this.icon = icon;
        }
    }

    interface Pick {
        void on(Item it);
    }

    /**
     * @param selected  set to tick several items (changed in place, "done" runs when the dialog closes);
     *                  null to pick a single item (then "single" is called)
     */
    static void list(final Activity a, String title, final List<Item> all, final Set<String> selected,
                     final Pick single, final Runnable done) {
        final boolean multi = selected != null;
        final LinearLayout col = vbox(a);
        col.setPadding(dp(a, 16), dp(a, 4), dp(a, 16), 0);

        final EditText search = edit(a, "Search");
        col.addView(search, new LinearLayout.LayoutParams(MATCH, WRAP));

        final ArrayList<Item> shown = new ArrayList<Item>(all);
        final ListView lv = new ListView(a);
        lv.setDivider(null);

        final BaseAdapter ad = new BaseAdapter() {
            @Override
            public int getCount() {
                return shown.size();
            }

            @Override
            public Object getItem(int i) {
                return shown.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View cv, ViewGroup parent) {
                Item it = shown.get(i);
                LinearLayout row = hbox(a);
                row.setPadding(0, dp(a, 9), 0, dp(a, 9));
                if (it.icon != null) {
                    ImageView iv = new ImageView(a);
                    iv.setImageDrawable(it.icon);
                    LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(a, 38), dp(a, 38));
                    ilp.rightMargin = dp(a, 12);
                    row.addView(iv, ilp);
                }
                LinearLayout tx = vbox(a);
                tx.addView(text(a, it.title, 15, TEXT, false));
                if (it.sub.length() > 0) tx.addView(text(a, it.sub, 12, SUB, false));
                row.addView(tx, new LinearLayout.LayoutParams(0, WRAP, 1f));
                if (multi) {
                    CheckBox cb = new CheckBox(a);
                    cb.setChecked(selected.contains(it.key));
                    cb.setClickable(false);
                    cb.setFocusable(false);
                    row.addView(cb);
                }
                return row;
            }
        };
        lv.setAdapter(ad);

        if (multi) {
            LinearLayout bar = hbox(a);
            TextView all1 = chip(a, "Tick all shown");
            TextView none = chip(a, "Clear all");
            all1.setOnClickListener(v -> {
                for (Item it : shown) selected.add(it.key);
                ad.notifyDataSetChanged();
            });
            none.setOnClickListener(v -> {
                selected.clear();
                ad.notifyDataSetChanged();
            });
            LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(WRAP, WRAP);
            l1.rightMargin = dp(a, 8);
            bar.addView(all1, l1);
            bar.addView(none, new LinearLayout.LayoutParams(WRAP, WRAP));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(MATCH, WRAP);
            bl.topMargin = dp(a, 8);
            col.addView(bar, bl);
        }
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(MATCH, dp(a, 340));
        ll.topMargin = dp(a, 6);
        col.addView(lv, ll);

        AlertDialog.Builder b = dialog(a).setTitle(title).setView(col);
        if (multi) b.setPositiveButton("Done", null);
        else b.setNegativeButton("Cancel", null);
        final AlertDialog dlg = b.create();
        dlg.getWindow().setBackgroundDrawable(round(a, CARD, 18));

        lv.setOnItemClickListener((p, v, pos, id) -> {
            Item it = shown.get(pos);
            if (multi) {
                if (!selected.remove(it.key)) selected.add(it.key);
                ad.notifyDataSetChanged();
            } else {
                dlg.dismiss();
                if (single != null) single.on(it);
            }
        });
        onText(search, s -> {
            String q = s.trim().toLowerCase(Locale.US);
            shown.clear();
            for (Item it : all) {
                if (q.length() == 0 || it.title.toLowerCase(Locale.US).contains(q)
                        || it.sub.toLowerCase(Locale.US).contains(q)) {
                    shown.add(it);
                }
            }
            ad.notifyDataSetChanged();
        });
        if (multi) {
            dlg.setOnDismissListener(d -> {
                if (done != null) done.run();
            });
        }
        dlg.show();
    }
}
