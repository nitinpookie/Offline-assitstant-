package com.liveedit.patcher;

/** Ready-made lists used by the one-tap options. */
final class Presets {

    private Presets() {}

    /** Ad networks. A host here also blocks every sub-domain of it. */
    static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "admob.com", "applovin.com", "applvn.com", "unityads.unity3d.com", "mopub.com", "ironsrc.com",
            "ironsrc.mobi", "supersonicads.com", "vungle.com", "chartboost.com", "adcolony.com", "inmobi.com",
            "startapp.com", "smaato.net", "pangleglobal.com", "pangle.io", "an.facebook.com", "mintegral.com",
            "rayjump.com", "tapjoy.com", "fyber.com", "digitalturbine.com", "bidmachine.io", "criteo.com",
            "taboola.com", "outbrain.com", "adnxs.com", "rubiconproject.com", "pubmatic.com", "openx.net",
            "casalemedia.com", "smartadserver.com", "amazon-adsystem.com", "adsrvr.org", "moatads.com"
    };

    /** Analytics, attribution and crash-report servers. */
    static final String[] TRACKER_HOSTS = {
            "app-measurement.com", "google-analytics.com", "crashlytics.com", "flurry.com", "appsflyer.com",
            "adjust.com", "adjust.io", "branch.io", "mixpanel.com", "amplitude.com", "segment.io", "segment.com",
            "bugsnag.com", "scorecardresearch.com", "singular.net", "kochava.com", "tenjin.io", "mparticle.com"
    };

    /** Permissions that most people call "private": location, contacts, calls, SMS, camera, microphone, storage. */
    static final String[] PRIVATE_PERMS = {
            "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION", "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS", "android.permission.GET_ACCOUNTS",
            "android.permission.READ_CALL_LOG", "android.permission.WRITE_CALL_LOG",
            "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS",
            "android.permission.READ_PHONE_STATE", "android.permission.READ_PHONE_NUMBERS",
            "android.permission.RECORD_AUDIO", "android.permission.CAMERA",
            "android.permission.READ_CALENDAR", "android.permission.WRITE_CALENDAR",
            "android.permission.BODY_SENSORS", "android.permission.ACTIVITY_RECOGNITION"
    };

    /** Friendly name for the permission list. */
    static String niceName(String perm) {
        String n = perm;
        int dot = n.lastIndexOf('.');
        if (dot >= 0) n = n.substring(dot + 1);
        return n.replace('_', ' ').toLowerCase(java.util.Locale.US);
    }
}
