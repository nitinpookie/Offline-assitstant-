package com.liveedit.patcher;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.graphics.drawable.Drawable;

import com.android.apksig.ApkSigner;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** The whole job: look inside an APK (analyze), then apply the chosen options, sign and check it (run). */
final class Patcher {

    interface Log {
        void line(String s);

        void progress(int percent);
    }

    /** What we learned about the picked APK. */
    static final class Analysis {
        File apk;
        long size;
        String label;
        Drawable icon;
        Axml.Info info;
        ApkScan.Result scan;
        boolean alreadyPatched;
        boolean split;
    }

    static final class Result {
        File apk;
        String packageName;
        String label;
        long size;
        final List<String> applied = new ArrayList<String>();
    }

    static final String PROVIDER = "com.liveedit.agent.AgentProvider";

    private Patcher() {}

    // =======================================================================================
    // analyze
    // =======================================================================================

    static Analysis analyze(Context ctx, File apk) throws Exception {
        Analysis a = new Analysis();
        a.apk = apk;
        a.size = apk.length();
        byte[] man = ZipPatcher.readEntry(apk, "AndroidManifest.xml");
        if (man == null) {
            throw new IOException("No AndroidManifest.xml inside. If this is an XAPK/APKS/bundle, "
                    + "pick the single base APK instead.");
        }
        Axml x = Axml.parse(man);
        a.info = x.info();
        a.alreadyPatched = x.hasString(PROVIDER);
        a.scan = ApkScan.scan(apk);
        if (a.scan.dexCount == 0) {
            throw new IOException("This APK has no code inside (common for pre-installed system apps). "
                    + "It cannot be patched.");
        }
        PackageManager pm = ctx.getPackageManager();
        try {
            PackageInfo pi = pm.getPackageArchiveInfo(apk.getAbsolutePath(), 0);
            if (pi != null && pi.applicationInfo != null) {
                ApplicationInfo ai = pi.applicationInfo;
                ai.sourceDir = apk.getAbsolutePath();
                ai.publicSourceDir = apk.getAbsolutePath();
                a.label = String.valueOf(ai.loadLabel(pm));
                a.icon = ai.loadIcon(pm);
            }
        } catch (Throwable t) {
            // name and icon are only for display
        }
        if (a.label == null || a.label.length() == 0) a.label = a.info.pkg != null ? a.info.pkg : "App";
        return a;
    }

    // =======================================================================================
    // run
    // =======================================================================================

    static Result run(Context ctx, Analysis an, Opts o, Log log) throws Exception {
        selfCheck();
        File outDir = new File(ctx.getCacheDir(), "out");
        deleteTree(outDir);
        if (!outDir.mkdirs()) throw new IOException("Cannot create cache folder (storage full?)");
        Result res = new Result();
        res.label = o.appName.trim().length() > 0 ? o.appName.trim() : an.label;

        log.progress(5);
        log.line("1/6 Reading the app manifest...");
        Axml x = Axml.parse(ZipPatcher.readEntry(an.apk, "AndroidManifest.xml"));
        String pkg = x.packageName();
        if (pkg == null) throw new IOException("package name not found in manifest");
        res.packageName = pkg;
        log.line("    package: " + pkg);

        log.progress(15);
        log.line("2/6 Applying your options to the manifest...");
        if (!o.removePerms.isEmpty()) {
            int n = x.removePermissions(o.removePerms);
            res.applied.add("Removed " + n + " permission" + (n == 1 ? "" : "s"));
        }
        if (!o.disableComps.isEmpty()) {
            int n = x.disableComponents(o.disableComps);
            res.applied.add("Disabled " + n + " part" + (n == 1 ? "" : "s") + " of the app");
        }
        if (o.orientation != 0) {
            int[] map = {0, 1, 0, 10, -1};
            x.setOrientation(map[o.orientation]);
            String[] nm = {"", "Locked to portrait", "Locked to landscape", "Auto-rotate always", "Rotation follows phone setting"};
            res.applied.add(nm[o.orientation]);
        }
        if (o.debuggable != 0) {
            x.setAppBool("debuggable", Axml.A_DEBUGGABLE, o.debuggable == 1);
            res.applied.add("Debuggable " + (o.debuggable == 1 ? "on" : "off"));
        }
        if (o.backup != 0) {
            x.setAppBool("allowBackup", Axml.A_ALLOW_BACKUP, o.backup == 1);
            res.applied.add("Backup " + (o.backup == 1 ? "allowed" : "blocked"));
        }
        if (o.cleartext != 0) {
            x.setAppBool("usesCleartextTraffic", Axml.A_CLEARTEXT, o.cleartext == 1);
            res.applied.add("Plain HTTP " + (o.cleartext == 1 ? "allowed" : "blocked"));
        }
        if (o.largeHeap != 0) {
            x.setAppBool("largeHeap", Axml.A_LARGE_HEAP, o.largeHeap == 1);
            res.applied.add("Large memory heap " + (o.largeHeap == 1 ? "on" : "off"));
        }
        if (o.appName.trim().length() > 0) {
            x.setLabel(o.appName.trim());
            res.applied.add("App name: " + o.appName.trim());
        }
        Integer code = null;
        String vname = null;
        if (o.versionCode.trim().length() > 0) {
            try {
                code = Integer.valueOf(Integer.parseInt(o.versionCode.trim()));
            } catch (NumberFormatException e) {
                throw new IOException("Version code must be a whole number (got \"" + o.versionCode.trim() + "\")");
            }
        }
        if (o.versionName.trim().length() > 0) vname = o.versionName.trim();
        if (code != null || vname != null) {
            x.setVersion(code, vname);
            res.applied.add("Version: " + (vname != null ? vname : "same") + (code != null ? " (" + code + ")" : ""));
        }

        log.progress(30);
        byte[] dex = null;
        Map<String, byte[]> extras = new LinkedHashMap<String, byte[]>();
        if (o.needsEngine()) {
            log.line("3/6 Adding the silent engine (no button, no menu)...");
            if (x.hasString(PROVIDER)) {
                throw new IOException("This APK already contains an older Live Editor. "
                        + "Pick the original app instead.");
            }
            x.addProvider(PROVIDER, pkg + ".liveeditagent");
            dex = readAsset(ctx, "agent.dex");
            extras.put("assets/liveedit_config.json", o.configJson().getBytes(StandardCharsets.UTF_8));
            describeEngine(o, res);
        } else {
            log.line("3/6 No engine needed for these options.");
        }

        log.progress(45);
        log.line("4/6 Rebuilding the APK...");
        ZipPatcher.Filter filter = null;
        if (o.keepAbi != null) {
            if (an.scan.abis.contains(o.keepAbi)) {
                final String keep = "lib/" + o.keepAbi + "/";
                filter = name -> name.startsWith("lib/") && !name.startsWith(keep);
                res.applied.add("Kept only " + o.keepAbi + " libraries");
            } else {
                log.line("    CPU filter skipped: " + o.keepAbi + " is not in this APK");
            }
        }
        File unsigned = new File(outDir, "unsigned.apk");
        ZipPatcher.Info info = ZipPatcher.rewrite(an.apk, unsigned, x.toBytes(), dex, extras, filter);
        log.line("    copied " + info.copied + " files, left out " + info.filtered + ", dropped "
                + info.dropped + " old signature/manifest entries"
                + (info.addedDex != null ? ", added " + info.addedDex : ""));

        log.progress(65);
        log.line("5/6 Signing...");
        File signed = new File(outDir, "patched.apk");
        sign(ctx, unsigned, signed);
        unsigned.delete();

        log.progress(85);
        log.line("6/6 Checking the result with Android itself...");
        PackageManager pm = ctx.getPackageManager();
        PackageInfo pi = pm.getPackageArchiveInfo(signed.getAbsolutePath(),
                PackageManager.GET_PROVIDERS | PackageManager.GET_PERMISSIONS);
        if (pi == null) {
            throw new IOException("Android cannot read the patched APK. "
                    + "The original app may use features this phone does not support.");
        }
        if (dex != null) {
            boolean found = false;
            if (pi.providers != null) {
                for (ProviderInfo p : pi.providers) {
                    if (PROVIDER.equals(p.name)) found = true;
                }
            }
            if (!found) throw new IOException("Android did not accept the engine entry in the manifest.");
        }
        if (!o.removePerms.isEmpty() && pi.requestedPermissions != null) {
            Set<String> left = new HashSet<String>();
            Collections.addAll(left, pi.requestedPermissions);
            for (String p : o.removePerms) {
                if (left.contains(p)) throw new IOException("Permission was not removed: " + p);
            }
        }
        res.apk = signed;
        res.size = signed.length();
        log.progress(100);
        log.line("Done: " + (res.size / 1024 / 1024) + " MB");
        return res;
    }

    private static void describeEngine(Opts o, Result res) {
        List<String> hosts = o.allHosts();
        if (!hosts.isEmpty()) res.applied.add("Blocked " + hosts.size() + " servers");
        if (o.hideAds) res.applied.add("Hides ad banners");
        if (o.scale != 100) res.applied.add("Overlay buttons size " + o.scale + "%");
        if (o.alpha != 100) res.applied.add("Overlay buttons opacity " + o.alpha + "%");
        if (o.mute) res.applied.add("Click sounds muted");
        if (o.keepOn) res.applied.add("Screen stays on");
        if (o.allowShot) res.applied.add("Screenshots allowed");
        if (o.immersive) res.applied.add("Fullscreen (bars hidden)");
        if (o.anim == 1) res.applied.add("Faster animations");
        if (o.anim == 2) res.applied.add("Animations off");
    }

    /** Makes sure the attribute numbers used by the manifest editor match this Android version's own list. */
    private static void selfCheck() throws IOException {
        String[] names = {"label", "name", "enabled", "debuggable", "exported", "authorities", "initOrder",
                "screenOrientation", "minSdkVersion", "versionCode", "versionName", "targetSdkVersion",
                "allowBackup", "largeHeap", "usesCleartextTraffic"};
        int[] mine = {Axml.A_LABEL, Axml.A_NAME, Axml.A_ENABLED, Axml.A_DEBUGGABLE, Axml.A_EXPORTED,
                Axml.A_AUTHORITIES, Axml.A_INIT_ORDER, Axml.A_ORIENTATION, Axml.A_MIN_SDK, Axml.A_VERSION_CODE,
                Axml.A_VERSION_NAME, Axml.A_TARGET_SDK, Axml.A_ALLOW_BACKUP, Axml.A_LARGE_HEAP, Axml.A_CLEARTEXT};
        try {
            Class<?> c = Class.forName("android.R$attr");
            for (int i = 0; i < names.length; i++) {
                int real;
                try {
                    real = c.getField(names[i]).getInt(null);
                } catch (NoSuchFieldException e) {
                    continue; // not public on this Android version: nothing to compare
                }
                if (real != mine[i]) {
                    throw new IOException("Internal attribute number mismatch for " + names[i]);
                }
            }
        } catch (ClassNotFoundException e) {
            // cannot check, carry on
        } catch (IllegalAccessException e) {
            // cannot check, carry on
        }
    }

    private static void sign(Context ctx, File in, File out) throws Exception {
        PrivateKey key = KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(readAsset(ctx, "key.pk8")));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(readAsset(ctx, "cert.der")));
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder(
                "liveeditor", key, Collections.singletonList(cert)).build();
        if (out.exists()) out.delete();
        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in)
                .setOutputApk(out)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(false)
                .build()
                .sign();
    }

    private static byte[] readAsset(Context ctx, String name) throws IOException {
        InputStream is = ctx.getAssets().open(name);
        try {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) o.write(buf, 0, n);
            return o.toByteArray();
        } finally {
            is.close();
        }
    }

    static void copy(InputStream is, File to) throws IOException {
        OutputStream os = new FileOutputStream(to);
        try {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        } finally {
            os.close();
            is.close();
        }
    }

    static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (int i = 0; i < kids.length; i++) deleteTree(kids[i]);
        }
        f.delete();
    }
}
