package com.liveedit.patcher;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Reads the code (classes.dex) of an APK without changing it and lists the places that start something after a
 * delay: Handler.postDelayed / sendMessageDelayed, Timer.schedule, scheduled executors and CountDownTimer.
 * The delay is a guess taken from the numbers loaded just before the call (milliseconds).
 */
final class TimerScan {

    private static final String[] SKIP = {
            "Landroidx/", "Landroid/", "Lcom/google/android/gms/", "Lcom/google/firebase/", "Lkotlin/", "Lkotlinx/",
            "Lokhttp3/", "Lokio/", "Lcom/squareup/", "Lcom/facebook/", "Lcom/bumptech/", "Lcom/unity3d/ads/",
            "Lcom/applovin/", "Lcom/ironsource/", "Lcom/vungle/", "Lcom/google/ads/", "Lcom/liveedit/"
    };

    private TimerScan() {}

    /** Appends findings of one dex file to out (at most 400 lines in total). */
    static void scan(byte[] dex, List<String> out) {
        try {
            if (dex.length < 0x70 || dex[0] != 'd' || dex[1] != 'e' || dex[2] != 'x') return;
            new Run(dex, out).go();
        } catch (Throwable t) {
            // a damaged or packed dex: nothing to list
        }
    }

    private static final class Run {
        final ByteBuffer b;
        final List<String> out;
        final int strings, strOff, types, typeOff, methods, methodOff, classes, classOff, protoOff;
        final int[] kind;
        final String[] cache;

        Run(byte[] d, List<String> out) {
            this.b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
            this.out = out;
            strings = b.getInt(0x38);
            strOff = b.getInt(0x3c);
            types = b.getInt(0x40);
            typeOff = b.getInt(0x44);
            protoOff = b.getInt(0x4c);
            methods = b.getInt(0x58);
            methodOff = b.getInt(0x5c);
            classes = b.getInt(0x60);
            classOff = b.getInt(0x64);
            kind = new int[Math.max(0, methods)];
            cache = new String[Math.max(0, strings)];
        }

        String str(int idx) {
            if (idx < 0 || idx >= strings) return "";
            if (cache[idx] != null) return cache[idx];
            int p = b.getInt(strOff + idx * 4);
            while ((b.get(p) & 0x80) != 0) p++; // skip the length (uleb128)
            p++;
            int e = p;
            while (e < b.limit() && b.get(e) != 0) e++;
            byte[] x = new byte[e - p];
            for (int i = 0; i < x.length; i++) x[i] = b.get(p + i);
            String s = new String(x, java.nio.charset.StandardCharsets.UTF_8);
            cache[idx] = s;
            return s;
        }

        String type(int idx) {
            if (idx < 0 || idx >= types) return "";
            return str(b.getInt(typeOff + idx * 4));
        }

        int uleb(int[] pos) {
            int r = 0, shift = 0;
            while (true) {
                int v = b.get(pos[0]++) & 0xFF;
                r |= (v & 0x7F) << shift;
                if ((v & 0x80) == 0) break;
                shift += 7;
                if (shift > 35) break;
            }
            return r;
        }

        void go() {
            for (int i = 0; i < methods; i++) {
                int o = methodOff + i * 8;
                String cls = type(b.getShort(o) & 0xFFFF);
                String name = str(b.getInt(o + 4));
                kind[i] = classify(cls, name);
            }
            for (int c = 0; c < classes && out.size() < 400; c++) {
                try {
                    oneClass(classOff + c * 32);
                } catch (Throwable t) {
                    // skip this class
                }
            }
        }

        int classify(String cls, String name) {
            if (cls.equals("Landroid/os/Handler;")) {
                if (name.equals("postDelayed") || name.equals("postAtTime")) return 1;
                if (name.equals("sendMessageDelayed") || name.equals("sendEmptyMessageDelayed")) return 4;
            }
            if (cls.equals("Ljava/util/Timer;") && name.equals("schedule")) return 2;
            if (cls.equals("Landroid/os/CountDownTimer;") && name.equals("<init>")) return 3;
            if (cls.equals("Ljava/util/concurrent/ScheduledExecutorService;")
                    && (name.equals("schedule") || name.startsWith("scheduleAt"))) return 5;
            return 0;
        }

        boolean skipped(String cls) {
            for (int i = 0; i < SKIP.length; i++) if (cls.startsWith(SKIP[i])) return true;
            return false;
        }

        String pretty(String d) {
            if (d.startsWith("L") && d.endsWith(";")) d = d.substring(1, d.length() - 1);
            return d.replace('/', '.');
        }

        void oneClass(int cd) {
            String cls = type(b.getInt(cd));
            if (skipped(cls)) return;
            String sup = type(b.getInt(cd + 8));
            if (sup.equals("Landroid/os/CountDownTimer;")) {
                add(pretty(cls) + ": is a CountDownTimer (counts down by itself, look at onTick / onFinish)");
            }
            int dataOff = b.getInt(cd + 24);
            if (dataOff == 0) return;
            int[] p = {dataOff};
            int sf = uleb(p), inf = uleb(p), dm = uleb(p), vm = uleb(p);
            for (int i = 0; i < sf + inf; i++) {
                uleb(p);
                uleb(p);
            }
            for (int pass = 0; pass < 2; pass++) {
                int n = pass == 0 ? dm : vm;
                int idx = 0;
                for (int i = 0; i < n; i++) {
                    idx += uleb(p);
                    uleb(p);
                    int code = uleb(p);
                    if (code != 0) method(cls, idx, code);
                }
            }
        }

        void method(String cls, int methodIdx, int code) {
            if (methodIdx < 0 || methodIdx >= methods) return;
            String mname = str(b.getInt(methodOff + methodIdx * 8 + 4));
            int size = b.getInt(code + 12);
            int base = code + 16;
            if (size <= 0 || base + size * 2 > b.limit()) return;
            long[] recent = new long[8];
            int rc = 0;
            int pc = 0;
            while (pc < size) {
                int u = b.getShort(base + pc * 2) & 0xFFFF;
                int op = u & 0xFF;
                int len = width(op, u, base, pc, size);
                if (len <= 0) return;
                long cv = Long.MIN_VALUE;
                switch (op) {
                    case 0x12: {
                        int v = (u >> 12) & 0xF;
                        cv = v > 7 ? v - 16 : v;
                        break;
                    }
                    case 0x13:
                    case 0x16:
                        cv = b.getShort(base + (pc + 1) * 2);
                        break;
                    case 0x14:
                    case 0x17:
                        cv = b.getInt(base + (pc + 1) * 2);
                        break;
                    case 0x15:
                        cv = (long) b.getShort(base + (pc + 1) * 2) << 16;
                        break;
                    case 0x18:
                        cv = b.getLong(base + (pc + 1) * 2);
                        break;
                    case 0x19:
                        cv = (long) b.getShort(base + (pc + 1) * 2) << 48;
                        break;
                    default:
                        break;
                }
                if (cv != Long.MIN_VALUE) {
                    recent[rc++ & 7] = cv;
                } else if ((op >= 0x6e && op <= 0x72) || (op >= 0x74 && op <= 0x78)) {
                    int mi = b.getShort(base + (pc + 1) * 2) & 0xFFFF;
                    if (mi < methods && kind[mi] != 0) report(cls, mname, kind[mi], recent);
                }
                pc += len;
            }
        }

        void report(String cls, String mname, int k, long[] recent) {
            String what = k == 1 ? "Handler.postDelayed" : k == 4 ? "Handler.sendMessageDelayed"
                    : k == 2 ? "Timer.schedule" : k == 3 ? "new CountDownTimer" : "scheduled task";
            StringBuilder ms = new StringBuilder();
            Set<Long> seen = new LinkedHashSet<Long>();
            for (int i = 0; i < 8; i++) {
                long v = recent[i];
                if (v >= 300 && v <= 3600000L && seen.add(Long.valueOf(v))) {
                    if (ms.length() > 0) ms.append(" / ");
                    ms.append(v);
                }
            }
            add(pretty(cls) + "." + mname + "(): " + what + (ms.length() > 0 ? " ~ " + ms + " ms" : " (delay not a fixed number)"));
        }

        void add(String s) {
            if (out.size() < 400 && !out.contains(s)) out.add(s);
        }

        /** Length in 16-bit units of the instruction at pc, 0 when it cannot be read. */
        int width(int op, int u, int base, int pc, int size) {
            if (op == 0x00) {
                if (u == 0) return 1;
                int rest = size - pc;
                if (rest < 2) return 0;
                if (u == 0x0100) return b.getShort(base + (pc + 1) * 2) * 2 + 4;
                if (u == 0x0200) return b.getShort(base + (pc + 1) * 2) * 4 + 2;
                if (u == 0x0300) {
                    int w = b.getShort(base + (pc + 1) * 2) & 0xFFFF;
                    long n = b.getInt(base + (pc + 2) * 2) & 0xFFFFFFFFL;
                    return (int) ((w * n + 1) / 2 + 4);
                }
                return 1;
            }
            if (op <= 0x01) return 1;
            if (op == 0x02 || op == 0x05 || op == 0x08) return 2;
            if (op == 0x03 || op == 0x06 || op == 0x09) return 3;
            if (op <= 0x11) return 1;
            if (op == 0x12) return 1;
            if (op == 0x13 || op == 0x15 || op == 0x16 || op == 0x19) return 2;
            if (op == 0x14 || op == 0x17) return 3;
            if (op == 0x18) return 5;
            if (op == 0x1a || op == 0x1c || op == 0x1f || op == 0x20 || op == 0x22 || op == 0x23) return 2;
            if (op == 0x1b || op == 0x24 || op == 0x25 || op == 0x26) return 3;
            if (op == 0x1d || op == 0x1e || op == 0x21 || op == 0x27 || op == 0x28) return 1;
            if (op == 0x29) return 2;
            if (op == 0x2a || op == 0x2b || op == 0x2c) return 3;
            if (op >= 0x2d && op <= 0x3d) return 2;
            if (op >= 0x3e && op <= 0x43) return 1;
            if (op >= 0x44 && op <= 0x6d) return 2;
            if ((op >= 0x6e && op <= 0x72) || (op >= 0x74 && op <= 0x78)) return 3;
            if (op == 0x73 || op == 0x79 || op == 0x7a) return 1;
            if (op >= 0x7b && op <= 0x8f) return 1;
            if (op >= 0x90 && op <= 0xaf) return 2;
            if (op >= 0xb0 && op <= 0xcf) return 1;
            if (op >= 0xd0 && op <= 0xe2) return 2;
            if (op == 0xfa || op == 0xfb) return 4;
            if (op == 0xfc || op == 0xfd) return 3;
            if (op == 0xfe || op == 0xff) return 2;
            return 1;
        }
    }

    static List<String> sorted(List<String> in) {
        ArrayList<String> out = new ArrayList<String>(in);
        // lines with a 1-10 second delay first: those are the usual "turns off by itself" timers
        java.util.Collections.sort(out, new java.util.Comparator<String>() {
            @Override
            public int compare(String a, String c) {
                return rank(a) - rank(c);
            }
        });
        return out;
    }

    private static int rank(String s) {
        int i = s.indexOf("~ ");
        if (i < 0) return s.contains("CountDownTimer") ? 1 : 3;
        try {
            int j = s.indexOf(' ', i + 2);
            long v = Long.parseLong(s.substring(i + 2, j));
            return (v >= 1000 && v <= 10000) ? 0 : 2;
        } catch (Throwable t) {
            return 3;
        }
    }
}
