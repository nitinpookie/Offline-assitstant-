package com.liveedit.patcher;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Everything the user can choose before patching. Plain values, so the screen can read and write them freely. */
final class Opts {

    // ---- app identity (empty text = keep the original) --------------------------------------
    String appName = "";
    String versionName = "";
    String versionCode = "";

    // ---- permissions and parts of the app ---------------------------------------------------
    final Set<String> removePerms = new LinkedHashSet<String>();
    final Set<String> disableComps = new LinkedHashSet<String>();

    // ---- screen and system flags (manifest) -------------------------------------------------
    /** 0 keep, 1 portrait, 2 landscape, 3 auto-rotate always, 4 follow phone setting. */
    int orientation;
    /** 0 keep, 1 on, 2 off. */
    int debuggable;
    int backup;
    int cleartext;
    int largeHeap;

    // ---- APK size ---------------------------------------------------------------------------
    /** Only this CPU type stays in the APK. Null keeps all. */
    String keepAbi;

    // ---- engine inside the app (no screen, just carries these out) ----------------------------
    int scale = 100;
    int alpha = 100;
    boolean mute;
    boolean keepOn;
    boolean allowShot;
    boolean immersive;
    boolean hideAds;
    /** 0 normal, 1 faster, 2 off. */
    int anim;
    boolean blockAds;
    boolean blockTrackers;
    final Set<String> blockHosts = new LinkedHashSet<String>();
    String customHosts = "";

    void reset() {
        appName = "";
        versionName = "";
        versionCode = "";
        removePerms.clear();
        disableComps.clear();
        orientation = 0;
        debuggable = 0;
        backup = 0;
        cleartext = 0;
        largeHeap = 0;
        keepAbi = null;
        scale = 100;
        alpha = 100;
        mute = false;
        keepOn = false;
        allowShot = false;
        immersive = false;
        hideAds = false;
        anim = 0;
        blockAds = false;
        blockTrackers = false;
        blockHosts.clear();
        customHosts = "";
    }

    /** Every server the engine must keep the app away from (clean names, no duplicates). */
    List<String> allHosts() {
        LinkedHashSet<String> out = new LinkedHashSet<String>();
        if (blockAds) for (String h : Presets.AD_HOSTS) out.add(h);
        if (blockTrackers) for (String h : Presets.TRACKER_HOSTS) out.add(h);
        for (String h : blockHosts) addHost(out, h);
        for (String h : customHosts.split("[,;\\s]+")) addHost(out, h);
        return new ArrayList<String>(out);
    }

    private static void addHost(Set<String> out, String raw) {
        String h = cleanHost(raw);
        if (h.length() > 3 && h.indexOf('.') > 0) out.add(h);
    }

    static String cleanHost(String s) {
        String h = s == null ? "" : s.trim().toLowerCase(Locale.US);
        int p = h.indexOf("://");
        if (p >= 0) h = h.substring(p + 3);
        int slash = h.indexOf('/');
        if (slash >= 0) h = h.substring(0, slash);
        int colon = h.indexOf(':');
        if (colon >= 0) h = h.substring(0, colon);
        while (h.startsWith("*") || h.startsWith(".")) h = h.substring(1);
        return h;
    }

    boolean needsEngine() {
        return scale != 100 || alpha != 100 || mute || keepOn || allowShot || immersive || hideAds
                || anim != 0 || !allHosts().isEmpty();
    }

    /** The file that is baked into the APK for the engine to read. */
    String configJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("v", 2);
        o.put("scale", scale);
        o.put("alpha", alpha);
        o.put("mute", mute);
        o.put("keepOn", keepOn);
        o.put("allowShot", allowShot);
        o.put("immersive", immersive);
        o.put("hideAds", hideAds);
        o.put("anim", anim);
        JSONArray a = new JSONArray();
        for (String h : allHosts()) a.put(h);
        o.put("block", a);
        return o.toString(2);
    }

    /** How many separate choices are different from "keep original". Shown on the Patch button. */
    int changeCount() {
        int n = 0;
        if (appName.trim().length() > 0) n++;
        if (versionName.trim().length() > 0) n++;
        if (versionCode.trim().length() > 0) n++;
        if (!removePerms.isEmpty()) n++;
        if (!disableComps.isEmpty()) n++;
        if (orientation != 0) n++;
        if (debuggable != 0) n++;
        if (backup != 0) n++;
        if (cleartext != 0) n++;
        if (largeHeap != 0) n++;
        if (keepAbi != null) n++;
        if (scale != 100) n++;
        if (alpha != 100) n++;
        if (mute) n++;
        if (keepOn) n++;
        if (allowShot) n++;
        if (immersive) n++;
        if (hideAds) n++;
        if (anim != 0) n++;
        if (blockAds) n++;
        if (blockTrackers) n++;
        if (!blockHosts.isEmpty() || customHosts.trim().length() > 0) n++;
        return n;
    }
}
