package com.liveedit.patcher;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Everything the user can choose before patching. Plain values, so the screen can read and write them freely. */
final class Opts {

    // ---- app identity (empty text = keep the original) --------------------------------------
    String appName = "";
    String versionName = "";
    String versionCode = "";

    // ---- permissions and parts of the app ---------------------------------------------------
    final Set<String> removePerms = new LinkedHashSet<String>();
    final Set<String> disableComps = new LinkedHashSet<String>();

    // ---- screen and system flags (manifest) -------------------------------------------------
    /** 0 keep, 1 portrait, 2 landscape, 3 auto-rotate always, 4 follow phone setting. */
    int orientation;
    /** 0 keep, 1 on, 2 off. */
    int debuggable;
    int backup;
    int cleartext;
    int largeHeap;

    // ---- APK size ---------------------------------------------------------------------------
    /** Only this CPU type stays in the APK. Null keeps all. */
    String keepAbi;
    /** Rebuild the zip cleanly (fake-encryption flags, wrong sizes) so tools like MT Manager can open every file. */
    boolean normalize;
    /** Best effort: let an app run on this phone although none of its native libraries fit the phone's CPU. */
    boolean armCompat;
    /** Set while patching (never by the screen): the engine keeps the app alive when a native library is missing. */
    boolean guard;

    // ---- engine inside the app (no screen, just carries these out) ----------------------------
    /** Live Editor (pencil handle) inside the patched app. */
    boolean live;
    /** Small floating buttons / icons: width in dp (0 = keep), opacity percent, text size dp (0 = keep). */
    int btnDp;
    int btnAlpha = 100;
    int btnText;
    /** Menu panels, same meaning. */
    int menuDp;
    int menuAlpha = 100;
    int menuText;
    /** 0 keep, 1 block links at app start, 2 block all links that leave the app. */
    int links;
    /** 0 keep, 1 hide timer texts, 2 replace timer texts. */
    int timers;
    String timerText = "";
    boolean themeOn;
    int themeBg = 0xFF101418;
    int themeText = 0xFFECEFF4;
    int themeAccent = 0xFF7C5CFF;
    /** Per-item rules made in the live editor (JSON array text). */
    String rules = "[]";
    boolean mute;
    boolean keepOn;
    boolean allowShot;
    boolean immersive;
    boolean hideAds;
    /** 0 normal, 1 faster, 2 off. */
    int anim;
    boolean blockAds;
    boolean blockTrackers;
    final Set<String> blockHosts = new LinkedHashSet<String>();
    String customHosts = "";

    void reset() {
        appName = "";
        versionName = "";
        versionCode = "";
        removePerms.clear();
        disableComps.clear();
        orientation = 0;
        debuggable = 0;
        backup = 0;
        cleartext = 0;
        largeHeap = 0;
        keepAbi = null;
        normalize = false;
        armCompat = false;
        guard = false;
        live = false;
        btnDp = 0;
        btnAlpha = 100;
        btnText = 0;
        menuDp = 0;
        menuAlpha = 100;
        menuText = 0;
        links = 0;
        timers = 0;
        timerText = "";
        themeOn = false;
        themeBg = 0xFF101418;
        themeText = 0xFFECEFF4;
        themeAccent = 0xFF7C5CFF;
        rules = "[]";
        mute = false;
        keepOn = false;
        allowShot = false;
        immersive = false;
        hideAds = false;
        anim = 0;
        blockAds = false;
        blockTrackers = false;
        blockHosts.clear();
        customHosts = "";
    }

    /** Every server the engine must keep the app away from (clean names, no duplicates). */
    List<String> allHosts() {
        LinkedHashSet<String> out = new LinkedHashSet<String>();
        if (blockAds) for (String h : Presets.AD_HOSTS) out.add(h);
        if (blockTrackers) for (String h : Presets.TRACKER_HOSTS) out.add(h);
        for (String h : blockHosts) addHost(out, h);
        for (String h : customHosts.split("[,;\\s]+")) addHost(out, h);
        return new ArrayList<String>(out);
    }

    private static void addHost(Set<String> out, String raw) {
        String h = cleanHost(raw);
        if (h.length() > 3 && h.indexOf('.') > 0) out.add(h);
    }

    static String cleanHost(String s) {
        String h = s == null ? "" : s.trim().toLowerCase(Locale.US);
        int p = h.indexOf("://");
        if (p >= 0) h = h.substring(p + 3);
        int slash = h.indexOf('/');
        if (slash >= 0) h = h.substring(0, slash);
        int colon = h.indexOf(':');
        if (colon >= 0) h = h.substring(0, colon);
        while (h.startsWith("*") || h.startsWith(".")) h = h.substring(1);
        return h;
    }

    boolean lookChanged() {
        return btnDp != 0 || btnAlpha != 100 || btnText != 0 || menuDp != 0 || menuAlpha != 100 || menuText != 0;
    }

    int ruleCount() {
        try {
            return new JSONArray(rules).length();
        } catch (Exception e) {
            return 0;
        }
    }

    boolean needsEngine() {
        return live || lookChanged() || links != 0 || timers != 0 || themeOn || ruleCount() > 0
                || mute || keepOn || allowShot || immersive || hideAds || anim != 0 || !allHosts().isEmpty() || guard;
    }

    static String hexOf(int c) {
        return String.format(Locale.US, "#%06X", c & 0xFFFFFF);
    }

    /** "#RRGGBB" or "RRGGBB"; anything else keeps the old colour. */
    static int hex(String s, int old) {
        try {
            String t = s.trim();
            if (t.startsWith("#")) t = t.substring(1);
            if (t.length() != 6) return old;
            return 0xFF000000 | Integer.parseInt(t, 16);
        } catch (Exception e) {
            return old;
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Reads a settings text (from the live editor's "Copy settings" or from inside a live APK). */
    void importJson(String text) throws Exception {
        JSONObject o = new JSONObject(text.trim());
        live = o.optBoolean("live", live);
        btnDp = clamp(o.optInt("btnDp", btnDp), 0, 400);
        btnAlpha = clamp(o.optInt("btnAlpha", btnAlpha), 10, 100);
        btnText = clamp(o.optInt("btnText", btnText), 0, 100);
        menuDp = clamp(o.optInt("menuDp", menuDp), 0, 1200);
        menuAlpha = clamp(o.optInt("menuAlpha", menuAlpha), 10, 100);
        menuText = clamp(o.optInt("menuText", menuText), 0, 100);
        mute = o.optBoolean("mute", mute);
        keepOn = o.optBoolean("keepOn", keepOn);
        allowShot = o.optBoolean("allowShot", allowShot);
        immersive = o.optBoolean("immersive", immersive);
        hideAds = o.optBoolean("hideAds", hideAds);
        anim = clamp(o.optInt("anim", anim), 0, 2);
        links = clamp(o.optInt("links", links), 0, 2);
        timers = clamp(o.optInt("timers", timers), 0, 2);
        timerText = o.optString("timerText", timerText);
        JSONObject th = o.optJSONObject("theme");
        if (th != null) {
            themeOn = th.optBoolean("on", themeOn);
            themeBg = th.optInt("bg", themeBg) | 0xFF000000;
            themeText = th.optInt("text", themeText) | 0xFF000000;
            themeAccent = th.optInt("accent", themeAccent) | 0xFF000000;
        }
        JSONArray b = o.optJSONArray("block");
        if (b != null) {
            blockHosts.clear();
            for (int i = 0; i < b.length(); i++) {
                String h = cleanHost(b.optString(i, ""));
                if (h.length() > 3 && h.indexOf('.') > 0) blockHosts.add(h);
            }
        }
        JSONArray r = o.optJSONArray("rules");
        if (r != null) rules = r.toString();
    }

    /** The file that is baked into the APK for the engine to read. */
    String configJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("v", 3);
        o.put("live", live);
        o.put("btnDp", btnDp);
        o.put("btnAlpha", btnAlpha);
        o.put("btnText", btnText);
        o.put("menuDp", menuDp);
        o.put("menuAlpha", menuAlpha);
        o.put("menuText", menuText);
        o.put("links", links);
        o.put("timers", timers);
        o.put("timerText", timerText);
        o.put("guard", guard);
        JSONObject th = new JSONObject();
        th.put("on", themeOn);
        th.put("bg", themeBg);
        th.put("text", themeText);
        th.put("accent", themeAccent);
        o.put("theme", th);
        o.put("rules", new JSONArray(rules));
        o.put("mute", mute);
        o.put("keepOn", keepOn);
        o.put("allowShot", allowShot);
        o.put("immersive", immersive);
        o.put("hideAds", hideAds);
        o.put("anim", anim);
        JSONArray a = new JSONArray();
        for (String h : allHosts()) a.put(h);
        o.put("block", a);
        return o.toString(2);
    }

    /** How many separate choices are different from "keep original". Shown on the Patch button. */
    int changeCount() {
        int n = 0;
        if (appName.trim().length() > 0) n++;
        if (versionName.trim().length() > 0) n++;
        if (versionCode.trim().length() > 0) n++;
        if (!removePerms.isEmpty()) n++;
        if (!disableComps.isEmpty()) n++;
        if (orientation != 0) n++;
        if (debuggable != 0) n++;
        if (backup != 0) n++;
        if (cleartext != 0) n++;
        if (largeHeap != 0) n++;
        if (keepAbi != null) n++;
        if (normalize) n++;
        if (armCompat) n++;
        if (live) n++;
        if (btnDp != 0 || btnAlpha != 100 || btnText != 0) n++;
        if (menuDp != 0 || menuAlpha != 100 || menuText != 0) n++;
        if (links != 0) n++;
        if (timers != 0) n++;
        if (themeOn) n++;
        if (ruleCount() > 0) n++;
        if (mute) n++;
        if (keepOn) n++;
        if (allowShot) n++;
        if (immersive) n++;
        if (hideAds) n++;
        if (anim != 0) n++;
        if (blockAds) n++;
        if (blockTrackers) n++;
        if (!blockHosts.isEmpty() || customHosts.trim().length() > 0) n++;
        return n;
    }
}
