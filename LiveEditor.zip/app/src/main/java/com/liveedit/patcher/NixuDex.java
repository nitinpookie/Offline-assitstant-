package com.liveedit.patcher;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.Adler32;

/**
 * classes.dex reader and in-place editor.
 *
 *  - browse classes, fields, methods and the string pool
 *  - read the bytecode of a method as text (smali style, with the address of every instruction)
 *  - change one instruction (same size or smaller, the rest is filled with nop) with a small assembler
 *  - change a string (same size, shorter text is padded)
 *
 * Everything is patched inside the existing file, so no offset in the file moves. The checksum and the SHA-1 in
 * the header are recomputed after each change.
 */
final class NixuDex {

    // ---- opcode table ----------------------------------------------------------------------------------

    private static final int F10X = 0, F12X = 1, F11N = 2, F11X = 3, F10T = 4, F20T = 5, F22X = 6, F21T = 7, F21S = 8,
            F21H = 9, F21C = 10, F23X = 11, F22B = 12, F22T = 13, F22S = 14, F22C = 15, F30T = 16, F32X = 17,
            F31I = 18, F31T = 19, F31C = 20, F35C = 21, F3RC = 22, F45CC = 23, F4RCC = 24, F51L = 25;
    private static final int[] FSIZE = {1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 5};

    static final String[] OPNAME = new String[256];
    private static final int[] OPFMT = new int[256];
    private static final Map<String, Integer> OPBYNAME = new HashMap<String, Integer>();

    private static void op(int code, String name, int fmt) {
        OPNAME[code] = name;
        OPFMT[code] = fmt;
        OPBYNAME.put(name, Integer.valueOf(code));
    }

    static {
        for (int i = 0; i < 256; i++) OPFMT[i] = -1;
        op(0x00, "nop", F10X);
        op(0x01, "move", F12X);
        op(0x02, "move/from16", F22X);
        op(0x03, "move/16", F32X);
        op(0x04, "move-wide", F12X);
        op(0x05, "move-wide/from16", F22X);
        op(0x06, "move-wide/16", F32X);
        op(0x07, "move-object", F12X);
        op(0x08, "move-object/from16", F22X);
        op(0x09, "move-object/16", F32X);
        op(0x0a, "move-result", F11X);
        op(0x0b, "move-result-wide", F11X);
        op(0x0c, "move-result-object", F11X);
        op(0x0d, "move-exception", F11X);
        op(0x0e, "return-void", F10X);
        op(0x0f, "return", F11X);
        op(0x10, "return-wide", F11X);
        op(0x11, "return-object", F11X);
        op(0x12, "const/4", F11N);
        op(0x13, "const/16", F21S);
        op(0x14, "const", F31I);
        op(0x15, "const/high16", F21H);
        op(0x16, "const-wide/16", F21S);
        op(0x17, "const-wide/32", F31I);
        op(0x18, "const-wide", F51L);
        op(0x19, "const-wide/high16", F21H);
        op(0x1a, "const-string", F21C);
        op(0x1b, "const-string/jumbo", F31C);
        op(0x1c, "const-class", F21C);
        op(0x1d, "monitor-enter", F11X);
        op(0x1e, "monitor-exit", F11X);
        op(0x1f, "check-cast", F21C);
        op(0x20, "instance-of", F22C);
        op(0x21, "array-length", F12X);
        op(0x22, "new-instance", F21C);
        op(0x23, "new-array", F22C);
        op(0x24, "filled-new-array", F35C);
        op(0x25, "filled-new-array/range", F3RC);
        op(0x26, "fill-array-data", F31T);
        op(0x27, "throw", F11X);
        op(0x28, "goto", F10T);
        op(0x29, "goto/16", F20T);
        op(0x2a, "goto/32", F30T);
        op(0x2b, "packed-switch", F31T);
        op(0x2c, "sparse-switch", F31T);
        op(0x2d, "cmpl-float", F23X);
        op(0x2e, "cmpg-float", F23X);
        op(0x2f, "cmpl-double", F23X);
        op(0x30, "cmpg-double", F23X);
        op(0x31, "cmp-long", F23X);
        String[] ifs = {"eq", "ne", "lt", "ge", "gt", "le"};
        for (int i = 0; i < 6; i++) {
            op(0x32 + i, "if-" + ifs[i], F22T);
            op(0x38 + i, "if-" + ifs[i] + "z", F21T);
        }
        String[] kinds = {"", "-wide", "-object", "-boolean", "-byte", "-char", "-short"};
        for (int i = 0; i < 7; i++) {
            op(0x44 + i, "aget" + kinds[i], F23X);
            op(0x4b + i, "aput" + kinds[i], F23X);
            op(0x52 + i, "iget" + kinds[i], F22C);
            op(0x59 + i, "iput" + kinds[i], F22C);
            op(0x60 + i, "sget" + kinds[i], F21C);
            op(0x67 + i, "sput" + kinds[i], F21C);
        }
        String[] inv = {"virtual", "super", "direct", "static", "interface"};
        for (int i = 0; i < 5; i++) {
            op(0x6e + i, "invoke-" + inv[i], F35C);
            op(0x74 + i, "invoke-" + inv[i] + "/range", F3RC);
        }
        String[] un = {"neg-int", "not-int", "neg-long", "not-long", "neg-float", "neg-double", "int-to-long",
                "int-to-float", "int-to-double", "long-to-int", "long-to-float", "long-to-double", "float-to-int",
                "float-to-long", "float-to-double", "double-to-int", "double-to-long", "double-to-float",
                "int-to-byte", "int-to-char", "int-to-short"};
        for (int i = 0; i < un.length; i++) op(0x7b + i, un[i], F12X);
        String[] full = {"add", "sub", "mul", "div", "rem", "and", "or", "xor", "shl", "shr", "ushr"};
        String[] tp = {"int", "long", "float", "double"};
        int code = 0x90;
        int code2 = 0xb0;
        for (int t = 0; t < 4; t++) {
            int n = t < 2 ? 11 : 5;
            for (int k = 0; k < n; k++) {
                op(code++, full[k] + "-" + tp[t], F23X);
                op(code2++, full[k] + "-" + tp[t] + "/2addr", F12X);
            }
        }
        String[] l16 = {"add-int/lit16", "rsub-int", "mul-int/lit16", "div-int/lit16", "rem-int/lit16", "and-int/lit16",
                "or-int/lit16", "xor-int/lit16"};
        for (int i = 0; i < l16.length; i++) op(0xd0 + i, l16[i], F22S);
        String[] l8 = {"add-int/lit8", "rsub-int/lit8", "mul-int/lit8", "div-int/lit8", "rem-int/lit8", "and-int/lit8",
                "or-int/lit8", "xor-int/lit8", "shl-int/lit8", "shr-int/lit8", "ushr-int/lit8"};
        for (int i = 0; i < l8.length; i++) op(0xd8 + i, l8[i], F22B);
        op(0xfa, "invoke-polymorphic", F45CC);
        op(0xfb, "invoke-polymorphic/range", F4RCC);
        op(0xfc, "invoke-custom", F35C);
        op(0xfd, "invoke-custom/range", F3RC);
        op(0xfe, "const-method-handle", F21C);
        op(0xff, "const-method-type", F21C);
    }

    /** Which table an index in a "c" instruction points into: S string, T type, F field, M method, P proto, H handle, C call site. */
    private static char refKind(int op) {
        if (op == 0x1a || op == 0x1b) return 'S';
        if (op == 0x1c || op == 0x1f || op == 0x20 || op == 0x22 || op == 0x23 || op == 0x24 || op == 0x25) return 'T';
        if (op >= 0x52 && op <= 0x6d) return 'F';
        if ((op >= 0x6e && op <= 0x72) || (op >= 0x74 && op <= 0x78) || op == 0xfa || op == 0xfb) return 'M';
        if (op == 0xfc || op == 0xfd) return 'C';
        if (op == 0xfe) return 'H';
        if (op == 0xff) return 'P';
        return '?';
    }

    // ---- file model ----------------------------------------------------------------------------------

    byte[] d;
    private ByteBuffer b;
    int version;
    int stringCount, typeCount, protoCount, fieldCount, methodCount, classCount;
    private int stringIdsOff, typeIdsOff, protoIdsOff, fieldIdsOff, methodIdsOff, classDefsOff;
    private String[] strCache;
    private Map<String, Integer> strMap;
    private Map<String, Integer> typeMap;
    private Map<String, Integer> fieldMap;
    private Map<String, Integer> methodMap;

    static final class Field {
        int idx;
        int access;
        boolean isStatic;
    }

    static final class Method {
        int idx;
        int access;
        int codeOff;
        boolean direct;
    }

    static final class ClassInfo {
        int defIdx;
        int typeIdx;
        String name;
        int access;
        int superIdx;
        int sourceIdx;
        int dataOff;
        final List<Field> fields = new ArrayList<Field>();
        final List<Method> methods = new ArrayList<Method>();
    }

    static final class Insn {
        int addr;
        int size;
        int op;
        boolean payload;
        String text;
    }

    static final class Code {
        int regs;
        int ins;
        int outs;
        int size;
        int insnsPos;
        final List<Insn> insns = new ArrayList<Insn>();
    }

    private NixuDex() {}

    static boolean looksLikeDex(byte[] d) {
        return d != null && d.length > 112 && d[0] == 'd' && d[1] == 'e' && d[2] == 'x' && d[3] == '\n' && d[7] == 0;
    }

    static NixuDex parse(byte[] data) throws IOException {
        if (!looksLikeDex(data)) throw new IOException("This is not a dex file");
        NixuDex x = new NixuDex();
        x.d = data;
        x.b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        try {
            x.version = Integer.parseInt(new String(data, 4, 3, "US-ASCII"));
        } catch (Exception e) {
            x.version = 35;
        }
        ByteBuffer b = x.b;
        if (b.getInt(40) != 0x12345678) throw new IOException("Unsupported dex byte order");
        x.stringCount = b.getInt(56);
        x.stringIdsOff = b.getInt(60);
        x.typeCount = b.getInt(64);
        x.typeIdsOff = b.getInt(68);
        x.protoCount = b.getInt(72);
        x.protoIdsOff = b.getInt(76);
        x.fieldCount = b.getInt(80);
        x.fieldIdsOff = b.getInt(84);
        x.methodCount = b.getInt(88);
        x.methodIdsOff = b.getInt(92);
        x.classCount = b.getInt(96);
        x.classDefsOff = b.getInt(100);
        long n = data.length;
        if (x.stringCount < 0 || x.stringIdsOff < 0 || x.stringIdsOff + 4L * x.stringCount > n
                || x.typeCount < 0 || x.typeIdsOff + 4L * x.typeCount > n
                || x.protoCount < 0 || x.protoIdsOff + 12L * x.protoCount > n
                || x.fieldCount < 0 || x.fieldIdsOff + 8L * x.fieldCount > n
                || x.methodCount < 0 || x.methodIdsOff + 8L * x.methodCount > n
                || x.classCount < 0 || x.classDefsOff + 32L * x.classCount > n) {
            throw new IOException("Dex header points outside the file");
        }
        x.strCache = new String[x.stringCount];
        return x;
    }

    // ---- low level reading --------------------------------------------------------------------------

    private int u16(int p) {
        return b.getShort(p) & 0xFFFF;
    }

    private int u32(int p) {
        return b.getInt(p);
    }

    private int[] uleb(int p) {
        int result = 0;
        int shift = 0;
        int start = p;
        while (p < d.length) {
            int x = d[p++] & 0xFF;
            result |= (x & 0x7F) << shift;
            if ((x & 0x80) == 0) break;
            shift += 7;
            if (shift > 35) break;
        }
        return new int[]{result, p - start};
    }

    static byte[] ulebBytes(int v) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        int x = v;
        while (true) {
            int bt = x & 0x7F;
            x >>>= 7;
            if (x != 0) {
                o.write(bt | 0x80);
            } else {
                o.write(bt);
                break;
            }
        }
        return o.toByteArray();
    }

    static String decodeMutf8(byte[] d, int p, int n) {
        int end = Math.min(d.length, p + n);
        StringBuilder sb = new StringBuilder(n);
        while (p < end) {
            int a = d[p++] & 0xFF;
            if (a < 0x80) {
                sb.append((char) a);
            } else if ((a & 0xE0) == 0xC0 && p < end) {
                int b2 = d[p++] & 0x3F;
                sb.append((char) (((a & 0x1F) << 6) | b2));
            } else if ((a & 0xF0) == 0xE0 && p + 1 < end) {
                int b2 = d[p++] & 0x3F;
                int b3 = d[p++] & 0x3F;
                sb.append((char) (((a & 0x0F) << 12) | (b2 << 6) | b3));
            } else if ((a & 0xF8) == 0xF0 && p + 2 < end) {
                int b2 = d[p++] & 0x3F;
                int b3 = d[p++] & 0x3F;
                int b4 = d[p++] & 0x3F;
                sb.appendCodePoint(((a & 0x07) << 18) | (b2 << 12) | (b3 << 6) | b4);
            } else {
                sb.append('\uFFFD');
            }
        }
        return sb.toString();
    }

    static byte[] encodeMutf8(String s) {
        ByteArrayOutputStream o = new ByteArrayOutputStream(s.length() + 4);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == 0) {
                o.write(0xC0);
                o.write(0x80);
            } else if (c < 0x80) {
                o.write(c);
            } else if (c < 0x800) {
                o.write(0xC0 | (c >> 6));
                o.write(0x80 | (c & 0x3F));
            } else {
                o.write(0xE0 | (c >> 12));
                o.write(0x80 | ((c >> 6) & 0x3F));
                o.write(0x80 | (c & 0x3F));
            }
        }
        return o.toByteArray();
    }

    // ---- tables -------------------------------------------------------------------------------------

    private int stringDataOff(int idx) {
        return u32(stringIdsOff + 4 * idx);
    }

    String str(int idx) {
        if (idx < 0 || idx >= stringCount) return "string@" + idx;
        String s = strCache[idx];
        if (s == null) {
            int off = stringDataOff(idx);
            if (off <= 0 || off >= d.length) return "";
            int[] u = uleb(off);
            int p = off + u[1];
            int e = p;
            while (e < d.length && d[e] != 0) e++;
            s = decodeMutf8(d, p, e - p);
            strCache[idx] = s;
        }
        return s;
    }

    String typeName(int idx) {
        if (idx < 0 || idx >= typeCount) return "type@" + idx;
        return str(u32(typeIdsOff + 4 * idx));
    }

    private int protoReturn(int idx) {
        return u32(protoIdsOff + 12 * idx + 4);
    }

    private int protoParams(int idx) {
        return u32(protoIdsOff + 12 * idx + 8);
    }

    private String protoText(int idx) {
        if (idx < 0 || idx >= protoCount) return "proto@" + idx;
        StringBuilder sb = new StringBuilder("(");
        int off = protoParams(idx);
        if (off != 0 && off + 4 <= d.length) {
            int n = u32(off);
            for (int i = 0; i < n && off + 4 + 2 * i + 2 <= d.length; i++) sb.append(typeName(u16(off + 4 + 2 * i)));
        }
        sb.append(')').append(typeName(protoReturn(idx)));
        return sb.toString();
    }

    String fieldRef(int idx) {
        if (idx < 0 || idx >= fieldCount) return "field@" + idx;
        int p = fieldIdsOff + 8 * idx;
        return typeName(u16(p)) + "->" + str(u32(p + 4)) + ":" + typeName(u16(p + 2));
    }

    String methodRef(int idx) {
        if (idx < 0 || idx >= methodCount) return "method@" + idx;
        int p = methodIdsOff + 8 * idx;
        return typeName(u16(p)) + "->" + str(u32(p + 4)) + protoText(u16(p + 2));
    }

    String methodName(int idx) {
        if (idx < 0 || idx >= methodCount) return "method@" + idx;
        return str(u32(methodIdsOff + 8 * idx + 4));
    }

    String methodProto(int idx) {
        if (idx < 0 || idx >= methodCount) return "()V";
        return protoText(u16(methodIdsOff + 8 * idx + 2));
    }

    String methodReturnType(int idx) {
        if (idx < 0 || idx >= methodCount) return "V";
        return typeName(protoReturn(u16(methodIdsOff + 8 * idx + 2)));
    }

    String fieldName(int idx) {
        if (idx < 0 || idx >= fieldCount) return "field@" + idx;
        return str(u32(fieldIdsOff + 8 * idx + 4));
    }

    String fieldType(int idx) {
        if (idx < 0 || idx >= fieldCount) return "I";
        return typeName(u16(fieldIdsOff + 8 * idx + 2));
    }

    String className(int defIdx) {
        return typeName(u32(classDefsOff + 32 * defIdx));
    }

    ClassInfo classInfo(int defIdx) throws IOException {
        if (defIdx < 0 || defIdx >= classCount) throw new IOException("No such class");
        int p = classDefsOff + 32 * defIdx;
        ClassInfo c = new ClassInfo();
        c.defIdx = defIdx;
        c.typeIdx = u32(p);
        c.name = typeName(c.typeIdx);
        c.access = u32(p + 4);
        c.superIdx = u32(p + 8);
        c.sourceIdx = u32(p + 16);
        c.dataOff = u32(p + 24);
        if (c.dataOff == 0 || c.dataOff >= d.length) return c;
        int q = c.dataOff;
        int[] sf = uleb(q);
        q += sf[1];
        int[] inf = uleb(q);
        q += inf[1];
        int[] dm = uleb(q);
        q += dm[1];
        int[] vm = uleb(q);
        q += vm[1];
        for (int pass = 0; pass < 2; pass++) {
            int n = pass == 0 ? sf[0] : inf[0];
            int idx = 0;
            for (int i = 0; i < n; i++) {
                int[] diff = uleb(q);
                q += diff[1];
                int[] acc = uleb(q);
                q += acc[1];
                idx += diff[0];
                Field f = new Field();
                f.idx = idx;
                f.access = acc[0];
                f.isStatic = pass == 0;
                c.fields.add(f);
            }
        }
        for (int pass = 0; pass < 2; pass++) {
            int n = pass == 0 ? dm[0] : vm[0];
            int idx = 0;
            for (int i = 0; i < n; i++) {
                int[] diff = uleb(q);
                q += diff[1];
                int[] acc = uleb(q);
                q += acc[1];
                int[] code = uleb(q);
                q += code[1];
                idx += diff[0];
                Method m = new Method();
                m.idx = idx;
                m.access = acc[0];
                m.codeOff = code[0];
                m.direct = pass == 0;
                c.methods.add(m);
            }
        }
        return c;
    }

    // ---- names, flags ---------------------------------------------------------------------------------

    static String flags(int a, boolean method, boolean cls) {
        StringBuilder s = new StringBuilder();
        if ((a & 0x1) != 0) s.append("public ");
        if ((a & 0x2) != 0) s.append("private ");
        if ((a & 0x4) != 0) s.append("protected ");
        if ((a & 0x8) != 0) s.append("static ");
        if ((a & 0x10) != 0) s.append("final ");
        if ((a & 0x20) != 0 && method) s.append("synchronized ");
        if ((a & 0x40) != 0) s.append(method ? "bridge " : "volatile ");
        if ((a & 0x80) != 0) s.append(method ? "varargs " : "transient ");
        if ((a & 0x100) != 0) s.append("native ");
        if ((a & 0x200) != 0) s.append("interface ");
        if ((a & 0x400) != 0) s.append("abstract ");
        if ((a & 0x800) != 0) s.append("strict ");
        if ((a & 0x1000) != 0) s.append("synthetic ");
        if ((a & 0x2000) != 0) s.append("annotation ");
        if ((a & 0x4000) != 0) s.append("enum ");
        if ((a & 0x10000) != 0) s.append("constructor ");
        if ((a & 0x20000) != 0) s.append("declared-synchronized ");
        return s.toString();
    }

    /** Short readable name of a class: com.foo.Bar from Lcom/foo/Bar; */
    static String dotted(String desc) {
        if (desc.startsWith("L") && desc.endsWith(";")) return desc.substring(1, desc.length() - 1).replace('/', '.');
        return desc;
    }

    // ---- lookup maps (for the assembler and search) -------------------------------------------------

    private void buildMaps() {
        if (strMap != null) return;
        strMap = new HashMap<String, Integer>();
        for (int i = 0; i < stringCount; i++) {
            String s = str(i);
            if (!strMap.containsKey(s)) strMap.put(s, Integer.valueOf(i));
        }
        typeMap = new HashMap<String, Integer>();
        for (int i = 0; i < typeCount; i++) typeMap.put(typeName(i), Integer.valueOf(i));
        fieldMap = new HashMap<String, Integer>();
        for (int i = 0; i < fieldCount; i++) fieldMap.put(fieldRef(i), Integer.valueOf(i));
        methodMap = new HashMap<String, Integer>();
        for (int i = 0; i < methodCount; i++) methodMap.put(methodRef(i), Integer.valueOf(i));
    }

    int findString(String s) {
        buildMaps();
        Integer i = strMap.get(s);
        return i == null ? -1 : i.intValue();
    }

    // =======================================================================================
    // disassembler
    // =======================================================================================

    static String quote(String s) {
        StringBuilder b = new StringBuilder(s.length() + 2);
        b.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\n':
                    b.append("\\n");
                    break;
                case '\r':
                    b.append("\\r");
                    break;
                case '\t':
                    b.append("\\t");
                    break;
                case '"':
                    b.append("\\\"");
                    break;
                case '\\':
                    b.append("\\\\");
                    break;
                default:
                    if (c < 0x20 || c == 0x7f) b.append(String.format(Locale.US, "\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        return b.append('"').toString();
    }

    private static String reg(int n) {
        return "v" + n;
    }

    private static String hex(long v) {
        return v < 0 ? "-0x" + Long.toHexString(-v) : "0x" + Long.toHexString(v);
    }

    private String ref(char kind, int idx) {
        switch (kind) {
            case 'S':
                return idx >= 0 && idx < stringCount ? quote(str(idx)) : "string@" + idx;
            case 'T':
                return typeName(idx);
            case 'F':
                return fieldRef(idx);
            case 'M':
                return methodRef(idx);
            case 'P':
                return protoText(idx);
            case 'H':
                return "method_handle@" + idx;
            case 'C':
                return "call_site@" + idx;
            default:
                return "ref@" + idx;
        }
    }

    Code code(int codeOff) throws IOException {
        if (codeOff <= 0 || codeOff + 16 > d.length) throw new IOException("This method has no code");
        Code c = new Code();
        c.regs = u16(codeOff);
        c.ins = u16(codeOff + 2);
        c.outs = u16(codeOff + 4);
        c.size = u32(codeOff + 12);
        c.insnsPos = codeOff + 16;
        if (c.size < 0 || (long) c.insnsPos + 2L * c.size > d.length) throw new IOException("Code item runs past the file");
        int u = 0;
        while (u < c.size) {
            Insn in = new Insn();
            in.addr = u;
            int u0 = unit(c, u);
            int opc = u0 & 0xFF;
            if (opc == 0 && (u0 >> 8) != 0) {
                in.payload = true;
                int ident = u0;
                int sz;
                String text;
                if (ident == 0x0100 && u + 4 <= c.size) {
                    int n = unit(c, u + 1);
                    sz = 4 + n * 2;
                    int first = unit(c, u + 2) | (unit(c, u + 3) << 16);
                    StringBuilder t = new StringBuilder(".packed-switch-payload first=" + hex(first) + " targets=");
                    for (int i = 0; i < n && i < 40 && u + 4 + 2 * i + 1 < c.size; i++) {
                        int off = unit(c, u + 4 + 2 * i) | (unit(c, u + 5 + 2 * i) << 16);
                        if (i > 0) t.append(' ');
                        t.append(String.format(Locale.US, ":%04x", c.insnsPos == 0 ? 0 : off));
                    }
                    text = t.toString() + (n > 40 ? " ..(" + n + " targets)" : "");
                } else if (ident == 0x0200 && u + 2 <= c.size) {
                    int n = unit(c, u + 1);
                    sz = 2 + n * 4;
                    text = ".sparse-switch-payload size=" + n;
                } else if (ident == 0x0300 && u + 4 <= c.size) {
                    int w = unit(c, u + 1);
                    long n = (unit(c, u + 2) & 0xFFFFL) | ((long) unit(c, u + 3) << 16);
                    sz = 4 + (int) ((n * w + 1) / 2);
                    text = ".array-data-payload width=" + w + " count=" + n;
                } else {
                    sz = 1;
                    text = "nop (data 0x" + Integer.toHexString(u0) + ")";
                    in.payload = false;
                }
                in.size = Math.max(1, sz);
                in.op = 0;
                in.text = text;
                if (u + in.size > c.size) {
                    in.size = c.size - u;
                    in.text += " (cut off)";
                }
                c.insns.add(in);
                u += in.size;
                continue;
            }
            int fmt = OPFMT[opc];
            if (fmt < 0) {
                in.size = 1;
                in.op = opc;
                in.text = String.format(Locale.US, "unused-%02x", opc);
                c.insns.add(in);
                u++;
                continue;
            }
            in.op = opc;
            in.size = FSIZE[fmt];
            if (u + in.size > c.size) {
                in.size = c.size - u;
                in.text = OPNAME[opc] + " (cut off)";
                c.insns.add(in);
                u += in.size;
                break;
            }
            in.text = format(c, u, opc, fmt);
            c.insns.add(in);
            u += in.size;
        }
        return c;
    }

    private int unit(Code c, int u) {
        return u16(c.insnsPos + 2 * u);
    }

    private String format(Code c, int u, int opc, int fmt) {
        String n = OPNAME[opc];
        int u0 = unit(c, u);
        int u1 = FSIZE[fmt] > 1 ? unit(c, u + 1) : 0;
        int u2 = FSIZE[fmt] > 2 ? unit(c, u + 2) : 0;
        switch (fmt) {
            case F10X:
                return n;
            case F12X:
                return n + " " + reg((u0 >> 8) & 0xF) + ", " + reg((u0 >> 12) & 0xF);
            case F11N: {
                int v = (u0 >> 12) & 0xF;
                if (v > 7) v -= 16;
                return n + " " + reg((u0 >> 8) & 0xF) + ", " + hex(v);
            }
            case F11X:
                return n + " " + reg(u0 >> 8);
            case F10T:
                return n + " " + target(u, (byte) (u0 >> 8));
            case F20T:
                return n + " " + target(u, (short) u1);
            case F22X:
                return n + " " + reg(u0 >> 8) + ", " + reg(u1);
            case F21T:
                return n + " " + reg(u0 >> 8) + ", " + target(u, (short) u1);
            case F21S:
                return n + " " + reg(u0 >> 8) + ", " + hex((short) u1) + (opc == 0x16 ? "L" : "");
            case F21H:
                if (opc == 0x15) return n + " " + reg(u0 >> 8) + ", " + hex(((long) (short) u1) << 16);
                return n + " " + reg(u0 >> 8) + ", " + hex(((long) (short) u1) << 48) + "L";
            case F21C:
                return n + " " + reg(u0 >> 8) + ", " + ref(refKind(opc), u1);
            case F23X:
                return n + " " + reg(u0 >> 8) + ", " + reg(u1 & 0xFF) + ", " + reg((u1 >> 8) & 0xFF);
            case F22B:
                return n + " " + reg(u0 >> 8) + ", " + reg(u1 & 0xFF) + ", " + hex((byte) (u1 >> 8));
            case F22T:
                return n + " " + reg((u0 >> 8) & 0xF) + ", " + reg((u0 >> 12) & 0xF) + ", " + target(u, (short) u1);
            case F22S:
                return n + " " + reg((u0 >> 8) & 0xF) + ", " + reg((u0 >> 12) & 0xF) + ", " + hex((short) u1);
            case F22C:
                return n + " " + reg((u0 >> 8) & 0xF) + ", " + reg((u0 >> 12) & 0xF) + ", " + ref(refKind(opc), u1);
            case F30T:
                return n + " " + target(u, u1 | (u2 << 16));
            case F32X:
                return n + " " + reg(u1) + ", " + reg(u2);
            case F31I:
                return n + " " + reg(u0 >> 8) + ", " + hex(u1 | (u2 << 16)) + (opc == 0x17 ? "L" : "");
            case F31T:
                return n + " " + reg(u0 >> 8) + ", " + target(u, u1 | (u2 << 16));
            case F31C:
                return n + " " + reg(u0 >> 8) + ", " + ref(refKind(opc), u1 | (u2 << 16));
            case F35C: {
                int cnt = (u0 >> 12) & 0xF;
                int[] r = {u2 & 0xF, (u2 >> 4) & 0xF, (u2 >> 8) & 0xF, (u2 >> 12) & 0xF, (u0 >> 8) & 0xF};
                StringBuilder s = new StringBuilder(n).append(" {");
                for (int i = 0; i < cnt && i < 5; i++) {
                    if (i > 0) s.append(", ");
                    s.append(reg(r[i]));
                }
                return s.append("}, ").append(ref(refKind(opc), u1)).toString();
            }
            case F3RC: {
                int cnt = u0 >> 8;
                StringBuilder s = new StringBuilder(n).append(" {");
                if (cnt > 0) s.append(reg(u2)).append(" .. ").append(reg(u2 + cnt - 1));
                return s.append("}, ").append(ref(refKind(opc), u1)).toString();
            }
            case F45CC: {
                int cnt = (u0 >> 12) & 0xF;
                int u3 = unit(c, u + 3);
                int[] r = {u2 & 0xF, (u2 >> 4) & 0xF, (u2 >> 8) & 0xF, (u2 >> 12) & 0xF, (u0 >> 8) & 0xF};
                StringBuilder s = new StringBuilder(n).append(" {");
                for (int i = 0; i < cnt && i < 5; i++) {
                    if (i > 0) s.append(", ");
                    s.append(reg(r[i]));
                }
                return s.append("}, ").append(methodRef(u1)).append(", ").append(protoText(u3)).toString();
            }
            case F4RCC: {
                int cnt = u0 >> 8;
                int u3 = unit(c, u + 3);
                StringBuilder s = new StringBuilder(n).append(" {");
                if (cnt > 0) s.append(reg(u2)).append(" .. ").append(reg(u2 + cnt - 1));
                return s.append("}, ").append(methodRef(u1)).append(", ").append(protoText(u3)).toString();
            }
            case F51L: {
                long v = (long) u1 | ((long) u2 << 16) | ((long) unit(c, u + 3) << 32) | ((long) unit(c, u + 4) << 48);
                return n + " " + reg(u0 >> 8) + ", " + hex(v) + "L";
            }
            default:
                return n;
        }
    }

    private static String target(int addr, int off) {
        return String.format(Locale.US, ":%04x", addr + off);
    }

    // =======================================================================================
    // text of classes
    // =======================================================================================

    void smali(ClassInfo c, StringBuilder sb) {
        sb.append(".class ").append(flags(c.access, false, true)).append(c.name).append('\n');
        if (c.superIdx != -1 && c.superIdx != 0xFFFFFFFF && c.superIdx >= 0) sb.append(".super ").append(typeName(c.superIdx)).append('\n');
        if (c.sourceIdx != -1 && c.sourceIdx >= 0 && c.sourceIdx < stringCount) {
            sb.append(".source ").append(quote(str(c.sourceIdx))).append('\n');
        }
        sb.append('\n');
        for (Field f : c.fields) {
            sb.append(".field ").append(flags(f.access, false, false)).append(fieldName(f.idx)).append(':')
                    .append(fieldType(f.idx)).append('\n');
        }
        for (Method m : c.methods) {
            sb.append("\n.method ").append(flags(m.access, true, false)).append(methodName(m.idx))
                    .append(methodProto(m.idx)).append('\n');
            if (m.codeOff != 0) {
                try {
                    Code code = code(m.codeOff);
                    sb.append("    .registers ").append(code.regs).append("   # ins=").append(code.ins)
                            .append(" outs=").append(code.outs).append(" size=").append(code.size).append(" code_off=0x")
                            .append(Integer.toHexString(m.codeOff)).append('\n');
                    for (Insn in : code.insns) {
                        sb.append(String.format(Locale.US, "    %04x: ", in.addr)).append(in.text).append('\n');
                    }
                } catch (IOException e) {
                    sb.append("    # code unreadable: ").append(e.getMessage()).append('\n');
                }
            }
            sb.append(".end method\n");
        }
    }

    // =======================================================================================
    // assembler (one instruction)
    // =======================================================================================

    private static List<String> splitOperands(String s) {
        List<String> out = new ArrayList<String>();
        StringBuilder cur = new StringBuilder();
        int brace = 0;
        boolean quoted = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (quoted) {
                cur.append(c);
                if (c == '\\' && i + 1 < s.length()) {
                    cur.append(s.charAt(++i));
                } else if (c == '"') {
                    quoted = false;
                }
                continue;
            }
            if (c == '"') {
                quoted = true;
                cur.append(c);
            } else if (c == '{') {
                brace++;
                cur.append(c);
            } else if (c == '}') {
                brace--;
                cur.append(c);
            } else if (c == ',' && brace == 0) {
                out.add(cur.toString().trim());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        String last = cur.toString().trim();
        if (last.length() > 0 || !out.isEmpty()) out.add(last);
        return out;
    }

    private static int regNum(String t, Code c, int maxBits) throws IOException {
        t = t.trim();
        if (t.length() < 2 || (t.charAt(0) != 'v' && t.charAt(0) != 'p')) throw new IOException("Expected a register like v0 or p1, got \"" + t + "\"");
        int n;
        try {
            n = Integer.parseInt(t.substring(1));
        } catch (NumberFormatException e) {
            throw new IOException("Bad register \"" + t + "\"");
        }
        if (t.charAt(0) == 'p') n += c.regs - c.ins;
        if (n < 0) throw new IOException("Bad register \"" + t + "\"");
        if (n >= (1 << maxBits)) throw new IOException("Register " + t + " does not fit this instruction (v0 .. v" + ((1 << maxBits) - 1) + ")");
        if (n >= c.regs) throw new IOException("Register " + t + " is beyond this method's " + c.regs + " registers (v0 .. v" + (c.regs - 1) + ")");
        return n;
    }

    private static long literal(String t) throws IOException {
        String s = t.trim();
        if (s.endsWith("L") || s.endsWith("l") || s.endsWith("s") || s.endsWith("t")) s = s.substring(0, s.length() - 1);
        boolean neg = false;
        if (s.startsWith("-")) {
            neg = true;
            s = s.substring(1);
        } else if (s.startsWith("+")) {
            s = s.substring(1);
        }
        try {
            long v;
            if (s.startsWith("0x") || s.startsWith("0X")) v = Long.parseUnsignedLong(s.substring(2), 16);
            else v = Long.parseLong(s);
            return neg ? -v : v;
        } catch (NumberFormatException e) {
            throw new IOException("Bad number \"" + t + "\"");
        }
    }

    private static int branch(String t, int addr, int bits) throws IOException {
        t = t.trim();
        long off;
        try {
            if (t.startsWith(":")) off = Long.parseLong(t.substring(1), 16) - addr;
            else if (t.startsWith("+") || t.startsWith("-")) off = Long.parseLong(t.startsWith("+") ? t.substring(1) : t);
            else throw new IOException("Write the target as :002a (address) or +4 / -3 (distance), got \"" + t + "\"");
        } catch (NumberFormatException e) {
            throw new IOException("Bad branch target \"" + t + "\"");
        }
        long lim = 1L << (bits - 1);
        if (off < -lim || off >= lim) throw new IOException("Target is too far for this instruction (" + off + " units)");
        return (int) off;
    }

    private int refIndex(char kind, String t) throws IOException {
        t = t.trim();
        String[] pre = {"string@", "type@", "field@", "method@"};
        for (String p : pre) {
            if (t.startsWith(p)) {
                try {
                    return Integer.parseInt(t.substring(p.length()));
                } catch (NumberFormatException e) {
                    throw new IOException("Bad index in " + t);
                }
            }
        }
        buildMaps();
        Integer i;
        switch (kind) {
            case 'S': {
                if (!t.startsWith("\"") || !t.endsWith("\"") || t.length() < 2) {
                    throw new IOException("A string must be in quotes, like \"hello\"");
                }
                String s = unquote(t.substring(1, t.length() - 1));
                i = strMap.get(s);
                if (i == null) {
                    throw new IOException("The text " + quote(s) + " is not in the dex string pool. "
                            + "Use the Strings tab to change an existing string, or point to one with string@123.");
                }
                return i.intValue();
            }
            case 'T':
                i = typeMap.get(t);
                if (i == null) throw new IOException("Type " + t + " is not used in this dex (use type@123 to pick by number)");
                return i.intValue();
            case 'F':
                i = fieldMap.get(t);
                if (i == null) throw new IOException("Field " + t + " is not in this dex (use field@123)");
                return i.intValue();
            case 'M':
                i = methodMap.get(t);
                if (i == null) throw new IOException("Method " + t + " is not in this dex (use method@123)");
                return i.intValue();
            default:
                throw new IOException("This reference kind cannot be typed");
        }
    }

    private static String unquote(String s) throws IOException {
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '\\') {
                b.append(c);
                continue;
            }
            if (i + 1 >= s.length()) throw new IOException("Text ends with a lone backslash");
            char n = s.charAt(++i);
            switch (n) {
                case 'n':
                    b.append('\n');
                    break;
                case 'r':
                    b.append('\r');
                    break;
                case 't':
                    b.append('\t');
                    break;
                case '"':
                    b.append('"');
                    break;
                case '\\':
                    b.append('\\');
                    break;
                case 'u':
                    if (i + 4 >= s.length() + 0 && i + 4 > s.length() - 0) throw new IOException("Bad \\u escape");
                    try {
                        b.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16));
                    } catch (RuntimeException e) {
                        throw new IOException("Bad \\u escape");
                    }
                    i += 4;
                    break;
                default:
                    throw new IOException("Unknown escape \\" + n);
            }
        }
        return b.toString();
    }

    /**
     * Turns one line of text into code units. addr is where the instruction will sit (for branches).
     * A leading "0012:" address (as shown in the listing) is ignored.
     */
    int[] assemble(String line, int addr, Code c) throws IOException {
        String s = line.trim();
        int colon = s.indexOf(':');
        if (colon > 0 && colon <= 8 && s.substring(0, colon).matches("[0-9a-fA-F]+")) s = s.substring(colon + 1).trim();
        if (s.length() == 0) throw new IOException("Empty instruction");
        int sp = 0;
        while (sp < s.length() && !Character.isWhitespace(s.charAt(sp))) sp++;
        String mn = s.substring(0, sp);
        String rest = s.substring(sp).trim();
        Integer oc = OPBYNAME.get(mn);
        if (oc == null) throw new IOException("Unknown instruction \"" + mn + "\"");
        int opc = oc.intValue();
        int fmt = OPFMT[opc];
        List<String> o = splitOperands(rest);
        int need;
        switch (fmt) {
            case F10X:
                need = 0;
                break;
            case F12X:
            case F11N:
            case F22X:
            case F21T:
            case F21S:
            case F21H:
            case F21C:
            case F31I:
            case F31T:
            case F31C:
            case F32X:
            case F51L:
            case F35C:
            case F3RC:
                need = 2;
                break;
            case F11X:
            case F10T:
            case F20T:
            case F30T:
                need = 1;
                break;
            case F23X:
            case F22B:
            case F22T:
            case F22S:
            case F22C:
                need = 3;
                break;
            default:
                throw new IOException(mn + " cannot be typed here");
        }
        if (o.size() != need) throw new IOException(mn + " needs " + need + " value" + (need == 1 ? "" : "s") + ", you wrote " + o.size());
        int[] u;
        switch (fmt) {
            case F10X:
                return new int[]{opc};
            case F12X:
                return new int[]{opc | (regNum(o.get(0), c, 4) << 8) | (regNum(o.get(1), c, 4) << 12)};
            case F11N: {
                long v = literal(o.get(1));
                if (v < -8 || v > 7) throw new IOException("const/4 takes -8 .. 7; use const/16 for bigger numbers");
                return new int[]{opc | (regNum(o.get(0), c, 4) << 8) | (((int) v & 0xF) << 12)};
            }
            case F11X:
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8)};
            case F10T:
                return new int[]{opc | ((branch(o.get(0), addr, 8) & 0xFF) << 8)};
            case F20T:
                return new int[]{opc, branch(o.get(0), addr, 16) & 0xFFFF};
            case F22X:
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), regNum(o.get(1), c, 16)};
            case F21T:
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), branch(o.get(1), addr, 16) & 0xFFFF};
            case F21S: {
                long v = literal(o.get(1));
                if (v < -32768 || v > 32767) throw new IOException("Number does not fit 16 bits (-0x8000 .. 0x7fff)");
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), (int) v & 0xFFFF};
            }
            case F21H: {
                long v = literal(o.get(1));
                if (opc == 0x15) {
                    if ((v & 0xFFFF) != 0 || v < Integer.MIN_VALUE || v > 0xFFFFFFFFL) {
                        throw new IOException("const/high16 needs a number whose lower 16 bits are 0 (like 0x3f800000)");
                    }
                    return new int[]{opc | (regNum(o.get(0), c, 8) << 8), (int) ((v >> 16) & 0xFFFF)};
                }
                if ((v & 0xFFFFFFFFFFFFL) != 0) throw new IOException("const-wide/high16 needs a number whose lower 48 bits are 0");
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), (int) ((v >>> 48) & 0xFFFF)};
            }
            case F21C: {
                int idx = refIndex(refKind(opc), o.get(1));
                if (idx < 0 || idx > 0xFFFF) throw new IOException("Index " + idx + " does not fit this instruction (use const-string/jumbo)");
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), idx};
            }
            case F23X:
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), regNum(o.get(1), c, 8) | (regNum(o.get(2), c, 8) << 8)};
            case F22B: {
                long v = literal(o.get(2));
                if (v < -128 || v > 127) throw new IOException("Number does not fit 8 bits (-0x80 .. 0x7f)");
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), regNum(o.get(1), c, 8) | (((int) v & 0xFF) << 8)};
            }
            case F22T:
                return new int[]{opc | (regNum(o.get(0), c, 4) << 8) | (regNum(o.get(1), c, 4) << 12), branch(o.get(2), addr, 16) & 0xFFFF};
            case F22S: {
                long v = literal(o.get(2));
                if (v < -32768 || v > 32767) throw new IOException("Number does not fit 16 bits (-0x8000 .. 0x7fff)");
                return new int[]{opc | (regNum(o.get(0), c, 4) << 8) | (regNum(o.get(1), c, 4) << 12), (int) v & 0xFFFF};
            }
            case F22C: {
                int idx = refIndex(refKind(opc), o.get(2));
                if (idx < 0 || idx > 0xFFFF) throw new IOException("Index does not fit this instruction");
                return new int[]{opc | (regNum(o.get(0), c, 4) << 8) | (regNum(o.get(1), c, 4) << 12), idx};
            }
            case F30T: {
                int off = branch(o.get(0), addr, 32);
                return new int[]{opc, off & 0xFFFF, (off >>> 16) & 0xFFFF};
            }
            case F32X:
                return new int[]{opc, regNum(o.get(0), c, 16), regNum(o.get(1), c, 16)};
            case F31I: {
                long v = literal(o.get(1));
                if (v < Integer.MIN_VALUE || v > 0xFFFFFFFFL) throw new IOException("Number does not fit 32 bits");
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), (int) (v & 0xFFFF), (int) ((v >> 16) & 0xFFFF)};
            }
            case F31T: {
                int off = branch(o.get(1), addr, 32);
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), off & 0xFFFF, (off >>> 16) & 0xFFFF};
            }
            case F31C: {
                int idx = refIndex(refKind(opc), o.get(1));
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), idx & 0xFFFF, (idx >>> 16) & 0xFFFF};
            }
            case F51L: {
                long v = literal(o.get(1));
                return new int[]{opc | (regNum(o.get(0), c, 8) << 8), (int) (v & 0xFFFF), (int) ((v >> 16) & 0xFFFF),
                        (int) ((v >> 32) & 0xFFFF), (int) ((v >>> 48) & 0xFFFF)};
            }
            case F35C: {
                String list = o.get(0).trim();
                if (!list.startsWith("{") || !list.endsWith("}")) throw new IOException("Registers must be in { }, like {v0, v1}");
                String inner = list.substring(1, list.length() - 1).trim();
                List<Integer> regs = new ArrayList<Integer>();
                if (inner.length() > 0) {
                    for (String r : inner.split(",")) regs.add(Integer.valueOf(regNum(r, c, 4)));
                }
                if (regs.size() > 5) throw new IOException("At most 5 registers here; use the /range form");
                int idx = refIndex(refKind(opc), o.get(1));
                if (idx < 0 || idx > 0xFFFF) throw new IOException("Index does not fit this instruction");
                int[] r = new int[5];
                for (int i = 0; i < regs.size(); i++) r[i] = regs.get(i).intValue();
                int cnt = regs.size();
                return new int[]{opc | (cnt << 12) | (r[4] << 8), idx, r[0] | (r[1] << 4) | (r[2] << 8) | (r[3] << 12)};
            }
            case F3RC: {
                String list = o.get(0).trim();
                if (!list.startsWith("{") || !list.endsWith("}")) throw new IOException("Registers must be in { }, like {v0 .. v3}");
                String inner = list.substring(1, list.length() - 1).trim();
                int first = 0;
                int cnt = 0;
                if (inner.length() > 0) {
                    String[] ends = inner.split("\\.\\.");
                    first = regNum(ends[0], c, 16);
                    int last = ends.length > 1 ? regNum(ends[1], c, 16) : first;
                    if (last < first) throw new IOException("Range must go up, like {v2 .. v5}");
                    cnt = last - first + 1;
                    if (cnt > 255) throw new IOException("A range holds at most 255 registers");
                }
                int idx = refIndex(refKind(opc), o.get(1));
                if (idx < 0 || idx > 0xFFFF) throw new IOException("Index does not fit this instruction");
                return new int[]{opc | (cnt << 8), idx, first};
            }
            default:
                throw new IOException(mn + " cannot be typed here");
        }
    }

    // =======================================================================================
    // patching
    // =======================================================================================

    /** Replaces the instruction at addr by new units (same size or smaller; the rest becomes nop). */
    void patchInsn(Code c, Insn old, int[] units) throws IOException {
        if (old.payload) throw new IOException("Data tables cannot be edited as instructions");
        if (units.length > old.size) {
            throw new IOException("The new instruction needs " + units.length + " code unit(s) but the old one only has "
                    + old.size + ". A longer instruction would shift everything after it. Use a shorter form "
                    + "(for example const/16 instead of const) or replace several instructions with nop.");
        }
        int p = c.insnsPos + 2 * old.addr;
        for (int i = 0; i < old.size; i++) {
            int v = i < units.length ? units[i] : 0;
            d[p + 2 * i] = (byte) v;
            d[p + 2 * i + 1] = (byte) (v >> 8);
        }
        fixHeader();
    }

    /** Writes the units at the start of the method and turns everything after them into nop (dead code). */
    void patchBody(Code c, int[] units) throws IOException {
        if (units.length > c.size) throw new IOException("This method is too short (" + c.size + " code units) for that");
        for (int i = 0; i < c.size; i++) {
            int v = i < units.length ? units[i] : 0;
            int p = c.insnsPos + 2 * i;
            d[p] = (byte) v;
            d[p + 1] = (byte) (v >> 8);
        }
        fixHeader();
    }

    /**
     * Makes a method return a fixed value right away. kind: "void", "int" (also boolean/byte/short/char), "object" (null),
     * "wide" (0). Returns the units written.
     */
    int[] quickReturn(Code c, String kind, long value) throws IOException {
        int[] u;
        if (kind.equals("void")) {
            u = new int[]{0x000e};
        } else if (kind.equals("int")) {
            if (c.regs < 1) throw new IOException("This method has no register to hold a result");
            if (value >= -8 && value <= 7) {
                u = new int[]{0x0012 | (((int) value & 0xF) << 12), 0x000f};
            } else if (value >= -32768 && value <= 32767) {
                u = new int[]{0x0013, (int) value & 0xFFFF, 0x000f};
            } else {
                u = new int[]{0x0014, (int) (value & 0xFFFF), (int) ((value >> 16) & 0xFFFF), 0x000f};
            }
        } else if (kind.equals("object")) {
            if (c.regs < 1) throw new IOException("This method has no register to hold a result");
            u = new int[]{0x0012, 0x0011};
        } else if (kind.equals("wide")) {
            if (c.regs < 2) throw new IOException("This method needs 2 registers to return a long/double");
            u = new int[]{0x0016, (int) (value & 0xFFFF), 0x0010};
        } else {
            throw new IOException("Unknown return kind");
        }
        patchBody(c, u);
        return u;
    }

    /** Short answer to "what kind of value does this method return": void / int / object / wide. */
    String returnKind(int methodIdx) {
        String r = methodReturnType(methodIdx);
        if (r.equals("V")) return "void";
        if (r.equals("J") || r.equals("D")) return "wide";
        if (r.startsWith("L") || r.startsWith("[")) return "object";
        return "int";
    }

    /**
     * Changes a string in place. A shorter text is padded with spaces (when padSpaces is on) so that the string keeps
     * the same size inside the file; a longer one is refused.
     */
    String setString(int idx, String text, boolean padSpaces) throws IOException {
        if (idx < 0 || idx >= stringCount) throw new IOException("No such string");
        int off = stringDataOff(idx);
        int[] u = uleb(off);
        int p = off + u[1];
        int e = p;
        while (e < d.length && d[e] != 0) e++;
        int oldLen = e - p;
        String t = text;
        byte[] nb = encodeMutf8(t);
        if (nb.length > oldLen) {
            throw new IOException("This text needs " + nb.length + " bytes but the old one only has " + oldLen
                    + ". Strings cannot grow inside a dex without rebuilding it; use a shorter text.");
        }
        if (nb.length < oldLen) {
            if (!padSpaces) throw new IOException("The new text is shorter (" + nb.length + " of " + oldLen
                    + " bytes). Switch on padding with spaces, or type a text of the same length.");
            StringBuilder sb = new StringBuilder(t);
            while (encodeMutf8(sb.toString()).length < oldLen) sb.append(' ');
            t = sb.toString();
            nb = encodeMutf8(t);
        }
        byte[] nu = ulebBytes(t.length());
        if (nu.length != u[1]) {
            throw new IOException("The text length crosses a 127 / 16383 character border, which changes the size of the "
                    + "length field. Make the text a little shorter or longer.");
        }
        System.arraycopy(nu, 0, d, off, nu.length);
        System.arraycopy(nb, 0, d, p, nb.length);
        strCache[idx] = t;
        strMap = null;
        fixHeader();
        return t;
    }

    /** Number of bytes the string uses in the file (for the edit screen). */
    int stringBytes(int idx) {
        int off = stringDataOff(idx);
        int[] u = uleb(off);
        int p = off + u[1];
        int e = p;
        while (e < d.length && d[e] != 0) e++;
        return e - p;
    }

    void fixHeader() throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            md.update(d, 32, d.length - 32);
            byte[] sha = md.digest();
            System.arraycopy(sha, 0, d, 12, 20);
            Adler32 a = new Adler32();
            a.update(d, 12, d.length - 12);
            long v = a.getValue();
            d[8] = (byte) v;
            d[9] = (byte) (v >> 8);
            d[10] = (byte) (v >> 16);
            d[11] = (byte) (v >> 24);
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException("SHA-1 is not available");
        }
    }

    // =======================================================================================
    // search and summary
    // =======================================================================================

    /** Class indexes whose name contains the text (case insensitive); empty text = all. */
    List<Integer> findClasses(String q) {
        List<Integer> out = new ArrayList<Integer>();
        String lq = q.toLowerCase(Locale.US).replace('.', '/');
        for (int i = 0; i < classCount; i++) {
            if (lq.length() == 0 || className(i).toLowerCase(Locale.US).contains(lq)) out.add(Integer.valueOf(i));
        }
        return out;
    }

    List<Integer> findStrings(String q, int max) {
        List<Integer> out = new ArrayList<Integer>();
        String lq = q.toLowerCase(Locale.US);
        for (int i = 0; i < stringCount && out.size() < max; i++) {
            if (lq.length() == 0 || str(i).toLowerCase(Locale.US).contains(lq)) out.add(Integer.valueOf(i));
        }
        return out;
    }

    /** Method ids whose "Lcls;->name(args)ret" text contains the query. */
    List<Integer> findMethods(String q, int max) {
        List<Integer> out = new ArrayList<Integer>();
        String lq = q.toLowerCase(Locale.US);
        for (int i = 0; i < methodCount && out.size() < max; i++) {
            if (lq.length() == 0 || methodRef(i).toLowerCase(Locale.US).contains(lq)) out.add(Integer.valueOf(i));
        }
        return out;
    }

    /** Finds where a method is defined: {class def index, position in ClassInfo.methods} or null. */
    int[] locateMethod(int methodIdx) {
        int cls = u16(methodIdsOff + 8 * methodIdx);
        for (int i = 0; i < classCount; i++) {
            if (u32(classDefsOff + 32 * i) != cls) continue;
            try {
                ClassInfo ci = classInfo(i);
                for (int k = 0; k < ci.methods.size(); k++) {
                    if (ci.methods.get(k).idx == methodIdx) return new int[]{i, k};
                }
            } catch (IOException e) {
                return null;
            }
        }
        return null;
    }

    String summary() {
        return "dex " + String.format(Locale.US, "%03d", version) + ": " + classCount + " classes, " + methodCount
                + " methods, " + fieldCount + " fields, " + stringCount + " strings, " + d.length + " bytes";
    }
}
