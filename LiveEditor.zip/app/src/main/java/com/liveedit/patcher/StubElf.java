package com.liveedit.patcher;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * Builds a tiny, valid, EMPTY 32-bit ARM shared library (no code, no symbols). Android loads it without complaint, so
 * System.loadLibrary("x") in an app that only shipped 64-bit libraries no longer fails at that line. Every call into
 * the library then fails later (UnsatisfiedLinkError); the engine's guard keeps the app alive when that happens.
 * Layout (everything is mapped at file offset = address):
 *   header, 3 program headers, dynstr, hash, dynsym, dynamic, then (not mapped) shstrtab and 6 section headers.
 */
final class StubElf {

    private StubElf() {}

    static byte[] bytes() {
        final int ehdr = 52;
        final int phnum = 3;
        final int strtab = ehdr + phnum * 32;     // 148: dynstr, one zero byte
        final int hash = strtab + 4;              // 152: nbucket, nchain, bucket[1], chain[1]
        final int symtab = hash + 16;             // 168: the empty symbol
        final int dynamic = symtab + 16;          // 184: 6 entries of 8 bytes
        final int loadEnd = dynamic + 48;         // 232
        final byte[] shstr = "\0.hash\0.dynsym\0.dynstr\0.dynamic\0.shstrtab\0".getBytes(StandardCharsets.US_ASCII);
        final int shstrOff = loadEnd;
        final int shdrOff = (shstrOff + shstr.length + 3) & ~3;
        final int total = shdrOff + 6 * 40;

        ByteBuffer b = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);

        // ---- ELF header
        b.put(new byte[] {0x7f, 'E', 'L', 'F', 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0});
        b.putShort((short) 3);          // ET_DYN
        b.putShort((short) 40);         // EM_ARM
        b.putInt(1);                    // EV_CURRENT
        b.putInt(0);                    // entry
        b.putInt(ehdr);                 // program headers
        b.putInt(shdrOff);              // section headers
        b.putInt(0x05000000);           // ARM EABI v5
        b.putShort((short) ehdr);
        b.putShort((short) 32);
        b.putShort((short) phnum);
        b.putShort((short) 40);
        b.putShort((short) 6);
        b.putShort((short) 5);          // .shstrtab

        // ---- program headers
        phdr(b, 1, 0, loadEnd, 6, 0x1000);                 // PT_LOAD, whole mapped part, read + write
        phdr(b, 2, dynamic, 48, 6, 4);                     // PT_DYNAMIC
        b.putInt(0x6474e551);                              // PT_GNU_STACK: stack not executable
        b.putInt(0);
        b.putInt(0);
        b.putInt(0);
        b.putInt(0);
        b.putInt(0);
        b.putInt(6);
        b.putInt(16);

        // ---- dynstr, hash (one bucket, one empty symbol), dynsym
        b.position(strtab);
        b.put((byte) 0);
        b.position(hash);
        b.putInt(1);
        b.putInt(1);
        b.putInt(0);
        b.putInt(0);
        b.position(symtab);
        b.put(new byte[16]);

        // ---- dynamic
        b.position(dynamic);
        b.putInt(4);  b.putInt(hash);      // DT_HASH
        b.putInt(5);  b.putInt(strtab);    // DT_STRTAB
        b.putInt(6);  b.putInt(symtab);    // DT_SYMTAB
        b.putInt(10); b.putInt(1);         // DT_STRSZ
        b.putInt(11); b.putInt(16);        // DT_SYMENT
        b.putInt(0);  b.putInt(0);         // DT_NULL

        // ---- section names and section headers (Android's loader wants a section table to exist)
        b.position(shstrOff);
        b.put(shstr);
        b.position(shdrOff);
        b.put(new byte[40]);                                                   // 0: null
        shdr(b, 1, 5, 2, hash, 16, 2, 0, 4, 4);                                // 1: .hash
        shdr(b, 7, 11, 2, symtab, 16, 3, 1, 4, 16);                            // 2: .dynsym
        shdr(b, 15, 3, 2, strtab, 1, 0, 0, 1, 0);                              // 3: .dynstr
        shdr(b, 23, 6, 3, dynamic, 48, 3, 0, 4, 8);                            // 4: .dynamic
        shdr(b, 32, 3, 0, shstrOff, shstr.length, 0, 0, 1, 0);                 // 5: .shstrtab
        return b.array();
    }

    private static void phdr(ByteBuffer b, int type, int off, int size, int flags, int align) {
        b.putInt(type);
        b.putInt(off);
        b.putInt(off);   // virtual address = file offset
        b.putInt(off);
        b.putInt(size);
        b.putInt(size);
        b.putInt(flags);
        b.putInt(align);
    }

    private static void shdr(ByteBuffer b, int name, int type, int flags, int addrAndOff, int size,
                             int link, int info, int align, int entSize) {
        b.putInt(name);
        b.putInt(type);
        b.putInt(flags);
        b.putInt((flags & 2) != 0 ? addrAndOff : 0);   // address (only for sections that are mapped)
        b.putInt(addrAndOff);                          // file offset
        b.putInt(size);
        b.putInt(link);
        b.putInt(info);
        b.putInt(align);
        b.putInt(entSize);
    }
}
