package com.liveedit.patcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

/**
 * "nixu cn" mode: every file of the APK is listed (nothing hidden) like MT Manager, and each one can be opened
 * in an editor. Edits are collected and written into a new APK, signed, when you tap Save.
 */
public class NixuActivity extends Activity {

    private static final int REQ_ADD = 51;
    private static final int REQ_REPLACE = 52;
    private static final int REQ_EXTRACT = 53;
    private static final int REQ_SAVE_APK = 54;
    private static final int REQ_SAVE_TXT = 55;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    // MT Manager look
    private static final int HEAD = 0xFF2B2B2B;
    private static final int LISTBG = 0xFFFAFAFA;
    private static final int SELBG = 0xFFD6E4FF;
    private static final int TXT = 0xFF111111;
    private static final int SUBTXT = 0xFF7A7A7A;
    private static final int C_FOLDER = 0xFF262626;
    private static final int C_DEX = 0xFF5E9EA0;
    private static final int C_ARSC = 0xFFDDA63A;
    private static final int C_XML = 0xFF3F5FB5;
    private static final int C_IMG = 0xFF8E6BBF;
    private static final int C_OTHER = 0xFF6B7280;

    static final class Meta {
        String name;
        long size;
        long time;
        boolean changed;
    }

    private static final class Row {
        String name;
        String path;
        boolean dir;
        long size;
        long time;
        boolean changed;
        int count;
    }

    private static final class LRow {
        String title;
        String sub;
        int tag;
        boolean mono;
        boolean dim;

        LRow(String t, String s, int tag) {
            this.title = t;
            this.sub = s;
            this.tag = tag;
        }
    }

    private interface OnRow {
        void on(LRow r);
    }

    private interface Searcher {
        List<LRow> run(String q);
    }

    private File apk;
    private String label = "app";
    private boolean repaired;
    private final List<NixuZip.E> orig = new ArrayList<NixuZip.E>();
    private final Map<String, NixuZip.E> origByName = new HashMap<String, NixuZip.E>();
    private final TreeMap<String, Meta> files = new TreeMap<String, Meta>();
    private final Map<String, File> staged = new LinkedHashMap<String, File>();
    private final Set<String> deleted = new HashSet<String>();
    private File stageDir;
    private int stageSeq;
    private String cwd = "";
    private final Set<String> selected = new LinkedHashSet<String>();
    private int sortMode;
    private final ArrayList<Runnable> stack = new ArrayList<Runnable>();
    private Runnable guard;
    private LinearLayout page;
    private File lastOut;
    private String pendingName;
    private byte[] pendingBytes;
    private File pendingFile;
    private boolean busy;

    // open editors
    private NixuArsc arsc;
    private NixuDex dex;
    private String dexPath;

    private final SimpleDateFormat dateFmt = new SimpleDateFormat("yy-MM-dd HH:mm", Locale.US);

    // =======================================================================================
    // lifecycle
    // =======================================================================================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(HEAD);
        getWindow().setNavigationBarColor(0xFFEDEDED);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(LISTBG);
        setContentView(page);
        String p = getIntent().getStringExtra("apk");
        String l = getIntent().getStringExtra("label");
        if (l != null && l.length() > 0) label = l;
        if (p == null) {
            finish();
            return;
        }
        apk = new File(p);
        stageDir = new File(getCacheDir(), "nixu_stage");
        Patcher.deleteTree(stageDir);
        stageDir.mkdirs();
        setScreen(header(label, "Opening...", null, null, null, null), centerText("Reading every file of the APK..."), null);
        async("", new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                List<NixuZip.E> l2 = NixuZip.read(apk);
                try {
                    for (NixuZip.E e : l2) {
                        if (e.name.equals("AndroidManifest.xml")) NixuZip.bytes(apk, e);
                    }
                } catch (IOException ex) {
                    // fake "encrypted" flags and similar zip tricks: repair them in a copy, keep the data as it is
                    File rep = new File(apk.getParentFile(), "nixu_repaired.apk");
                    ZipPatcher.rewrite(apk, rep, null, null, null, null, true);
                    apk = rep;
                    repaired = true;
                    l2 = NixuZip.read(rep);
                }
                orig.clear();
                origByName.clear();
                for (NixuZip.E e : l2) {
                    orig.add(e);
                    origByName.put(e.name, e);
                }
                return Boolean.TRUE;
            }
        }, new Consumer<Boolean>() {
            @Override
            public void accept(Boolean ok) {
                rebuild();
                push(new Runnable() {
                    @Override
                    public void run() {
                        showBrowser();
                    }
                });
                if (repaired) {
                    Toast.makeText(NixuActivity.this, "Zip tricks were repaired (data unchanged)", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (busy) return;
        if (guard != null) {
            guard.run();
            return;
        }
        if (!selected.isEmpty()) {
            selected.clear();
            refresh();
            return;
        }
        if (stack.size() > 1) {
            pop();
            return;
        }
        if (cwd.length() > 0) {
            upDir();
            return;
        }
        if (!staged.isEmpty() || !deleted.isEmpty()) {
            Ui.dialog(this).setTitle("Leave nixu cn?")
                    .setMessage("You have unsaved changes. They will be lost.")
                    .setPositiveButton("Leave", (d, w) -> finish())
                    .setNegativeButton("Stay", null).show();
            return;
        }
        finish();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        try {
            if (req == REQ_ADD || req == REQ_REPLACE) {
                final String target = req == REQ_REPLACE ? pendingName : cwd + displayName(uri);
                File f = new File(stageDir, "s" + (stageSeq++) + ".bin");
                copyTo(getContentResolver().openInputStream(uri), f);
                putStaged(target, f);
                Toast.makeText(this, (req == REQ_REPLACE ? "Replaced " : "Added ") + target, Toast.LENGTH_SHORT).show();
                refresh();
            } else if (req == REQ_EXTRACT) {
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) throw new IOException("Cannot write there");
                try {
                    if (pendingBytes != null) os.write(pendingBytes);
                    else if (pendingFile != null) {
                        InputStream is = new FileInputStream(pendingFile);
                        byte[] buf = new byte[1 << 16];
                        int n;
                        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                        is.close();
                    }
                } finally {
                    os.close();
                }
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            } else if (req == REQ_SAVE_APK || req == REQ_SAVE_TXT) {
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) throw new IOException("Cannot write there");
                File src = pendingFile;
                try {
                    InputStream is = new FileInputStream(src);
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                    is.close();
                } finally {
                    os.close();
                }
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable t) {
            err(t);
        }
    }

    // =======================================================================================
    // small helpers
    // =======================================================================================

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private void err(Throwable t) {
        busy = false;
        String m = t.getMessage() != null ? t.getMessage() : t.toString();
        Ui.info(this, "That did not work", m);
    }

    private <T> void async(final String msg, final Callable<T> work, final Consumer<T> done) {
        if (msg.length() > 0) Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        busy = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final T r = work.call();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            busy = false;
                            try {
                                done.accept(r);
                            } catch (Throwable t) {
                                err(t);
                            }
                        }
                    });
                } catch (final Throwable t) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            err(t);
                        }
                    });
                }
            }
        }).start();
    }

    private void push(Runnable show) {
        stack.add(show);
        guard = null;
        show.run();
    }

    private void pop() {
        guard = null;
        if (stack.size() > 1) stack.remove(stack.size() - 1);
        refresh();
    }

    private void refresh() {
        if (!stack.isEmpty()) stack.get(stack.size() - 1).run();
    }

    private void setScreen(View header, View content, View bottom) {
        page.removeAllViews();
        page.addView(header, new LinearLayout.LayoutParams(MATCH, WRAP));
        page.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        if (bottom != null) page.addView(bottom, new LinearLayout.LayoutParams(MATCH, WRAP));
    }

    private View centerText(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(SUBTXT);
        t.setTextSize(15);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private TextView glyph(String s, final Runnable click) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(22);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(10), dp(14), dp(10));
        if (click != null) t.setOnClickListener(v -> click.run());
        return t;
    }

    private View header(String title, String sub, String left, Runnable onLeft, String right, Runnable onRight) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(HEAD);
        bar.setPadding(dp(4), dp(6), dp(4), dp(6));
        if (left != null) bar.addView(glyph(left, onLeft));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(left == null ? 12 : 4), 0, dp(4), 0);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(19);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.START);
        col.addView(t);
        if (sub != null && sub.length() > 0) {
            TextView s = new TextView(this);
            s.setText(sub);
            s.setTextColor(0xFF9A9A9A);
            s.setTextSize(12.5f);
            s.setSingleLine(true);
            s.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(s);
        }
        bar.addView(col, new LinearLayout.LayoutParams(0, WRAP, 1f));
        if (right != null) bar.addView(glyph(right, onRight));
        return bar;
    }

    private AlertDialog.Builder lightDialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_Material_Light_Dialog_Alert);
    }

    private void menu(String title, final String[] items, final Consumer<String> pick) {
        AlertDialog d = Ui.dialog(this).setTitle(title).setItems(items, (dd, w) -> pick.accept(items[w])).create();
        d.getWindow().setBackgroundDrawable(Ui.round(this, Ui.CARD, 18));
        d.show();
    }

    private void input(String title, String hint, String initial, boolean multi, final Ui.OnText ok) {
        final EditText e = Ui.edit(this, hint);
        if (multi) {
            e.setSingleLine(false);
            e.setMinLines(4);
            e.setGravity(Gravity.TOP);
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        }
        e.setText(initial == null ? "" : initial);
        e.setSelection(e.getText().length());
        e.setTypeface(Typeface.MONOSPACE);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(8), dp(18), 0);
        col.addView(e, new LinearLayout.LayoutParams(MATCH, WRAP));
        AlertDialog d = Ui.dialog(this).setTitle(title).setView(col)
                .setPositiveButton("OK", (dd, w) -> ok.on(e.getText().toString()))
                .setNegativeButton("Cancel", null).create();
        d.getWindow().setBackgroundDrawable(Ui.round(this, Ui.CARD, 18));
        d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) {
                    String n = c.getString(i);
                    if (n != null && n.length() > 0) return n;
                }
            }
        } catch (Throwable t) {
            // fall back below
        } finally {
            if (c != null) c.close();
        }
        String s = uri.getLastPathSegment();
        if (s == null) return "file";
        int slash = s.lastIndexOf('/');
        return slash >= 0 ? s.substring(slash + 1) : s;
    }

    private static void copyTo(InputStream is, File to) throws IOException {
        if (is == null) throw new IOException("Cannot open that file");
        OutputStream os = new FileOutputStream(to);
        try {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        } finally {
            os.close();
            is.close();
        }
    }

    private static byte[] readFile(File f) throws IOException {
        InputStream is = new FileInputStream(f);
        try {
            ByteArrayOutputStream o = new ByteArrayOutputStream((int) Math.max(16, f.length()));
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = is.read(buf)) > 0) o.write(buf, 0, n);
            return o.toByteArray();
        } finally {
            is.close();
        }
    }

    private static String safeName(String s) {
        String n = s == null ? "app" : s.replaceAll("[^A-Za-z0-9._-]+", "_");
        return n.length() == 0 ? "app" : n;
    }

    private void copyText(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("nixu cn", s));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
        }
    }

    // =======================================================================================
    // file index (original entries + staged changes)
    // =======================================================================================

    private void rebuild() {
        files.clear();
        for (NixuZip.E e : orig) {
            if (deleted.contains(e.name) || staged.containsKey(e.name)) continue;
            Meta m = new Meta();
            m.name = e.name;
            m.size = e.size;
            m.time = e.millis();
            files.put(e.name, m);
        }
        for (Map.Entry<String, File> x : staged.entrySet()) {
            Meta m = new Meta();
            m.name = x.getKey();
            m.size = x.getKey().endsWith("/") ? 0 : x.getValue().length();
            m.time = x.getValue().lastModified();
            m.changed = true;
            files.put(x.getKey(), m);
        }
    }

    private byte[] read(String name) throws IOException {
        File s = staged.get(name);
        if (s != null) return readFile(s);
        if (deleted.contains(name)) return null;
        NixuZip.E e = origByName.get(name);
        if (e == null) return null;
        return NixuZip.bytes(apk, e);
    }

    private void putStaged(String name, File f) {
        File old = staged.get(name);
        if (old != null && !old.equals(f)) old.delete();
        staged.put(name, f);
        deleted.remove(name);
        rebuild();
    }

    private void stage(String name, byte[] data) throws IOException {
        File f = new File(stageDir, "s" + (stageSeq++) + ".bin");
        OutputStream os = new FileOutputStream(f);
        try {
            os.write(data);
        } finally {
            os.close();
        }
        putStaged(name, f);
    }

    private void deleteName(String n) {
        File s = staged.remove(n);
        if (s != null) s.delete();
        if (origByName.containsKey(n)) deleted.add(n);
    }

    private void deletePath(String path) {
        if (path.endsWith("/")) {
            List<String> names = new ArrayList<String>(files.keySet());
            for (String n : names) {
                if (n.startsWith(path)) deleteName(n);
            }
        }
        deleteName(path);
        rebuild();
    }

    private boolean isChanged(String name) {
        return staged.containsKey(name) || deleted.contains(name);
    }

    // =======================================================================================
    // browser
    // =======================================================================================

    private List<Row> children(String dir) {
        Map<String, Row> m = new LinkedHashMap<String, Row>();
        for (Meta f : files.values()) {
            if (!f.name.startsWith(dir)) continue;
            String rest = f.name.substring(dir.length());
            if (rest.length() == 0) continue;
            int slash = rest.indexOf('/');
            if (slash < 0) {
                Row r = new Row();
                r.name = rest;
                r.path = f.name;
                r.size = f.size;
                r.time = f.time;
                r.changed = f.changed;
                m.put(rest, r);
            } else {
                String child = rest.substring(0, slash);
                Row r = m.get(child + "/");
                if (r == null) {
                    r = new Row();
                    r.name = child;
                    r.path = dir + child + "/";
                    r.dir = true;
                    m.put(child + "/", r);
                }
                r.size += f.size;
                r.count++;
                if (f.time > r.time) r.time = f.time;
                if (f.changed) r.changed = true;
            }
        }
        List<Row> out = new ArrayList<Row>(m.values());
        final int mode = sortMode;
        Collections.sort(out, new Comparator<Row>() {
            @Override
            public int compare(Row a, Row b) {
                if (a.dir != b.dir) return a.dir ? -1 : 1;
                if (mode == 1 && a.size != b.size) return a.size > b.size ? -1 : 1;
                if (mode == 2 && a.time != b.time) return a.time > b.time ? -1 : 1;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        return out;
    }

    private void upDir() {
        if (cwd.length() == 0) return;
        String c = cwd.substring(0, cwd.length() - 1);
        int s = c.lastIndexOf('/');
        cwd = s < 0 ? "" : c.substring(0, s + 1);
        refresh();
    }

    private static int colorFor(String name, boolean dir) {
        if (dir) return C_FOLDER;
        String n = name.toLowerCase(Locale.US);
        if (n.endsWith(".dex")) return C_DEX;
        if (n.equals("resources.arsc")) return C_ARSC;
        if (n.endsWith(".xml")) return C_XML;
        if (n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp") || n.endsWith(".gif")) return C_IMG;
        return C_OTHER;
    }

    private static String labelFor(String name) {
        String n = name.toLowerCase(Locale.US);
        if (n.endsWith(".dex")) return "01";
        if (n.equals("resources.arsc")) return "\u2261";
        if (n.endsWith(".xml")) return "<>";
        int dot = n.lastIndexOf('.');
        if (dot >= 0 && n.length() - dot <= 5) return n.substring(dot + 1).toUpperCase(Locale.US);
        return "";
    }

    private static final class Icon extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int color = C_OTHER;
        String text = "";
        boolean folder;

        Icon(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            c.drawRoundRect(new RectF(0, 0, w, h), w * 0.2f, w * 0.2f, p);
            p.setColor(Color.WHITE);
            if (folder) {
                c.drawRoundRect(new RectF(w * 0.2f, h * 0.27f, w * 0.48f, h * 0.42f), w * 0.04f, w * 0.04f, p);
                c.drawRoundRect(new RectF(w * 0.2f, h * 0.34f, w * 0.8f, h * 0.72f), w * 0.05f, w * 0.05f, p);
            } else {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(w * 0.05f);
                c.drawRoundRect(new RectF(w * 0.28f, h * 0.2f, w * 0.72f, h * 0.8f), w * 0.06f, w * 0.06f, p);
                p.setStyle(Paint.Style.FILL);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTypeface(Typeface.DEFAULT_BOLD);
                p.setTextSize(text.length() > 3 ? w * 0.15f : w * 0.22f);
                c.drawText(text, w / 2f, h * 0.58f, p);
            }
        }
    }

    private void showBrowser() {
        final List<Row> rows = children(cwd);
        int folders = 0;
        int fileCount = 0;
        for (Row r : rows) {
            if (r.dir) folders++;
            else fileCount++;
        }
        final String shortName = label + ".apk/" + cwd;
        final boolean selMode = !selected.isEmpty();
        View head;
        if (selMode) {
            head = header(selected.size() + " selected", "tap items to select more", "\u2715", new Runnable() {
                @Override
                public void run() {
                    selected.clear();
                    refresh();
                }
            }, "\u22EE", new Runnable() {
                @Override
                public void run() {
                    selectionMenu(rows);
                }
            });
        } else {
            head = header(shortName, "Folders: " + folders + " Files: " + fileCount, "\u2630", new Runnable() {
                @Override
                public void run() {
                    mainMenu();
                }
            }, "\u22EE", new Runnable() {
                @Override
                public void run() {
                    viewMenu(rows);
                }
            });
        }

        final ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setBackgroundColor(LISTBG);
        final int total = rows.size() + 1;
        BaseAdapter ad = new BaseAdapter() {
            @Override
            public int getCount() {
                return total;
            }

            @Override
            public Object getItem(int i) {
                return i;
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View cv, ViewGroup parent) {
                LinearLayout row = new LinearLayout(NixuActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(7), dp(12), dp(7));
                Icon ic = new Icon(NixuActivity.this);
                String title;
                String sub;
                boolean changed = false;
                if (i == 0) {
                    ic.folder = true;
                    ic.color = C_FOLDER;
                    title = "..";
                    sub = "";
                } else {
                    Row r = rows.get(i - 1);
                    ic.folder = r.dir;
                    ic.color = colorFor(r.name, r.dir);
                    ic.text = labelFor(r.name);
                    title = r.name;
                    changed = r.changed;
                    sub = dateFmt.format(new Date(r.time)) + "  " + NixuExport.size(r.size);
                    if (selected.contains(r.path)) row.setBackgroundColor(SELBG);
                }
                LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(42), dp(42));
                ilp.rightMargin = dp(12);
                row.addView(ic, ilp);
                LinearLayout col = new LinearLayout(NixuActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                TextView t = new TextView(NixuActivity.this);
                t.setText(title);
                t.setTextSize(17);
                t.setTextColor(changed ? 0xFFC62828 : TXT);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                col.addView(t);
                if (sub.length() > 0) {
                    TextView s = new TextView(NixuActivity.this);
                    s.setText(sub);
                    s.setTextSize(12.5f);
                    s.setTextColor(SUBTXT);
                    col.addView(s);
                }
                row.addView(col, new LinearLayout.LayoutParams(0, WRAP, 1f));
                return row;
            }
        };
        lv.setAdapter(ad);
        lv.setOnItemClickListener((p, v, pos, id) -> {
            if (pos == 0) {
                if (!selected.isEmpty()) return;
                if (cwd.length() > 0) upDir();
                else onBackPressed();
                return;
            }
            Row r = rows.get(pos - 1);
            if (!selected.isEmpty()) {
                toggle(r.path);
                return;
            }
            if (r.dir) {
                cwd = r.path;
                refresh();
            } else {
                openWith(r.path);
            }
        });
        lv.setOnItemLongClickListener((p, v, pos, id) -> {
            if (pos == 0) return true;
            toggle(rows.get(pos - 1).path);
            return true;
        });
        setScreen(head, lv, selMode ? selectionBar(rows) : navBar());
    }

    private void toggle(String path) {
        if (!selected.remove(path)) selected.add(path);
        refresh();
    }

    private View barButton(String text, final Runnable click) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFF555555);
        t.setTextSize(text.length() > 2 ? 14 : 24);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(12), dp(8), dp(12));
        t.setOnClickListener(v -> click.run());
        return t;
    }

    private View bar(View... items) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setBackgroundColor(0xFFEDEDED);
        for (View v : items) b.addView(v, new LinearLayout.LayoutParams(0, WRAP, 1f));
        return b;
    }

    private View navBar() {
        return bar(
                barButton("\u2039", () -> onBackPressed()),
                barButton("\u2315", () -> searchFiles()),
                barButton("+", () -> addMenu()),
                barButton("Save", () -> saveSigned()),
                barButton("\u2191", () -> upDir()));
    }

    private View selectionBar(final List<Row> rows) {
        return bar(
                barButton("Delete", () -> deleteSelected()),
                barButton("Extract", () -> extractSelected()),
                barButton("Rename", () -> renameSelected()),
                barButton("All", () -> {
                    for (Row r : rows) selected.add(r.path);
                    refresh();
                }));
    }

    private void selectionMenu(final List<Row> rows) {
        menu(selected.size() + " selected", new String[]{"Delete", "Extract", "Rename", "Replace with a file", "Select all", "Copy path"},
                new Consumer<String>() {
                    @Override
                    public void accept(String s) {
                        if (s.equals("Delete")) deleteSelected();
                        else if (s.equals("Extract")) extractSelected();
                        else if (s.equals("Rename")) renameSelected();
                        else if (s.equals("Replace with a file")) replaceSelected();
                        else if (s.equals("Select all")) {
                            for (Row r : rows) selected.add(r.path);
                            refresh();
                        } else if (s.equals("Copy path")) {
                            copyText(selected.iterator().next());
                        }
                    }
                });
    }

    private void deleteSelected() {
        final List<String> names = new ArrayList<String>(selected);
        Ui.dialog(this).setTitle("Delete " + names.size() + " item(s)?")
                .setMessage("They are removed from the APK when you tap Save. Until then you can still discard all changes.")
                .setPositiveButton("Delete", (d, w) -> {
                    for (String n : names) deletePath(n);
                    selected.clear();
                    refresh();
                }).setNegativeButton("Cancel", null).show();
    }

    private void extractSelected() {
        if (selected.size() != 1) {
            Toast.makeText(this, "Select one file to extract", Toast.LENGTH_SHORT).show();
            return;
        }
        final String n = selected.iterator().next();
        if (n.endsWith("/")) {
            Toast.makeText(this, "Open the folder and extract files one by one", Toast.LENGTH_SHORT).show();
            return;
        }
        extractFile(n);
    }

    private void extractFile(final String n) {
        async("Reading...", new Callable<byte[]>() {
            @Override
            public byte[] call() throws Exception {
                return read(n);
            }
        }, new Consumer<byte[]>() {
            @Override
            public void accept(byte[] data) {
                if (data == null) return;
                pendingBytes = data;
                pendingFile = null;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_TITLE, n.substring(n.lastIndexOf('/') + 1));
                startActivityForResult(i, REQ_EXTRACT);
            }
        });
    }

    private void replaceSelected() {
        if (selected.size() != 1 || selected.iterator().next().endsWith("/")) {
            Toast.makeText(this, "Select one file to replace", Toast.LENGTH_SHORT).show();
            return;
        }
        pendingName = selected.iterator().next();
        selected.clear();
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_REPLACE);
    }

    private void renameSelected() {
        if (selected.size() != 1) {
            Toast.makeText(this, "Select one item to rename", Toast.LENGTH_SHORT).show();
            return;
        }
        final String old = selected.iterator().next();
        final boolean dir = old.endsWith("/");
        String plain = dir ? old.substring(0, old.length() - 1) : old;
        input("Rename (full path inside the APK)", "path", plain, false, new Ui.OnText() {
            @Override
            public void on(String s) {
                String nn = s.trim();
                if (nn.length() == 0 || nn.equals(dir ? old.substring(0, old.length() - 1) : old)) return;
                if (dir) nn += "/";
                final String target = nn;
                async("Renaming...", new Callable<Integer>() {
                    @Override
                    public Integer call() throws Exception {
                        int n = 0;
                        List<String> names = new ArrayList<String>();
                        if (dir) {
                            for (String k : files.keySet()) {
                                if (k.startsWith(old)) names.add(k);
                            }
                        } else {
                            names.add(old);
                        }
                        for (String k : names) {
                            String nk = dir ? target + k.substring(old.length()) : target;
                            if (k.endsWith("/")) {
                                stage(nk, new byte[0]);
                            } else {
                                byte[] data = read(k);
                                if (data != null) stage(nk, data);
                            }
                            deleteName(k);
                            n++;
                        }
                        return Integer.valueOf(n);
                    }
                }, new Consumer<Integer>() {
                    @Override
                    public void accept(Integer n) {
                        selected.clear();
                        rebuild();
                        refresh();
                        Toast.makeText(NixuActivity.this, "Renamed " + n + " file(s)", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void viewMenu(final List<Row> rows) {
        menu("View", new String[]{"Sort by name", "Sort by size", "Sort by date", "Select all"}, new Consumer<String>() {
            @Override
            public void accept(String s) {
                if (s.equals("Sort by name")) sortMode = 0;
                else if (s.equals("Sort by size")) sortMode = 1;
                else if (s.equals("Sort by date")) sortMode = 2;
                else for (Row r : rows) selected.add(r.path);
                refresh();
            }
        });
    }

    private void addMenu() {
        menu("Add to " + (cwd.length() == 0 ? "APK root" : cwd), new String[]{"File from phone", "New folder", "New text file"},
                new Consumer<String>() {
                    @Override
                    public void accept(String s) {
                        if (s.equals("File from phone")) {
                            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType("*/*");
                            startActivityForResult(i, REQ_ADD);
                        } else if (s.equals("New folder")) {
                            input("Folder name", "name", "", false, new Ui.OnText() {
                                @Override
                                public void on(String n) {
                                    String nm = n.trim();
                                    if (nm.length() == 0) return;
                                    try {
                                        stage(cwd + nm + "/", new byte[0]);
                                    } catch (IOException e) {
                                        err(e);
                                    }
                                    refresh();
                                }
                            });
                        } else {
                            input("File name", "name.txt", "", false, new Ui.OnText() {
                                @Override
                                public void on(String n) {
                                    String nm = n.trim();
                                    if (nm.length() == 0) return;
                                    try {
                                        stage(cwd + nm, new byte[0]);
                                    } catch (IOException e) {
                                        err(e);
                                    }
                                    refresh();
                                }
                            });
                        }
                    }
                });
    }

    private void searchFiles() {
        input("Find file (part of the path)", "for example .dex or layout", "", false, new Ui.OnText() {
            @Override
            public void on(String q) {
                final String lq = q.trim().toLowerCase(Locale.US);
                final List<LRow> rows = new ArrayList<LRow>();
                final List<String> names = new ArrayList<String>();
                for (Meta m : files.values()) {
                    if (m.name.endsWith("/")) continue;
                    if (lq.length() == 0 || m.name.toLowerCase(Locale.US).contains(lq)) {
                        rows.add(new LRow(m.name, NixuExport.size(m.size), names.size()));
                        names.add(m.name);
                        if (rows.size() >= 500) break;
                    }
                }
                push(new Runnable() {
                    @Override
                    public void run() {
                        showList("Found " + rows.size(), "tap to open", rows, null, null, new OnRow() {
                            @Override
                            public void on(LRow r) {
                                String n = names.get(r.tag);
                                int s = n.lastIndexOf('/');
                                cwd = s < 0 ? "" : n.substring(0, s + 1);
                                openWith(n);
                            }
                        }, null, null, null);
                    }
                });
            }
        });
    }

    private void mainMenu() {
        menu("nixu cn", new String[]{"Save and sign APK", "Export for Claude (text file)", "Info", "Discard all changes",
                "Back to simple mode"}, new Consumer<String>() {
            @Override
            public void accept(String s) {
                if (s.equals("Save and sign APK")) saveSigned();
                else if (s.equals("Export for Claude (text file)")) exportDialog();
                else if (s.equals("Info")) info();
                else if (s.equals("Discard all changes")) discard();
                else {
                    getSharedPreferences("liveeditor", MODE_PRIVATE).edit().putBoolean("nixu", false).apply();
                    finish();
                }
            }
        });
    }

    private void info() {
        long total = 0;
        for (Meta m : files.values()) total += m.size;
        Ui.info(this, label, orig.size() + " entries in the original APK\n" + files.size() + " entries now ("
                + NixuExport.size(total) + " unpacked)\n" + staged.size() + " changed or added, " + deleted.size()
                + " deleted\n\nSigned on Save with the Live Editor key (v1 + v2). Old signature files are removed.");
    }

    private void discard() {
        Ui.dialog(this).setTitle("Discard all changes?").setMessage("Everything you edited since opening is dropped.")
                .setPositiveButton("Discard", (d, w) -> {
                    for (File f : staged.values()) f.delete();
                    staged.clear();
                    deleted.clear();
                    selected.clear();
                    rebuild();
                    refresh();
                }).setNegativeButton("Cancel", null).show();
    }

    // =======================================================================================
    // open with...
    // =======================================================================================

    private void openWith(final String path) {
        final String n = path.toLowerCase(Locale.US);
        final List<String> opts = new ArrayList<String>();
        if (n.equals("resources.arsc") || n.endsWith(".arsc")) {
            opts.add("Arsc Editor plus");
            opts.add("Arsc Editor");
            opts.add("Translation mode");
            opts.add("Resource querier");
        } else if (n.endsWith(".dex")) {
            opts.add("Dex Editor Plus");
            opts.add("Dex strings");
            opts.add("Dex method search");
        } else if (n.endsWith(".xml")) {
            opts.add("XML editor");
        } else if (n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp") || n.endsWith(".gif")
                || n.endsWith(".bmp")) {
            opts.add("Image viewer");
        }
        opts.add("Text editor");
        opts.add("Hex editor");
        final String[] arr = opts.toArray(new String[0]);
        AlertDialog d = lightDialog().setTitle("Open with\u2026")
                .setSingleChoiceItems(arr, -1, (dd, w) -> {
                    dd.dismiss();
                    launch(path, arr[w]);
                }).create();
        d.show();
    }

    private void launch(final String path, final String how) {
        final String shortName = path.substring(path.lastIndexOf('/') + 1);
        if (how.startsWith("Arsc") || how.equals("Translation mode") || how.equals("Resource querier")) {
            async("Reading resources...", new Callable<NixuArsc>() {
                @Override
                public NixuArsc call() throws Exception {
                    byte[] d = read(path);
                    if (d == null) throw new IOException("File is gone");
                    return NixuArsc.parse(d);
                }
            }, new Consumer<NixuArsc>() {
                @Override
                public void accept(NixuArsc a) {
                    arsc = a;
                    final String name = path;
                    if (how.equals("Arsc Editor plus")) {
                        push(new Runnable() {
                            @Override
                            public void run() {
                                arscTypes(name);
                            }
                        });
                    } else if (how.equals("Arsc Editor")) {
                        push(new Runnable() {
                            @Override
                            public void run() {
                                arscFlat(name, "", "Arsc Editor");
                            }
                        });
                    } else if (how.equals("Translation mode")) {
                        push(new Runnable() {
                            @Override
                            public void run() {
                                arscTranslate(name);
                            }
                        });
                    } else {
                        input("Search resources (name, id, value)", "app_name or 0x7f010001 or text", "", false, new Ui.OnText() {
                            @Override
                            public void on(final String q) {
                                push(new Runnable() {
                                    @Override
                                    public void run() {
                                        arscFlat(name, q, "Resource querier");
                                    }
                                });
                            }
                        });
                    }
                }
            });
        } else if (how.startsWith("Dex")) {
            async("Reading dex...", new Callable<NixuDex>() {
                @Override
                public NixuDex call() throws Exception {
                    byte[] d = read(path);
                    if (d == null) throw new IOException("File is gone");
                    return NixuDex.parse(d);
                }
            }, new Consumer<NixuDex>() {
                @Override
                public void accept(NixuDex x) {
                    dex = x;
                    dexPath = path;
                    push(new Runnable() {
                        @Override
                        public void run() {
                            if (how.equals("Dex Editor Plus")) dexClasses();
                            else if (how.equals("Dex strings")) dexStrings();
                            else dexMethodSearch();
                        }
                    });
                }
            });
        } else {
            async("Opening...", new Callable<byte[]>() {
                @Override
                public byte[] call() throws Exception {
                    byte[] d = read(path);
                    if (d == null) throw new IOException("File is gone");
                    return d;
                }
            }, new Consumer<byte[]>() {
                @Override
                public void accept(final byte[] data) {
                    if (how.equals("Hex editor")) {
                        push(new Runnable() {
                            @Override
                            public void run() {
                                hexScreen(path, data);
                            }
                        });
                    } else if (how.equals("Image viewer")) {
                        push(new Runnable() {
                            @Override
                            public void run() {
                                imageScreen(path, data);
                            }
                        });
                    } else {
                        if (data.length > 2 * 1024 * 1024) {
                            Toast.makeText(NixuActivity.this, "Too big for the text editor, opened as hex", Toast.LENGTH_LONG).show();
                            push(new Runnable() {
                                @Override
                                public void run() {
                                    hexScreen(path, data);
                                }
                            });
                            return;
                        }
                        push(new Runnable() {
                            @Override
                            public void run() {
                                textScreen(path, data);
                            }
                        });
                    }
                }
            });
        }
    }

    // =======================================================================================
    // generic list screen
    // =======================================================================================

    private void showList(String title, String sub, final List<LRow> initial, final Searcher searcher, String initialQuery,
                          final OnRow click, final OnRow longClick, String menuGlyph, final Runnable menuAction) {
        final List<LRow> shown = new ArrayList<LRow>(initial);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        final EditText search = new EditText(this);
        search.setHint("Search");
        search.setHintTextColor(0xFF999999);
        search.setTextColor(TXT);
        search.setTextSize(15);
        search.setSingleLine(true);
        search.setPadding(dp(14), dp(10), dp(14), dp(10));
        search.setBackgroundColor(0xFFEDEDED);
        content.addView(search, new LinearLayout.LayoutParams(MATCH, WRAP));
        final ListView lv = new ListView(this);
        lv.setDivider(null);
        content.addView(lv, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        final BaseAdapter ad = new BaseAdapter() {
            @Override
            public int getCount() {
                return shown.size();
            }

            @Override
            public Object getItem(int i) {
                return shown.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View cv, ViewGroup parent) {
                LRow r = shown.get(i);
                LinearLayout row = new LinearLayout(NixuActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(14), dp(8), dp(14), dp(8));
                TextView t = new TextView(NixuActivity.this);
                t.setText(r.title);
                t.setTextSize(r.mono ? 13 : 16);
                t.setTextColor(r.dim ? 0xFF9A9A9A : TXT);
                if (r.mono) t.setTypeface(Typeface.MONOSPACE);
                t.setMaxLines(3);
                t.setEllipsize(TextUtils.TruncateAt.END);
                row.addView(t);
                if (r.sub != null && r.sub.length() > 0) {
                    TextView s = new TextView(NixuActivity.this);
                    s.setText(r.sub);
                    s.setTextSize(12);
                    s.setTextColor(SUBTXT);
                    s.setMaxLines(2);
                    s.setEllipsize(TextUtils.TruncateAt.END);
                    row.addView(s);
                }
                return row;
            }
        };
        lv.setAdapter(ad);
        lv.setOnItemClickListener((p, v, pos, id) -> {
            if (click != null) click.on(shown.get(pos));
        });
        lv.setOnItemLongClickListener((p, v, pos, id) -> {
            if (longClick == null) return false;
            longClick.on(shown.get(pos));
            return true;
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void afterTextChanged(Editable e) {
                String q = e.toString().trim();
                shown.clear();
                if (searcher != null) {
                    shown.addAll(searcher.run(q));
                } else {
                    String lq = q.toLowerCase(Locale.US);
                    for (LRow r : initial) {
                        if (lq.length() == 0 || r.title.toLowerCase(Locale.US).contains(lq)
                                || (r.sub != null && r.sub.toLowerCase(Locale.US).contains(lq))) {
                            shown.add(r);
                        }
                    }
                }
                ad.notifyDataSetChanged();
            }
        });
        if (initialQuery != null && initialQuery.length() > 0) search.setText(initialQuery);
        setScreen(header(title, sub, "\u2039", new Runnable() {
            @Override
            public void run() {
                onBackPressed();
            }
        }, menuGlyph, menuAction), content, null);
    }

    private static String oneLine(String s, int max) {
        String t = s.replace("\n", "\u23CE").replace("\r", "");
        return t.length() > max ? t.substring(0, max) + "\u2026" : t;
    }

    // =======================================================================================
    // text editor (plain text, and binary XML shown as text)
    // =======================================================================================

    private void textScreen(final String path, final byte[] data) {
        final boolean axml = NixuAxml.isBinary(data);
        String text;
        try {
            text = axml ? NixuAxml.toXml(data) : new String(data, "UTF-8");
        } catch (Exception e) {
            err(e);
            return;
        }
        final EditText ed = new EditText(this);
        ed.setText(text);
        ed.setTextColor(TXT);
        ed.setTextSize(12.5f);
        ed.setTypeface(Typeface.MONOSPACE);
        ed.setBackgroundColor(Color.WHITE);
        ed.setGravity(Gravity.TOP | Gravity.START);
        ed.setPadding(dp(10), dp(8), dp(10), dp(8));
        ed.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        final boolean[] dirty = {false};
        ed.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                dirty[0] = true;
            }

            @Override
            public void afterTextChanged(Editable e) {}
        });
        guard = new Runnable() {
            @Override
            public void run() {
                if (!dirty[0]) {
                    pop();
                    return;
                }
                Ui.dialog(NixuActivity.this).setTitle("Leave without saving?")
                        .setPositiveButton("Leave", (d, w) -> pop())
                        .setNegativeButton("Stay", null).show();
            }
        };
        setScreen(header(path.substring(path.lastIndexOf('/') + 1), axml ? "compiled XML shown as text" : "text editor", "\u2039",
                new Runnable() {
                    @Override
                    public void run() {
                        guard.run();
                    }
                }, "SAVE", new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String t = ed.getText().toString();
                            byte[] out = axml ? NixuAxml.fromXml(t, data, NixuAxml.androidIds()) : t.getBytes("UTF-8");
                            stage(path, out);
                            dirty[0] = false;
                            Toast.makeText(NixuActivity.this, "Saved in the APK (not signed yet). Tap Save in the browser.",
                                    Toast.LENGTH_LONG).show();
                            pop();
                        } catch (Throwable e) {
                            err(e);
                        }
                    }
                }), ed, null);
    }

    // =======================================================================================
    // hex editor
    // =======================================================================================

    private void hexScreen(final String path, final byte[] initial) {
        final byte[][] cur = {initial};
        final int rowsN = (initial.length + 15) / 16;
        final ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setBackgroundColor(Color.WHITE);
        final BaseAdapter ad = new BaseAdapter() {
            @Override
            public int getCount() {
                return Math.max(1, rowsN);
            }

            @Override
            public Object getItem(int i) {
                return i;
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View cv, ViewGroup parent) {
                TextView t = new TextView(NixuActivity.this);
                t.setTypeface(Typeface.MONOSPACE);
                t.setTextSize(10.5f);
                t.setTextColor(TXT);
                t.setPadding(dp(6), dp(3), dp(6), dp(3));
                t.setText(hexRow(cur[0], i * 16));
                return t;
            }
        };
        lv.setAdapter(ad);
        lv.setOnItemClickListener((p, v, pos, id) -> {
            final int off = pos * 16;
            final int n = Math.min(16, cur[0].length - off);
            if (n <= 0) return;
            StringBuilder h = new StringBuilder();
            for (int i = 0; i < n; i++) {
                if (i > 0) h.append(' ');
                h.append(String.format(Locale.US, "%02x", cur[0][off + i] & 0xFF));
            }
            input("Edit bytes at " + String.format(Locale.US, "0x%x", off), "hex bytes", h.toString(), false, new Ui.OnText() {
                @Override
                public void on(String s) {
                    String[] parts = s.trim().split("[\\s,]+");
                    if (parts.length != n) {
                        Toast.makeText(NixuActivity.this, "Keep exactly " + n + " bytes (same size)", Toast.LENGTH_LONG).show();
                        return;
                    }
                    try {
                        byte[] copy = cur[0].clone();
                        for (int i = 0; i < n; i++) copy[off + i] = (byte) Integer.parseInt(parts[i], 16);
                        stage(path, copy);
                        cur[0] = copy;
                        ad.notifyDataSetChanged();
                    } catch (Throwable e) {
                        Toast.makeText(NixuActivity.this, "Bad hex: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        });
        setScreen(header(path.substring(path.lastIndexOf('/') + 1), cur[0].length + " bytes - tap a row to edit", "\u2039",
                new Runnable() {
                    @Override
                    public void run() {
                        onBackPressed();
                    }
                }, "\u22EE", new Runnable() {
                    @Override
                    public void run() {
                        input("Go to offset (hex)", "1a40", "", false, new Ui.OnText() {
                            @Override
                            public void on(String s) {
                                try {
                                    int off = Integer.parseInt(s.trim().replace("0x", ""), 16);
                                    lv.setSelection(Math.min(rowsN - 1, off / 16));
                                } catch (NumberFormatException e) {
                                    Toast.makeText(NixuActivity.this, "Not a hex number", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }), lv, null);
    }

    private static String hexRow(byte[] d, int off) {
        StringBuilder sb = new StringBuilder(80);
        sb.append(String.format(Locale.US, "%08x  ", off));
        StringBuilder asc = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            if (off + i < d.length) {
                int v = d[off + i] & 0xFF;
                sb.append(String.format(Locale.US, "%02x ", v));
                asc.append(v >= 32 && v < 127 ? (char) v : '.');
            } else {
                sb.append("   ");
            }
        }
        return sb.append(' ').append(asc).toString();
    }

    // =======================================================================================
    // image viewer
    // =======================================================================================

    private void imageScreen(String path, byte[] data) {
        Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length);
        ImageView iv = new ImageView(this);
        iv.setBackgroundColor(0xFF333333);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        String sub;
        if (bm == null) {
            sub = "cannot decode this image";
        } else {
            iv.setImageBitmap(bm);
            sub = bm.getWidth() + " x " + bm.getHeight() + "  " + NixuExport.size(data.length);
        }
        setScreen(header(path.substring(path.lastIndexOf('/') + 1), sub, "\u2039", new Runnable() {
            @Override
            public void run() {
                onBackPressed();
            }
        }, null, null), iv, null);
    }

    // =======================================================================================
    // resources.arsc screens
    // =======================================================================================

    private void saveArsc(String path) throws IOException {
        stage(path, arsc.toBytes());
    }

    private void arscTypes(final String path) {
        final Map<String, Integer> counts = new LinkedHashMap<String, Integer>();
        for (NixuArsc.Res r : arsc.entries) {
            String k = r.pkg.name + " / " + r.typeName;
            Integer c = counts.get(k);
            counts.put(k, Integer.valueOf(c == null ? 1 : c.intValue() + 1));
        }
        final List<String> keys = new ArrayList<String>(counts.keySet());
        List<LRow> rows = new ArrayList<LRow>();
        for (int i = 0; i < keys.size(); i++) rows.add(new LRow(keys.get(i), counts.get(keys.get(i)) + " values", i));
        showList("Arsc Editor plus", arsc.pkgs.size() + " package(s), " + arsc.entries.size() + " values", rows, null, "",
                new OnRow() {
                    @Override
                    public void on(LRow r) {
                        final String key = keys.get(r.tag);
                        push(new Runnable() {
                            @Override
                            public void run() {
                                arscTypeEntries(path, key);
                            }
                        });
                    }
                }, null, null, null);
    }

    private void arscTypeEntries(final String path, final String key) {
        final Map<Integer, List<Integer>> byId = new LinkedHashMap<Integer, List<Integer>>();
        for (int i = 0; i < arsc.entries.size(); i++) {
            NixuArsc.Res r = arsc.entries.get(i);
            if (!(r.pkg.name + " / " + r.typeName).equals(key)) continue;
            List<Integer> l = byId.get(Integer.valueOf(r.resId));
            if (l == null) {
                l = new ArrayList<Integer>();
                byId.put(Integer.valueOf(r.resId), l);
            }
            l.add(Integer.valueOf(i));
        }
        final List<Integer> ids = new ArrayList<Integer>(byId.keySet());
        List<LRow> rows = new ArrayList<LRow>();
        for (int i = 0; i < ids.size(); i++) {
            List<Integer> l = byId.get(ids.get(i));
            NixuArsc.Res first = arsc.entries.get(l.get(0).intValue());
            rows.add(new LRow(first.name, first.id() + "  " + oneLine(arsc.valueSummary(first), 70) + (l.size() > 1 ? "  (+" + (l.size() - 1) + " more configs)" : ""), i));
        }
        showList(key, rows.size() + " resources", rows, null, "", new OnRow() {
            @Override
            public void on(LRow r) {
                final List<Integer> l = byId.get(ids.get(r.tag));
                push(new Runnable() {
                    @Override
                    public void run() {
                        arscConfigs(path, l);
                    }
                });
            }
        }, null, null, null);
    }

    private void arscConfigs(final String path, final List<Integer> idx) {
        List<LRow> rows = new ArrayList<LRow>();
        NixuArsc.Res first = arsc.entries.get(idx.get(0).intValue());
        for (int i = 0; i < idx.size(); i++) {
            NixuArsc.Res r = arsc.entries.get(idx.get(i).intValue());
            rows.add(new LRow("[" + r.config + "]  " + oneLine(arsc.valueSummary(r), 120), r.id(), idx.get(i).intValue()));
        }
        showList(first.path(), first.id(), rows, null, "", new OnRow() {
            @Override
            public void on(LRow r) {
                editArscEntry(path, r.tag);
            }
        }, null, null, null);
    }

    private void arscFlat(final String path, String query, String title) {
        final List<LRow> rows = new ArrayList<LRow>();
        for (int i = 0; i < arsc.entries.size(); i++) {
            NixuArsc.Res r = arsc.entries.get(i);
            rows.add(new LRow(r.path() + " [" + r.config + "]", r.id() + "  " + oneLine(arsc.valueSummary(r), 100), i));
        }
        showList(title, rows.size() + " values", rows, null, query, new OnRow() {
            @Override
            public void on(LRow r) {
                editArscEntry(path, r.tag);
            }
        }, null, null, null);
    }

    private void editArscEntry(final String path, final int entryIndex) {
        final NixuArsc.Res r = arsc.entries.get(entryIndex);
        if (r.complex) {
            push(new Runnable() {
                @Override
                public void run() {
                    List<LRow> rr = new ArrayList<LRow>();
                    NixuArsc.Res cur = arsc.entries.get(entryIndex);
                    for (int i = 0; i < cur.mapName.length; i++) {
                        rr.add(new LRow(String.format(Locale.US, "0x%08x", cur.mapName[i]) + " = " + oneLine(arsc.shown(cur.mapType[i], cur.mapData[i]), 120),
                                "type 0x" + Integer.toHexString(cur.mapType[i]), i));
                    }
                    showList(cur.path() + " [" + cur.config + "]", arsc.valueSummary(cur), rr, null, "", new OnRow() {
                        @Override
                        public void on(LRow row) {
                            askArscValue(path, entryIndex, row.tag);
                        }
                    }, null, null, null);
                }
            });
            return;
        }
        if (r.valuePos < 0) {
            Toast.makeText(this, "This entry uses a compact format and cannot be edited", Toast.LENGTH_LONG).show();
            return;
        }
        askArscValue(path, entryIndex, -1);
    }

    private void askArscValue(final String path, final int entryIndex, final int item) {
        NixuArsc.Res r = arsc.entries.get(entryIndex);
        String current = item < 0 ? arsc.editText(r.valueType, r.valueData) : arsc.editText(r.mapType[item], r.mapData[item]);
        String type = item < 0 ? r.valueType == 3 ? "string" : "type 0x" + Integer.toHexString(r.valueType)
                : r.mapType[item] == 3 ? "string" : "type 0x" + Integer.toHexString(r.mapType[item]);
        input(r.path() + " [" + r.config + "]  (" + type + ")",
                "text, true, 123, 0x7f, #ffffff, 16dp, @0x7f010001", item < 0 && r.valueType == 3 ? current : current, true,
                new Ui.OnText() {
                    @Override
                    public void on(String s) {
                        try {
                            arsc.setValue(entryIndex, item, s);
                            saveArsc(path);
                            Toast.makeText(NixuActivity.this, "Changed (tap Save in the browser to sign)", Toast.LENGTH_SHORT).show();
                            refresh();
                        } catch (Throwable e) {
                            err(e);
                        }
                    }
                });
    }

    private void arscTranslate(final String path) {
        Map<Integer, Integer> use = arsc.stringUsage();
        final List<Integer> idx = new ArrayList<Integer>(use.keySet());
        Collections.sort(idx);
        List<LRow> rows = new ArrayList<LRow>();
        for (int i = 0; i < idx.size(); i++) {
            int pi = idx.get(i).intValue();
            String s = arsc.stringAt(pi);
            if (s.length() == 0 || s.startsWith("res/") || s.startsWith("assets/")) continue;
            rows.add(new LRow(oneLine(s, 160), "#" + pi + "   used " + use.get(idx.get(i)) + "x", pi));
        }
        showList("Translation mode", rows.size() + " texts", rows, null, "", new OnRow() {
            @Override
            public void on(final LRow r) {
                input("Text #" + r.tag + " (changes every place that uses it)", "text", arsc.stringAt(r.tag), true, new Ui.OnText() {
                    @Override
                    public void on(String s) {
                        try {
                            arsc.setPoolString(r.tag, s);
                            saveArsc(path);
                            refresh();
                        } catch (Throwable e) {
                            err(e);
                        }
                    }
                });
            }
        }, null, null, null);
    }

    // =======================================================================================
    // dex screens
    // =======================================================================================

    private void saveDex() throws IOException {
        stage(dexPath, dex.d);
    }

    private void dexClasses() {
        final List<LRow> rows = new ArrayList<LRow>();
        for (int i = 0; i < dex.classCount; i++) {
            LRow r = new LRow(NixuDex.dotted(dex.className(i)), "", i);
            rows.add(r);
        }
        showList("Dex Editor Plus", dex.summary(), rows, null, "", new OnRow() {
            @Override
            public void on(final LRow r) {
                push(new Runnable() {
                    @Override
                    public void run() {
                        dexClass(r.tag);
                    }
                });
            }
        }, null, "\u22EE", new Runnable() {
            @Override
            public void run() {
                menu("Dex", new String[]{"Search methods", "Strings", "Copy summary"}, new Consumer<String>() {
                    @Override
                    public void accept(String s) {
                        if (s.equals("Search methods")) {
                            push(new Runnable() {
                                @Override
                                public void run() {
                                    dexMethodSearch();
                                }
                            });
                        } else if (s.equals("Strings")) {
                            push(new Runnable() {
                                @Override
                                public void run() {
                                    dexStrings();
                                }
                            });
                        } else {
                            copyText(dex.summary());
                        }
                    }
                });
            }
        });
    }

    private void dexClass(final int defIdx) {
        final NixuDex.ClassInfo ci;
        try {
            ci = dex.classInfo(defIdx);
        } catch (IOException e) {
            err(e);
            return;
        }
        List<LRow> rows = new ArrayList<LRow>();
        LRow head = new LRow(".class " + NixuDex.flags(ci.access, false, true) + ci.name,
                ".super " + (ci.superIdx >= 0 ? dex.typeName(ci.superIdx) : "none"), -1);
        head.dim = true;
        rows.add(head);
        for (NixuDex.Field f : ci.fields) {
            LRow r = new LRow(".field " + NixuDex.flags(f.access, false, false) + dex.fieldName(f.idx) + ":" + dex.fieldType(f.idx), "", -1);
            r.dim = true;
            rows.add(r);
        }
        for (int i = 0; i < ci.methods.size(); i++) {
            NixuDex.Method m = ci.methods.get(i);
            rows.add(new LRow(NixuDex.flags(m.access, true, false) + dex.methodName(m.idx) + dex.methodProto(m.idx),
                    m.codeOff == 0 ? "no code (abstract or native)" : "code at 0x" + Integer.toHexString(m.codeOff), i));
        }
        final List<LRow> all = rows;
        showList(NixuDex.dotted(ci.name), ci.methods.size() + " methods, " + ci.fields.size() + " fields", all, null, "",
                new OnRow() {
                    @Override
                    public void on(LRow r) {
                        if (r.tag < 0) return;
                        NixuDex.Method m = ci.methods.get(r.tag);
                        if (m.codeOff == 0) {
                            Toast.makeText(NixuActivity.this, "This method has no code", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        final int pos = r.tag;
                        push(new Runnable() {
                            @Override
                            public void run() {
                                dexMethod(defIdx, pos);
                            }
                        });
                    }
                }, null, "\u22EE", new Runnable() {
                    @Override
                    public void run() {
                        menu("Class", new String[]{"View smali text", "Export smali (share text file)", "Copy class name"},
                                new Consumer<String>() {
                                    @Override
                                    public void accept(String s) {
                                        StringBuilder sb = new StringBuilder();
                                        dex.smali(ci, sb);
                                        if (s.equals("View smali text")) {
                                            final String text = sb.toString();
                                            push(new Runnable() {
                                                @Override
                                                public void run() {
                                                    readOnlyText(NixuDex.dotted(ci.name), text);
                                                }
                                            });
                                        } else if (s.equals("Export smali (share text file)")) {
                                            shareText(safeName(NixuDex.dotted(ci.name)) + ".smali.txt", sb.toString());
                                        } else {
                                            copyText(NixuDex.dotted(ci.name));
                                        }
                                    }
                                });
                    }
                });
    }

    private void readOnlyText(String title, String text) {
        final EditText ed = new EditText(this);
        ed.setText(text);
        ed.setTextColor(TXT);
        ed.setTextSize(11.5f);
        ed.setTypeface(Typeface.MONOSPACE);
        ed.setBackgroundColor(Color.WHITE);
        ed.setGravity(Gravity.TOP | Gravity.START);
        ed.setPadding(dp(10), dp(8), dp(10), dp(8));
        ed.setKeyListener(null);
        ed.setTextIsSelectable(true);
        setScreen(header(title, "read only - select text to copy", "\u2039", new Runnable() {
            @Override
            public void run() {
                onBackPressed();
            }
        }, null, null), ed, null);
    }

    private void dexMethod(final int defIdx, final int pos) {
        final NixuDex.ClassInfo ci;
        final NixuDex.Method m;
        final NixuDex.Code code;
        try {
            ci = dex.classInfo(defIdx);
            m = ci.methods.get(pos);
            code = dex.code(m.codeOff);
        } catch (IOException e) {
            err(e);
            return;
        }
        final List<LRow> rows = new ArrayList<LRow>();
        for (int i = 0; i < code.insns.size(); i++) {
            NixuDex.Insn in = code.insns.get(i);
            LRow r = new LRow(String.format(Locale.US, "%04x: ", in.addr) + in.text, "", i);
            r.mono = true;
            r.dim = in.payload;
            rows.add(r);
        }
        final String name = dex.methodName(m.idx) + dex.methodProto(m.idx);
        showList(name, "regs " + code.regs + "  ins " + code.ins + "  size " + code.size + " units", rows, null, "", new OnRow() {
            @Override
            public void on(final LRow r) {
                final NixuDex.Insn in = code.insns.get(r.tag);
                if (in.payload) {
                    Toast.makeText(NixuActivity.this, "This is a data table, not an instruction", Toast.LENGTH_SHORT).show();
                    return;
                }
                input("Edit instruction at " + String.format(Locale.US, "%04x", in.addr) + " (max " + in.size + " unit"
                        + (in.size == 1 ? "" : "s") + ")", "for example const/4 v0, 0x1", in.text, true, new Ui.OnText() {
                    @Override
                    public void on(String s) {
                        try {
                            int[] u = dex.assemble(s.replace("\n", " "), in.addr, code);
                            dex.patchInsn(code, in, u);
                            saveDex();
                            refresh();
                        } catch (Throwable e) {
                            err(e);
                        }
                    }
                });
            }
        }, new OnRow() {
            @Override
            public void on(LRow r) {
                final NixuDex.Insn in = code.insns.get(r.tag);
                menu("Instruction " + String.format(Locale.US, "%04x", in.addr), new String[]{"Make it nop", "Copy line"},
                        new Consumer<String>() {
                            @Override
                            public void accept(String s) {
                                if (s.equals("Copy line")) {
                                    copyText(in.text);
                                    return;
                                }
                                try {
                                    dex.patchInsn(code, in, new int[]{0});
                                    saveDex();
                                    refresh();
                                } catch (Throwable e) {
                                    err(e);
                                }
                            }
                        });
            }
        }, "\u22EE", new Runnable() {
            @Override
            public void run() {
                quickMenu(code, m);
            }
        });
    }

    private void quickMenu(final NixuDex.Code code, final NixuDex.Method m) {
        final String kind = dex.returnKind(m.idx);
        final List<String> items = new ArrayList<String>();
        if (kind.equals("void")) {
            items.add("Return void right away");
        } else if (kind.equals("int")) {
            items.add("Return true / 1");
            items.add("Return false / 0");
            items.add("Return a number...");
        } else if (kind.equals("object")) {
            items.add("Return null");
        } else {
            items.add("Return 0");
        }
        items.add("Copy method text");
        String warn = dex.methodName(m.idx).equals("<init>") ? "Constructor: do not shortcut it" : "Quick patch";
        menu(warn, items.toArray(new String[0]), new Consumer<String>() {
            @Override
            public void accept(String s) {
                try {
                    if (s.equals("Copy method text")) {
                        StringBuilder sb = new StringBuilder();
                        for (NixuDex.Insn in : code.insns) sb.append(String.format(Locale.US, "%04x: ", in.addr)).append(in.text).append('\n');
                        copyText(sb.toString());
                    } else if (s.equals("Return void right away")) {
                        dex.quickReturn(code, "void", 0);
                        saveDex();
                        refresh();
                    } else if (s.equals("Return true / 1")) {
                        dex.quickReturn(code, "int", 1);
                        saveDex();
                        refresh();
                    } else if (s.equals("Return false / 0")) {
                        dex.quickReturn(code, "int", 0);
                        saveDex();
                        refresh();
                    } else if (s.equals("Return null")) {
                        dex.quickReturn(code, "object", 0);
                        saveDex();
                        refresh();
                    } else if (s.equals("Return 0")) {
                        dex.quickReturn(code, "wide", 0);
                        saveDex();
                        refresh();
                    } else if (s.equals("Return a number...")) {
                        input("Number to return", "0, 1, -1, 0x10", "1", false, new Ui.OnText() {
                            @Override
                            public void on(String v) {
                                try {
                                    String t = v.trim();
                                    long n = t.startsWith("0x") ? Long.parseLong(t.substring(2), 16) : Long.parseLong(t);
                                    dex.quickReturn(code, "int", n);
                                    saveDex();
                                    refresh();
                                } catch (Throwable e) {
                                    err(e);
                                }
                            }
                        });
                    }
                } catch (Throwable e) {
                    err(e);
                }
            }
        });
    }

    private void dexStrings() {
        final Searcher s = new Searcher() {
            @Override
            public List<LRow> run(String q) {
                List<LRow> out = new ArrayList<LRow>();
                for (Integer i : dex.findStrings(q, 400)) {
                    out.add(new LRow(oneLine(dex.str(i.intValue()), 160), "#" + i + "   " + dex.stringBytes(i.intValue()) + " bytes", i.intValue()));
                }
                return out;
            }
        };
        showList("Dex strings", "shows the first 400 matches - search to find more", s.run(""), s, "", new OnRow() {
            @Override
            public void on(final LRow r) {
                editDexString(r.tag);
            }
        }, null, null, null);
    }

    private void editDexString(final int idx) {
        final EditText e = Ui.edit(this, "text");
        e.setSingleLine(false);
        e.setMinLines(3);
        e.setGravity(Gravity.TOP);
        e.setTypeface(Typeface.MONOSPACE);
        e.setText(dex.str(idx));
        final CheckBox pad = new CheckBox(this);
        pad.setText("Pad a shorter text with spaces");
        pad.setTextColor(Ui.TEXT);
        pad.setChecked(true);
        TextView info = Ui.text(this, "String #" + idx + " has room for " + dex.stringBytes(idx)
                + " bytes. The text cannot be longer than that (a dex cannot grow without being rebuilt).", 12.5f, Ui.SUB, false);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(8), dp(18), 0);
        col.addView(e, new LinearLayout.LayoutParams(MATCH, WRAP));
        col.addView(pad);
        col.addView(info);
        AlertDialog d = Ui.dialog(this).setTitle("Edit string").setView(col)
                .setPositiveButton("OK", (dd, w) -> {
                    try {
                        dex.setString(idx, e.getText().toString(), pad.isChecked());
                        saveDex();
                        refresh();
                    } catch (Throwable t) {
                        err(t);
                    }
                }).setNegativeButton("Cancel", null).create();
        d.getWindow().setBackgroundDrawable(Ui.round(this, Ui.CARD, 18));
        d.show();
    }

    private void dexMethodSearch() {
        final Searcher s = new Searcher() {
            @Override
            public List<LRow> run(String q) {
                List<LRow> out = new ArrayList<LRow>();
                for (Integer i : dex.findMethods(q, 400)) {
                    out.add(new LRow(dex.methodRef(i.intValue()), "method #" + i, i.intValue()));
                }
                return out;
            }
        };
        showList("Dex method search", "first 400 matches", s.run(""), s, "", new OnRow() {
            @Override
            public void on(LRow r) {
                final int[] loc = dex.locateMethod(r.tag);
                if (loc == null) {
                    Toast.makeText(NixuActivity.this, "Not defined in this dex (it is called from here only)", Toast.LENGTH_LONG).show();
                    return;
                }
                try {
                    NixuDex.ClassInfo ci = dex.classInfo(loc[0]);
                    if (ci.methods.get(loc[1]).codeOff == 0) {
                        Toast.makeText(NixuActivity.this, "This method has no code", Toast.LENGTH_SHORT).show();
                        return;
                    }
                } catch (IOException e) {
                    err(e);
                    return;
                }
                push(new Runnable() {
                    @Override
                    public void run() {
                        dexMethod(loc[0], loc[1]);
                    }
                });
            }
        }, null, null, null);
    }

    // =======================================================================================
    // save, sign, export
    // =======================================================================================

    private void saveSigned() {
        if (busy) return;
        final NixuZip.Plan plan = new NixuZip.Plan();
        plan.delete.addAll(deleted);
        plan.put.putAll(staged);
        async("Building and signing...", new Callable<File>() {
            @Override
            public File call() throws Exception {
                File outDir = new File(getCacheDir(), "out");
                outDir.mkdirs();
                File tmp = new File(outDir, "nixu_unsigned.apk");
                NixuZip.rewrite(apk, tmp, plan);
                File out = new File(outDir, safeName(label) + "_nixu.apk");
                Patcher.sign(NixuActivity.this, tmp, out);
                tmp.delete();
                return out;
            }
        }, new Consumer<File>() {
            @Override
            public void accept(File out) {
                lastOut = out;
                final String[] items = {"Install", "Share", "Save a copy..."};
                AlertDialog d = Ui.dialog(NixuActivity.this).setTitle("Saved and signed (" + NixuExport.size(out.length()) + ")")
                        .setItems(items, (dd, w) -> {
                            if (w == 0) install();
                            else if (w == 1) shareFile(lastOut, "application/vnd.android.package-archive", "Share APK");
                            else saveCopy(lastOut, safeName(label) + "_nixu.apk", "application/vnd.android.package-archive", REQ_SAVE_APK);
                        }).setNegativeButton("Close", null).create();
                d.getWindow().setBackgroundDrawable(Ui.round(NixuActivity.this, Ui.CARD, 18));
                d.show();
            }
        });
    }

    private void install() {
        if (!getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Allow \"Install unknown apps\" for Live Editor, then tap Install again", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(FileProvider.getUriForFile(this, getPackageName() + ".files", lastOut), "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }

    private void shareFile(File f, String mime, String chooser) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(this, getPackageName() + ".files", f));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, chooser));
    }

    private void saveCopy(File f, String name, String mime, int req) {
        pendingFile = f;
        pendingBytes = null;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, req);
    }

    /** Writes a text file into the cache and offers share / save. */
    private void shareText(final String name, final String text) {
        async("", new Callable<File>() {
            @Override
            public File call() throws Exception {
                File outDir = new File(getCacheDir(), "out");
                outDir.mkdirs();
                File f = new File(outDir, name);
                OutputStream os = new FileOutputStream(f);
                try {
                    os.write(text.getBytes("UTF-8"));
                } finally {
                    os.close();
                }
                return f;
            }
        }, new Consumer<File>() {
            @Override
            public void accept(final File f) {
                final String[] items = {"Share", "Save to phone..."};
                AlertDialog d = Ui.dialog(NixuActivity.this).setTitle(name + " (" + NixuExport.size(f.length()) + ")")
                        .setItems(items, (dd, w) -> {
                            if (w == 0) shareFile(f, "text/plain", "Send text file");
                            else saveCopy(f, name, "text/plain", REQ_SAVE_TXT);
                        }).setNegativeButton("Close", null).create();
                d.getWindow().setBackgroundDrawable(Ui.round(NixuActivity.this, Ui.CARD, 18));
                d.show();
            }
        });
    }

    private void exportDialog() {
        final String[] items = {"File list", "AndroidManifest.xml", "Resources (resources.arsc)", "Dex class list",
                "Dex methods of every class", "Smali text of some classes (asks a name filter)"};
        final boolean[] on = {true, true, true, true, false, false};
        AlertDialog d = Ui.dialog(this).setTitle("Export for Claude")
                .setMultiChoiceItems(items, on, (dd, which, checked) -> on[which] = checked)
                .setPositiveButton("Export", (dd, w) -> {
                    final NixuExport.Options o = new NixuExport.Options();
                    o.entries = on[0];
                    o.manifest = on[1];
                    o.arsc = on[2];
                    o.dexClasses = on[3];
                    o.dexMethods = on[4];
                    if (on[5]) {
                        input("Class filter for smali", "com.example.app (part of the class name)", "", false, new Ui.OnText() {
                            @Override
                            public void on(String s) {
                                o.smaliFilter = s.trim().length() == 0 ? null : s.trim();
                                runExport(o);
                            }
                        });
                    } else {
                        runExport(o);
                    }
                }).setNegativeButton("Cancel", null).create();
        d.getWindow().setBackgroundDrawable(Ui.round(this, Ui.CARD, 18));
        d.show();
    }

    private void runExport(final NixuExport.Options o) {
        final NixuExport.Source src = new NixuExport.Source() {
            @Override
            public List<NixuZip.E> list() {
                List<NixuZip.E> l = new ArrayList<NixuZip.E>();
                for (Meta m : files.values()) {
                    NixuZip.E e = origByName.get(m.name);
                    if (e == null || staged.containsKey(m.name)) {
                        e = new NixuZip.E();
                        e.name = m.name;
                        e.size = m.size;
                        e.compSize = m.size;
                    }
                    l.add(e);
                }
                return l;
            }

            @Override
            public byte[] read(String name) throws IOException {
                return NixuActivity.this.read(name);
            }

            @Override
            public boolean changed(String name) {
                return isChanged(name);
            }
        };
        async("Building the text file...", new Callable<String>() {
            @Override
            public String call() {
                return NixuExport.build(src, o, label + ".apk");
            }
        }, new Consumer<String>() {
            @Override
            public void accept(String text) {
                shareText(safeName(label) + ".nixu.txt", text);
            }
        });
    }
}
