package com.liveedit.agent;

import android.os.Looper;

/**
 * Best-effort help for apps that were made to run on a CPU their native libraries do not fit (see "Make it run on my
 * phone"). Those libraries are replaced by empty stand-ins, so every call into them fails with an UnsatisfiedLinkError.
 * Instead of letting that close the app, the error is logged and the app carries on without that feature.
 * Any other crash is passed on untouched. If it keeps happening in a loop, the guard stops and lets the app close.
 */
final class Guard {
    private static boolean installed;
    private static int swallowed;
    private static long windowStart;

    private Guard() {}

    static synchronized void install() {
        if (installed) return;
        installed = true;
        try {
            final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                @Override
                public void uncaughtException(Thread t, Throwable e) {
                    if (!isMissingLibrary(e) || !allow()) {
                        pass(prev, t, e);
                        return;
                    }
                    U.err("native library missing on this CPU, app carries on", e);
                    Looper main = Looper.getMainLooper();
                    if (main == null || t != main.getThread()) return; // only that one worker thread ends
                    // The main thread must keep serving the screen: start its message loop again.
                    while (true) {
                        try {
                            Looper.loop();
                            return;
                        } catch (Throwable x) {
                            if (!isMissingLibrary(x) || !allow()) {
                                pass(prev, Thread.currentThread(), x);
                                return;
                            }
                            U.err("native library missing on this CPU, app carries on", x);
                        }
                    }
                }
            });
            U.log("native library guard installed");
        } catch (Throwable t) {
            U.err("native library guard not installed", t);
        }
    }

    private static void pass(Thread.UncaughtExceptionHandler prev, Thread t, Throwable e) {
        if (prev != null) {
            prev.uncaughtException(t, e);
        } else {
            System.exit(10);
        }
    }

    /** UnsatisfiedLinkError anywhere in the cause chain, or a class that could not start because of it. */
    private static boolean isMissingLibrary(Throwable e) {
        int depth = 0;
        Throwable c = e;
        while (c != null && depth < 10) {
            if (c instanceof UnsatisfiedLinkError) return true;
            if (c instanceof NoClassDefFoundError) {
                String m = c.getMessage();
                if (m != null && m.contains("Could not initialize class")) return true;
            }
            c = c.getCause();
            depth++;
        }
        return false;
    }

    /** At most 40 swallowed errors in 10 seconds, so a crash loop still ends the app. */
    private static synchronized boolean allow() {
        long now = System.currentTimeMillis();
        if (now - windowStart > 10000L) {
            windowStart = now;
            swallowed = 0;
        }
        swallowed++;
        return swallowed <= 40;
    }
}
