package com.liveedit.agent;

import android.os.Build;

import java.lang.reflect.Method;

/** Best effort: asks Android to let this app use its own hidden framework fields (window list, activity list). */
final class Hidden {
    private static boolean done;

    private Hidden() {}

    static synchronized void exempt() {
        if (done) return;
        done = true;
        if (Build.VERSION.SDK_INT < 28) return;
        try {
            Method forName = Class.class.getDeclaredMethod("forName", String.class);
            Method getDeclaredMethod = Class.class.getDeclaredMethod("getDeclaredMethod", String.class, Class[].class);
            Class<?> vm = (Class<?>) forName.invoke(null, "dalvik.system.VMRuntime");
            Method getRuntime = (Method) getDeclaredMethod.invoke(vm, "getRuntime", null);
            Method set = (Method) getDeclaredMethod.invoke(vm, "setHiddenApiExemptions", new Class[] {String[].class});
            Object rt = getRuntime.invoke(null);
            set.invoke(rt, new Object[] {new String[] {"L"}});
        } catch (Throwable t) {
            U.log("hidden api exemption not available");
        }
    }
}
