package com.liveedit.agent;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Saved edits. One rule = one view (found by selector) on one Activity class, plus the
 * properties to force on it. Rules are re-applied every time that screen opens, so no
 * rebuilding is needed.
 *
 * File: <app files dir>/liveedit_rules.json
 * Props: text, textSize(sp), textColor, bg, alpha, vis(visible|invisible|gone), w, h (dp, -1, -2), tint
 */
final class Rules {

    static final class Rule {
        String act;
        String sel;
        JSONObject props = new JSONObject();
    }

    private static final ArrayList<Rule> LIST = new ArrayList<Rule>();
    private static File file;

    private Rules() {}

    static void load(Context c) {
        file = new File(c.getFilesDir(), "liveedit_rules.json");
        LIST.clear();
        try {
            if (!file.exists()) return;
            JSONArray arr = new JSONObject(U.readAll(file)).optJSONArray("rules");
            if (arr == null) return;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Rule r = new Rule();
                r.act = o.getString("act");
                r.sel = o.getString("sel");
                JSONObject p = o.optJSONObject("props");
                if (p != null) r.props = p;
                LIST.add(r);
            }
            U.log("loaded " + LIST.size() + " rules");
        } catch (Throwable t) {
            U.err("load rules", t);
        }
    }

    static String toJson() {
        try {
            JSONArray arr = new JSONArray();
            for (Rule r : LIST) {
                JSONObject o = new JSONObject();
                o.put("act", r.act);
                o.put("sel", r.sel);
                o.put("props", r.props);
                arr.put(o);
            }
            JSONObject root = new JSONObject();
            root.put("rules", arr);
            return root.toString(2);
        } catch (Throwable t) {
            U.err("rules to json", t);
            return "{}";
        }
    }

    private static void save() {
        try {
            if (file != null) U.write(file, toJson());
        } catch (Throwable t) {
            U.err("save rules", t);
        }
    }

    static int count() {
        return LIST.size();
    }

    static List<Rule> all() {
        return new ArrayList<Rule>(LIST);
    }

    static boolean hasFor(String act) {
        for (int i = 0; i < LIST.size(); i++) {
            if (LIST.get(i).act.equals(act)) return true;
        }
        return false;
    }

    static List<Rule> forActivity(String act) {
        ArrayList<Rule> out = new ArrayList<Rule>();
        for (int i = 0; i < LIST.size(); i++) {
            if (LIST.get(i).act.equals(act)) out.add(LIST.get(i));
        }
        return out;
    }

    static Rule find(String act, String sel) {
        for (int i = 0; i < LIST.size(); i++) {
            Rule r = LIST.get(i);
            if (r.act.equals(act) && r.sel.equals(sel)) return r;
        }
        return null;
    }

    static void put(String act, String sel, JSONObject props) {
        Rule r = find(act, sel);
        if (r == null) {
            r = new Rule();
            r.act = act;
            r.sel = sel;
            LIST.add(r);
        }
        r.props = props;
        save();
    }

    static void remove(String act, String sel) {
        Rule r = find(act, sel);
        if (r != null) {
            LIST.remove(r);
            save();
        }
    }

    static void clear() {
        LIST.clear();
        save();
    }
}
