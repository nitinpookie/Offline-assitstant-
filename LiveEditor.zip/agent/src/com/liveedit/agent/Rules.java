package com.liveedit.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

/**
 * Per-item choices (size, colour, name, opacity, hidden) for single buttons, menus, icons and texts.
 * "baked" rules come from the APK, "live" rules are the ones edited with the pencil handle.
 * A live rule always wins over a baked rule with the same key.
 */
final class Rules {
    static final int NONE = Integer.MIN_VALUE;

    static final class Rule {
        final String key;
        /** null = automatic; otherwise "menu", "button" or "icon" (window roots only). */
        String kind;
        /** dp. For a window root, "w" is the whole size (width) of that floating window. */
        int w = NONE;
        int h = NONE;
        /** percent 10..100 */
        int alpha = NONE;
        /** text size in dp */
        int text = NONE;
        int textColor = NONE;
        /** background colour (icons: tint) */
        int bgColor = NONE;
        String name;
        boolean hide;

        Rule(String key) {
            this.key = key;
        }

        boolean isEmpty() {
            return kind == null && w == NONE && h == NONE && alpha == NONE && text == NONE
                    && textColor == NONE && bgColor == NONE && name == null && !hide;
        }

        Rule copy() {
            Rule r = new Rule(key);
            r.kind = kind;
            r.w = w;
            r.h = h;
            r.alpha = alpha;
            r.text = text;
            r.textColor = textColor;
            r.bgColor = bgColor;
            r.name = name;
            r.hide = hide;
            return r;
        }

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("k", key);
            if (kind != null) o.put("kd", kind);
            if (w != NONE) o.put("w", w);
            if (h != NONE) o.put("h", h);
            if (alpha != NONE) o.put("a", alpha);
            if (text != NONE) o.put("t", text);
            if (textColor != NONE) o.put("tc", textColor);
            if (bgColor != NONE) o.put("bc", bgColor);
            if (name != null) o.put("n", name);
            if (hide) o.put("hd", true);
            return o;
        }

        static Rule fromJson(JSONObject o) {
            String k = o.optString("k", "");
            if (k.length() == 0) return null;
            Rule r = new Rule(k);
            r.kind = o.has("kd") ? o.optString("kd") : null;
            r.w = o.has("w") ? o.optInt("w") : NONE;
            r.h = o.has("h") ? o.optInt("h") : NONE;
            r.alpha = o.has("a") ? o.optInt("a") : NONE;
            r.text = o.has("t") ? o.optInt("t") : NONE;
            r.textColor = o.has("tc") ? o.optInt("tc") : NONE;
            r.bgColor = o.has("bc") ? o.optInt("bc") : NONE;
            r.name = o.has("n") ? o.optString("n") : null;
            r.hide = o.optBoolean("hd", false);
            return r;
        }
    }

    private static final HashMap<String, Rule> baked = new HashMap<String, Rule>();
    private static final HashMap<String, Rule> live = new HashMap<String, Rule>();

    private Rules() {}

    static void loadBaked(JSONArray a) {
        baked.clear();
        fill(baked, a);
    }

    static void loadLive(JSONArray a) {
        live.clear();
        fill(live, a);
    }

    private static void fill(HashMap<String, Rule> into, JSONArray a) {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            Rule r = Rule.fromJson(o);
            if (r != null) into.put(r.key, r);
        }
    }

    static boolean hasAny() {
        return !baked.isEmpty() || !live.isEmpty();
    }

    /** The rule that applies to this item, or null when nothing is set for it. */
    static Rule get(String key) {
        Rule r = live.get(key);
        if (r == null) r = baked.get(key);
        return (r == null || r.isEmpty()) ? null : r;
    }

    /** A rule that can be changed (it is stored with the live edits). */
    static Rule edit(String key) {
        Rule r = live.get(key);
        if (r == null) {
            Rule b = baked.get(key);
            r = b == null ? new Rule(key) : b.copy();
            live.put(key, r);
        }
        return r;
    }

    static void clearLive() {
        live.clear();
    }

    /** Forget every rule (also the ones from the APK) until the app is restarted. */
    static void resetAll() {
        live.clear();
        for (String k : baked.keySet()) live.put(k, new Rule(k));
    }

    static JSONArray liveArray() throws Exception {
        JSONArray a = new JSONArray();
        for (Rule r : live.values()) a.put(r.toJson());
        return a;
    }

    /** Baked rules with live edits on top, empty ones left out. */
    static JSONArray mergedArray() throws Exception {
        HashMap<String, Rule> m = new HashMap<String, Rule>(baked);
        m.putAll(live);
        JSONArray a = new JSONArray();
        for (Rule r : m.values()) {
            if (!r.isEmpty()) a.put(r.toJson());
        }
        return a;
    }
}
