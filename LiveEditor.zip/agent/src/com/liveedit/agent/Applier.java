package com.liveedit.agent;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;
import java.util.WeakHashMap;

/**
 * Applies rule properties to views. Every property is only written when it differs from the
 * current value, so calling this repeatedly (after every layout pass) is cheap and never loops.
 */
final class Applier {

    private static final WeakHashMap<View, Integer> TINTS = new WeakHashMap<View, Integer>();

    private Applier() {}

    static void applyAll(Activity a, View decor) {
        List<Rules.Rule> rs = Rules.forActivity(a.getClass().getName());
        for (int i = 0; i < rs.size(); i++) {
            Rules.Rule r = rs.get(i);
            try {
                View v = Sel.resolve(decor, r.sel);
                if (v != null) apply(v, r.props);
            } catch (Throwable t) {
                U.err("apply " + r.sel, t);
            }
        }
    }

    static void apply(View v, JSONObject p) {
        DisplayMetrics dm = v.getResources().getDisplayMetrics();

        if (v instanceof TextView) {
            TextView t = (TextView) v;
            if (p.has("text")) {
                String s = p.optString("text");
                if (!s.contentEquals(t.getText())) t.setText(s);
            }
            if (p.has("textSize")) {
                float sp = (float) p.optDouble("textSize");
                float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, dm);
                if (Math.abs(t.getTextSize() - px) > 0.5f) {
                    t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
                }
            }
            if (p.has("textColor")) {
                Integer col = U.parseColor(p.optString("textColor"));
                if (col != null && t.getCurrentTextColor() != col.intValue()) {
                    t.setTextColor(col.intValue());
                }
            }
        }

        if (p.has("bg")) {
            Integer col = U.parseColor(p.optString("bg"));
            if (col != null) {
                Drawable bg = v.getBackground();
                boolean same = bg instanceof ColorDrawable
                        && ((ColorDrawable) bg).getColor() == col.intValue();
                if (!same) v.setBackgroundColor(col.intValue());
            }
        }

        if (p.has("alpha")) {
            float a = (float) p.optDouble("alpha");
            if (Math.abs(v.getAlpha() - a) > 0.001f) v.setAlpha(a);
        }

        if (p.has("vis")) {
            int vis = visOf(p.optString("vis"));
            if (v.getVisibility() != vis) v.setVisibility(vis);
        }

        if (p.has("w") || p.has("h")) {
            ViewGroup.LayoutParams lp = v.getLayoutParams();
            if (lp != null) {
                boolean changed = false;
                if (p.has("w")) {
                    int w = dim(p.optInt("w"), dm);
                    if (lp.width != w) {
                        lp.width = w;
                        changed = true;
                    }
                }
                if (p.has("h")) {
                    int h = dim(p.optInt("h"), dm);
                    if (lp.height != h) {
                        lp.height = h;
                        changed = true;
                    }
                }
                if (changed) v.setLayoutParams(lp);
            }
        }

        if (v instanceof ImageView && p.has("tint")) {
            Integer col = U.parseColor(p.optString("tint"));
            if (col != null) {
                ImageView iv = (ImageView) v;
                Integer last = TINTS.get(v);
                if (last == null || last.intValue() != col.intValue() || iv.getColorFilter() == null) {
                    iv.setColorFilter(col.intValue());
                    TINTS.put(v, col);
                }
            }
        }
    }

    private static int visOf(String s) {
        if ("gone".equals(s)) return View.GONE;
        if ("invisible".equals(s)) return View.INVISIBLE;
        return View.VISIBLE;
    }

    /** dp value to px; -1 (match parent) and -2 (wrap content) pass through. */
    private static int dim(int v, DisplayMetrics dm) {
        if (v < 0) return v;
        return Math.round(v * dm.density);
    }
}
