package com.liveedit.agent;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Lives inside the target app's process.
 *
 * - Watches every Activity (lifecycle callbacks).
 * - Some packed apps swap their Application object, which silences the callbacks. For those, a
 *   light fallback poll reads the running activities straight from ActivityThread.
 * - Adds the floating "UI" button to each Activity and re-applies saved rules after layout passes,
 *   so views that appear late (after the real classes.dex is loaded, lists, fragments) get edited too.
 */
public final class Agent implements Application.ActivityLifecycleCallbacks {

    private static Agent inst;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final HashMap<Activity, State> states = new HashMap<Activity, State>();
    private boolean callbacksWork;

    private static final class State {
        View button;
        boolean pending;
        String actName;
        Runnable applyRun;
        ViewTreeObserver.OnGlobalLayoutListener layoutListener;
    }

    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            try {
                poll();
            } catch (Throwable t) {
                U.err("poll", t);
            }
            if (!callbacksWork) handler.postDelayed(this, 1000);
        }
    };

    private Agent() {}

    static synchronized void start(Application app) {
        if (inst != null) return;
        inst = new Agent();
        Rules.load(app);
        app.registerActivityLifecycleCallbacks(inst);
        inst.handler.postDelayed(inst.poller, 800);
        U.log("Live Editor started in " + app.getPackageName());
    }

    // ---- lifecycle -------------------------------------------------------------------------

    @Override
    public void onActivityResumed(Activity a) {
        callbacksWork = true;
        try {
            attach(a);
        } catch (Throwable t) {
            U.err("resume", t);
        }
    }

    @Override
    public void onActivityDestroyed(Activity a) {
        states.remove(a);
    }

    @Override
    public void onActivityCreated(Activity a, Bundle b) {}

    @Override
    public void onActivityStarted(Activity a) {}

    @Override
    public void onActivityPaused(Activity a) {}

    @Override
    public void onActivityStopped(Activity a) {}

    @Override
    public void onActivitySaveInstanceState(Activity a, Bundle b) {}

    // ---- fallback for apps that swap their Application ------------------------------------

    private void poll() throws Exception {
        Iterator<Map.Entry<Activity, State>> it = states.entrySet().iterator();
        while (it.hasNext()) {
            Activity a = it.next().getKey();
            if (a.isDestroyed() || a.isFinishing()) it.remove();
        }
        Class<?> atc = Class.forName("android.app.ActivityThread");
        Object thread = atc.getMethod("currentActivityThread").invoke(null);
        if (thread == null) return;
        Field f = atc.getDeclaredField("mActivities");
        f.setAccessible(true);
        Object map = f.get(thread);
        if (!(map instanceof Map)) return;
        for (Object rec : ((Map<?, ?>) map).values()) {
            Field af = rec.getClass().getDeclaredField("activity");
            af.setAccessible(true);
            Object act = af.get(rec);
            if (act instanceof Activity) {
                Activity a = (Activity) act;
                if (!a.isFinishing() && !a.isDestroyed() && !states.containsKey(a)) attach(a);
            }
        }
    }

    // ---- per-activity setup -----------------------------------------------------------------

    private void attach(final Activity a) {
        Window w = a.getWindow();
        if (w == null) return;
        View dv = w.peekDecorView();
        if (!(dv instanceof ViewGroup)) return;
        ViewGroup decor = (ViewGroup) dv;

        State s = states.get(a);
        if (s == null) {
            s = new State();
            s.actName = a.getClass().getName();
            states.put(a, s);
            final State st = s;
            st.applyRun = new Runnable() {
                @Override
                public void run() {
                    st.pending = false;
                    applyRules(a);
                }
            };
            st.layoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    if (!st.pending && Rules.hasFor(st.actName)) {
                        st.pending = true;
                        handler.postDelayed(st.applyRun, 120);
                    }
                }
            };
        }

        // Re-register on every resume: the window may have been re-attached to a new root.
        ViewTreeObserver vto = decor.getViewTreeObserver();
        if (vto.isAlive()) {
            vto.removeOnGlobalLayoutListener(s.layoutListener);
            vto.addOnGlobalLayoutListener(s.layoutListener);
        }

        if (s.button == null || s.button.getParent() != decor) {
            s.button = Ui.addButton(a, decor);
        }
        applyRules(a);
    }

    private void applyRules(Activity a) {
        try {
            Window w = a.getWindow();
            View dv = w == null ? null : w.peekDecorView();
            if (dv != null) Applier.applyAll(a, dv);
        } catch (Throwable t) {
            U.err("applyRules", t);
        }
    }
}
