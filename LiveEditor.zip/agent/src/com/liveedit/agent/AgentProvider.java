package com.liveedit.agent;

import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

/**
 * Added to the target app's manifest. Android creates providers before Application.onCreate(),
 * so this is the earliest, cleanest entry point into the process. Nothing here may ever throw,
 * otherwise the host app would crash on launch.
 */
public final class AgentProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        try {
            Context c = getContext();
            if (c != null) {
                Context ac = c.getApplicationContext();
                if (ac instanceof Application) {
                    Agent.start((Application) ac);
                } else {
                    U.log("no Application context, agent not started");
                }
            }
        } catch (Throwable t) {
            U.err("provider start failed", t);
        }
        return true;
    }

    /**
     * Gives the current settings (baked edits plus live edits) to the Live Editor app, so it can build a normal APK
     * without copy and paste. Only the Live Editor app itself gets an answer; everybody else gets nothing.
     */
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        try {
            if (!"com.liveedit.patcher".equals(getCallingPackage())) return null;
            MatrixCursor c = new MatrixCursor(new String[] {"json"});
            c.addRow(new Object[] {Config.exportJson()});
            return c;
        } catch (Throwable t) {
            U.err("settings query failed", t);
            return null;
        }
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] args) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] args) {
        return 0;
    }
}
