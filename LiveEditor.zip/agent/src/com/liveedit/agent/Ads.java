package com.liveedit.agent;

import android.view.View;
import android.view.ViewGroup;

/** Hides banner and native-ad views that come from well-known ad SDKs. */
final class Ads {

    private static final String[] PREFIXES = {
            "com.google.android.gms.ads.", "com.google.ads.", "com.facebook.ads.", "com.applovin.",
            "com.unity3d.ads.", "com.unity3d.services.banners.", "com.mopub.", "com.ironsource.",
            "com.startapp.", "com.vungle.", "com.chartboost.", "com.inmobi.", "com.bytedance.sdk.openadsdk.",
            "com.adcolony.", "com.yandex.mobile.ads.", "net.pubnative.", "com.smaato.", "com.mbridge.msdk.",
            "com.my.target.", "com.amazon.device.ads.", "com.fyber.", "com.tapjoy."
    };

    private Ads() {}

    static void hide(View v) {
        if (v == null) return;
        if (isAd(v.getClass().getName())) {
            if (v.getVisibility() != View.GONE) v.setVisibility(View.GONE);
            return;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) hide(g.getChildAt(i));
        }
    }

    private static boolean isAd(String cls) {
        for (int i = 0; i < PREFIXES.length; i++) {
            if (cls.startsWith(PREFIXES[i])) return true;
        }
        return false;
    }
}
