package com.liveedit.agent;

import android.app.Application;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * The live editor: a small pencil handle that opens a panel. The panel lists every visible menu, button, icon and
 * text (overlays and app screens) and lets you change size (dp), colour, name, opacity or hide each one, plus the
 * global button/menu sizes and the app theme. Changes show at once and are kept; "Copy settings" exports them so
 * the Live Editor app can build a normal APK (no handle) with these edits inside.
 * Only exists when the APK was patched with "Live Editor inside the app".
 */
final class Panel {
    static final String TAG = "liveedit-own";

    private static final int BG = 0xF2171A21;
    private static final int CARD = 0xFF262B36;
    private static final int TEXT = 0xFFECEFF4;
    private static final int SUB = 0xFF9AA3B2;
    private static final int ACC = 0xFF7C5CFF;

    private static final String[] PRESET_NAMES = {"Dark", "AMOLED", "Light", "Blue", "Green", "Purple", "Red"};
    private static final int[][] PRESETS = {
            {0xFF101418, 0xFFECEFF4, 0xFF7C5CFF},
            {0xFF000000, 0xFFFFFFFF, 0xFF00E5FF},
            {0xFFF4F5F7, 0xFF111418, 0xFF2563EB},
            {0xFF0B1B33, 0xFFE6F0FF, 0xFF3B82F6},
            {0xFF0B2016, 0xFFE6FFF1, 0xFF22C55E},
            {0xFF1A1030, 0xFFF1E9FF, 0xFFA855F7},
            {0xFF240C0C, 0xFFFFECEC, 0xFFEF4444}
    };

    private interface IntCb {
        void on(int v);
    }

    private static Panel inst;
    private static boolean asked;

    private final Application app;
    private final Context ctx;
    private final WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());

    private TextView handle;
    private WindowManager.LayoutParams hlp;
    private LinearLayout panel;
    private WindowManager.LayoutParams plp;
    private LinearLayout body;
    private ScrollView scroll;
    private boolean open;

    private int tab;      // 0 items, 1 global, 2 theme, 3 more
    private int filter;   // 0 all, 1 menu, 2 buttons, 3 icons, 4 app
    private Overlays.El editing;

    private final Runnable ensure = new Runnable() {
        @Override
        public void run() {
            try {
                if (handle == null) tryAddHandle();
            } catch (Throwable t) {
                U.err("handle", t);
            }
            if (handle == null) h.postDelayed(this, 2500);
        }
    };

    static boolean isOwn(View v) {
        return v != null && TAG.equals(v.getTag());
    }

    static synchronized void start(Application app) {
        if (inst != null) return;
        try {
            inst = new Panel(app);
            inst.h.postDelayed(inst.ensure, 800);
        } catch (Throwable t) {
            U.err("panel", t);
        }
    }

    private Panel(Application app) {
        this.app = app;
        this.ctx = new ContextThemeWrapper(app, android.R.style.Theme_Material);
        this.wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
    }

    // ---- handle ----------------------------------------------------------------------------

    private static int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
    }

    private int dp(float v) {
        return U.dp(ctx, v);
    }

    private void toast(String s) {
        try {
            Toast.makeText(app, s, Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            // ignore
        }
    }

    private void tryAddHandle() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(app)) {
            if (!asked) {
                asked = true;
                toast("Live Editor: allow \"Display over other apps\" for this app to use the pencil handle.");
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + app.getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    app.startActivity(i);
                } catch (Throwable t) {
                    U.err("overlay permission screen", t);
                }
            }
            return;
        }
        final TextView t = new TextView(ctx);
        t.setText("\u270E");
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(ACC);
        t.setBackground(g);
        t.setAlpha(0.85f);
        t.setTag(TAG);

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(dp(44), dp(44), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = dp(4);
        lp.y = dp(120);
        hlp = lp;
        t.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int startX, startY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    startX = lp.x;
                    startY = lp.y;
                    downX = e.getRawX();
                    downY = e.getRawY();
                    moved = false;
                    return true;
                }
                if (a == MotionEvent.ACTION_MOVE) {
                    float dx = e.getRawX() - downX;
                    float dy = e.getRawY() - downY;
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                    if (moved) {
                        lp.x = startX + Math.round(dx);
                        lp.y = startY + Math.round(dy);
                        try {
                            wm.updateViewLayout(t, lp);
                        } catch (Throwable ex) {
                            // ignore
                        }
                    }
                    return true;
                }
                if (a == MotionEvent.ACTION_UP) {
                    if (!moved) toggle();
                    return true;
                }
                return false;
            }
        });
        wm.addView(t, lp);
        handle = t;
        U.log("live editor handle shown");
    }

    private void toggle() {
        if (open) closePanel();
        else openPanel();
    }

    private void closePanel() {
        open = false;
        editing = null;
        Config.saveLive(app);
        try {
            if (panel != null) wm.removeView(panel);
        } catch (Throwable t) {
            // ignore
        }
        panel = null;
    }

    private void openPanel() {
        try {
            int sw = app.getResources().getDisplayMetrics().widthPixels;
            int sh = app.getResources().getDisplayMetrics().heightPixels;
            panel = new LinearLayout(ctx);
            panel.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(BG);
            bg.setCornerRadius(dp(16));
            panel.setBackground(bg);
            panel.setPadding(dp(10), dp(8), dp(10), dp(8));
            panel.setTag(TAG);

            LinearLayout top = new LinearLayout(ctx);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            String[] tabs = {"Items", "Global", "Theme", "More"};
            for (int i = 0; i < tabs.length; i++) {
                final int which = i;
                TextView c = chip(tabs[i], tab == i);
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tab = which;
                        editing = null;
                        rebuildTop();
                        render();
                    }
                });
                top.addView(c, chipLp());
            }
            View sp = new View(ctx);
            top.addView(sp, new LinearLayout.LayoutParams(0, 1, 1f));
            TextView x = chip("\u2715", false);
            x.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closePanel();
                }
            });
            top.addView(x, chipLp());
            top.setTag("top");
            panel.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            scroll = new ScrollView(ctx);
            body = new LinearLayout(ctx);
            body.setOrientation(LinearLayout.VERTICAL);
            body.setPadding(0, dp(6), 0, dp(6));
            scroll.addView(body);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            slp.topMargin = dp(6);
            panel.addView(scroll, slp);

            int w = Math.min(dp(400), sw - dp(16));
            int hh = Math.min(dp(560), Math.round(sh * 0.78f));
            plp = new WindowManager.LayoutParams(w, hh, overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
            plp.gravity = Gravity.CENTER;
            plp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
            wm.addView(panel, plp);
            open = true;
            render();
        } catch (Throwable t) {
            U.err("open panel", t);
            toast("Live Editor could not open its panel.");
            panel = null;
            open = false;
        }
    }

    private void rebuildTop() {
        if (panel == null) return;
        View top = panel.findViewWithTag("top");
        if (!(top instanceof LinearLayout)) return;
        LinearLayout t = (LinearLayout) top;
        String[] tabs = {"Items", "Global", "Theme", "More"};
        for (int i = 0; i < tabs.length && i < t.getChildCount(); i++) {
            View c = t.getChildAt(i);
            if (c instanceof TextView) styleChip((TextView) c, tab == i);
        }
    }

    // ---- small view kit --------------------------------------------------------------------

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(6);
        return lp;
    }

    private TextView chip(String s, boolean on) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(13);
        t.setPadding(dp(11), dp(7), dp(11), dp(7));
        t.setClickable(true);
        styleChip(t, on);
        return t;
    }

    private void styleChip(TextView t, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? ACC : CARD);
        g.setCornerRadius(dp(14));
        t.setBackground(g);
        t.setTextColor(TEXT);
    }

    private TextView label(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void add(LinearLayout parent, View v, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topDp);
        parent.addView(v, lp);
    }

    private String fmt(String label, int v, int min, String unit, String zeroLabel) {
        String val = (zeroLabel != null && v == min) ? zeroLabel : (v + unit);
        return label + ":  " + val;
    }

    private void slider(LinearLayout parent, final String label, final int min, int max, int cur,
                        final String unit, final String zeroLabel, final IntCb cb) {
        final TextView head = label(fmt(label, cur, min, unit, zeroLabel), 13, TEXT, false);
        add(parent, head, 10);
        SeekBar sb = new SeekBar(ctx);
        sb.setMax(max - min);
        sb.setProgress(U.clamp(cur - min, 0, max - min));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                int v = min + p;
                head.setText(fmt(label, v, min, unit, zeroLabel));
                cb.on(v);
                Overlays.tick(app);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {}

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                Config.saveLive(app);
            }
        });
        add(parent, sb, 0);
    }

    /** Three sliders (red, green, blue) with a swatch. cur == NONE means "not set". */
    private void colorRow(LinearLayout parent, final String name, int cur, final boolean canClear, final IntCb cb) {
        final int[] rgb = cur == Rules.NONE ? new int[] {128, 128, 128}
                : new int[] {Color.red(cur), Color.green(cur), Color.blue(cur)};
        LinearLayout head = new LinearLayout(ctx);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        final View sw = new View(ctx);
        sw.setBackgroundColor(cur == Rules.NONE ? 0xFF808080 : (cur | 0xFF000000));
        head.addView(sw, new LinearLayout.LayoutParams(dp(26), dp(26)));
        final TextView t = label("  " + name + (cur == Rules.NONE ? ":  keep" : ":  " + hex(cur)), 13, TEXT, false);
        head.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (canClear) {
            TextView clr = chip("Clear", false);
            clr.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cb.on(Rules.NONE);
                    Config.saveLive(app);
                    Overlays.tick(app);
                    render();
                }
            });
            head.addView(clr);
        }
        add(parent, head, 12);
        String[] ch = {"R", "G", "B"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            SeekBar sb = new SeekBar(ctx);
            sb.setMax(255);
            sb.setProgress(rgb[i]);
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                    if (!fromUser) return;
                    rgb[idx] = p;
                    int c = Color.rgb(rgb[0], rgb[1], rgb[2]);
                    sw.setBackgroundColor(c);
                    t.setText("  " + name + ":  " + hex(c));
                    cb.on(c);
                    Overlays.tick(app);
                }

                @Override
                public void onStartTrackingTouch(SeekBar s) {}

                @Override
                public void onStopTrackingTouch(SeekBar s) {
                    Config.saveLive(app);
                }
            });
            add(parent, sb, 0);
        }
    }

    private static String hex(int c) {
        return String.format(java.util.Locale.US, "#%06X", c & 0xFFFFFF);
    }

    private void note(LinearLayout parent, String s) {
        TextView t = label(s, 11.5f, SUB, false);
        add(parent, t, 8);
    }

    // ---- screens ---------------------------------------------------------------------------

    private void render() {
        if (body == null) return;
        body.removeAllViews();
        try {
            if (tab == 0) {
                if (editing != null) renderEdit();
                else renderList();
            } else if (tab == 1) {
                renderGlobal();
            } else if (tab == 2) {
                renderTheme();
            } else {
                renderMore();
            }
        } catch (Throwable t) {
            U.err("render", t);
            note(body, "Could not draw this screen: " + t);
        }
        if (scroll != null) scroll.scrollTo(0, 0);
    }

    private boolean matches(Overlays.El e) {
        if (filter == 0) return true;
        if (filter == 1) return "menu".equals(e.group);
        if (filter == 2) return "button".equals(e.group);
        if (filter == 3) return "icon".equals(e.group);
        return "app".equals(e.group);
    }

    private void renderList() {
        LinearLayout fr = new LinearLayout(ctx);
        fr.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"All", "Menu", "Buttons", "Icons", "App"};
        for (int i = 0; i < names.length; i++) {
            final int which = i;
            TextView c = chip(names[i], filter == i);
            c.setTextSize(12);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    filter = which;
                    render();
                }
            });
            fr.addView(c, chipLp());
        }
        TextView rf = chip("\u21BB", false);
        rf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                render();
            }
        });
        fr.addView(rf, chipLp());
        body.addView(fr);

        List<Overlays.El> all = Overlays.collect(app);
        int shown = 0;
        for (int i = 0; i < all.size(); i++) {
            final Overlays.El e = all.get(i);
            if (!matches(e)) continue;
            shown++;
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            GradientDrawable g = new GradientDrawable();
            g.setColor(CARD);
            g.setCornerRadius(dp(10));
            row.setBackground(g);
            boolean edited = Rules.get(e.o.key) != null;
            row.addView(label((edited ? "\u270E " : "") + e.name, 14, TEXT, true));
            row.addView(label(e.sub, 11, SUB, false));
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editing = e;
                    render();
                }
            });
            add(body, row, 6);
        }
        if (shown == 0) {
            note(body, "Nothing found here. Open the menu or screen you want to edit in the app, then tap \u21BB. "
                    + "Only things that are visible right now are listed.");
        } else {
            note(body, shown + " items. \u270E = already edited. Tap one to change it.");
        }
    }

    private void renderEdit() {
        final Overlays.El e = editing;
        final Rules.Rule r = Rules.edit(e.o.key);
        TextView back = chip("\u2039 Back to list", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editing = null;
                render();
            }
        });
        body.addView(back);
        add(body, label(e.name, 15, TEXT, true), 8);
        add(body, label(e.sub, 11, SUB, false), 0);

        if (e.isText && !(e.view instanceof EditText)) {
            add(body, label("Name (text shown)", 13, TEXT, false), 12);
            final EditText box = new EditText(ctx);
            box.setSingleLine(true);
            box.setTextColor(TEXT);
            box.setTextSize(14);
            box.setText(r.name != null ? r.name : ((TextView) e.view).getText());
            add(body, box, 4);
            LinearLayout br = new LinearLayout(ctx);
            br.setOrientation(LinearLayout.HORIZONTAL);
            TextView set = chip("Set name", true);
            set.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String s = box.getText().toString();
                    r.name = s.length() == 0 ? null : s;
                    Config.saveLive(app);
                    Overlays.tick(app);
                    toast("Name set");
                }
            });
            TextView orig = chip("Original name", false);
            orig.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    r.name = null;
                    Config.saveLive(app);
                    Overlays.tick(app);
                    render();
                }
            });
            br.addView(set, chipLp());
            br.addView(orig, chipLp());
            add(body, br, 6);
        }

        if (e.root) {
            slider(body, "Size (width, now " + e.wDp + " dp)", 0, 600, r.w == Rules.NONE ? 0 : r.w, " dp", "keep",
                    new IntCb() {
                        @Override
                        public void on(int v) {
                            r.w = v == 0 ? Rules.NONE : v;
                        }
                    });
        } else {
            slider(body, "Width (now " + e.wDp + " dp)", 0, 500, r.w == Rules.NONE ? 0 : r.w, " dp", "keep",
                    new IntCb() {
                        @Override
                        public void on(int v) {
                            r.w = v == 0 ? Rules.NONE : v;
                        }
                    });
            slider(body, "Height (now " + e.hDp + " dp)", 0, 500, r.h == Rules.NONE ? 0 : r.h, " dp", "keep",
                    new IntCb() {
                        @Override
                        public void on(int v) {
                            r.h = v == 0 ? Rules.NONE : v;
                        }
                    });
        }
        if (e.isText || e.root) {
            slider(body, "Text size", 0, 60, r.text == Rules.NONE ? 0 : r.text, " dp", "keep", new IntCb() {
                @Override
                public void on(int v) {
                    r.text = v == 0 ? Rules.NONE : v;
                }
            });
        }
        if (!e.root) {
            slider(body, "Opacity", 0, 100, r.alpha == Rules.NONE ? 0 : r.alpha, "%", "keep", new IntCb() {
                @Override
                public void on(int v) {
                    r.alpha = v == 0 ? Rules.NONE : Math.max(10, v);
                }
            });
        } else {
            slider(body, "Opacity", 0, 100, r.alpha == Rules.NONE ? 0 : r.alpha, "%", "keep", new IntCb() {
                @Override
                public void on(int v) {
                    r.alpha = v == 0 ? Rules.NONE : Math.max(10, v);
                }
            });
        }
        if (e.isText) {
            colorRow(body, "Text colour", r.textColor, true, new IntCb() {
                @Override
                public void on(int v) {
                    r.textColor = v == Rules.NONE ? Rules.NONE : (v | 0xFF000000);
                }
            });
        }
        colorRow(body, e.isImage ? "Icon colour" : "Background colour", r.bgColor, true, new IntCb() {
            @Override
            public void on(int v) {
                r.bgColor = v == Rules.NONE ? Rules.NONE : (v | 0xFF000000);
            }
        });

        CheckBox hide = new CheckBox(ctx);
        hide.setText("Hide this item");
        hide.setTextColor(TEXT);
        hide.setChecked(r.hide);
        hide.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                r.hide = on;
                Config.saveLive(app);
                Overlays.tick(app);
            }
        });
        add(body, hide, 10);

        if (e.root) {
            add(body, label("Treat this window as", 13, TEXT, false), 8);
            LinearLayout kr = new LinearLayout(ctx);
            kr.setOrientation(LinearLayout.HORIZONTAL);
            final String[] kinds = {null, "menu", "button", "icon"};
            String[] kn = {"Auto", "Menu", "Button", "Icon"};
            for (int i = 0; i < kinds.length; i++) {
                final String k = kinds[i];
                TextView c = chip(kn[i], (r.kind == null && k == null) || (k != null && k.equals(r.kind)));
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        r.kind = k;
                        Config.saveLive(app);
                        Overlays.tick(app);
                        render();
                    }
                });
                kr.addView(c, chipLp());
            }
            add(body, kr, 4);
        }

        TextView reset = chip("Reset this item", false);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Rules.Rule x = Rules.edit(e.o.key);
                x.kind = null;
                x.w = Rules.NONE;
                x.h = Rules.NONE;
                x.alpha = Rules.NONE;
                x.text = Rules.NONE;
                x.textColor = Rules.NONE;
                x.bgColor = Rules.NONE;
                x.name = null;
                x.hide = false;
                Config.saveLive(app);
                Overlays.tick(app);
                render();
            }
        });
        add(body, reset, 14);
    }

    private void renderGlobal() {
        add(body, label("Floating buttons and icons", 14, ACC, true), 4);
        slider(body, "Size (width)", 0, 200, Config.btnDp, " dp", "keep", new IntCb() {
            @Override
            public void on(int v) {
                Config.btnDp = v;
            }
        });
        slider(body, "Opacity", 10, 100, Config.btnAlpha, "%", null, new IntCb() {
            @Override
            public void on(int v) {
                Config.btnAlpha = v;
            }
        });
        slider(body, "Text size", 0, 40, Config.btnText, " dp", "keep", new IntCb() {
            @Override
            public void on(int v) {
                Config.btnText = v;
            }
        });
        add(body, label("Menu panels", 14, ACC, true), 18);
        slider(body, "Size (width)", 0, 600, Config.menuDp, " dp", "keep", new IntCb() {
            @Override
            public void on(int v) {
                Config.menuDp = v;
            }
        });
        slider(body, "Opacity", 10, 100, Config.menuAlpha, "%", null, new IntCb() {
            @Override
            public void on(int v) {
                Config.menuAlpha = v;
            }
        });
        slider(body, "Text size", 0, 40, Config.menuText, " dp", "keep", new IntCb() {
            @Override
            public void on(int v) {
                Config.menuText = v;
            }
        });
        note(body, "Buttons and menus are separate: changing one never touches the other. "
                + "For a single button or menu item use the Items tab. Size 0 / keep = original.");
    }

    private void renderTheme() {
        CheckBox on = new CheckBox(ctx);
        on.setText("Apply theme to the whole app");
        on.setTextColor(TEXT);
        on.setChecked(Config.themeOn);
        on.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Config.themeOn = v;
                Config.saveLive(app);
                Overlays.tick(app);
            }
        });
        body.addView(on);
        add(body, label("Ready-made", 13, SUB, false), 8);
        LinearLayout pr = new LinearLayout(ctx);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(ctx);
        for (int i = 0; i < PRESET_NAMES.length; i++) {
            final int[] pv = PRESETS[i];
            TextView c = chip(PRESET_NAMES[i], false);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Config.themeOn = true;
                    Config.themeBg = pv[0];
                    Config.themeText = pv[1];
                    Config.themeAccent = pv[2];
                    Config.saveLive(app);
                    Overlays.tick(app);
                    render();
                }
            });
            pr.addView(c, chipLp());
        }
        hs.addView(pr);
        add(body, hs, 4);
        colorRow(body, "Background", Config.themeBg, false, new IntCb() {
            @Override
            public void on(int v) {
                Config.themeBg = v | 0xFF000000;
                Config.themeOn = true;
            }
        });
        colorRow(body, "Text", Config.themeText, false, new IntCb() {
            @Override
            public void on(int v) {
                Config.themeText = v | 0xFF000000;
                Config.themeOn = true;
            }
        });
        colorRow(body, "Buttons (accent)", Config.themeAccent, false, new IntCb() {
            @Override
            public void on(int v) {
                Config.themeAccent = v | 0xFF000000;
                Config.themeOn = true;
            }
        });
        note(body, "The theme repaints backgrounds, texts and buttons of the app screens and overlays. "
                + "Pictures stay as they are. A colour set on a single item (Items tab) wins over the theme.");
    }

    private void renderMore() {
        TextView copy = chip("Copy settings (to make a normal APK)", true);
        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ClipboardManager cm = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("Live Editor settings", Config.exportJson()));
                    toast("Settings copied. Open the Live Editor app, choose \"Convert live APK to normal\", "
                            + "pick this app, then tap \"Paste settings\".");
                } catch (Throwable t) {
                    toast("Could not copy: " + t);
                }
            }
        });
        add(body, copy, 6);
        note(body, "All sizes, colours, names, hidden items and the theme you set here are copied as text. "
                + "In the Live Editor app they are baked into a normal APK without this pencil.");
        TextView reset = chip("Reset all edits", false);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Rules.resetAll();
                Config.btnDp = 0;
                Config.btnAlpha = 100;
                Config.btnText = 0;
                Config.menuDp = 0;
                Config.menuAlpha = 100;
                Config.menuText = 0;
                Config.themeOn = false;
                Config.saveLive(app);
                Overlays.tick(app);
                toast("All edits reset");
                render();
            }
        });
        add(body, reset, 16);
        note(body, "Drag the \u270E handle to move it. Tap it to open or close this panel.");
    }
}
