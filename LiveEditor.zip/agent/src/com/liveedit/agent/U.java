package com.liveedit.agent;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Small shared helpers. */
final class U {
    static final String TAG = "LiveEditor";
    /** Every view the agent adds gets this tag so it is skipped by pickers, dumps and selectors. */
    static final String AGENT_TAG = "liveedit:agent";

    private U() {}

    static void log(String m) {
        Log.d(TAG, m);
    }

    static void err(String m, Throwable t) {
        Log.e(TAG, m, t);
    }

    /** Logcat truncates long lines, so print in chunks. */
    static void logLong(String s) {
        int i = 0;
        while (i < s.length()) {
            int end = Math.min(s.length(), i + 3000);
            Log.d(TAG, s.substring(i, end));
            i = end;
        }
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static boolean isAgent(View v) {
        return AGENT_TAG.equals(v.getTag());
    }

    /** Resource entry name of the view id (for example "title"), or null if it has none. */
    static String idName(View v) {
        int id = v.getId();
        if (id == View.NO_ID) return null;
        try {
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return null;
        }
    }

    static String shortClass(View v) {
        String n = v.getClass().getName();
        int i = n.lastIndexOf('.');
        return i >= 0 ? n.substring(i + 1) : n;
    }

    static String shortAct(String n) {
        int i = n.lastIndexOf('.');
        return i >= 0 ? n.substring(i + 1) : n;
    }

    /** Accepts #RRGGBB, #AARRGGBB, RRGGBB, AARRGGBB and color names. Returns null if invalid. */
    static Integer parseColor(String s) {
        if (s == null) return null;
        s = s.trim();
        if (s.matches("[0-9a-fA-F]{6}|[0-9a-fA-F]{8}")) s = "#" + s;
        try {
            return Integer.valueOf(Color.parseColor(s));
        } catch (Throwable t) {
            return null;
        }
    }

    static String hex(int c) {
        return String.format(Locale.US, "#%08X", c);
    }

    static String readAll(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            in.close();
        }
    }

    static void write(File f, String s) throws IOException {
        FileOutputStream out = new FileOutputStream(f);
        try {
            out.write(s.getBytes(StandardCharsets.UTF_8));
        } finally {
            out.close();
        }
    }
}
