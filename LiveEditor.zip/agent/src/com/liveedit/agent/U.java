package com.liveedit.agent;

import android.util.Log;

/** Small shared helpers. */
final class U {
    static final String TAG = "LiveEditor";

    private U() {}

    static void log(String m) {
        Log.d(TAG, m);
    }

    static void err(String m, Throwable t) {
        Log.e(TAG, m, t);
    }

    static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
