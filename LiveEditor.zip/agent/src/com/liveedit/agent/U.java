package com.liveedit.agent;

import android.content.Context;
import android.util.Log;

/** Small shared helpers. */
final class U {
    static final String TAG = "LiveEditor";

    private U() {}

    static void log(String m) {
        Log.d(TAG, m);
    }

    static void err(String m, Throwable t) {
        Log.e(TAG, m, t);
    }

    static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    static float density(Context c) {
        return c.getResources().getDisplayMetrics().density;
    }

    static int dp(Context c, float v) {
        return Math.round(v * density(c));
    }

    static int toDp(Context c, int px) {
        return Math.round(px / density(c));
    }
}
