package com.liveedit.agent;

import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * A selector points at one view inside an Activity's decor view.
 *   id:<entryName>#<n>   n-th view (depth-first) having that resource id name
 *   path:<i>/<j>/<k>     child indexes from the decor view (fallback for views without ids)
 */
final class Sel {

    private Sel() {}

    static String of(View decor, View v) {
        String name = U.idName(v);
        if (name != null) {
            ArrayList<View> same = new ArrayList<View>();
            collect(decor, name, same);
            int idx = same.indexOf(v);
            if (idx >= 0) return "id:" + name + "#" + idx;
        }
        return "path:" + pathOf(decor, v);
    }

    private static String pathOf(View decor, View v) {
        ArrayList<Integer> idx = new ArrayList<Integer>();
        View cur = v;
        while (cur != decor && cur.getParent() instanceof ViewGroup) {
            ViewGroup p = (ViewGroup) cur.getParent();
            idx.add(0, Integer.valueOf(p.indexOfChild(cur)));
            cur = p;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < idx.size(); i++) {
            if (i > 0) sb.append('/');
            sb.append(idx.get(i).intValue());
        }
        return sb.toString();
    }

    static View resolve(View decor, String sel) {
        try {
            if (sel.startsWith("id:")) {
                int hash = sel.lastIndexOf('#');
                String name = sel.substring(3, hash);
                int n = Integer.parseInt(sel.substring(hash + 1));
                ArrayList<View> same = new ArrayList<View>();
                collect(decor, name, same);
                return n < same.size() ? same.get(n) : null;
            }
            if (sel.startsWith("path:")) {
                String p = sel.substring(5);
                View cur = decor;
                if (p.length() == 0) return cur;
                String[] parts = p.split("/");
                for (int k = 0; k < parts.length; k++) {
                    if (!(cur instanceof ViewGroup)) return null;
                    ViewGroup g = (ViewGroup) cur;
                    int i = Integer.parseInt(parts[k]);
                    if (i < 0 || i >= g.getChildCount()) return null;
                    cur = g.getChildAt(i);
                }
                return cur;
            }
        } catch (Throwable t) {
            // bad selector: treat as not found
        }
        return null;
    }

    private static void collect(View decor, String name, List<View> out) {
        int id = 0;
        try {
            id = decor.getResources().getIdentifier(name, "id", decor.getContext().getPackageName());
        } catch (Throwable t) {
            id = 0;
        }
        collectRec(decor, name, id, out);
    }

    private static void collectRec(View v, String name, int id, List<View> out) {
        if (U.isAgent(v)) return;
        boolean match = id != 0 ? v.getId() == id : name.equals(U.idName(v));
        if (match) out.add(v);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                collectRec(g.getChildAt(i), name, id, out);
            }
        }
    }
}
