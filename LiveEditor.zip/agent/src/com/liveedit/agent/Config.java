package com.liveedit.agent;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * The choices made in the Live Editor app while patching. They are stored inside the patched APK
 * as assets/liveedit_config.json, so nothing needs to be set up (or can be changed) inside the app.
 */
final class Config {
    static boolean present;
    /** Floating overlay buttons: size in percent (30..250) and opacity in percent (10..100). */
    static int scale = 100;
    static int alpha = 100;
    /** Turn off the click sound effect of every view. */
    static boolean mute;
    static boolean keepOn;
    /** Remove the "no screenshots" flag. */
    static boolean allowShot;
    static boolean immersive;
    static boolean hideAds;
    /** 0 normal, 1 faster, 2 off. */
    static int anim;
    /** Servers (and their sub-domains) the app may not reach. */
    static String[] hosts = new String[0];

    private Config() {}

    static void load(Context c) {
        try {
            InputStream in = c.getAssets().open("liveedit_config.json");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try {
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally {
                in.close();
            }
            JSONObject o = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
            scale = U.clamp(o.optInt("scale", 100), 30, 250);
            alpha = U.clamp(o.optInt("alpha", 100), 10, 100);
            mute = o.optBoolean("mute", false);
            keepOn = o.optBoolean("keepOn", false);
            allowShot = o.optBoolean("allowShot", false);
            immersive = o.optBoolean("immersive", false);
            hideAds = o.optBoolean("hideAds", false);
            anim = U.clamp(o.optInt("anim", 0), 0, 2);
            JSONArray h = o.optJSONArray("block");
            ArrayList<String> list = new ArrayList<String>();
            if (h != null) {
                for (int i = 0; i < h.length(); i++) {
                    String s = h.optString(i, "").trim();
                    if (s.length() > 0) list.add(s);
                }
            }
            hosts = list.toArray(new String[list.size()]);
            present = true;
        } catch (Throwable t) {
            present = false;
        }
    }

    static boolean overlayChanged() {
        return scale != 100 || alpha != 100 || mute;
    }

    static boolean needsActivityHooks() {
        return keepOn || allowShot || immersive || hideAds;
    }
}
