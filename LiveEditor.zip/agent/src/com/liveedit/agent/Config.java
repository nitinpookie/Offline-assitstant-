package com.liveedit.agent;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * The choices made in the Live Editor app while patching. They are stored inside the patched APK
 * as assets/liveedit_config.json. In "live" mode the pencil handle can change them while the app runs;
 * those edits are kept in the app's private folder and can be exported to build a normal APK.
 */
final class Config {
    private static final String LIVE_FILE = "liveedit_live.json";

    static boolean present;
    /** The pencil handle (live editor) is inside this app. */
    static boolean live;

    /** Small floating icons and buttons: width in dp (0 = keep), opacity percent, text size dp (0 = keep). */
    static int btnDp;
    static int btnAlpha = 100;
    static int btnText;
    /** Menu panels (big overlay windows), same meaning. */
    static int menuDp;
    static int menuAlpha = 100;
    static int menuText;

    /** Turn off the click sound effect of every view. */
    static boolean mute;
    static boolean keepOn;
    /** Remove the "no screenshots" flag. */
    static boolean allowShot;
    static boolean immersive;
    static boolean hideAds;
    /** 0 normal, 1 faster, 2 off. */
    static int anim;
    /** Servers (and their sub-domains) the app may not reach. */
    static String[] hosts = new String[0];
    /** 0 keep, 1 block links that open at app start (first 30 s), 2 block all links that leave the app. */
    static int links;
    /** 0 keep, 1 hide timer texts, 2 replace timer texts with timerText. */
    static int timers;
    static String timerText = "";
    /** Best-effort mode for apps whose native libraries do not fit this CPU: keep the app alive when they are missing. */
    static boolean guard;

    static boolean themeOn;
    static int themeBg = 0xFF101418;
    static int themeText = 0xFFECEFF4;
    static int themeAccent = 0xFF7C5CFF;

    private Config() {}

    private static void defaults() {
        live = false;
        btnDp = 0;
        btnAlpha = 100;
        btnText = 0;
        menuDp = 0;
        menuAlpha = 100;
        menuText = 0;
        mute = false;
        keepOn = false;
        allowShot = false;
        immersive = false;
        hideAds = false;
        anim = 0;
        hosts = new String[0];
        links = 0;
        timers = 0;
        timerText = "";
        guard = false;
        themeOn = false;
        themeBg = 0xFF101418;
        themeText = 0xFFECEFF4;
        themeAccent = 0xFF7C5CFF;
    }

    static void load(Context c) {
        try {
            InputStream in = c.getAssets().open("liveedit_config.json");
            JSONObject o = new JSONObject(new String(readAll(in), StandardCharsets.UTF_8));
            defaults();
            live = o.optBoolean("live", false);
            readLook(o);
            mute = o.optBoolean("mute", false);
            keepOn = o.optBoolean("keepOn", false);
            allowShot = o.optBoolean("allowShot", false);
            immersive = o.optBoolean("immersive", false);
            hideAds = o.optBoolean("hideAds", false);
            anim = U.clamp(o.optInt("anim", 0), 0, 2);
            links = U.clamp(o.optInt("links", 0), 0, 2);
            timers = U.clamp(o.optInt("timers", 0), 0, 2);
            timerText = o.optString("timerText", "");
            guard = o.optBoolean("guard", false);
            JSONArray h = o.optJSONArray("block");
            ArrayList<String> list = new ArrayList<String>();
            if (h != null) {
                for (int i = 0; i < h.length(); i++) {
                    String s = h.optString(i, "").trim();
                    if (s.length() > 0) list.add(s);
                }
            }
            hosts = list.toArray(new String[list.size()]);
            Rules.loadBaked(o.optJSONArray("rules"));
            present = true;
        } catch (Throwable t) {
            present = false;
        }
    }

    /** Size, opacity, text size and theme: the part that the pencil handle can change. */
    private static void readLook(JSONObject o) {
        btnDp = U.clamp(o.optInt("btnDp", btnDp), 0, 400);
        btnAlpha = U.clamp(o.optInt("btnAlpha", btnAlpha), 10, 100);
        btnText = U.clamp(o.optInt("btnText", btnText), 0, 100);
        menuDp = U.clamp(o.optInt("menuDp", menuDp), 0, 1200);
        menuAlpha = U.clamp(o.optInt("menuAlpha", menuAlpha), 10, 100);
        menuText = U.clamp(o.optInt("menuText", menuText), 0, 100);
        JSONObject th = o.optJSONObject("theme");
        if (th != null) {
            themeOn = th.optBoolean("on", themeOn);
            themeBg = th.optInt("bg", themeBg) | 0xFF000000;
            themeText = th.optInt("text", themeText) | 0xFF000000;
            themeAccent = th.optInt("accent", themeAccent) | 0xFF000000;
        }
    }

    private static void writeLook(JSONObject o) throws Exception {
        o.put("btnDp", btnDp);
        o.put("btnAlpha", btnAlpha);
        o.put("btnText", btnText);
        o.put("menuDp", menuDp);
        o.put("menuAlpha", menuAlpha);
        o.put("menuText", menuText);
        JSONObject th = new JSONObject();
        th.put("on", themeOn);
        th.put("bg", themeBg);
        th.put("text", themeText);
        th.put("accent", themeAccent);
        o.put("theme", th);
    }

    // ---- live edits -------------------------------------------------------------------------

    static void loadLive(Context c) {
        try {
            File f = new File(c.getFilesDir(), LIVE_FILE);
            if (!f.exists()) return;
            JSONObject o = new JSONObject(new String(readAll(new FileInputStream(f)), StandardCharsets.UTF_8));
            JSONObject g = o.optJSONObject("g");
            if (g != null) readLook(g);
            Rules.loadLive(o.optJSONArray("rules"));
        } catch (Throwable t) {
            U.err("cannot read live edits", t);
        }
    }

    static void saveLive(Context c) {
        if (!live) return;
        try {
            JSONObject o = new JSONObject();
            JSONObject g = new JSONObject();
            writeLook(g);
            o.put("g", g);
            o.put("rules", Rules.liveArray());
            FileOutputStream out = new FileOutputStream(new File(c.getFilesDir(), LIVE_FILE));
            try {
                out.write(o.toString().getBytes(StandardCharsets.UTF_8));
            } finally {
                out.close();
            }
        } catch (Throwable t) {
            U.err("cannot save live edits", t);
        }
    }

    /** Forget every live edit and go back to what is baked into the APK. */
    static void resetLive(Context c) {
        try {
            new File(c.getFilesDir(), LIVE_FILE).delete();
        } catch (Throwable t) {
            // ignore
        }
        Rules.clearLive();
        load(c);
    }

    /** All current settings as one JSON text (for "Copy settings", to build a normal APK from it). */
    static String exportJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("v", 3);
            o.put("live", false);
            writeLook(o);
            o.put("mute", mute);
            o.put("keepOn", keepOn);
            o.put("allowShot", allowShot);
            o.put("immersive", immersive);
            o.put("hideAds", hideAds);
            o.put("anim", anim);
            o.put("links", links);
            o.put("timers", timers);
            o.put("timerText", timerText);
            JSONArray b = new JSONArray();
            for (int i = 0; i < hosts.length; i++) b.put(hosts[i]);
            o.put("block", b);
            o.put("rules", Rules.mergedArray());
            return o.toString();
        } catch (Throwable t) {
            U.err("export", t);
            return "{}";
        }
    }

    // ---- what is needed -----------------------------------------------------------------------

    static boolean needsTicker() {
        return live || btnDp != 0 || btnAlpha < 100 || btnText != 0 || menuDp != 0 || menuAlpha < 100
                || menuText != 0 || mute || themeOn || timers != 0 || Rules.hasAny();
    }

    static boolean needsActivityHooks() {
        return keepOn || allowShot || immersive || hideAds || themeOn || timers != 0 || Rules.hasAny() || live;
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            in.close();
        }
        return out.toByteArray();
    }
}
