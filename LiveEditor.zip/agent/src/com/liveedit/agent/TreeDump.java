package com.liveedit.agent;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/** Text dump of a view hierarchy. The [path] in front of each line is the same path Sel uses. */
final class TreeDump {

    private TreeDump() {}

    static String dump(View root) {
        StringBuilder sb = new StringBuilder();
        rec(root, 0, "", sb);
        return sb.toString();
    }

    private static void rec(View v, int depth, String path, StringBuilder sb) {
        if (U.isAgent(v)) return;
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append('[').append(path.length() == 0 ? "root" : path).append("] ");
        sb.append(U.shortClass(v));
        String id = U.idName(v);
        if (id != null) sb.append("  #").append(id);
        sb.append("  ").append(v.getWidth()).append('x').append(v.getHeight());
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null && t.length() > 0) {
                String s = t.toString().replace('\n', ' ');
                if (s.length() > 40) s = s.substring(0, 40) + "...";
                sb.append("  \"").append(s).append('"');
            }
        }
        int vis = v.getVisibility();
        if (vis == View.GONE) sb.append("  GONE");
        else if (vis == View.INVISIBLE) sb.append("  INVISIBLE");
        sb.append('\n');
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                String childPath = path.length() == 0 ? String.valueOf(i) : path + "/" + i;
                rec(g.getChildAt(i), depth + 1, childPath, sb);
            }
        }
    }
}
