package com.liveedit.agent;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** All on-screen pieces of the editor. Everything is built in code, so no resources are needed. */
final class Ui {

    private Ui() {}

    private static AlertDialog.Builder builder(Activity a) {
        return new AlertDialog.Builder(a, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
    }

    static void toast(Context c, String m) {
        Toast.makeText(c, m, Toast.LENGTH_SHORT).show();
    }

    static void copy(Context c, String label, String text) {
        try {
            String t = text.length() > 200000 ? text.substring(0, 200000) : text;
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText(label, t));
            toast(c, "Copied");
        } catch (Throwable t) {
            toast(c, "Copy failed");
        }
    }

    // ---------------------------------------------------------------------------------------
    // Floating button
    // ---------------------------------------------------------------------------------------

    static View addButton(final Activity a, final ViewGroup decor) {
        final TextView b = new TextView(a);
        b.setTag(U.AGENT_TAG);
        b.setText("UI");
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xDD6200EE);
        b.setBackground(bg);
        b.setElevation(U.dp(a, 6));

        int size = U.dp(a, 42);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size, Gravity.BOTTOM | Gravity.END);
        lp.setMargins(0, 0, U.dp(a, 10), U.dp(a, 110));

        final int slop = ViewConfiguration.get(a).getScaledTouchSlop();
        b.setOnTouchListener(new View.OnTouchListener() {
            float sx;
            float sy;
            float tx;
            float ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int act = e.getActionMasked();
                if (act == MotionEvent.ACTION_DOWN) {
                    sx = e.getRawX();
                    sy = e.getRawY();
                    tx = v.getTranslationX();
                    ty = v.getTranslationY();
                    moved = false;
                    return true;
                }
                if (act == MotionEvent.ACTION_MOVE) {
                    float mx = e.getRawX() - sx;
                    float my = e.getRawY() - sy;
                    if (!moved && Math.hypot(mx, my) > slop) moved = true;
                    if (moved) {
                        v.setTranslationX(tx + mx);
                        v.setTranslationY(ty + my);
                    }
                    return true;
                }
                if (act == MotionEvent.ACTION_UP) {
                    if (!moved) openMenu(a, decor);
                    return true;
                }
                return act == MotionEvent.ACTION_CANCEL;
            }
        });
        decor.addView(b, lp);
        return b;
    }

    // ---------------------------------------------------------------------------------------
    // Menu
    // ---------------------------------------------------------------------------------------

    static void openMenu(final Activity a, final ViewGroup decor) {
        AlertDialog.Builder b = builder(a);
        b.setTitle("Live Editor");
        String[] items = new String[] {
                "Pick a view to edit",
                "View tree",
                "Saved rules (" + Rules.count() + ")",
                "Copy rules as JSON",
                "Clear all rules"
        };
        b.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int which) {
                if (which == 0) startPick(a, decor);
                else if (which == 1) showTree(a, decor);
                else if (which == 2) showRules(a);
                else if (which == 3) copy(a, "liveedit rules", Rules.toJson());
                else if (which == 4) confirmClear(a);
            }
        });
        b.setNegativeButton("Close", null);
        b.show();
    }

    private static void confirmClear(final Activity a) {
        AlertDialog.Builder b = builder(a);
        b.setTitle("Clear all rules?");
        b.setMessage("All " + Rules.count() + " saved edits will be deleted. Screens go back to normal the next time they open.");
        b.setPositiveButton("Clear", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                Rules.clear();
                toast(a, "All rules cleared");
            }
        });
        b.setNegativeButton("Cancel", null);
        b.show();
    }

    // ---------------------------------------------------------------------------------------
    // View tree
    // ---------------------------------------------------------------------------------------

    static void showTree(final Activity a, ViewGroup decor) {
        final String full = TreeDump.dump(decor);
        U.logLong("---- view tree of " + a.getClass().getName() + " ----\n" + full);
        try {
            File dir = a.getExternalFilesDir(null);
            if (dir != null) U.write(new File(dir, "liveedit_tree.txt"), full);
        } catch (Throwable t) {
            // saving the file is optional
        }
        AlertDialog.Builder b = builder(a);
        Context ctx = b.getContext();
        TextView tv = new TextView(ctx);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tv.setTextColor(0xFFDDDDDD);
        tv.setTextIsSelectable(true);
        tv.setText(full.length() > 60000 ? full.substring(0, 60000) + "\n... (cut, full tree is in logcat)" : full);
        int pad = U.dp(ctx, 12);
        tv.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(ctx);
        sv.addView(tv);
        b.setTitle("View tree");
        b.setView(sv);
        b.setPositiveButton("Copy", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                copy(a, "view tree", full);
            }
        });
        b.setNegativeButton("Close", null);
        b.show();
    }

    // ---------------------------------------------------------------------------------------
    // Saved rules
    // ---------------------------------------------------------------------------------------

    private static void showRules(final Activity a) {
        final List<Rules.Rule> all = Rules.all();
        if (all.isEmpty()) {
            toast(a, "No saved rules yet");
            return;
        }
        String[] labels = new String[all.size()];
        for (int i = 0; i < all.size(); i++) {
            Rules.Rule r = all.get(i);
            labels[i] = U.shortAct(r.act) + "  " + r.sel + "\n" + r.props.toString();
        }
        AlertDialog.Builder b = builder(a);
        b.setTitle("Saved rules (tap one to delete)");
        b.setItems(labels, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int which) {
                confirmDelete(a, all.get(which));
            }
        });
        b.setNegativeButton("Close", null);
        b.show();
    }

    private static void confirmDelete(final Activity a, final Rules.Rule r) {
        AlertDialog.Builder b = builder(a);
        b.setTitle("Delete this rule?");
        b.setMessage(U.shortAct(r.act) + "  " + r.sel + "\n" + r.props.toString());
        b.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int w) {
                Rules.remove(r.act, r.sel);
                toast(a, "Deleted. The original look returns when the screen reopens.");
            }
        });
        b.setNegativeButton("Keep", null);
        b.show();
    }

    // ---------------------------------------------------------------------------------------
    // Picker
    // ---------------------------------------------------------------------------------------

    static void startPick(final Activity a, final ViewGroup decor) {
        final FrameLayout layer = new FrameLayout(a);
        layer.setTag(U.AGENT_TAG);

        PickView pv = new PickView(a, decor);
        layer.addView(pv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView cancel = new TextView(a);
        cancel.setText("Cancel pick");
        cancel.setTextColor(Color.WHITE);
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        cancel.setPadding(U.dp(a, 16), U.dp(a, 8), U.dp(a, 16), U.dp(a, 8));
        GradientDrawable cbg = new GradientDrawable();
        cbg.setCornerRadius(U.dp(a, 20));
        cbg.setColor(0xDDB00020);
        cancel.setBackground(cbg);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        clp.topMargin = U.dp(a, 70);
        layer.addView(cancel, clp);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decor.removeView(layer);
            }
        });

        pv.cb = new PickView.OnPick() {
            @Override
            public void onPick(View picked) {
                decor.removeView(layer);
                openEditor(a, decor, picked);
            }
        };
        decor.addView(layer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Full-screen touch layer. Finger down/move highlights the view under it, finger up selects it. */
    static final class PickView extends View {
        interface OnPick {
            void onPick(View v);
        }

        OnPick cb;
        private final View root;
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint();
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint chip = new Paint();
        private View hit;

        PickView(Context c, View root) {
            super(c);
            this.root = root;
            float d = c.getResources().getDisplayMetrics().density;
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2 * d);
            stroke.setColor(0xFFFF1744);
            fill.setColor(0x33FF1744);
            txt.setColor(Color.WHITE);
            txt.setTextSize(12 * d);
            chip.setColor(0xFFFF1744);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int act = e.getActionMasked();
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_MOVE) {
                hit = findAt(root, (int) e.getRawX(), (int) e.getRawY());
                invalidate();
            } else if (act == MotionEvent.ACTION_UP) {
                if (hit != null && cb != null) cb.onPick(hit);
            } else if (act == MotionEvent.ACTION_CANCEL) {
                hit = null;
                invalidate();
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas cv) {
            float d = getResources().getDisplayMetrics().density;
            if (hit == null) {
                String hint = "Touch a view, then release to select it";
                float hw = txt.measureText(hint);
                float hx = (getWidth() - hw) / 2f;
                float hy = getHeight() - 120 * d;
                cv.drawRect(hx - 8 * d, hy - 18 * d, hx + hw + 8 * d, hy + 8 * d, chip);
                cv.drawText(hint, hx, hy, txt);
                return;
            }
            int[] me = new int[2];
            int[] t = new int[2];
            getLocationOnScreen(me);
            hit.getLocationOnScreen(t);
            float l = t[0] - me[0];
            float tp = t[1] - me[1];
            RectF r = new RectF(l, tp, l + hit.getWidth(), tp + hit.getHeight());
            cv.drawRect(r, fill);
            cv.drawRect(r, stroke);

            String idn = U.idName(hit);
            String label = U.shortClass(hit) + (idn != null ? " #" + idn : "");
            float tw = txt.measureText(label);
            float cy = tp - 18 * d;
            if (cy < 0) cy = tp;
            float cx = Math.max(0, Math.min(l, getWidth() - tw - 8 * d));
            cv.drawRect(cx, cy, cx + tw + 8 * d, cy + 18 * d, chip);
            cv.drawText(label, cx + 4 * d, cy + 13 * d, txt);
        }

        /** Deepest visible, non-agent view containing the screen point. */
        static View findAt(View v, int x, int y) {
            if (U.isAgent(v) || v.getVisibility() != View.VISIBLE) return null;
            int[] loc = new int[2];
            v.getLocationOnScreen(loc);
            if (x < loc[0] || y < loc[1] || x >= loc[0] + v.getWidth() || y >= loc[1] + v.getHeight()) {
                return null;
            }
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = g.getChildCount() - 1; i >= 0; i--) {
                    View r = findAt(g.getChildAt(i), x, y);
                    if (r != null) return r;
                }
            }
            return v;
        }
    }

    // ---------------------------------------------------------------------------------------
    // Property editor
    // ---------------------------------------------------------------------------------------

    private static final class Field {
        final String key;
        final EditText et;
        final String init;
        final boolean hadRule;
        final int kind; // 0 text, 1 color, 2 decimal, 3 integer

        Field(String key, EditText et, String init, boolean hadRule, int kind) {
            this.key = key;
            this.et = et;
            this.init = init;
            this.hadRule = hadRule;
            this.kind = kind;
        }
    }

    private static Field addField(LinearLayout col, Context ctx, String key, String label,
                                  String initial, String hint, int kind, boolean hadRule) {
        TextView l = new TextView(ctx);
        l.setText(label);
        l.setTextColor(0xFFBBBBBB);
        l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        l.setPadding(0, U.dp(ctx, 10), 0, 0);
        col.addView(l);

        EditText et = new EditText(ctx);
        et.setText(initial);
        et.setHint(hint);
        et.setTextColor(Color.WHITE);
        et.setHintTextColor(0xFF777777);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        if (kind == 0) {
            et.setSingleLine(false);
        } else if (kind == 2) {
            et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        } else if (kind == 3) {
            et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        } else {
            et.setSingleLine(true);
        }
        col.addView(et);
        return new Field(key, et, initial, hadRule, kind);
    }

    private static String ruleStr(JSONObject cur, String key) {
        return cur.has(key) ? String.valueOf(cur.opt(key)) : "";
    }

    private static String fmt(float v) {
        return String.format(Locale.US, "%.2f", v);
    }

    private static String dimHint(int px, float density) {
        if (px == ViewGroup.LayoutParams.MATCH_PARENT) return "-1 (match parent)";
        if (px == ViewGroup.LayoutParams.WRAP_CONTENT) return "-2 (wrap content)";
        return String.valueOf(Math.round(px / density));
    }

    static void openEditor(final Activity a, final ViewGroup decor, final View target) {
        final String actName = a.getClass().getName();
        final String sel = Sel.of(decor, target);
        final Rules.Rule existing = Rules.find(actName, sel);
        final JSONObject cur = existing != null ? existing.props : new JSONObject();

        AlertDialog.Builder b = builder(a);
        final Context ctx = b.getContext();
        DisplayMetrics dm = target.getResources().getDisplayMetrics();

        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = U.dp(ctx, 16);
        col.setPadding(pad, pad / 2, pad, pad / 2);

        TextView head = new TextView(ctx);
        String idn = U.idName(target);
        head.setText(U.shortClass(target) + (idn != null ? "   #" + idn : "") + "\n"
                + target.getWidth() + " x " + target.getHeight() + " px\n" + sel);
        head.setTextColor(0xFF9E9E9E);
        head.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        col.addView(head);

        Button upBtn = null;
        final ViewParent vp = target.getParent();
        if (vp instanceof View && vp != decor) {
            upBtn = new Button(ctx);
            upBtn.setText("Select parent: " + U.shortClass((View) vp));
            col.addView(upBtn);
        }
        final Button up = upBtn;

        final List<Field> fields = new ArrayList<Field>();
        if (target instanceof TextView) {
            TextView t = (TextView) target;
            fields.add(addField(col, ctx, "text", "Text",
                    cur.has("text") ? cur.optString("text") : t.getText().toString(),
                    "", 0, cur.has("text")));
            fields.add(addField(col, ctx, "textSize", "Text size (sp)",
                    ruleStr(cur, "textSize"), fmt(t.getTextSize() / dm.scaledDensity),
                    2, cur.has("textSize")));
            fields.add(addField(col, ctx, "textColor", "Text color (#RRGGBB or #AARRGGBB)",
                    ruleStr(cur, "textColor"), U.hex(t.getCurrentTextColor()),
                    1, cur.has("textColor")));
        }
        Drawable bgd = target.getBackground();
        String bgHint = bgd instanceof ColorDrawable
                ? U.hex(((ColorDrawable) bgd).getColor()) : (bgd == null ? "none" : "(drawable)");
        fields.add(addField(col, ctx, "bg", "Background color",
                ruleStr(cur, "bg"), bgHint, 1, cur.has("bg")));
        fields.add(addField(col, ctx, "alpha", "Alpha (0 to 1)",
                ruleStr(cur, "alpha"), fmt(target.getAlpha()), 2, cur.has("alpha")));
        ViewGroup.LayoutParams lp = target.getLayoutParams();
        fields.add(addField(col, ctx, "w", "Width (dp, -1 = match parent, -2 = wrap)",
                ruleStr(cur, "w"), lp == null ? "" : dimHint(lp.width, dm.density), 3, cur.has("w")));
        fields.add(addField(col, ctx, "h", "Height (dp, -1 = match parent, -2 = wrap)",
                ruleStr(cur, "h"), lp == null ? "" : dimHint(lp.height, dm.density), 3, cur.has("h")));
        if (target instanceof ImageView) {
            fields.add(addField(col, ctx, "tint", "Image tint color",
                    ruleStr(cur, "tint"), "none", 1, cur.has("tint")));
        }

        TextView vl = new TextView(ctx);
        vl.setText("Visibility");
        vl.setTextColor(0xFFBBBBBB);
        vl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        vl.setPadding(0, U.dp(ctx, 10), 0, 0);
        col.addView(vl);
        final String[] visOpts = new String[] {"(no change)", "visible", "invisible", "gone"};
        final Spinner sp = new Spinner(ctx);
        sp.setAdapter(new ArrayAdapter<String>(ctx, android.R.layout.simple_spinner_dropdown_item, visOpts));
        int selIdx = 0;
        if (cur.has("vis")) {
            for (int i = 1; i < visOpts.length; i++) {
                if (visOpts[i].equals(cur.optString("vis"))) selIdx = i;
            }
        }
        sp.setSelection(selIdx);
        col.addView(sp);

        ScrollView sv = new ScrollView(ctx);
        sv.addView(col);
        b.setTitle("Edit view");
        b.setView(sv);
        b.setPositiveButton("Apply & save", null); // real click handler is set after show()
        b.setNegativeButton("Cancel", null);
        if (existing != null) {
            b.setNeutralButton("Delete rule", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    Rules.remove(actName, sel);
                    toast(a, "Rule deleted. The original look returns when the screen reopens.");
                }
            });
        }

        final AlertDialog dlg = b.create();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                    | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        }
        dlg.show();

        if (up != null) {
            up.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dlg.dismiss();
                    openEditor(a, decor, (View) vp);
                }
            });
        }

        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    JSONObject np = new JSONObject(cur.toString());
                    for (int i = 0; i < fields.size(); i++) {
                        Field f = fields.get(i);
                        String raw = f.et.getText().toString();
                        String now = f.kind == 0 ? raw : raw.trim();
                        if (now.length() == 0) {
                            np.remove(f.key);
                            continue;
                        }
                        if (now.equals(f.init) && !f.hadRule) continue; // untouched, not an edit
                        if (f.kind == 0) {
                            np.put(f.key, now);
                        } else if (f.kind == 1) {
                            Integer c = U.parseColor(now);
                            if (c == null) {
                                toast(a, "Invalid color for " + f.key);
                                return;
                            }
                            np.put(f.key, U.hex(c.intValue()));
                        } else if (f.kind == 2) {
                            np.put(f.key, Double.parseDouble(now));
                        } else {
                            np.put(f.key, Integer.parseInt(now));
                        }
                    }
                    int si = sp.getSelectedItemPosition();
                    if (si <= 0) np.remove("vis");
                    else np.put("vis", visOpts[si]);

                    if (np.length() == 0) {
                        Rules.remove(actName, sel);
                        toast(a, "Nothing to apply");
                    } else {
                        Rules.put(actName, sel, np);
                        Applier.apply(target, np);
                        toast(a, "Applied and saved");
                    }
                    dlg.dismiss();
                } catch (NumberFormatException nfe) {
                    toast(a, "Invalid number");
                } catch (Throwable t) {
                    U.err("apply edit", t);
                    toast(a, "Could not apply: " + t);
                }
            }
        });
    }
}
