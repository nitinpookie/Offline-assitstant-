package com.liveedit.agent;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketAddress;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/**
 * Keeps the app away from chosen servers. Connections to a blocked host are sent to a dead local port,
 * so they fail at once (like having no internet for that server only). Covers HttpURLConnection and
 * OkHttp. It does not cover WebView pages, Cronet/QUIC or apps that open raw sockets themselves.
 */
final class Net {

    private Net() {}

    static void install(String[] hosts) {
        final ArrayList<String> block = new ArrayList<String>();
        for (int i = 0; i < hosts.length; i++) {
            String h = clean(hosts[i]);
            if (h.length() > 0 && !block.contains(h)) block.add(h);
        }
        if (block.isEmpty()) return;
        final ProxySelector orig = ProxySelector.getDefault();
        final Proxy dead = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", 9));
        final HashSet<String> logged = new HashSet<String>();
        ProxySelector.setDefault(new ProxySelector() {
            @Override
            public List<Proxy> select(URI uri) {
                String h = uri == null ? null : uri.getHost();
                if (h != null && blocked(block, h.toLowerCase(Locale.US))) {
                    synchronized (logged) {
                        if (logged.add(h)) U.log("blocked server: " + h);
                    }
                    return Collections.singletonList(dead);
                }
                if (orig != null) return orig.select(uri);
                return Collections.singletonList(Proxy.NO_PROXY);
            }

            @Override
            public void connectFailed(URI uri, SocketAddress sa, IOException ioe) {
                if (orig != null) orig.connectFailed(uri, sa, ioe);
            }
        });
        U.log("blocking " + block.size() + " servers");
    }

    private static boolean blocked(List<String> block, String host) {
        for (int i = 0; i < block.size(); i++) {
            String b = block.get(i);
            if (host.equals(b) || host.endsWith("." + b)) return true;
        }
        return false;
    }

    /** "https://*.Ads.Example.com/path" -> "ads.example.com" */
    static String clean(String s) {
        String h = s == null ? "" : s.trim().toLowerCase(Locale.US);
        int p = h.indexOf("://");
        if (p >= 0) h = h.substring(p + 3);
        int slash = h.indexOf('/');
        if (slash >= 0) h = h.substring(0, slash);
        int colon = h.indexOf(':');
        if (colon >= 0) h = h.substring(0, colon);
        while (h.startsWith("*") || h.startsWith(".")) h = h.substring(1);
        return h;
    }
}
