package com.liveedit.agent;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import java.util.regex.Pattern;

/**
 * Everything that is changed on screen after the app has drawn it: floating overlay windows (menus, buttons, icons)
 * and, for theme / names / timers / per-item rules, the normal app screens too.
 *
 * Every view is remembered once, in its ORIGINAL state ({@link Orig}). What should be on screen is always computed
 * from that original plus the global settings and the per-item {@link Rules.Rule}, so moving a slider back (or
 * clearing a rule) restores the app. A view that nothing asks to change is never touched.
 *
 * Floating buttons and menus are separate on purpose: "button" size/opacity settings never reach a menu window.
 */
final class Overlays {

    /** The original state of one view, plus what we changed on it. */
    static final class Orig {
        String key;
        boolean isRoot;
        boolean overlay;
        /** Roots only: "menu", "button", "icon" or "app". */
        String kind;
        int lw, lh, ml, mt, mr, mb, pl, pt, pr, pb;
        /** positive base sizes in px used for scaling (0 = wrap/match, cannot be scaled directly). */
        int bw, bh;
        /** size on screen when first seen. */
        int mw, mh;
        float alpha = 1f;
        float winAlpha = 1f;
        float textPx;
        CharSequence text;
        ColorStateList tcl;
        Drawable bg;
        int vis;
        /** A full screen app window (never removed), and whether we made this window untouchable while hidden. */
        boolean screen, touchSet;
        boolean layDirty, alphaDirty, tsDirty, tcDirty, textDirty, bgDirty, tintDirty, hidden, timerHit;
        /** Timer detection: last value of this text, how often it changed lately, and when. */
        String tSeen;
        int tChanges;
        long tAt;
        String lastSet;
        Drawable ours;
        int oursColor;
        int tintColor;
    }

    /** One entry of the editor's list. */
    static final class El {
        View view;
        Orig o;
        String name = "";
        String sub = "";
        /** "menu", "button", "icon" or "app" (children belong to the group of their window). */
        String group = "app";
        boolean root;
        boolean isText;
        boolean isImage;
        /** a thin line (window or view): gets a thickness slider that may go thinner or thicker */
        boolean line;
        int wDp, hDp;
        /** original size and text size in dp (before any change of ours), used as the lowest slider value */
        int owDp, ohDp, otDp;
    }

    /** One window (menu, floating button, popup, dialog, screen) in the "Interfaces" list. */
    static final class Win {
        View root;
        Orig o;
        String name = "";
        String sub = "";
        String kind = "";
        boolean gone;
        /** The main screen of the app: it can be styled but never removed. */
        boolean locked;
    }

    private static final class Pass {
        float f = 1f;
        float d = 1f;
        boolean overlay;
        int textPct = 100;
        int lineDp;
        int budget = 3000;
    }

    private static final WeakHashMap<View, Orig> ORIG = new WeakHashMap<View, Orig>();
    private static final WeakHashMap<View, Boolean> HOOKED = new WeakHashMap<View, Boolean>();
    /** Counts every real change we make to a view, so a frame that was changed can be redrawn before it is shown. */
    private static int mods;
    /** The first small floating window of the app is its menu icon (launcher); the others are buttons. */
    private static boolean launcherTaken;
    /** Every window that was ever seen (key -> name, kind, sub), so a popup can be removed while it is closed. */
    private static final java.util.LinkedHashMap<String, String[]> SEEN = new java.util.LinkedHashMap<String, String[]>();

    private static final Pattern CLOCK = Pattern.compile("^\\D{0,24}(\\d{1,3}\\s*:\\s*){1,2}\\d{1,2}\\D{0,12}$");
    private static final Pattern UNIT = Pattern.compile(
            "(?i)\\d+\\s*(days?|d|hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b");
    private static final Pattern WORD = Pattern.compile(
            "(?i)(left|remaining|remain|expire|expires|expiry|valid|ends|timer|countdown)");
    /** Things that look like a clock but are not a countdown: "10:30 AM", "2025-11-04", "12/05/24". */
    private static final Pattern AMPM = Pattern.compile("(?i)\\b[ap]\\.?\\s?m\\b");
    private static final Pattern DATE = Pattern.compile("\\d{1,4}\\s*[/.-]\\s*\\d{1,2}\\s*[/.-]\\s*\\d{1,4}");

    private Overlays() {}

    // ---- windows -----------------------------------------------------------------------------

    /** All window root views of this process, or an empty list if Android does not allow reading them. */
    static List<View> roots() {
        ArrayList<View> out = new ArrayList<View>();
        try {
            Class<?> c = Class.forName("android.view.WindowManagerGlobal");
            Object g = c.getMethod("getInstance").invoke(null);
            Field f = c.getDeclaredField("mViews");
            f.setAccessible(true);
            Object o = f.get(g);
            if (o instanceof List) {
                List<Object> copy = new ArrayList<Object>((List<?>) o);
                for (int i = 0; i < copy.size(); i++) {
                    if (copy.get(i) instanceof View) out.add((View) copy.get(i));
                }
            }
        } catch (Throwable t) {
            U.err("cannot read app windows", t);
        }
        if (out.isEmpty()) {
            View d = Agent.topDecor();
            if (d != null) out.add(d);
        }
        return out;
    }

    static boolean isOverlay(View root) {
        ViewGroup.LayoutParams lp = root.getLayoutParams();
        if (!(lp instanceof WindowManager.LayoutParams)) return false;
        int t = ((WindowManager.LayoutParams) lp).type;
        return t >= 2000 && t < 3000 && t != 2005; // system-level windows, not toasts
    }

    /** Called about once a second, and right after something is changed in the editor. */
    static void tick(Context ctx) {
        if (!Config.needsTicker()) return;
        try {
            List<View> all = roots();
            for (int i = 0; i < all.size(); i++) {
                View r = all.get(i);
                if (Panel.isOwn(r)) continue;
                try {
                    if (Config.mute) mute(r);
                    hook(r);
                    handleRoot(ctx, r);
                } catch (Throwable t) {
                    U.err("window apply", t);
                }
            }
        } catch (Throwable t) {
            U.err("tick", t);
        }
    }

    // ---- no flicker: change a window before its first frame, and before every later frame ------

    /** A window list that tells us the moment the app adds a window, so it is changed before it is ever drawn. */
    private static final class Watched extends ArrayList<View> {
        private static final long serialVersionUID = 1L;

        Watched(List<View> from) {
            super(from);
        }

        @Override
        public boolean add(View v) {
            boolean r = super.add(v);
            added(v);
            return r;
        }

        @Override
        public void add(int i, View v) {
            super.add(i, v);
            added(v);
        }
    }

    private static void added(View v) {
        try {
            if (v != null && Config.needsTicker() && !Panel.isOwn(v)) hook(v);
        } catch (Throwable t) {
            U.err("window added", t);
        }
    }

    /** Called once at start: from now on new windows are noticed at once (the 0.7 s timer stays as a safety net). */
    static void watchWindows() {
        try {
            Class<?> c = Class.forName("android.view.WindowManagerGlobal");
            Object g = c.getMethod("getInstance").invoke(null);
            Field f = c.getDeclaredField("mViews");
            f.setAccessible(true);
            Object o = f.get(g);
            if (o instanceof Watched || !(o instanceof ArrayList)) return;
            ArrayList<View> copy = new ArrayList<View>();
            for (Object x : (ArrayList<?>) o) {
                if (x instanceof View) copy.add((View) x);
            }
            f.set(g, new Watched(copy));
            for (int i = 0; i < copy.size(); i++) hook(copy.get(i));
        } catch (Throwable t) {
            U.err("cannot watch windows (the timer still works)", t);
        }
    }

    static void hook(final View root) {
        if (root == null || Panel.isOwn(root) || HOOKED.containsKey(root)) return;
        HOOKED.put(root, Boolean.TRUE);
        try {
            root.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                private int cancels;
                private long last;

                @Override
                public boolean onPreDraw() {
                    try {
                        if (!Config.needsTicker() || Panel.isOwn(root)) return true;
                        boolean screen = isScreen(root);
                        long now = SystemClock.uptimeMillis();
                        if (screen && now - last < 120L) return true; // big app screens: not on every frame
                        last = now;
                        int before = mods;
                        handleRoot(root.getContext(), root);
                        if (mods != before && !screen && cancels < 3) {
                            cancels++;
                            return false; // changed: draw again so the unchanged look is never shown
                        }
                        cancels = 0;
                    } catch (Throwable t) {
                        U.err("pre-draw", t);
                    }
                    return true;
                }
            });
        } catch (Throwable t) {
            U.err("hook window", t);
        }
    }

    /** The window of an activity (a full app screen), as opposed to dialogs, popups and floating overlays. */
    static boolean isScreen(View root) {
        if (isOverlay(root)) return false;
        ViewGroup.LayoutParams lp = root.getLayoutParams();
        if (lp instanceof WindowManager.LayoutParams && ((WindowManager.LayoutParams) lp).type >= 1000) return false;
        return root.getContext() instanceof Activity;
    }

    private static void mute(View v) {
        if (v.isSoundEffectsEnabled()) v.setSoundEffectsEnabled(false);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) mute(g.getChildAt(i));
        }
    }

    // ---- remembering views -------------------------------------------------------------------

    private static void capture(View v, Orig o) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        o.lw = lp == null ? ViewGroup.LayoutParams.WRAP_CONTENT : lp.width;
        o.lh = lp == null ? ViewGroup.LayoutParams.WRAP_CONTENT : lp.height;
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
            o.ml = m.leftMargin;
            o.mt = m.topMargin;
            o.mr = m.rightMargin;
            o.mb = m.bottomMargin;
        }
        o.pl = v.getPaddingLeft();
        o.pt = v.getPaddingTop();
        o.pr = v.getPaddingRight();
        o.pb = v.getPaddingBottom();
        o.mw = v.getWidth();
        o.mh = v.getHeight();
        o.bw = (lp != null && lp.width > 0) ? lp.width : 0;
        o.bh = (lp != null && lp.height > 0) ? lp.height : 0;
        // Images (and single-view windows) that wrap their picture: use the size they have now.
        if (v instanceof ImageView || (o.isRoot && !(v instanceof ViewGroup))) {
            if (o.bw <= 0 && v.getWidth() > 0) o.bw = v.getWidth();
            if (o.bh <= 0 && v.getHeight() > 0) o.bh = v.getHeight();
        }
        o.alpha = v.getAlpha();
        o.vis = v.getVisibility();
        o.bg = v.getBackground();
        if (v instanceof TextView) {
            TextView t = (TextView) v;
            o.textPx = t.getTextSize();
            o.text = t.getText();
            o.tcl = t.getTextColors();
        }
    }

    private static Orig rootOrig(View root, boolean overlay) {
        Orig o = ORIG.get(root);
        if (o != null) return o;
        o = new Orig();
        o.isRoot = true;
        o.overlay = overlay;
        capture(root, o);
        ViewGroup.LayoutParams lp = root.getLayoutParams();
        if (lp instanceof WindowManager.LayoutParams) o.winAlpha = ((WindowManager.LayoutParams) lp).alpha;
        String where = overlay ? "" : activityName(root.getContext());
        o.key = (overlay ? "ov:" : "app:") + where + ":" + root.getClass().getSimpleName() + ":"
                + norm(firstText(root, 0));
        o.screen = !overlay && isScreen(root);
        o.kind = overlay ? classify(root) : "app";
        ORIG.put(root, o);
        return o;
    }

    private static Orig childOrig(View v, String parentKey, int idx) {
        Orig o = ORIG.get(v);
        if (o != null) return o;
        o = new Orig();
        capture(v, o);
        String t = null;
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null) t = cs.toString();
        }
        if (t == null || t.trim().length() == 0) {
            CharSequence cd = v.getContentDescription();
            if (cd != null) t = cd.toString();
        }
        o.key = parentKey + "/" + idx + v.getClass().getSimpleName() + ":" + norm(t);
        ORIG.put(v, o);
        return o;
    }

    /** Text without digits (so a ticking clock keeps the same key), lower case, short. */
    static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (Character.isDigit(ch)) continue;
            b.append(Character.toLowerCase(ch));
            if (b.length() >= 20) break;
        }
        return b.toString().trim();
    }

    private static String activityName(Context c) {
        int guard = 0;
        while (c instanceof ContextWrapper && guard++ < 8) {
            if (c instanceof Activity) return c.getClass().getSimpleName();
            c = ((ContextWrapper) c).getBaseContext();
        }
        return c == null ? "" : c.getClass().getSimpleName();
    }

    private static String firstText(View v, int depth) {
        if (depth > 8) return null;
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null && cs.toString().trim().length() > 0) return cs.toString();
        }
        CharSequence cd = v.getContentDescription();
        if (cd != null && cd.toString().trim().length() > 0) return cd.toString();
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount() && i < 30; i++) {
                String s = firstText(g.getChildAt(i), depth + 1);
                if (s != null) return s;
            }
        }
        return null;
    }

    /**
     * A window with many views is a menu; a thin one without text is a line; a screen-sized one without text is a
     * canvas (drawn by the app, never scaled); the first small window is the menu icon; the rest are buttons.
     */
    private static String classify(View root) {
        int[] n = new int[2]; // views, texts
        count(root, n, 0);
        int w = root.getWidth(), h = root.getHeight();
        android.util.DisplayMetrics dm = root.getResources().getDisplayMetrics();
        if (n[0] >= 7) return "menu";
        if (n[1] == 0 && w > 0 && h > 0) {
            int thin = Math.min(w, h), long_ = Math.max(w, h);
            if (thin <= Math.round(10 * dm.density) && long_ >= 4 * thin) return "line";
            if (w >= dm.widthPixels * 0.8f && h >= dm.heightPixels * 0.8f) return "canvas";
        }
        if (!launcherTaken) {
            launcherTaken = true;
            return "icon";
        }
        return "button";
    }

    private static void count(View v, int[] n, int depth) {
        if (depth > 12 || n[0] > 200) return;
        n[0]++;
        if (v instanceof TextView && ((TextView) v).getText() != null
                && ((TextView) v).getText().length() > 0) n[1]++;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) count(g.getChildAt(i), n, depth + 1);
        }
    }

    // ---- applying ---------------------------------------------------------------------------

    private static void handleRoot(Context ctx, View root) {
        if (ORIG.get(root) == null && (root.getWidth() <= 0 || root.getHeight() <= 0)) return; // not drawn yet
        boolean overlay = isOverlay(root);
        Orig ro = rootOrig(root, overlay);
        Rules.Rule rr = Rules.get(ro.key);
        float d = U.density(ctx);

        float f = 1f;
        int textPct = 100;
        int lineDp = 0;
        boolean sizeable = false;
        if (overlay) {
            String kind = effectiveKind(ro);
            int pct = 100;
            int galpha = 100;
            if ("menu".equals(kind)) {
                pct = Config.menuPct;
                galpha = Config.menuAlpha;
                textPct = Config.menuTextPct;
            } else if ("icon".equals(kind)) {
                pct = Config.iconPct;
                galpha = Config.iconAlpha;
                textPct = Config.iconTextPct;
            } else if ("button".equals(kind)) {
                pct = Config.btnPct;
                galpha = Config.btnAlpha;
                textPct = Config.btnTextPct;
            }
            boolean line = "line".equals(kind);
            boolean canvasK = "canvas".equals(kind);
            if (line || canvasK) {
                lineDp = (rr != null && rr.thick != Rules.NONE && rr.thick > 0) ? rr.thick : Config.lineDp;
                // lines the app paints itself (and thin line windows that are painted): set the Paint width
                if (lineDp > 0 || !PAINT_ORIG.isEmpty()) strokeTree(root, lineDp > 0 ? lineDp * d : 0f, 0);
            }
            sizeable = !"canvas".equals(kind) && !line;
            f = pct / 100f;
            if (sizeable && rr != null && rr.w != Rules.NONE && rr.w > 0 && ro.mw > 0) f = rr.w * d / ro.mw;
            if (!sizeable) f = 1f;
            f = Math.max(0.1f, Math.min(8f, f));
            int ap = Rules.NONE;
            if (rr != null && rr.alpha != Rules.NONE) ap = rr.alpha;
            else if (galpha < 100) ap = galpha;

            WindowManager.LayoutParams wlp = (WindowManager.LayoutParams) root.getLayoutParams();
            boolean ch = false;
            int nw = (f == 1f || ro.bw <= 0) ? ro.lw : Math.round(ro.bw * f);
            int nh = (f == 1f || ro.bh <= 0) ? ro.lh : Math.round(ro.bh * f);
            if (line && lineDp > 0 && ro.mw > 0 && ro.mh > 0) {
                if (ro.mw <= ro.mh) nw = Math.round(lineDp * d);
                else nh = Math.round(lineDp * d);
            }
            boolean sizeMod = nw != ro.lw || nh != ro.lh;
            if (sizeMod || ro.layDirty) {
                if (wlp.width != nw) {
                    wlp.width = nw;
                    ch = true;
                }
                if (wlp.height != nh) {
                    wlp.height = nh;
                    ch = true;
                }
                ro.layDirty = sizeMod;
            }
            boolean alphaMod = ap != Rules.NONE;
            if (alphaMod || ro.alphaDirty) {
                float na = alphaMod ? ap / 100f : ro.winAlpha;
                if (Math.abs(wlp.alpha - na) > 0.001f) {
                    wlp.alpha = na;
                    ch = true;
                }
                ro.alphaDirty = alphaMod;
            }
            if (ch) {
                WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
                wm.updateViewLayout(root, wlp);
                mods++;
            }
        }

        // A removed interface: hidden and untouchable, so the app under it still gets every touch. Never detached.
        ViewGroup.LayoutParams wl0 = root.getLayoutParams();
        if (wl0 instanceof WindowManager.LayoutParams && !ro.screen) {
            WindowManager.LayoutParams wl = (WindowManager.LayoutParams) wl0;
            boolean gone = rr != null && rr.hide;
            int flag = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            boolean upd = false;
            if (gone && (wl.flags & flag) == 0) {
                wl.flags |= flag;
                ro.touchSet = true;
                upd = true;
            } else if (!gone && ro.touchSet) {
                wl.flags &= ~flag;
                ro.touchSet = false;
                upd = true;
            }
            if (upd) {
                WindowManager wm2 = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
                wm2.updateViewLayout(root, wl);
                mods++;
            }
        }

        Pass p = new Pass();
        p.f = f;
        p.d = d;
        p.overlay = overlay;
        p.textPct = textPct;
        p.lineDp = lineDp;
        walk(root, ro, p);
    }

    private static void walk(View v, Orig o, Pass p) {
        if (p.budget-- <= 0) return;
        Rules.Rule r = Rules.get(o.key);
        try {
            applyView(v, o, r, p);
        } catch (Throwable t) {
            U.err("apply view", t);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View c = g.getChildAt(i);
                if (c == null) continue;
                walk(c, childOrig(c, o.key, i), p);
            }
        }
    }

    // ---- lines drawn by the app itself (canvas): change the thickness of its Paint objects ---------

    private static final WeakHashMap<android.graphics.Paint, Float> PAINT_ORIG =
            new WeakHashMap<android.graphics.Paint, Float>();

    /**
     * An app that draws a line itself keeps the Paint (with its stroke width) in a field of its view. Those paints are
     * found by reflection and their stroke width is set; 0 puts the original width back. Paints that are created
     * fresh on every draw cannot be reached this way.
     */
    private static void strokeTree(View v, float px, int depth) {
        if (v == null || depth > 6) return;
        strokeFields(v, px);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount() && i < 60; i++) strokeTree(g.getChildAt(i), px, depth + 1);
        }
    }

    private static void strokeFields(View v, float px) {
        boolean changed = false;
        Class<?> c = v.getClass();
        int guard = 0;
        while (c != null && c != View.class && c != Object.class && guard++ < 6) {
            String cn = c.getName();
            if (cn.startsWith("android.") || cn.startsWith("androidx.")) break;
            Field[] fs;
            try {
                fs = c.getDeclaredFields();
            } catch (Throwable t) {
                break;
            }
            for (int i = 0; i < fs.length; i++) {
                try {
                    Field f = fs[i];
                    if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                    f.setAccessible(true);
                    Object o = f.get(v);
                    if (o instanceof android.graphics.Paint) {
                        changed |= strokePaint((android.graphics.Paint) o, px);
                    } else if (o instanceof android.graphics.Paint[]) {
                        android.graphics.Paint[] arr = (android.graphics.Paint[]) o;
                        for (int k = 0; k < arr.length; k++) if (arr[k] != null) changed |= strokePaint(arr[k], px);
                    }
                } catch (Throwable t) {
                    // field not readable: skip
                }
            }
            c = c.getSuperclass();
        }
        if (changed) {
            v.invalidate();
            mods++;
        }
    }

    private static boolean strokePaint(android.graphics.Paint p, float px) {
        Float orig = PAINT_ORIG.get(p);
        if (orig == null) {
            // only paints that draw lines: stroke style, or a stroke width that is already set
            boolean stroke = p.getStyle() != android.graphics.Paint.Style.FILL || p.getStrokeWidth() > 0f;
            if (!stroke) return false;
            orig = Float.valueOf(p.getStrokeWidth());
            PAINT_ORIG.put(p, orig);
        }
        float want = px > 0 ? px : orig.floatValue();
        if (Math.abs(p.getStrokeWidth() - want) < 0.05f) return false;
        p.setStrokeWidth(want);
        return true;
    }

    /** A thin picture-less line view: no text, no children, one side short and the other much longer. */
    private static boolean isThin(View v, Orig o, float d) {
        if (v instanceof TextView || v instanceof ViewGroup || o.mw <= 0 || o.mh <= 0) return false;
        int thin = Math.min(o.mw, o.mh), len = Math.max(o.mw, o.mh);
        return thin <= Math.round(10 * d) && len >= 4 * thin;
    }

    private static boolean buttonLike(View v, Orig o) {
        return o.bg != null && (v instanceof Button || (v instanceof TextView && v.isClickable()
                && !(v instanceof EditText)));
    }

    private static int contrast(int c) {
        double lum = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
        return lum > 0.6 ? 0xFF111111 : 0xFFFFFFFF;
    }

    /** Only the SHAPE of the text (looks like 00:59 or "3 days left"). Whether it really counts is checked in timerNow. */
    static boolean isTimer(String s) {
        if (s == null) return false;
        int n = s.length();
        if (n == 0 || n > 60) return false;
        if (AMPM.matcher(s).find() || DATE.matcher(s).find()) return false;
        if (CLOCK.matcher(s).matches()) return true;
        return UNIT.matcher(s).find() && WORD.matcher(s).find();
    }

    /**
     * True when this text is a countdown. Words like "left" / "expires" count at once. A bare 00:59 only counts after
     * it changed a few times within seconds (a real countdown ticks; a fixed time, a score or a label does not).
     * Once found it stays a timer for as long as the text keeps the timer shape.
     */
    private static boolean timerNow(Orig o, String cur) {
        if (!isTimer(cur)) {
            o.tSeen = null;
            o.tChanges = 0;
            return false;
        }
        if (UNIT.matcher(cur).find() && WORD.matcher(cur).find()) return true;
        if (o.timerHit) return true;
        long now = SystemClock.elapsedRealtime();
        if (o.tSeen == null) {
            o.tSeen = cur;
            o.tChanges = 1;
            o.tAt = now;
            return false;
        }
        if (!cur.equals(o.tSeen)) {
            o.tChanges = (now - o.tAt > 6000L) ? 1 : o.tChanges + 1;
            o.tSeen = cur;
            o.tAt = now;
        }
        return o.tChanges >= 3;
    }

    private static void applyView(View v, Orig o, Rules.Rule r, Pass p) {
        final float d = p.d;

        // ---- size, margins, padding (a window root is sized through its window instead)
        if (!o.isRoot) {
            int nw = o.lw;
            int nh = o.lh;
            if (r != null && r.w != Rules.NONE && r.w > 0) nw = Math.round(r.w * d);
            else if (p.f != 1f && o.bw > 0) nw = Math.round(o.bw * p.f);
            if (r != null && r.h != Rules.NONE && r.h > 0) nh = Math.round(r.h * d);
            else if (p.f != 1f && o.bh > 0) nh = Math.round(o.bh * p.f);
            int thickDp = (r != null && r.thick != Rules.NONE && r.thick > 0) ? r.thick : (p.overlay ? Config.lineDp : 0);
            if (thickDp > 0 && isThin(v, o, d) && o.mw > 0 && o.mh > 0) {
                if (o.mw <= o.mh) nw = Math.round(thickDp * d);
                else nh = Math.round(thickDp * d);
            }
            float sf = p.f;
            int ml = Math.round(o.ml * sf), mt = Math.round(o.mt * sf), mr = Math.round(o.mr * sf), mb = Math.round(o.mb * sf);
            int pl = Math.round(o.pl * sf), pt = Math.round(o.pt * sf), pr = Math.round(o.pr * sf), pb = Math.round(o.pb * sf);
            boolean mod = nw != o.lw || nh != o.lh || ml != o.ml || mt != o.mt || mr != o.mr || mb != o.mb
                    || pl != o.pl || pt != o.pt || pr != o.pr || pb != o.pb;
            if (mod || o.layDirty) {
                ViewGroup.LayoutParams lp = v.getLayoutParams();
                if (lp != null) {
                    boolean ch = false;
                    if (lp.width != nw) {
                        lp.width = nw;
                        ch = true;
                    }
                    if (lp.height != nh) {
                        lp.height = nh;
                        ch = true;
                    }
                    if (lp instanceof ViewGroup.MarginLayoutParams) {
                        ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
                        if (m.leftMargin != ml || m.topMargin != mt || m.rightMargin != mr || m.bottomMargin != mb) {
                            m.setMargins(ml, mt, mr, mb);
                            ch = true;
                        }
                    }
                    if (ch) {
                        v.setLayoutParams(lp);
                        mods++;
                    }
                }
                if (v.getPaddingLeft() != pl || v.getPaddingTop() != pt
                        || v.getPaddingRight() != pr || v.getPaddingBottom() != pb) {
                    v.setPadding(pl, pt, pr, pb);
                    mods++;
                }
                o.layDirty = mod;
            }

            // ---- opacity
            if (r != null && r.alpha != Rules.NONE) {
                float wa = r.alpha / 100f;
                if (Math.abs(v.getAlpha() - wa) > 0.001f) {
                    v.setAlpha(wa);
                    mods++;
                }
                o.alphaDirty = true;
            } else if (o.alphaDirty) {
                v.setAlpha(o.alpha);
                mods++;
                o.alphaDirty = false;
            }
        }

        boolean hideIt = r != null && r.hide && !(o.isRoot && o.screen);

        // ---- texts: size, name / timers, colour
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            boolean edit = v instanceof EditText;

            float want = o.textPx;
            if (r != null && r.text != Rules.NONE && r.text > 0) want = r.text * d;
            else if (p.f != 1f || p.textPct != 100) want = o.textPx * p.f * (p.textPct / 100f);
            boolean tsMod = Math.abs(want - o.textPx) > 0.5f;
            if (tsMod || o.tsDirty) {
                if (Math.abs(tv.getTextSize() - want) > 0.5f) {
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, want);
                    mods++;
                }
                o.tsDirty = tsMod;
            }

            CharSequence cs = tv.getText();
            String cur = cs == null ? "" : cs.toString();
            boolean ours = o.textDirty && cur.equals(o.lastSet);
            String wantText = null;
            if (!edit) {
                if (r != null && r.name != null) {
                    wantText = r.name;
                } else if (Config.timers != 0) {
                    boolean isT = ours ? o.timerHit : timerNow(o, cur);
                    o.timerHit = isT;
                    if (isT) {
                        if (Config.timers == 2) wantText = Config.timerText;
                        else hideIt = true;
                    }
                }
            }
            if (wantText != null) {
                if (!wantText.equals(cur)) {
                    tv.setText(wantText);
                    mods++;
                }
                o.lastSet = wantText;
                o.textDirty = true;
            } else if (o.textDirty) {
                tv.setText(o.text);
                mods++;
                o.textDirty = false;
                o.lastSet = null;
            }

            int tc = Rules.NONE;
            if (r != null && r.textColor != Rules.NONE) tc = r.textColor;
            else if (Config.themeOn) tc = buttonLike(v, o) ? contrast(Config.themeAccent) : Config.themeText;
            if (tc != Rules.NONE) {
                if (tv.getCurrentTextColor() != tc) {
                    tv.setTextColor(tc);
                    mods++;
                }
                o.tcDirty = true;
            } else if (o.tcDirty) {
                if (o.tcl != null) {
                    tv.setTextColor(o.tcl);
                    mods++;
                }
                o.tcDirty = false;
            }
        }

        // ---- background colour (icons: tint)
        if (v instanceof ImageView) {
            ImageView iv = (ImageView) v;
            if (r != null && r.bgColor != Rules.NONE) {
                if (!o.tintDirty || o.tintColor != r.bgColor) {
                    iv.setColorFilter(r.bgColor, PorterDuff.Mode.SRC_IN);
                    mods++;
                }
                o.tintColor = r.bgColor;
                o.tintDirty = true;
            } else if (o.tintDirty) {
                iv.clearColorFilter();
                mods++;
                o.tintDirty = false;
            }
        } else {
            int wantBg = Rules.NONE;
            boolean exact = false;
            if (r != null && r.bgColor != Rules.NONE) {
                wantBg = r.bgColor;
                exact = true;
            } else if (Config.themeOn && o.bg != null) {
                wantBg = buttonLike(v, o) ? Config.themeAccent : Config.themeBg;
            }
            applyBg(v, o, wantBg, exact);
        }

        // ---- hide
        if (hideIt) {
            int hv = o.isRoot ? View.INVISIBLE : View.GONE;
            if (v.getVisibility() != hv) {
                v.setVisibility(hv);
                mods++;
            }
            o.hidden = true;
        } else if (o.hidden) {
            v.setVisibility(o.vis);
            mods++;
            o.hidden = false;
        }
    }

    private static void applyBg(View v, Orig o, int want, boolean exact) {
        if (want == Rules.NONE) {
            if (o.bgDirty) {
                v.setBackground(o.bg);
                mods++;
                o.bgDirty = false;
                o.ours = null;
            }
            return;
        }
        Drawable cur = v.getBackground();
        if (o.ours != null && cur == o.ours && o.oursColor == want) return;
        if (o.ours == null || cur != o.ours) o.bg = cur; // the app set its own background: that is the new original
        Drawable base = o.bg;
        Drawable made;
        if (exact) {
            made = new ColorDrawable(want);
        } else if (base instanceof ColorDrawable) {
            int a = Color.alpha(((ColorDrawable) base).getColor());
            if (a == 0) return;
            made = new ColorDrawable((want & 0x00FFFFFF) | (a << 24));
        } else if (base instanceof GradientDrawable) {
            Drawable.ConstantState cs = base.getConstantState();
            if (cs == null) return;
            Drawable nd = cs.newDrawable().mutate();
            if (!(nd instanceof GradientDrawable)) return;
            ((GradientDrawable) nd).setColor(want);
            made = nd;
        } else {
            return;
        }
        v.setBackground(made);
        mods++;
        o.ours = made;
        o.oursColor = want;
        o.bgDirty = true;
    }

    // ---- the list shown in the live editor ---------------------------------------------------

    static String effectiveKind(Orig ro) {
        Rules.Rule r = Rules.get(ro.key);
        return (r != null && r.kind != null) ? r.kind : ro.kind;
    }

    /** Everything visible that has a name: menus, buttons, icons and texts of overlays and of the app screens. */
    static List<El> collect(Context ctx) {
        ArrayList<El> out = new ArrayList<El>();
        List<View> all = roots();
        for (int i = 0; i < all.size() && out.size() < 400; i++) {
            View root = all.get(i);
            if (Panel.isOwn(root)) continue;
            if (ORIG.get(root) == null && (root.getWidth() <= 0 || root.getHeight() <= 0)) continue;
            boolean overlay = isOverlay(root);
            Orig ro = rootOrig(root, overlay);
            String group = overlay ? effectiveKind(ro) : "app";
            if (overlay) {
                El e = new El();
                e.view = root;
                e.o = ro;
                e.root = true;
                e.group = group;
                e.name = rootName(root, group);
                e.line = "line".equals(group) || "canvas".equals(group);
                e.wDp = U.toDp(ctx, root.getWidth());
                e.hDp = U.toDp(ctx, root.getHeight());
                fillOriginal(e, ro, root, ctx);
                e.sub = group + " window  \u2022  " + e.wDp + " x " + e.hDp + " dp";
                out.add(e);
            }
            collectChildren(root, ro, ctx, out, group, 0);
        }
        return out;
    }

    private static void fillOriginal(El e, Orig o, View v, Context ctx) {
        e.owDp = U.toDp(ctx, o.mw > 0 ? o.mw : v.getWidth());
        e.ohDp = U.toDp(ctx, o.mh > 0 ? o.mh : v.getHeight());
        e.otDp = o.textPx > 0 ? Math.round(o.textPx / U.density(ctx)) : 0;
    }

    /** Every window of the app that can be kept or removed, visible or not. */
    static List<Win> windows(Context ctx) {
        ArrayList<Win> out = new ArrayList<Win>();
        List<View> all = roots();
        for (int i = 0; i < all.size() && out.size() < 80; i++) {
            View root = all.get(i);
            if (Panel.isOwn(root)) continue;
            if (ORIG.get(root) == null && (root.getWidth() <= 0 || root.getHeight() <= 0)) continue;
            boolean overlay = isOverlay(root);
            Orig ro = rootOrig(root, overlay);
            Win w = new Win();
            w.root = root;
            w.o = ro;
            w.locked = ro.screen;
            Rules.Rule r = Rules.get(ro.key);
            w.gone = r != null && r.hide;
            String t = firstText(root, 0);
            if (t != null) {
                t = t.trim();
                if (t.length() > 24) t = t.substring(0, 24);
            }
            if (overlay) {
                w.kind = effectiveKind(ro);
                String label = "menu".equals(w.kind) ? "Menu" : ("icon".equals(w.kind) ? "Menu icon"
                        : ("line".equals(w.kind) ? "Line" : ("canvas".equals(w.kind) ? "Drawing layer" : "Floating button")));
                w.name = t == null ? label : label + ": " + t;
                w.sub = "floating window";
            } else if (ro.screen) {
                w.kind = "screen";
                w.name = "Screen: " + activityName(root.getContext());
                w.sub = "main screen (cannot be removed, only styled)";
            } else {
                w.kind = "popup";
                w.name = t == null ? "Popup / dialog" : "Popup: " + t;
                w.sub = "popup or dialog";
            }
            out.add(w);
            if (!w.locked) SEEN.put(ro.key, new String[] {w.name, w.kind, w.sub});
        }
        // windows seen earlier (this run or before) that are closed right now
        for (java.util.Map.Entry<String, String[]> en : SEEN.entrySet()) {
            boolean open = false;
            for (int i = 0; i < out.size(); i++) {
                if (out.get(i).o.key.equals(en.getKey())) {
                    open = true;
                    break;
                }
            }
            if (open) continue;
            Win w = new Win();
            w.o = new Orig();
            w.o.key = en.getKey();
            w.name = en.getValue()[0];
            w.kind = en.getValue()[1];
            w.sub = en.getValue()[2] + "  \u2022  not open now";
            Rules.Rule r = Rules.get(en.getKey());
            w.gone = r != null && r.hide;
            out.add(w);
        }
        return out;
    }

    static org.json.JSONArray seenArray() {
        org.json.JSONArray a = new org.json.JSONArray();
        try {
            for (java.util.Map.Entry<String, String[]> en : SEEN.entrySet()) {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("k", en.getKey());
                o.put("n", en.getValue()[0]);
                o.put("kd", en.getValue()[1]);
                o.put("s", en.getValue()[2]);
                a.put(o);
            }
        } catch (Throwable t) {
            U.err("seen", t);
        }
        return a;
    }

    static void loadSeen(org.json.JSONArray a) {
        if (a == null) return;
        for (int i = 0; i < a.length() && i < 200; i++) {
            org.json.JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String k = o.optString("k", "");
            if (k.length() == 0) continue;
            SEEN.put(k, new String[] {o.optString("n", k), o.optString("kd", "popup"), o.optString("s", "")});
        }
    }

    private static String rootName(View root, String group) {
        String t = firstText(root, 0);
        String label = "menu".equals(group) ? "Menu" : ("icon".equals(group) ? "Floating icon" : "Floating button");
        if (t == null) return label;
        t = t.trim();
        if (t.length() > 24) t = t.substring(0, 24);
        return label + ": " + t;
    }

    private static void collectChildren(View v, Orig o, Context ctx, ArrayList<El> out, String group, int depth) {
        if (!(v instanceof ViewGroup) || depth > 25) return;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount() && out.size() < 400; i++) {
            View c = g.getChildAt(i);
            if (c == null) continue;
            Orig co = childOrig(c, o.key, i);
            El e = listed(c, co, ctx, group);
            if (e != null) out.add(e);
            collectChildren(c, co, ctx, out, group, depth + 1);
        }
    }

    private static El listed(View v, Orig o, Context ctx, String group) {
        boolean text = v instanceof TextView;
        boolean image = v instanceof ImageView;
        boolean thin = false;
        boolean visible = (v.isShown() && v.getWidth() > 0 && v.getHeight() > 0) || o.hidden;
        if (!visible) return null;
        String name = null;
        if (text) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null && cs.toString().trim().length() > 0) name = cs.toString().trim();
            if (name == null && v.getContentDescription() != null) name = v.getContentDescription().toString();
            if (name == null && !o.hidden) return null;
        } else if (image) {
            CharSequence cd = v.getContentDescription();
            if (!v.isClickable() && cd == null) return null;
            name = cd != null ? cd.toString() : "Icon";
        } else if (v.isClickable() && !(v instanceof ViewGroup)) {
            name = v.getClass().getSimpleName();
        } else if (isThin(v, o, U.density(ctx))) {
            name = "Line";
            thin = true;
        } else {
            return null;
        }
        if (name == null) name = text ? "(empty text)" : "Item";
        if (name.length() > 40) name = name.substring(0, 40);
        El e = new El();
        e.view = v;
        e.o = o;
        e.group = group;
        e.isText = text;
        e.isImage = image;
        e.line = thin;
        e.name = name;
        e.wDp = U.toDp(ctx, v.getWidth());
        e.hDp = U.toDp(ctx, v.getHeight());
        fillOriginal(e, o, v, ctx);
        String what = text ? ((v instanceof Button) ? "button" : "text") : (image ? "icon" : "view");
        String id = resName(v);
        e.sub = what + "  \u2022  " + e.wDp + " x " + e.hDp + " dp" + (id == null ? "" : "  \u2022  " + id);
        return e;
    }

    private static String resName(View v) {
        try {
            int id = v.getId();
            if (id == View.NO_ID || id == 0) return null;
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return null;
        }
    }
}
