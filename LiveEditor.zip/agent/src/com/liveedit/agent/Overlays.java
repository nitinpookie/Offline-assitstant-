package com.liveedit.agent;

import android.content.Context;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;

/**
 * Floating overlay buttons live in their own windows (added with WindowManager), not inside an
 * Activity, so the normal view picker cannot reach them. This class reads the list of all windows
 * of the process and:
 *   - scales every overlay window (window size, view sizes, margins, paddings, text size)
 *   - sets the window opacity
 *   - turns off the click sound effect of every view (optional)
 * Everything is computed from the ORIGINAL values, so moving a slider back to 100% restores the app.
 */
final class Overlays {

    /** {rawW, rawH, margins l,t,r,b, paddings l,t,r,b, baseW, baseH} for child views. */
    private static final WeakHashMap<View, int[]> VIEW0 = new WeakHashMap<View, int[]>();
    /** {rawW, rawH, alpha, baseW, baseH} for overlay window roots. */
    private static final WeakHashMap<View, float[]> WIN0 = new WeakHashMap<View, float[]>();
    private static final WeakHashMap<TextView, Float> TEXT0 = new WeakHashMap<TextView, Float>();

    private static boolean touched;

    private Overlays() {}

    /** All window root views of this process, or an empty list if Android does not allow reading them. */
    static List<View> roots() {
        ArrayList<View> out = new ArrayList<View>();
        try {
            Class<?> c = Class.forName("android.view.WindowManagerGlobal");
            Object g = c.getMethod("getInstance").invoke(null);
            Field f = c.getDeclaredField("mViews");
            f.setAccessible(true);
            Object o = f.get(g);
            if (o instanceof List) {
                List<Object> copy = new ArrayList<Object>((List<?>) o);
                for (int i = 0; i < copy.size(); i++) {
                    if (copy.get(i) instanceof View) out.add((View) copy.get(i));
                }
            }
        } catch (Throwable t) {
            U.err("cannot read app windows", t);
        }
        return out;
    }

    static boolean isOverlay(View root) {
        ViewGroup.LayoutParams lp = root.getLayoutParams();
        if (!(lp instanceof WindowManager.LayoutParams)) return false;
        int t = ((WindowManager.LayoutParams) lp).type;
        return t >= 2000 && t < 3000 && t != 2005; // system-level windows, not toasts
    }

    static List<View> overlayRoots() {
        ArrayList<View> out = new ArrayList<View>();
        List<View> all = roots();
        for (int i = 0; i < all.size(); i++) {
            if (isOverlay(all.get(i))) out.add(all.get(i));
        }
        return out;
    }

    /** Called about once a second, and right after a slider moves. */
    static void tick(Context ctx) {
        boolean needed = touched || Config.overlayChanged();
        if (!needed) return;
        try {
            List<View> all = roots();
            for (int i = 0; i < all.size(); i++) {
                View r = all.get(i);
                if (Config.mute) mute(r);
                if (isOverlay(r)) {
                    try {
                        applyOverlay(ctx, r);
                    } catch (Throwable t) {
                        U.err("overlay apply", t);
                    }
                }
            }
        } catch (Throwable t) {
            U.err("overlay tick", t);
        }
    }

    // ---- sound -----------------------------------------------------------------------------

    private static void mute(View v) {
        if (v.isSoundEffectsEnabled()) v.setSoundEffectsEnabled(false);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) mute(g.getChildAt(i));
        }
    }

    // ---- size and opacity ------------------------------------------------------------------

    private static void applyOverlay(Context ctx, View root) {
        float f = Config.scale / 100f;
        WindowManager.LayoutParams wlp = (WindowManager.LayoutParams) root.getLayoutParams();

        float[] w0 = WIN0.get(root);
        if (w0 == null) {
            w0 = new float[] {wlp.width, wlp.height, wlp.alpha, wlp.width, wlp.height};
            // A wrap-content window around a single view: use its current pixel size as the base.
            if (!(root instanceof ViewGroup)) {
                if (wlp.width <= 0 && root.getWidth() > 0) w0[3] = root.getWidth();
                if (wlp.height <= 0 && root.getHeight() > 0) w0[4] = root.getHeight();
            }
            WIN0.put(root, w0);
        }

        boolean changed = false;
        int nw = (f == 1f || w0[3] <= 0) ? (int) w0[0] : Math.round(w0[3] * f);
        int nh = (f == 1f || w0[4] <= 0) ? (int) w0[1] : Math.round(w0[4] * f);
        if (wlp.width != nw) {
            wlp.width = nw;
            changed = true;
        }
        if (wlp.height != nh) {
            wlp.height = nh;
            changed = true;
        }
        float na = Config.alpha >= 100 ? w0[2] : Config.alpha / 100f;
        if (Math.abs(wlp.alpha - na) > 0.001f) {
            wlp.alpha = na;
            changed = true;
        }

        scaleTree(root, f, true);

        if (changed) {
            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            wm.updateViewLayout(root, wlp);
        }
        touched = true;
    }

    private static void scaleTree(View v, float f, boolean isRoot) {
        if (!isRoot) scaleView(v, f);
        if (v instanceof TextView) scaleText((TextView) v, f);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) scaleTree(g.getChildAt(i), f, false);
        }
    }

    private static void scaleText(TextView t, float f) {
        Float base = TEXT0.get(t);
        if (base == null) {
            base = Float.valueOf(t.getTextSize());
            TEXT0.put(t, base);
        }
        float want = f == 1f ? base.floatValue() : base.floatValue() * f;
        if (Math.abs(t.getTextSize() - want) > 0.5f) {
            t.setTextSize(TypedValue.COMPLEX_UNIT_PX, want);
        }
    }

    private static void scaleView(View v, float f) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (lp == null) return;
        ViewGroup.MarginLayoutParams mlp =
                lp instanceof ViewGroup.MarginLayoutParams ? (ViewGroup.MarginLayoutParams) lp : null;

        int[] o = VIEW0.get(v);
        if (o == null) {
            o = new int[12];
            o[0] = lp.width;
            o[1] = lp.height;
            if (mlp != null) {
                o[2] = mlp.leftMargin;
                o[3] = mlp.topMargin;
                o[4] = mlp.rightMargin;
                o[5] = mlp.bottomMargin;
            }
            o[6] = v.getPaddingLeft();
            o[7] = v.getPaddingTop();
            o[8] = v.getPaddingRight();
            o[9] = v.getPaddingBottom();
            o[10] = lp.width;
            o[11] = lp.height;
            // Images that wrap their drawable: use the pixel size they have now as the base.
            if (v instanceof ImageView) {
                if (lp.width <= 0 && v.getWidth() > 0) o[10] = v.getWidth();
                if (lp.height <= 0 && v.getHeight() > 0) o[11] = v.getHeight();
            }
            VIEW0.put(v, o);
        }

        boolean changed = false;
        int nw = (f == 1f || o[10] <= 0) ? o[0] : Math.round(o[10] * f);
        int nh = (f == 1f || o[11] <= 0) ? o[1] : Math.round(o[11] * f);
        if (lp.width != nw) {
            lp.width = nw;
            changed = true;
        }
        if (lp.height != nh) {
            lp.height = nh;
            changed = true;
        }
        if (mlp != null) {
            int ml = Math.round(o[2] * f);
            int mt = Math.round(o[3] * f);
            int mr = Math.round(o[4] * f);
            int mb = Math.round(o[5] * f);
            if (mlp.leftMargin != ml || mlp.topMargin != mt || mlp.rightMargin != mr || mlp.bottomMargin != mb) {
                mlp.setMargins(ml, mt, mr, mb);
                changed = true;
            }
        }
        if (changed) v.setLayoutParams(lp);

        int pl = Math.round(o[6] * f);
        int pt = Math.round(o[7] * f);
        int pr = Math.round(o[8] * f);
        int pb = Math.round(o[9] * f);
        if (v.getPaddingLeft() != pl || v.getPaddingTop() != pt
                || v.getPaddingRight() != pr || v.getPaddingBottom() != pb) {
            v.setPadding(pl, pt, pr, pb);
        }
    }
}
