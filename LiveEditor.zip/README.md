# Live Editor (v1)

> Isi repo mein jahan FastLink Browser (ya koi aur Gradle app) ki zip daalte ho, wahi is
> `LiveEditor.zip` ko bhi daal sakte ho. `.github/workflows/build.yml` khud pehchan leta hai
> ki naya daala gaya zip ek Gradle app hai ya Live Editor project, aur usi ke hisaab se build
> chalata hai — jo zip sabse naya hoga wahi build hoga.

Edit the UI of a running Android app, even if its real `classes.dex` only loads after launch.

It works by putting a small agent **inside the target app**. The agent starts before the app's own
code and watches every screen, so it sees the real views after the app has loaded everything.

## What v1 does

- Floating **UI** button on every screen (drag it anywhere, tap it for the menu)
- **Pick a view**: touch any view, release, and edit it
- Editable: text, text size, text color, background color, alpha, visibility (hide/show),
  width/height, image tint. "Select parent" climbs up to the container.
- **Saved rules**: every edit is stored and re-applied each time the screen opens, so you do not rebuild
  after each change. Rules can be viewed, deleted, or copied as JSON.
- **View tree**: dump the whole view hierarchy (also written to logcat, tag `LiveEditor`)
- Works for packed/encrypted apps too: the original dex is not touched, and a fallback finds screens
  even when the app swaps its Application object.

## How to use (from the phone, with GitHub)

1. Upload this project to a GitHub repo (keep the `.github/workflows/build.yml` path).
2. Put the app you want to edit in `target/` (one normal `.apk`), **or** skip that and paste a direct
   download link in the workflow's `apk_url` box.
3. Actions tab -> **Build Live Editor** -> Run workflow.
4. Download the artifact `LiveEditor-output`: `out/patched.apk` is the app with the editor inside.
5. Uninstall the original app, install `patched.apk`, open it, tap **UI**.

The artifact also contains `agent.dex`. If you prefer MT Manager: add `agent.dex` to the APK as the
next free `classesN.dex`, add this inside `<application>` in the manifest, then sign:

```xml
<provider android:name="com.liveedit.agent.AgentProvider"
          android:authorities="YOUR.PACKAGE.liveeditagent"
          android:exported="false"
          android:initOrder="2147483647"/>
```

## Limits (v1)

- Edits views inside the app's activities. Dialogs, popups, and other windows are not picked yet.
- Single APK only (not split APKs / bundles).
- The patched app has a different signature, so the original must be uninstalled first (its data is lost).
  Apps that check their own signature or integrity may refuse to start.
- List items are matched by position, so rules on rows inside lists can jump when the list changes.
- Removing a value from a rule restores the original look only after the screen reopens.
- Use it on apps you own, or for personal customization on your own device.

## Files

- `agent/src/com/liveedit/agent/` - the agent (Agent, AgentProvider, Ui, Rules, Sel, Applier, TreeDump)
- `tools/build_agent.sh` - javac + d8 -> `build/agent.dex`
- `tools/inject.sh` - apktool decode (no-src) -> add provider -> rebuild -> add dex -> zipalign -> sign
- `keystore/liveeditor.jks` - fixed debug key (password `liveeditor`) so patched builds can update in place
