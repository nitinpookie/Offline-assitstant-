# Live Editor

Pro APK patcher for Android. Pick an app, tick the options you want, tap **Patch**.
Everything is decided before patching. The patched app gets **no editor, no button and no menu**.

## What you can change (no coding)
- App name, version name, version code
- Remove permissions (internet, location, contacts, camera ... or any you tick)
- Switch off parts of the app (auto-start after boot, services, screens)
- Block ad servers, tracker servers, servers found inside the app, or your own list
- Hide ad banners, mute click sounds, fullscreen, keep screen on, allow screenshots
- Lock rotation, faster or no animations
- Resize / fade floating overlay buttons
- Debuggable / backup / plain HTTP / large heap flags
- Keep only one CPU type (smaller APK)
- One-tap presets: Privacy, Ads off, Smaller, Faster UI

## How it works
- Manifest options are written straight into the binary `AndroidManifest.xml` (no apktool).
- Options that need code at run time (server blocking, hide ads, overlay size, screen flags ...) are saved
  as `assets/liveedit_config.json` inside the APK, and a tiny silent engine (`agent.dex`) reads it at start.
  If no such option is ticked, no engine is added at all.
- The patched APK is signed with the key in `app/src/main/assets` (v1 + v2), checked with Android's own
  package parser, then installed from the same screen.

## Limits (honest)
- It changes the phone side only. It cannot change what a server sends back.
- Server blocking covers HttpURLConnection and OkHttp. WebView pages, Cronet/QUIC and raw sockets can still connect.
- Single APK only (no XAPK/APKS/split apps). System apps without code inside their APK cannot be patched.
- Apps that check their own signature may refuse to start. The original must be uninstalled first (data is lost).
- Compose / Flutter / game UIs are not affected by "hide ad banners" (it looks for classic ad views).

## Build (GitHub Actions)
Same as the other projects: upload this zip to the repo root, the existing workflow unzips it and builds.
The project module is called `app`. The silent engine (`agent.dex`) is compiled by `app/build.gradle`
(it runs `tools/build_agent.sh` when Gradle starts), so no extra workflow step is needed.
