# Live Editor

Pro APK patcher for Android. Pick an app, tick the options you want, tap **Patch**.

## What you can change (no coding)
- App name, version name, version code
- Remove permissions (internet, location, contacts, camera ... or any you tick)
- Switch off parts of the app (auto-start after boot, services, screens)
- Block ad servers, tracker servers, servers found inside the app, or your own list
- Hide ad banners, mute click sounds, fullscreen, keep screen on, allow screenshots
- Lock rotation, faster or no animations
- Debuggable / backup / plain HTTP / large heap flags
- Keep only one CPU type (smaller APK) + a "compatible with this phone" check (ARMv7 etc.)
- One-tap presets: Privacy, Ads off, Smaller, Faster UI

### New in 2.0
- **Floating buttons and Menu are separate.** Size (in **dp**), opacity (%), text size (dp). Changing the buttons no
  longer makes the menu huge (the old single "overlay size" scaled everything in every overlay window).
- **Live Editor inside the app** (optional switch): a pencil handle appears in the patched app. It lists everything
  that is visible (menus, floating buttons, icons, texts of overlays AND app screens / login page; background-only
  parts are not listed). Tap any item to change **size (dp), text size (dp), colour, name, opacity, hide**.
  Global button / menu sliders and a theme editor are in the same panel. Values are shown in dp, opacity in %.
- **App theme**: background, text and button colours for the whole app (ready-made themes or your own hex colours).
- **Links**: block links that throw you out of the app (browser, Telegram, Play Store ...) at app start or always.
  The link is skipped, the app keeps running (no crash).
- **Timers**: hide or replace countdown-like texts (00:59, "3 days left" ...).
- **Convert live APK to normal**: in the pencil panel tap *More > Copy settings*. In Live Editor choose
  *Convert live APK to normal*, pick that app, tap *Paste settings*, leave "Live Editor inside the app" off, Patch.
  You get a normal APK with all edits baked in and no handle.
- **ARMv7 / your CPU**: the options screen tells if the app has libraries for your phone and can keep only that CPU type.
  Native libraries cannot be converted from one CPU type to another (an arm64-only app cannot run on an ARMv7 phone).

### New in 2.1
- **Normal structure (for MT Manager)**: options screen > *Normal APK*. Every file is opened and checked; zip tricks that stop
  tools from opening the code files (a fake "encrypted" flag, a wrong size or checksum in the header) are repaired. The files
  themselves are not changed. An APK that Android's zip reader refuses is repaired automatically when you pick it.
  Code that is packed or encrypted by a protection tool is NOT unpacked (it only unpacks while the app runs): it stays as it is.
- **ARMv7 best-effort mode** (only shown when the app has no libraries for this phone and the phone is ARMv7): the app's native
  libraries are replaced by empty stand-ins (stored, aligned) so it installs and starts. Anything that needs those libraries
  stops working, and the engine keeps the app alive when such a call fails. Some apps will still close.
  The stand-in is an empty 32-bit ARM library built in code (`StubElf.java`); it was checked with `readelf`, not on a real phone.
- **Settings without copy and paste**: when you pick an installed app that was patched with this version, its settings
  (baked edits plus pencil edits) are read straight from it (the engine has a small provider that only answers Live Editor).
  The *Load settings from the installed app* button does the same later. Pasting still works.
- **Timers**: a bare 00:59 is only treated as a timer after it changed a few times within seconds; "10:30 AM", dates and fixed
  labels are left alone. Texts with words like "left" or "expires" still count at once.

## How it works
- Manifest options are written straight into the binary `AndroidManifest.xml` (no apktool).
- Options that need code at run time are saved as `assets/liveedit_config.json` inside the APK, and a small engine
  (`agent.dex`) reads it at start. If no such option is ticked, no engine is added at all.
- The patched APK is signed with the key in `app/src/main/assets` (v1 + v2), checked with Android's own
  package parser, then installed from the same screen.

## Limits (honest)
- It changes the phone side only. It cannot change what a server sends back, or how an app counts a timer.
- Server blocking covers HttpURLConnection and OkHttp. WebView pages, Cronet/QUIC and raw sockets can still connect.
- Link blocking works on links the app starts itself (Intent). Links opened inside a WebView are not covered.
- The pencil handle needs "Display over other apps" for the patched app. Item list reads the app's windows through
  Android internals: on some Android versions it may only see the visible screen.
- Compose / Flutter / game UIs only partly work (they draw without normal views).
- ARMv7 best-effort mode cannot give an app the code it needs: games and apps built around native libraries will not work.
- Auto-loading settings needs an app patched with this version (older patched apps: use copy and paste).
- Single APK only (no XAPK/APKS/split apps). System apps without code inside their APK cannot be patched.
- Apps that check their own signature may refuse to start. The original must be uninstalled first (data is lost).

## Build (GitHub Actions)
Same as the other projects: upload this zip to the repo root, the existing workflow unzips it and builds.
The project module is called `app`. The engine (`agent.dex`) is compiled by `app/build.gradle`
(it runs `tools/build_agent.sh` when Gradle starts), so no extra workflow step is needed.
There is no workflow file inside this zip on purpose: the one already in your repo is used.
