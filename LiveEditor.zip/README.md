# Live Editor

Pro APK patcher for Android. Pick an app, tick the options you want, tap **Patch**.

## What you can change (no coding)
- App name, version name, version code
- Remove permissions (internet, location, contacts, camera ... or any you tick)
- Switch off parts of the app (auto-start after boot, services, screens)
- Block ad servers, tracker servers, servers found inside the app, or your own list
- Hide ad banners, mute click sounds, fullscreen, keep screen on, allow screenshots
- Lock rotation, faster or no animations
- Debuggable / backup / plain HTTP / large heap flags
- Keep only one CPU type (smaller APK) + a "compatible with this phone" check (ARMv7 etc.)
- One-tap presets: Privacy, Ads off, Smaller, Faster UI

### New in 2.0
- **Floating buttons and Menu are separate.** Size (in **dp**), opacity (%), text size (dp). Changing the buttons no
  longer makes the menu huge (the old single "overlay size" scaled everything in every overlay window).
- **Live Editor inside the app** (optional switch): a pencil handle appears in the patched app. It lists everything
  that is visible (menus, floating buttons, icons, texts of overlays AND app screens / login page; background-only
  parts are not listed). Tap any item to change **size (dp), text size (dp), colour, name, opacity, hide**.
  Global button / menu sliders and a theme editor are in the same panel. Values are shown in dp, opacity in %.
- **App theme**: background, text and button colours for the whole app (ready-made themes or your own hex colours).
- **Links**: block links that throw you out of the app (browser, Telegram, Play Store ...) at app start or always.
  The link is skipped, the app keeps running (no crash).
- **Timers**: hide or replace countdown-like texts (00:59, "3 days left" ...).
- **Convert live APK to normal**: in the pencil panel tap *More > Copy settings*. In Live Editor choose
  *Convert live APK to normal*, pick that app, tap *Paste settings*, leave "Live Editor inside the app" off, Patch.
  You get a normal APK with all edits baked in and no handle.
- **ARMv7 / your CPU**: the options screen tells if the app has libraries for your phone and can keep only that CPU type.
  Native libraries cannot be converted from one CPU type to another (an arm64-only app cannot run on an ARMv7 phone).

### New in 2.1
- **Normal structure (for MT Manager)**: options screen > *Normal APK*. Every file is opened and checked; zip tricks that stop
  tools from opening the code files (a fake "encrypted" flag, a wrong size or checksum in the header) are repaired. The files
  themselves are not changed. An APK that Android's zip reader refuses is repaired automatically when you pick it.
  Code that is packed or encrypted by a protection tool is NOT unpacked (it only unpacks while the app runs): it stays as it is.
- **ARMv7 best-effort mode** (only shown when the app has no libraries for this phone and the phone is ARMv7): the app's native
  libraries are replaced by empty stand-ins (stored, aligned) so it installs and starts. Anything that needs those libraries
  stops working, and the engine keeps the app alive when such a call fails. Some apps will still close.
  The stand-in is an empty 32-bit ARM library built in code (`StubElf.java`); it was checked with `readelf`, not on a real phone.
- **Settings without copy and paste**: when you pick an installed app that was patched with this version, its settings
  (baked edits plus pencil edits) are read straight from it (the engine has a small provider that only answers Live Editor).
  The *Load settings from the installed app* button does the same later. Pasting still works.
- **Timers**: a bare 00:59 is only treated as a timer after it changed a few times within seconds; "10:30 AM", dates and fixed
  labels are left alone. Texts with words like "left" or "expires" still count at once.

### New in 2.2
- **Four separate size groups**: menu icon (the first small floating window = the button that opens the menu), floating
  buttons, menu panels, and line overlays. Each has its own size, opacity and text size. Change one, the others stay.
- **Sizes can go smaller and bigger**: icon, buttons and menu use percent (100% = original, 20% to 400%); every single
  item in the pencil panel shows its original dp and can go below or above it. Text size 50% to 300%.
- **Line thickness**: a thin line window or thin view gets a thickness slider (global and per item) that can go thinner
  or thicker. A line the app paints itself on a canvas cannot be re-drawn from outside.
- **Windows tab (pencil panel)**: a list of every menu, floating button, popup and dialog with a *Keep this interface*
  switch. Removed = hidden and untouchable (touches pass through), never detached, so the app cannot crash from it.
  Popups that are closed now stay in the list. The main screen can be styled but not removed.
- **No flicker**: windows are changed before their first frame (the engine is told the moment the app adds a window)
  and before every later frame of floating windows and popups, so the original look / colour / opacity is never shown
  for a moment. The 0.7 s timer stays as a safety net.
- **Lines drawn by the app itself** (a line from the top origin painted on a canvas): the engine finds the app's Paint
  objects by reflection and sets their stroke width (global *Lines* slider or per item). Works when the app keeps its
  Paint in a field; a Paint created fresh on every draw cannot be reached.
- **Timer editor** (options screen > *Timers in this app*): lists the places in the app's code that start something
  after a delay (Handler.postDelayed, Timer, CountDownTimer, scheduled executors) with the delay in ms. Tap one to set a
  new delay or *Never*; the number is written into classes.dex when you tap Patch (same length, dex checksum and SHA-1
  fixed, APK re-signed). Places up to 32767 ms are edited in place (or Never); a delay that is calculated by the app
  cannot be edited. *LINE:* entries are the numbers next to `Paint.setStrokeWidth` (line thickness): edit them the same
  way (for example 1.5 -> 1). Edits are checked against the real code at patch time and skipped if they do not match.
- **Components list** (*Switch off parts of the app*): the main screen, services and providers are marked, and a
  warning with an *Undo these (safe)* button appears when one of them is switched off (it can crash the app).
- **Windows tab** shows a small picture of each window, so it is clear which interface is which.
- Old settings with sizes in dp are not carried over (sizes are percent now).

### New in 2.3: nixu cn mode (MT Manager style)
Top right of the home screen there is a **nixu cn** switch. ON = the simple options are hidden and the app opens APKs in an
MT Manager style editor (`NixuActivity`). OFF = everything works as before.

- **File list**: every entry of the APK is shown (assets, lib, res, META-INF, classes*.dex, resources.arsc, AndroidManifest.xml ...).
  Nothing is hidden. Folders first, size and date per row, long-press to select, add / replace / rename / delete / extract.
- **Open with...** per file type:
  - `AndroidManifest.xml` and every compiled `res/*.xml`: *XML editor* (compiled XML shown as text, compiled again on save;
    values keep their exact type: `true`, `123`, `0x7f`, `#ffffff`, `16dp`, `@0x7f010001`, `f:1.5`; plain text that looks like
    one of those gets a leading backslash).
  - `resources.arsc`: *Arsc Editor plus* (package > type > resource > configuration), *Arsc Editor* (flat list with search),
    *Translation mode* (every text value, edit once = everywhere), *Resource querier* (search by name, id or value).
    Strings, numbers, booleans, colours, dimensions and references can be changed. A string shared by several entries is
    copied (the other entries keep their text).
  - `classes*.dex`: *Dex Editor Plus* (class list with search, fields, methods, bytecode of a method as text with the address of
    each instruction), *Dex strings*, *Dex method search*.
    Instruction edit: tap a line, type one instruction (`const/4 v0, 0x1`, `if-nez v0, :0012`, `invoke-static {v0}, Lcom/Foo;->bar(I)V`,
    `const-string v0, "text"` ...). It must fit the old instruction (same size or smaller, the rest becomes `nop`), registers must
    exist, references must already exist in this dex (or use `string@12`, `method@34`).
    Quick patches in the menu: return void / true / false / null / a number.
    Strings can be changed in place (same size; a shorter text can be padded with spaces).
  - Text editor, hex editor (tap a row, change the bytes), image viewer.
- **Save**: builds a new APK (untouched entries are copied byte for byte, resources.arsc is stored and aligned), signs it with the
  built-in key (v1 + v2) and offers Install / Share / Save a copy.
- **Export for Claude**: one `.nixu.txt` file with the file list, the manifest as text, all resources, the dex class list
  (optionally methods, or full smali text of the classes whose name contains a filter). Send that file to be read.

Limits of nixu cn (honest):
- The dex editor patches inside the existing file, so nothing can grow: no new classes, methods or strings, no full smali recompile.
  Edit a string only to a text that fits the old size. Keeping dex strings sorted is not re-checked.
- Old signature files (META-INF/*.SF, *.RSA, MANIFEST.MF) are dropped on Save; the new signature replaces them.
- Code packed or encrypted by a protection tool is not unpacked.
- Not run on a phone yet: the file-format engines (`NixuPool/NixuAxml/NixuArsc/NixuDex/NixuZip/NixuExport`) were tested on the
  PC with generated sample files; the screens (`NixuActivity`) were only compile-checked against stand-ins for the Android classes.

## How it works
- Manifest options are written straight into the binary `AndroidManifest.xml` (no apktool).
- Options that need code at run time are saved as `assets/liveedit_config.json` inside the APK, and a small engine
  (`agent.dex`) reads it at start. If no such option is ticked, no engine is added at all.
- The patched APK is signed with the key in `app/src/main/assets` (v1 + v2), checked with Android's own
  package parser, then installed from the same screen.

## Limits (honest)
- It changes the phone side only. It cannot change what a server sends back, or how an app counts a timer.
- Server blocking covers HttpURLConnection and OkHttp. WebView pages, Cronet/QUIC and raw sockets can still connect.
- Link blocking works on links the app starts itself (Intent). Links opened inside a WebView are not covered.
- The pencil handle needs "Display over other apps" for the patched app. Item list reads the app's windows through
  Android internals: on some Android versions it may only see the visible screen.
- Compose / Flutter / game UIs only partly work (they draw without normal views).
- ARMv7 best-effort mode cannot give an app the code it needs: games and apps built around native libraries will not work.
- Auto-loading settings needs an app patched with this version (older patched apps: use copy and paste).
- Single APK only (no XAPK/APKS/split apps). System apps without code inside their APK cannot be patched.
- Apps that check their own signature may refuse to start. The original must be uninstalled first (data is lost).

## Build (GitHub Actions)
Same as the other projects: upload this zip to the repo root, the existing workflow unzips it and builds.
The project module is called `app`. The engine (`agent.dex`) is compiled by `app/build.gradle`
(it runs `tools/build_agent.sh` when Gradle starts), so no extra workflow step is needed.
There is no workflow file inside this zip on purpose: the one already in your repo is used.
