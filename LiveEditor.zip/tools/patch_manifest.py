#!/usr/bin/env python3
"""Adds the Live Editor provider to an apktool-decoded AndroidManifest.xml."""
import re
import sys

PROVIDER_CLASS = "com.liveedit.agent.AgentProvider"


def main(path):
    with open(path, encoding="utf-8") as f:
        m = f.read()

    if PROVIDER_CLASS in m:
        print("manifest already patched")
        return

    pkg_m = re.search(r'<manifest[^>]*?\spackage="([^"]+)"', m, re.S)
    pkg = pkg_m.group(1) if pkg_m else "app"
    authority = pkg + ".liveeditagent"

    provider = (
        '<provider android:name="%s" android:authorities="%s" '
        'android:exported="false" android:initOrder="2147483647"/>'
    ) % (PROVIDER_CLASS, authority)

    if "</application>" in m:
        m = m.replace("</application>", "    " + provider + "\n    </application>", 1)
    else:
        # <application ... />  (self-closing)
        m, n = re.subn(
            r"(<application\b[^>]*?)\s*/>",
            lambda mo: mo.group(1) + ">\n    " + provider + "\n    </application>",
            m,
            count=1,
            flags=re.S,
        )
        if n == 0:
            sys.exit("could not find <application> in AndroidManifest.xml")

    with open(path, "w", encoding="utf-8") as f:
        f.write(m)
    print("provider added, authority:", authority)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("usage: patch_manifest.py AndroidManifest.xml")
    main(sys.argv[1])
