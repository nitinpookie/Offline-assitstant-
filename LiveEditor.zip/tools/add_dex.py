#!/usr/bin/env python3
"""Adds agent.dex to an APK as the next free classesN.dex (classes.dex, classes2.dex, ...)."""
import re
import sys
import zipfile


def main(apk, dex):
    with zipfile.ZipFile(apk) as z:
        names = z.namelist()

    nums = []
    for n in names:
        m = re.fullmatch(r"classes(\d*)\.dex", n)
        if m:
            nums.append(int(m.group(1) or "1"))

    nxt = (max(nums) + 1) if nums else 1
    name = "classes.dex" if nxt == 1 else "classes%d.dex" % nxt

    with zipfile.ZipFile(apk, "a", zipfile.ZIP_DEFLATED) as z:
        z.write(dex, name)
    print("added", name)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("usage: add_dex.py app.apk agent.dex")
    main(sys.argv[1], sys.argv[2])
