#!/usr/bin/env bash
# Compiles agent/src/**/*.java into build/agent.dex (no Gradle needed).
set -euo pipefail
cd "$(dirname "$0")/.."

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"

PLATFORM="$(ls -d "$SDK"/platforms/android-* 2>/dev/null | grep -E 'android-[0-9]+$' | sort -V | tail -n1 || true)"
[ -n "$PLATFORM" ] || { echo "No Android platform found in $SDK"; exit 1; }
JAR="$PLATFORM/android.jar"

BT="$(ls -d "$SDK"/build-tools/* 2>/dev/null | grep -v -- '-rc' | sort -V | tail -n1 || true)"
[ -n "$BT" ] || { echo "No build-tools found in $SDK"; exit 1; }

echo "Using $JAR"
echo "Using $BT"

rm -rf build/classes build/dex
mkdir -p build/classes build/dex

javac -source 8 -target 8 -Xlint:-options -nowarn \
  -bootclasspath "$JAR" -d build/classes \
  $(find agent/src -name '*.java')

"$BT/d8" --release --min-api 21 --lib "$JAR" --output build/dex \
  $(find build/classes -name '*.class')

cp build/dex/classes.dex build/agent.dex
ls -l build/agent.dex
