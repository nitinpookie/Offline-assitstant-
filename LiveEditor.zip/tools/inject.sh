#!/usr/bin/env bash
# usage: tools/inject.sh target.apk build/agent.dex out/patched.apk
set -euo pipefail

IN="$1"
DEX="$2"
OUT="$3"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
BT="$(ls -d "$SDK"/build-tools/* 2>/dev/null | grep -v -- '-rc' | sort -V | tail -n1 || true)"
[ -n "$BT" ] || { echo "No Android build-tools found in $SDK"; exit 1; }

APKTOOL_VERSION="${APKTOOL_VERSION:-2.9.3}"
WORK="$ROOT/work"
mkdir -p "$WORK" "$(dirname "$OUT")"

APKTOOL="$WORK/apktool.jar"
if [ ! -f "$APKTOOL" ]; then
  curl -L --fail -o "$APKTOOL" \
    "https://github.com/iBotPeaches/Apktool/releases/download/v${APKTOOL_VERSION}/apktool_${APKTOOL_VERSION}.jar"
fi

echo "== 1/5 decode (sources untouched, so packed or encrypted dex stays byte-for-byte as is)"
rm -rf "$WORK/decoded" "$WORK/rebuilt.apk" "$WORK/aligned.apk"
java -jar "$APKTOOL" d -s -f "$IN" -o "$WORK/decoded"

echo "== 2/5 add provider to manifest"
python3 "$ROOT/tools/patch_manifest.py" "$WORK/decoded/AndroidManifest.xml"

echo "== 3/5 rebuild"
java -jar "$APKTOOL" b "$WORK/decoded" -o "$WORK/rebuilt.apk"

echo "== 4/5 add agent dex + align"
python3 "$ROOT/tools/add_dex.py" "$WORK/rebuilt.apk" "$DEX"
"$BT/zipalign" -p -f 4 "$WORK/rebuilt.apk" "$WORK/aligned.apk"

echo "== 5/5 sign"
KS="$ROOT/keystore/liveeditor.jks"
if [ ! -f "$KS" ]; then
  mkdir -p "$ROOT/keystore"
  keytool -genkeypair -keystore "$KS" -alias liveeditor -storepass liveeditor -keypass liveeditor \
    -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=LiveEditor"
fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias liveeditor \
  --ks-pass pass:liveeditor --key-pass pass:liveeditor \
  --out "$OUT" "$WORK/aligned.apk"
"$BT/apksigner" verify "$OUT"

echo "Done: $OUT"
