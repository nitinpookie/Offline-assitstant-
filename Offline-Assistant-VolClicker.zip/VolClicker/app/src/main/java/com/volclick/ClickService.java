package com.volclick;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class ClickService extends AccessibilityService {

    static ClickService inst;

    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences p;
    private WindowManager wm;
    private View marker;
    private WindowManager.LayoutParams mlp;

    private boolean running;
    private int count, max, interval, dur;
    private long t0;

    @Override
    protected void onServiceConnected() {
        inst = this;
        p = getSharedPreferences("s", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
    }

    // ---------- volume key ----------

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        int want = p.getInt("key", 0) == 0 ? KeyEvent.KEYCODE_VOLUME_DOWN : KeyEvent.KEYCODE_VOLUME_UP;
        if (e.getKeyCode() != want || !p.getBoolean("on", true)) return false;

        boolean hold = p.getInt("mode", 0) == 1;
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() == 0) {
                if (hold || !running) start();
                else stop();
            }
        } else if (hold) {
            stop();
        }
        return true; // consume, so the volume does not change
    }

    // ---------- click loop ----------

    private void start() {
        if (running) return;
        interval = Math.max(1, p.getInt("int", 100));
        dur = Math.max(1, p.getInt("dur", 10));
        max = p.getInt("max", 0);
        count = 0;
        running = true;
        setMarkerTouchable(false);
        if (p.getInt("mode", 0) == 0) buzz(40);
        h.postDelayed(tick, marker != null ? 80 : 0);
    }

    private void stop() {
        if (!running) return;
        running = false;
        h.removeCallbacks(tick);
        setMarkerTouchable(true);
        if (p.getInt("mode", 0) == 0) buzz(120);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            t0 = SystemClock.uptimeMillis();
            float[] c = pos();
            Path path = new Path();
            path.moveTo(c[0], c[1]);
            GestureDescription g = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, dur))
                    .build();
            if (!dispatchGesture(g, cb, null)) h.postDelayed(this, interval);
        }
    };

    private final AccessibilityService.GestureResultCallback cb =
            new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription g) {
                    next();
                }

                @Override
                public void onCancelled(GestureDescription g) {
                    next();
                }
            };

    private void next() {
        if (!running) return;
        if (max > 0 && ++count >= max) {
            stop();
            return;
        }
        long d = interval - (SystemClock.uptimeMillis() - t0);
        h.postDelayed(tick, d > 0 ? d : 0);
    }

    // ---------- click position / target marker ----------

    private float[] pos() {
        if (marker != null) {
            int[] l = new int[2];
            marker.getLocationOnScreen(l);
            return new float[]{l[0] + marker.getWidth() / 2f, l[1] + marker.getHeight() / 2f};
        }
        DisplayMetrics m = getResources().getDisplayMetrics();
        return new float[]{p.getFloat("x", m.widthPixels / 2f), p.getFloat("y", m.heightPixels / 2f)};
    }

    private void savePos() {
        if (marker == null) return;
        float[] c = pos();
        p.edit().putFloat("x", c[0]).putFloat("y", c[1]).apply();
    }

    void toggleMarker() {
        if (marker != null) {
            try {
                wm.removeView(marker);
            } catch (Exception ignored) {
            }
            marker = null;
            return;
        }
        DisplayMetrics m = getResources().getDisplayMetrics();
        final int sz = (int) (56 * m.density);
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                sz, sz,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        final int wantL = (int) (p.getFloat("x", m.widthPixels / 2f) - sz / 2f);
        final int wantT = (int) (p.getFloat("y", m.heightPixels / 2f) - sz / 2f);
        lp.x = wantL;
        lp.y = wantT;
        mlp = lp;

        marker = new Marker(this);
        marker.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            int sx, sy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX();
                        dy = e.getRawY();
                        sx = lp.x;
                        sy = lp.y;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + (int) (e.getRawX() - dx);
                        lp.y = sy + (int) (e.getRawY() - dy);
                        wm.updateViewLayout(v, lp);
                        break;
                    case MotionEvent.ACTION_UP:
                        v.post(new Runnable() {
                            @Override
                            public void run() {
                                savePos();
                            }
                        });
                        break;
                }
                return true;
            }
        });
        wm.addView(marker, lp);

        // if the system placed it a bit off (cutout / bars), nudge it back
        marker.post(new Runnable() {
            @Override
            public void run() {
                if (marker == null) return;
                int[] l = new int[2];
                marker.getLocationOnScreen(l);
                if (l[0] != wantL || l[1] != wantT) {
                    lp.x += wantL - l[0];
                    lp.y += wantT - l[1];
                    wm.updateViewLayout(marker, lp);
                }
            }
        });
    }

    // while clicking, let the taps pass through the marker
    private void setMarkerTouchable(boolean touchable) {
        if (marker == null || mlp == null) return;
        if (touchable) mlp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else mlp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        marker.setAlpha(touchable ? 1f : 0.35f);
        try {
            wm.updateViewLayout(marker, mlp);
        } catch (Exception ignored) {
        }
    }

    private static class Marker extends View {
        private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);

        Marker(Context c) {
            super(c);
            pt.setStyle(Paint.Style.STROKE);
            pt.setStrokeWidth(4f);
            pt.setColor(0xFFFF3B30);
        }

        @Override
        protected void onDraw(Canvas c) {
            float a = getWidth() / 2f, b = getHeight() / 2f, r = Math.min(a, b) - 4f;
            c.drawCircle(a, b, r, pt);
            c.drawLine(a - r, b, a + r, b, pt);
            c.drawLine(a, b - r, a, b + r, pt);
        }
    }

    @SuppressWarnings("deprecation")
    private void buzz(long ms) {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.vibrate(ms);
        } catch (Exception ignored) {
        }
    }

    // ---------- lifecycle ----------

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
        stop();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    private void cleanup() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (marker != null) {
            try {
                wm.removeView(marker);
            } catch (Exception ignored) {
            }
            marker = null;
        }
        if (inst == this) inst = null;
    }
}
