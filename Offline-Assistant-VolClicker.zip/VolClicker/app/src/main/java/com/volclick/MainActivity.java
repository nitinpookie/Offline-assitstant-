package com.volclick;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private SharedPreferences p;
    private LinearLayout root;
    private TextView status;
    private int pad;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("s", MODE_PRIVATE);
        pad = (int) (14 * getResources().getDisplayMetrics().density);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        tv("Vol Clicker", 26);
        status = tv("", 15);

        button("1. Turn on service (Accessibility)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        button("2. Show / hide target (drag it onto the spot)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClickService s = ClickService.inst;
                if (s == null) {
                    Toast.makeText(MainActivity.this, "Turn the service on first", Toast.LENGTH_SHORT).show();
                } else {
                    s.toggleMarker();
                }
            }
        });

        Switch en = new Switch(this);
        en.setText("Enabled (volume key triggers clicking)");
        en.setPadding(0, pad, 0, 0);
        en.setChecked(p.getBoolean("on", true));
        en.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton v, boolean c) {
                p.edit().putBoolean("on", c).apply();
            }
        });
        root.addView(en);

        tv("Trigger key", 16).setPadding(0, pad, 0, 0);
        radio("key", "Volume Down", "Volume Up");

        tv("Mode", 16).setPadding(0, pad, 0, 0);
        radio("mode", "Toggle: press to start, press again to stop", "Hold: clicks only while key is held");

        num("Click every (ms)", "int", 100, 1);
        num("Tap length (ms)", "dur", 10, 1);
        num("Stop after N clicks (0 = never)", "max", 0, 0);

        tv("Tip: press the key while the target app is open. The red target must sit on the spot you want to tap; hide it when not needed.", 13)
                .setPadding(0, pad, 0, 0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        status.setText(ClickService.inst != null
                ? "Service: ON"
                : "Service: OFF - enable \"Vol Clicker\" in Accessibility settings");
    }

    // ---------- tiny UI helpers ----------

    private TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        root.addView(t);
        return t;
    }

    private void button(String s, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(s);
        bt.setAllCaps(false);
        bt.setOnClickListener(l);
        root.addView(bt);
    }

    private void radio(final String key, String... names) {
        RadioGroup g = new RadioGroup(this);
        final int[] ids = new int[names.length];
        for (int i = 0; i < names.length; i++) {
            RadioButton r = new RadioButton(this);
            r.setText(names[i]);
            ids[i] = View.generateViewId();
            r.setId(ids[i]);
            g.addView(r);
        }
        g.check(ids[Math.min(p.getInt(key, 0), names.length - 1)]);
        g.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup grp, int id) {
                for (int i = 0; i < ids.length; i++) {
                    if (ids[i] == id) p.edit().putInt(key, i).apply();
                }
            }
        });
        root.addView(g);
    }

    private void num(String label, final String key, final int def, final int min) {
        tv(label, 16).setPadding(0, pad, 0, 0);
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(p.getInt(key, def)));
        e.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                int v;
                try {
                    v = Math.max(min, Integer.parseInt(s.toString().trim()));
                } catch (Exception x) {
                    v = def;
                }
                p.edit().putInt(key, v).apply();
            }
        });
        root.addView(e);
    }
}
