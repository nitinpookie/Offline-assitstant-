package com.spudlab.tater

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** The gloo wall mesh (positions, UV, triangles). side[t] = 1 when the triangle is seen from +z, 0 when it is seen from -z. */
class GlooMesh(val pos: FloatArray, val uv: FloatArray, val idx: IntArray, val side: ByteArray) {
    val nt = idx.size / 3
    val minX: Float; val maxX: Float; val minY: Float; val maxY: Float

    init {
        var a = Float.MAX_VALUE; var b = -Float.MAX_VALUE; var c = Float.MAX_VALUE; var d = -Float.MAX_VALUE
        var i = 0
        while (i < pos.size) {
            a = min(a, pos[i]); b = max(b, pos[i]); c = min(c, pos[i + 1]); d = max(d, pos[i + 1])
            i += 3
        }
        minX = a; maxX = b; minY = c; maxY = d
    }
}

/** What the user did to one photo (copied out of the screen state so a background thread can use it). */
class XfSnap(val pix: IntArray?, val pw: Int, val ph: Int, val scale: Float, val rot: Float, val tx: Float, val ty: Float, val flip: Boolean)

class Xf {
    var photo by mutableStateOf<Bitmap?>(null)
    var scale by mutableFloatStateOf(1f)
    var rot by mutableFloatStateOf(0f)
    var tx by mutableFloatStateOf(0f)
    var ty by mutableFloatStateOf(0f)
    var flip by mutableStateOf(false)
    private var pixCache: IntArray? = null
    private var pixFor: Bitmap? = null

    fun reset() { scale = 1f; rot = 0f; tx = 0f; ty = 0f; flip = false }

    fun snap(): XfSnap {
        val p = photo ?: return XfSnap(null, 0, 0, scale, rot, tx, ty, flip)
        if (pixFor !== p || pixCache == null) {
            val arr = IntArray(p.width * p.height)
            p.getPixels(arr, 0, p.width, 0, 0, p.width, p.height)
            pixCache = arr; pixFor = p
        }
        return XfSnap(pixCache, p.width, p.height, scale, rot, tx, ty, flip)
    }
}

object Gloo {
    const val TARGET = "IceWall_Bunker_Apple_GR_D"
    val FLAT = listOf("IceWall_Bunker_Apple_GR_N", "IceWall_Bunker_Apple_GR_S")
    const val BUNDLE = "optionalab_weapon_096."
    val PKGS = listOf("com.garena.game.ffi", "com.dts.freefiremax")
    fun gameName(pkg: String): String = if (pkg == "com.dts.freefiremax") "Free Fire MAX" else "Free Fire India"
    private const val WHITE = -1

    fun loadMesh(ctx: Context): GlooMesh {
        val b = ctx.assets.open("gloo_apple_gr.bin").use { it.readBytes() }
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        bb.int
        val nv = bb.int; val nt = bb.int
        val pos = FloatArray(nv * 3) { bb.float }
        val uv = FloatArray(nv * 2) { bb.float }
        val idx = IntArray(nt * 3) { bb.short.toInt() and 0xFFFF }
        val side = ByteArray(nt)
        bb.get(side)
        return GlooMesh(pos, uv, idx, side)
    }

    /** Looks for the gloo bundle in the folders of every game. Returns (package, path) for each game that has it. */
    suspend fun findAll(ctx: Context): List<Pair<String, String>> {
        val res = ArrayList<Pair<String, String>>()
        for (pkg in PKGS) {
            val root = Fs.root + "/Android/data/" + pkg + "/files/contentcache"
            var hit: String? = null
            try {
                Fs.walk(ctx, root) { p, _ ->
                    if (hit == null) {
                        val n = p.substringAfterLast('/')
                        if (n.startsWith(BUNDLE)) hit = p
                    }
                }
            } catch (t: Throwable) { }
            val h = hit
            if (h != null) res.add(pkg to h)
        }
        return res
    }

    private fun sample(x: XfSnap, u: Float, v: Float): Int {
        val pix = x.pix ?: return WHITE
        val fx = u * (x.pw - 1); val fy = (1f - v) * (x.ph - 1)
        val x0 = floor(fx).toInt().coerceIn(0, x.pw - 1); val y0 = floor(fy).toInt().coerceIn(0, x.ph - 1)
        val x1 = min(x.pw - 1, x0 + 1); val y1 = min(x.ph - 1, y0 + 1)
        val ax = fx - x0; val ay = fy - y0
        val c00 = pix[y0 * x.pw + x0]; val c10 = pix[y0 * x.pw + x1]; val c01 = pix[y1 * x.pw + x0]; val c11 = pix[y1 * x.pw + x1]
        var out = 0xFF shl 24
        var sh = 16
        while (sh >= 0) {
            val a = (c00 shr sh) and 255; val b = (c10 shr sh) and 255; val c = (c01 shr sh) and 255; val d = (c11 shr sh) and 255
            val top = a + (b - a) * ax; val bot = c + (d - c) * ax
            var v2 = (top + (bot - top) * ay + 0.5f).toInt()
            if (v2 < 0) v2 = 0; if (v2 > 255) v2 = 255
            // alpha of the photo is ignored: transparent areas become white
            out = out or (v2 shl sh)
            sh -= 8
        }
        return out
    }

    /**
     * The picture for every texel of the 3D model: each texel knows where it sits on the wall (barycentric position), the photo of its side is
     * projected flat onto the wall from that side. Result rows are in Unity order (row 0 = v 0 = bottom), colours are ARGB.
     */
    fun bake(m: GlooMesh, size: Int, front: XfSnap, back: XfSnap, swap: Boolean): IntArray {
        val out = IntArray(size * size) { WHITE }
        val mask = BooleanArray(size * size)
        val wf = m.maxX - m.minX; val hf = m.maxY - m.minY
        val faceAsp = wf / hf
        val frontRaw = if (swap) 1 else 0
        val cf = cos(-Math.toRadians(front.rot.toDouble())).toFloat(); val sf = sin(-Math.toRadians(front.rot.toDouble())).toFloat()
        val cb = cos(-Math.toRadians(back.rot.toDouble())).toFloat(); val sb = sin(-Math.toRadians(back.rot.toDouble())).toFloat()
        for (t in 0 until m.nt) {
            val s = m.side[t].toInt()
            val xf = if (s == frontRaw) front else back
            val cr = if (s == frontRaw) cf else cb
            val sr = if (s == frontRaw) sf else sb
            val i0 = m.idx[t * 3]; val i1 = m.idx[t * 3 + 1]; val i2 = m.idx[t * 3 + 2]
            val ax = m.uv[i0 * 2] * size; val ay = m.uv[i0 * 2 + 1] * size
            val bx = m.uv[i1 * 2] * size; val by = m.uv[i1 * 2 + 1] * size
            val cx = m.uv[i2 * 2] * size; val cy = m.uv[i2 * 2 + 1] * size
            val den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
            if (abs(den) < 1e-9f) continue
            val x0 = max(0, floor(min(ax, min(bx, cx))).toInt()); val x1 = min(size - 1, ceil(max(ax, max(bx, cx))).toInt())
            val y0 = max(0, floor(min(ay, min(by, cy))).toInt()); val y1 = min(size - 1, ceil(max(ay, max(by, cy))).toInt())
            val pa = if (xf.ph > 0) xf.pw.toFloat() / xf.ph else 1f
            val phW = if (pa > faceAsp) hf * pa else wf
            val phH = if (pa > faceAsp) hf else wf / pa
            for (py in y0..y1) {
                for (px in x0..x1) {
                    val qx = px + 0.5f; val qy = py + 0.5f
                    val w0 = ((by - cy) * (qx - cx) + (cx - bx) * (qy - cy)) / den
                    val w1 = ((cy - ay) * (qx - cx) + (ax - cx) * (qy - cy)) / den
                    val w2 = 1f - w0 - w1
                    if (w0 < -0.02f || w1 < -0.02f || w2 < -0.02f) continue
                    val wx = w0 * m.pos[i0 * 3] + w1 * m.pos[i1 * 3] + w2 * m.pos[i2 * 3]
                    val wy = w0 * m.pos[i0 * 3 + 1] + w1 * m.pos[i1 * 3 + 1] + w2 * m.pos[i2 * 3 + 1]
                    val fx = (wx - m.minX) / wf; val fy = (wy - m.minY) / hf
                    val fxv = if (s == 1) 1f - fx else fx          // a viewer at +z sees +x on his left
                    val dx = (fxv - 0.5f) * wf - xf.tx * wf; val dy = (fy - 0.5f) * hf - xf.ty * hf
                    val rx = cr * dx - sr * dy; val ry = sr * dx + cr * dy
                    var u = rx / (phW * xf.scale) + 0.5f; val v = ry / (phH * xf.scale) + 0.5f
                    if (xf.flip) u = 1f - u
                    val col = if (u < 0f || u > 1f || v < 0f || v > 1f) WHITE else sample(xf, u, v)
                    out[py * size + px] = col
                    mask[py * size + px] = true
                }
            }
        }
        dilate(out, mask, size, if (size >= 512) 6 else 4)
        return out
    }

    /** Colours of the islands are spread a few pixels outwards so that no thin seams show when the picture is smoothed. */
    private fun dilate(px: IntArray, mask: BooleanArray, n: Int, iters: Int) {
        var cur = mask.copyOf()
        repeat(iters) {
            val nxt = cur.copyOf()
            for (y in 0 until n) for (x in 0 until n) {
                val i = y * n + x
                if (cur[i]) continue
                var found = -1
                var dy = -1
                while (dy <= 1 && found < 0) {
                    var dx = -1
                    while (dx <= 1 && found < 0) {
                        val xx = x + dx; val yy = y + dy
                        if (xx in 0 until n && yy in 0 until n && cur[yy * n + xx]) found = yy * n + xx
                        dx++
                    }
                    dy++
                }
                if (found >= 0) { px[i] = px[found]; nxt[i] = true }
            }
            cur = nxt
        }
    }

    fun rgba(px: IntArray): ByteArray {
        val o = ByteArray(px.size * 4)
        for (i in px.indices) {
            val p = px[i]
            o[i * 4] = (p shr 16).toByte(); o[i * 4 + 1] = (p shr 8).toByte(); o[i * 4 + 2] = p.toByte(); o[i * 4 + 3] = 0xFF.toByte()
        }
        return o
    }

    /** Top-down bitmap of the atlas (Unity order has the bottom row first). */
    fun toBitmap(px: IntArray, n: Int): Bitmap {
        val b = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        for (r in 0 until n) b.setPixels(px, (n - 1 - r) * n, n, 0, r, n, 1)
        return b
    }

    /** The wall as a viewer sees it. viewRaw 0 = viewer stands at -z (sees the side==0 triangles), 1 = viewer stands at +z. Far triangles first. */
    fun renderView(m: GlooMesh, atlas: Bitmap, viewRaw: Int, outW: Int): Bitmap {
        val wf = m.maxX - m.minX; val hf = m.maxY - m.minY
        val margin = 20f
        val k = (outW - 2 * margin) / wf
        val outH = (hf * k + 2 * margin).toInt()
        val bm = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        c.drawColor(0xFFE9E9E9.toInt())
        val tris = ArrayList<Int>()
        for (t in 0 until m.nt) if (m.side[t].toInt() == viewRaw) tris.add(t)
        fun cz(t: Int): Float = (m.pos[m.idx[t * 3] * 3 + 2] + m.pos[m.idx[t * 3 + 1] * 3 + 2] + m.pos[m.idx[t * 3 + 2] * 3 + 2]) / 3f
        if (viewRaw == 0) tris.sortByDescending { cz(it) } else tris.sortBy { cz(it) }
        val n = tris.size * 3
        val verts = FloatArray(n * 2); val texs = FloatArray(n * 2); val cols = IntArray(n)
        for ((q, t) in tris.withIndex()) {
            val i0 = m.idx[t * 3]; val i1 = m.idx[t * 3 + 1]; val i2 = m.idx[t * 3 + 2]
            val ux = m.pos[i1 * 3] - m.pos[i0 * 3]; val uy = m.pos[i1 * 3 + 1] - m.pos[i0 * 3 + 1]; val uz = m.pos[i1 * 3 + 2] - m.pos[i0 * 3 + 2]
            val vx = m.pos[i2 * 3] - m.pos[i0 * 3]; val vy = m.pos[i2 * 3 + 1] - m.pos[i0 * 3 + 1]; val vz = m.pos[i2 * 3 + 2] - m.pos[i0 * 3 + 2]
            val nx = uy * vz - uz * vy; val ny = uz * vx - ux * vz; val nz = ux * vy - uy * vx
            val len = Math.sqrt((nx * nx + ny * ny + nz * nz).toDouble()).toFloat()
            val facing = if (len > 1e-9f) abs(nz) / len else 1f
            val g = ((0.74f + 0.26f * facing) * 255f).toInt().coerceIn(0, 255)
            val col = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
            for (j in 0..2) {
                val vi = m.idx[t * 3 + j]
                val fx = (m.pos[vi * 3] - m.minX) / wf
                val fxv = if (viewRaw == 1) 1f - fx else fx
                val o = (q * 3 + j) * 2
                verts[o] = margin + fxv * wf * k
                verts[o + 1] = outH - margin - (m.pos[vi * 3 + 1] - m.minY) * k
                texs[o] = m.uv[vi * 2] * atlas.width
                texs[o + 1] = (1f - m.uv[vi * 2 + 1]) * atlas.height
                cols[q * 3 + j] = col
            }
        }
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.shader = BitmapShader(atlas, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        c.drawVertices(Canvas.VertexMode.TRIANGLES, n * 2, verts, 0, texs, 0, cols, 0, null, 0, 0, paint)
        return bm
    }

    fun loadPhoto(ctx: Context, uri: Uri): Bitmap? = try {
        var rot = 0
        ctx.contentResolver.openInputStream(uri)?.use {
            val ex = android.media.ExifInterface(it)
            rot = when (ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90; 3 -> 180; 8 -> 270; else -> 0 }
        }
        val opt = BitmapFactory.Options(); opt.inJustDecodeBounds = true
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt) }
        var ss = 1
        while (max(opt.outWidth, opt.outHeight) / ss > 2200) ss *= 2
        val o2 = BitmapFactory.Options(); o2.inSampleSize = ss
        var bm = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        if (bm != null && rot != 0) {
            val mx = Matrix(); mx.postRotate(rot.toFloat())
            bm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, mx, true)
        }
        if (bm != null && max(bm.width, bm.height) > 1200) {
            val s = 1200f / max(bm.width, bm.height)
            bm = Bitmap.createScaledBitmap(bm, max(1, (bm.width * s).toInt()), max(1, (bm.height * s).toInt()), true)
        }
        bm
    } catch (t: Throwable) { null }

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0)
            }
        } catch (t: Throwable) { }
        return uri.lastPathSegment ?: "bundle"
    }
}

@Composable
fun GlooTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val mesh = remember { Gloo.loadMesh(ctx) }
    val front = remember { Xf() }
    val back = remember { Xf() }
    var sideSel by remember { mutableIntStateOf(0) }
    var swap by remember { mutableStateOf(false) }
    var flat by remember { mutableStateOf(true) }
    var foundList by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var selPkg by remember { mutableStateOf(Gloo.PKGS[1]) }
    val target: String? = foundList.firstOrNull { it.first == selPkg }?.second
    val targetPkg = selPkg
    var pickedBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pickedName by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(true) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var outBytes by remember { mutableStateOf<ByteArray?>(null) }
    var outName by remember { mutableStateOf("") }
    var origBytes by remember { mutableStateOf<ByteArray?>(null) }
    val logs = remember { mutableStateListOf("Gloo Vault ready.") }
    fun log(s: String) { logs.add(s); if (logs.size > 300) logs.removeAt(0) }

    LaunchedEffect(Unit) {
        val r = try { Gloo.findAll(ctx) } catch (t: Throwable) { emptyList() }
        foundList = r
        if (r.isNotEmpty()) {
            selPkg = r.firstOrNull { it.first == Gloo.PKGS[1] }?.first ?: r[0].first
            for (x in r) log("Found the gloo bundle in ${Gloo.gameName(x.first)}: ${x.second.substringAfterLast('/')}")
        } else log("Gloo bundle (optionalab_weapon_096) not found in the game folders.")
        searching = false
    }

    val pickFront = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) scope.launch {
            val b = withContext(Dispatchers.IO) { Gloo.loadPhoto(ctx, u) }
            if (b != null) { front.photo = b; front.reset(); log("Front photo: ${b.width}x${b.height}") } else log("Could not read that picture.")
        }
    }
    val pickBack = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) scope.launch {
            val b = withContext(Dispatchers.IO) { Gloo.loadPhoto(ctx, u) }
            if (b != null) { back.photo = b; back.reset(); log("Back photo: ${b.width}x${b.height}") } else log("Could not read that picture.")
        }
    }
    val pickBundle = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            val r = withContext(Dispatchers.IO) { try { ctx.contentResolver.openInputStream(u)?.use { it.readBytes() } } catch (t: Throwable) { null } }
            if (r != null) { pickedBytes = r; pickedName = Gloo.displayName(ctx, u); log("Picked bundle: $pickedName (${Fs.human(r.size.toLong())})") }
            else log("Could not read that file.")
        }
    }

    val previewKey = listOf(front.photo, front.scale, front.rot, front.tx, front.ty, front.flip, back.photo, back.scale, back.rot, back.tx, back.ty, back.flip, sideSel, swap)
    LaunchedEffect(previewKey) {
        delay(40)
        val fs = front.snap(); val bs = back.snap()
        val sw = swap; val sel = sideSel
        val bmp = withContext(Dispatchers.Default) {
            val px = Gloo.bake(mesh, 256, fs, bs, sw)
            val atlas = Gloo.toBitmap(px, 256)
            val frontRaw = if (sw) 1 else 0
            Gloo.renderView(mesh, atlas, if (sel == 0) frontRaw else 1 - frontRaw, 720)
        }
        preview = bmp
    }

    fun generate() {
        val fs = front.snap(); val bs = back.snap()
        val sw = swap; val fl = flat
        val tp = target; val pb = pickedBytes; val pn = pickedName; val sp = selPkg
        scope.launch {
            busy = true; status = "Working..."; outBytes = null
            try {
                val res = withContext(Dispatchers.Default) {
                    val orig: ByteArray = if (tp != null) Fs.read(ctx, tp) else pb ?: throw IllegalStateException("No gloo bundle. Pick the file first.")
                    val name = if (tp != null) tp.substringAfterLast('/') else pn
                    origBytes = orig
                    log("Original bundle: ${Fs.human(orig.size.toLong())}")
                    val modes = if (fl) listOf(Triple(512, false, "512 px (sharp, no mip levels)"), Triple(256, true, "256 px (with mip levels)"))
                    else listOf(Triple(256, true, "256 px (with mip levels)"))
                    var done: ByteArray? = null
                    var used = ""
                    for ((sz, mips, label) in modes) {
                        log("Trying $label ...")
                        val px = Gloo.bake(mesh, sz, fs, bs, sw)
                        val ch = Reencode.encodeChain(Gloo.rgba(px), sz, sz, mips)
                        val r = UnityFs.glooPatch(orig, Gloo.TARGET, ch, sz, sz, if (fl) Gloo.FLAT else emptyList())
                        if (r.data == null) { log("  not possible: ${r.why}"); continue }
                        val inv = UnityFs.inventory(r.data)
                        val t = inv?.firstOrNull { it.name == Gloo.TARGET }
                        if (t == null || !t.ok || t.w != sz || t.h != sz) { log("  check failed, the new bundle does not read back correctly"); continue }
                        log("  ok: ${r.why}")
                        done = r.data; used = label
                        break
                    }
                    Triple(done, used, name)
                }
                val data = res.first
                if (data == null) {
                    status = "Could not build the file. See the log."
                } else {
                    val rel = if (tp != null) tp.substringAfter("/Android/data/$sp/", "") else ""
                    val shown = if (rel.isNotEmpty()) "$sp/$rel" else "$sp/${res.third}"
                    val outFile = File(File(Fs.root, "Tater Manager/Gloo Vault"), shown)
                    outFile.parentFile?.mkdirs()
                    outFile.writeBytes(data)
                    outBytes = data; outName = res.third
                    status = "Done: ${res.second}. Saved in Tater Manager/Gloo Vault/$sp"
                    log("Saved $shown (${Fs.human(data.size.toLong())})")
                }
            } catch (t: Throwable) {
                status = "Failed: ${t.message ?: t.javaClass.simpleName}"
                log("Failed: ${t.message ?: t.javaClass.simpleName}")
            }
            busy = false
        }
    }

    fun applyToGame() {
        val tp = target; val data = outBytes; val orig = origBytes
        if (tp == null || data == null) return
        scope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) {
                    val bdir = File(Fs.root, "Tater Manager/Gloo Vault/Original backup/$targetPkg")
                    bdir.mkdirs()
                    val bf = File(bdir, tp.substringAfterLast('/'))
                    if (!bf.exists() && orig != null) bf.writeBytes(orig)
                    Fs.openOut(ctx, tp).use { it.write(data) }
                }
                status = "Copied into the game folder. The original is saved in Gloo Vault/Original backup/$targetPkg."
                log("Applied to $tp")
            } catch (t: Throwable) {
                status = "Could not copy into the game: ${t.message ?: t.javaClass.simpleName}"
                log(status)
            }
            busy = false
        }
    }

    val cur = if (sideSel == 0) front else back
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Gloo Vault", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Game", fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (pk in Gloo.PKGS) {
                val has = foundList.any { it.first == pk }
                val label = Gloo.gameName(pk) + (if (has) "" else " (not found)")
                if (selPkg == pk) Button(onClick = { selPkg = pk }, enabled = !busy) { Text(label) }
                else OutlinedButton(onClick = { selPkg = pk }, enabled = !busy) { Text(label) }
            }
        }
        Text(
            when {
                searching -> "Looking for the gloo wall bundle in the game folders..."
                target != null -> "Gloo wall bundle found: ${target.substringAfterLast('/')}"
                pickedBytes != null -> "Using the picked file: $pickedName (for ${Gloo.gameName(selPkg)})"
                else -> "Gloo wall bundle not found for ${Gloo.gameName(selPkg)}. Pick the file optionalab_weapon_096.* by hand."
            },
            fontSize = 13.sp
        )
        if (target == null) OutlinedButton(onClick = { pickBundle.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Pick bundle file") }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (sideSel == 0) Button(onClick = { sideSel = 0 }) { Text("Front") } else OutlinedButton(onClick = { sideSel = 0 }) { Text("Front") }
            if (sideSel == 1) Button(onClick = { sideSel = 1 }) { Text("Back") } else OutlinedButton(onClick = { sideSel = 1 }) { Text("Back") }
            Spacer(Modifier.weight(1f))
            Text(if (swap) "Sides swapped" else "Front = your side", fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterVertically))
            Switch(checked = swap, onCheckedChange = { swap = it })
        }
        Text(
            "Front = the side you see when you stand behind the wall. Back = the side the enemy sees. If it is the wrong way round in the game, turn on the swap switch and generate again.",
            fontSize = 11.sp
        )

        val pv = preview
        if (pv != null) {
            Image(
                bitmap = pv.asImageBitmap(), contentDescription = null, contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxWidth().aspectRatio(pv.width.toFloat() / pv.height).clip(RoundedCornerShape(12.dp)).background(androidx.compose.ui.graphics.Color(0xFFE9E9E9))
                    .pointerInput(sideSel) {
                        detectTransformGestures { _, pan, zoom, rotation ->
                            val x = if (sideSel == 0) front else back
                            x.scale = (x.scale * zoom).coerceIn(0.2f, 6f)
                            x.rot = x.rot - rotation
                            x.tx = (x.tx + pan.x / (size.width * 0.94f)).coerceIn(-1.5f, 1.5f)
                            x.ty = (x.ty - pan.y / (size.height * 0.88f)).coerceIn(-1.5f, 1.5f)
                        }
                    }
            )
        } else Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) { Text("Preparing preview...") }
        Text("Drag with one finger to move, pinch to zoom and turn the photo. This is the real model of the wall with your photo on it.", fontSize = 11.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = { pickFront.launch("image/*") }, enabled = !busy) { Text(if (front.photo == null) "Front photo" else "Change front") }
            FilledTonalButton(onClick = { pickBack.launch("image/*") }, enabled = !busy) { Text(if (back.photo == null) "Back photo" else "Change back") }
        }
        Text("Editing: ${if (sideSel == 0) "front" else "back"} photo" + (if (cur.photo == null) " (no photo yet, this side stays white)" else ""), fontSize = 12.sp)
        Text("Size  ${"%.2f".format(cur.scale)}x", fontSize = 12.sp)
        Slider(value = cur.scale, onValueChange = { cur.scale = it }, valueRange = 0.2f..4f)
        Text("Turn  ${cur.rot.toInt()}\u00B0", fontSize = 12.sp)
        Slider(value = cur.rot.coerceIn(-180f, 180f), onValueChange = { cur.rot = it }, valueRange = -180f..180f)
        Text("Move left / right", fontSize = 12.sp)
        Slider(value = cur.tx, onValueChange = { cur.tx = it }, valueRange = -1f..1f)
        Text("Move up / down", fontSize = 12.sp)
        Slider(value = cur.ty, onValueChange = { cur.ty = it }, valueRange = -1f..1f)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = cur.flip, onCheckedChange = { cur.flip = it })
            Text("Mirror this photo", fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { cur.reset() }) { Text("Reset") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = flat, onCheckedChange = { flat = it })
            Text(
                if (flat) "Flat finish: removes the apple relief and shine so your photo is sharp (recommended)"
                else "Keep the apple relief (smaller, blurrier picture)",
                fontSize = 12.sp
            )
        }

        Button(
            onClick = { generate() },
            enabled = !busy && !searching && (target != null || pickedBytes != null) && (front.photo != null || back.photo != null),
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "Working..." else "Generate gloo wall") }
        if (status.isNotEmpty()) Text(status, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        if (outBytes != null && target != null) OutlinedButton(onClick = { applyToGame() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Copy into the game now") }

        Text("Log", fontWeight = FontWeight.SemiBold)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(androidx.compose.ui.graphics.Color(0x22888888)).padding(8.dp)) {
            for (l in logs.takeLast(40)) Text(l, fontSize = 11.sp)
        }
        OutlinedButton(onClick = { clip.setText(AnnotatedString(logs.joinToString("\n"))) }, modifier = Modifier.fillMaxWidth()) { Text("Copy log") }
        Spacer(Modifier.height(24.dp))
    }
}
