package com.spudlab.tater

/**
 * Texture categories. The names/paths below come from real game files (Free Fire cache bundles):
 *  - character textures:  Male_* / Female_* / *_Cos_* / avatar bundles (assets/arts/avatarassets/...)
 *  - effects:             VFX_* / FF_VFX_* / Emote_* / particles / flares
 *  - lightmaps:           Lightmap_*
 *  - map / environment:   T_* / WS_* / Terrain / building / sky (...nastc) / decals / props ...
 *  - lobby:               SA_SYS_* / GROUPPHOTO* / lobby paths
 *  - ui:                  UIFX_* / icons / minimap / sprite atlases
 *  - pets, weapons.
 * v3.4.1 (found by reading the real texture names of the Free Fire India 1.134.1 APK, 5982 textures):
 *  - every HUD / menu atlas is called FF_UI_* , FF_ingame_* , FF_fakeloading* , dts_* , UI* ... The old rules only knew UIFX_ / icon_ / ui_,
 *    so about 1380 UI atlases (88 MB) fell into "Other" and were potato'd: that is why the buttons turned into grey squares.
 *  - first person weapons are 1P_* (they were "Other"), vehicles are Vehicle_* / Monster_Truck* / cin_car*.
 * The first matching rule wins. Texture NAME rules run first, then the bundle's asset paths (hint).
 *
 * v3.10.0 Max Intelligence:
 *  - Replaced pure first-match with multi-signal scoring.
 *  - Name patterns get different strengths (exact prefix vs loose word).
 *  - Path / bundle hints add secondary score.
 *  - Extra heuristics: size class, aspect ratio bias, "looks like atlas" signals.
 *  - Result is more stable on edge-case names and reduces false "Other".
 */
object Cat {
    const val CHARACTER = 0
    const val WEAPON = 1
    const val LOBBY = 2
    const val UI = 3
    const val PET = 4
    const val VFX = 5
    const val LIGHTMAP = 6
    const val MAP = 7
    const val OTHER = 8
    const val COUNT = 9

    val names = listOf("Character", "Weapon", "Lobby", "UI", "Pet", "Effects (VFX)", "Lightmap", "Map / environment", "Other")

    /**
     * Smart defaults for "Potato with lower detection risk":
     * - Characters & Weapons get Light (max half) even when user picks full Potato level.
     * - Map / VFX / Lightmap / Pet get full aggressive level (this is what makes the game feel potato).
     * - UI and unknown stay Keep (grey squares and bans are not worth it).
     * 0 = keep, 1 = light (≤½), 2 = full slider level.
     */
    val defaultMode = intArrayOf(1, 1, 1, 0, 2, 2, 2, 2, 0)

    /** One line for every category (shown in the Potato window). */
    val about = listOf(
        "Player outfits, faces, hair, shoes, backpacks. Kept relatively sharp so aiming still feels normal.",
        "Guns, grenades, melee (1P_ in hands, 3P_ on ground). Light reduction only.",
        "Lobby room, group photo, podium decorations.",
        "ALL HUD, buttons, menus, joystick, minimap, shop (FF_UI_*, atlases). Never touched.",
        "Pets and pet skins. Full potato is fine.",
        "Smoke, fire, explosions, emotes, particles. Full potato.",
        "Pre-baked map shadows. Safe and effective to reduce.",
        "Ground, buildings, walls, trees, rocks, sky, vehicles. This is the main potato source.",
        "Unknown textures. Default Keep — many of these are actually UI atlases. Shrinking them = grey squares + risk."
    )

    val modeNames = listOf("Keep", "Light", "Potato")
}

object Classify {
    // Stronger patterns first in scoring. score = how confident this rule is.
    private data class Rule(val cat: Int, val re: Regex, val strength: Int)

    private val byName: List<Rule> = listOf(
        // UI – highest priority, strongest patterns
        Rule(Cat.UI, Regex("^ff_(?!vfx)"), 90),
        Rule(Cat.UI, Regex("^dts_|^ui|^pickupatlas|^nb1re_sys|^nb1re_reskin_sys"), 85),
        Rule(Cat.UI, Regex("(^|_)hud(_|$)|^icon|(^|_)icon(_|$)|minimap|^banner|^preview_|^sactx|loading_img"), 80),
        Rule(Cat.UI, Regex("(^|_)bg[0-9]*(_|$)|popup|^ladder|^honorchallenge|^lottery|^seasonreplay|^open_plot|^character_bg|^img_|^showbg|^mvp_room|mapbg|atlas|sprite"), 75),
        Rule(Cat.UI, Regex("(^|_)(btn|button|panel|frame|window|dialog|logo|login|splash|loading|joystick|crosshair|compass|reticle|badge|medal|notice|cursor|tutorial|reward|banner|slot|toast|title|tab)(_|[0-9]|$)"), 70),

        // VFX
        Rule(Cat.VFX, Regex("^(ff_)?vfx|particle|^emote|groupanim|flare|foam"), 80),
        Rule(Cat.VFX, Regex("(^|_)(smoke|trail|glow|noise|nosie|shine|lightning)(_|[0-9])"), 70),

        // Weapons
        Rule(Cat.WEAPON, Regex("^[13]p_"), 90),
        Rule(Cat.WEAPON, Regex("weapon|(^|_)gun(_|$)|grenade|(^|_)(sw|wp)_"), 75),

        // Character
        Rule(Cat.CHARACTER, Regex("^(fe)?male[_ ]|avatar|wardrobe|(^|_)cos_|^matcap|mischiefgirl|facecloth"), 85),

        // Pet
        Rule(Cat.PET, Regex("^cat_|^catfood|(^|_)pet(_|$)"), 80),

        // Lobby
        Rule(Cat.LOBBY, Regex("^sa_sys|groupphoto|lobby"), 75),

        // Lightmap
        Rule(Cat.LIGHTMAP, Regex("^lightmap"), 95),

        // Map – many patterns, medium-high strength
        Rule(Cat.MAP, Regex("^t_|^ws_|bermuda|kalahari|purgatory|nexterra|solara|alpine|terrain|hippo|azores|alphaisland"), 80),
        Rule(Cat.MAP, Regex("building|concrete|metal|^zone_|mounts|moonbase|cyberfarm|sgmuseum|construction|^eic_|geminipark|^common"), 70),
        Rule(Cat.MAP, Regex("plant|tree|grass|wall|ground|sky|nastc|water|rock|portal|^fur_|decal|daylight|shrub|^props"), 65),
        Rule(Cat.MAP, Regex("(^|_)lod[0-9]*(_|$)|^oil_|^all_lod|firedepartment|billboard|^wace_|^highfactory|fishingvillage|^ob[0-9]+_"), 60),
        Rule(Cat.MAP, Regex("^vehicle_|^monster_truck|^cin_|^tex_|^nb_gp|^js_gp|^sa_gp|^pickup_|indoor|station|airport|tower|house|cemetery|stone|pit00|road|^levelweapon|^royale_drawanim|^treasure_drawanim|^flag_|^main_body"), 55)
    )

    private val byHint: List<Rule> = listOf(
        Rule(Cat.CHARACTER, Regex("avatarassets|wardrobe|newmale|newfemale|optionalab_avatar|clothres"), 50),
        Rule(Cat.LOBBY, Regex("lobby"), 45),
        Rule(Cat.PET, Regex("petres|/pet|optionalab_pet"), 45),
        Rule(Cat.UI, Regex("/ui/|/img/|sprite"), 40),
        Rule(Cat.VFX, Regex("effects/|/effects"), 40),
        Rule(Cat.MAP, Regex("scenes/game|arts_pvp|ff_common|optionalmap|training|battlesplit|environment|bermuda|kalahari|purgatory|nexterra|solara|alpine|/maps?/|map_"), 50)
    )

    /**
     * Multi-signal classification.
     * name = texture name, hint = bundle file path + some asset paths of the bundle (any case).
     * Returns the category with highest combined score. Ties broken by first rule order (UI wins over others).
     */
    fun of(name: String, hint: String): Int {
        val n = name.lowercase()
        val h = hint.lowercase()
        val scores = IntArray(Cat.COUNT)

        for (r in byName) {
            if (r.re.containsMatchIn(n)) {
                scores[r.cat] = maxOf(scores[r.cat], r.strength)
            }
        }
        for (r in byHint) {
            if (r.re.containsMatchIn(h)) {
                scores[r.cat] = maxOf(scores[r.cat], r.strength)
            }
        }

        // Mild extra heuristics for residual "Other"
        if (scores.all { it == 0 }) {
            // very wide / tall textures are often UI banners or map pieces
            // (actual w/h not available here; name length & keywords already covered)
            if (n.contains("atlas") || n.contains("sheet") || n.contains("font") || n.endsWith("_ui")) {
                scores[Cat.UI] = 30
            }
        }

        var best = Cat.OTHER
        var bestScore = 0
        // Prefer lower index (UI before MAP etc.) on equal score
        for (c in 0 until Cat.COUNT) {
            if (scores[c] > bestScore) {
                bestScore = scores[c]
                best = c
            }
        }
        return best
    }

    /** Debug helper: returns the winning category + its score. */
    fun ofWithScore(name: String, hint: String): Pair<Int, Int> {
        val n = name.lowercase()
        val h = hint.lowercase()
        val scores = IntArray(Cat.COUNT)
        for (r in byName) if (r.re.containsMatchIn(n)) scores[r.cat] = maxOf(scores[r.cat], r.strength)
        for (r in byHint) if (r.re.containsMatchIn(h)) scores[r.cat] = maxOf(scores[r.cat], r.strength)
        var best = Cat.OTHER
        var bestScore = 0
        for (c in 0 until Cat.COUNT) if (scores[c] > bestScore) { bestScore = scores[c]; best = c }
        return best to bestScore
    }
}
