# Changes (version 2.3)

## Internet + offline hearing (hybrid)
- Offline always works (Hindi + English models, nothing changes when there is no internet).
- When the internet works, right after the wake phrase the phone's online speech (Google) also listens to the command.
  The better answer is used: your own "call <contact>" / "open <app>" that the phone understood offline wins (exact names);
  everything else uses the internet text. If the internet ear is slow, empty or fails, the offline answer is used.
  3 bad internet results in a row pause the internet ear for 10 minutes by itself.
- Switch: More options > "Hear with internet too" (ON by default). Only the command after the wake phrase goes online;
  the always-on wake word listening stays 100% offline.
- Internet text in Roman Hinglish ("calculator kholo") is understood too.

## Hears better, also on weak phones
- Mic signal is cleaned before the models hear it: rumble filter + a quiet voice is lifted (room noise is not lifted).
- The three decoders (English, Hindi, contact/app grammar) now run side by side on different cores, and both voice
  models load at the same time: less delay on cheap phones.
- Mic loop runs with audio-thread priority.

## Incoming calls
- "oye pookie" / "oye phone utha" / "pick up" / "answer" / "accept" and more Hindi sounds (उठा, रिसीव, एक्सेप्ट, अटेंड, पिक अप, आंसर...) pick the call up on speaker.
- WhatsApp / Telegram / Messenger calls too: turn on More setup > "Answer WhatsApp calls too" (Notification access).
- Speaker is forced several ways (old method, Android 12+ method, tapping the speaker button as last resort).

## Repo
- .gitignore does not ignore the keystore (app/chanit.keystore), so every build is signed with the same key and installs over the old one.
- Version 2.3 (code 5).

## Earlier: version 2.2

## Fix 1: slow voice / late listening / mishearing
- Greeting no longer blocks the mic; voice engine warmed up at start and voice setup cached.
- Mic source is VOICE_RECOGNITION (same as "Teach my voice"), no noise suppressor, bigger buffer.
- Noise / low-confidence / one-word junk results are ignored instead of being run (and sent to the AI).
- Tuning knobs at the top of AssistantService.kt: MIN_AVG_CONF, MIN_SINGLE_CONF, MIN_VOICED_CHUNKS, MIN_RMS.

## Fix 2 (this version)
- "call <contact>" / "open <app>": a small grammar made from your contacts and installed apps is heard first;
  app names and contact names also forgive small mishearings.
- Wake phrase + command in one breath works; the spoken greeting is OFF by default (switch in More options).
- Pill moved to the top (Siri style), more transparent, draggable (position remembered).
- After an action it waits ~3.5 s for one more command, then hides itself.
- Notification reduced to the minimum Android allows (silent, no status-bar icon, hidden on lock screen, no buttons).
- Service no longer switches itself off when another app (e.g. Claude) takes the mic; it gets the mic back, and restarts if Android kills it.
- Incoming call: "oye pookie" / "oye phone utha" / "pick up" answers it and turns the speaker on.
- Extra "assist" entry so the app can show up in Default digital assistant app on more phones.
- Permanent signing key: new builds install as an update over the old one. Version 2.2 (code 4).
