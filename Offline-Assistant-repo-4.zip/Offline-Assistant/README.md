# Chanit Assistant (offline voice assistant)

Bolo "oye pookie" -> beep -> command. Offline chalta hai; internet ho to online speech bhi saath sunti hai (More options mein switch). Hindi + English + Hinglish.

## Build
Repo ke root mein is zip ko (`Offline-Assistant-repo.zip`) upload karo ya files extract karke upload karo.
Workflow `Build Offline Assistant APK` isko build karega. Actions > artifact `Offline-Assistant-APK-run...`.

## Pehli baar setup (app ke andar steps 1-8)
1 permissions, 2 overlay, 3 voice models (net chahiye, ek baar), 4 AI model (optional, sawal-jawab),
5 battery, 6 accessibility (screen control / camera / WhatsApp send), 7 brightness, 8 default assistant.
Phir "Train wake word" dabao aur 3 baar "oye pookie" bolo. Phir Start.

## Icon hide karna
"Hide from home screen" dabao. Wapas kholne ke liye: Settings > Apps > Chanit Assistant > App settings,
ya Quick Settings mein "Assistant" tile, ya dialer mein *#*#2580#*#*.

## Lock screen
Phone lock hone par sirf call chalega ("Rahul ko call karo"). Baaki sab "phone lock hai" bolega.
Checkbox se poora band bhi kar sakte ho.

## Commands
call / message / whatsapp, open app, torch, alarm, timer, reminder, notes, calculator, music (play/pause/next),
photo/selfie/video, home/back/screenshot/lock/scroll/click <name>, volume, brightness, battery, time, date,
"new command" (apne commands), baaki sab AI se.

## Voice
App mein "Voice (how I sound)": English (India) voice choose karo, speed / pitch / pause sliders, "hmm" filler, Test button.
Behtar voice ke liye: Settings > System > Languages > Text-to-speech > Google > Install voice data > English (India).

## New black UI
- Big ON/OFF switch (green = listening), live download bars for the Hindi + English voice pack.
- Only missing permissions are shown; once granted they disappear.
- Siri-style pill (animated waves + glowing edge) appears over any app when the wake phrase is heard.
- Say "oye pookie" -> soft tick -> speak the command. You can also say it all in one breath ("oye pookie call Rahul").
  (The spoken "Hmm, bolo ji…" greeting is optional: More options > "Speak a greeting".)
- After an action (opening an app, a call...) it waits about 3 seconds for one more command, then the pill hides by itself.
- The pill sits at the top like Siri; drag it anywhere and it remembers the place.
- When the phone rings, say "oye pookie" or "oye phone utha": it picks up and turns the speaker on (needs the Phone permission).
- Updates: every build is signed with the same key (app/chanit.keystore), so a new APK installs over the old one.
- Language is fixed to Hindi + English + Hinglish (no language options).
- Internet + offline: after the wake phrase the Google online speech also listens when the internet works; the better answer is used. No internet = offline as before. Switch: More options > "Hear with internet too". Google ki chhoti beep aa sakti hai; pasand na ho to switch OFF karo.
- Calls: "oye pookie" / "oye phone utha" / "pick up" picks up a ringing call on speaker. WhatsApp-type calls too if you allow Notification access (Android 13+: pehle App info > ⋮ > "Allow restricted settings"). Ringtone bahut tez ho to sunne mein dikkat ho sakti hai.
