package com.chanit.assistant

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the Vosk speech models once (English + Hindi together). After that everything is offline. */
object ModelStore {
    private const val EN = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val HI = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"
    private const val EN_GUESS = 41_000_000L
    private const val HI_GUESS = 43_000_000L

    /** Live state of one download. The screen reads this every 300 ms. */
    class Job {
        @Volatile var got = 0L
        @Volatile var total = 0L
        @Volatile var finished = false
        @Volatile var error: String? = null
        val active: Boolean get() = !finished && error == null
    }

    private val jobs = HashMap<String, Job>()

    fun dir(c: Context, lang: String) = File(c.filesDir, "vosk-$lang")
    fun ready(c: Context, lang: String) = File(dir(c, lang), "am").isDirectory
    fun allReady(c: Context) = ready(c, "en") && ready(c, "hi")

    fun job(lang: String): Job? = synchronized(jobs) { jobs[lang] }
    fun busy(): Boolean = synchronized(jobs) { jobs.values.any { it.active } }

    /** Combined progress of both packs: (bytes so far, bytes total) */
    fun overall(c: Context): Pair<Long, Long> {
        var got = 0L
        var total = 0L
        for (lang in listOf("en", "hi")) {
            val guess = if (lang == "hi") HI_GUESS else EN_GUESS
            val j = job(lang)
            if (ready(c, lang)) {
                val t = if (j != null && j.total > 0L) j.total else guess
                got += t
                total += t
            } else if (j != null && j.total > 0L) {
                got += j.got
                total += j.total
            } else {
                total += guess
            }
        }
        return got to total
    }

    /** Starts both packs at the same time (skips the ones already installed). */
    fun start(c: Context) {
        val app = c.applicationContext
        for (lang in listOf("en", "hi")) {
            if (ready(app, lang)) continue
            val job = Job()
            val go = synchronized(jobs) {
                val old = jobs[lang]
                if (old != null && old.active) false else {
                    jobs[lang] = job
                    true
                }
            }
            if (!go) continue
            Thread {
                try {
                    download(app, lang, job)
                    job.finished = true
                } catch (e: Throwable) {
                    job.error = e.message ?: e.javaClass.simpleName
                }
            }.start()
        }
    }

    private fun download(c: Context, lang: String, job: Job) {
        val tmp = File(c.filesDir, "vosk-$lang.tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()

        val conn = URL(if (lang == "hi") HI else EN).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        val code = conn.responseCode
        if (code != 200) throw IOException("Server error $code")
        val size = conn.contentLengthLong
        job.total = if (size > 0) size else if (lang == "hi") HI_GUESS else EN_GUESS

        val counting = object : FilterInputStream(conn.inputStream) {
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                val n = super.read(b, off, len)
                if (n > 0) job.got += n
                return n
            }
        }

        ZipInputStream(BufferedInputStream(counting)).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                // strip the top-level folder name inside the zip
                val rel = e.name.substringAfter('/', "")
                if (rel.isNotEmpty()) {
                    val f = File(tmp, rel)
                    if (!f.canonicalPath.startsWith(tmp.canonicalPath)) throw IOException("bad zip")
                    if (e.isDirectory) {
                        f.mkdirs()
                    } else {
                        f.parentFile?.mkdirs()
                        FileOutputStream(f).use { out -> zip.copyTo(out) }
                    }
                }
                e = zip.nextEntry
            }
        }

        val dst = dir(c, lang)
        dst.deleteRecursively()
        if (!tmp.renameTo(dst)) throw IOException("could not save model")
        if (!ready(c, lang)) throw IOException("pack incomplete, try again")
        job.got = job.total
    }
}
