package com.chanit.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/** One place for how the assistant sounds: a girl's voice, natural speed, short pauses between sentences. */
object Speech {

    fun split(text: String): List<String> =
        text.split(Regex("(?<=[.!?।…])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }

    fun isFemale(v: Voice): Boolean = v.name.contains("female", ignoreCase = true)

    /** Offline voices of a language, best first: tagged female, then India accent, then highest quality. */
    fun voicesFor(t: TextToSpeech, hindi: Boolean): List<Voice> {
        val lang = if (hindi) "hi" else "en"
        val all: Set<Voice> = (try { t.voices } catch (_: Throwable) { null }) ?: return emptyList()
        return all
            .filter { it.locale.language == lang && !it.isNetworkConnectionRequired }
            .filter { it.features?.contains("notInstalled") != true }
            .sortedWith(compareBy<Voice>({ !isFemale(it) }, { it.locale.country != "IN" }, { -it.quality }, { it.name }))
    }

    private var lastKey: String? = null
    private var lastRes = TextToSpeech.SUCCESS

    /**
     * Picks the saved voice, else the best girl voice. Returns the TextToSpeech language result.
     * Listing + loading voices is slow (up to a second on cheap phones), so it is only redone when
     * the engine, language, voice, speed or pitch really changed.
     */
    @Synchronized
    fun apply(t: TextToSpeech, c: Context, hindi: Boolean): Int {
        val p = Store.prefs(c)
        val key = System.identityHashCode(t).toString() + "|" + hindi + "|" +
            p.getString(if (hindi) "voice_hi" else "voice_en", "") + "|" +
            p.getFloat("tts_rate", 1.0f) + "|" + p.contains("tts_pitch") + "|" + p.getFloat("tts_pitch", 1.0f)
        if (key == lastKey) return lastRes
        var res = t.setLanguage(if (hindi) Locale("hi", "IN") else Locale("en", "IN"))
        if (!hindi && (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED)) {
            res = t.setLanguage(Locale.US)
        }
        var female = false
        try {
            val list = voicesFor(t, hindi)
            val saved = p.getString(if (hindi) "voice_hi" else "voice_en", null)
            val v = list.firstOrNull { it.name == saved } ?: list.firstOrNull()
            if (v != null) {
                t.setVoice(v)
                female = isFemale(v)
            }
        } catch (_: Throwable) {}
        t.setSpeechRate(p.getFloat("tts_rate", 1.0f))
        // if the phone doesn't tell us the voice is female, lift the pitch a little so it sounds like a girl
        t.setPitch(if (p.contains("tts_pitch")) p.getFloat("tts_pitch", 1.0f) else if (female) 1.0f else 1.12f)
        if (res >= 0) {   // don't remember a failure, so it is retried after the voice data gets installed
            lastKey = key
            lastRes = res
        }
        return res
    }

    /** Speaks sentence by sentence with a short pause in between. Only the last part carries [lastId]. */
    fun say(t: TextToSpeech, c: Context, text: String, lastId: String) {
        val pause = Store.prefs(c).getFloat("tts_pause", 150f).toLong()
        val parts = split(text).ifEmpty { listOf(text) }
        for ((i, s) in parts.withIndex()) {
            val last = i == parts.size - 1
            t.speak(s, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, if (last) lastId else "part$i")
            if (!last && pause > 0) t.playSilentUtterance(pause, TextToSpeech.QUEUE_ADD, "gap$i")
        }
    }
}
