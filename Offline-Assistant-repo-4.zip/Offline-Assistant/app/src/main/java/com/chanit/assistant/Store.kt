package com.chanit.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    const val DEFAULT_WAKE = "oye pookie"

    /** Sound-alikes the speech model is likely to hear when you say the default phrase once. */
    private val ALIASES = listOf(
        "oy pookie", "oh pookie", "hey pookie", "hi pookie",
        "oye cookie", "oye bookie", "hey cookie", "hey bookie"
    )

    fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** Language is fixed: Hindi + English + Hinglish together. No option in the UI. */
    fun mode(c: Context): String = "auto"

    /** the phrase(s) you typed + sound-alikes of the default + the ones learned by "Teach my voice" */
    fun wakeList(c: Context): List<String> {
        val p = prefs(c)
        val mains = (p.getString("wake_main", DEFAULT_WAKE) ?: DEFAULT_WAKE).split(",").map { it.trim().lowercase() }
        val aliases = if (mains.contains(DEFAULT_WAKE)) ALIASES else emptyList()
        val trained = (p.getString("wake_trained", "") ?: "").split("|")
        return (mains + aliases + trained).map { it.trim().lowercase() }.filter { it.isNotEmpty() }.distinct()
    }

    fun customs(c: Context): MutableList<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        try {
            val a = JSONArray(prefs(c).getString("custom", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(o.getString("t") to o.getString("a"))
            }
        } catch (_: Exception) {}
        return out
    }

    fun saveCustoms(c: Context, list: List<Pair<String, String>>) {
        val a = JSONArray()
        for (p in list) a.put(JSONObject().put("t", p.first).put("a", p.second))
        prefs(c).edit().putString("custom", a.toString()).apply()
    }

    fun notes(c: Context): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(prefs(c).getString("notes", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (_: Exception) {}
        return out
    }

    fun saveNotes(c: Context, list: List<String>) {
        val a = JSONArray()
        for (s in list) a.put(s)
        prefs(c).edit().putString("notes", a.toString()).apply()
    }
}
