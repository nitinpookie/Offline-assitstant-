package com.chanit.assistant

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/** Is there a working internet connection right now? (checked once per command, costs almost nothing) */
object Net {
    fun online(c: Context): Boolean = try {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork
        val cap = if (n == null) null else cm.getNetworkCapabilities(n)
        cap != null &&
            cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (_: Throwable) {
        false
    }
}

/**
 * Cleans the microphone signal before the speech models hear it (offline AND online side):
 *  - high-pass filter (about 90 Hz): removes rumble, hum and wind that confuse the models
 *  - gain: a quiet voice (cheap phone mics, far away speaker) is lifted up to a level the models like.
 *    Silence and room noise are NOT lifted, so only the voice gets louder.
 * Very light: a few multiplications per sample, fine for the weakest phones.
 */
class MicDsp {
    private var x1 = 0f
    private var y1 = 0f
    private var gain = 1f

    /** [rms] = loudness of this 100 ms piece before cleaning (0..1); [noise] = how loud the room is when nobody talks */
    fun process(buf: ShortArray, n: Int, rms: Float, noise: Float) {
        val voice = rms > maxOf(0.006f, noise * 2.2f)
        val want = if (voice) (0.07f / rms).coerceIn(1f, 6f) else 1f
        val g0 = gain
        // loud = turn down at once (no clipping), quiet = come up fast but smoothly
        val g1 = if (want < g0) want else g0 + (want - g0) * 0.5f
        gain = g1
        val a = 0.965f
        var px = x1
        var py = y1
        for (i in 0 until n) {
            val x = buf[i].toFloat()
            val y = a * (py + x - px)
            px = x
            py = y
            val g = g0 + (g1 - g0) * (i + 1).toFloat() / n.toFloat()
            val o = y * g
            buf[i] = if (o > 32767f) 32767.toShort() else if (o < -32768f) (-32768).toShort() else o.toInt().toShort()
        }
        x1 = px
        y1 = py
    }
}

/** Small helpers for Hinglish typed in Roman letters (the internet ear often returns it that way). */
object Hinglish {
    private val FIX = mapOf(
        "kholo" to "open", "kholiye" to "open", "kholiyega" to "open", "kholna" to "open",
        "tarikh" to "date", "tareekh" to "date", "taarikh" to "date",
        "awaaz" to "volume", "awaz" to "volume", "avaaz" to "volume"
    )
    private val MARK = setOf(
        "kya", "hai", "hain", "karo", "batao", "bolo", "kholo", "kholiye", "mujhe", "mera", "meri", "mere", "nahi",
        "haan", "abhi", "kaun", "kaise", "kitne", "kitna", "baje", "chalao", "lagao", "bhejo", "uthao", "kahan",
        "mausam", "aaj", "kal", "karna", "karein", "dikhao", "chalu", "shuru"
    )

    /** "calculator kholo" -> "calculator open" style fixes, so the normal command rules understand it */
    fun fix(text: String): String {
        if (text.isEmpty()) return text
        var s = text.split(" ").joinToString(" ") { p -> FIX[p.lowercase(Locale.ROOT)] ?: p }
        s = s.replace(Regex("(?i)kitne baje( hain| hai)?"), "time")
        return s
    }

    /** true = the person spoke Hindi / Hinglish (so the answer is spoken in Hindi) */
    fun isHindi(text: String): Boolean {
        for (ch in text) if (ch in '\u0900'..'\u097F') return true
        return text.lowercase(Locale.ROOT).split(" ").any { it in MARK }
    }
}

/**
 * The "internet ear": Google's online speech recognizer, started only right after the wake phrase and
 * only when the internet works. The offline models keep listening at the same time, so if the internet
 * ear fails (slow net, no answer, mic busy) the offline answer is used as before.
 */
class OnlineEar(private val ctx: Context, private val main: Handler) {

    @Volatile var text: String = ""
    @Volatile var partial: String = ""
    @Volatile var finished = false
    /** network / service / mic trouble (not just "nobody spoke") */
    @Volatile var hardFail = false
    @Volatile private var active = false

    private var rec: SpeechRecognizer? = null     // main thread only
    private var svc: ComponentName? = null
    private var looked = false

    /** true when the phone has a speech service other than this app (normally the Google app) */
    @Synchronized
    fun available(): Boolean {
        if (!looked) {
            looked = true
            svc = findService()
        }
        return svc != null
    }

    private fun findService(): ComponentName? = try {
        val list = ctx.packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
        val others = list.filter { it.serviceInfo != null && it.serviceInfo.packageName != ctx.packageName }
        val pick = others.firstOrNull { it.serviceInfo.packageName == "com.google.android.googlequicksearchbox" }
            ?: others.firstOrNull { it.serviceInfo.packageName.startsWith("com.google.") }
            ?: others.firstOrNull()
        if (pick == null) null else ComponentName(pick.serviceInfo.packageName, pick.serviceInfo.name)
    } catch (_: Throwable) {
        null
    }

    fun start(hindi: Boolean) {
        text = ""
        partial = ""
        finished = false
        hardFail = false
        active = true
        main.post { begin(hindi) }
    }

    /** stop listening and let go of the mic (the answer, if any, is already read) */
    fun stop() {
        active = false
        main.post {
            try { rec?.cancel() } catch (_: Throwable) {}
        }
    }

    fun destroy() {
        active = false
        main.post { drop() }
    }

    private fun drop() {
        try { rec?.destroy() } catch (_: Throwable) {}
        rec = null
    }

    private fun make(): SpeechRecognizer {
        val comp = svc
        val r: SpeechRecognizer = if (comp != null) SpeechRecognizer.createSpeechRecognizer(ctx, comp)
        else SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(listener)
        rec = r
        return r
    }

    private fun begin(hindi: Boolean) {
        if (!active) return
        try {
            val r: SpeechRecognizer = rec ?: make()
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (hindi) "hi-IN" else "en-IN")
            // plain key (the constant is not in the public SDK; an unknown key is simply ignored by the service)
            i.putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", arrayOf(if (hindi) "en-IN" else "hi-IN"))
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
            r.startListening(i)
        } catch (_: Throwable) {
            drop()
            hardFail = true
            finished = true
        }
    }

    private fun clean(s: String): String =
        s.replace(Regex("[.,!?;:।]+"), " ").replace(Regex("\\s+"), " ").trim()

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            if (!active) return
            val s = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (s != null) {
                val c = clean(s)
                if (c.isNotEmpty()) partial = c
            }
        }

        override fun onResults(results: Bundle?) {
            if (!active) return
            val s = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (s != null) text = clean(s)
            finished = true
        }

        override fun onError(error: Int) {
            if (!active) return
            val soft = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS
            ) {
                main.post { drop() }   // a fresh recognizer is made next time
            }
            hardFail = !soft
            finished = true
        }
    }
}

/**
 * Optional (needs "Notification access"): sees the incoming-call notification of WhatsApp, Telegram, Messenger,
 * the phone app... and can press its "Answer" button, so the assistant can pick those calls up too.
 */
class CallNotifService : NotificationListenerService() {

    companion object {
        private val ANSWER = listOf("answer", "accept", "pick", "receive", "जवाब", "उत्तर", "स्वीकार", "उठा", "रिसीव")
        private val DECLINE = listOf("decline", "reject", "dismiss", "ignore", "hang", "end", "cancel", "अस्वीकार", "काट", "रद्द")

        @Volatile private var ring: PendingIntent? = null
        @Volatile private var ringKey: String? = null
        @Volatile private var ringAt = 0L

        /** a call is ringing and its Answer button is known */
        fun ringing(): Boolean = ringKey != null && System.currentTimeMillis() - ringAt < 60_000L

        /** presses the Answer button of the ringing call */
        fun answer(): Boolean {
            val p = ring ?: return false
            return try {
                p.send()
                true
            } catch (_: Throwable) {
                false
            }
        }
    }

    private fun look(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            val n = sbn.notification ?: return
            var pick: PendingIntent? = null
            if (n.category == Notification.CATEGORY_CALL) {
                val acts = n.actions
                if (acts != null) {
                    for (a in acts) {
                        val t = (a.title?.toString() ?: "").lowercase(Locale.ROOT)
                        if (ANSWER.any { t.contains(it) } && !DECLINE.any { t.contains(it) }) {
                            pick = a.actionIntent
                            break
                        }
                    }
                }
            }
            if (pick != null) {
                ring = pick
                ringKey = sbn.key
                ringAt = System.currentTimeMillis()
            } else if (sbn.key == ringKey) {
                // the same notification changed into "ongoing call": it is not ringing any more
                ring = null
                ringKey = null
            }
        } catch (_: Throwable) {}
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) look(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null && sbn.key == ringKey) {
            ring = null
            ringKey = null
        }
    }

    override fun onListenerDisconnected() {
        ring = null
        ringKey = null
    }
}
