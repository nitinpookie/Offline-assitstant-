package com.chanit.assistant

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.HapticFeedbackConstants
import android.view.View
import kotlin.math.abs

object Ui {
    val BG = 0xFF000000.toInt()
    val CARD = 0xFF101013.toInt()
    val FIELD = 0xFF1A1A1F.toInt()
    val STROKE = 0xFF222228.toInt()
    val TEXT = 0xFFF5F5F7.toInt()
    val MUTED = 0xFF8E8E98.toInt()
    val GREEN = 0xFF30D158.toInt()
    val RED = 0xFFFF453A.toInt()
    val AMBER = 0xFFFF9F0A.toInt()
    val BLUE = 0xFF5B7CFF.toInt()
    val PURPLE = 0xFFA855F7.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()
    fun dpf(c: Context, v: Float): Float = v * c.resources.displayMetrics.density

    fun round(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radius
        if (strokeW > 0) g.setStroke(strokeW, strokeColor)
        return g
    }

    fun gradient(radius: Float): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(BLUE, PURPLE))
        g.cornerRadius = radius
        return g
    }

    /** Tap ripple clipped to the same rounded shape */
    fun ripple(bg: Drawable, radius: Float): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, round(Color.WHITE, radius))

    fun bold(): Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
}

/** Shizuku-style switch: green + "ON" when on, grey + "OFF" when off. Knob slides. */
class Toggle(ctx: Context) : View(ctx) {
    var onToggle: ((Boolean) -> Unit)? = null
    var checked = false
        private set
    private var pos = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val argb = ArgbEvaluator()

    init {
        isClickable = true
        setOnClickListener {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            setOn(!checked, true)
            onToggle?.invoke(checked)
        }
    }

    fun setOn(v: Boolean, animate: Boolean = true) {
        if (v == checked) return
        checked = v
        anim?.cancel()
        val to = if (v) 1f else 0f
        if (!animate || !isAttachedToWindow) {
            pos = to
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(pos, to)
        a.duration = 220
        a.addUpdateListener {
            pos = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        p.style = Paint.Style.FILL
        p.color = argb.evaluate(pos, 0xFF3A3A40.toInt(), Ui.GREEN) as Int
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, p)

        val pad = h * 0.1f
        val kr = r - pad
        val cx = r + (w - 2f * r) * pos
        p.color = Color.WHITE
        canvas.drawCircle(cx, r, kr, p)

        if (h >= Ui.dp(context, 38)) {
            val on = pos > 0.5f
            p.color = Color.WHITE
            p.alpha = (abs(pos - 0.5f) * 2f * 255f).toInt().coerceIn(0, 255)
            p.textSize = h * 0.27f
            p.typeface = Ui.bold()
            p.textAlign = Paint.Align.CENTER
            val tx = if (on) (w - h) / 2f else (w + h) / 2f
            canvas.drawText(if (on) "ON" else "OFF", tx, r + p.textSize * 0.35f, p)
            p.alpha = 255
        }
    }
}

/** Rounded progress bar that glides to its target value. */
class Bar(ctx: Context) : View(ctx) {
    var target = 0f
    var color = Ui.BLUE
    private var shown = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0xFF2A2A30.toInt()
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, p)

        shown += (target - shown) * 0.2f
        if (abs(target - shown) < 0.002f) shown = target else postInvalidateOnAnimation()
        if (shown > 0f) {
            val fw = (w * shown).coerceAtLeast(h)
            p.color = color
            rect.set(0f, 0f, fw, h)
            canvas.drawRoundRect(rect, h / 2f, h / 2f, p)
        }
    }
}
