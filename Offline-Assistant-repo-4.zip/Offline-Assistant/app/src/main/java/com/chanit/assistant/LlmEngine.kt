package com.chanit.assistant

import android.content.Context
import android.os.Process
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** On-device AI (MediaPipe LLM). Picked once by the user, then fully offline. Remembers the last 2 turns. */
class LlmEngine(private val c: Context) {

    companion object {
        /** MediaPipe LLM has 64-bit native libs only. On 32-bit phones the AI is skipped, everything else works. */
        fun supported(): Boolean = Process.is64Bit()

        fun modelFile(c: Context): File? =
            File(c.filesDir, "llm").listFiles()?.firstOrNull { it.isFile && !it.name.endsWith(".part") }
    }

    private var llm: LlmInference? = null
    private val history = ArrayList<Pair<String, String>>()

    fun ready() = supported() && modelFile(c) != null

    @Synchronized
    fun reset() { history.clear() }

    @Synchronized
    fun ask(q: String, hindi: Boolean): String {
        val file = modelFile(c) ?: return ""
        if (llm == null) {
            val o = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(1024)
                .build()
            llm = LlmInference.createFromOptions(c, o)
        }
        val sys = if (hindi) {
            "You are a friendly voice assistant. Reply in Hindi (Devanagari script) in at most two short sentences."
        } else {
            "You are a friendly voice assistant. Reply in at most two short sentences."
        }
        val qwen = file.name.lowercase().contains("qwen")
        val sb = StringBuilder()
        if (qwen) {
            sb.append("<|im_start|>system\n").append(sys).append("<|im_end|>\n")
            for ((uq, ua) in history) {
                sb.append("<|im_start|>user\n").append(uq).append("<|im_end|>\n")
                sb.append("<|im_start|>assistant\n").append(ua).append("<|im_end|>\n")
            }
            sb.append("<|im_start|>user\n").append(q).append("<|im_end|>\n<|im_start|>assistant\n")
        } else {
            var first = true
            for ((uq, ua) in history) {
                sb.append("<start_of_turn>user\n")
                if (first) { sb.append(sys).append("\n\n"); first = false }
                sb.append(uq).append("<end_of_turn>\n<start_of_turn>model\n").append(ua).append("<end_of_turn>\n")
            }
            sb.append("<start_of_turn>user\n")
            if (first) sb.append(sys).append("\n\n")
            sb.append(q).append("<end_of_turn>\n<start_of_turn>model\n")
        }
        val ans = llm!!.generateResponse(sb.toString()).trim().take(400)
        history.add(q to ans.take(250))
        while (history.size > 2) history.removeAt(0)
        return ans
    }

    @Synchronized
    fun close() {
        try { llm?.close() } catch (_: Throwable) {}
        llm = null
    }
}
