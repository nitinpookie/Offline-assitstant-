package com.chanit.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val pickCode = 42
    private val prefs by lazy { Store.prefs(this) }
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            render()
            handler.postDelayed(this, 200)
        }
    }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var scroll: ScrollView
    private lateinit var col: LinearLayout

    // hero (ON / OFF)
    private lateinit var heroCard: LinearLayout
    private lateinit var heroSub: TextView
    private lateinit var heroErr: TextView
    private lateinit var dot: View
    private lateinit var toggle: Toggle
    private var startingUntil = 0L
    private var stoppingUntil = 0L
    private var warnText = ""
    private var warnUntil = 0L
    private var heroState = -1
    private var pulse: ObjectAnimator? = null

    // voice pack
    private lateinit var packCard: LinearLayout
    private lateinit var packTitle: TextView
    private lateinit var packSub: TextView
    private lateinit var packBtn: TextView
    private lateinit var packBar: Bar
    private lateinit var packBytes: TextView
    private var wasBusy = false

    // setup (only what is still missing)
    private lateinit var setupCard: LinearLayout
    private lateinit var setupTitle: TextView
    private val needs = ArrayList<Need>()

    // wake phrase
    private lateinit var wakeEdit: EditText
    private lateinit var wakeMsg: TextView
    private lateinit var teachBtn: TextView

    // more options
    private lateinit var moreBody: LinearLayout
    private lateinit var iconSub: TextView
    private lateinit var aiSub: TextView
    private lateinit var voiceEnSub: TextView
    private lateinit var voiceHiSub: TextView
    private var aiCopying = false

    private var testTts: TextToSpeech? = null
    private var testReady = false
    private var testInit = false

    // ------------------------------------------------------------------ build screen
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val pad = Ui.dp(this, 16)
        col.setPadding(pad, Ui.dp(this, 14), pad, Ui.dp(this, 40))

        col.addView(tv("Chanit Assistant", 28f, Ui.TEXT, true))
        val subtitle = tv("Offline + online voice assistant · Hindi + English", 13f, Ui.MUTED)
        subtitle.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 2))
        col.addView(subtitle)

        buildHero()
        buildPack()
        buildSetup()
        buildWake()
        buildMore()

        scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(col)
        setContentView(scroll)
        render()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        savePhrase()
        super.onPause()
    }

    override fun onDestroy() {
        pulse?.cancel()
        try { testTts?.shutdown() } catch (_: Throwable) {}
        super.onDestroy()
    }

    // ------------------------------------------------------------------ small view helpers
    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Ui.bold()
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Ui.round(Ui.CARD, Ui.dpf(this, 22f), Ui.STROKE, Ui.dp(this, 1))
        val p = Ui.dp(this, 18)
        c.setPadding(p, p, p, p)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = Ui.dp(this, 14)
        c.layoutParams = lp
        return c
    }

    /** Full-width button. primary = blue-purple gradient, otherwise dark grey. */
    private fun button(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val b = tv(text, 15f, Color.WHITE, true)
        b.gravity = Gravity.CENTER
        val v = Ui.dp(this, 14)
        b.setPadding(v, v, v, v)
        val r = Ui.dpf(this, 16f)
        b.background = Ui.ripple(if (primary) Ui.gradient(r) else Ui.round(0xFF1F1F25.toInt(), r), r)
        b.isClickable = true
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = Ui.dp(this, 14)
        b.layoutParams = lp
        return b
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val b = tv(text, 13f, Color.WHITE, true)
        b.gravity = Gravity.CENTER
        b.setPadding(Ui.dp(this, 16), Ui.dp(this, 9), Ui.dp(this, 16), Ui.dp(this, 9))
        val r = Ui.dpf(this, 20f)
        b.background = Ui.ripple(Ui.gradient(r), r)
        b.isClickable = true
        b.setOnClickListener { onClick() }
        return b
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun mb(bytes: Long) = String.format(Locale.US, "%.1f", bytes / 1048576.0)

    // ------------------------------------------------------------------ hero: big ON / OFF
    private fun buildHero() {
        heroCard = card()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(tv("Assistant", 22f, Ui.TEXT, true))
        val sr = LinearLayout(this)
        sr.orientation = LinearLayout.HORIZONTAL
        sr.gravity = Gravity.CENTER_VERTICAL
        dot = View(this)
        dot.background = Ui.round(Ui.MUTED, Ui.dpf(this, 10f))
        sr.addView(dot, LinearLayout.LayoutParams(Ui.dp(this, 9), Ui.dp(this, 9)))
        heroSub = tv("", 14f, Ui.MUTED)
        heroSub.setPadding(Ui.dp(this, 8), 0, 0, 0)
        sr.addView(heroSub)
        val srLp = LinearLayout.LayoutParams(WRAP, WRAP)
        srLp.topMargin = Ui.dp(this, 6)
        left.addView(sr, srLp)
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        toggle = Toggle(this)
        toggle.onToggle = { on -> if (on) startAssistant() else stopAssistant() }
        row.addView(toggle, LinearLayout.LayoutParams(Ui.dp(this, 76), Ui.dp(this, 44)))
        heroCard.addView(row)

        heroErr = tv("", 13f, Ui.RED)
        heroErr.visibility = View.GONE
        heroErr.setPadding(0, Ui.dp(this, 12), 0, 0)
        heroCard.addView(heroErr)
        col.addView(heroCard)
    }

    private fun warn(m: String) {
        warnText = m
        warnUntil = System.currentTimeMillis() + 5000
        toggle.setOn(false)
        render()
    }

    private fun flash(v: View) {
        scroll.smoothScrollTo(0, (v.top - Ui.dp(this, 20)).coerceAtLeast(0))
        v.animate().scaleX(1.025f).scaleY(1.025f).setDuration(120).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    private fun startAssistant() {
        savePhrase()
        when {
            !ModelStore.allReady(this) -> {
                warn("Download the voice pack first ↓")
                flash(packCard)
            }
            !granted(Manifest.permission.RECORD_AUDIO) -> {
                warn("Microphone permission is needed ↓")
                if (setupCard.visibility == View.VISIBLE) flash(setupCard)
            }
            else -> launchService()
        }
    }

    private fun launchService() {
        AssistantService.lastError = null
        stoppingUntil = 0
        startingUntil = System.currentTimeMillis() + 8000
        try {
            startForegroundService(Intent(this, AssistantService::class.java))
        } catch (e: Throwable) {
            startingUntil = 0
            warn("Couldn't start: ${e.message}")
        }
        render()
    }

    private fun stopAssistant() {
        startingUntil = 0
        stoppingUntil = System.currentTimeMillis() + 1500
        startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
        render()
    }

    // ------------------------------------------------------------------ voice pack card
    private fun buildPack() {
        packCard = card()
        packTitle = tv("Voice pack", 18f, Ui.TEXT, true)
        packSub = tv("", 13f, Ui.MUTED)
        packSub.setPadding(0, Ui.dp(this, 4), 0, 0)
        packCard.addView(packTitle)
        packCard.addView(packSub)
        packBar = Bar(this)
        val blp = LinearLayout.LayoutParams(MATCH, Ui.dp(this, 10))
        blp.topMargin = Ui.dp(this, 16)
        packCard.addView(packBar, blp)
        packBytes = tv("", 13f, Ui.MUTED)
        packBytes.setPadding(0, Ui.dp(this, 8), 0, 0)
        packCard.addView(packBytes)
        packBtn = button("Download voice pack", true) {
            ModelStore.start(this)
            renderPack()
        }
        packCard.addView(packBtn)
        col.addView(packCard)
    }

    private fun friendly(e: String): String =
        if (e.contains("resolve", true) || e.contains("connect", true) || e.contains("timed out", true) ||
            e.contains("network", true) || e.contains("unreachable", true)
        ) "Check your internet connection." else e

    private fun renderPack() {
        val enOk = ModelStore.ready(this, "en")
        val hiOk = ModelStore.ready(this, "hi")
        val ready = enOk && hiOk
        val busy = ModelStore.busy()
        val jEn = ModelStore.job("en")
        val jHi = ModelStore.job("hi")
        val err = if (busy) null else (if (!enOk) jEn?.error else null) ?: (if (!hiOk) jHi?.error else null)

        if (wasBusy && !busy && ready) toast("Voice pack downloaded ✓")
        wasBusy = busy

        if (ready) {
            packTitle.text = "✓  Voice pack ready"
            packTitle.setTextColor(Ui.GREEN)
            packSub.text = "Download complete. Hindi + English work fully offline."
            packBar.visibility = View.GONE
            packBytes.visibility = View.GONE
            packBtn.visibility = View.GONE
            return
        }

        // ONE combined bar for the whole voice pack
        val (got, total) = ModelStore.overall(this)
        val f = if (total > 0L) (got.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
        val pct = (f * 100).toInt()
        val show = busy || err != null
        packBar.visibility = if (show) View.VISIBLE else View.GONE
        packBytes.visibility = if (show) View.VISIBLE else View.GONE
        packBar.target = f
        packBar.color = if (err != null) Ui.RED else Ui.BLUE
        packBytes.text = "$pct%  ·  ${mb(got)} / ${mb(total)} MB"

        if (busy) {
            packTitle.text = "Downloading voice pack…  $pct%"
            packTitle.setTextColor(Ui.TEXT)
            packSub.text = "Hindi + English download together. Keep the app open."
            packBtn.visibility = View.GONE
        } else if (err != null) {
            packTitle.text = "Download failed"
            packTitle.setTextColor(Ui.RED)
            packSub.text = friendly(err)
            packBtn.text = "Retry download"
            packBtn.visibility = View.VISIBLE
        } else {
            packTitle.text = "Voice pack needed"
            packTitle.setTextColor(Ui.AMBER)
            packSub.text = "One tap, one download (about 85 MB) so I can understand Hindi + English offline."
            packBtn.text = "Download voice pack"
            packBtn.visibility = View.VISIBLE
        }
    }

    // ------------------------------------------------------------------ setup: only what is still missing
    private inner class Need(
        title: String, sub: String, optional: Boolean,
        val ok: () -> Boolean, act: () -> Unit
    ) {
        val root = LinearLayout(this@MainActivity)

        init {
            root.orientation = LinearLayout.HORIZONTAL
            root.gravity = Gravity.CENTER_VERTICAL
            val left = LinearLayout(this@MainActivity)
            left.orientation = LinearLayout.VERTICAL
            left.addView(tv(if (optional) "$title · optional" else title, 15f, Ui.TEXT, true))
            left.addView(tv(sub, 12f, Ui.MUTED))
            root.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
            root.addView(chip("Allow", act))
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = Ui.dp(this@MainActivity, 16)
            root.layoutParams = lp
        }
    }

    private fun permList(): List<String> {
        val p = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        return p
    }

    private fun askPerms() {
        val missing = permList().filter { !granted(it) }
        if (missing.isEmpty()) return
        val asked = prefs.getBoolean("perm_asked", false)
        val blocked = asked && missing.none { shouldShowRequestPermissionRationale(it) }
        if (blocked) {
            toast("Open Permissions and allow everything")
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } else {
            prefs.edit().putBoolean("perm_asked", true).apply()
            requestPermissions(missing.toTypedArray(), 1)
        }
    }

    private fun isDefaultAssistant(): Boolean = try {
        val a = Settings.Secure.getString(contentResolver, "assistant") ?: ""
        val v = Settings.Secure.getString(contentResolver, "voice_interaction_service") ?: ""
        a.contains(packageName) || v.contains(packageName)
    } catch (_: Throwable) {
        false
    }

    private fun openAssistantSettings() {
        try {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) } catch (_: Exception) {}
        }
    }

    private fun buildSetup() {
        setupCard = card()
        setupTitle = tv("Setup needed", 18f, Ui.TEXT, true)
        setupCard.addView(setupTitle)
        val pkg = Uri.parse("package:$packageName")

        needs.add(Need("Mic, contacts, calls & SMS", "So I can hear you and call or message", false,
            { permList().all { granted(it) } }, { askPerms() }))
        needs.add(Need("Show pill over apps", "The Siri-style pill needs this", false,
            { Settings.canDrawOverlays(this) },
            { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) }))
        needs.add(Need("Keep running in background", "So I keep listening with the screen off", false,
            { getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName) },
            { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)) }))
        needs.add(Need("Screen control", "Home, back, scroll, tap and WhatsApp by voice", true,
            { ScreenService.instance != null },
            { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }))
        needs.add(Need("Brightness control", "Change brightness by voice", true,
            { Settings.System.canWrite(this) },
            { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg)) }))
        needs.add(Need("Answer WhatsApp calls too", "Notification access: lets me pick up WhatsApp-type calls by voice", true,
            { (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName) },
            { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }))
        needs.add(Need("Default assistant", "Open me with the power button", true,
            { isDefaultAssistant() }, { openAssistantSettings() }))

        for (n in needs) setupCard.addView(n.root)
        col.addView(setupCard)
    }

    private fun renderSetup() {
        var missing = 0
        for (n in needs) {
            val ok = try { n.ok() } catch (_: Throwable) { true }
            n.root.visibility = if (ok) View.GONE else View.VISIBLE
            if (!ok) missing++
        }
        setupCard.visibility = if (missing == 0) View.GONE else View.VISIBLE
        setupTitle.text = "Setup needed  ($missing)"
    }

    // ------------------------------------------------------------------ wake phrase
    private fun buildWake() {
        val c = card()
        c.addView(tv("Wake phrase", 18f, Ui.TEXT, true))
        val sub = tv("Say this once and I wake up", 13f, Ui.MUTED)
        sub.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12))
        c.addView(sub)

        wakeEdit = EditText(this)
        wakeEdit.setSingleLine()
        wakeEdit.setText(prefs.getString("wake_main", Store.DEFAULT_WAKE))
        wakeEdit.setTextColor(Ui.TEXT)
        wakeEdit.setHintTextColor(Ui.MUTED)
        wakeEdit.hint = Store.DEFAULT_WAKE
        wakeEdit.textSize = 17f
        wakeEdit.background = Ui.round(Ui.FIELD, Ui.dpf(this, 14f), Ui.STROKE, Ui.dp(this, 1))
        wakeEdit.setPadding(Ui.dp(this, 16), Ui.dp(this, 13), Ui.dp(this, 16), Ui.dp(this, 13))
        wakeEdit.imeOptions = EditorInfo.IME_ACTION_DONE
        wakeEdit.setOnEditorActionListener { _, _, _ ->
            savePhrase()
            false
        }
        c.addView(wakeEdit, LinearLayout.LayoutParams(MATCH, WRAP))

        wakeMsg = tv("I'll answer “Hmm, bolo ji, kya kaam hai?”", 13f, Ui.MUTED)
        wakeMsg.setPadding(0, Ui.dp(this, 10), 0, 0)
        c.addView(wakeMsg)

        teachBtn = button("Teach my voice (one time)", false) { train() }
        teachBtn.setOnLongClickListener {
            prefs.edit().remove("wake_trained").apply()
            wakeMsg.text = "Taught samples cleared."
            true
        }
        c.addView(teachBtn)
        col.addView(c)
    }

    private fun savePhrase() {
        if (!::wakeEdit.isInitialized) return
        val v = wakeEdit.text.toString().trim().lowercase().ifEmpty { Store.DEFAULT_WAKE }
        if (v == (prefs.getString("wake_main", Store.DEFAULT_WAKE) ?: Store.DEFAULT_WAKE)) return
        prefs.edit().putString("wake_main", v).remove("wake_trained").apply()
        wakeMsg.text = "Saved ✓"
        if (AssistantService.running) {
            stopAssistant()
            handler.postDelayed({ launchService() }, 700)
        }
    }

    private fun train() {
        if (AssistantService.running) {
            wakeMsg.text = "Turn the assistant OFF first, then teach."
            return
        }
        if (!granted(Manifest.permission.RECORD_AUDIO) || !ModelStore.ready(this, "en")) {
            wakeMsg.text = "Allow the mic and download the voice pack first."
            return
        }
        savePhrase()
        val phrase = Store.wakeList(this).firstOrNull() ?: Store.DEFAULT_WAKE
        teachBtn.isEnabled = false
        teachBtn.alpha = 0.5f
        wakeMsg.text = "Getting ready…"
        thread {
            val heard = ArrayList<String>()
            var ar: AudioRecord? = null
            var model: Model? = null
            try {
                model = Model(ModelStore.dir(this, "en").absolutePath)
                val a = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, 32000
                )
                ar = a
                a.startRecording()
                for (i in 1..3) {
                    runOnUiThread { wakeMsg.text = "Say “$phrase” now  ($i/3)" }
                    val r = Recognizer(model!!, 16000.0f)
                    val buf = ShortArray(1600)
                    val end = System.currentTimeMillis() + 2800
                    while (System.currentTimeMillis() < end) {
                        val n = a.read(buf, 0, buf.size)
                        if (n > 0) r.acceptWaveForm(buf, n)
                    }
                    val text = JSONObject(r.finalResult).optString("text").trim()
                    r.close()
                    if (text.isNotEmpty()) heard.add(text)
                }
            } catch (e: Throwable) {
                runOnUiThread { wakeMsg.text = "Teaching failed: ${e.message}" }
            } finally {
                try { ar?.stop() } catch (_: Throwable) {}
                try { ar?.release() } catch (_: Throwable) {}
                try { model?.close() } catch (_: Throwable) {}
            }
            val boring = setOf("the", "a", "i", "you", "it", "and", "yeah", "oh", "uh", "hey", "he", "she", "is", "to")
            val good = heard.filter { it.replace(" ", "").length >= 4 && it !in boring }
            val old = (prefs.getString("wake_trained", "") ?: "").split("|").filter { it.isNotEmpty() }
            val merged = (old + good).distinct().takeLast(8)
            prefs.edit().putString("wake_trained", merged.joinToString("|")).apply()
            runOnUiThread {
                teachBtn.isEnabled = true
                teachBtn.alpha = 1f
                wakeMsg.text = if (good.isEmpty()) "Couldn't hear a clear phrase. Try again closer to the mic."
                else "Learned your voice ✓"
            }
        }
    }

    // ------------------------------------------------------------------ more options (collapsed)
    private fun toggleRow(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit): TextView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(tv(title, 15f, Ui.TEXT, true))
        val s = tv(sub, 12f, Ui.MUTED)
        left.addView(s)
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        val t = Toggle(this)
        t.setOn(on, false)
        t.onToggle = change
        row.addView(t, LinearLayout.LayoutParams(Ui.dp(this, 56), Ui.dp(this, 32)))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = Ui.dp(this, 16)
        moreBody.addView(row, lp)
        return s
    }

    private fun navRow(title: String, sub: String, go: () -> Unit): TextView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(tv(title, 15f, Ui.TEXT, true))
        val s = tv(sub, 12f, Ui.MUTED)
        left.addView(s)
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(tv("›", 22f, Ui.MUTED))
        row.isClickable = true
        row.setOnClickListener { go() }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = Ui.dp(this, 16)
        moreBody.addView(row, lp)
        return s
    }

    private fun slider(name: String, key: String, min: Float, max: Float, def: Float, unit: String) {
        val label = tv("", 12f, Ui.MUTED)
        label.setPadding(0, Ui.dp(this, 12), 0, 0)
        moreBody.addView(label)
        val sb = SeekBar(this)
        sb.max = 100
        fun show(v: Float) { label.text = name + ": " + String.format(Locale.US, "%.2f", v) + unit }
        val cur = prefs.getFloat(key, def)
        sb.progress = ((cur - min) / (max - min) * 100).toInt()
        show(cur)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = min + (max - min) * p / 100f
                show(v)
                if (fromUser) prefs.edit().putFloat(key, v).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        moreBody.addView(sb)
    }

    private fun buildMore() {
        val c = card()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("More options", 16f, Ui.TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val arrow = tv("▾", 18f, Ui.MUTED)
        head.addView(arrow)
        head.isClickable = true
        c.addView(head)

        moreBody = LinearLayout(this)
        moreBody.orientation = LinearLayout.VERTICAL
        moreBody.visibility = View.GONE
        c.addView(moreBody)
        head.setOnClickListener {
            val open = moreBody.visibility != View.VISIBLE
            moreBody.visibility = if (open) View.VISIBLE else View.GONE
            arrow.text = if (open) "▴" else "▾"
            if (open) scroll.post { scroll.smoothScrollBy(0, Ui.dp(this, 240)) }
        }

        toggleRow("Start after restart", "Turns itself on when the phone boots", prefs.getBoolean("autostart", true)) {
            prefs.edit().putBoolean("autostart", it).apply()
        }
        toggleRow("Work on lock screen", "Calls only while locked. Off = ignore everything",
            prefs.getString("lock_mode", "calls") != "off") {
            prefs.edit().putString("lock_mode", if (it) "calls" else "off").apply()
        }
        toggleRow("Speak a greeting", "Says “Hmm, bolo ji…” after the wake phrase. Off (recommended) = soft tick, you can say the command right away",
            prefs.getBoolean("greet_voice", false)) {
            prefs.edit().putBoolean("greet_voice", it).apply()
        }
        toggleRow("Hear with internet too",
            "After the wake phrase I also ask Google's speech when the internet works and use whichever heard better. No internet = fully offline. Off = always offline",
            prefs.getBoolean("hybrid", true)) {
            prefs.edit().putBoolean("hybrid", it).apply()
        }
        iconSub = toggleRow("Show app icon", "", iconVisible()) { setIcon(it) }

        slider("Voice speed", "tts_rate", 0.5f, 1.5f, 1.0f, "x")
        slider("Voice pitch", "tts_pitch", 0.5f, 1.5f, 1.0f, "x")
        val test = button("▶  Test voice", false) { speakTest() }
        moreBody.addView(test)
        voiceEnSub = navRow("Girl voice · English / Hinglish", "") { pickVoice(false) }
        voiceHiSub = navRow("Girl voice · Hindi", "") { pickVoice(true) }

        navRow("Custom commands", "Teach me your own phrases") { customDialog() }
        aiSub = navRow("AI model (optional)", "") { pickAiModel() }
        col.addView(c)
    }

    private fun iconCn() = ComponentName(this, "com.chanit.assistant.LauncherAlias")

    private fun iconVisible() =
        packageManager.getComponentEnabledSetting(iconCn()) != PackageManager.COMPONENT_ENABLED_STATE_DISABLED

    private fun setIcon(show: Boolean) {
        packageManager.setComponentEnabledSetting(
            iconCn(),
            if (show) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }

    private fun renderMore() {
        iconSub.text = if (iconVisible()) "Visible on the home screen"
        else "Hidden. Open via Settings › Apps › Chanit Assistant › App settings, the Assistant tile, or dial *#*#2580#*#*"
        voiceEnSub.text = prefs.getString("voice_en", null)?.let { "Selected: $it" } ?: "Auto · girl's voice picked for you"
        voiceHiSub.text = prefs.getString("voice_hi", null)?.let { "Selected: $it" } ?: "Auto · girl's voice picked for you"
        if (!aiCopying) {
            aiSub.text = if (!LlmEngine.supported()) "Not available on 32-bit phones"
            else if (LlmEngine.modelFile(this) != null) "Added ✓" else "Add a .task / .bin file so I can answer questions"
        }
    }

    // ------------------------------------------------------------------ render (runs every 200 ms)
    private fun render() {
        if (!::toggle.isInitialized || !::aiSub.isInitialized) return
        val now = System.currentTimeMillis()
        val running = AssistantService.running
        val listening = AssistantService.listening
        if (!running && AssistantService.lastError != null) startingUntil = 0
        val starting = !listening && (running || now < startingUntil)
        val on = if (now < stoppingUntil) false else (listening || starting)
        toggle.setOn(on)

        val phrase = Store.wakeList(this).firstOrNull() ?: Store.DEFAULT_WAKE
        val st = if (!on) 0 else if (starting) 1 else 2
        heroSub.text = when (st) {
            2 -> "ON · Say “$phrase”"
            1 -> "Starting… loading voices"
            else -> "OFF · Switch on to start listening"
        }
        if (st != heroState) {
            heroState = st
            val color = when (st) { 2 -> Ui.GREEN; 1 -> Ui.AMBER; else -> Ui.MUTED }
            (dot.background as android.graphics.drawable.GradientDrawable).setColor(color)
            heroSub.setTextColor(if (st == 2) Ui.GREEN else if (st == 1) Ui.AMBER else Ui.MUTED)
            heroCard.background = Ui.round(
                if (st == 2) 0xFF0C1A12.toInt() else Ui.CARD, Ui.dpf(this, 22f),
                if (st == 2) 0xFF1F6B3A.toInt() else Ui.STROKE, Ui.dp(this, 1)
            )
            pulse?.cancel()
            dot.alpha = 1f
            if (st != 0) {
                pulse = ObjectAnimator.ofFloat(dot, "alpha", 1f, 0.25f).apply {
                    duration = 700
                    repeatCount = ObjectAnimator.INFINITE
                    repeatMode = ObjectAnimator.REVERSE
                    start()
                }
            }
        }
        val err = if (now < warnUntil) warnText
        else if (!running && !starting) AssistantService.lastError?.let { "Stopped: $it" } else null
        if (err.isNullOrEmpty()) {
            heroErr.visibility = View.GONE
        } else {
            heroErr.text = err
            heroErr.visibility = View.VISIBLE
        }

        renderPack()
        renderSetup()
        renderMore()
    }

    // ------------------------------------------------------------------ voice test
    private fun withTts(f: (TextToSpeech) -> Unit) {
        val t = testTts
        if (t != null && testReady) {
            f(t)
            return
        }
        if (testInit) return
        testInit = true
        testTts = TextToSpeech(this) { st ->
            testReady = st == TextToSpeech.SUCCESS
            testInit = false
            runOnUiThread {
                val x = testTts
                if (testReady && x != null) f(x) else toast("Text-to-speech engine not available")
            }
        }
    }

    private fun speakTest() = withTts { doSpeak(it, false) }

    private fun doSpeak(t: TextToSpeech, hindi: Boolean) {
        Speech.apply(t, this, hindi)
        Speech.say(
            t, this,
            if (hindi) "हम्म, बोलो जी, क्या काम है?" else "Hmm, bolo ji, kya kaam hai?",
            "test"
        )
    }

    /** Lists installed offline voices (girl voices first). Tap one to hear it and keep it. */
    private fun pickVoice(hindi: Boolean) {
        withTts { t ->
            val list = Speech.voicesFor(t, hindi)
            if (list.isEmpty()) {
                toast("No offline voice found. Install voice data, then try again.")
                try {
                    startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
                } catch (_: Exception) {
                    try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) {}
                }
                return@withTts
            }
            val names = list.map {
                (if (Speech.isFemale(it)) "♀ Girl · " else "") + it.locale.displayCountry + " · " + it.name
            }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle(if (hindi) "Hindi voice" else "English / Hinglish voice")
                .setItems(names) { _, i ->
                    prefs.edit().putString(if (hindi) "voice_hi" else "voice_en", list[i].name).apply()
                    doSpeak(t, hindi)
                }
                .setNeutralButton("Auto") { _, _ ->
                    prefs.edit().remove(if (hindi) "voice_hi" else "voice_en").apply()
                    doSpeak(t, hindi)
                }
                .setNegativeButton("Close", null)
                .show()
        }
    }

    // ------------------------------------------------------------------ custom commands
    private fun customDialog() {
        val pad = Ui.dp(this, 16)
        val list = Store.customs(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, 0)
        val tvList = TextView(this)
        tvList.text = if (list.isEmpty()) "(no custom commands yet)" else list.joinToString("\n") { "• ${it.first}  →  ${it.second}" }
        box.addView(tvList)
        val e1 = EditText(this)
        e1.hint = "When I say…"
        val e2 = EditText(this)
        e2.hint = "Do… (e.g. open youtube / call mom / say good morning)"
        box.addView(e1)
        box.addView(e2)
        AlertDialog.Builder(this)
            .setTitle("Custom commands")
            .setView(box)
            .setPositiveButton("Add") { _, _ ->
                val a = e1.text.toString().trim()
                val b = e2.text.toString().trim()
                if (a.isNotEmpty() && b.isNotEmpty()) {
                    list.add(a.lowercase() to b)
                    Store.saveCustoms(this, list)
                }
            }
            .setNeutralButton("Delete last") { _, _ ->
                if (list.isNotEmpty()) {
                    list.removeAt(list.size - 1)
                    Store.saveCustoms(this, list)
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ------------------------------------------------------------------ AI model picker
    private fun pickAiModel() {
        if (!LlmEngine.supported()) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        @Suppress("DEPRECATION")
        startActivityForResult(i, pickCode)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != pickCode || resultCode != RESULT_OK || uri == null) return

        var name = "model.task"
        contentResolver.query(uri, null, null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = cur.getString(i) ?: name
            }
        }
        val fname = name
        aiCopying = true
        aiSub.text = "Copying… keep the app open"
        thread {
            try {
                val dir = File(filesDir, "llm")
                dir.deleteRecursively()
                dir.mkdirs()
                val part = File(dir, "$fname.part")
                contentResolver.openInputStream(uri)!!.use { input ->
                    part.outputStream().use { out -> input.copyTo(out, 1 shl 16) }
                }
                part.renameTo(File(dir, fname))
                runOnUiThread { aiCopying = false }
            } catch (e: Exception) {
                runOnUiThread {
                    aiCopying = false
                    aiSub.text = "Copy failed: ${e.message}"
                }
            }
        }
    }
}
