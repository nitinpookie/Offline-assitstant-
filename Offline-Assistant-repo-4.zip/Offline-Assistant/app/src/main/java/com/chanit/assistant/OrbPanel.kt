package com.chanit.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.sin

/** Flowing Siri-like waves. state: 0 idle, 1 listening (reacts to your voice), 2 thinking, 3 speaking */
class WaveView(ctx: Context) : View(ctx) {
    var state = 0
    var level = 0f
    private var t = 0f
    private var amp = 0.1f
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val colors = intArrayOf(0xFF22D3EE.toInt(), 0xFFA855F7.toInt(), 0xFFFF6BA8.toInt())
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1500
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((70 * d).toInt(), (40 * d).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val mid = h / 2f
        val pi = PI.toFloat()
        val ph = t * 2f * pi
        val target = when (state) {
            1 -> 0.2f + level.coerceIn(0f, 1f) * 0.8f
            2 -> 0.32f
            3 -> 0.6f
            else -> 0.08f
        }
        amp += (target - amp) * 0.15f
        val speed = if (state == 2) 2.4f else 1f
        paint.strokeWidth = 2.6f * d
        for (k in 0 until 3) {
            paint.color = colors[k]
            paint.alpha = if (k == 0) 255 else 175
            path.reset()
            val freq = 1.1f + 0.55f * k
            val dir = if (k == 1) -1f else 1f
            val k2 = 1f - 0.28f * k
            val wob = if (state == 3) 0.75f + 0.25f * sin(ph * 2f + k) else 1f
            var x = 0f
            while (x <= w) {
                val nx = x / w
                val env = sin(pi * nx)
                val y = mid + sin(nx * 2f * pi * freq + ph * speed * dir + k * 1.7f) * h * 0.42f * amp * k2 * wob * env * env
                if (x == 0f) path.moveTo(x, y) else path.lineTo(x, y)
                x += 3f * d
            }
            canvas.drawPath(path, paint)
        }
    }
}

/**
 * The Siri-style pill: dark capsule, slowly turning rainbow edge, flowing waves + what I heard / say.
 * Same small API as before (update / level / onIdle) so the service and the assistant screen work unchanged.
 */
class OrbPanel(ctx: Context) : LinearLayout(ctx) {
    private val d = resources.displayMetrics.density
    private val wave = WaveView(ctx)
    private val label = TextView(ctx)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val mat = Matrix()
    private var sweep: SweepGradient? = null
    private var angle = 0f
    var onIdle: (() -> Unit)? = null

    private val spin = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 3200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            angle = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setWillNotDraw(false)
        val padH = (16 * d).toInt()
        val padV = (8 * d).toInt()
        setPadding(padH, padV, padH, padV)
        minimumWidth = (150 * d).toInt()

        fill.style = Paint.Style.FILL
        fill.color = 0xB0101015.toInt()   // dark glass, you can still see a bit of what is behind
        edge.style = Paint.Style.STROKE

        addView(wave)
        label.setTextColor(0xF2FFFFFF.toInt())
        label.textSize = 15f
        label.maxLines = 3
        label.ellipsize = TextUtils.TruncateAt.END
        label.maxWidth = (resources.displayMetrics.widthPixels * 0.58f).toInt()
        label.setPadding((10 * d).toInt(), 0, (4 * d).toInt(), 0)
        label.visibility = View.GONE
        addView(label)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        sweep = SweepGradient(
            w / 2f, h / 2f,
            intArrayOf(0xFF22D3EE.toInt(), 0xFF5B7CFF.toInt(), 0xFFA855F7.toInt(), 0xFFFF6BA8.toInt(), 0xFFFFA14A.toInt(), 0xFF22D3EE.toInt()),
            null
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, fill)

        val s = sweep
        if (s != null) {
            mat.setRotate(angle, w / 2f, h / 2f)
            s.setLocalMatrix(mat)
            edge.shader = s
            // soft glow, then the crisp edge on top
            edge.strokeWidth = 6f * d
            edge.alpha = 38
            rect.set(3.5f * d, 3.5f * d, w - 3.5f * d, h - 3.5f * d)
            canvas.drawRoundRect(rect, r, r, edge)
            edge.strokeWidth = 1.5f * d
            edge.alpha = 215
            rect.set(1f * d, 1f * d, w - 1f * d, h - 1f * d)
            canvas.drawRoundRect(rect, r, r, edge)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        spin.start()
        alpha = 0f
        scaleX = 0.8f
        scaleY = 0.8f
        translationY = -28f * d
        animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(200).setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    override fun onDetachedFromWindow() {
        spin.cancel()
        super.onDetachedFromWindow()
    }

    /** state: 0 idle, 1 listening, 2 thinking, 3 speaking */
    fun update(state: Int, text: String?) {
        wave.state = state
        if (state != 0) {
            val t = if (text.isNullOrEmpty()) {
                when (state) {
                    1 -> "Listening…"
                    2 -> "Thinking…"
                    else -> ""
                }
            } else text
            if (t.isEmpty()) {
                label.visibility = View.GONE
            } else {
                label.text = t
                label.visibility = View.VISIBLE
            }
        }
        // at idle the last words stay visible for a moment, then the pill fades away
        if (state == 0) onIdle?.invoke()
    }

    fun level(l: Float) {
        wave.level = wave.level * 0.6f + l * 0.4f
    }

    /** Glide out, then run [end] (usually removes the window). */
    fun dismiss(animated: Boolean, end: () -> Unit) {
        if (!animated) {
            end()
            return
        }
        animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).translationY(-24f * d)
            .setDuration(160).withEndAction { end() }.start()
    }
}
