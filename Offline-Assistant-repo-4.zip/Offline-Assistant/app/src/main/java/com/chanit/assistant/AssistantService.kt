package com.chanit.assistant

import android.Manifest
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.media.audiofx.AcousticEchoCanceler
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.Executors

private const val S_WAKE = 0
private const val S_CMD = 1
private const val S_THINK = 2
private const val S_SPEAK = 3

private class Cand(val text: String, val score: Double, val hindi: Boolean, val avg: Double, val words: Int)

// ---- tuning knobs for "hears the wrong thing" (safe to adjust) ----
/** average word confidence under this = most likely noise or made-up words, so it is ignored */
private const val MIN_AVG_CONF = 0.40
/** a result of just one word must be surer than this */
private const val MIN_SINGLE_CONF = 0.55
/** a command needs at least this many 100 ms pieces of real voice energy, otherwise it was background noise */
private const val MIN_VOICED_CHUNKS = 2
/** quietest sound (0..1) that can count as a voice */
private const val MIN_RMS = 0.006f
/** one-word results that small speech models invent out of noise */
private val JUNK = setOf(
    "the", "a", "an", "uh", "um", "huh", "oh", "ah", "eh", "hmm", "i", "it", "he", "she", "and", "is", "to", "in", "of", "on", "so",
    "है", "हैं", "का", "की", "के", "में", "से", "को", "तो", "ही", "भी", "और", "ये", "वो", "यह", "वह", "था", "थी"
)

/** a grammar result is only trusted when it starts like a real "do this" command */
private val ACTION_EN = setOf("call", "dial", "open", "launch", "message", "text", "whatsapp", "sms")
/** fixed words of the "call <contact> / open <app>" grammar (contact and app names are added at start) */
private val CMD_EN = listOf(
    "call", "dial", "open", "launch", "start", "send", "message", "text", "whatsapp", "sms", "to", "the", "please", "app",
    "my", "saying", "that", "a", "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "oh"
)
/** while the phone rings: these pick the call up (the wake phrase works too) */
private val RING_EN = listOf(
    "pick up", "pick it up", "pickup", "answer", "answer it", "accept", "accept it", "receive", "utha", "uthao"
)
private val RING_HI_GRAMMAR = listOf(
    "फोन उठा", "फोन उठाओ", "फ़ोन उठा", "फ़ोन उठाओ", "कॉल उठा", "कॉल उठाओ", "फोन उठा लो", "कॉल उठा लो", "फोन उठा ले",
    "उठा", "उठाओ", "उठाइए", "उठा लो", "उठा ले", "रिसीव", "रिसीव करो", "फोन रिसीव करो", "कॉल रिसीव करो",
    "पिक अप", "पिकअप", "एक्सेप्ट", "एक्सेप्ट करो", "अटेंड", "अटेंड करो", "आंसर", "ओए", "ओये", "ओए फोन उठा",
    "ओए पुकी", "ओये पुकी", "पुकी", "पूकी", "पुक्की"
)
private val RING_HI_HIT = listOf("उठा", "रिसीव", "पुकी", "पूकी", "पुक्की", "पिक", "एक्सेप्ट", "अटेंड", "आंसर")
/** leftovers of the wake phrase that can stick to the front of a command ("pookie call rahul") */
private val LEAD = setOf(
    "oye", "oy", "oi", "hey", "hay", "ok", "okay", "oh", "ae", "ay", "yo", "hi",
    "pookie", "pooky", "pookey", "pooki", "puki", "poo", "cookie", "cooky", "bookie", "hookie", "rookie", "ookie", "key", "kie",
    "ओए", "ओये", "हे", "पुकी", "पूकी", "पुक्की"
)

/**
 * Always-listening foreground service.
 * wake phrase -> command (Hindi + English heard together, best one wins) -> action -> spoken reply (offline TTS).
 * While it speaks, "stop" or the wake phrase interrupts it.
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "com.chanit.assistant.STOP"
        const val ACTION_LISTEN_NOW = "com.chanit.assistant.LISTEN_NOW"
        @Volatile var running = false
        /** true once the mic is open and models are loaded (the switch shows "Starting…" before that) */
        @Volatile var listening = false
        /** last reason the assistant stopped by itself, shown on the main screen */
        @Volatile var lastError: String? = null
        @Volatile var instance: AssistantService? = null
        val panels = CopyOnWriteArraySet<OrbPanel>()

        private val STOP_EN = listOf("stop", "quiet", "silence", "enough", "shut up", "cancel")
        private val STOP_HI = listOf("रुको", "रुक", "बस", "चुप", "बंद", "स्टॉप", "रुकिए")

        fun listenNow(c: Context) {
            val s = instance
            if (s != null) {
                s.listenRequested = true
                return
            }
            try {
                c.startForegroundService(Intent(c, AssistantService::class.java).setAction(ACTION_LISTEN_NOW))
            } catch (_: Throwable) {}
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val pool = Executors.newFixedThreadPool(2)   // helpers: models load together, decoders run side by side
    private lateinit var ear: OnlineEar
    private val tone by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 80) }
    private lateinit var llm: LlmEngine
    private lateinit var commands: Commands

    @Volatile private var alive = false
    @Volatile private var state = S_WAKE
    @Volatile private var resetAsr = false
    @Volatile var listenRequested = false
    @Volatile private var follow = false
    @Volatile private var pendingFollow = false
    @Volatile private var ttsReady = false
    @Volatile private var uiState = 0
    @Volatile private var lastHindi = false
    private val fast = Executors.newSingleThreadExecutor()   // speaking happens here, so the mic loop is never blocked
    @Volatile private var speakGuardUntil = 0L   // just after speech starts: ignore "stop"/wake (echo of our own voice)
    @Volatile private var wakeBlockUntil = 0L    // just after speech ends: the tail must not trigger the wake word
    @Volatile private var uiPending: String? = null
    @Volatile private var replyId = ""
    @Volatile private var idleChecks = 0
    @Volatile private var followLimit = 3500L   // how long to wait for one more command after an action

    /** shows the pill at the moment the voice really starts, so picture and sound match */
    private val showSpeakUi = Runnable {
        val t = uiPending
        if (t != null) {
            uiPending = null
            ui(3, t)
        }
    }

    /** safety net: if the speech engine never reports "done", don't stay deaf forever */
    private val speakWatch = object : Runnable {
        override fun run() {
            if (state != S_SPEAK) return
            val busy = try { tts?.isSpeaking == true } catch (_: Throwable) { false }
            if (busy) {
                idleChecks = 0
                main.postDelayed(this, 700)
            } else if (++idleChecks >= 2) {
                afterSpeech()
            } else {
                main.postDelayed(this, 500)
            }
        }
    }
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var overlayPanel: OrbPanel? = null
    private var wakes: List<String> = emptyList()
    private var wakeLabel = "hey"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        llm = LlmEngine(applicationContext)
        commands = Commands(applicationContext, llm)
        ear = OnlineEar(applicationContext, main)
        fast.execute { ear.available() }   // looks up the phone's online speech service once, not at the first command
        val nm = getSystemService(NotificationManager::class.java)
        try { nm.deleteNotificationChannel("assistant") } catch (_: Throwable) {}
        // smallest possible notification: no sound, no status-bar icon, hidden on the lock screen
        nm.createNotificationChannel(
            NotificationChannel("assistant_quiet", "Assistant running", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
        )
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    // the voice really started: show the pill now
                    if (utteranceId != null && (utteranceId == replyId || utteranceId.startsWith("part"))) main.post(showSpeakUi)
                }
                override fun onDone(utteranceId: String?) { if (utteranceId == replyId) afterSpeech() }
                override fun onError(utteranceId: String?) {
                    if (utteranceId != null && (utteranceId == replyId || utteranceId.startsWith("part"))) {
                        try { tts?.stop() } catch (_: Throwable) {}
                        afterSpeech()
                    }
                }
            })
            if (ttsReady) warmUp()
        }
    }

    /** loads the voice once at start, so the first "Hmm, bolo ji" doesn't pay the loading time */
    private fun warmUp() {
        fast.execute {
            try {
                val t = tts ?: return@execute
                Speech.apply(t, this, false)
                val quiet = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 0f) }
                t.speak("hm", TextToSpeech.QUEUE_FLUSH, quiet, "warm")
            } catch (_: Throwable) {}
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val n = buildNotification("Starting…")
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Throwable) {
            Alerts.promptStart(this)
            stopSelf()
            return START_NOT_STICKY
        }
        instance = this
        running = true
        if (intent?.action == ACTION_LISTEN_NOW) listenRequested = true
        if (!alive) {
            alive = true
            try {
                val pm = getSystemService(PowerManager::class.java)
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "chanit:listen")
                wakeLock?.acquire()
            } catch (_: Throwable) {}
            Thread { loop() }.start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        running = false
        listening = false
        instance = null
        main.post { removeOverlay(false) }
        try { tts?.shutdown() } catch (_: Throwable) {}
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Throwable) {}
        llm.close()
        ear.destroy()
        main.removeCallbacks(speakWatch)
        main.removeCallbacks(showSpeakUi)
        exec.shutdownNow()
        fast.shutdownNow()
        pool.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ audio loop
    private fun parse(json: String, hindi: Boolean): Cand {
        val o = JSONObject(json)
        val text = o.optString("text").trim()
        var sum = 0.0
        var n = 0
        val arr = o.optJSONArray("result")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                sum += arr.getJSONObject(i).optDouble("conf", 0.6)
                n++
            }
        }
        if (n == 0 && text.isNotEmpty()) {
            n = text.split(" ").size
            sum = 0.6 * n
        }
        val avg = if (n > 0) sum / n else 0.0
        // The AVERAGE confidence decides (small bonus for explaining more words).
        // Before, every confidence was added up, so the model that invented the most words won.
        val score = avg * (1.0 + 0.08 * minOf(n, 6))
        return Cand(text, score, hindi, avg, n)
    }

    /** true = most likely noise or made-up words: must not be run as a command */
    private fun looksLikeNoise(c: Cand): Boolean {
        if (c.text.isEmpty()) return true
        if (c.avg < MIN_AVG_CONF) return true
        if (c.words <= 1 && (c.avg < MIN_SINGLE_CONF || c.text.lowercase(Locale.ROOT) in JUNK)) return true
        return false
    }

    /**
     * Opens the mic the way the speech model likes it: VOICE_RECOGNITION (the same source the
     * "Teach my voice" screen uses). VOICE_COMMUNICATION is tuned for phone calls and squashes speech.
     */
    private fun openMic(minBuf: Int): AudioRecord {
        val size = maxOf(minBuf, 16000) * 4    // about 2 seconds of safety buffer
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_COMMUNICATION
        )
        for (src in sources) {
            try {
                val r = AudioRecord(src, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
                if (r.state == AudioRecord.STATE_INITIALIZED) return r
                r.release()
            } catch (_: Throwable) {}
        }
        throw IllegalStateException("Microphone not available")
    }

    /** all words of the "call <contact> / open <app>" grammar */
    private fun buildCmdWords(vocab: Set<String>?): List<String> {
        val out = LinkedHashSet<String>(CMD_EN)
        fun add(s: String) {
            for (p in s.lowercase(Locale.ROOT).split(Regex("[^a-z]+"))) {
                if (p.length >= 2 && (vocab == null || p in vocab)) out.add(p)
            }
        }
        try {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME), null, null, null
                )?.use { cur ->
                    var k = 0
                    while (cur.moveToNext() && k < 1500) {
                        cur.getString(0)?.let { add(it) }
                        k++
                    }
                }
            }
        } catch (_: Throwable) {}
        try {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            for (ri in apps.take(400)) add(ri.loadLabel(pm).toString())
        } catch (_: Throwable) {}
        return out.toList().take(1200)
    }

    /** tries to get the mic back (another app may hold it for a while) */
    private fun reopenMic(minBuf: Int): AudioRecord? {
        for (i in 0 until 30) {
            if (!alive) return null
            try { Thread.sleep(2000) } catch (_: InterruptedException) { return null }
            try {
                val r = openMic(minBuf)
                r.startRecording()
                try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.setEnabled(true) } catch (_: Throwable) {}
                return r
            } catch (_: Throwable) {}
        }
        return null
    }

    /** removes wake-phrase leftovers at the front: "pookie call rahul" -> "call rahul" */
    private fun cleanLead(text: String): String {
        val w = text.trim().split(Regex("\\s+")).toMutableList()
        val wl = wakes.flatMap { it.split(" ") }.toSet()
        while (w.size > 1) {
            val f = w[0].lowercase(Locale.ROOT)
            if (f in LEAD || f in wl) w.removeAt(0) else break
        }
        return w.joinToString(" ")
    }

    /** picks up the ringing call (normal phone call, or WhatsApp-type call if notification access is on) and puts it on speaker */
    private fun answerCall(gsm: Boolean) {
        ui(2, "Call utha raha hoon…")
        fast.execute {
            var done = false
            if (gsm) {
                try {
                    if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
                        getSystemService(TelecomManager::class.java).acceptRingingCall()
                        done = true
                    }
                } catch (_: Throwable) {}
            }
            // no phone permission, or a WhatsApp-type call: press the Answer button of the call notification
            if (!done) done = CallNotifService.answer()
            // last chance: tap the Answer button on the screen
            if (!done) ScreenService.instance?.clickText("answer", "accept", "जवाब", "उत्तर", "स्वीकार")
            speakerOn(gsm)
            main.postDelayed({ ui(0, null) }, 1200)
        }
    }

    @Suppress("DEPRECATION")
    private fun speakerIsOn(am: AudioManager): Boolean = try { am.isSpeakerphoneOn } catch (_: Throwable) { false }

    @Suppress("DEPRECATION")
    private fun forceSpeaker(am: AudioManager) {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val d = am.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                if (d != null) am.setCommunicationDevice(d)
            }
        } catch (_: Throwable) {}
        try { am.isSpeakerphoneOn = true } catch (_: Throwable) {}
    }

    private fun speakerOn(gsm: Boolean) {
        val am = getSystemService(AudioManager::class.java)
        if (gsm) {
            // wait until the call is really connected
            val tm = getSystemService(TelephonyManager::class.java)
            var waited = 0
            while (waited < 8000) {
                val cs = try { tm.callState } catch (_: Throwable) { TelephonyManager.CALL_STATE_IDLE }
                if (cs == TelephonyManager.CALL_STATE_OFFHOOK) break
                try { Thread.sleep(150) } catch (_: InterruptedException) { return }
                waited += 150
            }
        } else {
            try { Thread.sleep(1500) } catch (_: InterruptedException) { return }
        }
        // some phones reset the route right after connecting, so set it a few times
        for (i in 0 until 6) {
            try { Thread.sleep(400) } catch (_: InterruptedException) { return }
            forceSpeaker(am)
            if (i >= 2 && speakerIsOn(am)) break
        }
        // last resort: tap the speaker button of the call screen, but only if the speaker is still off
        if (!speakerIsOn(am)) ScreenService.instance?.clickText("speaker", "स्पीकर", "loudspeaker")
    }

    private fun loop() {
        val closers = ArrayList<AutoCloseable>()
        var recHolder: AudioRecord? = null
        try {
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            val prefs = Store.prefs(this)
            val mode = Store.mode(this)
            lastError = null
            val rawWakes = Store.wakeList(this)
            wakeLabel = rawWakes.firstOrNull() ?: "hey"
            // the speech model only knows its own words: keep only those, so "oye pookie" still
            // matches even if the model hears just "pookie" (too-short leftovers are dropped)
            val vocab = loadVocab(ModelStore.dir(this, "en"))
            wakes = if (vocab == null) rawWakes else
                rawWakes.map { ph -> ph.split(" ").filter { w -> w in vocab }.joinToString(" ") }
                    .filter { it.replace(" ", "").length >= 5 }
                    .distinct()
                    .ifEmpty { listOf("hey cookie") }
            lastHindi = mode == "hi"

            // both speech models load at the same time (cheap phones need several seconds for each)
            val enPath = ModelStore.dir(this, "en").absolutePath
            val hiFuture = if (mode != "en" && ModelStore.ready(this, "hi")) {
                val hiPath = ModelStore.dir(this, "hi").absolutePath
                pool.submit(Callable<Model> { Model(hiPath) })
            } else null
            val en = Model(enPath)
            closers.add(en)
            val hi: Model? = hiFuture?.get()
            if (hi != null) closers.add(hi)
            val useHi = hi != null
            val useEn = mode != "hi" || !useHi

            val wakeRec = Recognizer(en, 16000.0f, JSONArray(wakes + "[unk]").toString())
            closers.add(wakeRec)
            val enRec: Recognizer? = if (useEn) {
                val r = Recognizer(en, 16000.0f); r.setWords(true); closers.add(r); r
            } else null
            val hiRec: Recognizer? = if (useHi) {
                val r = Recognizer(hi!!, 16000.0f); r.setWords(true); closers.add(r); r
            } else null
            val stopEn = Recognizer(en, 16000.0f, JSONArray(STOP_EN + wakes + "[unk]").toString())
            closers.add(stopEn)
            val stopHi: Recognizer? = if (hi != null) {
                val r = Recognizer(hi, 16000.0f, JSONArray(STOP_HI + "[unk]").toString()); closers.add(r); r
            } else null
            // "call <contact>" / "open <app>": a small grammar of your own contact and app names is heard
            // far more reliably than free speech. Only trusted when the result clearly looks like such a command.
            val cmdRec: Recognizer? = if (useEn) {
                try {
                    val r = Recognizer(en, 16000.0f, JSONArray(buildCmdWords(vocab) + "[unk]").toString())
                    r.setWords(true)
                    closers.add(r)
                    r
                } catch (_: Throwable) { null }
            } else null
            // while the phone rings, the wake phrase or "phone utha" picks the call up
            val ringEn = Recognizer(
                en, 16000.0f,
                JSONArray(wakes + RING_EN.filter { vocab == null || it.split(" ").all { w -> w in vocab } } + "[unk]").toString()
            )
            closers.add(ringEn)
            val ringHi: Recognizer? = if (hi != null) {
                val r = Recognizer(hi, 16000.0f, JSONArray(RING_HI_GRAMMAR + "[unk]").toString()); closers.add(r); r
            } else null

            // the mic loop gets audio-thread priority, so a busy cheap phone doesn't drop or delay voice pieces
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (_: Throwable) {}
            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            var ar = openMic(minBuf)
            recHolder = ar
            // echo cancel only (no NoiseSuppressor: it distorts speech and makes the model mishear)
            try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(ar.audioSessionId)?.setEnabled(true) } catch (_: Throwable) {}
            ar.startRecording()
            listening = true
            try { tone.stopTone() } catch (_: Throwable) {}   // creates the beep generator now, not at the first wake
            setStatus("Say \"$wakeLabel\"")

            val buf = ShortArray(1600)
            var t0 = 0L
            var heard = false
            var firstLimit = 7000L
            var checked = false
            var noiseFloor = 0.004f   // how loud the room is when nobody talks
            var voiced = 0            // 100 ms pieces with real voice energy in this command
            var voiceFrom = 0L        // ignore the beep / speech tail right after we start listening
            var rejects = 0
            val startT = System.currentTimeMillis()
            var lastCallCheck = 0L
            var callSt = TelephonyManager.CALL_STATE_IDLE
            var lastCallSt = TelephonyManager.CALL_STATE_IDLE
            var ringBlockUntil = 0L
            var lastVoip = false
            val dsp = MicDsp()
            // ---- hybrid hearing: offline models always listen; the internet ear joins when the internet works ----
            var online = false              // the internet ear is also listening to this command
            var cmdFu = false               // this command window is a quick "one more thing" window: offline only, no extra beep
            var offDoneAt = 0L              // when the offline side finished this command (0 = not yet)
            var offBest: Cand? = null
            var offCmd: Cand? = null
            var offAny = false
            var onlineSeenAt = 0L           // when the internet ear finished (0 = not yet)
            var cmdMaxRms = 0f              // loudest piece of this command (0 = the mic gave pure silence)
            var strikes = 0                 // internet-ear trouble in a row
            var onlineOffUntil = 0L         // internet ear paused until then (after repeated trouble)
            val gWords = ArrayList<String>()
            val gConf = ArrayList<Double>()
            var gUnk = 0

            fun gAdd(json: String) {
                try {
                    val arr = JSONObject(json).optJSONArray("result") ?: return
                    for (i in 0 until arr.length()) {
                        val r = arr.getJSONObject(i)
                        val w = r.optString("word")
                        if (w == "[unk]") { gUnk++; continue }
                        gWords.add(w)
                        gConf.add(r.optDouble("conf", 0.6))
                    }
                } catch (_: Throwable) {}
            }
            fun gClear() { gWords.clear(); gConf.clear(); gUnk = 0 }
            fun gBest(): Cand? {
                if (gWords.size < 2 || gUnk > 1 || gWords[0] !in ACTION_EN) return null
                val avg = gConf.sum() / gConf.size
                if (avg < 0.55) return null
                return Cand(gWords.joinToString(" "), avg * 2.0, false, avg, gWords.size)
            }

            fun endOnline() {
                if (online) {
                    online = false
                    ear.stop()
                }
            }

            fun startOnline() {
                if (cmdFu || !prefs.getBoolean("hybrid", true) || System.currentTimeMillis() < onlineOffUntil) return
                if (!ear.available() || !Net.online(this)) return
                ear.start(lastHindi)
                online = true
            }

            fun resetCmdSide() {
                offDoneAt = 0L
                offBest = null
                offCmd = null
                offAny = false
                onlineSeenAt = 0L
            }

            /** keeps score of the internet ear: 3 bad commands in a row = pause it for 10 minutes */
            fun noteOnline(ok: Boolean, hard: Boolean, silentMic: Boolean) {
                if (ok) {
                    strikes = 0
                    return
                }
                if (hard) strikes++
                if (silentMic) strikes += 2
                if (strikes >= 3) {
                    strikes = 0
                    onlineOffUntil = System.currentTimeMillis() + 10 * 60_000L
                }
            }

            fun toWake() {
                endOnline()
                state = S_WAKE
                resetAsr = true
                ui(0, null)
                setStatus("Say \"$wakeLabel\"")
            }

            fun enterCmd(fu: Boolean) {
                endOnline()
                cmdFu = fu
                resetCmdSide()
                cmdMaxRms = 0f
                wakeRec.reset(); enRec?.reset(); hiRec?.reset(); cmdRec?.reset()
                gClear()
                t0 = System.currentTimeMillis()
                voiceFrom = t0 + (if (fu) 200L else 250L)
                heard = false
                voiced = 0
                rejects = 0
                firstLimit = if (fu) followLimit else 7000L
                state = S_CMD
                if (!fu) {
                    try { tone.startTone(ToneGenerator.TONE_PROP_ACK, 70) } catch (_: Throwable) {}
                    startOnline()
                }
                ui(1, null)
                setStatus("Listening…")
            }

            // wake word heard -> (optional) answer out loud, then listen for the command.
            // The speaking runs on another thread, so the mic loop never waits for the voice engine.
            fun greet() {
                wakeRec.reset()
                val t = tts
                if (!ttsReady || t == null || !prefs.getBoolean("greet_voice", false)) {
                    enterCmd(false)
                    return
                }
                resetAsr = true
                speakGuardUntil = System.currentTimeMillis() + 900
                state = S_SPEAK
                fast.execute { speak(Reply("Hmm, bolo ji, kya kaam hai?", true), false) }
            }

            while (alive) {
                val n = ar.read(buf, 0, buf.size)
                if (n < 0) {
                    // the mic was taken away (another app, a call...): get it back instead of switching off
                    try { ar.stop() } catch (_: Throwable) {}
                    try { ar.release() } catch (_: Throwable) {}
                    val again = reopenMic(minBuf) ?: throw IllegalStateException("Microphone is busy with another app")
                    ar = again
                    recHolder = again
                    continue
                }
                if (n == 0) {
                    try { Thread.sleep(20) } catch (_: InterruptedException) {}
                    continue
                }
                val now = System.currentTimeMillis()

                if (!checked && now - startT > 1500) {
                    checked = true
                    if (Build.VERSION.SDK_INT >= 29 && ar.activeRecordingConfiguration?.isClientSilenced == true) {
                        Alerts.promptStart(this)
                        throw IllegalStateException("Android blocked the mic in background. Tap the notification to start.")
                    }
                }

                // how loud is this 100 ms piece (0..1)
                var sq = 0.0
                for (i in 0 until n) {
                    val v = buf[i] / 32768.0
                    sq += v * v
                }
                val rms = Math.sqrt(sq / n).toFloat()
                // clean the signal for the speech models (rumble filter + lift a quiet voice)
                dsp.process(buf, n, if (state == S_SPEAK) 0f else rms, noiseFloor)

                // phone call state (needs the phone permission; without it we just never see a call)
                if (now - lastCallCheck > 400) {
                    lastCallCheck = now
                    callSt = try {
                        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED)
                            getSystemService(TelephonyManager::class.java).callState
                        else TelephonyManager.CALL_STATE_IDLE
                    } catch (_: Throwable) { TelephonyManager.CALL_STATE_IDLE }
                }
                // a WhatsApp-type call (only seen when notification access is on)
                val voipRing = CallNotifService.ringing()
                if (callSt != lastCallSt || voipRing != lastVoip) {
                    lastCallSt = callSt
                    lastVoip = voipRing
                    ringEn.reset(); ringHi?.reset(); wakeRec.reset()
                    if ((callSt != TelephonyManager.CALL_STATE_IDLE || voipRing) && state != S_WAKE) {
                        try { tts?.stop() } catch (_: Throwable) {}
                        main.removeCallbacks(speakWatch)
                        main.removeCallbacks(showSpeakUi)
                        uiPending = null
                        follow = false
                        pendingFollow = false
                        toWake()
                    }
                    if (callSt == TelephonyManager.CALL_STATE_IDLE && !voipRing) resetAsr = true
                }
                // during a call the assistant stays quiet
                if (callSt == TelephonyManager.CALL_STATE_OFFHOOK) continue
                // somebody is calling: wake phrase or "phone utha" -> pick up, on speaker
                if (callSt == TelephonyManager.CALL_STATE_RINGING || voipRing) {
                    val de = ringEn.acceptWaveForm(buf, n)
                    val te = if (de) JSONObject(ringEn.result).optString("text") else JSONObject(ringEn.partialResult).optString("partial")
                    var th = ""
                    if (ringHi != null) {
                        val dh = ringHi.acceptWaveForm(buf, n)
                        th = if (dh) JSONObject(ringHi.result).optString("text") else JSONObject(ringHi.partialResult).optString("partial")
                    }
                    val hit = (te.isNotEmpty() && (wakes.any { te.contains(it) } || RING_EN.any { te.contains(it) })) ||
                        (th.isNotEmpty() && RING_HI_HIT.any { th.contains(it) })
                    if (hit && now >= ringBlockUntil) {
                        ringBlockUntil = now + 5000
                        ringEn.reset(); ringHi?.reset()
                        answerCall(callSt == TelephonyManager.CALL_STATE_RINGING)
                    }
                    continue
                }

                if (resetAsr) {
                    resetAsr = false
                    wakeRec.reset(); enRec?.reset(); hiRec?.reset(); stopEn.reset(); stopHi?.reset()
                }
                val locked = isLocked()
                val lockOff = prefs.getString("lock_mode", "calls") == "off"

                if (state == S_WAKE) {
                    // learn how noisy the room is while nobody is talking to the assistant
                    noiseFloor = if (rms < noiseFloor * 2.5f) noiseFloor * 0.97f + rms * 0.03f else noiseFloor * 0.999f + rms * 0.001f
                    noiseFloor = noiseFloor.coerceIn(0.002f, 0.05f)
                    if (pendingFollow) {
                        pendingFollow = false
                        enterCmd(true)
                        continue
                    }
                    if (listenRequested) {
                        listenRequested = false
                        if (locked && lockOff) continue
                        greet()
                        continue
                    }
                }

                when (state) {
                    S_WAKE -> {
                        if (now >= wakeBlockUntil) {
                            val done = wakeRec.acceptWaveForm(buf, n)
                            val txt = if (done) JSONObject(wakeRec.result).optString("text")
                            else JSONObject(wakeRec.partialResult).optString("partial")
                            if (txt.isNotEmpty() && wakes.any { txt.contains(it) }) {
                                if (locked && lockOff) {
                                    wakeRec.reset()
                                } else {
                                    greet()
                                }
                            }
                        }
                    }
                    S_CMD -> {
                        levelUi(rms)
                        if (rms > cmdMaxRms) cmdMaxRms = rms
                        if (now >= voiceFrom && rms > maxOf(MIN_RMS, noiseFloor * 2.2f)) voiced++
                        // the decoders work side by side on different cores (this is what makes cheap phones keep up)
                        val chunk = buf
                        val fHi = hiRec?.let { r -> pool.submit(Callable<Boolean> { r.acceptWaveForm(chunk, n) }) }
                        val fG = cmdRec?.let { r -> pool.submit(Callable<Boolean> { r.acceptWaveForm(chunk, n) }) }
                        val dEn = enRec?.acceptWaveForm(chunk, n) ?: false
                        val dHi = fHi?.get() ?: false
                        val dG = fG?.get() ?: false
                        if (dG) cmdRec?.let { gAdd(it.result) }
                        val age = now - t0

                        // ---- offline side: when it has finished, freeze its answer
                        if (offDoneAt == 0L && (dEn || dHi || age > 15000)) {
                            val cands = ArrayList<Cand>()
                            enRec?.let { cands.add(parse(if (dEn) it.result else it.finalResult, false)) }
                            hiRec?.let { cands.add(parse(if (dHi) it.result else it.finalResult, true)) }
                            cmdRec?.let { if (!dG) gAdd(it.finalResult) }
                            offCmd = gBest()
                            gClear()
                            enRec?.reset(); hiRec?.reset(); cmdRec?.reset()
                            offBest = offCmd ?: cands.filter { !looksLikeNoise(it) }.maxByOrNull { it.score }
                            offAny = cands.any { it.text.isNotEmpty() }
                            offDoneAt = now
                        }

                        // ---- internet side
                        val onFin = online && ear.finished
                        val onTxt = if (onFin) ear.text.trim() else ""
                        val onOk = onTxt.length >= 2
                        if (onFin && onlineSeenAt == 0L) onlineSeenAt = now

                        // ---- who answers? the internet text wins, except a clear "call / open ..." that the phone
                        // understood itself from your own contact and app names. 0 = wait, 1 = offline, 2 = internet
                        var verdict = 0
                        if (offDoneAt != 0L) {
                            if (offCmd != null || !online) verdict = 1
                            else if (onFin) verdict = if (onOk) 2 else 1
                            else if (now - offDoneAt > (if (ear.partial.isNotEmpty()) 2200L else 900L)) verdict = 1
                        } else if (onFin && onOk && now - onlineSeenAt > 450L) {
                            verdict = 2
                        }

                        if (verdict == 0) {
                            if (offDoneAt == 0L) {
                                val pe = enRec?.let { JSONObject(it.partialResult).optString("partial") } ?: ""
                                val ph = hiRec?.let { JSONObject(it.partialResult).optString("partial") } ?: ""
                                var part = if (pe.length >= ph.length) pe else ph
                                val op = if (online) ear.partial else ""
                                if (op.isNotEmpty()) part = op
                                // words only count as "heard" when there is real voice energy behind them
                                // (the internet ear only reports real speech, so its words count at once)
                                if (part.isNotEmpty() && (voiced >= MIN_VOICED_CHUNKS || op.isNotEmpty())) {
                                    heard = true
                                    ui(1, part)
                                } else if (!heard && age > firstLimit) {
                                    toWake()
                                }
                            }
                        } else {
                            val useOnline = verdict == 2
                            val best = offBest
                            val spoke = voiced >= MIN_VOICED_CHUNKS
                            if (online) noteOnline(useOnline, onFin && ear.hardFail, cmdMaxRms < 0.0002f && !useOnline)
                            if (useOnline) {
                                endOnline()
                                process(onTxt, Hinglish.isHindi(onTxt), locked)
                            } else if (best != null && spoke) {
                                endOnline()
                                process(best.text, best.hindi, locked)
                            } else if (spoke && offAny) {
                                // someone clearly spoke but nothing trustworthy came out: ask again instead of guessing
                                rejects++
                                if (rejects >= 2) {
                                    toWake()
                                } else {
                                    endOnline()
                                    resetCmdSide()
                                    t0 = System.currentTimeMillis()
                                    heard = false
                                    voiced = 0
                                    ui(1, "Samajh nahi aaya, phir se bolo")
                                    startOnline()
                                }
                            } else {
                                // only noise: forget it and keep waiting (until the time runs out)
                                heard = false
                                voiced = 0
                                if (age > firstLimit) {
                                    toWake()
                                } else {
                                    resetCmdSide()
                                    // the internet ear may still be listening: leave it running, only restart it if it is over
                                    if (!(online && !ear.finished)) {
                                        endOnline()
                                        startOnline()
                                    }
                                }
                            }
                        }
                    }
                    S_SPEAK -> {
                        if (now >= speakGuardUntil) {
                            val de = stopEn.acceptWaveForm(buf, n)
                            val pe = if (de) JSONObject(stopEn.result).optString("text")
                            else JSONObject(stopEn.partialResult).optString("partial")
                            var ph = ""
                            if (stopHi != null) {
                                val dh = stopHi.acceptWaveForm(buf, n)
                                ph = if (dh) JSONObject(stopHi.result).optString("text")
                                else JSONObject(stopHi.partialResult).optString("partial")
                            }
                            val wakeHit = pe.isNotEmpty() && wakes.any { pe.contains(it) }
                            val stopHit = (pe.isNotEmpty() && STOP_EN.any { pe.contains(it) }) ||
                                (ph.isNotEmpty() && STOP_HI.any { ph.contains(it) })
                            if (wakeHit || stopHit) {
                                try { tts?.stop() } catch (_: Throwable) {}
                                main.removeCallbacks(speakWatch)
                                main.removeCallbacks(showSpeakUi)
                                uiPending = null
                                follow = false
                                pendingFollow = false
                                resetAsr = true
                                if (wakeHit) greet() else toWake()
                            }
                        }
                    }
                    else -> {}   // thinking: ignore audio
                }
            }
        } catch (e: Throwable) {
            // when the service is being switched off on purpose, helper tasks get cancelled: that is not an error
            if (alive) {
                val msg = e.message ?: e.toString()
                lastError = msg
                main.post { Toast.makeText(this, "Assistant error: $msg", Toast.LENGTH_LONG).show() }
            }
        } finally {
            try { recHolder?.stop() } catch (_: Throwable) {}
            try { recHolder?.release() } catch (_: Throwable) {}
            for (cl in closers) { try { cl.close() } catch (_: Throwable) {} }
            alive = false
            listening = false
            main.post { stopSelf() }
        }
    }

    // ------------------------------------------------------------------ commands + speech
    /** All words the English model knows (graph/words.txt), or null if the file isn't there. */
    private fun loadVocab(dir: File): Set<String>? = try {
        val f = File(dir, "graph/words.txt")
        if (!f.isFile) null else {
            val set = HashSet<String>(60000)
            f.forEachLine { line ->
                val i = line.indexOf(' ')
                if (i > 0) set.add(line.substring(0, i))
            }
            set
        }
    } catch (_: Throwable) {
        null
    }

    private fun isLocked(): Boolean =
        try { getSystemService(KeyguardManager::class.java).isKeyguardLocked } catch (_: Throwable) { false }

    private fun process(text0: String, hindi: Boolean, locked: Boolean) {
        val text = Hinglish.fix(cleanLead(text0))
        state = S_THINK
        lastHindi = hindi
        ui(2, "“$text”")
        setStatus("Heard: $text")
        // natural "hmm…" if the answer takes a moment (AI questions)
        val filler = Runnable {
            val t = tts
            if (state == S_THINK && ttsReady && t != null) {
                Speech.apply(t, this, hindi)
                Speech.say(t, this, if (hindi) "हम्म…" else "Hmm…", "filler")
            }
        }
        if (Store.prefs(this).getBoolean("tts_hmm", true) && !locked) main.postDelayed(filler, 600)
        exec.execute {
            val reply = try {
                commands.handle(text, hindi, locked)
            } catch (e: Throwable) {
                Reply(if (hindi) "कुछ गड़बड़ हो गई।" else "Something went wrong.")
            }
            main.removeCallbacks(filler)
            speak(reply, hindi)
        }
    }

    private fun speak(reply: Reply, hindi: Boolean) {
        follow = reply.follow
        val t = tts
        if (!ttsReady || t == null) {
            ui(3, reply.text)
            afterSpeech(true)
            return
        }
        // the pill appears when the voice really starts (see onStart); 1.5 s fallback if the engine never says so
        uiPending = reply.text
        main.removeCallbacks(showSpeakUi)
        main.postDelayed(showSpeakUi, 1500)
        val res = Speech.apply(t, this, hindi)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            main.post {
                Toast.makeText(this, "Install the offline voice for this language in phone Text-to-speech settings", Toast.LENGTH_LONG).show()
            }
        }
        speakGuardUntil = maxOf(speakGuardUntil, System.currentTimeMillis() + 300)
        replyId = "reply" + System.nanoTime()
        state = S_SPEAK
        Speech.say(t, this, reply.text, replyId)
        idleChecks = 0
        main.removeCallbacks(speakWatch)
        main.postDelayed(speakWatch, 3000)
    }

    /** speech finished (or failed): go back to listening. [force] = called directly, not from an engine callback */
    private fun afterSpeech(force: Boolean = false) {
        if (!force && state != S_SPEAK) return   // late or duplicate callback from an older sentence
        main.removeCallbacks(speakWatch)
        main.removeCallbacks(showSpeakUi)
        uiPending = null
        resetAsr = true
        // a question gets a long window for the answer; after an action wait a moment for "one more thing", then hide
        followLimit = if (follow) 8000L else 3500L
        pendingFollow = true
        follow = false
        state = S_WAKE
        ui(1, null)
    }

    /** reminders that fire while the service is idle */
    fun sayReminder(text: String) {
        if (state != S_WAKE) return
        exec.execute { speak(Reply((if (lastHindi) "याद दिलाना: " else "Reminder: ") + text), lastHindi) }
    }

    private fun levelUi(rms: Float) {
        val l = (rms * 7f).coerceAtMost(1f)
        main.post { for (p in panels) p.level(l) }
    }

    // ------------------------------------------------------------------ UI
    private fun buildNotification(@Suppress("UNUSED_PARAMETER") text: String): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "assistant_quiet")
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Chanit Assistant")
            .setContentText("On")
            .setContentIntent(open)
            .setOngoing(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_SECRET)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    /** the notification stays as quiet as Android allows, so it is no longer updated with every step */
    private fun setStatus(@Suppress("UNUSED_PARAMETER") text: String) {}

    /** state: 0 idle, 1 listening, 2 thinking, 3 speaking */
    private fun ui(state: Int, text: String?) {
        uiState = state
        main.post {
            if (state != 0 && overlayPanel == null && panels.isEmpty()) addOverlay()
            for (p in panels) p.update(state, text)
            if (state == 0) main.postDelayed({ if (uiState == 0) removeOverlay(true) }, 600)
        }
    }

    private fun addOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val p = OrbPanel(this)
            val d = resources.displayMetrics.density
            val prefs = Store.prefs(this)
            val wm = getSystemService(WindowManager::class.java)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            // top of the screen, just under the status bar (like Siri); drag it and it remembers the place
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            val sbId = resources.getIdentifier("status_bar_height", "dimen", "android")
            val sb = if (sbId > 0) resources.getDimensionPixelSize(sbId) else (24 * d).toInt()
            lp.x = prefs.getInt("pill_x", 0)
            lp.y = prefs.getInt("pill_y", sb + (6 * d).toInt())
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            p.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dm = resources.displayMetrics
                        lp.x = (ox + (e.rawX - sx).toInt()).coerceIn(-dm.widthPixels / 2, dm.widthPixels / 2)
                        lp.y = (oy + (e.rawY - sy).toInt()).coerceIn(0, (dm.heightPixels - v.height).coerceAtLeast(0))
                        try { wm.updateViewLayout(v, lp) } catch (_: Throwable) {}
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        prefs.edit().putInt("pill_x", lp.x).putInt("pill_y", lp.y).apply()
                        true
                    }
                    else -> false
                }
            }
            wm.addView(p, lp)
            overlayPanel = p
            panels.add(p)
        } catch (_: Throwable) {}
    }

    private fun removeOverlay(animated: Boolean) {
        val p = overlayPanel ?: return
        overlayPanel = null
        panels.remove(p)
        p.dismiss(animated) {
            try { getSystemService(WindowManager::class.java).removeView(p) } catch (_: Throwable) {}
        }
    }
}
