package com.djsound.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * Finds the Bluetooth dongle by name, removes the stale "saved" entry,
 * pairs again and asks the phone to connect audio (A2DP).
 */
@SuppressLint("MissingPermission")
class BtFixer(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("dj", Context.MODE_PRIVATE)
    private val adapter: BluetoothAdapter? = try {
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    } catch (e: Throwable) {
        null
    }
    private val h = Handler(Looper.getMainLooper())

    var log: ((String) -> Unit)? = null
    var onDevice: ((String, String, Boolean) -> Unit)? = null

    private var autoOn = false
    private var wantFix = false
    private var bondingAddr: String? = null
    private var lastFix = 0L
    private var foundCount = 0

    private fun say(s: String) {
        log?.invoke(s)
    }

    private fun target(): String = prefs.getString("btName", "") ?: ""

    private fun matches(n: String): Boolean {
        val t = target().trim()
        return t.isNotEmpty() && n.contains(t, ignoreCase = true)
    }

    fun hasPerms(): Boolean {
        val list = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        for (p in list) {
            if (ctx.checkPermission(p, android.os.Process.myPid(), android.os.Process.myUid()) != PackageManager.PERMISSION_GRANTED) return false
        }
        return true
    }

    @Suppress("DEPRECATION")
    private fun dev(i: Intent): BluetoothDevice? {
        return if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
        }
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i == null) return
            try {
                when (i.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val d = dev(i) ?: return
                        val n = d.name ?: return
                        foundCount++
                        onDevice?.invoke(n, d.address, d.bondState == BluetoothDevice.BOND_BONDED)
                        if (wantFix && matches(n)) {
                            wantFix = false
                            try { adapter?.cancelDiscovery() } catch (e: Throwable) {}
                            say("Dongle mil gaya: $n")
                            repair(d)
                        }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        if (wantFix) {
                            wantFix = false
                            say("'${target()}' nahi mila. Dongle ON hai na? Phone ke paas rakho.")
                        } else {
                            say("Scan khatam.")
                        }
                        if (foundCount == 0) say("Kuch nahi mila? Android 11 ya purane phone me Location (GPS) ON rakho.")
                    }
                    BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                        val d = dev(i) ?: return
                        val st = i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR)
                        if (d.address == bondingAddr) {
                            if (st == BluetoothDevice.BOND_BONDED) {
                                bondingAddr = null
                                say("Pair ho gaya. Connect kar raha hu...")
                                h.postDelayed({ connect(d) }, 1500)
                            } else if (st == BluetoothDevice.BOND_NONE) {
                                bondingAddr = null
                                say("Pairing fail ya cancel hui. Dongle off-on karke phir Fix dabao. PIN maange to 0000.")
                            }
                        }
                    }
                }
            } catch (e: Throwable) {
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!autoOn) return
            try {
                val a = adapter
                if (a != null && a.isEnabled && hasPerms() && target().isNotBlank() &&
                    bondingAddr == null && !a.isDiscovering &&
                    a.getProfileConnectionState(BluetoothProfile.A2DP) != BluetoothProfile.STATE_CONNECTED &&
                    SystemClock.elapsedRealtime() - lastFix > 60000
                ) {
                    say("Auto: dongle dhoondh raha hu...")
                    scan(true)
                }
            } catch (e: Throwable) {
            }
            h.postDelayed(this, 20000)
        }
    }

    init {
        val f = IntentFilter()
        f.addAction(BluetoothDevice.ACTION_FOUND)
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        try { ctx.registerReceiver(rx, f) } catch (e: Throwable) {}
    }

    fun scan(fix: Boolean) {
        val a = adapter
        if (a == null) { say("Is phone me Bluetooth nahi mila."); return }
        if (!a.isEnabled) { say("Pehle Bluetooth ON karo."); return }
        if (!hasPerms()) { say("Permission allow karo, phir dobara dabao."); return }
        try {
            foundCount = 0
            wantFix = fix
            if (a.isDiscovering) a.cancelDiscovery()
            for (b in a.bondedDevices) onDevice?.invoke(b.name ?: b.address, b.address, true)
            if (a.startDiscovery()) say("Scan chalu... (dongle ko ON rakho)") else say("Scan start nahi hua.")
        } catch (e: Throwable) {
            say("Scan error: ${e.message}")
        }
    }

    fun fixNow() {
        if (target().isBlank()) { say("Pehle dongle ka naam likho ya Scan se chuno."); return }
        say("Fix shuru: '${target()}' dhoondh raha hu...")
        scan(true)
    }

    fun pickAndFix(name: String, addr: String) {
        prefs.edit().putString("btName", name).apply()
        val a = adapter ?: return
        try {
            if (a.isDiscovering) a.cancelDiscovery()
            repair(a.getRemoteDevice(addr))
        } catch (e: Throwable) {
            say("Error: ${e.message}")
        }
    }

    private fun removeBond(d: BluetoothDevice): Boolean {
        return try {
            val m = d.javaClass.getMethod("removeBond")
            (m.invoke(d) as? Boolean) ?: false
        } catch (e: Throwable) {
            false
        }
    }

    private fun repair(d: BluetoothDevice) {
        lastFix = SystemClock.elapsedRealtime()
        var wait = 0L
        try {
            val n = d.name ?: ""
            val bonded = adapter?.bondedDevices
            if (bonded != null) {
                for (b in bonded) {
                    val bn = b.name ?: ""
                    if (b.address == d.address || (n.isNotEmpty() && bn == n)) {
                        if (removeBond(b)) {
                            say("Purani saved entry hata di: $bn")
                            wait = 2500L
                        } else {
                            say("Purani entry khud hatao: Phone Settings > Bluetooth > '$bn' > Forget")
                        }
                    }
                }
            }
        } catch (e: Throwable) {
        }
        h.postDelayed({ doBond(d) }, wait)
    }

    private fun doBond(d: BluetoothDevice) {
        try {
            if (d.bondState == BluetoothDevice.BOND_BONDED) {
                say("Pehle se saved hai, seedha connect kar raha hu...")
                connect(d)
                return
            }
            bondingAddr = d.address
            say("Pair ho raha hu... (popup aaye to Pair dabao)")
            h.postDelayed({ if (bondingAddr == d.address) bondingAddr = null }, 30000)
            if (!d.createBond()) {
                bondingAddr = null
                say("Pairing shuru nahi hui.")
            }
        } catch (e: Throwable) {
            say("Error: ${e.message}")
        }
    }

    fun connect(d: BluetoothDevice) {
        val a = adapter ?: return
        try {
            a.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
                    try {
                        val m = proxy!!.javaClass.getMethod("connect", BluetoothDevice::class.java)
                        m.invoke(proxy, d)
                        say("Connect command bheja.")
                    } catch (e: Throwable) {
                        say("Phone auto-connect allow nahi karta. Phone ki Bluetooth list me '${d.name}' par tap karo.")
                    }
                    h.postDelayed({
                        try {
                            val ok = a.getProfileConnectionState(BluetoothProfile.A2DP) == BluetoothProfile.STATE_CONNECTED
                            say(if (ok) "Connected. Ab music chalao." else "Abhi connected nahi dikh raha. Bluetooth list se tap karke dekho.")
                            a.closeProfileProxy(profile, proxy)
                        } catch (e: Throwable) {
                        }
                    }, 6000)
                }

                override fun onServiceDisconnected(profile: Int) {}
            }, BluetoothProfile.A2DP)
        } catch (e: Throwable) {
        }
    }

    fun startAuto() {
        if (autoOn) return
        autoOn = true
        h.post(tick)
    }

    fun stopAuto() {
        autoOn = false
        h.removeCallbacks(tick)
    }

    fun release() {
        stopAuto()
        try { ctx.unregisterReceiver(rx) } catch (e: Throwable) {}
    }
}
