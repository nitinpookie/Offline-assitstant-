package com.djsound.app

import android.content.SharedPreferences
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer

/** Sound effects chain: 5-band EQ, bass boost, surround, hall reverb, loudness. */
class Fx(private val prefs: SharedPreferences) {
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loud: LoudnessEnhancer? = null
    private var rev: PresetReverb? = null
    var sessionId = -1

    private fun <T : AudioEffect> mk(f: () -> T): T? {
        return try {
            val e = f()
            e.setEnabled(true)
            e
        } catch (t: Throwable) {
            null
        }
    }

    fun build(session: Int, global: Boolean) {
        release()
        sessionId = session
        eq = mk { Equalizer(0, session) }
        bass = mk { BassBoost(0, session) }
        virt = mk { Virtualizer(0, session) }
        loud = mk { LoudnessEnhancer(session) }
        rev = if (global) null else mk { PresetReverb(0, 0) }
        refresh()
    }

    fun refresh() {
        val e = eq
        if (e != null) {
            try {
                val range = e.bandLevelRange
                val lo = range[0].toInt()
                val hi = range[1].toInt()
                val n = e.numberOfBands.toInt()
                for (b in 0 until n) {
                    val pos = if (n <= 1) 0f else b * 4f / (n - 1)
                    val i = Math.min(pos.toInt(), 3)
                    val frac = pos - i
                    val p = prefs.getInt("eq$i", 50) * (1f - frac) + prefs.getInt("eq${i + 1}", 50) * frac
                    val v = (p - 50f) / 50f
                    val lvl = if (v >= 0f) v * hi else -v * lo
                    e.setBandLevel(b.toShort(), lvl.toInt().toShort())
                }
            } catch (t: Throwable) {
            }
        }
        try { bass?.setStrength(prefs.getInt("bass", 0).toShort()) } catch (t: Throwable) {}
        try { virt?.setStrength(prefs.getInt("virt", 0).toShort()) } catch (t: Throwable) {}
        try { loud?.setTargetGain(prefs.getInt("loud", 0)) } catch (t: Throwable) {}
        try { rev?.setPreset(prefs.getInt("revPreset", 0).toShort()) } catch (t: Throwable) {}
    }

    fun reverbId(): Int {
        return try { rev?.id ?: -1 } catch (t: Throwable) { -1 }
    }

    fun release() {
        val all: List<AudioEffect?> = listOf(eq, bass, virt, loud, rev)
        for (x in all) {
            try { x?.release() } catch (t: Throwable) {}
        }
        eq = null; bass = null; virt = null; loud = null; rev = null
        sessionId = -1
    }
}
