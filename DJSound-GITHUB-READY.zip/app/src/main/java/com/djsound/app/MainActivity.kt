package com.djsound.app

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class Preset(
    val name: String, val eq: IntArray, val bass: Int, val virt: Int,
    val rev: Int, val send: Int, val loud: Int
)

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private var svc: SoundService? = null
    private var bound = false

    private val bars = HashMap<String, SeekBar>()
    private val seen = HashSet<String>()
    private lateinit var pages: List<View>
    private lateinit var tvNow: TextView
    private lateinit var tvLog: TextView
    private lateinit var devBox: LinearLayout
    private lateinit var etName: EditText
    private lateinit var spRev: Spinner

    private val presets = listOf(
        Preset("Concert Hall", intArrayOf(68, 55, 48, 62, 70), 500, 800, 5, 60, 500),
        Preset("DJ Club", intArrayOf(85, 65, 45, 58, 68), 800, 600, 2, 30, 800),
        Preset("Deep Bass", intArrayOf(92, 72, 50, 50, 55), 1000, 300, 0, 0, 800),
        Preset("Clear Vocal", intArrayOf(40, 50, 68, 72, 60), 200, 400, 1, 25, 400),
        Preset("Flat", intArrayOf(50, 50, 50, 50, 50), 0, 0, 0, 0, 0)
    )

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            val s = (b as SoundService.LocalBinder).get()
            svc = s
            s.onState = { runOnUiThread { refreshNow() } }
            s.bt.log = { m -> addLog(m) }
            s.bt.onDevice = { name, addr, saved -> runOnUiThread { addDevice(name, addr, saved) } }
            s.reloadFx()
            refreshNow()
        }

        override fun onServiceDisconnected(n: ComponentName?) {
            svc = null
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("dj", MODE_PRIVATE)
        if (!prefs.getBoolean("init", false)) {
            writePreset(presets[0])
            prefs.edit().putBoolean("init", true).apply()
        }
        buildUi()
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val si = Intent(this, SoundService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(si) else startService(si)
        bound = bindService(si, conn, BIND_AUTO_CREATE)
    }

    override fun onDestroy() {
        svc?.let {
            it.onState = null
            it.bt.log = null
            it.bt.onDevice = null
        }
        if (bound) {
            try { unbindService(conn) } catch (e: Throwable) {}
            bound = false
        }
        super.onDestroy()
    }

    // ---------- small UI helpers ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(s: String, size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(Color.WHITE)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    private fun btn(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setAllCaps(false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(vararg v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        for (x in v) l.addView(x, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return l
    }

    private fun page(build: (LinearLayout) -> Unit): ScrollView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(4), dp(14), dp(14))
        build(col)
        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    private fun show(i: Int) {
        for (k in pages.indices) pages[k].visibility = if (k == i) View.VISIBLE else View.GONE
    }

    private fun slider(parent: LinearLayout, key: String, label: String, max: Int, fmt: (Int) -> String) {
        val t = tv("", 14f, false)
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = prefs.getInt(key, 0)
        t.text = label + ": " + fmt(sb.progress)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                t.text = label + ": " + fmt(p)
                if (fromUser) {
                    prefs.edit().putInt(key, p).apply()
                    svc?.reloadFx()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(t)
        parent.addView(sb)
        bars[key] = sb
    }

    private fun addLog(m: String) {
        runOnUiThread { tvLog.append(m + "\n") }
    }

    private fun refreshNow() {
        tvNow.text = svc?.nowText() ?: "..."
    }

    // ---------- UI ----------

    private fun buildUi() {
        val rootL = LinearLayout(this)
        rootL.orientation = LinearLayout.VERTICAL
        rootL.setBackgroundColor(Color.parseColor("#0B0B14"))

        val title = tv("DJ Sound", 22f, true)
        title.setPadding(dp(14), dp(14), dp(14), dp(4))
        rootL.addView(title)

        pages = listOf(
            page { c -> buildSound(c) },
            page { c -> buildBt(c) },
            page { c -> buildFix(c) }
        )
        val frame = FrameLayout(this)
        for (p in pages) frame.addView(p)
        rootL.addView(frame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val labels = arrayOf("Sound", "Bluetooth", "Crackle fix")
        for (k in 0..2) {
            bar.addView(btn(labels[k]) { show(k) }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        rootL.addView(bar)
        setContentView(rootL)
        show(0)
    }

    private fun buildSound(c: LinearLayout) {
        tvNow = tv("Koi song nahi. 'Songs chuno' dabao.", 15f, true)
        c.addView(tvNow)
        c.addView(row(
            btn("Songs chuno") { pick() },
            btn("<<") { svc?.prev() },
            btn("Play/Pause") { svc?.toggle() },
            btn(">>") { svc?.next() }
        ))

        c.addView(tv("Preset (ek tap me sound set):", 13f, false))
        val hs = HorizontalScrollView(this)
        val pr = LinearLayout(this)
        pr.orientation = LinearLayout.HORIZONTAL
        for (p in presets) pr.addView(btn(p.name) { applyPreset(p) })
        hs.addView(pr)
        c.addView(hs)

        val eqNames = arrayOf("Deep Bass", "Bass", "Mid", "Vocal", "Treble")
        for (i in 0..4) slider(c, "eq$i", eqNames[i], 100) { "${(it - 50) * 2}%" }
        slider(c, "bass", "Bass Boost", 1000) { "${it / 10}%" }
        slider(c, "virt", "Surround / Wide sound", 1000) { "${it / 10}%" }

        c.addView(tv("Reverb (hall ka echo)", 14f, false))
        spRev = Spinner(this)
        spRev.adapter = ArrayAdapter<String>(
            this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Reverb OFF", "Chhota kamra", "Medium kamra", "Bada kamra", "Medium hall", "Bada hall (concert)", "Plate")
        )
        spRev.setSelection(prefs.getInt("revPreset", 0))
        spRev.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("revPreset", pos).apply()
                svc?.reloadFx()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        c.addView(spRev)
        slider(c, "revSend", "Reverb amount", 100) { "$it%" }
        slider(c, "loud", "Loudness (volume boost)", 1500) { "+${it / 100} dB" }

        val sw = Switch(this)
        sw.text = "Saari apps ke liye (experimental)"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = prefs.getBoolean("global", false)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("global", on).apply()
            svc?.reloadFx()
        }
        c.addView(sw)
        c.addView(tv(
            "Effects sirf is app ke player me pakke chalte hain. 'Saari apps' mode YouTube/Spotify par bhi try karta hai, " +
                "par kai phones me kaam nahi karta (reverb us mode me nahi hota). " +
                "Awaaz phatne ya distort hone lage to Bass Boost aur Loudness kam karo.", 12f, false
        ))
    }

    private fun buildBt(c: LinearLayout) {
        c.addView(tv(
            "Dongle har baar naya device kyu dikhta hai?\n" +
                "Sasta dongle apni pairing yaad nahi rakhta (khaas kar jab amp ke saath uski power OFF hoti hai). " +
                "Phone me purani entry rehti hai, par dongle use bhool chuka hota hai, isliye wo 'naya device' ban jata hai.\n\n" +
                "Ye app kya karta hai: dongle ko naam se dhoondhta hai, purani saved entry hata kar naye sire se pair karta hai " +
                "aur connect ka command bhejta hai.\n\n" +
                "Pakka fix: dongle ko alag always-ON 5V USB charger se power do (amp ke saath OFF na ho).", 13f, false
        ))
        etName = EditText(this)
        etName.hint = "Dongle ka naam (Scan se chuno)"
        etName.setTextColor(Color.WHITE)
        etName.setHintTextColor(Color.GRAY)
        etName.setText(prefs.getString("btName", ""))
        c.addView(etName)

        c.addView(row(
            btn("Scan") {
                if (!needBtPerms()) {
                    devBox.removeAllViews()
                    seen.clear()
                    svc?.let { it.bt.scan(false) }
                }
            },
            btn("Fix & Connect") {
                if (!needBtPerms()) {
                    prefs.edit().putString("btName", etName.text.toString().trim()).apply()
                    svc?.let { it.bt.fixNow() }
                }
            }
        ))

        val sw = Switch(this)
        sw.text = "Auto reconnect (background me)"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = prefs.getBoolean("autoBt", false)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("autoBt", on).putString("btName", etName.text.toString().trim()).apply()
            if (on) {
                needBtPerms()
                svc?.let { it.bt.startAuto() }
            } else {
                svc?.let { it.bt.stopAuto() }
            }
        }
        c.addView(sw)
        c.addView(btn("Phone ki Bluetooth settings") {
            try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (e: Throwable) {}
        })

        c.addView(tv("Mile hue devices (tap = ye mera dongle hai, fix karo):", 13f, false))
        devBox = LinearLayout(this)
        devBox.orientation = LinearLayout.VERTICAL
        c.addView(devBox)

        c.addView(tv("Log:", 13f, true))
        tvLog = tv("", 12f, false)
        c.addView(tvLog)
    }

    private fun buildFix(c: LinearLayout) {
        val sw = Switch(this)
        sw.text = "Silent keep-alive / Noise test"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = prefs.getBoolean("keepAlive", false)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("keepAlive", on).apply()
            svc?.let { if (on) it.startSilence() else it.stopSilence() }
        }
        c.addView(sw)
        c.addView(tv(
            "Isko ON karke koi music mat chalao. Agar tab bhi kachar-kachar / hiss aa rahi hai, to noise phone ya app se nahi, " +
                "dongle, cable ya power se aa raha hai. Ye switch phone se dongle tak stream ko jaga bhi rakhta hai, " +
                "jisse shuru/band hote waqt ke pop aur click kam ho sakte hain.", 13f, false
        ))
        c.addView(tv("Kachar-kachar ke asli fix (hardware):", 15f, true))
        c.addView(tv(
            "1. Dongle ko amp ke USB se ya sasti charger se power mat do. Alag achhe 5V mobile charger ya power bank se do.\n\n" +
                "2. Phone ka Bluetooth media volume 80-100% rakho aur amp ka volume kam. Phone ka volume kam hoga to dongle ka hiss zyada sunai deta hai.\n\n" +
                "3. 3.5mm jack poora andar tak lagao. Cable achha, shielded aur chhota ho. Usse power wire aur amp ke transformer se door rakho.\n\n" +
                "4. Charging ke saath hum / crackle badhe to phone ka charger hatake dekho (ground loop). Aise me ground-loop isolator lagana sabse pakka hai.\n\n" +
                "5. Dongle amp ke metal ke peeche ya heat-sink ke paas na ho. USB extension se bahar kholi jagah par rakho, phone se 3-5 meter ke andar.\n\n" +
                "6. Router, microwave aur doosre Bluetooth se door rakho.\n\n" +
                "7. Agar sab karke bhi hiss/crackle rahe, dongle hi kharab ya sasta hai. Naya Bluetooth receiver (jo pairing yaad rakhe) lena sabse accha hai.", 13f, false
        ))
        c.addView(btn("App / service band karo") {
            if (bound) {
                try { unbindService(conn) } catch (e: Throwable) {}
                bound = false
            }
            svc = null
            stopService(Intent(this, SoundService::class.java))
            finish()
        })
    }

    // ---------- actions ----------

    private fun writePreset(p: Preset) {
        val e = prefs.edit()
        for (i in 0..4) e.putInt("eq$i", p.eq[i])
        e.putInt("bass", p.bass).putInt("virt", p.virt)
        e.putInt("revPreset", p.rev).putInt("revSend", p.send).putInt("loud", p.loud)
        e.apply()
    }

    private fun applyPreset(p: Preset) {
        writePreset(p)
        for (i in 0..4) bars["eq$i"]?.progress = p.eq[i]
        bars["bass"]?.progress = p.bass
        bars["virt"]?.progress = p.virt
        bars["revSend"]?.progress = p.send
        bars["loud"]?.progress = p.loud
        spRev.setSelection(p.rev)
        svc?.reloadFx()
    }

    private fun needBtPerms(): Boolean {
        val list = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val miss = ArrayList<String>()
        for (p in list) {
            if (checkPermission(p, android.os.Process.myPid(), android.os.Process.myUid()) != PackageManager.PERMISSION_GRANTED) miss.add(p)
        }
        if (miss.isNotEmpty() && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(miss.toTypedArray(), 2)
            addLog("Permission allow karo, phir button dobara dabao.")
            return true
        }
        return false
    }

    private fun addDevice(name: String, addr: String, saved: Boolean) {
        if (!seen.add(addr)) return
        val label = name + (if (saved) "  [saved]" else "") + "\n" + addr
        devBox.addView(btn(label) {
            etName.setText(name)
            prefs.edit().putString("btName", name).apply()
            svc?.let { it.bt.pickAndFix(name, addr) }
        })
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 11)
    }

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
                if (cur.moveToFirst()) return cur.getString(0)
            }
        } catch (e: Throwable) {
        }
        return u.lastPathSegment ?: "track"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 11 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val cd = data.clipData
        if (cd != null) {
            for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
        } else {
            val d = data.data
            if (d != null) uris.add(d)
        }
        val nm = ArrayList<String>()
        for (u in uris) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Throwable) {}
            nm.add(nameOf(u))
        }
        svc?.setQueue(uris, nm)
    }
}
