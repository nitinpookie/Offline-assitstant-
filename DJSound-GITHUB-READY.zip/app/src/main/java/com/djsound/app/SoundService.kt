package com.djsound.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

@SuppressLint("MissingPermission")
class SoundService : Service() {
    inner class LocalBinder : Binder() {
        fun get(): SoundService = this@SoundService
    }

    private val binder = LocalBinder()
    override fun onBind(intent: Intent?): IBinder = binder

    lateinit var prefs: SharedPreferences
    lateinit var fx: Fx
    lateinit var bt: BtFixer

    var onState: (() -> Unit)? = null

    private var mp: MediaPlayer? = null
    private val queue = ArrayList<Uri>()
    private val names = ArrayList<String>()
    private var index = -1
    private var errors = 0

    @Volatile private var silentRun = false

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("dj", MODE_PRIVATE)
        fx = Fx(prefs)
        bt = BtFixer(this)
        goForeground()
        if (prefs.getBoolean("global", false)) fx.build(0, true)
        if (prefs.getBoolean("keepAlive", false)) startSilence()
        if (prefs.getBoolean("autoBt", false)) bt.startAuto()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun goForeground() {
        try {
            val ch = "dj_sound"
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(NotificationChannel(ch, "DJ Sound", NotificationManager.IMPORTANCE_LOW))
            }
            val pi = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)
            val n = b.setContentTitle("DJ Sound chal raha hai")
                .setContentText("Tap karke app kholo")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
            startForeground(1, n)
        } catch (e: Throwable) {
        }
    }

    // ---------- playback ----------

    fun setQueue(u: List<Uri>, n: List<String>) {
        queue.clear(); queue.addAll(u)
        names.clear(); names.addAll(n)
        errors = 0
        if (queue.isNotEmpty()) playAt(0)
    }

    fun playAt(i: Int) {
        if (queue.isEmpty()) return
        index = ((i % queue.size) + queue.size) % queue.size
        releasePlayer()
        val p = MediaPlayer()
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(this, queue[index])
            p.setOnCompletionListener { playAt(index + 1) }
            p.setOnErrorListener(MediaPlayer.OnErrorListener { _, _, _ ->
                errors++
                if (errors <= queue.size) playAt(index + 1)
                true
            })
            p.prepare()
            mp = p
            if (!prefs.getBoolean("global", false)) fx.build(p.audioSessionId, false)
            attachReverb()
            p.start()
            errors = 0
        } catch (e: Throwable) {
            try { p.release() } catch (t: Throwable) {}
            mp = null
            errors++
            if (errors <= queue.size) playAt(index + 1)
        }
        onState?.invoke()
    }

    private fun attachReverb() {
        val p = mp ?: return
        try {
            val id = fx.reverbId()
            if (id != -1 && prefs.getInt("revPreset", 0) != 0) {
                p.attachAuxEffect(id)
                p.setAuxEffectSendLevel(prefs.getInt("revSend", 50) / 100f)
            } else {
                p.setAuxEffectSendLevel(0f)
            }
        } catch (e: Throwable) {
        }
    }

    fun reloadFx() {
        val global = prefs.getBoolean("global", false)
        val p = mp
        if (global && fx.sessionId != 0) {
            fx.build(0, true)
        } else if (!global && fx.sessionId == 0) {
            if (p != null) fx.build(p.audioSessionId, false) else fx.release()
        }
        fx.refresh()
        attachReverb()
    }

    fun toggle() {
        val p = mp
        if (p == null) {
            if (queue.isNotEmpty()) playAt(if (index < 0) 0 else index)
            return
        }
        try { if (p.isPlaying) p.pause() else p.start() } catch (e: Throwable) {}
        onState?.invoke()
    }

    fun next() { playAt(index + 1) }
    fun prev() { playAt(index - 1) }

    fun nowText(): String {
        if (index < 0 || index >= names.size) return "Koi song nahi. 'Songs chuno' dabao."
        val playing = try { mp?.isPlaying == true } catch (e: Throwable) { false }
        return (if (playing) "Play: " else "Pause: ") + names[index]
    }

    private fun releasePlayer() {
        val p = mp
        mp = null
        if (p != null) {
            try { p.reset() } catch (e: Throwable) {}
            try { p.release() } catch (e: Throwable) {}
        }
    }

    // ---------- silent keep-alive (also works as a noise test) ----------

    fun startSilence() {
        if (silentRun) return
        silentRun = true
        Thread {
            var t: AudioTrack? = null
            try {
                val rate = 44100
                val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                t = AudioTrack(
                    AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 4096) * 2, AudioTrack.MODE_STREAM
                )
                t.play()
                val buf = ShortArray(4096)
                while (silentRun) t.write(buf, 0, buf.size)
            } catch (e: Throwable) {
            } finally {
                try { t?.stop() } catch (e: Throwable) {}
                try { t?.release() } catch (e: Throwable) {}
            }
        }.start()
    }

    fun stopSilence() {
        silentRun = false
    }

    override fun onDestroy() {
        silentRun = false
        onState = null
        releasePlayer()
        fx.release()
        bt.release()
        super.onDestroy()
    }
}
