# DJ Sound

Sound presets (EQ, bass, surround, reverb, loudness), Bluetooth dongle fix and crackle test.

Is zip ko repo ke root mein upload karo. `.github/workflows/build.yml` wahi hai jo baaki projects mein hai.
Actions > Build > Artifacts se APK milegi (naam `iLauncher-debug.apk` aayega, andar DJ Sound hai).
