package com.liveedit.agent;

import android.app.Application;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;

/**
 * Tells the Live Editor app that this (recently patched) app is on screen, so Live Editor can show its pencil as an
 * overlay above it. Runs on its own thread; a missing Live Editor, a refusal or a slow answer never touches the app.
 * While Live Editor shows the pencil ({@link #hostShown}) this app's own pencil stays up as well (two pencils, both open the
 * same full menu); {@link #hostShown} is only used to keep the window previews fresh.
 */
final class HostLink {

    private static final String HOST = "content://com.liveedit.patcher.host";

    /** True while the Live Editor app is showing its pencil over this app. */
    static volatile boolean hostShown;
    /** Last time (uptime ms) Live Editor said its pencil is on screen over this app. */
    static volatile long lastShownAt;
    /** Live Editor says the pencil switch is OFF: this app shows no pencil either. */
    static volatile boolean hostOff;
    /** Since when an app screen is on screen (uptime ms), 0 when none or unknown. */
    static volatile long fgSince;

    /**
     * ONE pencil: the Live Editor pencil. This app's own pencil is only a safety net: it is needed only when Live Editor's pencil
     * has not been confirmed on screen for a while (Live Editor not installed, its Accessibility service off or killed).
     * panelStart = uptime when this app's pencil code started (used when the screen state is unknown).
     */
    static boolean ownPencilNeeded(long panelStart) {
        if (hostOff) return false;
        long now = SystemClock.uptimeMillis();
        if (now - lastShownAt < 8000L) return false;
        long since = fgSince != 0L ? fgSince : panelStart;
        return now - since > 6000L;
    }

    private static volatile boolean busy;
    private static long lastBeat;
    private static boolean wasFg;
    private static int fails;
    private static long pausedUntil;

    private HostLink() {}

    /** Called from the 0.7 s tick of the engine. fg = an app screen is on screen right now. */
    static void tick(final Application app, boolean fg) {
        long now = SystemClock.uptimeMillis();
        if (fg) {
            if (fgSince == 0L) fgSince = now;
        } else {
            fgSince = 0L;
        }
        // while Live Editor shows its pencil, keep a small picture of every window and screen for the previews
        if (fg && hostShown) {
            try {
                Overlays.cacheThumbs(app);
            } catch (Throwable t) {
                // previews are a bonus
            }
        }
        if (busy || now < pausedUntil) return;
        final String method;
        if (fg) {
            if (now - lastBeat < 1500L) return;
            method = "fg";
        } else if (wasFg) {
            method = "bg";
        } else {
            return;
        }
        lastBeat = now;
        wasFg = fg;
        busy = true;
        final String pkg = app.getPackageName();
        // how many floating windows the app has: when it grows, the pencil of Live Editor puts itself on top again
        final Bundle extras = new Bundle();
        try {
            extras.putInt("n", fg ? Overlays.overlayCount() : 0);
        } catch (Throwable t) {
            // the count is a bonus
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Bundle b = app.getContentResolver().call(Uri.parse(HOST), method, pkg, extras);
                    if (b == null) {
                        hostShown = false;
                        noteFail();
                    } else {
                        fails = 0;
                        hostShown = "fg".equals(method) && b.getBoolean("shown", false);
                        if (hostShown) lastShownAt = SystemClock.uptimeMillis();
                        hostOff = b.getBoolean("off", false);
                    }
                } catch (Throwable t) {
                    hostShown = false;
                    hostOff = false;
                    noteFail();
                } finally {
                    busy = false;
                }
            }
        }, "liveedit-host").start();
    }

    private static void noteFail() {
        if (++fails >= 3) {
            fails = 0;
            pausedUntil = SystemClock.uptimeMillis() + 20000L; // Live Editor is not there: try again in 20 s
        }
    }
}
