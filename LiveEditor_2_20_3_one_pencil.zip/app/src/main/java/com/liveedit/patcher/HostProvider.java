package com.liveedit.patcher;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

/**
 * A patched app tells Live Editor "I am on screen" ("fg") or "I left" ("bg"). The answer says whether the one Live Editor
 * pencil (Accessibility) is on screen over it, and whether the pencil switch is OFF. Only that app itself can ask.
 */
public final class HostProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        Bundle out = new Bundle();
        out.putBoolean("shown", false);
        out.putBoolean("off", false);
        try {
            Context c = getContext();
            if (c == null || arg == null) return out;
            Context app = c.getApplicationContext();
            String caller = getCallingPackage();
            if (!arg.equals(caller)) return out;
            if (!PencilPrefs.isOn(app)) {
                // the pencil switch is OFF: no pencil of any kind, not even the one inside the app
                out.putBoolean("off", true);
                PencilHost.leave(arg);
                return out;
            }
            if (!PencilPrefs.hasEngine(app, arg)) {
                PencilHost.leave(arg); // not a Live Editor app: nothing to show
                return out;
            }
            // Live Editor was woken up by a patched app: try to bring the always-on pencil service up again
            PencilService.ensure(app);
            if ("fg".equals(method)) {
                // ONE pencil: the Live Editor (Accessibility) pencil. No second overlay pencil is drawn here any more. The answer
                // tells the app whether that pencil really is on screen over it; if it is not (service off, blocked), the app
                // shows its own pencil after a few seconds so it is never left without one.
                out.putBoolean("shown", AccessPencil.shownFor(arg));
            } else if ("bg".equals(method)) {
                PencilHost.leave(arg);
            }
        } catch (Throwable t) {
            // never let a bad call hurt this app
        }
        return out;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] args) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] args) {
        return 0;
    }
}
