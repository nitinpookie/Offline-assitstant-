package com.liveedit.patcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

/**
 * The always-on service of the pencil. While the pencil switch is ON, this foreground service keeps the Live Editor process
 * alive (with one quiet notification), so a patched app finds Live Editor ready the moment it asks for the pencil, instead
 * of waiting for a cold start that some phones (battery saver, auto-start limits) delay or block.
 *
 * It starts when Live Editor opens (and again every time Live Editor comes to the front), and stops when the pencil is
 * switched OFF (the switch in Live Editor, "Pencil OFF" in the pencil panel, or the button in the notification).
 * Android 14: it is a foreground service of type "specialUse" and needs the notification permission to show its card.
 */
public final class PencilService extends Service {

    static final String CHANNEL = "pencil_ready";
    static final String ACT_OFF = "com.liveedit.patcher.PENCIL_OFF";
    private static final int ID = 2021;

    private static volatile boolean running;
    private static long lastTry;

    /** True while the service is alive in this process. */
    static boolean isRunning() {
        return running;
    }

    /**
     * Starts (or refreshes) the service. Call it from Live Editor's own screen. Does nothing when the pencil is OFF.
     * Never throws: a phone that refuses a foreground service must not hurt Live Editor.
     */
    static void start(Context c) {
        try {
            Context app = c.getApplicationContext();
            if (!PencilPrefs.isOn(app)) return;
            lastTry = SystemClock.uptimeMillis();
            Intent i = new Intent(app, PencilService.class);
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i);
            else app.startService(i);
        } catch (Throwable t) {
            // not allowed right now (for example Live Editor is in the background): the next time Live Editor opens it starts
        }
    }

    /**
     * For the content provider (a patched app asked for the pencil and Live Editor was started in the background): try to
     * bring the service up again, at most once every 20 s. Android may refuse from the background; then nothing happens.
     */
    static void ensure(Context c) {
        if (running) return;
        if (SystemClock.uptimeMillis() - lastTry < 20000L && lastTry != 0L) return;
        start(c);
    }

    static void stop(Context c) {
        try {
            Context app = c.getApplicationContext();
            app.stopService(new Intent(app, PencilService.class));
        } catch (Throwable t) {
            // already stopped
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Pencil ready", NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Keeps the Live Editor pencil ready on top of your patched apps");
                ch.setShowBadge(false);
                ch.setSound(null, null);
                ch.enableVibration(false);
                nm.createNotificationChannel(ch);
            }
        } catch (Throwable t) {
            // the card is a bonus; the service still runs
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // "Pencil OFF" from the notification: switch the pencil off and go away (not started as a foreground service)
        if (intent != null && ACT_OFF.equals(intent.getAction())) {
            PencilPrefs.setOn(getApplicationContext(), false);
            leave();
            return START_NOT_STICKY;
        }
        // Started with startForegroundService: Android wants startForeground() within 5 s, in every case
        boolean up = goForeground();
        if (!up || !PencilPrefs.isOn(getApplicationContext())) {
            leave();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private boolean goForeground() {
        try {
            Notification n = card();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(ID, n);
            }
            return true;
        } catch (Throwable t) {
            // Android refused a foreground service from here (background start limits)
            return false;
        }
    }

    private void leave() {
        running = false;
        try {
            stopForeground(true);
        } catch (Throwable t) {
            // not in the foreground
        }
        stopSelf();
    }

    private Notification card() {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 1, open, flags);
        Intent off = new Intent(this, PencilService.class).setAction(ACT_OFF);
        PendingIntent offPi = PendingIntent.getService(this, 2, off, flags);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_pencil_notif)
                .setContentTitle("Live Editor pencil is ready")
                .setContentText("Open a patched app and the pencil shows on top. Tap to open Live Editor.")
                .setContentIntent(openPi)
                .setOngoing(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
