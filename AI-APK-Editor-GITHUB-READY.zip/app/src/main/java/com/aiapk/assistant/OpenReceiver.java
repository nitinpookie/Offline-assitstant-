package com.aiapk.assistant;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Opens the app when the user dials *#*#2424#*#* (the app has no launcher icon). */
public class OpenReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent i = new Intent(context, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }
}
