package com.aiapk.assistant;

import android.content.Context;

import com.android.apksig.ApkSigner;

import org.jf.baksmali.Baksmali;
import org.jf.baksmali.BaksmaliOptions;
import org.jf.dexlib2.DexFileFactory;
import org.jf.dexlib2.Opcodes;
import org.jf.dexlib2.iface.DexFile;
import org.jf.smali.Smali;
import org.jf.smali.SmaliOptions;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Decompile dex -> smali, rebuild, repack and sign an APK fully on the phone. */
public class ApkTool {

    static int apiForDex(File dex) throws IOException {
        byte[] h = new byte[8];
        try (InputStream in = new FileInputStream(dex)) {
            if (in.read(h) < 8) return 28;
        }
        String v = new String(h, 4, 3, StandardCharsets.US_ASCII);
        switch (v) {
            case "035": return 19;
            case "037": return 24;
            case "038": return 26;
            default: return 28;
        }
    }

    static String trunc(String s, int n) {
        return s.length() > n ? s.substring(0, n) + "..." : s;
    }

    public static void disassemble(File dexFile, File outDir) throws Exception {
        Tools.deleteRec(outDir);
        outDir.mkdirs();
        int api = apiForDex(dexFile);
        DexFile dex = DexFileFactory.loadDexFile(dexFile, Opcodes.forApi(api));
        BaksmaliOptions opt = new BaksmaliOptions();
        PrintStream oldErr = System.err;
        ByteArrayOutputStream eb = new ByteArrayOutputStream();
        System.setErr(new PrintStream(eb, true));
        try {
            Baksmali.disassembleDexFile(dex, outDir, 2, opt);
        } finally {
            System.setErr(oldErr);
        }
        if (Tools.countFiles(outDir) == 0) {
            throw new IOException("baksmali ne kuch nahi banaya. " + trunc(eb.toString(), 1500));
        }
    }

    static void assemble(File smaliDir, File outDex, int api) throws Exception {
        SmaliOptions so = new SmaliOptions();
        so.apiLevel = api;
        so.outputDexFile = outDex.getAbsolutePath();
        PrintStream oldErr = System.err;
        ByteArrayOutputStream eb = new ByteArrayOutputStream();
        System.setErr(new PrintStream(eb, true));
        boolean ok;
        try {
            ok = Smali.assemble(so, Collections.singletonList(smaliDir.getAbsolutePath()));
        } finally {
            System.setErr(oldErr);
        }
        if (!ok || !outDex.exists()) {
            throw new IOException("smali errors (fix karke dobara apk_build karo):\n" + trunc(eb.toString(), 3500));
        }
    }

    static int dexIndex(String name) {
        String n = name.replace("classes", "").replace(".dex", "");
        if (n.isEmpty()) return 1;
        try {
            return Integer.parseInt(n);
        } catch (NumberFormatException e) {
            return 999;
        }
    }

    static boolean isSignatureFile(String n) {
        if (!n.startsWith("META-INF/")) return false;
        String u = n.toUpperCase();
        return u.equals("META-INF/MANIFEST.MF") || u.endsWith(".SF") || u.endsWith(".RSA")
                || u.endsWith(".DSA") || u.endsWith(".EC");
    }

    static void collect(File base, File dir, List<ZipWriter.Ent> out, Set<String> stored) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        Arrays.sort(fs);
        for (File f : fs) {
            if (f.isDirectory()) {
                collect(base, f, out, stored);
            } else {
                String n = base.toPath().relativize(f.toPath()).toString().replace(File.separatorChar, '/');
                if (isSignatureFile(n)) continue;
                out.add(new ZipWriter.Ent(n, f, stored.contains(n) || n.equals("resources.arsc")));
            }
        }
    }

    public static File build(Context ctx, File root, File outDir, File tmp, StringBuilder log) throws Exception {
        File orig = new File(root, ".orig");
        File[] dexes = orig.listFiles((x, n) -> n.endsWith(".dex"));
        if (dexes == null || dexes.length == 0) throw new IOException("APK import nahi hui (dex nahi mili)");
        Arrays.sort(dexes, (a, b) -> Integer.compare(dexIndex(a.getName()), dexIndex(b.getName())));
        Tools.deleteRec(tmp);
        tmp.mkdirs();

        Set<String> stored = new HashSet<>();
        File sf = new File(orig, "stored.txt");
        if (sf.exists()) {
            for (String line : new String(Files.readAllBytes(sf.toPath()), StandardCharsets.UTF_8).split("\n")) {
                if (!line.isEmpty()) stored.add(line);
            }
        }

        List<ZipWriter.Ent> ents = new ArrayList<>();
        for (File d : dexes) {
            String base = d.getName().substring(0, d.getName().length() - 4);
            File sm = new File(root, "smali/" + base);
            File use = d;
            if (sm.isDirectory() && Tools.countFiles(sm) > 0) {
                File nd = new File(tmp, d.getName());
                assemble(sm, nd, apiForDex(d));
                use = nd;
                log.append(d.getName()).append(": smali se dobara banayi\n");
            } else {
                log.append(d.getName()).append(": original (badli nahi)\n");
            }
            ents.add(new ZipWriter.Ent(d.getName(), use, false));
        }
        File files = new File(root, "apk_files");
        collect(files, files, ents, stored);

        File unsigned = new File(tmp, "unsigned.apk");
        ZipWriter.write(unsigned, ents);
        outDir.mkdirs();
        File signed = new File(outDir, "modified.apk");
        sign(ctx, unsigned, signed);
        return signed;
    }

    static byte[] asset(Context ctx, String name) throws IOException {
        try (InputStream in = ctx.getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int r;
            while ((r = in.read(b)) > 0) bo.write(b, 0, r);
            return bo.toByteArray();
        }
    }

    static void sign(Context ctx, File in, File out) throws Exception {
        PrivateKey key = KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(asset(ctx, "sign.pk8")));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(asset(ctx, "sign.x509.der")));
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder(
                "assistant", key, Collections.singletonList(cert)).build();
        if (out.exists()) out.delete();
        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in)
                .setOutputApk(out)
                .setMinSdkVersion(24)
                .setV1SigningEnabled(false)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(false)
                .build()
                .sign();
    }
}
