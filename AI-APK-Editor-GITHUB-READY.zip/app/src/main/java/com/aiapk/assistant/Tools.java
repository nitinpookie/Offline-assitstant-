package com.aiapk.assistant;

import android.content.Context;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/** Workspace + tools the AI can call. Everything runs on the phone. */
public class Tools {

    public interface Sink {
        void onOutput(File f, String name, String mime);
    }

    final Context ctx;
    final File root, outDir, tmpDir;
    final Sink sink;

    public Tools(Context ctx, Sink sink) {
        this.ctx = ctx;
        this.sink = sink;
        root = new File(ctx.getFilesDir(), "ws");
        outDir = new File(ctx.getFilesDir(), "out");
        tmpDir = new File(ctx.getCacheDir(), "build");
        root.mkdirs();
        outDir.mkdirs();
    }

    // ---------- helpers ----------
    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[65536];
        int r;
        while ((r = in.read(b)) > 0) out.write(b, 0, r);
    }

    static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] c = f.listFiles();
        if (c != null) for (File x : c) deleteRec(x);
        f.delete();
    }

    static int countFiles(File f) {
        if (f.isFile()) return 1;
        File[] c = f.listFiles();
        int n = 0;
        if (c != null) for (File x : c) n += countFiles(x);
        return n;
    }

    static boolean isBinary(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[1024];
            int r = in.read(b);
            for (int i = 0; i < r; i++) if (b[i] == 0) return true;
        }
        return false;
    }

    boolean apkMode() {
        return new File(root, ".orig").isDirectory();
    }

    File resolve(String rel) throws IOException {
        if (rel == null) rel = "";
        rel = rel.trim();
        while (rel.startsWith("/")) rel = rel.substring(1);
        File f = (rel.isEmpty() || rel.equals(".")) ? root : new File(root, rel);
        String rc = root.getCanonicalPath();
        String fc = f.getCanonicalPath();
        if (!fc.equals(rc) && !fc.startsWith(rc + File.separator)) {
            throw new IOException("path workspace ke bahar hai: " + rel);
        }
        return f;
    }

    String rel(File f) {
        return root.toPath().relativize(f.toPath()).toString();
    }

    public String shortStatus() {
        if (apkMode()) {
            return "APK workspace (smali: " + (new File(root, "smali").isDirectory() ? "ready" : "abhi decompile nahi") + ")";
        }
        String[] l = root.list();
        return (l == null || l.length == 0) ? "Workspace khali - Import dabao" : "Source workspace (" + l.length + " items)";
    }

    // ---------- import ----------
    public String importFile(File src, String name) throws IOException {
        deleteRec(root);
        root.mkdirs();
        deleteRec(outDir);
        outDir.mkdirs();
        ZipFile zf;
        try {
            zf = new ZipFile(src);
        } catch (ZipException e) {
            File dest = new File(root, (name == null || name.isEmpty()) ? "file" : name);
            try (InputStream in = new FileInputStream(src); OutputStream o = new FileOutputStream(dest)) {
                copy(in, o);
            }
            return "Single file import hui: " + dest.getName() + " (zip/apk nahi tha)";
        }
        try {
            boolean apk = zf.getEntry("AndroidManifest.xml") != null
                    && (zf.getEntry("classes.dex") != null || zf.getEntry("resources.arsc") != null);
            StringBuilder stored = new StringBuilder();
            int files = 0, dex = 0;
            String rootCanon = root.getCanonicalPath() + File.separator;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String n = e.getName();
                String target;
                if (apk) {
                    if (n.matches("classes\\d*\\.dex")) {
                        target = ".orig/" + n;
                        dex++;
                    } else {
                        target = "apk_files/" + n;
                    }
                    if (e.getMethod() == ZipEntry.STORED) stored.append(n).append('\n');
                } else {
                    target = n;
                }
                File dest = new File(root, target);
                if (!dest.getCanonicalPath().startsWith(rootCanon)) continue;
                dest.getParentFile().mkdirs();
                try (InputStream in = zf.getInputStream(e); OutputStream o = new FileOutputStream(dest)) {
                    copy(in, o);
                }
                files++;
            }
            if (apk) {
                Files.write(new File(root, ".orig/stored.txt").toPath(), stored.toString().getBytes(StandardCharsets.UTF_8));
                return "APK import hui: " + files + " files, " + dex + " dex. apk_files/ mein assets/res/lib hain; code ke liye apk_disassemble chalana padega.";
            }
            return "Project import hui: " + files + " files.";
        } finally {
            zf.close();
        }
    }

    // ---------- dispatcher ----------
    public String call(String name, JSONObject a) {
        try {
            switch (name) {
                case "workspace_info": return info();
                case "list_files": return listFiles(a.optString("path", ""), a.optInt("depth", 2));
                case "read_file": return readFile(a.optString("path", ""), a.optInt("start_line", 0), a.optInt("end_line", 0));
                case "write_file": return writeFile(a.optString("path", ""), a.optString("content", ""));
                case "replace_in_file": return replaceInFile(a.optString("path", ""), a.optString("old_text", ""),
                        a.optString("new_text", ""), a.optBoolean("replace_all", false));
                case "search": return search(a.optString("query", ""), a.optString("path", ""), a.optInt("max_results", 40));
                case "delete_path": return deletePath(a.optString("path", ""));
                case "move_path": return movePath(a.optString("from_path", ""), a.optString("to_path", ""));
                case "apk_disassemble": return apkDisassemble(a.optString("dex", "all"));
                case "apk_build": return apkBuild();
                case "export_zip": return exportZip(a.optString("name", ""));
                default: return "ERROR: unknown tool " + name;
            }
        } catch (Throwable t) {
            return "ERROR: " + t.getClass().getSimpleName() + ": " + t.getMessage();
        }
    }

    String info() {
        StringBuilder sb = new StringBuilder();
        if (apkMode()) {
            sb.append("MODE: APK\n");
            File[] d = new File(root, ".orig").listFiles((x, n) -> n.endsWith(".dex"));
            if (d != null) {
                Arrays.sort(d);
                for (File f : d) {
                    String base = f.getName().substring(0, f.getName().length() - 4);
                    boolean dec = new File(root, "smali/" + base).isDirectory();
                    sb.append(f.getName()).append(" (").append(f.length()).append(" B) ")
                            .append(dec ? "[decompiled -> smali/" + base + "/]" : "[not decompiled]").append('\n');
                }
            }
            sb.append("apk_files/ = all non-dex entries (assets, res, lib, AndroidManifest.xml binary)\n");
        } else {
            String[] l = root.list();
            sb.append("MODE: SOURCE/FILES\n");
            if (l == null || l.length == 0) sb.append("workspace khali hai (user ne kuch import nahi kiya)\n");
            else sb.append("top-level: ").append(String.join(", ", l)).append('\n');
        }
        String[] o = outDir.list();
        if (o != null && o.length > 0) sb.append("saved outputs: ").append(String.join(", ", o)).append('\n');
        return sb.toString();
    }

    String listFiles(String path, int depth) throws IOException {
        File base = resolve(path);
        if (!base.exists()) return "ERROR: path nahi mila: " + path;
        if (base.isFile()) return base.getName() + " (" + base.length() + " B)";
        StringBuilder sb = new StringBuilder();
        int[] cnt = {0};
        walkList(base, 0, Math.max(1, Math.min(depth, 6)), sb, cnt);
        if (cnt[0] >= 300) sb.append("[300 se zyada items - chhota path ya depth do]\n");
        return sb.length() == 0 ? "(khali)" : sb.toString();
    }

    void walkList(File dir, int level, int maxDepth, StringBuilder sb, int[] cnt) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        Arrays.sort(fs, (x, y) -> {
            if (x.isDirectory() != y.isDirectory()) return x.isDirectory() ? -1 : 1;
            return x.getName().compareToIgnoreCase(y.getName());
        });
        StringBuilder ind = new StringBuilder();
        for (int i = 0; i < level; i++) ind.append("  ");
        for (File f : fs) {
            if (f.getName().startsWith(".")) continue;
            if (cnt[0] >= 300) return;
            cnt[0]++;
            if (f.isDirectory()) {
                sb.append(ind).append(f.getName()).append("/\n");
                if (level + 1 < maxDepth) walkList(f, level + 1, maxDepth, sb, cnt);
            } else {
                sb.append(ind).append(f.getName()).append(" (").append(f.length()).append(" B)\n");
            }
        }
    }

    String readFile(String path, int start, int end) throws IOException {
        File f = resolve(path);
        if (!f.isFile()) return "ERROR: file nahi mili: " + path;
        if (isBinary(f)) return "BINARY file (" + f.length() + " bytes) - text mein padh nahi sakte.";
        String all = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
        if (start > 0 || end > 0) {
            String[] lines = all.split("\n", -1);
            int s = Math.max(1, start);
            int e = end > 0 ? Math.min(end, lines.length) : lines.length;
            StringBuilder sb = new StringBuilder("[lines " + s + "-" + e + " of " + lines.length + "]\n");
            for (int i = s - 1; i < e; i++) sb.append(lines[i]).append('\n');
            all = sb.toString();
        }
        if (all.length() > 20000) all = all.substring(0, 20000) + "\n...[truncated - start_line/end_line use karo]";
        return all;
    }

    String writeFile(String path, String content) throws IOException {
        File f = resolve(path);
        if (f.equals(root)) return "ERROR: path galat";
        f.getParentFile().mkdirs();
        Files.write(f.toPath(), content.getBytes(StandardCharsets.UTF_8));
        return "OK: " + path + " likhi (" + content.length() + " chars)";
    }

    String replaceInFile(String path, String oldT, String newT, boolean all) throws IOException {
        File f = resolve(path);
        if (!f.isFile()) return "ERROR: file nahi mili: " + path;
        if (oldT.isEmpty()) return "ERROR: old_text khali hai";
        String s = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
        int count = 0, idx = 0;
        while ((idx = s.indexOf(oldT, idx)) >= 0) {
            count++;
            idx += oldT.length();
        }
        if (count == 0) return "ERROR: old_text file mein nahi mila (spaces/newlines exact match chahiye). Pehle read_file se dekho.";
        if (count > 1 && !all) return "ERROR: old_text " + count + " baar mila. Zyada context do ya replace_all=true.";
        String out = all ? s.replace(oldT, newT) : s.replaceFirst(java.util.regex.Pattern.quote(oldT),
                java.util.regex.Matcher.quoteReplacement(newT));
        Files.write(f.toPath(), out.getBytes(StandardCharsets.UTF_8));
        return "OK: " + count + " jagah badla " + path;
    }

    String search(String query, String path, int max) throws IOException {
        if (query.isEmpty()) return "ERROR: query khali hai";
        File base = resolve(path);
        if (max <= 0 || max > 100) max = 40;
        List<String> res = new ArrayList<>();
        searchWalk(base, query.toLowerCase(), res, max);
        if (res.isEmpty()) return "Kuch nahi mila";
        StringBuilder sb = new StringBuilder();
        for (String r : res) sb.append(r).append('\n');
        if (res.size() >= max) sb.append("[max results - query ya path chhota karo]\n");
        return sb.toString();
    }

    void searchWalk(File f, String q, List<String> res, int max) {
        if (res.size() >= max) return;
        if (f.isDirectory()) {
            File[] c = f.listFiles();
            if (c == null) return;
            Arrays.sort(c);
            for (File x : c) {
                if (x.getName().startsWith(".")) continue;
                searchWalk(x, q, res, max);
                if (res.size() >= max) return;
            }
            return;
        }
        if (f.length() == 0 || f.length() > 3000000) return;
        try {
            if (isBinary(f)) return;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                int n = 0;
                while ((line = br.readLine()) != null) {
                    n++;
                    if (line.toLowerCase().contains(q)) {
                        String t = line.trim();
                        if (t.length() > 200) t = t.substring(0, 200);
                        res.add(rel(f) + ":" + n + ": " + t);
                        if (res.size() >= max) return;
                    }
                }
            }
        } catch (IOException ignored) {
        }
    }

    String deletePath(String path) throws IOException {
        File f = resolve(path);
        if (f.equals(root)) return "ERROR: root delete nahi hoga";
        if (!f.exists()) return "ERROR: nahi mila: " + path;
        deleteRec(f);
        return "OK: delete " + path;
    }

    String movePath(String from, String to) throws IOException {
        File a = resolve(from), b = resolve(to);
        if (!a.exists()) return "ERROR: nahi mila: " + from;
        b.getParentFile().mkdirs();
        return a.renameTo(b) ? "OK: " + from + " -> " + to : "ERROR: move fail";
    }

    String apkDisassemble(String dex) throws Exception {
        File[] dexes = new File(root, ".orig").listFiles((x, n) -> n.endsWith(".dex"));
        if (dexes == null || dexes.length == 0) return "ERROR: APK mode nahi hai (APK import nahi hui)";
        Arrays.sort(dexes);
        StringBuilder sb = new StringBuilder();
        for (File d : dexes) {
            if (dex != null && !dex.isEmpty() && !dex.equals("all") && !d.getName().equals(dex)) continue;
            String base = d.getName().substring(0, d.getName().length() - 4);
            File out = new File(root, "smali/" + base);
            ApkTool.disassemble(d, out);
            sb.append(d.getName()).append(" -> smali/").append(base).append("/ (")
                    .append(countFiles(out)).append(" smali files)\n");
        }
        if (sb.length() == 0) return "ERROR: aisi dex nahi mili: " + dex;
        return sb + "Ab search / read_file se smali dekho.";
    }

    String apkBuild() throws Exception {
        StringBuilder log = new StringBuilder();
        File out = ApkTool.build(ctx, root, outDir, tmpDir, log);
        sink.onOutput(out, "modified.apk", "application/vnd.android.package-archive");
        return "OK: modified.apk bani aur sign hui (" + out.length() + " bytes). User Save button se save kar sakta hai.\n"
                + log + "Note: signature original se alag hai, isliye pehle original app uninstall karni padegi.";
    }

    String exportZip(String name) throws IOException {
        if (name == null || name.trim().isEmpty()) name = "modified-project.zip";
        name = name.trim();
        if (!name.endsWith(".zip")) name += ".zip";
        File out = new File(outDir, name);
        outDir.mkdirs();
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out)))) {
            zipDir(root, root, z);
        }
        sink.onOutput(out, name, "application/zip");
        return "OK: " + name + " tayyar (" + out.length() + " bytes). User Save button se save kar sakta hai.";
    }

    void zipDir(File base, File dir, ZipOutputStream z) throws IOException {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        Arrays.sort(fs);
        for (File f : fs) {
            if (f.getName().startsWith(".")) continue;
            if (f.isDirectory()) {
                zipDir(base, f, z);
            } else {
                String n = base.toPath().relativize(f.toPath()).toString().replace(File.separatorChar, '/');
                z.putNextEntry(new ZipEntry(n));
                try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
                    copy(in, z);
                }
                z.closeEntry();
            }
        }
    }
}
