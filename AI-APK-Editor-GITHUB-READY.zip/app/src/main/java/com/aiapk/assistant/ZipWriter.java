package com.aiapk.assistant;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Writes a zip/APK where STORED entries are aligned (4 bytes, .so files 16 KB), like zipalign. */
public class ZipWriter {

    public static class Ent {
        public final String name;
        public final File file;
        public final boolean stored;

        public Ent(String name, File file, boolean stored) {
            this.name = name;
            this.file = file;
            this.stored = stored;
        }
    }

    static class CountingOut extends FilterOutputStream {
        long n;

        CountingOut(OutputStream o) {
            super(o);
        }

        @Override
        public void write(int b) throws IOException {
            out.write(b);
            n++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            n += len;
        }
    }

    public static void write(File outFile, List<Ent> ents) throws IOException {
        CountingOut co = new CountingOut(new BufferedOutputStream(new FileOutputStream(outFile), 1 << 16));
        byte[] buf = new byte[1 << 16];
        try (ZipOutputStream z = new ZipOutputStream(co)) {
            for (Ent e : ents) {
                ZipEntry ze = new ZipEntry(e.name);
                if (e.stored) {
                    CRC32 crc = new CRC32();
                    long len = 0;
                    try (InputStream in = new FileInputStream(e.file)) {
                        int r;
                        while ((r = in.read(buf)) > 0) {
                            crc.update(buf, 0, r);
                            len += r;
                        }
                    }
                    ze.setMethod(ZipEntry.STORED);
                    ze.setSize(len);
                    ze.setCompressedSize(len);
                    ze.setCrc(crc.getValue());
                    int align = e.name.endsWith(".so") ? 16384 : 4;
                    long dataOff = co.n + 30 + e.name.getBytes(StandardCharsets.UTF_8).length;
                    int pad = (int) ((align - (dataOff % align)) % align);
                    if (pad > 0 && pad < 4) pad += align;
                    if (pad > 0) {
                        byte[] ex = new byte[pad];
                        ex[0] = (byte) 0x35;
                        ex[1] = (byte) 0xD9;
                        ex[2] = (byte) ((pad - 4) & 0xff);
                        ex[3] = (byte) (((pad - 4) >> 8) & 0xff);
                        ze.setExtra(ex);
                    }
                }
                z.putNextEntry(ze);
                try (InputStream in = new FileInputStream(e.file)) {
                    int r;
                    while ((r = in.read(buf)) > 0) z.write(buf, 0, r);
                }
                z.closeEntry();
            }
        }
    }
}
