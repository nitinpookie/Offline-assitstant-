package com.aiapk.assistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.text.util.Linkify;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    static final int RQ_IMPORT = 1, RQ_IMAGE = 2, RQ_SAVE = 3;
    static final String DEFAULT_MODEL = "gemini-2.5-flash";

    final Handler h = new Handler(Looper.getMainLooper());
    LinearLayout chat;
    ScrollView scroll;
    EditText input;
    Button sendBtn;
    TextView statusTv, wsTv, pendingTv;
    SharedPreferences prefs;
    Tools tools;
    Agent agent;
    String pendingB64;
    volatile boolean busy;
    File saveFile, lastOut;
    String saveMime, lastOutName, lastOutMime;

    final Agent.Ui uiCb = new Agent.Ui() {
        @Override public void say(String t) { h.post(() -> addBubble(clean(t), 1)); }
        @Override public void log(String t) { h.post(() -> addBubble(t, 2)); }
        @Override public void status(String t) { h.post(() -> statusTv.setText(t)); }
        @Override public void error(String t) { h.post(() -> addBubble("⚠️ " + t, 3)); }
    };

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF3F4F6);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF1F2937);
        bar.setPadding(dp(12), dp(4), dp(4), dp(4));
        TextView title = new TextView(this);
        title.setText("AI Assistant");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(barBtn("Import", v -> pickFile()));
        bar.addView(barBtn("Save", v -> saveLast()));
        bar.addView(barBtn("New", v -> newChat()));
        bar.addView(barBtn("⚙", v -> settings()));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        wsTv = new TextView(this);
        wsTv.setTextSize(12);
        wsTv.setTextColor(0xFF4B5563);
        wsTv.setPadding(dp(12), dp(4), dp(12), dp(4));
        root.addView(wsTv);

        scroll = new ScrollView(this);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(dp(10), dp(6), dp(10), dp(6));
        scroll.addView(chat);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        statusTv = new TextView(this);
        statusTv.setTextSize(12);
        statusTv.setTextColor(0xFF2563EB);
        statusTv.setPadding(dp(12), dp(2), dp(12), dp(2));
        statusTv.setVisibility(View.GONE);
        root.addView(statusTv);

        pendingTv = new TextView(this);
        pendingTv.setText("📷 Screenshot laga hai (hatane ke liye dabao)");
        pendingTv.setTextSize(13);
        pendingTv.setPadding(dp(12), dp(4), dp(12), dp(4));
        pendingTv.setVisibility(View.GONE);
        pendingTv.setOnClickListener(v -> {
            pendingB64 = null;
            pendingTv.setVisibility(View.GONE);
        });
        root.addView(pendingTv);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(4), dp(4), dp(4));
        row.setBackgroundColor(Color.WHITE);
        Button img = new Button(this, null, android.R.attr.borderlessButtonStyle);
        img.setText("📷");
        img.setMinWidth(0);
        img.setMinimumWidth(0);
        img.setOnClickListener(v -> pickImage());
        row.addView(img);
        input = new EditText(this);
        input.setHint("Message likho...");
        input.setMaxLines(5);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        row.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        sendBtn = new Button(this);
        sendBtn.setText("Send");
        sendBtn.setOnClickListener(v -> onSend());
        row.addView(sendBtn);
        root.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);

        tools = new Tools(this, (f, n, m) -> h.post(() -> showOutput(f, n, m)));
        wsTv.setText("📂 " + tools.shortStatus());
        addBubble("Namaste! 1) ⚙ mein free Gemini API key daalo. 2) Import se APK ya project zip chuno. 3) Batao kya badalna hai. 📷 se screenshot bhi bhej sakte ho.", 1);
        if (prefs.getString("key", "").isEmpty()) h.postDelayed(this::settings, 400);
    }

    Button barBtn(String t, View.OnClickListener l) {
        Button x = new Button(this, null, android.R.attr.borderlessButtonStyle);
        x.setText(t);
        x.setAllCaps(false);
        x.setTextColor(Color.WHITE);
        x.setTextSize(13);
        x.setMinWidth(0);
        x.setMinimumWidth(0);
        x.setPadding(dp(10), 0, dp(10), 0);
        x.setOnClickListener(l);
        return x;
    }

    TextView addBubble(String text, int kind) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextIsSelectable(true);
        tv.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.9f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        if (kind == 2) {
            tv.setTextSize(12);
            tv.setTextColor(0xFF6B7280);
            lp.gravity = Gravity.START;
        } else {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(14));
            bg.setColor(kind == 0 ? 0xFFDCE8FF : kind == 3 ? 0xFFFFE1E1 : Color.WHITE);
            if (kind == 1) bg.setStroke(dp(1), 0xFFE5E7EB);
            tv.setBackground(bg);
            tv.setPadding(dp(12), dp(8), dp(12), dp(8));
            tv.setTextSize(15);
            tv.setTextColor(0xFF111827);
            lp.gravity = kind == 0 ? Gravity.END : Gravity.START;
        }
        chat.addView(tv, lp);
        scrollDown();
        return tv;
    }

    void scrollDown() {
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    static String clean(String t) {
        StringBuilder sb = new StringBuilder();
        for (String line : t.replace("**", "").split("\n", -1)) {
            if (line.startsWith("* ")) line = "• " + line.substring(2);
            else if (line.startsWith("  * ")) line = "   • " + line.substring(4);
            sb.append(line).append('\n');
        }
        return sb.toString().trim();
    }

    void setBusy(boolean b) {
        busy = b;
        sendBtn.setText(b ? "Stop" : "Send");
        statusTv.setVisibility(b ? View.VISIBLE : View.GONE);
        if (!b) wsTv.setText("📂 " + tools.shortStatus());
    }

    // ---------- send ----------
    void onSend() {
        if (busy) {
            if (agent != null) agent.cancel = true;
            return;
        }
        final String t = input.getText().toString().trim();
        if (t.isEmpty() && pendingB64 == null) return;
        String key = prefs.getString("key", "");
        if (key.isEmpty()) {
            settings();
            return;
        }
        addBubble(t.isEmpty() ? "(screenshot)" : (pendingB64 != null ? "📷 " + t : t), 0);
        final String img = pendingB64;
        pendingB64 = null;
        pendingTv.setVisibility(View.GONE);
        input.setText("");
        if (agent == null) agent = new Agent(tools, uiCb);
        agent.apiKey = key;
        agent.model = prefs.getString("model", DEFAULT_MODEL);
        agent.cancel = false;
        setBusy(true);
        final Agent ag = agent;
        new Thread(() -> {
            try {
                ag.run(t, img);
            } catch (Throwable e) {
                uiCb.error(String.valueOf(e.getMessage()));
            } finally {
                h.post(() -> setBusy(false));
            }
        }).start();
    }

    void newChat() {
        if (busy) {
            Toast.makeText(this, "Pehle Stop dabao", Toast.LENGTH_SHORT).show();
            return;
        }
        chat.removeAllViews();
        if (agent != null) agent.reset();
        addBubble("Nayi chat. Workspace wahi hai (" + tools.shortStatus() + ").", 1);
    }

    // ---------- file pickers ----------
    void pickFile() {
        if (busy) {
            Toast.makeText(this, "Pehle kaam khatam hone do ya Stop dabao", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, RQ_IMPORT);
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        startActivityForResult(i, RQ_IMAGE);
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (rs != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (rq == RQ_IMPORT) importUri(uri);
        else if (rq == RQ_IMAGE) {
            try {
                pendingB64 = loadImageB64(uri);
                pendingTv.setVisibility(View.VISIBLE);
            } catch (Exception e) {
                Toast.makeText(this, "Image load nahi hui", Toast.LENGTH_SHORT).show();
            }
        } else if (rq == RQ_SAVE) saveTo(uri);
    }

    String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {
        }
        return "file";
    }

    void importUri(Uri uri) {
        final String name = displayName(uri);
        setBusy(true);
        statusTv.setText("⏳ Import ho raha hai...");
        new Thread(() -> {
            try {
                File tmp = new File(getCacheDir(), "import.tmp");
                try (InputStream in = getContentResolver().openInputStream(uri); OutputStream o = new FileOutputStream(tmp)) {
                    Tools.copy(in, o);
                }
                String res = tools.importFile(tmp, name);
                tmp.delete();
                if (agent != null) agent.reset();
                h.post(() -> addBubble("📂 " + name + ": " + res + "\nAb batao kya karna hai.", 1));
            } catch (Throwable e) {
                uiCb.error("Import fail: " + e.getMessage());
            } finally {
                h.post(() -> setBusy(false));
            }
        }).start();
    }

    String loadImageB64(Uri uri) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            Tools.copy(in, bo);
        }
        byte[] bytes = bo.toByteArray();
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / s > 2400) s *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = s;
        Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o2);
        if (bmp == null) throw new IOException("decode fail");
        float sc = 1568f / Math.max(bmp.getWidth(), bmp.getHeight());
        if (sc < 1f) bmp = Bitmap.createScaledBitmap(bmp, (int) (bmp.getWidth() * sc), (int) (bmp.getHeight() * sc), true);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out);
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    // ---------- outputs ----------
    void showOutput(File f, String name, String mime) {
        lastOut = f;
        lastOutName = name;
        lastOutMime = mime;
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText("💾 Save: " + name + " (" + (f.length() / 1024) + " KB)");
        b.setOnClickListener(v -> startSave(f, name, mime));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.START;
        chat.addView(b, lp);
        scrollDown();
    }

    void saveLast() {
        if (lastOut == null || !lastOut.exists()) {
            Toast.makeText(this, "Abhi koi output nahi bana", Toast.LENGTH_SHORT).show();
            return;
        }
        startSave(lastOut, lastOutName, lastOutMime);
    }

    void startSave(File f, String name, String mime) {
        saveFile = f;
        saveMime = mime;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, RQ_SAVE);
    }

    void saveTo(Uri uri) {
        final File f = saveFile;
        if (f == null) return;
        new Thread(() -> {
            try (InputStream in = new FileInputStream(f); OutputStream o = getContentResolver().openOutputStream(uri)) {
                Tools.copy(in, o);
                h.post(() -> Toast.makeText(this, "Save ho gaya ✅", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                uiCb.error("Save fail: " + e.getMessage());
            }
        }).start();
    }

    // ---------- settings ----------
    void settings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        TextView hint = new TextView(this);
        hint.setTextSize(13);
        hint.setAutoLinkMask(Linkify.WEB_URLS);
        hint.setText("Free key: https://aistudio.google.com/apikey (Google account se, card nahi chahiye).\nModel: gemini-2.5-flash ya gemini-2.5-flash-lite (zyada requests).");
        EditText k = new EditText(this);
        k.setHint("Gemini API key");
        k.setSingleLine(true);
        k.setText(prefs.getString("key", ""));
        k.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText m = new EditText(this);
        m.setHint("Model");
        m.setSingleLine(true);
        m.setText(prefs.getString("model", DEFAULT_MODEL));
        box.addView(hint);
        box.addView(k);
        box.addView(m);
        new AlertDialog.Builder(this)
                .setTitle("Settings")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    String mm = m.getText().toString().trim();
                    prefs.edit().putString("key", k.getText().toString().trim())
                            .putString("model", mm.isEmpty() ? DEFAULT_MODEL : mm).apply();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
