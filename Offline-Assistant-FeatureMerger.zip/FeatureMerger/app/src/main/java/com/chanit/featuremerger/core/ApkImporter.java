package com.chanit.featuremerger.core;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Turns whatever the user hands over into ONE plain, readable .apk inside the app's store:
 *
 *  - a normal .apk (also with a wrong extension: it is recognised by content);
 *  - split bundles: .xapk, .apks, .apkm, or any .zip that holds .apk files. The base apk is chosen
 *    and the native libraries of this phone's CPU are copied in from the config splits;
 *  - an app that is already installed on the phone (base apk + its splits);
 *  - apks whose zip directory is non-standard (re-packed / "optimised" files): they are re-written cleanly.
 */
public final class ApkImporter {
    private ApkImporter() {}

    public interface Log { void log(String line); }

    public static final class Result {
        public File file;
        /** "APK", "Bundle" or "Installed app". */
        public String kind;
        /** Shown in the app's notes and log: what was done / what was left out. Never null. */
        public final List<String> notes = new ArrayList<>();
    }

    // ------------------------------------------------------------------ from a file the user picked
    public static Result fromFile(Context ctx, File raw, String displayName, Store store, Log log) throws IOException {
        Result res = new Result();
        String base = cleanName(displayName);
        SafeZip zip;
        try {
            zip = new SafeZip(raw);
        } catch (IOException e) {
            throw new IOException("This is not an APK or a zip based package (" + e.getMessage() + ")");
        }
        try {
            if (zip.getEntry("BundleConfig.pb") != null || zip.getEntry("base/manifest/AndroidManifest.xml") != null)
                throw new IOException("This is an .aab (Android App Bundle). It cannot be installed or merged. "
                        + "Export an .apks / .apk from it first (bundletool or your build tool).");

            if (zip.wasRecovered()) res.notes.add("The zip directory was damaged; entries were recovered by scanning the file.");

            if (zip.getEntry("AndroidManifest.xml") != null) {
                res.kind = "APK";
                if (!hasDex(zip)) throw new IOException("This APK contains no code (classes.dex is missing), so there is nothing to merge.");
                zip.close();
                File dest = store.uniqueFile(base);
                placeClean(raw, dest, res, log);
                res.file = dest;
                return res;
            }

            List<SafeZip.Entry> apkEntries = new ArrayList<>();
            boolean obb = false;
            for (SafeZip.Entry e : zip.list()) {
                String n = e.getName().toLowerCase(Locale.ROOT);
                if (!e.isDirectory() && n.endsWith(".apk")) apkEntries.add(e);
                if (n.endsWith(".obb")) obb = true;
            }
            if (apkEntries.isEmpty()) throw new IOException("No APK found inside this file (no AndroidManifest.xml and no .apk entries).");

            res.kind = "Bundle";
            File tmpDir = new File(ctx.getCacheDir(), "bundle_" + System.nanoTime());
            //noinspection ResultOfMethodCallIgnored
            tmpDir.mkdirs();
            try {
                List<Cand> cands = new ArrayList<>();
                int i = 0;
                for (SafeZip.Entry e : apkEntries) {
                    File f = new File(tmpDir, (i++) + ".apk");
                    try (InputStream in = zip.getInputStream(e); FileOutputStream o = new FileOutputStream(f)) {
                        pump(in, o);
                    }
                    Cand c = Cand.read(f, e.getName());
                    if (c != null) cands.add(c);
                }
                if (cands.isEmpty()) throw new IOException("The .apk files inside this bundle could not be read.");

                Cand baseC = pickBase(cands);
                try (SafeZip bz = new SafeZip(baseC.file)) {
                    if (!hasDex(bz)) throw new IOException("The base apk in this bundle has no code (classes.dex missing).");
                }
                List<File> libSplits = new ArrayList<>();
                int otherSplits = 0;
                for (Cand c : cands) {
                    if (c == baseC) continue;
                    if (c.isSplit) libSplits.add(c.file); else otherSplits++;
                }
                log.log("Bundle: " + cands.size() + " apk(s) inside, base = " + baseC.entryName);
                File dest = store.uniqueFile(base);
                assemble(baseC.file, libSplits, dest, res, log);
                if (otherSplits > 0) res.notes.add(otherSplits + " other full apk(s) in the bundle were ignored.");
                if (obb) res.notes.add("OBB game data in the bundle is not included; copy it to Android/obb yourself.");
                res.file = dest;
                return res;
            } finally {
                deleteTree(tmpDir);
            }
        } finally {
            try { zip.close(); } catch (IOException ignored) { }
        }
    }

    // ------------------------------------------------------------------ from an installed app
    public static Result fromInstalled(Context ctx, ApplicationInfo ai, Store store, Log log) throws IOException {
        Result res = new Result();
        res.kind = "Installed app";
        File baseApk = new File(ai.sourceDir);
        if (!baseApk.canRead()) throw new IOException("Android does not let this app read " + ai.packageName + " (" + ai.sourceDir + ").");
        List<File> splits = new ArrayList<>();
        if (ai.splitSourceDirs != null) for (String s : ai.splitSourceDirs) {
            File f = new File(s);
            if (f.canRead()) splits.add(f);
        }
        try (SafeZip z = new SafeZip(baseApk)) {
            if (!hasDex(z)) throw new IOException(ai.packageName + " has no classes.dex in its APK (stripped system app), so it cannot be merged.");
        }
        File dest = store.uniqueFile(ai.packageName);
        if (!splits.isEmpty()) log.log(ai.packageName + " is installed as " + (splits.size() + 1) + " apk files (split install).");
        assemble(baseApk, splits, dest, res, log);
        res.file = dest;
        return res;
    }

    // ------------------------------------------------------------------ building the single apk
    /** Writes base (+ native libs of this phone's CPU taken from the splits) to out. */
    private static void assemble(File base, List<File> splits, File out, Result res, Log log) throws IOException {
        String abi = chooseAbi(base, splits);
        List<File> withLibs = new ArrayList<>();
        if (abi != null) for (File s : splits) if (hasLibs(s, abi)) withLibs.add(s);

        if (withLibs.isEmpty()) {
            placeClean(base, out, res, log, true);
        } else {
            try (ApkZip.Writer w = new ApkZip.Writer(out)) {
                w.copy(base, null, false);
                int n = 0;
                for (File s : withLibs) n += w.copyPrefix(s, new String[]{"lib/" + abi + "/"});
                log.log("Copied " + n + " native file(s) (" + abi + ") from the split apks into the base.");
            }
            res.notes.add("Split install combined into one apk: native libraries for " + abi + " were taken from the config splits.");
        }
        int unused = splits.size() - withLibs.size();
        if (!splits.isEmpty() && unused > 0)
            res.notes.add(unused + " split apk(s) (languages / screen density / feature modules) were not merged; the app falls back to its default resources.");
    }

    private static String chooseAbi(File base, List<File> splits) throws IOException {
        Set<String> present = new LinkedHashSet<>();
        collectAbis(base, present);
        for (File s : splits) collectAbis(s, present);
        if (present.isEmpty()) return null;
        String[] sup = Build.SUPPORTED_ABIS == null ? new String[0] : Build.SUPPORTED_ABIS;
        for (String s : sup) if (present.contains(s)) return s;
        return null;
    }

    private static void collectAbis(File apk, Set<String> out) {
        try (SafeZip z = new SafeZip(apk)) {
            for (SafeZip.Entry e : z.list()) {
                String n = e.getName();
                if (!n.startsWith("lib/")) continue;
                String[] p = n.split("/");
                if (p.length >= 3) out.add(p[1]);
            }
        } catch (IOException ignored) { }
    }

    private static boolean hasLibs(File apk, String abi) {
        try (SafeZip z = new SafeZip(apk)) {
            for (SafeZip.Entry e : z.list()) if (e.getName().startsWith("lib/" + abi + "/")) return true;
        } catch (IOException ignored) { }
        return false;
    }

    private static boolean hasDex(SafeZip z) {
        for (SafeZip.Entry e : z.list()) if (e.getName().matches("classes\\d*\\.dex")) return true;
        return false;
    }

    // ------------------------------------------------------------------ choosing the base apk of a bundle
    private static final class Cand {
        File file;
        String entryName;
        boolean isSplit;
        long size;

        static Cand read(File f, String entryName) {
            Cand c = new Cand();
            c.file = f;
            c.entryName = entryName;
            c.size = f.length();
            try (SafeZip z = new SafeZip(f)) {
                SafeZip.Entry me = z.getEntry("AndroidManifest.xml");
                if (me == null) return null;
                try {
                    Axml mf = Axml.parse(z.readAll(me));
                    c.isSplit = mf.root.plain("split") != null;
                } catch (RuntimeException ignored) { }
                return c;
            } catch (IOException e) {
                return null;
            }
        }
    }

    private static Cand pickBase(List<Cand> cands) {
        String[] sup = Build.SUPPORTED_ABIS == null ? new String[0] : Build.SUPPORTED_ABIS;
        Cand best = null;
        long bestScore = Long.MIN_VALUE;
        for (Cand c : cands) {
            if (c.isSplit) continue;
            String n = c.entryName.toLowerCase(Locale.ROOT).replace('-', '_');
            long score = c.size >> 20; // bigger apk wins ties
            if (n.contains("universal")) score += 1000;
            if (n.endsWith("base.apk") || n.contains("base_master")) score += 400;
            if (n.contains("standalone")) {
                score += 300;
                for (String a : sup) if (n.contains(a.replace('-', '_'))) { score += 100; break; }
            }
            if (score > bestScore) { bestScore = score; best = c; }
        }
        if (best != null) return best;
        // every apk claims to be a split: take the biggest one
        for (Cand c : cands) if (best == null || c.size > best.size) best = c;
        return best;
    }

    // ------------------------------------------------------------------ writing a clean copy
    private static void placeClean(File src, File dest, Result res, Log log) throws IOException {
        placeClean(src, dest, res, log, false);
    }

    private static void placeClean(File src, File dest, Result res, Log log, boolean keepSrc) throws IOException {
        if (javaZipOk(src)) {
            if (keepSrc || !src.renameTo(dest)) copyFile(src, dest);
            return;
        }
        log.log("The zip directory of " + src.getName() + " is non-standard (Android's own zip reader fails on it). Re-packing it cleanly.");
        try (ApkZip.Writer w = new ApkZip.Writer(dest)) {
            w.copy(src, null, false);
        }
        res.notes.add("Re-packed: the original zip directory was non-standard (typical for optimised / modified APKs).");
    }

    /** The exact check that failed in the field: can java.util.zip list every entry? */
    static boolean javaZipOk(File f) {
        try (java.util.zip.ZipFile z = new java.util.zip.ZipFile(f)) {
            Enumeration<? extends java.util.zip.ZipEntry> en = z.entries();
            while (en.hasMoreElements()) en.nextElement();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------ small helpers
    static String cleanName(String n) {
        if (n == null || n.trim().isEmpty()) return "app";
        String l = n.toLowerCase(Locale.ROOT);
        for (String ext : new String[]{".apk", ".xapk", ".apks", ".apkm", ".zip", ".bin"}) {
            if (l.endsWith(ext)) { n = n.substring(0, n.length() - ext.length()); l = n.toLowerCase(Locale.ROOT); }
        }
        return n.isEmpty() ? "app" : n;
    }

    private static void pump(InputStream in, FileOutputStream o) throws IOException {
        byte[] buf = new byte[1 << 16];
        int r;
        while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
    }

    private static void copyFile(File a, File b) throws IOException {
        try (InputStream in = new FileInputStream(a); FileOutputStream o = new FileOutputStream(b)) {
            pump(in, o);
        }
    }

    private static void deleteTree(File f) {
        File[] k = f.listFiles();
        if (k != null) for (File x : k) deleteTree(x);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
