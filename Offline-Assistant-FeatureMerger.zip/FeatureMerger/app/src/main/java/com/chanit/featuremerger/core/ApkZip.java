package com.chanit.featuremerger.core;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Zip writer that keeps resources.arsc / native libs stored and aligned (what zipalign would do). */
public final class ApkZip {
    private ApkZip() {}

    public static boolean isSignature(String n) {
        return n.startsWith("META-INF/") && n.indexOf('/', 9) < 0
                && (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC") || n.equals("META-INF/MANIFEST.MF"));
    }

    public static byte[] readAll(SafeZip zf, SafeZip.Entry e) throws IOException {
        return zf.readAll(e);
    }

    /** CRC32 of what the entry really contains (the stored value in the directory can be wrong in re-packed APKs). */
    private static long realCrc(SafeZip zf, SafeZip.Entry e, byte[] buf) throws IOException {
        CRC32 crc = new CRC32();
        try (InputStream in = zf.getInputStream(e)) {
            int r;
            while ((r = in.read(buf)) > 0) crc.update(buf, 0, r);
        }
        return crc.getValue();
    }

    private static final class Count extends FilterOutputStream {
        long n;
        Count(OutputStream o) { super(o); }
        @Override public void write(int b) throws IOException { out.write(b); n++; }
        @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); n += len; }
    }

    public static final class Writer implements Closeable {
        private final Count cos;
        private final ZipOutputStream zos;
        private final Set<String> names = new HashSet<>();

        public Writer(File out) throws IOException {
            cos = new Count(new BufferedOutputStream(new FileOutputStream(out), 1 << 16));
            zos = new ZipOutputStream(cos);
        }

        private static int alignFor(String name) { return name.endsWith(".so") ? 4096 : 4; }

        private void beginStored(String name, long size, long crc) throws IOException {
            zos.closeEntry();
            ZipEntry ze = new ZipEntry(name);
            ze.setMethod(ZipEntry.STORED);
            ze.setSize(size);
            ze.setCompressedSize(size);
            ze.setCrc(crc);
            int align = alignFor(name);
            long dataStart = cos.n + 30 + name.getBytes(StandardCharsets.UTF_8).length;
            int pad = (int) ((align - (dataStart % align)) % align);
            if (pad > 0) {
                if (pad < 4) pad += align;
                byte[] x = new byte[pad];
                x[0] = (byte) 0xD9; x[1] = 0x35;
                x[2] = (byte) ((pad - 4) & 0xff); x[3] = (byte) (((pad - 4) >> 8) & 0xff);
                ze.setExtra(x);
            }
            zos.putNextEntry(ze);
        }

        public boolean has(String name) { return names.contains(name); }

        public void put(String name, byte[] data, boolean stored) throws IOException {
            names.add(name);
            if (stored) {
                CRC32 crc = new CRC32();
                crc.update(data);
                beginStored(name, data.length, crc.getValue());
            } else {
                zos.closeEntry();
                ZipEntry ze = new ZipEntry(name);
                ze.setMethod(ZipEntry.DEFLATED);
                zos.putNextEntry(ze);
            }
            zos.write(data);
            zos.closeEntry();
        }

        public void putFile(String name, File f) throws IOException {
            names.add(name);
            CRC32 crc = new CRC32();
            byte[] buf = new byte[1 << 16];
            try (InputStream in = new FileInputStream(f)) {
                int r;
                while ((r = in.read(buf)) > 0) crc.update(buf, 0, r);
            }
            beginStored(name, f.length(), crc.getValue());
            try (InputStream in = new FileInputStream(f)) {
                int r;
                while ((r = in.read(buf)) > 0) zos.write(buf, 0, r);
            }
            zos.closeEntry();
        }

        /** Copies every entry of src; replace maps entry name -> new content. */
        public void copy(File src, Map<String, byte[]> replace, boolean dropSignatures) throws IOException {
            copy(src, replace, dropSignatures, null);
        }

        /**
         * Same as above; entries whose name starts with one of the prefixes in {@code skipPrefixes}
         * are left out (used to replace a folder such as lib/ wholesale).
         */
        public void copy(File src, Map<String, byte[]> replace, boolean dropSignatures, String[] skipPrefixes) throws IOException {
            try (SafeZip zf = new SafeZip(src)) {
                byte[] buf = new byte[1 << 16];
                for (SafeZip.Entry e : zf.list()) {
                    String name = e.getName();
                    if (e.isDirectory() || names.contains(name)) continue;
                    if (dropSignatures && isSignature(name)) continue;
                    if (skipPrefixes != null && startsWithAny(name, skipPrefixes)) continue;
                    byte[] rep = replace == null ? null : replace.get(name);
                    if (rep != null) {
                        put(name, rep, name.equals("resources.arsc"));
                        continue;
                    }
                    copyEntry(zf, e, buf);
                }
            }
        }

        /** Copies selected entries (by name prefix) of src into this zip, skipping names that already exist. */
        public int copyPrefix(File src, String[] prefixes) throws IOException {
            int n = 0;
            try (SafeZip zf = new SafeZip(src)) {
                byte[] buf = new byte[1 << 16];
                for (SafeZip.Entry e : zf.list()) {
                    String name = e.getName();
                    if (e.isDirectory() || names.contains(name) || !startsWithAny(name, prefixes)) continue;
                    copyEntry(zf, e, buf);
                    n++;
                }
            }
            return n;
        }

        private static boolean startsWithAny(String name, String[] prefixes) {
            for (String p : prefixes) if (name.startsWith(p)) return true;
            return false;
        }

        private void copyEntry(SafeZip zf, SafeZip.Entry e, byte[] buf) throws IOException {
            String name = e.getName();
            names.add(name);
            if (e.getMethod() == SafeZip.STORED) {
                beginStored(name, e.getCompressedSize(), realCrc(zf, e, buf));
            } else {
                zos.closeEntry();
                ZipEntry ze = new ZipEntry(name);
                ze.setMethod(ZipEntry.DEFLATED);
                zos.putNextEntry(ze);
            }
            try (InputStream in = zf.getInputStream(e)) {
                int r;
                while ((r = in.read(buf)) > 0) zos.write(buf, 0, r);
            }
            zos.closeEntry();
        }

        @Override public void close() throws IOException {
            zos.finish();
            zos.close();
        }
    }
}
