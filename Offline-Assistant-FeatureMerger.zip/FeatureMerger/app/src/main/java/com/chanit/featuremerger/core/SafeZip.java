package com.chanit.featuremerger.core;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/**
 * Forgiving zip reader (pure Java, no Android classes).
 *
 * java.util.zip.ZipFile on some Android versions throws while it merely lists the entries of
 * re-packed / "optimised" APKs (NullPointerException inside ZipFile.getZipEntry). Android's own
 * installer does not care, so those APKs install fine but this app could not read them.
 * This class reads the central directory by itself, ignores fields it does not need
 * (extra field, comment, odd flags), and falls back to scanning local headers when the
 * central directory is damaged.
 *
 * API mirrors the small part of ZipFile / ZipEntry that this project uses.
 */
public final class SafeZip implements Closeable {
    public static final int STORED = 0, DEFLATED = 8;

    private static final int SIG_EOCD = 0x06054b50, SIG_CEN = 0x02014b50, SIG_LOC = 0x04034b50,
            SIG_EOCD64_LOC = 0x07064b50, SIG_EOCD64 = 0x06064b50;

    public static final class Entry {
        private final String name;
        private final int method;
        private final long crc, size, csize, localOffset;

        Entry(String name, int method, long crc, long csize, long size, long localOffset) {
            this.name = name;
            this.method = method;
            this.crc = crc;
            this.csize = csize;
            this.size = size;
            this.localOffset = localOffset;
        }

        public String getName() { return name; }
        public int getMethod() { return method; }
        /** CRC from the central directory (may be wrong in damaged files; callers that need it must verify). */
        public long getCrc() { return crc; }
        public long getSize() { return size; }
        public long getCompressedSize() { return csize; }
        public boolean isDirectory() { return name.endsWith("/"); }
        @Override public String toString() { return name; }
    }

    private final RandomAccessFile raf;
    private final FileChannel ch;
    private final long length;
    private final List<Entry> list = new ArrayList<>();
    private final Map<String, Entry> byName = new HashMap<>();
    private boolean recovered;
    private int skipped;

    public SafeZip(File f) throws IOException {
        raf = new RandomAccessFile(f, "r");
        ch = raf.getChannel();
        length = raf.length();
        try {
            if (length < 22) throw new IOException("Not a zip file (too small)");
            boolean ok = false;
            try {
                ok = readCentral();
            } catch (IOException | RuntimeException e) {
                ok = false;
            }
            if (!ok || list.isEmpty()) {
                list.clear();
                byName.clear();
                skipped = 0;
                recovered = true;
                scanLocalHeaders();
            }
            if (list.isEmpty()) throw new IOException("Not a zip file (no entries found)");
        } catch (IOException | RuntimeException e) {
            try { raf.close(); } catch (IOException ignored) { }
            if (e instanceof IOException) throw (IOException) e;
            throw new IOException("Unreadable zip: " + e, e);
        }
    }

    /** True when the central directory was damaged and entries were found by scanning instead. */
    public boolean wasRecovered() { return recovered; }

    /** Entries that were ignored because their header was unusable. */
    public int skippedCount() { return skipped; }

    public List<Entry> list() { return Collections.unmodifiableList(list); }

    public Enumeration<Entry> entries() { return Collections.enumeration(list); }

    public Entry getEntry(String name) { return byName.get(name); }

    @Override public void close() throws IOException { raf.close(); }

    // ------------------------------------------------------------------ central directory
    private boolean readCentral() throws IOException {
        // end-of-central-directory record: last 22 bytes + up to 65535 bytes of comment
        int max = (int) Math.min(length, 22 + 65535);
        byte[] tail = new byte[max];
        readFully(length - max, tail, 0, max);
        int eocd = -1;
        for (int i = max - 22; i >= 0; i--) {
            if (i32(tail, i) == SIG_EOCD) {
                int commentLen = u16(tail, i + 20);
                // prefer a record whose comment ends exactly at EOF, otherwise accept the last one found
                if (i + 22 + commentLen == max) { eocd = i; break; }
                if (eocd < 0) eocd = i;
            }
        }
        if (eocd < 0) return false;

        long total = u16(tail, eocd + 10);
        long cdSize = i32(tail, eocd + 12) & 0xffffffffL;
        long cdOff = i32(tail, eocd + 16) & 0xffffffffL;
        long eocdPos = length - max + eocd;

        boolean zip64 = total == 0xffff || cdSize == 0xffffffffL || cdOff == 0xffffffffL;
        if (zip64 && eocd >= 20 && i32(tail, eocd - 20) == SIG_EOCD64_LOC) {
            long pos64 = i64(tail, eocd - 20 + 8);
            byte[] z = new byte[56];
            readFully(pos64, z, 0, 56);
            if (i32(z, 0) == SIG_EOCD64) {
                total = i64(z, 32);
                cdSize = i64(z, 40);
                cdOff = i64(z, 48);
            }
        }

        // Some tools write a wrong offset; the directory normally ends right where the EOCD starts.
        if (cdOff < 0 || cdOff + cdSize > eocdPos + 1 || cdOff >= length) {
            long guess = eocdPos - cdSize;
            if (guess >= 0 && guess < length) cdOff = guess; else return false;
        }
        if (cdSize <= 0 || cdSize > Integer.MAX_VALUE) return false;
        byte[] cd = new byte[(int) cdSize];
        readFully(cdOff, cd, 0, cd.length);

        int p = 0;
        while (p + 46 <= cd.length && i32(cd, p) == SIG_CEN) {
            int flags = u16(cd, p + 8);
            int method = u16(cd, p + 10);
            long crc = i32(cd, p + 16) & 0xffffffffL;
            long csize = i32(cd, p + 20) & 0xffffffffL;
            long size = i32(cd, p + 24) & 0xffffffffL;
            int nameLen = u16(cd, p + 28);
            int extraLen = u16(cd, p + 30);
            int commentLen = u16(cd, p + 32);
            long lho = i32(cd, p + 42) & 0xffffffffL;
            int next = p + 46 + nameLen + extraLen + commentLen;
            if (next > cd.length) break;

            if (csize == 0xffffffffL || size == 0xffffffffL || lho == 0xffffffffL) {
                // zip64 extended information inside the extra field
                int e = p + 46 + nameLen, end = e + extraLen;
                while (e + 4 <= end) {
                    int id = u16(cd, e), len = u16(cd, e + 2);
                    if (id == 0x0001) {
                        int q = e + 4;
                        if (size == 0xffffffffL && q + 8 <= end) { size = i64(cd, q); q += 8; }
                        if (csize == 0xffffffffL && q + 8 <= end) { csize = i64(cd, q); q += 8; }
                        if (lho == 0xffffffffL && q + 8 <= end) { lho = i64(cd, q); }
                        break;
                    }
                    e += 4 + len;
                }
            }

            String name = decodeName(cd, p + 46, nameLen, (flags & 0x800) != 0);
            if (name == null || name.isEmpty() || lho < 0 || lho >= length) {
                skipped++;
            } else if (!byName.containsKey(name)) {
                Entry en = new Entry(name, method, crc, csize, size, lho);
                list.add(en);
                byName.put(name, en);
            }
            p = next;
        }
        return !list.isEmpty();
    }

    // ------------------------------------------------------------------ fallback: scan local headers
    private void scanLocalHeaders() throws IOException {
        byte[] h = new byte[30];
        long pos = 0;
        while (pos + 30 <= length) {
            if (!tryRead(pos, h, 30) || i32(h, 0) != SIG_LOC) {
                // resync: look for the next local header signature
                long next = findSig(pos + 1);
                if (next < 0) break;
                pos = next;
                continue;
            }
            int flags = u16(h, 6);
            int method = u16(h, 8);
            long crc = i32(h, 14) & 0xffffffffL;
            long csize = i32(h, 18) & 0xffffffffL;
            long size = i32(h, 22) & 0xffffffffL;
            int nameLen = u16(h, 26);
            int extraLen = u16(h, 28);
            if (pos + 30 + nameLen > length) break;
            byte[] nb = new byte[nameLen];
            readFully(pos + 30, nb, 0, nameLen);
            String name = decodeName(nb, 0, nameLen, (flags & 0x800) != 0);
            long dataStart = pos + 30 + nameLen + extraLen;
            if ((flags & 0x8) != 0 && csize == 0) {
                // sizes are in a trailing data descriptor; only a stored entry cannot be measured, so skip it
                long next = findSig(dataStart);
                if (name != null && !name.isEmpty() && method == DEFLATED && next > dataStart) {
                    csize = next - dataStart;
                    // strip a trailing descriptor (optional signature + 12 bytes) when present
                    byte[] d = new byte[16];
                    long dpos = next - 16;
                    if (dpos >= dataStart && tryRead(dpos, d, 16) && i32(d, 0) == 0x08074b50) csize -= 16;
                    else if (next - 12 >= dataStart) csize -= 12;
                    size = -1;
                    addScanned(name, method, crc, csize, size, pos);
                } else {
                    skipped++;
                }
                pos = next < 0 ? length : next;
                continue;
            }
            if (name == null || name.isEmpty() || dataStart + csize > length) {
                skipped++;
            } else {
                addScanned(name, method, crc, csize, size, pos);
            }
            pos = dataStart + csize;
        }
    }

    private void addScanned(String name, int method, long crc, long csize, long size, long lho) {
        if (byName.containsKey(name)) return;
        Entry en = new Entry(name, method, crc, csize, size, lho);
        list.add(en);
        byName.put(name, en);
    }

    private long findSig(long from) throws IOException {
        byte[] buf = new byte[1 << 16];
        long pos = from;
        while (pos + 4 <= length) {
            int n = (int) Math.min(buf.length, length - pos);
            readFully(pos, buf, 0, n);
            for (int i = 0; i + 4 <= n; i++) {
                if (buf[i] == 'P' && buf[i + 1] == 'K' && ((buf[i + 2] == 3 && buf[i + 3] == 4) || (buf[i + 2] == 1 && buf[i + 3] == 2)))
                    return pos + i;
            }
            if (n < 4) break;
            pos += n - 3;
        }
        return -1;
    }

    // ------------------------------------------------------------------ reading entry data
    public InputStream getInputStream(Entry e) throws IOException {
        if (e == null) throw new IOException("No such entry");
        byte[] h = new byte[30];
        readFully(e.localOffset, h, 0, 30);
        if (i32(h, 0) != SIG_LOC) throw new IOException("Bad local header for " + e.name);
        long dataStart = e.localOffset + 30 + u16(h, 26) + u16(h, 28);
        long csize = e.csize;
        if (dataStart > length) throw new EOFException("Entry starts past end of file: " + e.name);
        if (csize < 0 || dataStart + csize > length) csize = length - dataStart; // damaged size: read what exists
        if (e.method == STORED) return new Bounded(dataStart, csize);
        if (e.method == DEFLATED) return new Inflating(new Bounded(dataStart, csize), e.size);
        throw new IOException("Unsupported compression method " + e.method + " for " + e.name);
    }

    public byte[] readAll(Entry e) throws IOException {
        try (InputStream in = getInputStream(e)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream((int) Math.max(32, Math.min(e.size, 1 << 24)));
            byte[] buf = new byte[16384];
            int r;
            while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
            return bo.toByteArray();
        }
    }

    /** Reads bytes [start, start+len) of the file through positional reads (safe across threads). */
    private final class Bounded extends InputStream {
        private long pos;
        private final long end;

        Bounded(long start, long len) {
            pos = start;
            end = start + len;
        }

        @Override public int read() throws IOException {
            byte[] b = new byte[1];
            int r = read(b, 0, 1);
            return r < 0 ? -1 : (b[0] & 0xff);
        }

        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (len == 0) return 0;
            if (pos >= end) return -1;
            int n = (int) Math.min(len, end - pos);
            int r = ch.read(ByteBuffer.wrap(b, off, n), pos);
            if (r <= 0) return -1;
            pos += r;
            return r;
        }

        @Override public int available() { return (int) Math.min(Integer.MAX_VALUE, end - pos); }
    }

    private static final class Inflating extends InputStream {
        private final InputStream src;
        private final Inflater inf = new Inflater(true);
        private final byte[] in = new byte[1 << 14];
        private boolean done;

        Inflating(InputStream src, long expected) { this.src = src; }

        @Override public int read() throws IOException {
            byte[] b = new byte[1];
            int r = read(b, 0, 1);
            return r < 0 ? -1 : (b[0] & 0xff);
        }

        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (len == 0) return 0;
            if (done) return -1;
            try {
                int n;
                while ((n = inf.inflate(b, off, len)) == 0) {
                    if (inf.finished() || inf.needsDictionary()) { done = true; return -1; }
                    if (inf.needsInput()) {
                        int r = src.read(in, 0, in.length);
                        if (r < 0) { done = true; return -1; } // truncated stream: return what we got
                        inf.setInput(in, 0, r);
                    }
                }
                return n;
            } catch (DataFormatException ex) {
                throw new IOException("Corrupt compressed data: " + ex.getMessage(), ex);
            }
        }

        @Override public void close() throws IOException {
            inf.end();
            src.close();
        }
    }

    // ------------------------------------------------------------------ small helpers
    private void readFully(long pos, byte[] b, int off, int len) throws IOException {
        ByteBuffer bb = ByteBuffer.wrap(b, off, len);
        long p = pos;
        while (bb.hasRemaining()) {
            int r = ch.read(bb, p);
            if (r < 0) throw new EOFException("Unexpected end of file");
            p += r;
        }
    }

    private boolean tryRead(long pos, byte[] b, int len) {
        try {
            if (pos < 0 || pos + len > length) return false;
            readFully(pos, b, 0, len);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private static String decodeName(byte[] b, int off, int len, boolean utf8Flag) {
        if (len <= 0) return null;
        for (int i = 0; i < len; i++) if (b[off + i] == 0) return null;
        String s = new String(b, off, len, StandardCharsets.UTF_8);
        if (s.indexOf('\uFFFD') >= 0) s = new String(b, off, len, StandardCharsets.ISO_8859_1);
        return s;
    }

    private static int u16(byte[] b, int o) { return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8); }

    private static int i32(byte[] b, int o) {
        return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8) | ((b[o + 2] & 0xff) << 16) | ((b[o + 3] & 0xff) << 24);
    }

    private static long i64(byte[] b, int o) {
        return (i32(b, o) & 0xffffffffL) | ((long) i32(b, o + 4) << 32);
    }
}
