package com.chanit.featuremerger;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** The "Installed" tab: every app on the phone, with a button that copies it into this app. */
final class InstalledAdapter extends RecyclerView.Adapter<InstalledAdapter.VH> {
    static final class Item {
        String label, pkg, version;
        long size;
        boolean system, split;
        ApplicationInfo ai;
        volatile boolean busy;
    }

    interface Listener {
        void onAdd(Item it);
        boolean isAdded(Item it);
    }

    private final List<Item> shown = new ArrayList<>();
    private final Listener listener;
    private final PackageManager pm;
    private final LruCache<String, Drawable> icons = new LruCache<>(150);

    InstalledAdapter(PackageManager pm, Listener l) {
        this.pm = pm;
        this.listener = l;
    }

    void setItems(List<Item> items) {
        shown.clear();
        shown.addAll(items);
        notifyDataSetChanged();
    }

    static final class VH extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView name, pkg, meta;
        final MaterialButton add;

        VH(View v) {
            super(v);
            icon = v.findViewById(R.id.ivIcon);
            name = v.findViewById(R.id.tvName);
            pkg = v.findViewById(R.id.tvPkg);
            meta = v.findViewById(R.id.tvMeta);
            add = v.findViewById(R.id.btnAdd);
        }
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_installed, p, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        final Item it = shown.get(pos);
        h.name.setText(it.label);
        h.pkg.setText(it.pkg);
        StringBuilder m = new StringBuilder();
        if (it.version != null) m.append('v').append(it.version).append("  |  ");
        m.append(String.format(Locale.US, "%.1f MB", it.size / 1048576.0));
        if (it.system) m.append("  |  system");
        if (it.split) m.append("  |  split apks");
        h.meta.setText(m.toString());

        Drawable d = icons.get(it.pkg);
        if (d == null) {
            try {
                d = it.ai.loadIcon(pm);
                if (d != null) icons.put(it.pkg, d);
            } catch (Throwable ignored) { }
        }
        if (d != null) h.icon.setImageDrawable(d); else h.icon.setImageResource(R.drawable.ic_launcher);

        final boolean added = listener.isAdded(it);
        h.add.setText(it.busy ? "Adding..." : added ? "Added" : "Add");
        h.add.setEnabled(!it.busy && !added);
        h.add.setOnClickListener(v -> listener.onAdd(it));
    }

    @Override public int getItemCount() { return shown.size(); }
}
