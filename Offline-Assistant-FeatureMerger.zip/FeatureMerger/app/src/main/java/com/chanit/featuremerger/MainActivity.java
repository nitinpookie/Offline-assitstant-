package com.chanit.featuremerger;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chanit.featuremerger.core.ApkAnalyzer;
import com.chanit.featuremerger.core.Model;
import com.chanit.featuremerger.core.Store;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    final ExecutorService exec = Executors.newSingleThreadExecutor();
    final Handler ui = new Handler(Looper.getMainLooper());
    final List<Model.Apk> apks = new ArrayList<>();
    private final StringBuilder logBuf = new StringBuilder();
    private final AtomicInteger pending = new AtomicInteger();
    private Store store;
    private ApkAdapter adapter;
    private View pageApps, pageMerge, pageLog, emptyApps;
    private TextView tvLog, analysisText;
    private ScrollView logScroll;
    private LinearProgressIndicator analysisBar;
    private BottomNavigationView nav;
    MergeController merge;

    private final ActivityResultLauncher<String[]> picker =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), this::onPicked);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        store = new Store(this);
        pageApps = findViewById(R.id.pageApps);
        pageMerge = findViewById(R.id.pageMerge);
        pageLog = findViewById(R.id.pageLog);
        emptyApps = findViewById(R.id.emptyApps);
        tvLog = findViewById(R.id.tvLog);
        logScroll = findViewById(R.id.logScroll);
        analysisBar = findViewById(R.id.analysisBar);
        analysisText = findViewById(R.id.analysisText);
        nav = findViewById(R.id.nav);

        RecyclerView rv = findViewById(R.id.rvApps);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ApkAdapter(apks, new ApkAdapter.Listener() {
            @Override public void onRemove(Model.Apk a) { confirmRemove(a); }
            @Override public void onActivate(Model.Apk a) { openMerge(a); }
        });
        rv.setAdapter(adapter);

        ExtendedFloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> picker.launch(new String[]{"application/vnd.android.package-archive", "application/octet-stream", "*/*"}));

        nav.setOnItemSelectedListener(item -> {
            show(item.getItemId());
            return true;
        });
        findViewById(R.id.btnCopyLog).setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("log", logBuf.toString()));
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnClearLog).setOnClickListener(v -> {
            logBuf.setLength(0);
            tvLog.setText("");
        });
        merge = new MergeController(this);
        refreshAll();

        for (File f : store.listApks()) {
            pending.incrementAndGet();
            exec.execute(() -> loadOne(f));
        }
    }

    private void show(int id) {
        pageApps.setVisibility(id == R.id.nav_apps ? View.VISIBLE : View.GONE);
        pageMerge.setVisibility(id == R.id.nav_merge ? View.VISIBLE : View.GONE);
        pageLog.setVisibility(id == R.id.nav_log ? View.VISIBLE : View.GONE);
    }

    void openMerge(Model.Apk a) {
        nav.setSelectedItemId(R.id.nav_merge);
        merge.select(a);
    }

    void refreshAll() {
        emptyApps.setVisibility(apks.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
        if (merge != null) merge.refresh();
    }

    // ------------------------------------------------------------------ importing
    private void onPicked(List<Uri> uris) {
        if (uris == null) return;
        for (Uri u : uris) {
            pending.incrementAndGet();
            exec.execute(() -> importUri(u));
        }
    }

    private String displayName(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) { }
        return "app.apk";
    }

    private void importUri(Uri u) {
        try {
            File out = store.uniqueFile(displayName(u));
            try (InputStream in = getContentResolver().openInputStream(u); FileOutputStream o = new FileOutputStream(out)) {
                byte[] buf = new byte[1 << 16];
                int r;
                while (in != null && (r = in.read(buf)) > 0) o.write(buf, 0, r);
            }
            log("Imported " + out.getName());
            loadOne(out);
        } catch (Throwable t) {
            log("Import failed:\n" + android.util.Log.getStackTraceString(t));
            done();
        }
    }

    private void loadOne(File f) {
        Model.Apk a = store.loadCached(f);
        if (a == null) {
            try {
                a = ApkAnalyzer.analyze(this, f, (p, m) -> progress(p, f.getName() + ": " + m));
                store.save(a);
                log("Analyzed " + a.label + ": " + a.features.size() + " overlay feature(s), " + a.hidden.size() + " switched-off item(s)");
            } catch (Throwable t) {
                log("Could not read " + f.getName() + ":\n" + android.util.Log.getStackTraceString(t));
                //noinspection ResultOfMethodCallIgnored
                f.delete();
                done();
                ui.post(() -> Toast.makeText(this, "Not a readable APK: " + f.getName(), Toast.LENGTH_LONG).show());
                return;
            }
        }
        final Model.Apk fa = a;
        ui.post(() -> {
            apks.add(fa);
            refreshAll();
        });
        done();
    }

    private void progress(int p, String msg) {
        ui.post(() -> {
            analysisBar.setVisibility(View.VISIBLE);
            analysisText.setVisibility(View.VISIBLE);
            analysisBar.setProgress(p);
            analysisText.setText(msg);
        });
    }

    private void done() {
        if (pending.decrementAndGet() <= 0) ui.post(() -> {
            analysisBar.setVisibility(View.GONE);
            analysisText.setVisibility(View.GONE);
        });
    }

    private void confirmRemove(Model.Apk a) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Remove " + a.label + "?")
                .setMessage("Only the imported copy inside this app is deleted.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove", (d, w) -> {
                    store.delete(a);
                    apks.remove(a);
                    refreshAll();
                }).show();
    }

    // ------------------------------------------------------------------ log
    void log(String line) {
        String stamp = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        ui.post(() -> {
            logBuf.append(stamp).append("  ").append(line).append('\n');
            if (logBuf.length() > 200000) logBuf.delete(0, 50000);
            tvLog.setText(logBuf.toString());
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
    }
}
