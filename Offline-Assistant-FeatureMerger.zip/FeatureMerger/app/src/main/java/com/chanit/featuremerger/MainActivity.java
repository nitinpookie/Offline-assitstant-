package com.chanit.featuremerger;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chanit.featuremerger.core.ApkAnalyzer;
import com.chanit.featuremerger.core.ApkImporter;
import com.chanit.featuremerger.core.Model;
import com.chanit.featuremerger.core.Store;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    final ExecutorService exec = Executors.newSingleThreadExecutor();
    final Handler ui = new Handler(Looper.getMainLooper());
    final List<Model.Apk> apks = new ArrayList<>();
    private final StringBuilder logBuf = new StringBuilder();
    private final AtomicInteger pending = new AtomicInteger();
    private Store store;
    private ApkAdapter adapter;
    private final ExecutorService listExec = Executors.newSingleThreadExecutor();
    private View pageApps, pageInstalled, pageMerge, pageLog, emptyApps;
    private InstalledAdapter installedAdapter;
    private final List<InstalledAdapter.Item> allInstalled = new ArrayList<>();
    private EditText etSearch;
    private MaterialSwitch swSystem;
    private TextView tvInstalledCount;
    private CircularProgressIndicator installedLoading;
    private boolean installedLoaded, installedBusy;
    private TextView tvLog, analysisText;
    private ScrollView logScroll;
    private LinearProgressIndicator analysisBar;
    private BottomNavigationView nav;
    MergeController merge;

    private final ActivityResultLauncher<String[]> picker =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), this::onPicked);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        store = new Store(this);
        pageApps = findViewById(R.id.pageApps);
        pageInstalled = findViewById(R.id.pageInstalled);
        pageMerge = findViewById(R.id.pageMerge);
        pageLog = findViewById(R.id.pageLog);
        emptyApps = findViewById(R.id.emptyApps);
        tvLog = findViewById(R.id.tvLog);
        logScroll = findViewById(R.id.logScroll);
        analysisBar = findViewById(R.id.analysisBar);
        analysisText = findViewById(R.id.analysisText);
        nav = findViewById(R.id.nav);

        RecyclerView rv = findViewById(R.id.rvApps);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ApkAdapter(apks, new ApkAdapter.Listener() {
            @Override public void onRemove(Model.Apk a) { confirmRemove(a); }
            @Override public void onActivate(Model.Apk a) { openMerge(a); }
        });
        rv.setAdapter(adapter);

        ExtendedFloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> picker.launch(new String[]{"application/vnd.android.package-archive", "application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"}));

        nav.setOnItemSelectedListener(item -> {
            show(item.getItemId());
            return true;
        });
        setupInstalled();
        findViewById(R.id.btnCopyLog).setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("log", logBuf.toString()));
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnClearLog).setOnClickListener(v -> {
            logBuf.setLength(0);
            tvLog.setText("");
        });
        merge = new MergeController(this);
        refreshAll();

        for (File f : store.listApks()) {
            pending.incrementAndGet();
            exec.execute(() -> loadOne(f));
        }
    }

    private void show(int id) {
        pageApps.setVisibility(id == R.id.nav_apps ? View.VISIBLE : View.GONE);
        pageInstalled.setVisibility(id == R.id.nav_installed ? View.VISIBLE : View.GONE);
        if (id == R.id.nav_installed && !installedLoaded) loadInstalled();
        pageMerge.setVisibility(id == R.id.nav_merge ? View.VISIBLE : View.GONE);
        pageLog.setVisibility(id == R.id.nav_log ? View.VISIBLE : View.GONE);
    }

    void openMerge(Model.Apk a) {
        nav.setSelectedItemId(R.id.nav_merge);
        merge.select(a);
    }

    void refreshAll() {
        emptyApps.setVisibility(apks.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
        if (installedAdapter != null) installedAdapter.notifyDataSetChanged();
        if (merge != null) merge.refresh();
    }

    // ------------------------------------------------------------------ importing
    private void onPicked(List<Uri> uris) {
        if (uris == null) return;
        for (Uri u : uris) {
            pending.incrementAndGet();
            exec.execute(() -> importUri(u));
        }
    }

    private String displayName(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) { }
        return "app.apk";
    }

    private void importUri(Uri u) {
        File tmp = new File(getCacheDir(), "incoming_" + System.nanoTime() + ".bin");
        String name = displayName(u);
        try {
            progress(0, "Reading " + name);
            try (InputStream in = getContentResolver().openInputStream(u); FileOutputStream o = new FileOutputStream(tmp)) {
                byte[] buf = new byte[1 << 16];
                int r;
                while (in != null && (r = in.read(buf)) > 0) o.write(buf, 0, r);
            }
            ApkImporter.Result res = ApkImporter.fromFile(this, tmp, name, store, this::log);
            log("Imported " + res.file.getName() + " (" + res.kind + ")");
            loadOne(res.file, res.notes);
        } catch (Throwable t) {
            log("Import failed (" + name + "):\n" + android.util.Log.getStackTraceString(t));
            done();
            final String msg = t.getMessage() == null ? t.toString() : t.getMessage();
            ui.post(() -> Toast.makeText(this, name + ": " + msg, Toast.LENGTH_LONG).show());
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        }
    }

    private void loadOne(File f) { loadOne(f, null); }

    private void loadOne(File f, List<String> importNotes) {
        Model.Apk a = store.loadCached(f);
        if (a == null) {
            try {
                a = ApkAnalyzer.analyze(this, f, (p, m) -> progress(p, f.getName() + ": " + m));
                if (importNotes != null) a.notes.addAll(0, importNotes);
                store.save(a);
                log("Analyzed " + a.label + ": " + a.features.size() + " overlay feature(s), " + a.hidden.size() + " switched-off item(s)");
            } catch (Throwable t) {
                log("Could not read " + f.getName() + ":\n" + android.util.Log.getStackTraceString(t));
                //noinspection ResultOfMethodCallIgnored
                f.delete();
                done();
                final String why = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
                ui.post(() -> Toast.makeText(this, "Could not read " + f.getName() + ": " + why, Toast.LENGTH_LONG).show());
                return;
            }
        }
        final Model.Apk fa = a;
        ui.post(() -> {
            apks.add(fa);
            refreshAll();
        });
        done();
    }

    // ------------------------------------------------------------------ installed apps tab
    private void setupInstalled() {
        etSearch = findViewById(R.id.etSearch);
        swSystem = findViewById(R.id.swSystem);
        tvInstalledCount = findViewById(R.id.tvInstalledCount);
        installedLoading = findViewById(R.id.installedLoading);
        installedAdapter = new InstalledAdapter(getPackageManager(), new InstalledAdapter.Listener() {
            @Override public void onAdd(InstalledAdapter.Item it) { importInstalled(it); }

            @Override public boolean isAdded(InstalledAdapter.Item it) {
                for (Model.Apk a : apks) if (it.pkg.equals(a.pkg)) return true;
                return false;
            }
        });
        RecyclerView rv = findViewById(R.id.rvInstalled);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(installedAdapter);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { applyInstalledFilter(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        swSystem.setOnCheckedChangeListener((b, on) -> applyInstalledFilter());
    }

    private void loadInstalled() {
        if (installedBusy) return;
        installedBusy = true;
        if (allInstalled.isEmpty()) installedLoading.setVisibility(View.VISIBLE);
        listExec.execute(() -> {
            final List<InstalledAdapter.Item> items = new ArrayList<>();
            try {
                PackageManager pm = getPackageManager();
                for (PackageInfo pi : pm.getInstalledPackages(0)) {
                    ApplicationInfo ai = pi.applicationInfo;
                    if (ai == null || ai.sourceDir == null) continue;
                    InstalledAdapter.Item it = new InstalledAdapter.Item();
                    it.ai = ai;
                    it.pkg = pi.packageName;
                    it.version = pi.versionName;
                    CharSequence l = ai.loadLabel(pm);
                    it.label = l == null || l.length() == 0 ? pi.packageName : l.toString();
                    // an updated preinstalled app (Chrome, YouTube...) behaves like a normal app, so it is not "system" here
                    it.system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                    long size = new File(ai.sourceDir).length();
                    if (ai.splitSourceDirs != null) {
                        it.split = ai.splitSourceDirs.length > 0;
                        for (String sp : ai.splitSourceDirs) size += new File(sp).length();
                    }
                    it.size = size;
                    items.add(it);
                }
                Collections.sort(items, (x, y) -> x.label.compareToIgnoreCase(y.label));
            } catch (Throwable t) {
                log("Could not list installed apps:\n" + android.util.Log.getStackTraceString(t));
            }
            ui.post(() -> {
                installedBusy = false;
                installedLoaded = true;
                installedLoading.setVisibility(View.GONE);
                allInstalled.clear();
                allInstalled.addAll(items);
                applyInstalledFilter();
            });
        });
    }

    private void applyInstalledFilter() {
        if (installedAdapter == null) return;
        String q = etSearch.getText() == null ? "" : etSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        boolean sys = swSystem.isChecked();
        List<InstalledAdapter.Item> out = new ArrayList<>();
        for (InstalledAdapter.Item it : allInstalled) {
            if (it.system && !sys) continue;
            if (!q.isEmpty() && !it.label.toLowerCase(Locale.ROOT).contains(q) && !it.pkg.toLowerCase(Locale.ROOT).contains(q)) continue;
            out.add(it);
        }
        installedAdapter.setItems(out);
        tvInstalledCount.setText(out.size() + (out.size() == 1 ? " app" : " apps"));
    }

    private void importInstalled(InstalledAdapter.Item it) {
        if (it.busy) return;
        it.busy = true;
        installedAdapter.notifyDataSetChanged();
        pending.incrementAndGet();
        exec.execute(() -> {
            try {
                progress(0, "Copying " + it.label);
                ApkImporter.Result res = ApkImporter.fromInstalled(this, it.ai, store, this::log);
                log("Imported " + it.label + " (" + res.kind + ")");
                loadOne(res.file, res.notes);
            } catch (Throwable t) {
                log("Import failed (" + it.label + "):\n" + android.util.Log.getStackTraceString(t));
                done();
                final String msg = t.getMessage() == null ? t.toString() : t.getMessage();
                ui.post(() -> Toast.makeText(this, it.label + ": " + msg, Toast.LENGTH_LONG).show());
            } finally {
                it.busy = false;
                ui.post(() -> installedAdapter.notifyDataSetChanged());
            }
        });
    }

    private void progress(int p, String msg) {
        ui.post(() -> {
            analysisBar.setVisibility(View.VISIBLE);
            analysisText.setVisibility(View.VISIBLE);
            analysisBar.setProgress(p);
            analysisText.setText(msg);
        });
    }

    private void done() {
        if (pending.decrementAndGet() <= 0) ui.post(() -> {
            analysisBar.setVisibility(View.GONE);
            analysisText.setVisibility(View.GONE);
        });
    }

    private void confirmRemove(Model.Apk a) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Remove " + a.label + "?")
                .setMessage("Only the imported copy inside this app is deleted.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove", (d, w) -> {
                    store.delete(a);
                    apks.remove(a);
                    refreshAll();
                }).show();
    }

    // ------------------------------------------------------------------ log
    void log(String line) {
        String stamp = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        ui.post(() -> {
            logBuf.append(stamp).append("  ").append(line).append('\n');
            if (logBuf.length() > 200000) logBuf.delete(0, 50000);
            tvLog.setText(logBuf.toString());
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (installedLoaded) loadInstalled();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
        listExec.shutdown();
    }
}
