# Feature Merger

Android app that reads APKs on the phone (picked from storage **or taken from the apps already installed**) and

* lists every **overlay feature** inside them (floating menus, switches, sliders) with a traffic light:
  green = should work the same after the move, amber = check first, red = probably will not work
* lists everything the developer **switched off** (controls hidden with `visibility=gone/invisible`, disabled
  controls, disabled services/activities/receivers) and lets you **activate** it
* moves chosen features from one APK into another (the **base app**) and, if the base app has a switch menu,
  **adds a matching switch row** to that menu by cloning its last row, so it looks like every other option
* can turn off whole base-app features or hide single controls
* signs the result (v1 + v2) with a key generated on first use and offers Install / Share

Everything runs on the phone, pure Java (no native code, fine on armv7a), no internet needed.

## Build on GitHub (shared Offline-Assistant repo, zip only)

1. Upload `Offline-Assistant-FeatureMerger.zip` into the repo root (keep the name: it must start with `Offline-Assistant`).
2. The repo's existing workflow unpacks the newest such zip, builds it and uploads the artifact
   `Offline-Assistant-APK-run<N>` with `Offline-Assistant-debug.apk` (and `-release.apk`).

## What can be added

| Source | How it is handled |
|---|---|
| `.apk` (any file name, even without extension) | recognised by content, not by name |
| `.xapk`, `.apks`, `.apkm`, any `.zip` that holds `.apk` files | the base apk is picked (no `split=` in its manifest; `universal` / `standalone` sets work too) and the native libraries for this phone's CPU are copied in from the config splits, so you get ONE apk |
| An installed app (**Installed** tab) | base apk + its split apks are combined the same way |
| Re-packed / "optimised" APKs whose zip directory breaks Android's own `ZipFile` | read with the built-in tolerant reader (`SafeZip`) and re-written cleanly |
| `.aab` | rejected with a clear message (an app bundle cannot be installed) |

## Use

1. **APKs** tab: Add APK / bundle (one or more). Tap **Details** to see features, risk colours and switched-off items.
2. **Installed** tab: search the apps on this phone, tap **Add** to copy one in. Turn on *System apps* to list those too.
3. **Merge** tab: pick the base app, tick what to activate / turn off / bring in, press **Build merged APK**.
4. Uninstall the original base app, then Install the merged APK (it is signed with your own key).

## How a moved feature works

The source APK is embedded unchanged in the base APK. A small bridge (extracted from this app's own dex)
loads it with its own code and resources, so the feature behaves like in the original app. A manifest
provider boots the bridge, shim services host the feature's overlay Service, and the cloned menu switch
(found at runtime through its `android:tag`) starts/stops it.

## Known limits

* Features that drive their own app's VPN engine are marked red; the engine cannot be moved.
* Overlays built inside an Activity (not a Service) are listed but cannot be moved yet.
* Only hidden/disabled items that exist in layouts or the manifest are found; flags inside code are not.
* Menus built entirely in code (no layout XML) cannot get a cloned switch; the feature then starts automatically.
* Split bundles: only native libraries are merged from the config splits. Language / screen-density / dynamic-feature splits are left out (the app uses its default resources).
* `.obb` game data inside an `.xapk` is not copied.
* Stripped system apps (no `classes.dex` in the APK) cannot be merged.
* The "Installed" tab needs the `QUERY_ALL_PACKAGES` permission (Android 11+); this is fine for a side-loaded build.
