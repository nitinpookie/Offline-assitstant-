package com.liveedit.agent;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.SystemClock;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Stops links from throwing the user out of the app (browser, Telegram, Play Store ...). Every activity start goes
 * through Instrumentation; we put a thin wrapper there. A blocked link is simply not started: the app carries on
 * as if the start had happened, so nothing crashes. Everything is best effort: if Android refuses the hook,
 * the app is left exactly as it was.
 */
final class Links {
    private static final long START_WINDOW_MS = 30000L;
    private static long t0;
    private static String ownPkg = "";

    private Links() {}

    /** Needed either to redirect outgoing links (Config.links) or just to block this app's own store page
     *  (Config.neverUpdate), so install() is called whenever either is set. */
    static boolean needed() {
        return Config.links != 0 || Config.neverUpdate;
    }

    static void install(String pkg) {
        try {
            Hidden.exempt();
            ownPkg = pkg == null ? "" : pkg;
            t0 = SystemClock.elapsedRealtime();
            Class<?> atc = Class.forName("android.app.ActivityThread");
            Object thread = atc.getMethod("currentActivityThread").invoke(null);
            if (thread == null) return;
            Field f = atc.getDeclaredField("mInstrumentation");
            f.setAccessible(true);
            Instrumentation base = (Instrumentation) f.get(thread);
            if (base == null || base instanceof Hook) return;

            Method m1 = Instrumentation.class.getDeclaredMethod("execStartActivity", Context.class, IBinder.class,
                    IBinder.class, Activity.class, Intent.class, int.class, Bundle.class);
            m1.setAccessible(true);
            Method m2 = null;
            try {
                m2 = Instrumentation.class.getDeclaredMethod("execStartActivity", Context.class, IBinder.class,
                        IBinder.class, String.class, Intent.class, int.class, Bundle.class);
                m2.setAccessible(true);
            } catch (Throwable t) {
                m2 = null;
            }
            Hook hook = new Hook(base, m1, m2);
            copyState(base, hook);
            f.set(thread, hook);
            U.log("link guard installed, mode " + Config.links);
        } catch (Throwable t) {
            U.err("link guard not installed", t);
        }
    }

    /** The wrapper must behave like the original, so its fields are copied over. */
    private static void copyState(Instrumentation from, Instrumentation to) {
        Field[] fs = Instrumentation.class.getDeclaredFields();
        for (int i = 0; i < fs.length; i++) {
            try {
                Field f = fs[i];
                if (Modifier.isStatic(f.getModifiers())) continue;
                f.setAccessible(true);
                f.set(to, f.get(from));
            } catch (Throwable t) {
                // a field that cannot be copied is not needed for starting activities
            }
        }
    }

    static boolean shouldBlock(Intent intent) {
        try {
            if (intent == null) return false;
            if (Config.neverUpdate && isOwnStorePage(intent)) {
                U.log("blocked this app's own Play Store page (never update)");
                return true;
            }
            if (Config.links == 0) return false;
            if (Config.links == 1 && SystemClock.elapsedRealtime() - t0 > START_WINDOW_MS) return false;
            String a = intent.getAction();
            if (a != null && !Intent.ACTION_VIEW.equals(a)) return false;
            if (intent.getComponent() != null && ownPkg.equals(intent.getComponent().getPackageName())) return false;
            if (ownPkg.equals(intent.getPackage())) return false;
            Uri d = intent.getData();
            if (d == null) return false;
            String s = d.getScheme();
            if (s == null) return false;
            s = s.toLowerCase(java.util.Locale.US);
            boolean out = s.equals("http") || s.equals("https") || s.equals("tg") || s.equals("market")
                    || s.equals("intent") || s.equals("whatsapp") || s.equals("fb") || s.equals("instagram")
                    || s.equals("vnd.youtube") || s.equals("youtube") || s.equals("mailto") || s.equals("tel");
            if (out) U.log("blocked link: " + d);
            return out;
        } catch (Throwable t) {
            return false;
        }
    }

    /** The intent opens THIS app's own page on the Play Store / a market app (its "Update" button). */
    private static boolean isOwnStorePage(Intent intent) {
        Uri d = intent.getData();
        if (d == null) return false;
        String s = d.getScheme();
        if (s == null) return false;
        s = s.toLowerCase(java.util.Locale.US);
        String id = d.getQueryParameter("id");
        if (id == null) id = d.getLastPathSegment();
        boolean ownId = ownPkg.length() > 0 && ownPkg.equals(id);
        if (s.equals("market")) return ownId || id == null; // market://details with no id still means this app
        if (s.equals("http") || s.equals("https")) {
            String host = d.getHost();
            return host != null && host.toLowerCase(java.util.Locale.US).endsWith("play.google.com") && ownId;
        }
        return false;
    }

    private static Object call(Method m, Object target, Object... args) {
        try {
            return m.invoke(target, args);
        } catch (InvocationTargetException e) {
            Throwable c = e.getCause();
            if (c instanceof RuntimeException) throw (RuntimeException) c;
            if (c instanceof Error) throw (Error) c;
            throw new RuntimeException(c);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    static final class Hook extends Instrumentation {
        private final Instrumentation base;
        private final Method m1;
        private final Method m2;

        Hook(Instrumentation base, Method m1, Method m2) {
            this.base = base;
            this.m1 = m1;
            this.m2 = m2;
        }

        // These two exist in Android but are hidden from the public SDK, so they cannot be marked @Override.
        public ActivityResult execStartActivity(Context who, IBinder contextThread, IBinder token, Activity target,
                                                Intent intent, int requestCode, Bundle options) {
            if (shouldBlock(intent)) return null;
            return (ActivityResult) call(m1, base, who, contextThread, token, target, intent, requestCode, options);
        }

        public ActivityResult execStartActivity(Context who, IBinder contextThread, IBinder token, String target,
                                                Intent intent, int requestCode, Bundle options) {
            if (shouldBlock(intent)) return null;
            if (m2 == null) return null;
            return (ActivityResult) call(m2, base, who, contextThread, token, target, intent, requestCode, options);
        }
    }
}
