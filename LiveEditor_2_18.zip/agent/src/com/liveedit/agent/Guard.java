package com.liveedit.agent;

import android.os.Looper;

/**
 * Best-effort "do not crash on an edit". Two kinds of trouble are caught on the main thread and the app is kept
 * running instead of closing:
 *  - a missing native library (see "Make it run on my phone": libraries the app's CPU cannot use are replaced by
 *    empty stand-ins, so a call into one fails with UnsatisfiedLinkError);
 *  - any other crash that happens after the app has been running for a couple of seconds, which is most likely one
 *    of this tool's own edits (a renamed text, a resized view, a removed window ...) rather than something the app
 *    would have crashed on anyway.
 * A crash in the first two seconds (before Config/EditGuard settle in) is passed on untouched, so a genuine startup
 * problem is not hidden. A crash that keeps looping is also passed on, so a broken app still closes instead of
 * freezing. This cannot catch a crash on a background thread that has no exception handler of its own, a hard
 * native crash, or the app calling System.exit() / Process.killProcess() itself.
 */
final class Guard {
    private static boolean installed;
    private static int swallowed;
    private static long windowStart;
    private static long startedAt;

    private Guard() {}

    static synchronized void install() {
        if (installed) return;
        installed = true;
        startedAt = android.os.SystemClock.uptimeMillis();
        try {
            final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                @Override
                public void uncaughtException(Thread t, Throwable e) {
                    if (!recoverable(e) || !allow()) {
                        pass(prev, t, e);
                        return;
                    }
                    U.err(isMissingLibrary(e) ? "native library missing on this CPU, app carries on"
                            : "a crash was caught, app carries on", e);
                    Looper main = Looper.getMainLooper();
                    if (main == null || t != main.getThread()) return; // only that one worker thread ends
                    // The main thread must keep serving the screen: start its message loop again.
                    while (true) {
                        try {
                            Looper.loop();
                            return;
                        } catch (Throwable x) {
                            if (!recoverable(x) || !allow()) {
                                pass(prev, Thread.currentThread(), x);
                                return;
                            }
                            U.err(isMissingLibrary(x) ? "native library missing on this CPU, app carries on"
                                    : "a crash was caught, app carries on", x);
                        }
                    }
                }
            });
            U.log("native library guard installed");
        } catch (Throwable t) {
            U.err("native library guard not installed", t);
        }
    }

    /** A missing library is always caught; any other crash is caught only once the app has settled in a little,
     *  so a real startup problem (nothing to do with an edit) still shows as a crash. */
    private static boolean recoverable(Throwable e) {
        if (isMissingLibrary(e)) return true;
        return android.os.SystemClock.uptimeMillis() - startedAt > 2000L;
    }

    private static void pass(Thread.UncaughtExceptionHandler prev, Thread t, Throwable e) {
        if (prev != null) {
            prev.uncaughtException(t, e);
        } else {
            System.exit(10);
        }
    }

    /** UnsatisfiedLinkError anywhere in the cause chain, or a class that could not start because of it. */
    private static boolean isMissingLibrary(Throwable e) {
        int depth = 0;
        Throwable c = e;
        while (c != null && depth < 10) {
            if (c instanceof UnsatisfiedLinkError) return true;
            if (c instanceof NoClassDefFoundError) {
                String m = c.getMessage();
                if (m != null && m.contains("Could not initialize class")) return true;
            }
            c = c.getCause();
            depth++;
        }
        return false;
    }

    /** At most 40 swallowed errors in 10 seconds, so a crash loop still ends the app. */
    private static synchronized boolean allow() {
        long now = System.currentTimeMillis();
        if (now - windowStart > 10000L) {
            windowStart = now;
            swallowed = 0;
        }
        swallowed++;
        return swallowed <= 40;
    }
}
