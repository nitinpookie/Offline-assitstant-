package com.liveedit.agent;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * "Auto-off timer: never" for one button. After the button is touched, every DELAYED job the app's own code puts on the
 * main thread's queue (Handler.postDelayed, View.postDelayed, a Handler message with a delay, a CountDownTimer tick)
 * is taken out of the queue again, so a button that switches itself off after a few seconds simply never does: it
 * changes only when you press it.
 *
 * How it stays safe:
 * - only jobs that are NEW since the finger touched down are looked at (what the app already had waiting is left alone);
 * - only jobs of the app's own classes (and Kotlin coroutine delays) with a delay between 0.3 and 6 seconds, or a
 *   CountDownTimer, are cancelled; Android's and other libraries' jobs are never touched;
 * - it only runs for a couple of seconds after a touch of that one button.
 * A timer kept in another thread (java.util.Timer, Thread.sleep, an executor) is not in the queue: for that use the
 * Live Editor patch card "Button that turns itself off, and its beep".
 */
final class Manual {
    private static final long MIN_REMAIN_MS = 300L;
    private static final long MAX_REMAIN_MS = 6000L;
    private static final long WATCH_MS = 2600L;

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static Field fMessages, fWhen, fNext, fTarget, fCallback, fWhat;
    private static Method mGetQueue;
    private static boolean failed;

    private static HashSet<String> before = new HashSet<String>();
    private static long until;
    private static boolean scanning;

    private Manual() {}

    private static final class Pend {
        Object msg;
        Object prev;
        Handler target;
        Runnable callback;
        int what;
        long when;
        String key;
    }

    /** Called for every touch event of a button that has "Auto-off timer: never". */
    static void touch(int action) {
        if (failed) return;
        try {
            if (action == android.view.MotionEvent.ACTION_DOWN) {
                before = keys(list());
            }
            if (action == android.view.MotionEvent.ACTION_DOWN || action == android.view.MotionEvent.ACTION_UP) {
                until = SystemClock.uptimeMillis() + WATCH_MS;
                if (!scanning) {
                    scanning = true;
                    H.postDelayed(SCAN, 60);
                }
            }
        } catch (Throwable t) {
            failed = true;
            U.err("manual touch", t);
        }
    }

    private static final Runnable SCAN = new Runnable() {
        @Override
        public void run() {
            try {
                cancelNew();
            } catch (Throwable t) {
                failed = true;
                U.err("manual scan", t);
                scanning = false;
                return;
            }
            if (SystemClock.uptimeMillis() < until) {
                H.postDelayed(this, 90);
            } else {
                scanning = false;
            }
        }
    };

    private static HashSet<String> keys(ArrayList<Pend> all) {
        HashSet<String> s = new HashSet<String>();
        for (int i = 0; i < all.size(); i++) s.add(all.get(i).key);
        return s;
    }

    /** Everything waiting in the main queue, as plain data (the Message objects themselves are reused by Android). */
    private static ArrayList<Pend> list() throws Exception {
        ArrayList<Pend> out = new ArrayList<Pend>();
        if (fMessages == null) {
            Class<?> mq = Class.forName("android.os.MessageQueue");
            Class<?> msg = Class.forName("android.os.Message");
            fMessages = mq.getDeclaredField("mMessages");
            fMessages.setAccessible(true);
            fWhen = msg.getDeclaredField("when");
            fWhen.setAccessible(true);
            fNext = msg.getDeclaredField("next");
            fNext.setAccessible(true);
            fTarget = msg.getDeclaredField("target");
            fTarget.setAccessible(true);
            fCallback = msg.getDeclaredField("callback");
            fCallback.setAccessible(true);
            fWhat = msg.getDeclaredField("what");
            fWhat.setAccessible(true);
            mGetQueue = Looper.class.getMethod("getQueue");
        }
        Object queue = mGetQueue.invoke(Looper.getMainLooper());
        synchronized (queue) {
            Object prev = null;
            Object m = fMessages.get(queue);
            int guard = 0;
            while (m != null && guard++ < 3000) {
                Pend p = new Pend();
                p.msg = m;
                p.prev = prev;
                p.when = fWhen.getLong(m);
                p.target = (Handler) fTarget.get(m);
                p.callback = (Runnable) fCallback.get(m);
                p.what = fWhat.getInt(m);
                p.key = System.identityHashCode(p.target) + ":" + System.identityHashCode(p.callback) + ":" + p.what
                        + ":" + p.when;
                out.add(p);
                prev = m;
                m = fNext.get(m);
            }
        }
        return out;
    }

    /** The app's own code (and Kotlin coroutine delays), not Android or another library. */
    private static boolean appOwned(Class<?> c) {
        if (c == null) return false;
        String n = c.getName();
        if (n.startsWith("kotlinx.coroutines")) return true;
        return !(n.startsWith("android.") || n.startsWith("androidx.") || n.startsWith("java.")
                || n.startsWith("javax.") || n.startsWith("kotlin.") || n.startsWith("dalvik.")
                || n.startsWith("com.android.") || n.startsWith("com.google.") || n.startsWith("com.liveedit.")
                || n.startsWith("org.chromium.") || n.startsWith("com.facebook.") || n.startsWith("com.unity3d.ads"));
    }

    private static void cancelNew() throws Exception {
        long now = SystemClock.uptimeMillis();
        ArrayList<Pend> all = list();
        HashSet<Runnable> doneCb = new HashSet<Runnable>();
        for (int i = 0; i < all.size(); i++) {
            Pend p = all.get(i);
            if (before.contains(p.key) || p.target == null) continue;
            long remain = p.when - now;
            // a CountDownTimer that started after the touch: stop the whole timer
            Class<?> tc = p.target.getClass();
            if (p.callback == null && tc.getName().startsWith("android.os.CountDownTimer")) {
                try {
                    Field outer = tc.getDeclaredField("this$0");
                    outer.setAccessible(true);
                    Object cdt = outer.get(p.target);
                    if (cdt != null) cdt.getClass().getMethod("cancel").invoke(cdt);
                } catch (Throwable t) {
                    p.target.removeMessages(p.what);
                }
                continue;
            }
            if (remain < MIN_REMAIN_MS || remain > MAX_REMAIN_MS) continue;
            if (p.callback != null) {
                if (!appOwned(p.callback.getClass()) || doneCb.contains(p.callback)) continue;
                doneCb.add(p.callback);
                p.target.removeCallbacks(p.callback);
            } else if (appOwned(tc)) {
                p.target.removeMessages(p.what);
            }
        }
    }
}
