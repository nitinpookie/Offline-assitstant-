package com.liveedit.agent;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.SystemClock;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.WeakHashMap;

/**
 * Origin lines: a PNG marker on the end of every line, and an optional "lock" that makes the lines stick to their
 * targets like head-tracked objects in VR.
 *
 * How it works (no change to the app's code):
 * - The app draws its lines itself on a canvas. Right before every frame (the same moment the window is already
 *   checked for size / opacity) the view that draws them is drawn ONE extra time onto a recording canvas that does
 *   not paint anything, only writes down every line (start, end, paint) it is asked to draw.
 * - The origin is the point that most lines share. Every line has two ends; the one that is not the origin is the
 *   end that gets the marker. The marker is never rotated: it stays upright (tip down) wherever the line goes.
 * - Without the lock, a small drawable in the view's overlay paints the marker after the app has drawn its lines,
 *   in that same frame.
 *
 * Lock (like VR reprojection): the app reports where the targets are only now and then, so while you swipe the lines
 * step. In lock mode the app's own line drawing is hidden (view alpha ~0) and the lines are drawn again on our own
 * transparent layer at EVERY screen refresh. Between two reports each line end is moved along its recent speed
 * (dead reckoning, an alpha-beta filter on irregular samples); when a new report arrives the picture is blended to it
 * with a short exponential correction, never a jump. A line the app misses for a frame or two is kept for a moment, so
 * it does not blink. Prediction, blending and hold time tune themselves from the measured gap between the app's reports.
 */
final class LineTips {
    private static final String BUILTIN_B64 =
            "iVBORw0KGgoAAAANSUhEUgAAAB0AAAAYCAYAAAAGXva8AAAEYElEQVR42rWWf0xWZRTHv+fcFw2bioQ4qVSy2DC0SPu5cmtWaDM2"
            + "cbxrpnPmcGM2araW5AzfmbPQNCttJgZZLseVZLKiYAoqUjr74RSCHPgLTFHAF15+3Pfe5zn98b64V8IYgt/t7Nm99zzPc87u55zn"
            + "IQRkAJgAYBQAwdCLAPgAnAfguJgZWuvJq1ev/X7evOR7oQEioYDfICUCAQkZJAV7C698sG7tq8zqpEspRUR04fEZj3kTE6c93NrY"
            + "Bm0LiGnQOYsIyAAi7x+N+rr6esCuU0rI5Xa7mYi613+48Z3ExEfKR46I4AuX/iGXy6BBbUqAYyuZEDtOGi42SvaGTZlE5HO73YbL"
            + "NE0lIkxElYX79ue9kZGeFt5yt+rsspiZby9bArQWDA8fpseMHWl8vSlv97Fjh0uD+6ieH8ciIkQU8+fvJ3+LT0iIPlF9VsJcLr6d"
            + "TYkAy2/L9CmxqKk63frUMzOf6O721hOtIcCjOeinATCAxp2536wzoCk6KkI6tIKfBdYAzM8Cn1a4J2q0HmaAcnJyN1pWW11gfY/u"
            + "QflGgIFkKezHouKKOXNnzzhQVa/BxITerrdEBwCglNYvJkzm4qKfTr+cPOdpEekkIulx4NAZbrdJzGxlb9my8urlJhV3XzTalSM2"
            + "AxZJv2Yz0K4cPBgzFteuXJUNmz9Zxcw+0zQptP5doXGaprsHqgN7Cwq/S1++bGFt83DV5rcNF/UPsxZB+F3DVGzkKOOLrV/uKyv7"
            + "eX8PPKF+Ru+JHg9IpBzPzZz1x/zk5EVxkyeNqGpuBrkMckigCH2aJkKHcmRm7AQ0VNf6UhcvWeBYnVdFhA4dOnRTvPzfeD0aAFuW"
            + "9+z2r/KyxzDTxMgI3S4KNgH+PswmwCcKMaNH6rFhYbw9d9envpbL1Uopw+MJwNO7J/ZJfRCq8NLi0l+en/3C1J01NTpQuL1mSbAR"
            + "OEoviY/noyUHz8xKmvWkiFwnIvTVy/lWGJqmSczUkb1py6q2pmsyPToazd1dsJSDLttGlx0YLeWgpasL06KiYLd68fHn27KIqNU0"
            + "Tb7V4UH99E4mIr19W07BsvSlKduqq9R12zbCQqBSIgg3DPVWwlQjN2dXyetpi+eICEJLpLeM/ppLRcURqag8dmr+3LmL4mInDa9o"
            + "bAAzkV8rKBF4uy1JfSgOvnMXu19LS1vY2e691Bc8Az0pDABYsWKlR0RkR81fTkblEXnv+K/yZmWFfHb6lCMisipzzeZQ/0EfwCLC"
            + "ACLKSspqvVpL+uEylXH0iCwrP6iabFtXlh89DyBaROh/OBmY8vPzDSJCUtIr7o6W61J47qx6qahQ7z7zt7J9nZKSsmApESE/P98Y"
            + "0utGMFvOy9n1g4jIRyeO+x0R2fPtnsMAwoLfaUgvOVlZWczMiImZ+GjVqWqfiDh1Z+qsKVOmPcvMSE1NHdIsbyohAFi+/O31dfXn"
            + "JDPz/a2h7++UKAjLmPHjH3gXwLjgM+FOK9jebowD1b8xmXHSM2iU3QAAAABJRU5ErkJggg==";

    private static final int MAX = 96;
    /** The line view is kept at this alpha while locked: invisible, but not 0 (some Android versions skip alpha 0). */
    private static final float LOCK_ALPHA = 0.004f;

    private LineTips() {}

    // ---- gliding of one point (smooth catch-up on sparse, irregular reports) ---------------------

    /**
     * One 2D point that the app reports now and then. Measured on a real app: about 10 reports a second, 15 - 400 ms apart,
     * big jumps while swiping, then standing still. Guessing where the point goes next (dead reckoning) overshoots there
     * and is worse than not filtering at all. So this does not guess: the point GLIDES to every new report with a short
     * time constant (a small lag, never a jump, never an overshoot), ignores the app's own shake of a pixel or two, and
     * snaps at once when the picture jumps (a target that goes behind you, a camera cut).
     */
    static final class Pt {
        /** px: the app's own shake. A report that moved less than this from the last accepted one is not followed. */
        private static final float DEAD = 2.5f;
        /** px: a report further than this from the last one is a jump of the picture: no gliding (set from dp). */
        static float snapPx = 600f;

        float rx, ry;       // last report (raw)
        float tx, ty;       // where the point glides to (last accepted report)
        float sx, sy;       // where the point was shown at 'ts'
        long ts, lastRep;
        float dtAvg = 60f;  // average gap between two reports in a row, ms
        boolean init;

        void reset(float x, float y, long t) {
            rx = x;
            ry = y;
            tx = x;
            ty = y;
            sx = x;
            sy = y;
            ts = t;
            lastRep = t;
            dtAvg = 60f;
            init = true;
        }

        /** Everything tunes itself from dtAvg, the measured gap between the app's reports. No settings. */
        private float tau() {
            return Math.max(25f, Math.min(70f, 0.4f * dtAvg)); // ms the point needs to catch up with a new report
        }

        /** ms a line the app missed is kept (so it does not blink). */
        long hold() {
            return (long) Math.max(60f, Math.min(260f, 1.8f * dtAvg));
        }

        /** A new report at time t. */
        void sample(float zx, float zy, long t) {
            if (!init) {
                reset(zx, zy, t);
                return;
            }
            // the app draws the numbers of its last report again on every frame: that is not a new report
            if (Math.abs(zx - rx) < 0.05f && Math.abs(zy - ry) < 0.05f) return;
            float[] cur = new float[2];
            at(t, cur); // what is on screen right now: the glide starts from there, so nothing jumps
            sx = cur[0];
            sy = cur[1];
            ts = t;
            float gap = t - lastRep;
            if (gap > 0f && gap <= 400f) dtAvg = dtAvg * 0.8f + gap * 0.2f;
            lastRep = t;
            rx = zx;
            ry = zy;
            float jump = (float) Math.hypot(zx - tx, zy - ty);
            if (jump > snapPx) {
                sx = zx;
                sy = zy;
                tx = zx;
                ty = zy;
            } else if (jump >= DEAD) {
                tx = zx;
                ty = zy;
            }
        }

        /** Where the point is shown at time t: out[0], out[1]. */
        void at(long t, float[] out) {
            if (!init) {
                out[0] = rx;
                out[1] = ry;
                return;
            }
            float k = 1f - (float) Math.exp(-Math.max(0L, t - ts) / (double) tau());
            out[0] = sx + (tx - sx) * k;
            out[1] = sy + (ty - sy) * k;
        }
    }

    // ---- data ------------------------------------------------------------------------------

    /** One line the app drew in one frame. */
    private static final class Seg {
        float x0, y0, x1, y1;
        Paint paint;
    }

    /** One origin line of this frame (origin -> end). */
    private static final class Raw {
        float ox, oy, ex, ey;
        Seg src;
    }

    /** One origin line that is followed from frame to frame. */
    private static final class Track {
        final Pt e = new Pt();      // the end (target)
        final Pt o = new Pt();      // the origin
        Paint paint = new Paint();  // the app's paint for this line (colour, width ...)
        long seenAt, repAt;
    }

    private static final class Owner {
        final WeakReference<View> view;
        final Rec rec = new Rec();
        final Raw[] raw = new Raw[MAX];
        int rawN;
        final ArrayList<Track> tracks = new ArrayList<Track>();
        final boolean[] ru = new boolean[MAX];
        final boolean[] tu = new boolean[MAX];
        final float[] refX = new float[MAX], refY = new float[MAX];
        final float[] tmp = new float[4];
        final Pen pen = new Pen();
        float ox, oy;
        boolean haveOrigin;
        Tip tip;
        boolean attached, dead, locked;
        float origAlpha = 1f;
        long recAt, frameAt;
        int fails;
        int viewH = 1;
        float density = 1f;

        Owner(View v) {
            view = new WeakReference<View>(v);
            for (int i = 0; i < MAX; i++) raw[i] = new Raw();
        }
    }

    private static final class RootState {
        final ArrayList<WeakReference<View>> views = new ArrayList<WeakReference<View>>();
        long scanAt;
    }

    private static final WeakHashMap<View, RootState> ROOTS = new WeakHashMap<View, RootState>();
    private static final WeakHashMap<View, Owner> OWNERS = new WeakHashMap<View, Owner>();
    private static final WeakHashMap<View, Boolean> PAINTY = new WeakHashMap<View, Boolean>();

    // ---- recording canvas ------------------------------------------------------------------

    /**
     * A canvas that paints nothing for lines and texts: it writes them down. Everything else the app draws lands on a
     * 1 x 1 bitmap and costs nothing. Width, height and clip bounds are those of the view, so an app that places its
     * lines from canvas.getWidth() gets the same numbers as in the real frame.
     */
    private static final class Rec extends Canvas {
        int w = 1, h = 1, n;
        final Seg[] segs = new Seg[MAX];
        private final Matrix m = new Matrix();
        private final float[] p = new float[4];
        private final PathMeasure pm = new PathMeasure();
        private final float[] pos = new float[2];

        Rec() {
            super(Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8));
            for (int i = 0; i < MAX; i++) segs[i] = new Seg();
        }

        @Override
        public int getWidth() {
            return w;
        }

        @Override
        public int getHeight() {
            return h;
        }

        @Override
        public boolean getClipBounds(Rect r) {
            if (r != null) r.set(0, 0, w, h);
            return true;
        }

        @Override
        public void drawLine(float x0, float y0, float x1, float y1, Paint paint) {
            add(x0, y0, x1, y1, paint);
        }

        @Override
        public void drawLines(float[] pts, int offset, int count, Paint paint) {
            if (pts == null) return;
            for (int i = offset; i + 3 < offset + count && i + 3 < pts.length; i += 4) {
                add(pts[i], pts[i + 1], pts[i + 2], pts[i + 3], paint);
            }
        }

        @Override
        public void drawLines(float[] pts, Paint paint) {
            if (pts != null) drawLines(pts, 0, pts.length, paint);
        }

        @Override
        public void drawPath(Path path, Paint paint) {
            if (path == null || paint == null || paint.getStyle() == Paint.Style.FILL) return;
            try {
                pm.setPath(path, false);
                float len = pm.getLength();
                if (len <= 0.5f) return;
                pm.getPosTan(0f, pos, null);
                float sx = pos[0], sy = pos[1];
                pm.getPosTan(len, pos, null);
                float ex = pos[0], ey = pos[1];
                if ((float) Math.hypot(ex - sx, ey - sy) < len * 0.98f) return; // a curve, not a line
                if (pm.nextContour()) return;
                add(sx, sy, ex, ey, paint);
            } catch (Throwable t) {
                // not a line we can read
            }
        }

        @Override
        public void drawText(String text, float x, float y, Paint paint) {
            // texts are not needed
        }

        @Override
        public void drawText(String text, int start, int end, float x, float y, Paint paint) {
            // texts are not needed
        }

        @Override
        public void drawText(CharSequence text, int start, int end, float x, float y, Paint paint) {
            // texts are not needed
        }

        @Override
        public void drawText(char[] text, int index, int count, float x, float y, Paint paint) {
            // texts are not needed
        }

        private void add(float x0, float y0, float x1, float y1, Paint paint) {
            if (paint == null || n >= MAX) return;
            if (Color.alpha(paint.getColor()) == 0) return;
            p[0] = x0;
            p[1] = y0;
            p[2] = x1;
            p[3] = y1;
            try {
                getMatrix(m);
                m.mapPoints(p);
            } catch (Throwable t) {
                p[0] = x0;
                p[1] = y0;
                p[2] = x1;
                p[3] = y1;
            }
            if (Float.isNaN(p[0]) || Float.isNaN(p[1]) || Float.isNaN(p[2]) || Float.isNaN(p[3])) return;
            Seg s = segs[n++];
            s.x0 = p[0];
            s.y0 = p[1];
            s.x1 = p[2];
            s.y1 = p[3];
            if (s.paint == null) s.paint = new Paint();
            s.paint.set(paint); // the app reuses one Paint: keep what it was at this very line
        }

    }




    // ---- public entry points ---------------------------------------------------------------

    /**
     * Something to do at all. The marker has its own safety (an error while reading a view switches it off for that
     * view only), so it is NOT tied to the edit guard: leaving the app with Back must never switch it off.
     */
    static boolean wanted() {
        return Config.tipOn || Config.lockOn;
    }

    /** A big window (a full screen drawing layer that also holds some texts or pictures). */
    static boolean bigWindow(View root, float density) {
        try {
            android.util.DisplayMetrics dm = root.getResources().getDisplayMetrics();
            return root.getWidth() >= dm.widthPixels * 0.6f && root.getHeight() >= dm.heightPixels * 0.6f;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Called for a window root before each frame (and at the 1 s tick). strict = a line / canvas window. */
    static void frame(View root, float d, boolean strict) {
        try {
            RootState st = ROOTS.get(root);
            if (st == null) {
                st = new RootState();
                ROOTS.put(root, st);
            }
            long now = SystemClock.uptimeMillis();
            // look for the line view again often (the app may swap it when the feature is switched off and on),
            // and at once when the one we know is gone
            int valid = 0;
            for (int i = 0; i < st.views.size(); i++) {
                View v = st.views.get(i).get();
                if (v != null && v.isAttachedToWindow() && v.getWidth() > 0 && v.getHeight() > 0) valid++;
            }
            long gap = valid == 0 ? 120L : 400L;
            if (now - st.scanAt > gap) {
                st.scanAt = now;
                scan(root, st, strict);
            }
            for (int i = 0; i < st.views.size(); i++) {
                View v = st.views.get(i).get();
                if (v == null || !v.isAttachedToWindow() || v.getWidth() <= 0 || v.getHeight() <= 0) continue;
                step(v, d, now);
            }
        } catch (Throwable t) {
            U.err("line tips", t);
        }
    }

    /** The marker is off (or this window is not a drawing layer): take everything away again. */
    static void release(View root) {
        try {
            RootState st = ROOTS.get(root);
            if (st == null) return;
            ROOTS.remove(root);
            for (int i = 0; i < st.views.size(); i++) {
                View v = st.views.get(i).get();
                if (v == null) continue;
                Owner o = OWNERS.get(v);
                if (o != null) detach(v, o);
            }
            maybeDropLayer();
        } catch (Throwable t) {
            U.err("line tips off", t);
        }
    }

    /** A setting (size, picture, scale, range, model, lock) changed: draw again at once. */
    static void refresh() {
        try {
            ArrayList<Owner> all = new ArrayList<Owner>(OWNERS.values());
            for (int i = 0; i < all.size(); i++) {
                View v = all.get(i).view.get();
                if (v != null) v.invalidate();
            }
            if (layer != null) layer.postInvalidateOnAnimation();
        } catch (Throwable t) {
            // ignore
        }
    }






    // ---- lock status ------------------------------------------------------------------------

    /** The Lock switch was turned on again: forget an earlier failure so the lock gets a new try. */
    static void retryLock() {
        layerFailed = false;
        refresh();
    }

    /** One line of text for the panel: is the lock working right now. */
    static String lockStatus() {
        if (!Config.lockOn) return "Lock is OFF: the app draws its own lines.";
        if (layerFailed) {
            return "Lock is ON but could not start: the extra line window was refused. Switch Lock off and on to try again.";
        }
        int locked = 0, lines = 0, views = 0;
        try {
            ArrayList<Owner> all = new ArrayList<Owner>(OWNERS.values());
            for (int i = 0; i < all.size(); i++) {
                Owner o = all.get(i);
                views++;
                if (o.locked) {
                    locked++;
                    lines += o.tracks.size();
                }
            }
        } catch (Throwable t) {
            // ignore
        }
        if (views == 0) return "Lock is ON, waiting for the app's lines: switch the lines on in the app.";
        if (locked == 0) return "Lock is ON, starting...";
        return "Lock is ON: " + lines + (lines == 1 ? " line" : " lines") + " locked.";
    }

    // ---- data recorder: real numbers from the phone, to tune the lock ------------------------------

    private static boolean recOn;
    private static long recStartAt;
    private static final StringBuilder recRows = new StringBuilder();
    private static int recRowN, recFrames, recSlow, recReports, recAlpha, recSteps;
    private static float recFrameMax, recGapMin, recGapMax, recStepMax, recShownMax;
    private static double recFrameSum, recGapSum, recStepSum, recShownSum;

    static boolean recording() {
        return recOn;
    }

    static void recordStart() {
        recRows.setLength(0);
        recRowN = 0;
        recFrames = 0;
        recSlow = 0;
        recReports = 0;
        recAlpha = 0;
        recSteps = 0;
        recFrameMax = 0f;
        recGapMin = 1e9f;
        recGapMax = 0f;
        recStepMax = 0f;
        recShownMax = 0f;
        recFrameSum = 0.0;
        recGapSum = 0.0;
        recStepSum = 0.0;
        recShownSum = 0.0;
        recStartAt = SystemClock.uptimeMillis();
        recOn = true;
    }

    /** One frame of a line view: how evenly the frames come. */
    private static void recFrame(Owner o, long now) {
        if (o.frameAt != 0L) {
            float g = now - o.frameAt;
            if (g > 0f && g < 1000f) {
                recFrames++;
                recFrameSum += g;
                if (g > recFrameMax) recFrameMax = g;
                if (g > 24f) recSlow++;
            }
        }
        o.frameAt = now;
    }

    /** The app drew a line end: when the numbers changed it is a report; note the gap, the step and what is shown now. */
    private static void recReport(int idx, Track t, Raw w, long now) {
        if (Math.abs(w.ex - t.e.rx) < 0.05f && Math.abs(w.ey - t.e.ry) < 0.05f) return;
        float[] sh = new float[2];
        t.e.at(now, sh);
        float shown = (float) Math.hypot(w.ex - sh[0], w.ey - sh[1]);
        float step = (float) Math.hypot(w.ex - t.e.rx, w.ey - t.e.ry);
        recSteps++;
        recStepSum += step;
        if (step > recStepMax) recStepMax = step;
        recShownSum += shown;
        if (shown > recShownMax) recShownMax = shown;
        if (t.repAt != 0L) {
            float gap = now - t.repAt;
            if (gap < 500f) {
                recReports++;
                recGapSum += gap;
                if (gap < recGapMin) recGapMin = gap;
                if (gap > recGapMax) recGapMax = gap;
            }
        }
        t.repAt = now;
        if (idx < 3 && recRowN < 1500) {
            recRows.append(idx).append(' ').append(now - recStartAt).append(' ').append(Math.round(w.ex))
                    .append(' ').append(Math.round(w.ey)).append('\n');
            recRowN++;
        }
    }

    /** Stops the recording and returns the text to paste. */
    static String recordStop(Context c) {
        recOn = false;
        java.util.Locale L = java.util.Locale.US;
        StringBuilder b = new StringBuilder("LIVE EDITOR LOCK DATA v1\n");
        try {
            android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
            float hz = ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRefreshRate();
            b.append("phone: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append(", android ")
                    .append(Build.VERSION.SDK_INT).append(", screen ").append(dm.widthPixels).append('x')
                    .append(dm.heightPixels).append(" px, density ").append(dm.density).append(", refresh ")
                    .append(Math.round(hz)).append(" Hz\n");
            b.append("app: ").append(c.getPackageName()).append('\n');
        } catch (Throwable t) {
            b.append("phone: unknown\n");
        }
        b.append("lock: ").append(lockStatus()).append('\n');
        try {
            ArrayList<Owner> all = new ArrayList<Owner>(OWNERS.values());
            b.append("line views: ").append(all.size()).append('\n');
            for (int i = 0; i < all.size() && i < 4; i++) {
                Owner o = all.get(i);
                View v = o.view.get();
                if (v == null) continue;
                b.append("  view ").append(v.getClass().getName()).append(' ').append(v.getWidth()).append('x')
                        .append(v.getHeight()).append(" locked=").append(o.locked).append(" lines=")
                        .append(o.tracks.size()).append(" origin=").append(Math.round(o.ox)).append(',')
                        .append(Math.round(o.oy));
                ViewGroup.LayoutParams lp = v.getRootView().getLayoutParams();
                if (lp instanceof WindowManager.LayoutParams) {
                    WindowManager.LayoutParams w0 = (WindowManager.LayoutParams) lp;
                    b.append(" window type=").append(w0.type).append(" flags=0x").append(Integer.toHexString(w0.flags))
                            .append(" alpha=").append(w0.alpha);
                }
                b.append('\n');
            }
        } catch (Throwable t) {
            b.append("  (views unreadable)\n");
        }
        float secs = (SystemClock.uptimeMillis() - recStartAt) / 1000f;
        b.append(String.format(L, "recorded: %.1f s\n", secs));
        if (recFrames > 0) {
            b.append(String.format(L, "frames: %d, average gap %.1f ms, slower than 24 ms: %d, longest %.0f ms\n",
                    recFrames, recFrameSum / recFrames, recSlow, recFrameMax));
        } else {
            b.append("frames: none seen (no line view was drawn while recording)\n");
        }
        if (recReports > 0) {
            b.append(String.format(L, "gap between the app's reports: average %.1f ms, shortest %.0f ms, longest %.0f ms (%d reports)\n",
                    recGapSum / recReports, recGapMin, recGapMax, recReports));
        } else {
            b.append("reports: none measured\n");
        }
        if (recSteps > 0) {
            b.append(String.format(L, "step the app makes per report (what you see without lock): average %.1f px, largest %.1f px\n",
                    recStepSum / recSteps, recStepMax));
            b.append(String.format(L, "gap between what is shown and the app's new number at each report (with the current engine): average %.1f px, largest %.1f px\n",
                    recShownSum / recSteps, recShownMax));
        }
        b.append("times the app set the line view's alpha back: ").append(recAlpha).append('\n');
        b.append("rows: line, ms since start, end x, end y (only when the app changed the numbers; first 3 lines)\n");
        b.append(recRows);
        recRows.setLength(0);
        return b.toString();
    }

    // ---- finding the view that draws the lines ---------------------------------------------

    private static boolean appClass(Class<?> c) {
        String n = c.getName();
        return !(n.startsWith("android.") || n.startsWith("androidx.") || n.startsWith("java.")
                || n.startsWith("javax.") || n.startsWith("kotlin.") || n.startsWith("dalvik.")
                || n.startsWith("libcore.") || c.isPrimitive() || c.isArray() || c.isEnum());
    }

    private static void scan(View root, RootState st, boolean strict) {
        st.views.clear();
        ArrayList<View> paint = new ArrayList<View>();
        ArrayList<View> leaves = new ArrayList<View>();
        int[] budget = {160};
        collect(root, 0, paint, leaves, budget);
        ArrayList<View> use = !paint.isEmpty() ? paint : (strict ? leaves : new ArrayList<View>());
        for (int i = 0; i < use.size() && i < 8; i++) st.views.add(new WeakReference<View>(use.get(i)));
    }

    private static void collect(View v, int depth, ArrayList<View> paint, ArrayList<View> leaves, int[] budget) {
        if (v == null || depth > 8 || budget[0]-- <= 0) return;
        boolean leaf = !(v instanceof ViewGroup) || ((ViewGroup) v).getChildCount() == 0;
        if (leaf && !(v instanceof TextView) && !(v instanceof ImageView) && appClass(v.getClass())
                && v.getWidth() > 0 && v.getHeight() > 0) {
            leaves.add(v);
            if (hasPaint(v)) paint.add(v);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount() && i < 60; i++) {
                collect(g.getChildAt(i), depth + 1, paint, leaves, budget);
            }
        }
    }

    /** A custom view that keeps a Paint (or several) in a field is the one that draws lines. Only "yes" is remembered. */
    private static boolean hasPaint(View v) {
        if (PAINTY.get(v) != null) return true;
        boolean r = false;
        try {
            r = paintIn(v, 0);
        } catch (Throwable t) {
            // not readable
        }
        if (r) PAINTY.put(v, Boolean.TRUE);
        return r;
    }

    private static boolean paintIn(Object target, int depth) {
        Class<?> c = target.getClass();
        int guard = 0;
        while (c != null && c != View.class && c != Object.class && guard++ < 6) {
            if (!appClass(c)) break;
            Field[] fs;
            try {
                fs = c.getDeclaredFields();
            } catch (Throwable t) {
                break;
            }
            for (int i = 0; i < fs.length && i < 200; i++) {
                try {
                    Field f = fs[i];
                    if (java.lang.reflect.Modifier.isStatic(f.getModifiers()) || f.getType().isPrimitive()) continue;
                    f.setAccessible(true);
                    Object o = f.get(target);
                    if (o == null) continue;
                    if (o instanceof Paint || o instanceof Paint[]) return true;
                    if (depth < 1 && !(o instanceof View) && !(o instanceof android.content.Context)
                            && appClass(o.getClass()) && paintIn(o, depth + 1)) return true;
                } catch (Throwable t) {
                    // skip
                }
            }
            c = c.getSuperclass();
        }
        return false;
    }

    // ---- one frame -------------------------------------------------------------------------

    private static void step(View v, float d, long now) {
        Owner o = OWNERS.get(v);
        if (o == null) {
            o = new Owner(v);
            OWNERS.put(v, o);
        }
        if (o.dead) return;
        o.density = d;
        if (!o.attached) attach(v, o);
        Rect b = o.tip.getBounds();
        if (b.width() != v.getWidth() || b.height() != v.getHeight()) o.tip.setBounds(0, 0, v.getWidth(), v.getHeight());
        // lock on / off
        if (Config.lockOn && !layerFailed) {
            if (!o.locked) lock(v, o);
            else if (v.getAlpha() != LOCK_ALPHA) {
                if (recOn) recAlpha++;
                v.setAlpha(LOCK_ALPHA); // the app set it back: hide again before drawing
            }
        } else if (o.locked) {
            unlock(v, o);
        }
        if (o.recAt != 0 && now - o.recAt < 4L) return; // already written down for this frame
        Rec r = o.rec;
        r.w = v.getWidth();
        r.h = v.getHeight();
        r.n = 0;
        try {
            v.draw(r);
        } catch (Throwable t) {
            U.err("line tips record", t);
            o.fails++;
            if (o.fails >= 3) {
                o.dead = true;
                detach(v, o);
            }
            return;
        }
        o.recAt = now;
        if (recOn) recFrame(o, now);
        o.viewH = r.h;
        update(o, r, d, now);
        if (o.locked && layer != null) layer.postInvalidateOnAnimation();
    }

    private static void attach(View v, Owner o) {
        o.tip = new Tip(o);
        v.getOverlay().add(o.tip);
        o.tip.setBounds(0, 0, v.getWidth(), v.getHeight());
        o.attached = true;
        Overlays.bump(); // the window is drawn once more, so the first frame already has the marker
    }

    private static void detach(View v, Owner o) {
        if (o.locked) unlock(v, o);
        try {
            if (o.attached && o.tip != null) v.getOverlay().remove(o.tip);
        } catch (Throwable t) {
            // ignore
        }
        o.attached = false;
        o.tip = null;
        o.tracks.clear();
        v.invalidate();
    }

    private static boolean near(float ax, float ay, float bx, float by, float tol) {
        float dx = ax - bx, dy = ay - by;
        return dx * dx + dy * dy <= tol * tol;
    }

    /** Finds the origin lines in what was just drawn, and follows them from frame to frame. */
    private static void update(Owner o, Rec r, float d, long now) {
        Pt.snapPx = 300f * d;
        int n = r.n;
        Seg[] s = r.segs;
        float tol = Math.max(3f, 2f * d);

        // 1. the origin = the point most lines share
        int lim = Math.min(n, 96);
        int best = 0;
        float bx = 0f, by = 0f;
        for (int i = 0; i < lim; i++) {
            for (int e = 0; e < 2; e++) {
                float px = e == 0 ? s[i].x0 : s[i].x1;
                float py = e == 0 ? s[i].y0 : s[i].y1;
                int c = 0;
                for (int j = 0; j < lim; j++) {
                    if (near(px, py, s[j].x0, s[j].y0, tol) || near(px, py, s[j].x1, s[j].y1, tol)) c++;
                }
                if (c > best || (c == best && c >= 2 && py < by - 0.5f)) {
                    best = c;
                    bx = px;
                    by = py;
                }
            }
        }
        int cr = 0;
        if (o.haveOrigin) {
            for (int j = 0; j < lim; j++) {
                if (near(o.ox, o.oy, s[j].x0, s[j].y0, tol) || near(o.ox, o.oy, s[j].x1, s[j].y1, tol)) cr++;
            }
        }
        boolean haveO = false;
        float ox = 0f, oy = 0f;
        if (o.haveOrigin && (cr >= 2 || (cr == 1 && best < 2))) {
            ox = o.ox;
            oy = o.oy;
            haveO = true;
        } else if (best >= 2) {
            ox = bx;
            oy = by;
            haveO = true;
            if (best >= 3 || !o.haveOrigin) {
                o.ox = bx;
                o.oy = by;
                o.haveOrigin = true;
            }
        } else if (n == 1) {
            ox = s[0].x0;
            oy = s[0].y0;
            haveO = true;
        }

        // 2. the origin lines of this frame (origin -> end)
        Raw[] raw = o.raw;
        int rn = 0;
        if (haveO) {
            for (int i = 0; i < n && rn < MAX; i++) {
                Seg g = s[i];
                boolean a = near(g.x0, g.y0, ox, oy, tol), b = near(g.x1, g.y1, ox, oy, tol);
                if (a == b) continue; // does not start at the origin (or has no length)
                float sx = a ? g.x0 : g.x1, sy = a ? g.y0 : g.y1;
                float ex = a ? g.x1 : g.x0, ey = a ? g.y1 : g.y0;
                boolean dup = false;
                for (int k = 0; k < rn; k++) {
                    if (near(raw[k].ex, raw[k].ey, ex, ey, 1f)) { // the same line drawn twice: the one on top counts
                        raw[k].src = g;
                        dup = true;
                        break;
                    }
                }
                if (dup) continue;
                Raw w = raw[rn++];
                w.ox = sx;
                w.oy = sy;
                w.ex = ex;
                w.ey = ey;
                w.src = g;
            }
        }
        o.rawN = rn;

        // 4. which raw line is which known track (nearest to where the track is now)
        boolean lock = o.locked;
        ArrayList<Track> tr = o.tracks;
        int tn = tr.size();
        boolean[] ru = o.ru, tu = o.tu;
        for (int i = 0; i < rn; i++) ru[i] = false;
        for (int j = 0; j < tn; j++) {
            tu[j] = false;
            Track t = tr.get(j);
            if (lock) {
                t.e.at(now, o.tmp);
                o.refX[j] = o.tmp[0];
                o.refY[j] = o.tmp[1];
            } else {
                o.refX[j] = t.e.rx;
                o.refY[j] = t.e.ry;
            }
        }
        int pairs = Math.min(tn, rn);
        int[] mate = new int[rn]; // raw i -> track index, -1 = new
        for (int i = 0; i < rn; i++) mate[i] = -1;
        if (tn <= 48 && rn <= 48) {
            for (int k = 0; k < pairs; k++) {
                float bd = Float.MAX_VALUE;
                int bi = -1, bj = -1;
                for (int j = 0; j < tn; j++) {
                    if (tu[j]) continue;
                    for (int i = 0; i < rn; i++) {
                        if (ru[i]) continue;
                        float dx = o.refX[j] - raw[i].ex, dy = o.refY[j] - raw[i].ey;
                        float dd = dx * dx + dy * dy;
                        if (dd < bd) {
                            bd = dd;
                            bi = i;
                            bj = j;
                        }
                    }
                }
                if (bi < 0) break;
                ru[bi] = true;
                tu[bj] = true;
                mate[bi] = bj;
            }
        } else {
            for (int k = 0; k < pairs; k++) {
                ru[k] = true;
                tu[k] = true;
                mate[k] = k;
            }
        }

        // 5. every raw line goes to its track (a new track for a new line)
        for (int i = 0; i < rn; i++) {
            Raw w = raw[i];
            Track t;
            if (mate[i] >= 0) {
                t = tr.get(mate[i]);
                if (recOn) recReport(mate[i], t, w, now);
                t.e.sample(w.ex, w.ey, now);
                t.o.sample(w.ox, w.oy, now);
            } else {
                if (tr.size() >= MAX) continue;
                t = new Track();
                t.e.reset(w.ex, w.ey, now);
                t.o.reset(w.ox, w.oy, now);
                tr.add(t);
            }
            t.seenAt = now;
            if (w.src.paint != null) t.paint.set(w.src.paint);
        }
        // lines the app did not draw this time: gone at once, or kept a moment in lock mode (no blink)
        for (int j = tr.size() - 1; j >= 0; j--) {
            Track tk = tr.get(j);
            long hold = lock ? tk.e.hold() : 0L;
            if (now - tk.seenAt > hold) tr.remove(j);
        }
    }



    // ---- the marker picture ----------------------------------------------------------------

    private static Bitmap srcBmp;
    private static String srcRef;
    private static boolean srcBuiltin = true;
    private static float srcAx, srcAy;
    private static Bitmap scaled;
    private static int scaledW;
    private static float tipX, tipY;

    private static Bitmap decode(String b64) {
        try {
            byte[] raw = Base64.decode(b64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(raw, 0, raw.length);
        } catch (Throwable t) {
            return null;
        }
    }

    /** The picture to use (the user's PNG, or the built-in triangle), with the point of it that touches the line end. */
    private static Bitmap source() {
        String want = (Config.tipPng == null || Config.tipPng.length() == 0) ? null : Config.tipPng;
        if (srcBmp != null && want == srcRef) return srcBmp;
        Bitmap b = want == null ? null : decode(want);
        boolean builtin = false;
        if (b == null) {
            b = decode(BUILTIN_B64);
            builtin = true;
        }
        if (b == null) return null;
        srcBmp = b;
        srcRef = want;
        srcBuiltin = builtin;
        scaled = null;
        // the tip = bottom centre of what is visible (transparent borders do not count)
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        int yl = -1;
        for (int y = h - 1; y >= 0 && yl < 0; y--) {
            for (int x = 0; x < w; x++) {
                if ((px[y * w + x] >>> 24) > 24) {
                    yl = y;
                    break;
                }
            }
        }
        if (yl < 0) {
            srcAx = w / 2f;
            srcAy = h;
        } else {
            double sx = 0, sa = 0;
            int rows = 0;
            for (int y = yl; y >= 0 && rows < 3; y--) {
                boolean any = false;
                for (int x = 0; x < w; x++) {
                    int a = px[y * w + x] >>> 24;
                    if (a > 24) {
                        sx += (x + 0.5) * a;
                        sa += a;
                        any = true;
                    }
                }
                if (!any) break;
                rows++;
            }
            srcAx = sa > 0 ? (float) (sx / sa) : w / 2f;
            srcAy = yl + 0.75f;
        }
        return b;
    }

    /** The marker at the size in dp (1 .. 20), scaled down in steps so it stays sharp. */
    private static Bitmap sized(float density) {
        Bitmap b = source();
        if (b == null) return null;
        int tw = Math.max(1, Math.round(U.clamp(Config.tipDp, 1, 20) * density));
        if (scaled != null && scaledW == tw) return scaled;
        int th = Math.max(1, Math.round(tw * (float) b.getHeight() / b.getWidth()));
        Bitmap cur = b;
        try {
            while (cur.getWidth() >= tw * 2 && cur.getHeight() >= th * 2) {
                cur = Bitmap.createScaledBitmap(cur, cur.getWidth() / 2, cur.getHeight() / 2, true);
            }
            scaled = Bitmap.createScaledBitmap(cur, tw, th, true);
        } catch (Throwable t) {
            U.err("line tip picture", t);
            return null;
        }
        scaledW = tw;
        tipX = srcAx * tw / b.getWidth();
        tipY = srcAy * th / b.getHeight();
        return scaled;
    }

    // ---- painting: markers and (in lock mode) the lines themselves ---------------------

    /** The paints and the drawing of one owner; used by the overlay (no lock) and by the lock layer. */
    private static final class Pen {
        private final Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final float[] a = new float[2];
        private final float[] b2 = new float[2];

        Pen() {
        }

        /** lock = true: also draw the line itself, at the shown (predicted) positions; false: marker only. */
        void draw(Canvas c, Owner o, long now, boolean lock) {
            int n = o.tracks.size();
            if (n == 0) return;
            float d = o.density;
            Bitmap bm = Config.tipOn ? sized(d) : null;
            for (int i = 0; i < n; i++) {
                Track t = o.tracks.get(i);
                float ex, ey, ox, oy;
                if (lock) {
                    t.e.at(now, a);
                    t.o.at(now, b2);
                    ex = a[0];
                    ey = a[1];
                    ox = b2[0];
                    oy = b2[1];
                } else {
                    ex = t.e.rx;
                    ey = t.e.ry;
                    ox = t.o.rx;
                    oy = t.o.ry;
                }
                if (lock) c.drawLine(ox, oy, ex, ey, t.paint);
                if (bm == null) continue;
                float top = Config.tipAnchor == 1 ? ey - bm.getHeight() / 2f : ey - tipY;
                if (Config.tipOn) {
                    float left = Config.tipAnchor == 1 ? ex - bm.getWidth() / 2f : ex - tipX;
                    c.drawBitmap(bm, left, top, mp);
                }
            }
        }

    }

    /** In the line view's overlay (no lock): the marker and the number, painted in the same frame as the app's lines. */
    private static final class Tip extends Drawable {
        private final Owner o;

        Tip(Owner o) {
            this.o = o;
        }

        @Override
        public void draw(Canvas c) {
            if (c instanceof Rec || o.locked) return; // the recording pass, or the lock layer paints instead
            try {
                o.pen.draw(c, o, SystemClock.uptimeMillis(), false);
            } catch (Throwable t) {
                U.err("line tips draw", t);
            }
        }

        @Override
        public void setAlpha(int alpha) {}

        @Override
        public void setColorFilter(ColorFilter cf) {}

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    // ---- the lock layer ----------------------------------------------------------------------

    private static Layer layer;
    private static WindowManager layerWm;
    private static boolean layerFailed;

    /**
     * One transparent, untouchable window over the screen. It is painted at every screen refresh (it asks for the
     * next one itself while a line is shown), so the lines move smoothly even when the app reports them rarely.
     */
    private static final class Layer extends View {
        private final int[] l1 = new int[2], l2 = new int[2];

        Layer(Context c) {
            super(c);
            setTag(Panel.TAG); // our own window: the rest of the editor leaves it alone
            setWillNotDraw(false);
        }

        @Override
        protected void onDraw(Canvas c) {
            try {
                long now = SystemClock.uptimeMillis();
                boolean any = false;
                getLocationOnScreen(l2);
                ArrayList<Owner> all = new ArrayList<Owner>(OWNERS.values());
                for (int i = 0; i < all.size(); i++) {
                    Owner o = all.get(i);
                    View v = o.view.get();
                    if (!o.locked || v == null || !v.isAttachedToWindow() || o.tracks.isEmpty()) continue;
                    v.getLocationOnScreen(l1);
                    c.save();
                    c.translate(l1[0] - l2[0], l1[1] - l2[1]);
                    o.pen.draw(c, o, now, true);
                    c.restore();
                    any = true;
                }
                if (any) postInvalidateOnAnimation(); // the next screen refresh
            } catch (Throwable t) {
                U.err("line tips layer", t);
            }
        }
    }

    /** Hides the app's own lines and lets the layer draw them. */
    private static void lock(View v, Owner o) {
        try {
            if (!ensureLayer(v)) {
                layerFailed = true;
                return;
            }
            o.origAlpha = v.getAlpha();
            v.setAlpha(LOCK_ALPHA);
            o.locked = true;
        } catch (Throwable t) {
            U.err("line lock", t);
            layerFailed = true;
            try {
                v.setAlpha(o.origAlpha);
            } catch (Throwable t2) {
                // ignore
            }
            o.locked = false;
        }
    }

    private static void unlock(View v, Owner o) {
        try {
            v.setAlpha(o.origAlpha);
        } catch (Throwable t) {
            // ignore
        }
        o.locked = false;
        maybeDropLayer();
    }

    private static boolean ensureLayer(View v) {
        if (layer != null && layer.isAttachedToWindow()) return true;
        try {
            Context cx = v.getContext();
            WindowManager wm = (WindowManager) cx.getSystemService(Context.WINDOW_SERVICE);
            int type = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
            float alpha = 1f;
            int format = PixelFormat.TRANSLUCENT;
            // same kind of window as the app's own line window: same type, same transparency (and so the same touch rules)
            ViewGroup.LayoutParams lp0 = v.getRootView().getLayoutParams();
            if (lp0 instanceof WindowManager.LayoutParams) {
                WindowManager.LayoutParams w0 = (WindowManager.LayoutParams) lp0;
                type = w0.type;
                alpha = w0.alpha;
                if (w0.format != PixelFormat.UNKNOWN) format = w0.format;
            }
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, type, flags, format);
            lp.gravity = Gravity.TOP | Gravity.LEFT;
            lp.alpha = alpha;
            Layer l = new Layer(cx);
            wm.addView(l, lp);
            layer = l;
            layerWm = wm;
            return true;
        } catch (Throwable t) {
            U.err("line layer", t);
            layer = null;
            return false;
        }
    }

    /** No line view is locked any more: take the layer away. */
    private static void maybeDropLayer() {
        try {
            if (layer == null) return;
            ArrayList<Owner> all = new ArrayList<Owner>(OWNERS.values());
            for (int i = 0; i < all.size(); i++) {
                if (all.get(i).locked) return;
            }
            layerWm.removeView(layer);
        } catch (Throwable t) {
            // ignore
        }
        layer = null;
        layerWm = null;
    }

    /** True while a marker picture is the user's own (for the panel text). */
    static boolean customPicture() {
        return Config.tipPng != null && Config.tipPng.length() > 0 && !srcBuiltin;
    }
}
