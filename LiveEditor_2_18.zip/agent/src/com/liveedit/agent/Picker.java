package com.liveedit.agent;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Lets the user choose a picture (PNG of any size) from inside the patched app. A fragment without a screen is added to
 * the app's current activity, starts the system file picker and receives its result, so no change of the app's code
 * or manifest is needed. The picture is scaled down (longest side 192 px, transparency kept) and handed back as base64.
 */
public final class Picker extends Fragment {

    interface Result {
        /** base64 of the PNG, or null when nothing was chosen or it could not be read. */
        void done(String base64, String error);
    }

    private static final int REQ = 48211;
    private static final String TAG = "liveedit-picker";
    private static Result pending;

    public Picker() {}

    static boolean pick(Result cb) {
        try {
            Activity a = Agent.topActivity();
            if (a == null) return false;
            pending = cb;
            Picker p = new Picker();
            a.getFragmentManager().beginTransaction().add(p, TAG).commitAllowingStateLoss();
            a.getFragmentManager().executePendingTransactions();
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            p.startActivityForResult(Intent.createChooser(i, "Choose a PNG"), REQ);
            return true;
        } catch (Throwable t) {
            U.err("picker", t);
            pending = null;
            return false;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ) return;
        Result cb = pending;
        pending = null;
        String b64 = null;
        String err = null;
        try {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                b64 = encode(getActivity(), data.getData());
                if (b64 == null) err = "could not read that picture";
            }
        } catch (Throwable t) {
            U.err("picker result", t);
            err = String.valueOf(t);
        }
        try {
            Activity a = getActivity();
            if (a != null) a.getFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
        } catch (Throwable t) {
            // ignore
        }
        if (cb != null) cb.done(b64, err);
    }

    private static String encode(Activity a, Uri u) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in = a.getContentResolver().openInputStream(u);
        try {
            BitmapFactory.decodeStream(in, null, o);
        } finally {
            if (in != null) in.close();
        }
        int big = Math.max(o.outWidth, o.outHeight);
        if (big <= 0) return null;
        int sample = 1;
        while (big / (sample * 2) >= 192) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        in = a.getContentResolver().openInputStream(u);
        Bitmap bm;
        try {
            bm = BitmapFactory.decodeStream(in, null, o2);
        } finally {
            if (in != null) in.close();
        }
        if (bm == null) return null;
        int max = Math.max(bm.getWidth(), bm.getHeight());
        if (max > 192) {
            float sc = 192f / max;
            bm = Bitmap.createScaledBitmap(bm, Math.max(1, Math.round(bm.getWidth() * sc)),
                    Math.max(1, Math.round(bm.getHeight() * sc)), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, out);
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }
}
