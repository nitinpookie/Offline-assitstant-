package com.liveedit.agent;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.LinkedHashSet;

/**
 * Safety net for removed interfaces. A removed window is only bypassed (see Overlays.hideWindow), but if some app
 * still closes shortly after one was removed, the next start remembers it: that window is then kept visible
 * (never removed again) and the app keeps working. The marks can be cleared in the Windows tab.
 */
final class HideGuard {
    private static final String STAMP = "liveedit_hide_stamp.json";
    private static final String UNSAFE = "liveedit_unsafe.json";
    private static final String STAMP_SHOW = "liveedit_show_stamp.json";
    private static final String UNSAFE_SHOW = "liveedit_unsafe_show.json";
    /** If the app is still alive this long after a change, the change was fine. */
    private static final long SAFE_AFTER_MS = 6000L;

    private static Context app;
    private static final Handler H = new Handler(Looper.getMainLooper());
    /** Windows that must never be auto-removed again (removing one closed the app before): forced to stay visible. */
    private static final HashSet<String> unsafe = new HashSet<String>();
    /** Windows that must never be auto-restored again (bringing one back closed the app before): forced to stay removed. */
    private static final HashSet<String> unsafeShow = new HashSet<String>();
    private static final LinkedHashSet<String> recent = new LinkedHashSet<String>();
    private static final LinkedHashSet<String> recentShow = new LinkedHashSet<String>();

    private static final Runnable CLEAR = new Runnable() {
        @Override
        public void run() {
            recent.clear();
            delete(STAMP);
        }
    };
    private static final Runnable CLEAR_SHOW = new Runnable() {
        @Override
        public void run() {
            recentShow.clear();
            delete(STAMP_SHOW);
        }
    };

    private HideGuard() {}

    /** Called once at start (after the rules are loaded). */
    static void init(Context c) {
        app = c.getApplicationContext() == null ? c : c.getApplicationContext();
        try {
            readSet(UNSAFE, unsafe);
            readSet(UNSAFE_SHOW, unsafeShow);
            LinkedHashSet<String> died = new LinkedHashSet<String>();
            readSet(STAMP, died);
            LinkedHashSet<String> diedShow = new LinkedHashSet<String>();
            readSet(STAMP_SHOW, diedShow);
            boolean any = false;
            if (!died.isEmpty()) {
                // the app closed within seconds of a removal last time: never remove this window by itself again
                unsafe.addAll(died);
                writeSet(UNSAFE, unsafe);
                delete(STAMP);
                any = true;
            }
            if (!diedShow.isEmpty()) {
                // the app closed within seconds of bringing a window BACK last time: keep it removed from now on
                unsafeShow.addAll(diedShow);
                writeSet(UNSAFE_SHOW, unsafeShow);
                delete(STAMP_SHOW);
                for (String k : diedShow) Rules.edit(k).hide = true;
                any = true;
            }
            if (any) {
                H.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Toast.makeText(app, "Live Editor: the app closed right after a window was changed. "
                                    + "That one is left exactly as it was before, so this does not happen again.",
                                    Toast.LENGTH_LONG).show();
                        } catch (Throwable t) {
                            // ignore
                        }
                    }
                }, 4000);
            }
            for (String k : unsafe) Rules.edit(k).hide = false;
        } catch (Throwable t) {
            U.err("hide guard init", t);
        }
    }

    /** A window was just removed: if the app dies in the next seconds, this key is marked unsafe to remove again. */
    static void note(String key) {
        if (app == null || key == null) return;
        try {
            recent.add(key);
            writeSet(STAMP, recent);
            H.removeCallbacks(CLEAR);
            H.postDelayed(CLEAR, SAFE_AFTER_MS);
        } catch (Throwable t) {
            U.err("hide guard note", t);
        }
    }

    /** A window was just brought back: if the app dies in the next seconds, this key is marked unsafe to restore. */
    static void noteShow(String key) {
        if (app == null || key == null) return;
        try {
            recentShow.add(key);
            writeSet(STAMP_SHOW, recentShow);
            H.removeCallbacks(CLEAR_SHOW);
            H.postDelayed(CLEAR_SHOW, SAFE_AFTER_MS);
        } catch (Throwable t) {
            U.err("hide guard note show", t);
        }
    }

    static void markUnsafe(String key) {
        if (key == null) return;
        unsafe.add(key);
        try {
            writeSet(UNSAFE, unsafe);
        } catch (Throwable t) {
            U.err("hide guard mark", t);
        }
    }

    static boolean isUnsafe(String key) {
        return key != null && unsafe.contains(key);
    }

    static boolean isUnsafeShow(String key) {
        return key != null && unsafeShow.contains(key);
    }

    static int unsafeCount() {
        return unsafe.size() + unsafeShow.size();
    }

    /** The user left the app on purpose: a closing app is not a crash of a window change. */
    static void settle() {
        recent.clear();
        recentShow.clear();
        delete(STAMP);
        delete(STAMP_SHOW);
    }

    /** Forget every mark, so those windows can be changed again. */
    static void forgetAll() {
        unsafe.clear();
        unsafeShow.clear();
        delete(UNSAFE);
        delete(STAMP);
        delete(UNSAFE_SHOW);
        delete(STAMP_SHOW);
    }

    // ---- tiny storage -------------------------------------------------------------------------

    private static void readSet(String name, java.util.Set<String> into) {
        try {
            File f = new File(app.getFilesDir(), name);
            if (!f.exists()) return;
            byte[] b = new byte[(int) Math.min(f.length(), 200000L)];
            FileInputStream in = new FileInputStream(f);
            int n = 0;
            try {
                int r;
                while (n < b.length && (r = in.read(b, n, b.length - n)) > 0) n += r;
            } finally {
                in.close();
            }
            JSONArray a = new JSONArray(new String(b, 0, n, StandardCharsets.UTF_8));
            for (int i = 0; i < a.length(); i++) {
                String s = a.optString(i, "");
                if (s.length() > 0) into.add(s);
            }
        } catch (Throwable t) {
            // unreadable: treat as empty
        }
    }

    private static void writeSet(String name, java.util.Set<String> set) throws Exception {
        JSONArray a = new JSONArray();
        for (String s : set) a.put(s);
        FileOutputStream out = new FileOutputStream(new File(app.getFilesDir(), name));
        try {
            out.write(a.toString().getBytes(StandardCharsets.UTF_8));
            out.getFD().sync(); // reaches the disk even if the app is killed a moment later
        } finally {
            out.close();
        }
    }

    private static void delete(String name) {
        try {
            if (app != null) new File(app.getFilesDir(), name).delete();
        } catch (Throwable t) {
            // ignore
        }
    }
}
