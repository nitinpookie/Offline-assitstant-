package com.liveedit.patcher;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Builds one plain-text report of an APK (structure, manifest, resources, code) so it can be shared and read. */
final class NixuExport {

    interface Source {
        List<NixuZip.E> list();

        byte[] read(String name) throws IOException;

        boolean changed(String name);
    }

    static final class Options {
        boolean entries = true;
        boolean manifest = true;
        boolean arsc = true;
        boolean dexClasses = true;
        boolean dexMethods = false;
        /** Class-name filter (dotted or slashed, case-insensitive) for full smali text; null = no smali. */
        String smaliFilter;
        int arscLimit = 4000;
    }

    private NixuExport() {}

    /** Entries whose name does not say what they are: checked by their content instead. */
    static boolean needsSniff(NixuZip.E e) {
        String n = e.name.toLowerCase(Locale.US);
        if (n.endsWith("/") || e.size < 112 || e.size > (64L << 20)) return false;
        if (n.startsWith("meta-inf/") || n.startsWith("res/") || n.startsWith("lib/")) return false;
        if (n.equals("androidmanifest.xml") || n.equals("resources.arsc") || n.matches("classes\\d*\\.dex")) return false;
        String[] skip = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".xml", ".so", ".ttf", ".otf", ".mp3", ".mp4", ".ogg",
                ".wav", ".json", ".txt", ".html", ".js", ".css", ".kotlin_module", ".version", ".properties"};
        for (String k : skip) {
            if (n.endsWith(k)) return false;
        }
        return true;
    }

    static String size(long n) {
        if (n < 1024) return n + "B";
        if (n < 1048576) return String.format(Locale.US, "%.2fK", n / 1024.0);
        return String.format(Locale.US, "%.2fM", n / 1048576.0);
    }

    static String build(Source src, Options o, String title) {
        StringBuilder sb = new StringBuilder(1 << 16);
        sb.append("# nixu cn export\n# ").append(title).append("\n\n");
        List<NixuZip.E> es = src.list();
        List<String> dexNames = new ArrayList<String>();
        for (NixuZip.E e : es) {
            if (e.name.matches("classes\\d*\\.dex")) dexNames.add(e.name);
        }
        StringBuilder odd = new StringBuilder();
        int checked = 0;
        for (NixuZip.E e : es) {
            if (!needsSniff(e) || checked >= 300) continue;
            checked++;
            try {
                byte[] d = src.read(e.name);
                if (d == null) continue;
                odd.append(e.name).append(" | ").append(NixuDex.sniffLine(d)).append('\n');
                if (!dexNames.contains(e.name) && (NixuDex.looksLikeDex(d) || NixuDex.fixMagic(d) != null)) {
                    dexNames.add(e.name);
                }
            } catch (Exception ex) {
                odd.append(e.name).append(" | cannot read: ").append(ex.getMessage()).append('\n');
            }
        }
        if (o.entries) {
            sb.append("=== FILES (").append(es.size()).append(" entries, nothing hidden) ===\n");
            sb.append("path | size | packed | method | crc | flags\n");
            for (NixuZip.E e : es) {
                sb.append(e.name).append(" | ").append(e.size).append(" | ").append(e.compSize).append(" | ")
                        .append(e.method == 0 ? "stored" : e.method == 8 ? "deflate" : "method" + e.method)
                        .append(" | ").append(String.format(Locale.US, "%08x", e.crc)).append(" | ")
                        .append(String.format(Locale.US, "0x%04x", e.flags));
                if ((e.flags & 1) != 0) sb.append(" ENCRYPTED-FLAG");
                if (src.changed(e.name)) sb.append(" CHANGED");
                sb.append('\n');
            }
            sb.append('\n');
        }
        if (odd.length() > 0) {
            sb.append("=== FILES CHECKED BY CONTENT (name tells nothing) ===\n");
            sb.append("path | size | entropy | type by content | first 16 bytes\n");
            sb.append(odd).append('\n');
        }
        if (o.manifest) {
            sb.append("=== AndroidManifest.xml ===\n");
            try {
                byte[] m = src.read("AndroidManifest.xml");
                if (m == null) sb.append("(not found)\n");
                else if (NixuAxml.isBinary(m)) sb.append(NixuAxml.toXml(m));
                else sb.append(new String(m, "UTF-8"));
            } catch (Exception e) {
                sb.append("(cannot read: ").append(e.getMessage()).append(")\n");
            }
            sb.append('\n');
        }
        if (o.arsc) {
            sb.append("=== resources.arsc ===\n");
            try {
                byte[] a = src.read("resources.arsc");
                if (a == null) sb.append("(not found)\n");
                else NixuArsc.parse(a).dump(sb, o.arscLimit);
            } catch (Exception e) {
                sb.append("(cannot read: ").append(e.getMessage()).append(")\n");
            }
            sb.append('\n');
        }
        if (o.dexClasses || o.dexMethods || o.smaliFilter != null) {
            for (String dn : dexNames) {
                sb.append("=== ").append(dn).append(" ===\n");
                try {
                    NixuDex dex = NixuDex.parseLoose(src.read(dn));
                    sb.append(dex.summary()).append('\n');
                    String f = o.smaliFilter == null ? null : o.smaliFilter.toLowerCase(Locale.US).replace('.', '/');
                    for (int i = 0; i < dex.classCount; i++) {
                        String cn = dex.className(i);
                        boolean wantSmali = f != null && cn.toLowerCase(Locale.US).contains(f);
                        if (wantSmali) {
                            NixuDex.ClassInfo ci = dex.classInfo(i);
                            sb.append("\n# ---- ").append(cn).append(" ----\n");
                            dex.smali(ci, sb);
                            continue;
                        }
                        if (!o.dexClasses && !o.dexMethods) continue;
                        if (f != null && !o.dexClasses) continue;
                        sb.append(cn);
                        if (o.dexMethods) {
                            NixuDex.ClassInfo ci = dex.classInfo(i);
                            sb.append("  (").append(ci.fields.size()).append(" fields, ").append(ci.methods.size()).append(" methods)\n");
                            for (NixuDex.Method m : ci.methods) {
                                sb.append("    ").append(NixuDex.flags(m.access, true, false)).append(dex.methodName(m.idx))
                                        .append(dex.methodProto(m.idx)).append('\n');
                            }
                        } else {
                            sb.append('\n');
                        }
                    }
                } catch (Exception e) {
                    sb.append("(cannot read: ").append(e.getMessage()).append(")\n");
                }
                sb.append('\n');
            }
        }
        return sb.toString();
    }
}
