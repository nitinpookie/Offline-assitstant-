package com.liveedit.patcher;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Android string pool chunk (RES_STRING_POOL_TYPE), used by binary XML files and resources.arsc.
 * Strings can be changed or appended; style (span) data is carried over byte for byte.
 */
final class NixuPool {

    boolean utf8;
    boolean sorted;
    final List<String> strings = new ArrayList<String>();
    int styleCount;
    int[] styleOffsets = new int[0];
    /** Raw bytes from stylesStart to the end of the chunk (span lists + end guards). */
    byte[] styles = new byte[0];
    /** Size in bytes of the chunk this pool was read from. */
    int readSize;

    static NixuPool parse(byte[] d, int pos) throws IOException {
        if (pos < 0 || pos + 28 > d.length) throw new IOException("string pool is cut off");
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        if ((b.getShort(pos) & 0xFFFF) != 0x0001) throw new IOException("string pool not found at " + pos);
        int hdr = b.getShort(pos + 2) & 0xFFFF;
        int size = b.getInt(pos + 4);
        int count = b.getInt(pos + 8);
        int styleCount = b.getInt(pos + 12);
        int flags = b.getInt(pos + 16);
        int stringsStart = b.getInt(pos + 20);
        int stylesStart = b.getInt(pos + 24);
        if (size < 28 || pos + size > d.length || count < 0 || styleCount < 0
                || (long) count * 4 + (long) styleCount * 4 + hdr > size) {
            throw new IOException("string pool header is not valid");
        }
        NixuPool p = new NixuPool();
        p.utf8 = (flags & 0x100) != 0;
        p.sorted = (flags & 0x1) != 0;
        p.readSize = size;
        for (int i = 0; i < count; i++) {
            int off = b.getInt(pos + hdr + 4 * i);
            int at = pos + stringsStart + off;
            if (stringsStart < 0 || off < 0 || at < pos || at >= pos + size) {
                p.strings.add("");
                continue;
            }
            p.strings.add(readString(d, at, pos + size, p.utf8));
        }
        p.styleCount = styleCount;
        p.styleOffsets = new int[styleCount];
        for (int i = 0; i < styleCount; i++) p.styleOffsets[i] = b.getInt(pos + hdr + 4 * count + 4 * i);
        if (styleCount > 0 && stylesStart > 0 && pos + stylesStart <= pos + size) {
            p.styles = new byte[size - stylesStart];
            System.arraycopy(d, pos + stylesStart, p.styles, 0, p.styles.length);
        }
        return p;
    }

    private static String readString(byte[] d, int at, int limit, boolean utf8) {
        try {
            if (utf8) {
                int p = at;
                int n1 = d[p++] & 0xFF;
                if ((n1 & 0x80) != 0) {
                    n1 = ((n1 & 0x7F) << 8) | (d[p++] & 0xFF);
                }
                int n2 = d[p++] & 0xFF;
                if ((n2 & 0x80) != 0) {
                    n2 = ((n2 & 0x7F) << 8) | (d[p++] & 0xFF);
                }
                if (n2 < 0 || p + n2 > limit) return "";
                return NixuDex.decodeMutf8(d, p, n2);
            }
            int p = at;
            int n = (d[p] & 0xFF) | ((d[p + 1] & 0xFF) << 8);
            p += 2;
            if ((n & 0x8000) != 0) {
                int lo = (d[p] & 0xFF) | ((d[p + 1] & 0xFF) << 8);
                p += 2;
                n = ((n & 0x7FFF) << 16) | lo;
            }
            if (n < 0 || p + n * 2 > limit) return "";
            return new String(d, p, n * 2, StandardCharsets.UTF_16LE);
        } catch (RuntimeException e) {
            return "";
        }
    }

    byte[] build() throws IOException {
        int n = strings.size();
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offs = new int[n];
        for (int i = 0; i < n; i++) {
            offs[i] = data.size();
            writeString(data, strings.get(i), utf8);
        }
        while (data.size() % 4 != 0) data.write(0);
        int stringsStart = 28 + 4 * n + 4 * styleCount;
        int stylesStart = styleCount > 0 ? stringsStart + data.size() : 0;
        int size = stringsStart + data.size() + (styleCount > 0 ? styles.length : 0);
        ByteBuffer o = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        o.putShort((short) 0x0001);
        o.putShort((short) 28);
        o.putInt(size);
        o.putInt(n);
        o.putInt(styleCount);
        o.putInt((utf8 ? 0x100 : 0) | (sorted ? 1 : 0));
        o.putInt(stringsStart);
        o.putInt(stylesStart);
        for (int i = 0; i < n; i++) o.putInt(offs[i]);
        for (int i = 0; i < styleCount; i++) o.putInt(styleOffsets[i]);
        o.put(data.toByteArray());
        if (styleCount > 0) o.put(styles);
        return o.array();
    }

    private static void writeString(ByteArrayOutputStream o, String s, boolean utf8) throws IOException {
        if (utf8) {
            byte[] b = s.getBytes(StandardCharsets.UTF_8);
            if (s.length() > 0x7FFF || b.length > 0x7FFF) throw new IOException("string is too long for a resource pool");
            len8(o, s.length());
            len8(o, b.length);
            o.write(b, 0, b.length);
            o.write(0);
        } else {
            int n = s.length();
            if (n > 0x7FFFFFFF >> 1) throw new IOException("string is too long");
            if (n > 0x7FFF) {
                int hi = (n >> 16) | 0x8000;
                o.write(hi & 0xFF);
                o.write((hi >> 8) & 0xFF);
                o.write(n & 0xFF);
                o.write((n >> 8) & 0xFF);
            } else {
                o.write(n & 0xFF);
                o.write((n >> 8) & 0xFF);
            }
            byte[] b = s.getBytes(StandardCharsets.UTF_16LE);
            o.write(b, 0, b.length);
            o.write(0);
            o.write(0);
        }
    }

    private static void len8(ByteArrayOutputStream o, int n) {
        if (n > 0x7F) {
            o.write(((n >> 8) & 0x7F) | 0x80);
            o.write(n & 0xFF);
        } else {
            o.write(n);
        }
    }

    /** Index of the first equal string, or -1. */
    int indexOf(String s) {
        for (int i = 0; i < strings.size(); i++) {
            if (strings.get(i).equals(s)) return i;
        }
        return -1;
    }
}
