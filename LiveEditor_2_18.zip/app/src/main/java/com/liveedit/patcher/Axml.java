package com.liveedit.patcher;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Reads and edits a compiled (binary) AndroidManifest.xml without any external tool.
 *
 * Binary XML = string pool + resource map (attribute name -> resource id) + element chunks.
 * Attribute names that carry a resource id sit in the first N strings of the pool (N = length of the
 * resource map). When an attribute we need is missing, its name is inserted right after that prefix and
 * every string reference at or above the insertion point is shifted. Attributes inside an element are
 * kept sorted by resource id, which Android requires.
 */
final class Axml {

    // ---- android attribute resource ids (same numbers as android.R.attr.*) -----------------
    static final int A_LABEL = 0x01010001;
    static final int A_NAME = 0x01010003;
    static final int A_ENABLED = 0x0101000e;
    static final int A_DEBUGGABLE = 0x0101000f;
    static final int A_EXPORTED = 0x01010010;
    static final int A_AUTHORITIES = 0x01010018;
    static final int A_INIT_ORDER = 0x0101001a;
    static final int A_ORIENTATION = 0x0101001e;
    static final int A_MIN_SDK = 0x0101020c;
    static final int A_VERSION_CODE = 0x0101021b;
    static final int A_VERSION_NAME = 0x0101021c;
    static final int A_TARGET_SDK = 0x01010270;
    static final int A_ALLOW_BACKUP = 0x01010280;
    static final int A_LARGE_HEAP = 0x0101035a;
    static final int A_CLEARTEXT = 0x010104ec;

    private static final int RES_XML = 0x0003;
    private static final int POOL = 0x0001;
    private static final int RESMAP = 0x0180;
    private static final int START_NS = 0x0100;
    private static final int END_NS = 0x0101;
    private static final int START_EL = 0x0102;
    private static final int END_EL = 0x0103;
    private static final int CDATA = 0x0104;

    private static final int T_STRING = 0x03;
    private static final int T_INT = 0x10;
    private static final int T_BOOL = 0x12;

    private static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";

    /** One activity / service / receiver / provider found in the manifest. */
    static final class Comp {
        String type;
        String name;
        boolean enabled = true;
        boolean exported;
        boolean launcher;
        final List<String> actions = new ArrayList<String>();
    }

    /** What the manifest says, for the options screen. */
    static final class Info {
        String pkg;
        String versionName;
        int versionCode;
        int minSdk;
        int targetSdk;
        final List<String> perms = new ArrayList<String>();
        final List<Comp> comps = new ArrayList<Comp>();
    }

    private boolean utf8;
    private final List<String> strings = new ArrayList<String>();
    private final List<Integer> resIds = new ArrayList<Integer>();
    private final List<byte[]> chunks = new ArrayList<byte[]>();

    private Axml() {}

    // =======================================================================================
    // parse / write
    // =======================================================================================

    static Axml parse(byte[] in) {
        ByteBuffer bb = ByteBuffer.wrap(in).order(ByteOrder.LITTLE_ENDIAN);
        if (in.length < 16 || (bb.getShort(0) & 0xFFFF) != RES_XML) {
            throw new IllegalArgumentException("AndroidManifest.xml is not binary XML");
        }
        Axml x = new Axml();
        int end = Math.min(in.length, bb.getInt(4));
        int pos = bb.getShort(2) & 0xFFFF;

        if ((bb.getShort(pos) & 0xFFFF) != POOL) throw new IllegalArgumentException("string pool not found");
        int poolHdr = bb.getShort(pos + 2) & 0xFFFF;
        int poolSize = bb.getInt(pos + 4);
        int stringCount = bb.getInt(pos + 8);
        int styleCount = bb.getInt(pos + 12);
        int flags = bb.getInt(pos + 16);
        int stringsStart = bb.getInt(pos + 20);
        x.utf8 = (flags & 0x100) != 0;
        // styles (rare in a manifest) are not kept: the strings are what matters
        for (int i = 0; i < stringCount; i++) {
            String sv;
            try {
                int off = bb.getInt(pos + poolHdr + 4 * i);
                sv = readString(bb, pos + stringsStart + off, x.utf8);
            } catch (RuntimeException re) {
                sv = ""; // a junk string slot (some protectors add them): keep the numbering
            }
            x.strings.add(sv);
        }
        pos += poolSize;

        if (pos + 8 <= end && (bb.getShort(pos) & 0xFFFF) == RESMAP) {
            int sz = bb.getInt(pos + 4);
            int n = (sz - 8) / 4;
            for (int i = 0; i < n; i++) x.resIds.add(Integer.valueOf(bb.getInt(pos + 8 + 4 * i)));
            pos += sz;
        }

        while (pos + 8 <= end) {
            int size = bb.getInt(pos + 4);
            if (size < 8 || pos + size > in.length) {
                // junk after the real document is ignored; a broken start is still an error
                if (!x.chunks.isEmpty()) break;
                throw new IllegalArgumentException("broken chunk at " + pos);
            }
            byte[] c = new byte[size];
            System.arraycopy(in, pos, c, 0, size);
            x.chunks.add(c);
            pos += size;
        }
        return x;
    }

    byte[] toBytes() {
        byte[] pool = writePool(strings, utf8);
        int total = 8 + pool.length + (8 + 4 * resIds.size());
        for (int i = 0; i < chunks.size(); i++) total += chunks.get(i).length;
        ByteBuffer out = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
        out.putShort((short) RES_XML);
        out.putShort((short) 8);
        out.putInt(total);
        out.put(pool);
        out.putShort((short) RESMAP);
        out.putShort((short) 8);
        out.putInt(8 + 4 * resIds.size());
        for (int i = 0; i < resIds.size(); i++) out.putInt(resIds.get(i).intValue());
        for (int i = 0; i < chunks.size(); i++) out.put(chunks.get(i));
        return out.array();
    }

    // =======================================================================================
    // reading
    // =======================================================================================

    Info info() {
        Info r = new Info();
        r.pkg = packageName();
        Comp cur = null;
        for (int i = 0; i < chunks.size(); i++) {
            byte[] c = chunks.get(i);
            ByteBuffer b = wrap(c);
            int type = b.getShort(0) & 0xFFFF;
            if (type == START_EL) {
                String n = str(b.getInt(20));
                if ("uses-permission".equals(n) || "uses-permission-sdk-23".equals(n)) {
                    String p = attrString(c, A_NAME);
                    if (p != null && !r.perms.contains(p)) r.perms.add(p);
                } else if ("manifest".equals(n)) {
                    r.versionCode = attrInt(c, A_VERSION_CODE, 0);
                    r.versionName = attrString(c, A_VERSION_NAME);
                } else if ("uses-sdk".equals(n)) {
                    r.minSdk = attrInt(c, A_MIN_SDK, 0);
                    r.targetSdk = attrInt(c, A_TARGET_SDK, 0);
                } else if (isComponent(n)) {
                    String nm = attrString(c, A_NAME);
                    if (nm != null) {
                        cur = new Comp();
                        cur.type = n;
                        cur.name = fullName(r.pkg, nm);
                        cur.enabled = attrBool(c, A_ENABLED, true);
                        cur.exported = attrBool(c, A_EXPORTED, false);
                        r.comps.add(cur);
                    } else {
                        cur = null;
                    }
                } else if (cur != null && "action".equals(n)) {
                    String a = attrString(c, A_NAME);
                    if (a != null) cur.actions.add(a);
                } else if (cur != null && "category".equals(n)) {
                    if ("android.intent.category.LAUNCHER".equals(attrString(c, A_NAME))) cur.launcher = true;
                }
            } else if (type == END_EL) {
                if (isComponent(str(b.getInt(20)))) cur = null;
            }
        }
        return r;
    }

    String packageName() {
        for (int i = 0; i < chunks.size(); i++) {
            byte[] c = chunks.get(i);
            ByteBuffer b = wrap(c);
            if ((b.getShort(0) & 0xFFFF) != START_EL) continue;
            if (!"manifest".equals(str(b.getInt(20)))) continue;
            int attrStart = b.getShort(24) & 0xFFFF;
            int attrSize = b.getShort(26) & 0xFFFF;
            int count = b.getShort(28) & 0xFFFF;
            for (int a = 0; a < count; a++) {
                int base = 16 + attrStart + a * attrSize;
                int an = b.getInt(base + 4);
                int raw = b.getInt(base + 8);
                if (b.getInt(base) == -1 && "package".equals(str(an)) && raw >= 0 && raw < strings.size()) {
                    return strings.get(raw);
                }
            }
            return null;
        }
        return null;
    }

    boolean hasString(String s) {
        return strings.contains(s);
    }

    // =======================================================================================
    // editing
    // =======================================================================================

    /** Removes every uses-permission whose name is in the set. Returns how many were removed. */
    int removePermissions(Set<String> names) {
        int removed = 0;
        for (int i = chunks.size() - 2; i >= 0; i--) {
            byte[] c = chunks.get(i);
            ByteBuffer b = wrap(c);
            if ((b.getShort(0) & 0xFFFF) != START_EL) continue;
            String n = str(b.getInt(20));
            if (!"uses-permission".equals(n) && !"uses-permission-sdk-23".equals(n)) continue;
            String p = attrString(c, A_NAME);
            if (p == null || !names.contains(p)) continue;
            ByteBuffer nx = wrap(chunks.get(i + 1));
            if ((nx.getShort(0) & 0xFFFF) != END_EL) continue; // has children: leave it alone
            chunks.remove(i + 1);
            chunks.remove(i);
            removed++;
        }
        return removed;
    }

    /** Sets android:enabled=false on the listed components (full class names). */
    int disableComponents(Set<String> names) {
        int done = 0;
        String pkg = packageName();
        for (int i = 0; i < chunks.size(); i++) {
            byte[] c = chunks.get(i);
            ByteBuffer b = wrap(c);
            if ((b.getShort(0) & 0xFFFF) != START_EL) continue;
            if (!isComponent(str(b.getInt(20)))) continue;
            String nm = attrString(c, A_NAME);
            if (nm == null || !names.contains(fullName(pkg, nm))) continue;
            setAttr(i, "enabled", A_ENABLED, -1, T_BOOL, 0);
            done++;
        }
        return done;
    }

    /** android:screenOrientation on every activity. value: 0 landscape, 1 portrait, 10 fullSensor, -1 unspecified. */
    int setOrientation(int value) {
        int done = 0;
        for (int i = 0; i < chunks.size(); i++) {
            if (!isStart(i, "activity")) continue;
            setAttr(i, "screenOrientation", A_ORIENTATION, -1, T_INT, value);
            done++;
        }
        return done;
    }

    /** Boolean attribute on the application element (debuggable, allowBackup, ...). */
    boolean setAppBool(String name, int resId, boolean value) {
        for (int i = 0; i < chunks.size(); i++) {
            if (!isStart(i, "application")) continue;
            setAttr(i, name, resId, -1, T_BOOL, value ? -1 : 0);
            return true;
        }
        return false;
    }

    /** Replaces the app name shown by the launcher (application label and any activity labels). */
    int setLabel(String label) {
        int done = 0;
        for (int i = 0; i < chunks.size(); i++) {
            boolean app = isStart(i, "application");
            boolean act = isStart(i, "activity") || isStart(i, "activity-alias");
            if (!app && !act) continue;
            if (act && findAttr(chunks.get(i), A_LABEL) < 0) continue; // inherits the application label
            setAttrString(i, "label", A_LABEL, label);
            done++;
        }
        return done;
    }

    /** versionCode (null = keep) and versionName (null = keep) on the manifest element. */
    boolean setVersion(Integer code, String name) {
        for (int i = 0; i < chunks.size(); i++) {
            if (!isStart(i, "manifest")) continue;
            if (code != null) setAttr(i, "versionCode", A_VERSION_CODE, -1, T_INT, code.intValue());
            if (name != null) setAttrString(i, "versionName", A_VERSION_NAME, name);
            return true;
        }
        return false;
    }

    /**
     * Adds <uses-permission android:name="..."/> (before <application>) unless the manifest already asks for it.
     * Returns true when it was added. Android only lets the user grant "Display over other apps" to an app that
     * asks for SYSTEM_ALERT_WINDOW here, so the pencil needs this.
     */
    boolean addPermission(String name) {
        for (int i = 0; i < chunks.size(); i++) {
            byte[] c = chunks.get(i);
            ByteBuffer b = wrap(c);
            if ((b.getShort(0) & 0xFFFF) != START_EL) continue;
            String n = str(b.getInt(20));
            if (("uses-permission".equals(n) || "uses-permission-sdk-23".equals(n)) && name.equals(attrString(c, A_NAME))) {
                return false;
            }
        }
        int nName = ensureName("name", A_NAME);
        int androidNs = strings.indexOf(ANDROID_NS);
        if (androidNs < 0) throw new IllegalArgumentException("android namespace not declared in manifest");

        int appStart = -1;
        for (int i = 0; i < chunks.size(); i++) {
            if (isStart(i, "application")) {
                appStart = i;
                break;
            }
        }
        if (appStart < 0) throw new IllegalArgumentException("<application> not found in manifest");

        int sTag = addString("uses-permission");
        int sName = addString(name);

        ByteBuffer s = ByteBuffer.allocate(56).order(ByteOrder.LITTLE_ENDIAN);
        s.putShort((short) START_EL);
        s.putShort((short) 16);
        s.putInt(56);
        s.putInt(0);
        s.putInt(-1);
        s.putInt(-1);
        s.putInt(sTag);
        s.putShort((short) 20);
        s.putShort((short) 20);
        s.putShort((short) 1);
        s.putShort((short) 0);
        s.putShort((short) 0);
        s.putShort((short) 0);
        putAttr(s, androidNs, nName, sName, T_STRING, sName);

        ByteBuffer e = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        e.putShort((short) END_EL);
        e.putShort((short) 16);
        e.putInt(24);
        e.putInt(0);
        e.putInt(-1);
        e.putInt(-1);
        e.putInt(sTag);

        chunks.add(appStart, e.array());
        chunks.add(appStart, s.array());
        return true;
    }

    /** Adds a non-exported provider with an initOrder as high as possible, as the first thing the app starts. */
    boolean addProvider(String providerClass, String authority) {
        int nName = ensureName("name", A_NAME);
        int nExp = ensureName("exported", A_EXPORTED);
        int nAuth = ensureName("authorities", A_AUTHORITIES);
        int nInit = ensureName("initOrder", A_INIT_ORDER);
        int androidNs = strings.indexOf(ANDROID_NS);
        if (androidNs < 0) throw new IllegalArgumentException("android namespace not declared in manifest");

        int appEnd = -1;
        for (int i = 0; i < chunks.size(); i++) {
            ByteBuffer c = wrap(chunks.get(i));
            if ((c.getShort(0) & 0xFFFF) == END_EL && "application".equals(str(c.getInt(20)))) {
                appEnd = i;
                break;
            }
        }
        if (appEnd < 0) throw new IllegalArgumentException("<application> not found in manifest");

        int sProvider = addString("provider");
        int sClass = addString(providerClass);
        int sAuth = addString(authority);

        ByteBuffer s = ByteBuffer.allocate(116).order(ByteOrder.LITTLE_ENDIAN);
        s.putShort((short) START_EL);
        s.putShort((short) 16);
        s.putInt(116);
        s.putInt(0);
        s.putInt(-1);
        s.putInt(-1);
        s.putInt(sProvider);
        s.putShort((short) 20);
        s.putShort((short) 20);
        s.putShort((short) 4);
        s.putShort((short) 0);
        s.putShort((short) 0);
        s.putShort((short) 0);
        // sorted by resource id: name, exported, authorities, initOrder
        putAttr(s, androidNs, nName, sClass, T_STRING, sClass);
        // exported: the Live Editor app asks it for the live settings (only that app gets an answer, see AgentProvider)
        putAttr(s, androidNs, nExp, -1, T_BOOL, -1);
        putAttr(s, androidNs, nAuth, sAuth, T_STRING, sAuth);
        putAttr(s, androidNs, nInit, -1, T_INT, 0x7FFFFFFF);

        ByteBuffer e = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        e.putShort((short) END_EL);
        e.putShort((short) 16);
        e.putInt(24);
        e.putInt(0);
        e.putInt(-1);
        e.putInt(-1);
        e.putInt(sProvider);

        chunks.add(appEnd, e.array());
        chunks.add(appEnd, s.array());
        return true;
    }

    // =======================================================================================
    // helpers
    // =======================================================================================

    private static boolean isComponent(String n) {
        return "activity".equals(n) || "service".equals(n) || "receiver".equals(n)
                || "provider".equals(n) || "activity-alias".equals(n);
    }

    static String fullName(String pkg, String n) {
        if (n == null) return null;
        if (n.startsWith(".")) return (pkg == null ? "" : pkg) + n;
        if (n.indexOf('.') < 0) return (pkg == null ? "" : pkg + ".") + n;
        return n;
    }

    private static ByteBuffer wrap(byte[] c) {
        return ByteBuffer.wrap(c).order(ByteOrder.LITTLE_ENDIAN);
    }

    private String str(int i) {
        return i >= 0 && i < strings.size() ? strings.get(i) : null;
    }

    private boolean isStart(int ci, String name) {
        ByteBuffer b = wrap(chunks.get(ci));
        return (b.getShort(0) & 0xFFFF) == START_EL && name.equals(str(b.getInt(20)));
    }

    private int resIdOfName(int nameIdx) {
        return nameIdx >= 0 && nameIdx < resIds.size() ? resIds.get(nameIdx).intValue() : 0;
    }

    /** Index of the attribute (inside the element chunk) that carries this resource id, or -1. */
    private int findAttr(byte[] c, int resId) {
        ByteBuffer b = wrap(c);
        int attrStart = b.getShort(24) & 0xFFFF;
        int attrSize = b.getShort(26) & 0xFFFF;
        int count = b.getShort(28) & 0xFFFF;
        for (int a = 0; a < count; a++) {
            int base = 16 + attrStart + a * attrSize;
            if (resIdOfName(b.getInt(base + 4)) == resId) return a;
        }
        return -1;
    }

    private int attrBase(byte[] c, int a) {
        ByteBuffer b = wrap(c);
        return 16 + (b.getShort(24) & 0xFFFF) + a * (b.getShort(26) & 0xFFFF);
    }

    private String attrString(byte[] c, int resId) {
        int a = findAttr(c, resId);
        if (a < 0) return null;
        ByteBuffer b = wrap(c);
        int base = attrBase(c, a);
        int raw = b.getInt(base + 8);
        if (raw >= 0 && raw < strings.size()) return strings.get(raw);
        if ((b.get(base + 15) & 0xFF) == T_STRING) return str(b.getInt(base + 16));
        return null;
    }

    private int attrInt(byte[] c, int resId, int def) {
        int a = findAttr(c, resId);
        if (a < 0) return def;
        ByteBuffer b = wrap(c);
        int base = attrBase(c, a);
        int t = b.get(base + 15) & 0xFF;
        return (t == T_INT || t == 0x11) ? b.getInt(base + 16) : def;
    }

    private boolean attrBool(byte[] c, int resId, boolean def) {
        int a = findAttr(c, resId);
        if (a < 0) return def;
        ByteBuffer b = wrap(c);
        int base = attrBase(c, a);
        return (b.get(base + 15) & 0xFF) == T_BOOL ? b.getInt(base + 16) != 0 : def;
    }

    private int addString(String s) {
        int i = strings.indexOf(s);
        if (i >= 0) return i;
        strings.add(s);
        return strings.size() - 1;
    }

    /** Index of the attribute-name string for this resource id. Inserts it (and shifts references) if missing. */
    private int ensureName(String name, int resId) {
        for (int i = 0; i < resIds.size(); i++) {
            if (resIds.get(i).intValue() == resId) return i;
        }
        int at = resIds.size();
        strings.add(at, name);
        resIds.add(Integer.valueOf(resId));
        for (int i = 0; i < chunks.size(); i++) remap(chunks.get(i), at, 1);
        return at;
    }

    private void setAttrString(int ci, String name, int resId, String value) {
        if (findAttr(chunks.get(ci), resId) < 0) ensureName(name, resId);
        int s = addString(value);
        setAttr(ci, name, resId, s, T_STRING, s);
    }

    /** Overwrites the attribute if the element has it, otherwise inserts it in resource-id order. */
    private void setAttr(int ci, String name, int resId, int raw, int type, int data) {
        byte[] c = chunks.get(ci);
        int a = findAttr(c, resId);
        if (a >= 0) {
            ByteBuffer b = wrap(c);
            int base = attrBase(c, a);
            b.putInt(base + 8, raw);
            b.putShort(base + 12, (short) 8);
            b.put(base + 14, (byte) 0);
            b.put(base + 15, (byte) type);
            b.putInt(base + 16, data);
            return;
        }
        int nameIdx = ensureName(name, resId);
        c = chunks.get(ci); // arrays are patched in place by ensureName, same object
        ByteBuffer b = wrap(c);
        int attrStart = b.getShort(24) & 0xFFFF;
        int attrSize = b.getShort(26) & 0xFFFF;
        int count = b.getShort(28) & 0xFFFF;
        if (attrSize != 20) throw new IllegalArgumentException("unexpected attribute size " + attrSize);

        int pos = count;
        for (int k = 0; k < count; k++) {
            int rid = resIdOfName(b.getInt(16 + attrStart + k * attrSize + 4));
            if (rid == 0 || rid > resId) {
                pos = k;
                break;
            }
        }
        int nsIdx = strings.indexOf(ANDROID_NS);
        if (nsIdx < 0) throw new IllegalArgumentException("android namespace not declared in manifest");

        byte[] out = new byte[c.length + attrSize];
        int cut = 16 + attrStart + pos * attrSize;
        System.arraycopy(c, 0, out, 0, cut);
        ByteBuffer o = wrap(out);
        o.position(cut);
        putAttr(o, nsIdx, nameIdx, raw, type, data);
        System.arraycopy(c, cut, out, cut + attrSize, c.length - cut);
        o.putInt(4, out.length);
        o.putShort(28, (short) (count + 1));
        for (int off = 30; off <= 34; off += 2) { // idIndex, classIndex, styleIndex are 1-based
            int v = o.getShort(off) & 0xFFFF;
            if (v != 0 && v - 1 >= pos) o.putShort(off, (short) (v + 1));
        }
        chunks.set(ci, out);
    }

    private static void putAttr(ByteBuffer b, int ns, int name, int raw, int type, int data) {
        b.putInt(ns);
        b.putInt(name);
        b.putInt(raw);
        b.putShort((short) 8);
        b.put((byte) 0);
        b.put((byte) type);
        b.putInt(data);
    }

    /** Shift every string index >= insertAt by k inside one chunk. */
    private static void remap(byte[] chunk, int insertAt, int k) {
        ByteBuffer c = wrap(chunk);
        int type = c.getShort(0) & 0xFFFF;
        if (type == START_NS || type == END_NS) {
            fix(c, 12, insertAt, k);
            fix(c, 16, insertAt, k);
            fix(c, 20, insertAt, k);
        } else if (type == START_EL) {
            fix(c, 12, insertAt, k);
            fix(c, 16, insertAt, k);
            fix(c, 20, insertAt, k);
            int attrStart = c.getShort(24) & 0xFFFF;
            int attrSize = c.getShort(26) & 0xFFFF;
            int count = c.getShort(28) & 0xFFFF;
            for (int a = 0; a < count; a++) {
                int base = 16 + attrStart + a * attrSize;
                fix(c, base, insertAt, k);
                fix(c, base + 4, insertAt, k);
                fix(c, base + 8, insertAt, k);
                if ((c.get(base + 15) & 0xFF) == T_STRING) fix(c, base + 16, insertAt, k);
            }
        } else if (type == END_EL) {
            fix(c, 12, insertAt, k);
            fix(c, 16, insertAt, k);
            fix(c, 20, insertAt, k);
        } else if (type == CDATA) {
            fix(c, 12, insertAt, k);
            fix(c, 16, insertAt, k);
            if ((c.get(23) & 0xFF) == T_STRING) fix(c, 24, insertAt, k);
        }
    }

    private static void fix(ByteBuffer c, int off, int insertAt, int k) {
        int v = c.getInt(off);
        if (v >= insertAt) c.putInt(off, v + k);
    }

    // ---- string pool encode / decode -----------------------------------------------------

    private static String readString(ByteBuffer bb, int at, boolean utf8) {
        int p = at;
        if (utf8) {
            int u16len = bb.get(p) & 0xFF;
            p++;
            if ((u16len & 0x80) != 0) {
                p++;
            }
            int u8len = bb.get(p) & 0xFF;
            p++;
            if ((u8len & 0x80) != 0) {
                u8len = ((u8len & 0x7F) << 8) | (bb.get(p) & 0xFF);
                p++;
            }
            byte[] b = new byte[u8len];
            for (int i = 0; i < u8len; i++) b[i] = bb.get(p + i);
            return new String(b, StandardCharsets.UTF_8);
        }
        int len = bb.getShort(p) & 0xFFFF;
        p += 2;
        if ((len & 0x8000) != 0) {
            len = ((len & 0x7FFF) << 16) | (bb.getShort(p) & 0xFFFF);
            p += 2;
        }
        char[] ch = new char[len];
        for (int i = 0; i < len; i++) ch[i] = (char) (bb.getShort(p + 2 * i) & 0xFFFF);
        return new String(ch);
    }

    private static byte[] writePool(List<String> strings, boolean utf8) {
        int n = strings.size();
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offs = new int[n];
        for (int i = 0; i < n; i++) {
            offs[i] = data.size();
            String s = strings.get(i);
            if (utf8) {
                byte[] b = s.getBytes(StandardCharsets.UTF_8);
                writeLen8(data, s.length());
                writeLen8(data, b.length);
                data.write(b, 0, b.length);
                data.write(0);
            } else {
                int len = s.length();
                if (len > 0x7FFF) {
                    int hi = (len >> 16) | 0x8000;
                    data.write(hi & 0xFF);
                    data.write((hi >> 8) & 0xFF);
                    data.write(len & 0xFF);
                    data.write((len >> 8) & 0xFF);
                } else {
                    data.write(len & 0xFF);
                    data.write((len >> 8) & 0xFF);
                }
                for (int j = 0; j < len; j++) {
                    char ch = s.charAt(j);
                    data.write(ch & 0xFF);
                    data.write((ch >> 8) & 0xFF);
                }
                data.write(0);
                data.write(0);
            }
        }
        while (data.size() % 4 != 0) data.write(0);

        int hdr = 28;
        int stringsStart = hdr + 4 * n;
        int size = stringsStart + data.size();
        ByteBuffer out = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        out.putShort((short) POOL);
        out.putShort((short) hdr);
        out.putInt(size);
        out.putInt(n);
        out.putInt(0);
        out.putInt(utf8 ? 0x100 : 0);
        out.putInt(stringsStart);
        out.putInt(0);
        for (int i = 0; i < n; i++) out.putInt(offs[i]);
        out.put(data.toByteArray());
        return out.array();
    }

    private static void writeLen8(ByteArrayOutputStream o, int n) {
        if (n > 0x7F) {
            o.write((n >> 8) | 0x80);
            o.write(n & 0xFF);
        } else {
            o.write(n);
        }
    }
}
