package com.liveedit.patcher;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 * Own zip reader / writer for the nixu cn browser. It lists EVERY entry of the APK (nothing is hidden), reads
 * entries without trusting extra checks, and writes a new APK where untouched entries are copied byte for byte.
 */
final class NixuZip {

    static final class E {
        String name;
        byte[] nameBytes;
        int versionMadeBy;
        int flags;
        int method;
        int time;
        int date;
        long crc;
        long compSize;
        long size;
        int intAttr;
        long extAttr;
        long localOffset;
        long dataOffset = -1;
        byte[] cdExtra = new byte[0];
        byte[] comment = new byte[0];

        boolean isDir() {
            return name.endsWith("/");
        }

        /** Milliseconds since 1970 from the DOS date and time (local time). */
        long millis() {
            Calendar c = Calendar.getInstance();
            c.clear();
            c.set(1980 + ((date >> 9) & 0x7F), Math.max(0, ((date >> 5) & 0xF) - 1), Math.max(1, date & 0x1F),
                    (time >> 11) & 0x1F, (time >> 5) & 0x3F, (time & 0x1F) * 2);
            return c.getTimeInMillis();
        }
    }

    /** Changes to apply when saving. */
    static final class Plan {
        final Set<String> delete = new HashSet<String>();
        /** name -> file with the new content (name ending in / = empty folder entry). */
        final java.util.LinkedHashMap<String, File> put = new java.util.LinkedHashMap<String, File>();
    }

    private static final int BAD_FLAGS = 0x0001 | 0x0040 | 0x2000;

    private NixuZip() {}

    static List<E> read(File f) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(f, "r");
        try {
            return readEntries(raf);
        } finally {
            raf.close();
        }
    }

    private static List<E> readEntries(RandomAccessFile raf) throws IOException {
        long len = raf.length();
        int scan = (int) Math.min(len, 65557);
        byte[] tail = new byte[scan];
        raf.seek(len - scan);
        raf.readFully(tail);
        int eocd = -1;
        for (int i = scan - 22; i >= 0; i--) {
            if (tail[i] == 0x50 && tail[i + 1] == 0x4b && tail[i + 2] == 0x05 && tail[i + 3] == 0x06) {
                eocd = i;
                break;
            }
        }
        if (eocd < 0) throw new IOException("Not a zip/APK file (no end record)");
        ByteBuffer t = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN);
        int count = t.getShort(eocd + 10) & 0xFFFF;
        long cdSize = t.getInt(eocd + 12) & 0xFFFFFFFFL;
        long cdOffset = t.getInt(eocd + 16) & 0xFFFFFFFFL;
        if (count == 0xFFFF || cdOffset == 0xFFFFFFFFL) throw new IOException("Zip64 APK is not supported");
        if (cdOffset + cdSize > len) throw new IOException("Broken central directory");
        byte[] cd = new byte[(int) cdSize];
        raf.seek(cdOffset);
        raf.readFully(cd);
        ByteBuffer c = ByteBuffer.wrap(cd).order(ByteOrder.LITTLE_ENDIAN);
        List<E> list = new ArrayList<E>();
        int p = 0;
        for (int i = 0; i < count; i++) {
            if (p + 46 > cd.length || c.getInt(p) != 0x02014b50) throw new IOException("Broken central directory");
            E e = new E();
            e.versionMadeBy = c.getShort(p + 4) & 0xFFFF;
            e.flags = c.getShort(p + 8) & 0xFFFF;
            e.method = c.getShort(p + 10) & 0xFFFF;
            e.time = c.getShort(p + 12) & 0xFFFF;
            e.date = c.getShort(p + 14) & 0xFFFF;
            e.crc = c.getInt(p + 16) & 0xFFFFFFFFL;
            e.compSize = c.getInt(p + 20) & 0xFFFFFFFFL;
            e.size = c.getInt(p + 24) & 0xFFFFFFFFL;
            int nameLen = c.getShort(p + 28) & 0xFFFF;
            int extraLen = c.getShort(p + 30) & 0xFFFF;
            int commentLen = c.getShort(p + 32) & 0xFFFF;
            e.intAttr = c.getShort(p + 36) & 0xFFFF;
            e.extAttr = c.getInt(p + 38) & 0xFFFFFFFFL;
            e.localOffset = c.getInt(p + 42) & 0xFFFFFFFFL;
            if (p + 46 + nameLen + extraLen + commentLen > cd.length) throw new IOException("Broken central directory");
            e.nameBytes = new byte[nameLen];
            System.arraycopy(cd, p + 46, e.nameBytes, 0, nameLen);
            e.name = new String(e.nameBytes, StandardCharsets.UTF_8);
            e.cdExtra = new byte[extraLen];
            System.arraycopy(cd, p + 46 + nameLen, e.cdExtra, 0, extraLen);
            e.comment = new byte[commentLen];
            System.arraycopy(cd, p + 46 + nameLen + extraLen, e.comment, 0, commentLen);
            p += 46 + nameLen + extraLen + commentLen;
            try {
                byte[] lh = new byte[30];
                raf.seek(e.localOffset);
                raf.readFully(lh);
                ByteBuffer l = ByteBuffer.wrap(lh).order(ByteOrder.LITTLE_ENDIAN);
                if (l.getInt(0) == 0x04034b50) {
                    e.dataOffset = e.localOffset + 30 + (l.getShort(26) & 0xFFFF) + (l.getShort(28) & 0xFFFF);
                }
            } catch (IOException ex) {
                e.dataOffset = -1;
            }
            list.add(e);
        }
        return list;
    }

    private static final long MAX_READ = 300L * 1024 * 1024;

    /** Content of one entry (decompressed). */
    static byte[] bytes(File f, E e) throws IOException {
        if (e.dataOffset < 0) throw new IOException("The header of " + e.name + " is broken");
        if (e.size > MAX_READ || e.compSize > MAX_READ) throw new IOException(e.name + " is too big to open here");
        RandomAccessFile raf = new RandomAccessFile(f, "r");
        try {
            byte[] raw = new byte[(int) e.compSize];
            raf.seek(e.dataOffset);
            raf.readFully(raw);
            if (e.method == 0) return raw;
            if (e.method != 8) throw new IOException("Unknown compression method " + e.method);
            Inflater inf = new Inflater(true);
            try {
                inf.setInput(raw);
                ByteArrayOutputStream out = new ByteArrayOutputStream((int) Math.max(64, Math.min(e.size, MAX_READ)));
                byte[] buf = new byte[1 << 16];
                while (!inf.finished()) {
                    int n = inf.inflate(buf);
                    if (n == 0 && (inf.needsInput() || inf.needsDictionary())) {
                        throw new IOException(e.name + " is cut off or really encrypted");
                    }
                    out.write(buf, 0, n);
                }
                return out.toByteArray();
            } catch (java.util.zip.DataFormatException ex) {
                throw new IOException(e.name + " is not valid compressed data (encrypted or damaged): " + ex.getMessage());
            } finally {
                inf.end();
            }
        } finally {
            raf.close();
        }
    }

    /** True for the old v1 signature files (they are dropped on save, the new signature replaces them). */
    static boolean isSignatureFile(String name) {
        String n = name.toUpperCase(Locale.US);
        if (!n.startsWith("META-INF/")) return false;
        String rest = n.substring(9);
        if (rest.indexOf('/') >= 0) return false;
        return rest.equals("MANIFEST.MF") || rest.endsWith(".SF") || rest.endsWith(".RSA") || rest.endsWith(".DSA")
                || rest.endsWith(".EC");
    }

    // =======================================================================================
    // writing
    // =======================================================================================

    private static final class Counter extends OutputStream {
        private final OutputStream out;
        long count;

        Counter(OutputStream out) {
            this.out = out;
        }

        @Override
        public void write(int b) throws IOException {
            out.write(b);
            count++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            count += len;
        }

        @Override
        public void flush() throws IOException {
            out.flush();
        }
    }

    private static int pad(Counter o, int nameLen, int method, String name) {
        if (method != 0) return 0;
        int align = name.endsWith(".so") ? 4096 : 4;
        long start = o.count + 30 + nameLen;
        return (int) ((align - (start % align)) % align);
    }

    private static void local(Counter o, E e, int pad) throws IOException {
        e.localOffset = o.count;
        ByteBuffer h = ByteBuffer.allocate(30).order(ByteOrder.LITTLE_ENDIAN);
        h.putInt(0x04034b50);
        h.putShort((short) 20);
        h.putShort((short) (e.flags & ~0x08));
        h.putShort((short) e.method);
        h.putShort((short) e.time);
        h.putShort((short) e.date);
        h.putInt((int) e.crc);
        h.putInt((int) e.compSize);
        h.putInt((int) e.size);
        h.putShort((short) e.nameBytes.length);
        h.putShort((short) pad);
        o.write(h.array());
        o.write(e.nameBytes);
        if (pad > 0) o.write(new byte[pad]);
    }

    private static void central(Counter o, E e) throws IOException {
        ByteBuffer h = ByteBuffer.allocate(46).order(ByteOrder.LITTLE_ENDIAN);
        h.putInt(0x02014b50);
        h.putShort((short) e.versionMadeBy);
        h.putShort((short) 20);
        h.putShort((short) (e.flags & ~0x08));
        h.putShort((short) e.method);
        h.putShort((short) e.time);
        h.putShort((short) e.date);
        h.putInt((int) e.crc);
        h.putInt((int) e.compSize);
        h.putInt((int) e.size);
        h.putShort((short) e.nameBytes.length);
        h.putShort((short) e.cdExtra.length);
        h.putShort((short) e.comment.length);
        h.putShort((short) 0);
        h.putShort((short) e.intAttr);
        h.putInt((int) e.extAttr);
        h.putInt((int) e.localOffset);
        o.write(h.array());
        o.write(e.nameBytes);
        o.write(e.cdExtra);
        o.write(e.comment);
    }

    private static int dosTime(Calendar c) {
        return (c.get(Calendar.HOUR_OF_DAY) << 11) | (c.get(Calendar.MINUTE) << 5) | (c.get(Calendar.SECOND) / 2);
    }

    private static int dosDate(Calendar c) {
        return ((Math.max(1980, c.get(Calendar.YEAR)) - 1980) << 9) | ((c.get(Calendar.MONTH) + 1) << 5) | c.get(Calendar.DAY_OF_MONTH);
    }

    private static E writeNew(Counter o, String name, File src) throws IOException {
        E e = new E();
        e.name = name;
        e.nameBytes = name.getBytes(StandardCharsets.UTF_8);
        e.versionMadeBy = 20;
        e.flags = 0x0800;
        Calendar now = Calendar.getInstance();
        e.time = dosTime(now);
        e.date = dosDate(now);
        if (name.endsWith("/")) {
            e.method = 0;
            e.crc = 0;
            e.size = 0;
            e.compSize = 0;
            e.extAttr = 0x10;
            local(o, e, 0);
            return e;
        }
        long len = src.length();
        CRC32 crc = new CRC32();
        InputStream in = new FileInputStream(src);
        try {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) crc.update(buf, 0, n);
        } finally {
            in.close();
        }
        e.crc = crc.getValue();
        e.size = len;
        // resources.arsc and native libraries must be stored (not compressed) and aligned so Android can map them
        boolean store = name.equals("resources.arsc") || name.endsWith(".so") || len > 96L * 1024 * 1024;
        if (store) {
            e.method = 0;
            e.compSize = len;
            local(o, e, pad(o, e.nameBytes.length, 0, name));
            in = new FileInputStream(src);
            try {
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            } finally {
                in.close();
            }
            return e;
        }
        byte[] data = new byte[(int) len];
        in = new FileInputStream(src);
        try {
            int off = 0;
            while (off < data.length) {
                int n = in.read(data, off, data.length - off);
                if (n < 0) break;
                off += n;
            }
        } finally {
            in.close();
        }
        Deflater d = new Deflater(Deflater.DEFAULT_COMPRESSION, true);
        d.setInput(data);
        d.finish();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        while (!d.finished()) {
            int n = d.deflate(buf);
            bo.write(buf, 0, n);
        }
        d.end();
        byte[] comp = bo.toByteArray();
        e.method = 8;
        e.compSize = comp.length;
        local(o, e, 0);
        o.write(comp);
        return e;
    }

    /**
     * Writes a new zip. Entries in plan.delete and plan.put are not copied from the original; put entries are added at the
     * end. Old signature files are always left out (the caller signs the result).
     */
    static int rewrite(File in, File out, Plan plan) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(in, "r");
        try {
            List<E> entries = readEntries(raf);
            OutputStream fos = new BufferedOutputStream(new FileOutputStream(out), 1 << 16);
            Counter o = new Counter(fos);
            List<E> written = new ArrayList<E>();
            try {
                for (E e : entries) {
                    if (isSignatureFile(e.name) || plan.delete.contains(e.name) || plan.put.containsKey(e.name)) continue;
                    if (e.dataOffset < 0) throw new IOException("The header of " + e.name + " is broken; cannot copy it");
                    local(o, e, pad(o, e.nameBytes.length, e.method, e.name));
                    raf.seek(e.dataOffset);
                    byte[] buf = new byte[1 << 16];
                    long left = e.compSize;
                    while (left > 0) {
                        int n = raf.read(buf, 0, (int) Math.min(buf.length, left));
                        if (n < 0) throw new IOException("Unexpected end of file while copying " + e.name);
                        o.write(buf, 0, n);
                        left -= n;
                    }
                    written.add(e);
                }
                for (Map.Entry<String, File> x : plan.put.entrySet()) {
                    if (plan.delete.contains(x.getKey()) && !x.getValue().exists()) continue;
                    written.add(writeNew(o, x.getKey(), x.getValue()));
                }
                long cdStart = o.count;
                for (E e : written) central(o, e);
                long cdSize = o.count - cdStart;
                ByteBuffer eocd = ByteBuffer.allocate(22).order(ByteOrder.LITTLE_ENDIAN);
                eocd.putInt(0x06054b50);
                eocd.putShort((short) 0);
                eocd.putShort((short) 0);
                eocd.putShort((short) written.size());
                eocd.putShort((short) written.size());
                eocd.putInt((int) cdSize);
                eocd.putInt((int) cdStart);
                eocd.putShort((short) 0);
                o.write(eocd.array());
            } finally {
                o.flush();
                fos.close();
            }
            return written.size();
        } finally {
            raf.close();
        }
    }
}
