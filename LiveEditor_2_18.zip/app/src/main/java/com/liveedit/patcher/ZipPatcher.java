package com.liveedit.patcher;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 * Rewrites an APK without recompressing anything: existing entries are copied byte for byte
 * (so encrypted or packed dex files stay exactly as they are), old signature files are dropped,
 * AndroidManifest.xml is replaced, an optional dex and extra files are added, unwanted entries can be
 * left out, and stored entries are aligned like zipalign does.
 */
final class ZipPatcher {

    private static final int DOS_DATE = (1 << 5) | 1; // 1980-01-01
    private static final int DOS_TIME = 0;

    private static final class Entry {
        String name;
        byte[] nameBytes;
        int versionMadeBy;
        int flags;
        int method;
        int time;
        int date;
        long crc;
        long compSize;
        long size;
        int intAttr;
        long extAttr;
        long localOffset;
        long dataOffset;
        byte[] cdExtra;
        byte[] comment;
    }

    static final class Info {
        /** Name given to the added dex, for example classes3.dex (null when no dex was added). */
        String addedDex;
        int copied;
        int dropped;
        /** Entries removed by the caller's filter (for example other CPU types). */
        int filtered;
        /** Normal mode: entries whose header was repaired (fake encryption flag, wrong size or checksum). */
        int fixed;
        /** Normal mode: entries that still look wrong and could not be repaired (really encrypted or cut off). */
        int unfixed;
    }

    /** Decides which original entries are left out of the new APK. */
    interface Filter {
        boolean drop(String name);
    }

    private ZipPatcher() {}

    /** Reads the raw bytes of one entry (decompressing if needed). Used for AndroidManifest.xml. */
    static byte[] readEntry(File apk, String name) throws IOException {
        java.util.zip.ZipFile z = new java.util.zip.ZipFile(apk);
        try {
            java.util.zip.ZipEntry e = z.getEntry(name);
            if (e == null) return null;
            java.io.InputStream in = z.getInputStream(e);
            try {
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toByteArray();
            } finally {
                in.close();
            }
        } finally {
            z.close();
        }
    }

    /**
     * Same as readEntry, but when ZipFile fails for ANY reason (fake "encrypted" flag, wrong checksum, odd header, a
     * bug in the phone's zip code) the entry is read with our own zip reader, which ignores all of that.
     * Returns null when the entry is not in the file.
     */
    static byte[] readEntrySafe(File apk, String name) throws IOException {
        try {
            return readEntry(apk, name);
        } catch (Throwable t) {
            // fall through to our own reader
        }
        return readEntryRaw(apk, name);
    }

    /** Reads one entry with our own zip reader (central directory + inflate). null when the entry is not there. */
    static byte[] readEntryRaw(File apk, String name) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(apk, "r");
        try {
            List<Entry> es = readEntries(raf, true);
            for (int i = 0; i < es.size(); i++) {
                Entry e = es.get(i);
                if (e.name.equals(name)) return readData(raf, e);
            }
            return null;
        } finally {
            raf.close();
        }
    }

    /** What forEach hands to its caller for one entry: read() gives the uncompressed bytes. */
    interface Data {
        byte[] read() throws IOException;
    }

    interface Visitor {
        void entry(String name, long size, Data data) throws Exception;
    }

    /** Walks every file entry with our own zip reader. One entry failing never stops the walk. */
    static void forEach(File apk, final Visitor v) throws IOException {
        final RandomAccessFile raf = new RandomAccessFile(apk, "r");
        try {
            List<Entry> es = readEntries(raf, true);
            for (int i = 0; i < es.size(); i++) {
                final Entry e = es.get(i);
                if (e.name.endsWith("/")) continue;
                try {
                    v.entry(e.name, e.size, new Data() {
                        @Override
                        public byte[] read() throws IOException {
                            return readData(raf, e);
                        }
                    });
                } catch (Throwable t) {
                    // skip this entry
                }
            }
        } finally {
            raf.close();
        }
    }

    private static byte[] readData(RandomAccessFile raf, Entry e) throws IOException {
        if (e.compSize < 0 || e.compSize > 400L * 1024 * 1024) throw new IOException("entry too big: " + e.name);
        byte[] raw = new byte[(int) e.compSize];
        raf.seek(e.dataOffset);
        raf.readFully(raw);
        if (e.method == 0) return raw;
        if (e.method == 8) {
            try {
                return inflate(raw, e.size);
            } catch (IOException ioe) {
                throw ioe;
            } catch (Exception ex) {
                throw new IOException("cannot unpack " + e.name + ": " + ex);
            }
        }
        throw new IOException("unsupported compression (" + e.method + ") in " + e.name);
    }

    /**
     * @param newDex  dex to add as the next free classesN.dex, or null to add none
     * @param extras  more files to add (name -> bytes), or null; an original entry with the same name is replaced
     * @param filter  entries to leave out, or null
     */
    static Info rewrite(File in, File out, byte[] newManifest, byte[] newDex,
                        Map<String, byte[]> extras, Filter filter) throws IOException {
        return rewrite(in, out, newManifest, newDex, extras, filter, false);
    }

    /**
     * Same, with a normal-structure mode: every entry is opened and checked. Tricks that make tools such as MT Manager
     * refuse the file (an "encrypted" flag on data that is not encrypted, a wrong size or checksum in the header) are
     * repaired; the data itself is never changed. newManifest may be null to keep the original manifest.
     */
    static Info rewrite(File in, File out, byte[] newManifest, byte[] newDex,
                        Map<String, byte[]> extras, Filter filter, boolean normalize) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(in, "r");
        try {
            List<Entry> entries = readEntries(raf, normalize);
            Info info = new Info();

            int maxDex = 0;
            Pattern dexName = Pattern.compile("classes(\\d*)\\.dex");
            for (int i = 0; i < entries.size(); i++) {
                Matcher m = dexName.matcher(entries.get(i).name);
                if (m.matches()) {
                    int n = m.group(1).length() == 0 ? 1 : Integer.parseInt(m.group(1));
                    if (n > maxDex) maxDex = n;
                }
            }
            int next = maxDex + 1;
            info.addedDex = newDex == null ? null : (next == 1 ? "classes.dex" : "classes" + next + ".dex");
            Set<String> replaced = new HashSet<String>();
            if (extras != null) replaced.addAll(extras.keySet());

            OutputStream fos = new BufferedOutputStream(new FileOutputStream(out), 1 << 16);
            Counter o = new Counter(fos);
            List<Entry> written = new ArrayList<Entry>();
            try {
                for (int i = 0; i < entries.size(); i++) {
                    Entry e = entries.get(i);
                    if ((newManifest != null && e.name.equals("AndroidManifest.xml")) || isSignatureFile(e.name)
                            || replaced.contains(e.name)) {
                        info.dropped++;
                        continue;
                    }
                    if (filter != null && filter.drop(e.name)) {
                        info.filtered++;
                        continue;
                    }
                    if (normalize) writeChecked(raf, o, e, info);
                    else writeRaw(raf, o, e);
                    written.add(e);
                    info.copied++;
                }
                if (newManifest != null) written.add(writeNew(o, "AndroidManifest.xml", newManifest));
                if (newDex != null) written.add(writeNew(o, info.addedDex, newDex));
                if (extras != null) {
                    for (Map.Entry<String, byte[]> x : extras.entrySet()) {
                        written.add(writeNew(o, x.getKey(), x.getValue()));
                    }
                }

                long cdStart = o.count;
                for (int i = 0; i < written.size(); i++) writeCentral(o, written.get(i));
                long cdSize = o.count - cdStart;

                ByteBuffer eocd = ByteBuffer.allocate(22).order(ByteOrder.LITTLE_ENDIAN);
                eocd.putInt(0x06054b50);
                eocd.putShort((short) 0);
                eocd.putShort((short) 0);
                eocd.putShort((short) written.size());
                eocd.putShort((short) written.size());
                eocd.putInt((int) cdSize);
                eocd.putInt((int) cdStart);
                eocd.putShort((short) 0);
                o.write(eocd.array());
            } finally {
                o.flush();
                fos.close();
            }
            return info;
        } finally {
            raf.close();
        }
    }

    // ---- names ---------------------------------------------------------------------------

    /** Every entry name of the zip, read straight from its central directory (works even when ZipFile refuses the file). */
    static List<String> listNames(File apk) throws IOException {
        RandomAccessFile raf = new RandomAccessFile(apk, "r");
        try {
            List<Entry> es = readEntries(raf, true);
            List<String> out = new ArrayList<String>(es.size());
            for (int i = 0; i < es.size(); i++) out.add(es.get(i).name);
            return out;
        } finally {
            raf.close();
        }
    }

    // ---- normal mode ---------------------------------------------------------------------

    private static final long CHECK_LIMIT = 96L * 1024 * 1024;
    private static final int BAD_FLAGS = 0x0001 | 0x0040 | 0x2000; // encrypted, strong encryption, masked headers

    /** Copies one entry; when its header is wrong or carries a fake flag, the header is repaired and the data kept. */
    private static void writeChecked(RandomAccessFile raf, Counter o, Entry e, Info info) throws IOException {
        boolean flagged = (e.flags & BAD_FLAGS) != 0;
        boolean knownMethod = e.method == 0 || e.method == 8;
        if (!knownMethod || e.compSize > CHECK_LIMIT) {
            if (flagged || !knownMethod) info.unfixed++;
            writeRaw(raf, o, e);
            return;
        }
        byte[] raw = new byte[(int) e.compSize];
        raf.seek(e.dataOffset);
        raf.readFully(raw);
        byte[] plain = null;
        try {
            plain = e.method == 0 ? raw : inflate(raw, e.size);
        } catch (Exception x) {
            plain = null;
        }
        if (plain == null) { // really encrypted or cut off: leave it exactly as it was
            info.unfixed++;
            writeRaw(raf, o, e);
            return;
        }
        CRC32 c = new CRC32();
        c.update(plain, 0, plain.length);
        boolean wrongHeader = c.getValue() != e.crc || plain.length != e.size;
        if (!flagged && !wrongHeader) {
            int pad = padFor(o, e.nameBytes.length, e.method, e.name);
            writeLocal(o, e, pad);
            o.write(raw, 0, raw.length);
            return;
        }
        e.flags &= ~BAD_FLAGS;
        e.crc = c.getValue();
        e.size = plain.length;
        e.compSize = raw.length;
        int pad = padFor(o, e.nameBytes.length, e.method, e.name);
        writeLocal(o, e, pad);
        o.write(raw, 0, raw.length);
        info.fixed++;
    }

    /** Inflates raw deflate data; fails (exception) when the data is not valid deflate data. */
    private static byte[] inflate(byte[] raw, long hint) throws Exception {
        Inflater inf = new Inflater(true);
        try {
            inf.setInput(raw);
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(
                    (int) Math.max(64, Math.min(hint, CHECK_LIMIT)));
            byte[] buf = new byte[1 << 16];
            while (!inf.finished()) {
                int n = inf.inflate(buf);
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) throw new IOException("cut off");
                out.write(buf, 0, n);
                if (out.size() > CHECK_LIMIT) throw new IOException("too big to check");
            }
            return out.toByteArray();
        } finally {
            inf.end();
        }
    }

    // ---- reading -------------------------------------------------------------------------

    private static List<Entry> readEntries(RandomAccessFile raf) throws IOException {
        return readEntries(raf, false);
    }

    /**
     * lenient = true: a damaged or trick-filled zip is read as far as possible (entries whose headers are broken are
     * skipped, a central directory that is cut short ends the list) instead of giving up on the whole file.
     */
    private static List<Entry> readEntries(RandomAccessFile raf, boolean lenient) throws IOException {
        long len = raf.length();
        int scan = (int) Math.min(len, 65557);
        byte[] tail = new byte[scan];
        raf.seek(len - scan);
        raf.readFully(tail);
        int eocdPos = -1;
        for (int i = scan - 22; i >= 0; i--) {
            if (tail[i] == 0x50 && tail[i + 1] == 0x4b && tail[i + 2] == 0x05 && tail[i + 3] == 0x06) {
                eocdPos = i;
                break;
            }
        }
        if (eocdPos < 0) throw new IOException("Not a zip/APK file (no end record)");
        ByteBuffer t = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN);
        int count = t.getShort(eocdPos + 10) & 0xFFFF;
        long cdSize = t.getInt(eocdPos + 12) & 0xFFFFFFFFL;
        long cdOffset = t.getInt(eocdPos + 16) & 0xFFFFFFFFL;
        if (count == 0xFFFF || cdOffset == 0xFFFFFFFFL) throw new IOException("Zip64 APK is not supported");

        if (cdOffset > len) throw new IOException("Broken central directory");
        if (cdOffset + cdSize > len) {
            if (!lenient) throw new IOException("Broken central directory");
            cdSize = len - cdOffset;
        }
        byte[] cd = new byte[(int) cdSize];
        raf.seek(cdOffset);
        raf.readFully(cd);
        ByteBuffer c = ByteBuffer.wrap(cd).order(ByteOrder.LITTLE_ENDIAN);

        List<Entry> list = new ArrayList<Entry>();
        int p = 0;
        for (int i = 0; i < count; i++) {
            if (p + 46 > cd.length || c.getInt(p) != 0x02014b50) {
                if (lenient && !list.isEmpty()) break;
                throw new IOException("Broken central directory");
            }
            Entry e = new Entry();
            e.versionMadeBy = c.getShort(p + 4) & 0xFFFF;
            e.flags = c.getShort(p + 8) & 0xFFFF;
            e.method = c.getShort(p + 10) & 0xFFFF;
            e.time = c.getShort(p + 12) & 0xFFFF;
            e.date = c.getShort(p + 14) & 0xFFFF;
            e.crc = c.getInt(p + 16) & 0xFFFFFFFFL;
            e.compSize = c.getInt(p + 20) & 0xFFFFFFFFL;
            e.size = c.getInt(p + 24) & 0xFFFFFFFFL;
            int nameLen = c.getShort(p + 28) & 0xFFFF;
            int extraLen = c.getShort(p + 30) & 0xFFFF;
            int commentLen = c.getShort(p + 32) & 0xFFFF;
            if (p + 46 + nameLen + extraLen + commentLen > cd.length) {
                if (lenient && !list.isEmpty()) break;
                throw new IOException("Broken central directory");
            }
            e.intAttr = c.getShort(p + 36) & 0xFFFF;
            e.extAttr = c.getInt(p + 38) & 0xFFFFFFFFL;
            e.localOffset = c.getInt(p + 42) & 0xFFFFFFFFL;
            e.nameBytes = new byte[nameLen];
            System.arraycopy(cd, p + 46, e.nameBytes, 0, nameLen);
            e.name = new String(e.nameBytes, StandardCharsets.UTF_8);
            e.cdExtra = new byte[extraLen];
            System.arraycopy(cd, p + 46 + nameLen, e.cdExtra, 0, extraLen);
            e.comment = new byte[commentLen];
            System.arraycopy(cd, p + 46 + nameLen + extraLen, e.comment, 0, commentLen);
            p += 46 + nameLen + extraLen + commentLen;

            // data offset comes from the LOCAL header (its extra field can differ from the central one)
            byte[] lh = new byte[30];
            try {
                if (e.localOffset < 0 || e.localOffset + 30 > len) throw new IOException("local header outside the file");
                raf.seek(e.localOffset);
                raf.readFully(lh);
            } catch (IOException ioe) {
                if (lenient) continue; // this entry cannot be used; the others still can
                throw ioe;
            }
            ByteBuffer l = ByteBuffer.wrap(lh).order(ByteOrder.LITTLE_ENDIAN);
            if (l.getInt(0) != 0x04034b50) {
                if (lenient) continue;
                throw new IOException("Broken local header for " + e.name);
            }
            e.dataOffset = e.localOffset + 30 + (l.getShort(26) & 0xFFFF) + (l.getShort(28) & 0xFFFF);
            list.add(e);
        }
        return list;
    }

    private static boolean isSignatureFile(String name) {
        String n = name.toUpperCase(Locale.US);
        if (!n.startsWith("META-INF/")) return false;
        String rest = n.substring(9);
        if (rest.indexOf('/') >= 0) return false;
        return rest.equals("MANIFEST.MF") || rest.endsWith(".SF") || rest.endsWith(".RSA")
                || rest.endsWith(".DSA") || rest.endsWith(".EC");
    }

    // ---- writing -------------------------------------------------------------------------

    private static final class Counter extends OutputStream {
        private final OutputStream out;
        long count;

        Counter(OutputStream out) {
            this.out = out;
        }

        @Override
        public void write(int b) throws IOException {
            out.write(b);
            count++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            count += len;
        }

        @Override
        public void flush() throws IOException {
            out.flush();
        }
    }

    private static int padFor(Counter o, int nameLen, int method, String name) {
        if (method != 0) return 0;
        int align = name.endsWith(".so") ? 4096 : 4;
        long dataStart = o.count + 30 + nameLen;
        return (int) ((align - (dataStart % align)) % align);
    }

    private static void writeLocal(Counter o, Entry e, int pad) throws IOException {
        e.localOffset = o.count;
        ByteBuffer h = ByteBuffer.allocate(30).order(ByteOrder.LITTLE_ENDIAN);
        h.putInt(0x04034b50);
        h.putShort((short) 20);
        h.putShort((short) (e.flags & ~0x08)); // no data descriptor: sizes are known
        h.putShort((short) e.method);
        h.putShort((short) e.time);
        h.putShort((short) e.date);
        h.putInt((int) e.crc);
        h.putInt((int) e.compSize);
        h.putInt((int) e.size);
        h.putShort((short) e.nameBytes.length);
        h.putShort((short) pad);
        o.write(h.array());
        o.write(e.nameBytes);
        if (pad > 0) o.write(new byte[pad]);
    }

    private static void writeRaw(RandomAccessFile raf, Counter o, Entry e) throws IOException {
        int pad = padFor(o, e.nameBytes.length, e.method, e.name);
        writeLocal(o, e, pad);
        raf.seek(e.dataOffset);
        byte[] buf = new byte[1 << 16];
        long left = e.compSize;
        while (left > 0) {
            int n = raf.read(buf, 0, (int) Math.min(buf.length, left));
            if (n < 0) throw new IOException("Unexpected end of file while copying " + e.name);
            o.write(buf, 0, n);
            left -= n;
        }
    }

    private static Entry writeNew(Counter o, String name, byte[] data) throws IOException {
        Entry e = new Entry();
        e.name = name;
        e.nameBytes = name.getBytes(StandardCharsets.UTF_8);
        e.versionMadeBy = 20;
        e.flags = 0x0800; // UTF-8 names
        e.method = 8;
        e.time = DOS_TIME;
        e.date = DOS_DATE;
        CRC32 crc = new CRC32();
        crc.update(data, 0, data.length);
        e.crc = crc.getValue();
        e.size = data.length;

        if (name.startsWith("lib/") && name.endsWith(".so")) {
            // native libraries are stored (not compressed) and page aligned, so Android can load them straight from the APK
            e.method = 0;
            e.compSize = data.length;
            e.cdExtra = new byte[0];
            e.comment = new byte[0];
            writeLocal(o, e, padFor(o, e.nameBytes.length, 0, name));
            o.write(data, 0, data.length);
            return e;
        }

        Deflater d = new Deflater(Deflater.DEFAULT_COMPRESSION, true);
        d.setInput(data);
        d.finish();
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        while (!d.finished()) {
            int n = d.deflate(buf);
            bo.write(buf, 0, n);
        }
        d.end();
        byte[] comp = bo.toByteArray();
        e.compSize = comp.length;
        e.cdExtra = new byte[0];
        e.comment = new byte[0];
        writeLocal(o, e, 0);
        o.write(comp);
        return e;
    }

    private static void writeCentral(Counter o, Entry e) throws IOException {
        ByteBuffer h = ByteBuffer.allocate(46).order(ByteOrder.LITTLE_ENDIAN);
        h.putInt(0x02014b50);
        h.putShort((short) e.versionMadeBy);
        h.putShort((short) 20);
        h.putShort((short) (e.flags & ~0x08));
        h.putShort((short) e.method);
        h.putShort((short) e.time);
        h.putShort((short) e.date);
        h.putInt((int) e.crc);
        h.putInt((int) e.compSize);
        h.putInt((int) e.size);
        h.putShort((short) e.nameBytes.length);
        h.putShort((short) e.cdExtra.length);
        h.putShort((short) e.comment.length);
        h.putShort((short) 0);
        h.putShort((short) e.intAttr);
        h.putInt((int) e.extAttr);
        h.putInt((int) e.localOffset);
        o.write(h.array());
        o.write(e.nameBytes);
        o.write(e.cdExtra);
        o.write(e.comment);
    }
}
