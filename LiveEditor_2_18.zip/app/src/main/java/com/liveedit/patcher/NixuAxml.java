package com.liveedit.patcher;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Compiled (binary) XML <-> readable XML text. Used for AndroidManifest.xml and every res/*.xml file.
 *
 * The text is lossless: every attribute value that is not a plain string is written so that it is read back
 * as exactly the same type and number (true/false, 123, 0x7f, #ff00ff00, 16dp, @0x7f010002, f:1.5 ...).
 * A plain string that would look like one of those is written with a leading backslash.
 */
final class NixuAxml {

    static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";

    interface Ids {
        /** Resource id of the attribute, or 0 when unknown. */
        int attr(String uri, String name);
    }

    private NixuAxml() {}

    static boolean isBinary(byte[] d) {
        return d != null && d.length >= 16 && d[0] == 0x03 && d[1] == 0x00 && d[2] == 0x08 && d[3] == 0x00;
    }

    /** Attribute ids of the Android version this code runs on (android.R.attr.*); 0 outside Android. */
    static Ids androidIds() {
        return new Ids() {
            private Class<?> c;
            private boolean tried;

            @Override
            public int attr(String uri, String name) {
                if (!ANDROID_NS.equals(uri)) return 0;
                if (!tried) {
                    tried = true;
                    try {
                        c = Class.forName("android.R$attr");
                    } catch (Throwable t) {
                        c = null;
                    }
                }
                if (c == null) return 0;
                try {
                    return c.getField(name).getInt(null);
                } catch (Throwable t) {
                    return 0;
                }
            }
        };
    }

    // =======================================================================================
    // values
    // =======================================================================================

    static final class Val {
        final int type;
        final int data;

        Val(int type, int data) {
            this.type = type;
            this.data = data;
        }
    }

    private static final String[] DIM_UNITS = {"px", "dp", "sp", "pt", "in", "mm"};
    private static final float[] RADIX_MULTS = {0.00390625f, 3.0517578125E-5f, 1.1920929E-7f, 4.6566129E-10f};
    private static final Pattern P_INT = Pattern.compile("-?\\d{1,10}");
    private static final Pattern P_HEX = Pattern.compile("0x[0-9a-fA-F]{1,8}");
    private static final Pattern P_COLOR = Pattern.compile("#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})");
    private static final Pattern P_DIM = Pattern.compile("(-?\\d+(?:\\.\\d+)?)(px|dp|dip|sp|pt|in|mm)");
    private static final Pattern P_FRAC = Pattern.compile("(-?\\d+(?:\\.\\d+)?)(%p|%)");

    /** Typed value for the text, or null when the text is a plain string. */
    static Val parseValue(String t) throws IOException {
        if (t.length() == 0) return null;
        char c = t.charAt(0);
        if (t.startsWith("raw(") && t.endsWith(")")) {
            String[] p = t.substring(4, t.length() - 1).split(",");
            if (p.length != 2) throw new IOException("Bad value: " + t);
            return new Val(parseNum(p[0].trim()) & 0xFF, parseNum(p[1].trim()));
        }
        if (t.startsWith("f:")) {
            try {
                return new Val(0x04, Float.floatToRawIntBits(Float.parseFloat(t.substring(2))));
            } catch (NumberFormatException e) {
                throw new IOException("Bad number after f: in " + t);
            }
        }
        if (c == '@') {
            if (t.equals("@null")) return new Val(0x01, 0);
            if (t.equals("@empty")) return new Val(0x00, 1);
            if (t.startsWith("@0x")) {
                try {
                    return new Val(0x01, (int) Long.parseLong(t.substring(3), 16));
                } catch (NumberFormatException e) {
                    throw new IOException("Bad reference: " + t);
                }
            }
            throw new IOException("Reference \"" + t + "\" cannot be used here. Write it as @0x7f0b0001 (the id), "
                    + "or put a backslash first (\\" + t + ") if it is plain text.");
        }
        if (c == '?') {
            if (t.startsWith("?0x")) {
                try {
                    return new Val(0x02, (int) Long.parseLong(t.substring(3), 16));
                } catch (NumberFormatException e) {
                    throw new IOException("Bad attribute reference: " + t);
                }
            }
            throw new IOException("Theme reference \"" + t + "\" must be written as ?0x01010000 (the id), "
                    + "or with a backslash first if it is plain text.");
        }
        if (t.equals("true")) return new Val(0x12, -1);
        if (t.equals("false")) return new Val(0x12, 0);
        if (P_INT.matcher(t).matches()) {
            long v = Long.parseLong(t);
            if (v >= Integer.MIN_VALUE && v <= Integer.MAX_VALUE) return new Val(0x10, (int) v);
            return null;
        }
        if (P_HEX.matcher(t).matches()) return new Val(0x11, (int) Long.parseLong(t.substring(2), 16));
        Matcher m = P_COLOR.matcher(t);
        if (m.matches()) {
            String h = m.group(1);
            switch (h.length()) {
                case 8:
                    return new Val(0x1c, (int) Long.parseLong(h, 16));
                case 6:
                    return new Val(0x1d, 0xFF000000 | (int) Long.parseLong(h, 16));
                case 4: {
                    int a = Integer.parseInt(h.substring(0, 1), 16);
                    int r = Integer.parseInt(h.substring(1, 2), 16);
                    int g = Integer.parseInt(h.substring(2, 3), 16);
                    int b = Integer.parseInt(h.substring(3, 4), 16);
                    return new Val(0x1e, (a * 17) << 24 | (r * 17) << 16 | (g * 17) << 8 | (b * 17));
                }
                default: {
                    int r = Integer.parseInt(h.substring(0, 1), 16);
                    int g = Integer.parseInt(h.substring(1, 2), 16);
                    int b = Integer.parseInt(h.substring(2, 3), 16);
                    return new Val(0x1f, 0xFF000000 | (r * 17) << 16 | (g * 17) << 8 | (b * 17));
                }
            }
        }
        m = P_DIM.matcher(t);
        if (m.matches()) {
            int unit = unitIndex(m.group(2));
            return new Val(0x05, complex(Float.parseFloat(m.group(1)), unit));
        }
        m = P_FRAC.matcher(t);
        if (m.matches()) {
            int unit = m.group(2).equals("%") ? 0 : 1;
            return new Val(0x06, complex(Float.parseFloat(m.group(1)) / 100f, unit));
        }
        return null;
    }

    private static int parseNum(String s) throws IOException {
        try {
            if (s.startsWith("0x")) return (int) Long.parseLong(s.substring(2), 16);
            return (int) Long.parseLong(s);
        } catch (NumberFormatException e) {
            throw new IOException("Bad number: " + s);
        }
    }

    private static int unitIndex(String u) {
        if (u.equals("dip")) return 1;
        for (int i = 0; i < DIM_UNITS.length; i++) {
            if (DIM_UNITS[i].equals(u)) return i;
        }
        return 0;
    }

    static int complex(float value, int unit) throws IOException {
        boolean neg = value < 0;
        if (neg) value = -value;
        long bits = (long) (value * (1 << 23) + 0.5f);
        int radix;
        int shift;
        if ((bits & 0x7FFFFFL) == 0) {
            radix = 0;
            shift = 23;
        } else if ((bits & 0xFFFFFFFFFF800000L) == 0) {
            radix = 3;
            shift = 0;
        } else if ((bits & 0xFFFFFFFF80000000L) == 0) {
            radix = 2;
            shift = 8;
        } else if ((bits & 0xFFFFFF8000000000L) == 0) {
            radix = 1;
            shift = 16;
        } else {
            throw new IOException("Number is too big");
        }
        int mantissa = (int) ((bits >> shift) & 0xFFFFFF);
        if (neg) mantissa = (-mantissa) & 0xFFFFFF;
        return (radix << 4) | (mantissa << 8) | (unit & 0xF);
    }

    static float complexToFloat(int data) {
        return (data & 0xFFFFFF00) * RADIX_MULTS[(data >> 4) & 3];
    }

    private static String num(float v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e9) return Long.toString((long) v);
        String s = Float.toString(v);
        if (s.indexOf('E') >= 0) {
            s = new java.math.BigDecimal(s).toPlainString();
        }
        return s;
    }

    static String rawText(int type, int data) {
        return String.format("raw(0x%02x,0x%08x)", type & 0xFF, data);
    }

    /** Readable text for one typed value; always reads back as the same type and number. */
    static String valueText(NixuPool pool, int type, int data) {
        if (type == 0x03) {
            String s = pool != null && data >= 0 && data < pool.strings.size() ? pool.strings.get(data) : "";
            return escapeString(s);
        }
        String t;
        switch (type) {
            case 0x01:
                t = data == 0 ? "@null" : String.format("@0x%08x", data);
                break;
            case 0x02:
                t = String.format("?0x%08x", data);
                break;
            case 0x04:
                t = "f:" + Float.intBitsToFloat(data);
                break;
            case 0x05: {
                int u = data & 0xF;
                t = u < DIM_UNITS.length ? num(complexToFloat(data)) + DIM_UNITS[u] : null;
                break;
            }
            case 0x06: {
                int u = data & 0xF;
                t = u < 2 ? num(complexToFloat(data) * 100f) + (u == 0 ? "%" : "%p") : null;
                break;
            }
            case 0x10:
                t = Integer.toString(data);
                break;
            case 0x11:
                t = "0x" + Integer.toHexString(data);
                break;
            case 0x12:
                t = data == 0 ? "false" : (data == -1 ? "true" : null);
                break;
            case 0x1c:
                t = String.format("#%08x", data);
                break;
            case 0x1d:
                t = (data & 0xFF000000) == 0xFF000000 ? String.format("#%06x", data & 0xFFFFFF) : null;
                break;
            case 0x1e: {
                int a = (data >>> 28) & 0xF, r = (data >>> 20) & 0xF, g = (data >>> 12) & 0xF, b = (data >>> 4) & 0xF;
                t = String.format("#%x%x%x%x", a, r, g, b);
                break;
            }
            case 0x1f: {
                int r = (data >>> 20) & 0xF, g = (data >>> 12) & 0xF, b = (data >>> 4) & 0xF;
                t = String.format("#%x%x%x", r, g, b);
                break;
            }
            default:
                t = null;
        }
        if (t == null) return rawText(type, data);
        try {
            Val v = parseValue(t);
            if (v == null || v.type != type || v.data != data) return rawText(type, data);
        } catch (IOException e) {
            return rawText(type, data);
        }
        return t;
    }

    static String escapeString(String s) {
        try {
            if (s.startsWith("\\") || parseValue(s) != null) return "\\" + s;
        } catch (IOException e) {
            return "\\" + s;
        }
        return s;
    }

    // =======================================================================================
    // binary -> text
    // =======================================================================================

    private static final class Ev {
        int type;
        int line;
        int ns = -1;
        int name = -1;
        int prefix = -1;
        int uri = -1;
        int text = -1;
        int[] attr = new int[0]; // ns, name, raw, type, data ...
    }

    private static final class Doc {
        NixuPool pool;
        int[] resIds = new int[0];
        final List<Ev> events = new ArrayList<Ev>();
    }

    private static Doc parse(byte[] d) throws IOException {
        if (!isBinary(d)) throw new IOException("This is not a compiled (binary) XML file");
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        int end = Math.min(d.length, b.getInt(4));
        int pos = b.getShort(2) & 0xFFFF;
        Doc doc = new Doc();
        while (pos + 8 <= end) {
            int type = b.getShort(pos) & 0xFFFF;
            int size = b.getInt(pos + 4);
            if (size < 8 || pos + size > d.length) throw new IOException("Broken XML chunk at " + pos);
            if (type == 0x0001) {
                doc.pool = NixuPool.parse(d, pos);
            } else if (type == 0x0180) {
                int n = (size - 8) / 4;
                doc.resIds = new int[n];
                for (int i = 0; i < n; i++) doc.resIds[i] = b.getInt(pos + 8 + 4 * i);
            } else if (type >= 0x0100 && type <= 0x0104 && size >= 24) {
                Ev e = new Ev();
                e.type = type;
                e.line = b.getInt(pos + 8);
                if (type == 0x0100 || type == 0x0101) {
                    e.prefix = b.getInt(pos + 16);
                    e.uri = b.getInt(pos + 20);
                } else if (type == 0x0102) {
                    e.ns = b.getInt(pos + 16);
                    e.name = b.getInt(pos + 20);
                    int attrStart = b.getShort(pos + 24) & 0xFFFF;
                    int attrSize = b.getShort(pos + 26) & 0xFFFF;
                    int count = b.getShort(pos + 28) & 0xFFFF;
                    if (attrSize < 20) throw new IOException("Unexpected attribute size " + attrSize);
                    e.attr = new int[count * 5];
                    for (int a = 0; a < count; a++) {
                        int base = pos + 16 + attrStart + a * attrSize;
                        if (base + 20 > pos + size) throw new IOException("Attribute runs past its element");
                        e.attr[a * 5] = b.getInt(base);
                        e.attr[a * 5 + 1] = b.getInt(base + 4);
                        e.attr[a * 5 + 2] = b.getInt(base + 8);
                        e.attr[a * 5 + 3] = d[base + 15] & 0xFF;
                        e.attr[a * 5 + 4] = b.getInt(base + 16);
                    }
                } else if (type == 0x0103) {
                    e.ns = b.getInt(pos + 16);
                    e.name = b.getInt(pos + 20);
                } else {
                    e.text = b.getInt(pos + 16);
                }
                doc.events.add(e);
            }
            pos += size;
        }
        if (doc.pool == null) throw new IOException("This XML has no string pool");
        return doc;
    }

    private static String str(Doc doc, int i) {
        return i >= 0 && i < doc.pool.strings.size() ? doc.pool.strings.get(i) : "";
    }

    static String toXml(byte[] bin) throws IOException {
        Doc doc = parse(bin);
        StringBuilder sb = new StringBuilder(bin.length * 3);
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        Map<String, String> prefixOf = new HashMap<String, String>();
        List<String[]> pending = new ArrayList<String[]>();
        int depth = 0;
        for (int i = 0; i < doc.events.size(); i++) {
            Ev e = doc.events.get(i);
            if (e.type == 0x0100) {
                String prefix = str(doc, e.prefix);
                String uri = str(doc, e.uri);
                prefixOf.put(uri, prefix);
                pending.add(new String[]{prefix, uri});
            } else if (e.type == 0x0102) {
                indent(sb, depth);
                sb.append('<').append(qname(doc, prefixOf, e.ns, e.name));
                int count = e.attr.length / 5;
                boolean multi = pending.size() + count > 1;
                for (String[] ns : pending) {
                    sb.append(multi ? "\n" : " ");
                    if (multi) indent(sb, depth + 2);
                    sb.append(ns[0].length() == 0 ? "xmlns" : "xmlns:" + ns[0]).append("=\"").append(escAttr(ns[1])).append('"');
                }
                pending.clear();
                for (int a = 0; a < count; a++) {
                    sb.append(multi ? "\n" : " ");
                    if (multi) indent(sb, depth + 2);
                    int ans = e.attr[a * 5];
                    int an = e.attr[a * 5 + 1];
                    int type = e.attr[a * 5 + 3];
                    int data = e.attr[a * 5 + 4];
                    int raw = e.attr[a * 5 + 2];
                    if (type == 0x03 && (data < 0 || data >= doc.pool.strings.size())) data = raw;
                    sb.append(qname(doc, prefixOf, ans, an)).append("=\"")
                            .append(escAttr(valueText(doc.pool, type, data))).append('"');
                }
                Ev nx = i + 1 < doc.events.size() ? doc.events.get(i + 1) : null;
                if (nx != null && nx.type == 0x0103) {
                    sb.append("/>\n");
                    i++;
                } else {
                    sb.append(">\n");
                    depth++;
                }
            } else if (e.type == 0x0103) {
                depth = Math.max(0, depth - 1);
                indent(sb, depth);
                sb.append("</").append(qname(doc, prefixOf, e.ns, e.name)).append(">\n");
            } else if (e.type == 0x0104) {
                indent(sb, depth);
                sb.append(escText(str(doc, e.text))).append('\n');
            }
        }
        return sb.toString();
    }

    private static String qname(Doc doc, Map<String, String> prefixOf, int ns, int name) {
        String n = str(doc, name);
        if (ns < 0) return n;
        String p = prefixOf.get(str(doc, ns));
        return p == null || p.length() == 0 ? n : p + ":" + n;
    }

    private static void indent(StringBuilder sb, int depth) {
        for (int i = 0; i < depth; i++) sb.append("    ");
    }

    private static String escAttr(String s) {
        StringBuilder b = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&':
                    b.append("&amp;");
                    break;
                case '<':
                    b.append("&lt;");
                    break;
                case '"':
                    b.append("&quot;");
                    break;
                case '\n':
                    b.append("&#10;");
                    break;
                case '\r':
                    b.append("&#13;");
                    break;
                case '\t':
                    b.append("&#9;");
                    break;
                default:
                    b.append(c);
            }
        }
        return b.toString();
    }

    private static String escText(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    // =======================================================================================
    // text -> binary
    // =======================================================================================

    private static final class X {
        int kind; // 0 start, 1 end, 2 text
        String name;
        String text;
        int line;
        List<String[]> attrs = new ArrayList<String[]>();
    }

    private static int lineOf(int[] nl, int pos) {
        int lo = 0;
        int hi = nl.length;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (nl[mid] < pos) lo = mid + 1;
            else hi = mid;
        }
        return lo + 1;
    }

    private static List<X> tokenize(String s) throws IOException {
        int cnt = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') cnt++;
        int[] nl = new int[cnt];
        int k = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') nl[k++] = i;

        List<X> out = new ArrayList<X>();
        int i = 0;
        int n = s.length();
        while (i < n) {
            char c = s.charAt(i);
            if (c != '<') {
                int j = s.indexOf('<', i);
                if (j < 0) j = n;
                String t = decode(s.substring(i, j), lineOf(nl, i));
                if (t.trim().length() > 0) {
                    X x = new X();
                    x.kind = 2;
                    x.text = t.trim();
                    x.line = lineOf(nl, i);
                    out.add(x);
                }
                i = j;
                continue;
            }
            if (s.startsWith("<!--", i)) {
                int e = s.indexOf("-->", i + 4);
                if (e < 0) throw new IOException("Line " + lineOf(nl, i) + ": comment is not closed");
                i = e + 3;
            } else if (s.startsWith("<![CDATA[", i)) {
                int e = s.indexOf("]]>", i + 9);
                if (e < 0) throw new IOException("Line " + lineOf(nl, i) + ": CDATA is not closed");
                X x = new X();
                x.kind = 2;
                x.text = s.substring(i + 9, e);
                x.line = lineOf(nl, i);
                if (x.text.trim().length() > 0) out.add(x);
                i = e + 3;
            } else if (s.startsWith("<?", i)) {
                int e = s.indexOf("?>", i + 2);
                if (e < 0) throw new IOException("Line " + lineOf(nl, i) + ": <? is not closed");
                i = e + 2;
            } else if (s.startsWith("<!", i)) {
                int e = s.indexOf('>', i + 2);
                if (e < 0) throw new IOException("Line " + lineOf(nl, i) + ": <! is not closed");
                i = e + 1;
            } else if (s.startsWith("</", i)) {
                int e = s.indexOf('>', i + 2);
                if (e < 0) throw new IOException("Line " + lineOf(nl, i) + ": </ is not closed");
                X x = new X();
                x.kind = 1;
                x.name = s.substring(i + 2, e).trim();
                x.line = lineOf(nl, i);
                out.add(x);
                i = e + 1;
            } else {
                int line = lineOf(nl, i);
                int j = i + 1;
                while (j < n && !Character.isWhitespace(s.charAt(j)) && s.charAt(j) != '/' && s.charAt(j) != '>') j++;
                X x = new X();
                x.kind = 0;
                x.name = s.substring(i + 1, j);
                x.line = line;
                if (x.name.length() == 0) throw new IOException("Line " + line + ": missing tag name after <");
                boolean selfClose = false;
                while (true) {
                    while (j < n && Character.isWhitespace(s.charAt(j))) j++;
                    if (j >= n) throw new IOException("Line " + line + ": tag <" + x.name + "> is not closed");
                    char ch = s.charAt(j);
                    if (ch == '>') {
                        j++;
                        break;
                    }
                    if (ch == '/') {
                        if (j + 1 < n && s.charAt(j + 1) == '>') {
                            selfClose = true;
                            j += 2;
                            break;
                        }
                        throw new IOException("Line " + lineOf(nl, j) + ": stray / inside tag <" + x.name + ">");
                    }
                    int a = j;
                    while (j < n && s.charAt(j) != '=' && !Character.isWhitespace(s.charAt(j))
                            && s.charAt(j) != '>' && s.charAt(j) != '/') j++;
                    String an = s.substring(a, j);
                    while (j < n && Character.isWhitespace(s.charAt(j))) j++;
                    if (j >= n || s.charAt(j) != '=') {
                        throw new IOException("Line " + lineOf(nl, a) + ": attribute " + an + " has no = sign");
                    }
                    j++;
                    while (j < n && Character.isWhitespace(s.charAt(j))) j++;
                    if (j >= n || (s.charAt(j) != '"' && s.charAt(j) != '\'')) {
                        throw new IOException("Line " + lineOf(nl, a) + ": value of " + an + " must be in quotes");
                    }
                    char q = s.charAt(j);
                    int e = s.indexOf(q, j + 1);
                    if (e < 0) throw new IOException("Line " + lineOf(nl, a) + ": quote is not closed for " + an);
                    x.attrs.add(new String[]{an, decode(s.substring(j + 1, e), lineOf(nl, a))});
                    j = e + 1;
                }
                out.add(x);
                if (selfClose) {
                    X en = new X();
                    en.kind = 1;
                    en.name = x.name;
                    en.line = line;
                    out.add(en);
                }
                i = j;
            }
        }
        return out;
    }

    private static String decode(String s, int line) throws IOException {
        if (s.indexOf('&') < 0) return s;
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '&') {
                b.append(c);
                continue;
            }
            int e = s.indexOf(';', i);
            if (e < 0) throw new IOException("Line " + line + ": & without ; (write &amp; for a plain &)");
            String ent = s.substring(i + 1, e);
            if (ent.equals("amp")) b.append('&');
            else if (ent.equals("lt")) b.append('<');
            else if (ent.equals("gt")) b.append('>');
            else if (ent.equals("quot")) b.append('"');
            else if (ent.equals("apos")) b.append('\'');
            else if (ent.startsWith("#x") || ent.startsWith("#X")) {
                try {
                    b.appendCodePoint(Integer.parseInt(ent.substring(2), 16));
                } catch (RuntimeException ex) {
                    throw new IOException("Line " + line + ": bad entity &" + ent + ";");
                }
            } else if (ent.startsWith("#")) {
                try {
                    b.appendCodePoint(Integer.parseInt(ent.substring(1)));
                } catch (RuntimeException ex) {
                    throw new IOException("Line " + line + ": bad entity &" + ent + ";");
                }
            } else {
                throw new IOException("Line " + line + ": unknown entity &" + ent + ";");
            }
            i = e;
        }
        return b.toString();
    }

    private static final class Attr {
        String uri;
        String local;
        String value;
        int resId;
        int order;
    }

    private static final class El {
        String uri;
        String local;
        int line;
        final List<String[]> decls = new ArrayList<String[]>();
        final List<Attr> attrs = new ArrayList<Attr>();
    }

    private static final class Item {
        int kind; // 0 start, 1 end, 2 text
        El el;
        String text;
        int line;
    }

    /**
     * @param original the file being edited (its attribute ids are reused), or null
     * @param ids      extra source of attribute ids (for attributes that were not in the original), or null
     */
    static byte[] fromXml(String xml, byte[] original, Ids ids) throws IOException {
        // ids known from the original file: "uri|name" -> id
        Map<String, Integer> known = new HashMap<String, Integer>();
        boolean utf8 = true;
        if (original != null && isBinary(original)) {
            try {
                Doc od = parse(original);
                utf8 = od.pool.utf8;
                for (Ev e : od.events) {
                    if (e.type != 0x0102) continue;
                    for (int a = 0; a < e.attr.length / 5; a++) {
                        int nsIdx = e.attr[a * 5];
                        int nm = e.attr[a * 5 + 1];
                        if (nsIdx >= 0 && nm >= 0 && nm < od.resIds.length && od.resIds[nm] != 0) {
                            known.put(str(od, nsIdx) + "|" + str(od, nm), Integer.valueOf(od.resIds[nm]));
                        }
                    }
                }
            } catch (IOException e) {
                // original unreadable: carry on without its ids
            }
        }

        List<X> toks = tokenize(xml);
        List<Item> items = new ArrayList<Item>();
        List<Map<String, String>> scopes = new ArrayList<Map<String, String>>();
        List<El> open = new ArrayList<El>();
        TreeMap<Integer, String> idName = new TreeMap<Integer, String>();
        boolean rootSeen = false;
        boolean rootClosed = false;
        for (X x : toks) {
            if (x.kind == 0) {
                if (rootClosed) throw new IOException("Line " + x.line + ": only one root element is allowed");
                rootSeen = true;
                El el = new El();
                el.line = x.line;
                Map<String, String> scope = new HashMap<String, String>();
                List<String[]> plain = new ArrayList<String[]>();
                for (String[] a : x.attrs) {
                    if (a[0].equals("xmlns")) {
                        scope.put("", a[1]);
                        el.decls.add(new String[]{"", a[1]});
                    } else if (a[0].startsWith("xmlns:")) {
                        scope.put(a[0].substring(6), a[1]);
                        el.decls.add(new String[]{a[0].substring(6), a[1]});
                    } else {
                        plain.add(a);
                    }
                }
                scopes.add(scope);
                String[] qn = split(x.name);
                el.uri = qn[0] == null ? lookup(scopes, "") : lookup(scopes, qn[0]);
                if (qn[0] != null && el.uri == null) {
                    throw new IOException("Line " + x.line + ": prefix \"" + qn[0] + "\" is not declared");
                }
                el.local = qn[1];
                int order = 0;
                for (String[] a : plain) {
                    Attr at = new Attr();
                    String[] an = split(a[0]);
                    at.local = an[1];
                    at.uri = an[0] == null ? null : lookup(scopes, an[0]);
                    if (an[0] != null && at.uri == null) {
                        throw new IOException("Line " + x.line + ": prefix \"" + an[0] + "\" is not declared");
                    }
                    at.value = a[1];
                    at.order = order++;
                    if (at.uri != null) {
                        Integer id = known.get(at.uri + "|" + at.local);
                        int r = id != null ? id.intValue() : (ids != null ? ids.attr(at.uri, at.local) : 0);
                        at.resId = r;
                        if (r != 0) {
                            String prev = idName.get(Integer.valueOf(r));
                            if (prev != null && !prev.equals(at.local)) {
                                throw new IOException("Line " + x.line + ": attribute " + at.local
                                        + " and " + prev + " share one id");
                            }
                            idName.put(Integer.valueOf(r), at.local);
                        }
                    }
                    el.attrs.add(at);
                }
                sortAttrs(el.attrs);
                open.add(el);
                Item it = new Item();
                it.kind = 0;
                it.el = el;
                it.line = x.line;
                items.add(it);
            } else if (x.kind == 1) {
                if (open.isEmpty()) throw new IOException("Line " + x.line + ": </" + x.name + "> has no opening tag");
                El el = open.remove(open.size() - 1);
                scopes.remove(scopes.size() - 1);
                String[] qn = split(x.name);
                if (!qn[1].equals(el.local)) {
                    throw new IOException("Line " + x.line + ": </" + x.name + "> does not match <" + el.local + ">");
                }
                Item it = new Item();
                it.kind = 1;
                it.el = el;
                it.line = x.line;
                items.add(it);
                if (open.isEmpty()) rootClosed = true;
            } else {
                if (open.isEmpty()) continue;
                Item it = new Item();
                it.kind = 2;
                it.text = x.text;
                it.line = x.line;
                items.add(it);
            }
        }
        if (!rootSeen) throw new IOException("There is no root element");
        if (!open.isEmpty()) throw new IOException("<" + open.get(open.size() - 1).local + "> is never closed");

        // string pool: attribute names that carry ids first (in id order), then everything else
        List<String> poolStrings = new ArrayList<String>();
        Map<Integer, Integer> idIndex = new HashMap<Integer, Integer>();
        int[] resIds = new int[idName.size()];
        int p = 0;
        for (Map.Entry<Integer, String> e : idName.entrySet()) {
            idIndex.put(e.getKey(), Integer.valueOf(p));
            poolStrings.add(e.getValue());
            resIds[p++] = e.getKey().intValue();
        }
        final int base = poolStrings.size();
        Map<String, Integer> general = new LinkedHashMap<String, Integer>();

        Le body = new Le();
        List<El> stack = new ArrayList<El>();
        for (Item it : items) {
            if (it.kind == 0) {
                El el = it.el;
                for (String[] d : el.decls) {
                    body.i(0x0100 | (16 << 16));
                    body.i(24);
                    body.i(it.line);
                    body.i(-1);
                    body.i(gi(general, base, d[0]));
                    body.i(gi(general, base, d[1]));
                }
                int count = el.attrs.size();
                int idIdx = 0;
                int classIdx = 0;
                int styleIdx = 0;
                for (int a = 0; a < count; a++) {
                    Attr at = el.attrs.get(a);
                    if (at.uri == null) {
                        if (at.local.equals("id")) idIdx = a + 1;
                        else if (at.local.equals("class")) classIdx = a + 1;
                        else if (at.local.equals("style")) styleIdx = a + 1;
                    }
                }
                int size = 36 + 20 * count;
                body.i(0x0102 | (16 << 16));
                body.i(size);
                body.i(it.line);
                body.i(-1);
                body.i(el.uri == null ? -1 : gi(general, base, el.uri));
                body.i(gi(general, base, el.local));
                body.s(20);
                body.s(20);
                body.s(count);
                body.s(idIdx);
                body.s(classIdx);
                body.s(styleIdx);
                for (Attr at : el.attrs) {
                    int nsIdx = at.uri == null ? -1 : gi(general, base, at.uri);
                    int nameIdx = at.resId != 0 ? idIndex.get(Integer.valueOf(at.resId)).intValue()
                            : gi(general, base, at.local);
                    String v = at.value;
                    Val val = null;
                    String str = null;
                    if (v.startsWith("\\")) {
                        str = v.substring(1);
                    } else {
                        try {
                            val = parseValue(v);
                        } catch (IOException e) {
                            throw new IOException("Line " + it.line + ": " + e.getMessage());
                        }
                        if (val == null) str = v;
                    }
                    body.i(nsIdx);
                    body.i(nameIdx);
                    if (str != null) {
                        int si = gi(general, base, str);
                        body.i(si);
                        body.s(8);
                        body.b(0);
                        body.b(0x03);
                        body.i(si);
                    } else {
                        body.i(-1);
                        body.s(8);
                        body.b(0);
                        body.b(val.type);
                        body.i(val.data);
                    }
                }
                stack.add(el);
            } else if (it.kind == 1) {
                El el = it.el;
                body.i(0x0103 | (16 << 16));
                body.i(24);
                body.i(it.line);
                body.i(-1);
                body.i(el.uri == null ? -1 : gi(general, base, el.uri));
                body.i(gi(general, base, el.local));
                for (int d = el.decls.size() - 1; d >= 0; d--) {
                    String[] dc = el.decls.get(d);
                    body.i(0x0101 | (16 << 16));
                    body.i(24);
                    body.i(it.line);
                    body.i(-1);
                    body.i(gi(general, base, dc[0]));
                    body.i(gi(general, base, dc[1]));
                }
                stack.remove(stack.size() - 1);
            } else {
                body.i(0x0104 | (16 << 16));
                body.i(28);
                body.i(it.line);
                body.i(-1);
                body.i(gi(general, base, it.text));
                body.s(8);
                body.b(0);
                body.b(0);
                body.i(0);
            }
        }
        poolStrings.addAll(general.keySet());

        NixuPool pool = new NixuPool();
        pool.utf8 = utf8;
        pool.strings.addAll(poolStrings);
        byte[] poolBytes = pool.build();
        byte[] chunks = body.toBytes();
        int resChunk = resIds.length > 0 ? 8 + 4 * resIds.length : 0;
        int total = 8 + poolBytes.length + resChunk + chunks.length;
        ByteBuffer out = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
        out.putShort((short) 0x0003);
        out.putShort((short) 8);
        out.putInt(total);
        out.put(poolBytes);
        if (resIds.length > 0) {
            out.putShort((short) 0x0180);
            out.putShort((short) 8);
            out.putInt(resChunk);
            for (int id : resIds) out.putInt(id);
        }
        out.put(chunks);
        return out.array();
    }

    private static void sortAttrs(List<Attr> attrs) {
        stableSort(attrs, new Comparator<Attr>() {
            @Override
            public int compare(Attr a, Attr b) {
                if (a.resId != b.resId) return a.resId < b.resId ? -1 : 1;
                return a.order - b.order;
            }
        });
    }

    private static void stableSort(List<Attr> l, Comparator<Attr> c) {
        Attr[] arr = l.toArray(new Attr[0]);
        Arrays.sort(arr, c);
        l.clear();
        l.addAll(Arrays.asList(arr));
    }

    private static String[] split(String q) {
        int c = q.indexOf(':');
        if (c < 0) return new String[]{null, q};
        return new String[]{q.substring(0, c), q.substring(c + 1)};
    }

    private static String lookup(List<Map<String, String>> scopes, String prefix) {
        for (int i = scopes.size() - 1; i >= 0; i--) {
            String u = scopes.get(i).get(prefix);
            if (u != null) return u;
        }
        if (prefix.equals("xml")) return "http://www.w3.org/XML/1998/namespace";
        return null;
    }

    private static int gi(Map<String, Integer> general, int base, String s) {
        Integer i = general.get(s);
        if (i == null) {
            i = Integer.valueOf(base + general.size());
            general.put(s, i);
        }
        return i.intValue();
    }

    /** Little-endian byte builder. */
    private static final class Le {
        private final ByteArrayOutputStream o = new ByteArrayOutputStream();

        void i(int v) {
            o.write(v & 0xFF);
            o.write((v >> 8) & 0xFF);
            o.write((v >> 16) & 0xFF);
            o.write((v >>> 24) & 0xFF);
        }

        void s(int v) {
            o.write(v & 0xFF);
            o.write((v >> 8) & 0xFF);
        }

        void b(int v) {
            o.write(v & 0xFF);
        }

        byte[] toBytes() {
            return o.toByteArray();
        }
    }
}
