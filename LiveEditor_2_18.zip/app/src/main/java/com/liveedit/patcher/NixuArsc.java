package com.liveedit.patcher;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * resources.arsc: reads every package, type, entry and configuration, and edits values.
 * Values are patched in place (same size). Strings go through the global string pool, which is rebuilt
 * (everything after it only moves, nothing inside the packages refers to absolute positions).
 */
final class NixuArsc {

    static final class Pkg {
        int id;
        String name;
        int pos;
        int size;
        NixuPool typeNames;
        NixuPool keyNames;
    }

    /** One resource entry in one configuration (for example string/app_name in values-hi). */
    static final class Res {
        Pkg pkg;
        int typeId;
        String typeName;
        int entryIdx;
        int resId;
        String name;
        String config;
        boolean complex;
        boolean compact;
        int flags;
        int parent;
        int entryPos;
        // simple value
        int valueType;
        int valueData;
        int valuePos = -1;
        // complex (style, array, plurals, attr ...): one row per map item
        int[] mapName = new int[0];
        int[] mapType = new int[0];
        int[] mapData = new int[0];
        int[] mapPos = new int[0];

        String id() {
            return String.format(Locale.US, "0x%08x", resId);
        }

        String path() {
            return typeName + "/" + name;
        }
    }

    byte[] data;
    NixuPool global;
    int globalPos = -1;
    final List<Pkg> pkgs = new ArrayList<Pkg>();
    final List<Res> entries = new ArrayList<Res>();

    private NixuArsc() {}

    static NixuArsc parse(byte[] d) throws IOException {
        NixuArsc a = new NixuArsc();
        a.data = d;
        a.reparse();
        return a;
    }

    private void reparse() throws IOException {
        pkgs.clear();
        entries.clear();
        global = null;
        globalPos = -1;
        byte[] d = data;
        if (d.length < 12) throw new IOException("resources.arsc is too small");
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        if ((b.getShort(0) & 0xFFFF) != 0x0002) throw new IOException("resources.arsc: not a resource table");
        int hdr = b.getShort(2) & 0xFFFF;
        int end = Math.min(d.length, b.getInt(4));
        int pos = hdr;
        while (pos + 8 <= end) {
            int type = b.getShort(pos) & 0xFFFF;
            int size = b.getInt(pos + 4);
            if (size < 8 || pos + size > d.length) break;
            if (type == 0x0001 && global == null) {
                global = NixuPool.parse(d, pos);
                globalPos = pos;
            } else if (type == 0x0200) {
                parsePackage(b, pos, size);
            }
            pos += size;
        }
        if (global == null) throw new IOException("resources.arsc has no string pool");
    }

    private void parsePackage(ByteBuffer b, int pos, int size) throws IOException {
        byte[] d = data;
        Pkg p = new Pkg();
        p.pos = pos;
        p.size = size;
        int hdr = b.getShort(pos + 2) & 0xFFFF;
        p.id = b.getInt(pos + 8);
        StringBuilder nm = new StringBuilder();
        for (int i = 0; i < 128; i++) {
            char c = (char) (b.getShort(pos + 12 + i * 2) & 0xFFFF);
            if (c == 0) break;
            nm.append(c);
        }
        p.name = nm.toString();
        int typeOff = b.getInt(pos + 268);
        int keyOff = b.getInt(pos + 276);
        p.typeNames = NixuPool.parse(d, pos + typeOff);
        p.keyNames = NixuPool.parse(d, pos + keyOff);
        pkgs.add(p);
        int q = pos + hdr;
        int pend = pos + size;
        while (q + 8 <= pend) {
            int ct = b.getShort(q) & 0xFFFF;
            int cs = b.getInt(q + 4);
            if (cs < 8 || q + cs > d.length) break;
            if (ct == 0x0201) parseType(b, p, q, cs);
            q += cs;
        }
    }

    private void parseType(ByteBuffer b, Pkg p, int q, int cs) {
        byte[] d = data;
        int hdr = b.getShort(q + 2) & 0xFFFF;
        int tid = d[q + 8] & 0xFF;
        int tflags = d[q + 9] & 0xFF;
        int count = b.getInt(q + 12);
        int entriesStart = b.getInt(q + 16);
        if (count < 0 || count > 0x100000 || q + hdr > d.length) return;
        String typeName = tid - 1 >= 0 && tid - 1 < p.typeNames.strings.size() ? p.typeNames.strings.get(tid - 1) : "type" + tid;
        String cfg = describeConfig(d, q + 20);
        int tableAt = q + hdr;
        boolean sparse = (tflags & 0x01) != 0;
        boolean off16 = (tflags & 0x02) != 0;
        for (int i = 0; i < count; i++) {
            int idx;
            long off;
            if (sparse) {
                int at = tableAt + i * 4;
                if (at + 4 > q + cs) break;
                idx = b.getShort(at) & 0xFFFF;
                off = (b.getShort(at + 2) & 0xFFFFL) * 4;
            } else if (off16) {
                int at = tableAt + i * 2;
                if (at + 2 > q + cs) break;
                int v = b.getShort(at) & 0xFFFF;
                if (v == 0xFFFF) continue;
                idx = i;
                off = v * 4L;
            } else {
                int at = tableAt + i * 4;
                if (at + 4 > q + cs) break;
                long v = b.getInt(at) & 0xFFFFFFFFL;
                if (v == 0xFFFFFFFFL) continue;
                idx = i;
                off = v;
            }
            long ep = (long) q + (entriesStart & 0xFFFFFFFFL) + off;
            if (ep + 8 > q + cs) continue;
            readEntry(b, p, tid, typeName, cfg, idx, (int) ep, q + cs);
        }
    }

    private void readEntry(ByteBuffer b, Pkg p, int tid, String typeName, String cfg, int idx, int ep, int limit) {
        byte[] d = data;
        Res r = new Res();
        r.pkg = p;
        r.typeId = tid;
        r.typeName = typeName;
        r.entryIdx = idx;
        r.resId = (p.id << 24) | (tid << 16) | idx;
        r.config = cfg;
        r.entryPos = ep;
        int esize = b.getShort(ep) & 0xFFFF;
        int eflags = b.getShort(ep + 2) & 0xFFFF;
        r.flags = eflags;
        if ((eflags & 0x8) != 0) { // compact entry: key is 16 bit, the value type sits in the flag bits
            r.compact = true;
            int key = esize;
            r.name = keyName(p, key);
            r.valueType = (eflags >> 8) & 0xFF;
            r.valueData = b.getInt(ep + 4);
            r.valuePos = -1;
            entries.add(r);
            return;
        }
        int key = b.getInt(ep + 4);
        r.name = keyName(p, key);
        r.complex = (eflags & 0x1) != 0;
        if (!r.complex) {
            int vp = ep + esize;
            if (vp + 8 > limit) return;
            r.valuePos = vp;
            r.valueType = d[vp + 3] & 0xFF;
            r.valueData = b.getInt(vp + 4);
        } else {
            if (ep + 16 > limit) return;
            r.parent = b.getInt(ep + 8);
            int n = b.getInt(ep + 12);
            if (n < 0 || n > 0x100000) return;
            int at = ep + esize;
            if (at + (long) n * 12 > limit) n = Math.max(0, (limit - at) / 12);
            r.mapName = new int[n];
            r.mapType = new int[n];
            r.mapData = new int[n];
            r.mapPos = new int[n];
            for (int i = 0; i < n; i++) {
                int mp = at + i * 12;
                r.mapName[i] = b.getInt(mp);
                r.mapPos[i] = mp + 4;
                r.mapType[i] = d[mp + 4 + 3] & 0xFF;
                r.mapData[i] = b.getInt(mp + 4 + 4);
            }
        }
        entries.add(r);
    }

    private static String keyName(Pkg p, int key) {
        return key >= 0 && key < p.keyNames.strings.size() ? p.keyNames.strings.get(key) : "key" + key;
    }

    // =======================================================================================
    // describing
    // =======================================================================================

    static String describeConfig(byte[] d, int at) {
        try {
            ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
            int size = b.getInt(at);
            if (size < 28) return "default";
            List<String> q = new ArrayList<String>();
            int mcc = b.getShort(at + 4) & 0xFFFF;
            int mnc = b.getShort(at + 6) & 0xFFFF;
            if (mcc != 0) q.add("mcc" + mcc);
            if (mnc != 0) q.add("mnc" + mnc);
            String lang = chars(d, at + 8, 2);
            String country = chars(d, at + 10, 2);
            String script = size >= 44 ? chars(d, at + 36, 4) : "";
            String variant = size >= 48 ? chars(d, at + 40, 8) : "";
            if (lang.length() > 0 || country.length() > 0) {
                if (script.length() > 0 || variant.length() > 0) {
                    StringBuilder l = new StringBuilder("b+").append(lang);
                    if (script.length() > 0) l.append('+').append(script);
                    if (country.length() > 0) l.append('+').append(country);
                    if (variant.length() > 0) l.append('+').append(variant);
                    q.add(l.toString());
                } else {
                    q.add(lang + (country.length() > 0 ? "-r" + country : ""));
                }
            }
            int layout = d[at + 28] & 0xFF;
            int dir = layout & 0xC0;
            if (dir == 0x40) q.add("ldltr");
            else if (dir == 0x80) q.add("ldrtl");
            int sw = b.getShort(at + 30) & 0xFFFF;
            int w = b.getShort(at + 32) & 0xFFFF;
            int h = b.getShort(at + 34) & 0xFFFF;
            if (sw != 0) q.add("sw" + sw + "dp");
            if (w != 0) q.add("w" + w + "dp");
            if (h != 0) q.add("h" + h + "dp");
            int sz = layout & 0x0F;
            String[] szn = {"", "small", "normal", "large", "xlarge"};
            if (sz >= 1 && sz <= 4) q.add(szn[sz]);
            int lg = layout & 0x30;
            if (lg == 0x10) q.add("notlong");
            else if (lg == 0x20) q.add("long");
            int orient = d[at + 12] & 0xFF;
            if (orient == 1) q.add("port");
            else if (orient == 2) q.add("land");
            int ui = d[at + 29] & 0xFF;
            String[] uin = {"", "", "desk", "car", "television", "appliance", "watch", "vrheadset"};
            int ut = ui & 0x0F;
            if (ut >= 2 && ut < uin.length) q.add(uin[ut]);
            int night = ui & 0x30;
            if (night == 0x10) q.add("notnight");
            else if (night == 0x20) q.add("night");
            int den = b.getShort(at + 14) & 0xFFFF;
            if (den != 0) {
                switch (den) {
                    case 120:
                        q.add("ldpi");
                        break;
                    case 160:
                        q.add("mdpi");
                        break;
                    case 213:
                        q.add("tvdpi");
                        break;
                    case 240:
                        q.add("hdpi");
                        break;
                    case 320:
                        q.add("xhdpi");
                        break;
                    case 480:
                        q.add("xxhdpi");
                        break;
                    case 640:
                        q.add("xxxhdpi");
                        break;
                    case 0xFFFE:
                        q.add("anydpi");
                        break;
                    case 0xFFFF:
                        q.add("nodpi");
                        break;
                    default:
                        q.add(den + "dpi");
                }
            }
            int touch = d[at + 13] & 0xFF;
            if (touch == 1) q.add("notouch");
            else if (touch == 3) q.add("finger");
            int sdk = b.getShort(at + 24) & 0xFFFF;
            if (sdk != 0) q.add("v" + sdk);
            if (q.isEmpty()) return "default";
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < q.size(); i++) {
                if (i > 0) s.append('-');
                s.append(q.get(i));
            }
            return s.toString();
        } catch (RuntimeException e) {
            return "config?";
        }
    }

    private static String chars(byte[] d, int at, int n) {
        int len = 0;
        while (len < n && d[at + len] != 0) len++;
        if (len > 0 && (d[at] & 0x80) != 0) return "";
        return new String(d, at, len, StandardCharsets.US_ASCII);
    }

    String stringAt(int i) {
        return i >= 0 && i < global.strings.size() ? global.strings.get(i) : "";
    }

    /** Value as shown in lists (plain text for strings, same notation as the XML editor for the rest). */
    String shown(int type, int data) {
        if (type == 0x03) return stringAt(data);
        return NixuAxml.valueText(global, type, data);
    }

    /** Text that goes into the edit box for a value. */
    String editText(int type, int data) {
        return shown(type, data);
    }

    String valueSummary(Res r) {
        if (r.complex) {
            return (r.typeName.equals("style") ? "style" : r.typeName.equals("plurals") ? "plurals"
                    : r.typeName.equals("array") ? "array" : r.typeName.equals("attr") ? "attr" : "map")
                    + " (" + r.mapName.length + " items"
                    + (r.parent != 0 ? ", parent " + String.format(Locale.US, "0x%08x", r.parent) : "") + ")";
        }
        return shown(r.valueType, r.valueData);
    }

    /** How many value slots (simple values and map items) use this pool string. */
    int refCount(int poolIdx) {
        int n = 0;
        for (Res r : entries) {
            if (!r.complex) {
                if (r.valueType == 0x03 && r.valueData == poolIdx) n++;
            } else {
                for (int i = 0; i < r.mapType.length; i++) {
                    if (r.mapType[i] == 0x03 && r.mapData[i] == poolIdx) n++;
                }
            }
        }
        return n;
    }

    /** Pool strings that are used as value strings. */
    Map<Integer, Integer> stringUsage() {
        Map<Integer, Integer> m = new HashMap<Integer, Integer>();
        for (Res r : entries) {
            if (!r.complex) {
                if (r.valueType == 0x03) inc(m, r.valueData);
            } else {
                for (int i = 0; i < r.mapType.length; i++) {
                    if (r.mapType[i] == 0x03) inc(m, r.mapData[i]);
                }
            }
        }
        return m;
    }

    private static void inc(Map<Integer, Integer> m, int k) {
        Integer v = m.get(Integer.valueOf(k));
        m.put(Integer.valueOf(k), Integer.valueOf(v == null ? 1 : v.intValue() + 1));
    }

    private Set<Integer> spanNames() {
        Set<Integer> s = new HashSet<Integer>();
        byte[] st = global.styles;
        if (st == null) return s;
        ByteBuffer b = ByteBuffer.wrap(st).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < global.styleCount; i++) {
            int p = global.styleOffsets[i];
            while (p >= 0 && p + 4 <= st.length) {
                int nameIdx = b.getInt(p);
                if (nameIdx == -1) break;
                s.add(Integer.valueOf(nameIdx));
                p += 12;
            }
        }
        return s;
    }

    // =======================================================================================
    // editing
    // =======================================================================================

    /** Replaces the text of one pool string everywhere it is used (translation mode). */
    void setPoolString(int idx, String text) throws IOException {
        if (idx < 0 || idx >= global.strings.size()) throw new IOException("No such string");
        global.strings.set(idx, text);
        global.sorted = false;
        rebuildPool();
    }

    /** Changes one simple value or one map item of an entry. item = -1 for a simple value. */
    void setValue(int entryIndex, int item, String text) throws IOException {
        Res r = entries.get(entryIndex);
        int type;
        int val;
        NixuAxml.Val v;
        boolean asString;
        if (text.startsWith("\\")) {
            asString = true;
            text = text.substring(1);
            v = null;
        } else {
            v = NixuAxml.parseValue(text);
            asString = v == null;
        }
        int pos;
        int oldType;
        int oldData;
        if (item < 0) {
            if (r.complex || r.valuePos < 0) throw new IOException("This entry cannot be edited as a single value");
            pos = r.valuePos;
            oldType = r.valueType;
            oldData = r.valueData;
        } else {
            if (item >= r.mapPos.length) throw new IOException("No such item");
            pos = r.mapPos[item];
            oldType = r.mapType[item];
            oldData = r.mapData[item];
        }
        if (!asString) {
            type = v.type;
            val = v.data;
            data[pos + 3] = (byte) type;
            putInt(data, pos + 4, val);
            reparse();
            return;
        }
        // string: reuse the pool slot when nothing else uses it, otherwise add a new string
        boolean inPlace = oldType == 0x03 && refCount(oldData) == 1 && !spanNames().contains(Integer.valueOf(oldData))
                && oldData < global.strings.size();
        int idx;
        if (inPlace) {
            idx = oldData;
            global.strings.set(idx, text);
        } else {
            int found = -1;
            // an identical plain string already in the pool can be shared (never a styled one)
            for (int i = Math.max(global.styleCount, 0); i < global.strings.size(); i++) {
                if (global.strings.get(i).equals(text)) {
                    found = i;
                    break;
                }
            }
            if (found >= 0) {
                idx = found;
            } else {
                global.strings.add(text);
                idx = global.strings.size() - 1;
            }
        }
        data[pos + 3] = 0x03;
        putInt(data, pos + 4, idx);
        global.sorted = false;
        rebuildPool();
    }

    private void rebuildPool() throws IOException {
        byte[] pool = global.build();
        int oldEnd = globalPos + global.readSize;
        byte[] nd = new byte[globalPos + pool.length + (data.length - oldEnd)];
        System.arraycopy(data, 0, nd, 0, globalPos);
        System.arraycopy(pool, 0, nd, globalPos, pool.length);
        System.arraycopy(data, oldEnd, nd, globalPos + pool.length, data.length - oldEnd);
        putInt(nd, 4, nd.length);
        data = nd;
        reparse();
    }

    private static void putInt(byte[] d, int at, int v) {
        d[at] = (byte) v;
        d[at + 1] = (byte) (v >> 8);
        d[at + 2] = (byte) (v >> 16);
        d[at + 3] = (byte) (v >> 24);
    }

    byte[] toBytes() {
        return data;
    }

    // =======================================================================================
    // text dump
    // =======================================================================================

    void dump(StringBuilder sb, int maxEntries) {
        sb.append("resources.arsc: ").append(data.length).append(" bytes, ").append(pkgs.size())
                .append(" package(s), ").append(entries.size()).append(" entries, ")
                .append(global.strings.size()).append(" pool strings\n");
        for (Pkg p : pkgs) {
            sb.append("package 0x").append(Integer.toHexString(p.id)).append(' ').append(p.name).append('\n');
        }
        int shownCount = 0;
        for (Res r : entries) {
            if (shownCount >= maxEntries) {
                sb.append("... ").append(entries.size() - shownCount).append(" more entries not listed\n");
                break;
            }
            sb.append(r.id()).append(' ').append(r.path()).append(" [").append(r.config).append("] = ");
            if (r.complex) {
                sb.append(valueSummary(r)).append('\n');
                for (int i = 0; i < r.mapName.length; i++) {
                    sb.append("    ").append(String.format(Locale.US, "0x%08x", r.mapName[i])).append(" = ")
                            .append(oneLine(shown(r.mapType[i], r.mapData[i]))).append('\n');
                }
            } else {
                sb.append(oneLine(valueSummary(r))).append('\n');
            }
            shownCount++;
        }
    }

    private static String oneLine(String s) {
        if (s == null) return "";
        String t = s.replace("\n", "\\n").replace("\r", "\\r");
        return t.length() > 300 ? t.substring(0, 300) + "..." : t;
    }
}
