package com.chanit.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout

/** Lets the app be chosen as "Default digital assistant" (power-button long press / home gesture). */
class AssistVIService : VoiceInteractionService()

class AssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = AssistSession(this)
}

class AssistSession(ctx: Context) : VoiceInteractionSession(ctx) {
    private var panel: OrbPanel? = null

    override fun onCreateContentView(): View {
        val p = OrbPanel(context)
        panel = p
        val root = FrameLayout(context)
        val lp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        lp.bottomMargin = 120
        root.addView(p, lp)
        return root
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        panel?.let {
            it.onIdle = { hide() }
            AssistantService.panels.add(it)
        }
        AssistantService.listenNow(context)
    }

    override fun onHide() {
        panel?.let { AssistantService.panels.remove(it) }
        super.onHide()
    }
}

/** Needed so Android accepts the app as an assistant. Does nothing itself. */
class StubRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }
    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
