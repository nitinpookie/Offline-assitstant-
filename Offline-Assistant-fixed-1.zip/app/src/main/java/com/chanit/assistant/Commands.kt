package com.chanit.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class Reply(val text: String, val follow: Boolean = false)

private val DEV = mapOf(
    'क' to "k", 'ख' to "k", 'ग' to "g", 'घ' to "g", 'च' to "c", 'छ' to "c", 'ज' to "j", 'झ' to "j",
    'ट' to "t", 'ठ' to "t", 'त' to "t", 'थ' to "t", 'ड' to "d", 'ढ' to "d", 'द' to "d", 'ध' to "d",
    'ण' to "n", 'न' to "n", 'ं' to "n", 'ँ' to "n", 'प' to "p", 'फ' to "p", 'ब' to "b", 'भ' to "b",
    'म' to "m", 'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "s", 'ष' to "s", 'स' to "s"
)

/** Rough sound skeleton so Devanagari speech matches Roman names: राहुल -> "rl", Rahul -> "rl" */
fun skel(s: String): String {
    val sb = StringBuilder()
    for (ch in s.lowercase(Locale.ROOT)) {
        val m: String? = when (ch) {
            'a', 'e', 'i', 'o', 'u', 'h' -> null
            'w' -> "v"
            'z' -> "j"
            'q' -> "k"
            'f' -> "p"
            'x' -> "s"
            in 'a'..'z' -> ch.toString()
            else -> DEV[ch]
        }
        if (m != null && !sb.endsWith(m)) sb.append(m)
    }
    return sb.toString()
}

class Commands(private val c: Context, private val llm: LlmEngine) {

    companion object {
        @Volatile var torchOn = false

        private val UNITS = listOf(
            "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
            "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"
        )
        private val TENS = mapOf(
            "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60,
            "seventy" to 70, "eighty" to 80, "ninety" to 90
        )
        private val HI_NUM = mapOf(
            "शून्य" to 0, "एक" to 1, "दो" to 2, "तीन" to 3, "चार" to 4, "पांच" to 5, "पाँच" to 5, "छह" to 6, "छः" to 6,
            "छे" to 6, "सात" to 7, "आठ" to 8, "नौ" to 9, "दस" to 10, "ग्यारह" to 11, "बारह" to 12, "तेरह" to 13,
            "चौदह" to 14, "पंद्रह" to 15, "पन्द्रह" to 15, "सोलह" to 16, "सत्रह" to 17, "अठारह" to 18, "उन्नीस" to 19,
            "बीस" to 20, "इक्कीस" to 21, "बाईस" to 22, "तेईस" to 23, "चौबीस" to 24, "पच्चीस" to 25, "छब्बीस" to 26,
            "सत्ताईस" to 27, "अट्ठाईस" to 28, "उनतीस" to 29, "तीस" to 30, "इकतीस" to 31, "बत्तीस" to 32,
            "तैंतीस" to 33, "चौंतीस" to 34, "पैंतीस" to 35, "छत्तीस" to 36, "सैंतीस" to 37, "अड़तीस" to 38,
            "उनतालीस" to 39, "चालीस" to 40, "इकतालीस" to 41, "बयालीस" to 42, "तैंतालीस" to 43, "चवालीस" to 44,
            "पैंतालीस" to 45, "छियालीस" to 46, "सैंतालीस" to 47, "अड़तालीस" to 48, "उनचास" to 49, "पचास" to 50,
            "इक्यावन" to 51, "बावन" to 52, "तिरपन" to 53, "चौवन" to 54, "पचपन" to 55, "छप्पन" to 56,
            "सत्तावन" to 57, "अट्ठावन" to 58, "उनसठ" to 59, "साठ" to 60, "सत्तर" to 70, "अस्सी" to 80, "नब्बे" to 90
        )
        private val OPS = mapOf(
            "plus" to '+', "add" to '+', "added" to '+', "प्लस" to '+', "जोड़" to '+', "जोड़ो" to '+', "जोड़ें" to '+',
            "minus" to '-', "subtract" to '-', "माइनस" to '-', "घटा" to '-', "घटाओ" to '-', "घटाना" to '-',
            "times" to '*', "multiplied" to '*', "into" to '*', "गुना" to '*', "गुणा" to '*',
            "divided" to '/', "over" to '/', "भाग" to '/', "बटा" to '/', "डिवाइड" to '/'
        )
        private val ALIAS = mapOf(
            "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "व्हाट्सअप" to "whatsapp",
            "यूट्यूब" to "youtube", "कैमरा" to "camera", "सेटिंग" to "settings", "सेटिंग्स" to "settings",
            "गैलरी" to "gallery", "क्रोम" to "chrome", "इंस्टाग्राम" to "instagram", "कैलकुलेटर" to "calculator",
            "घड़ी" to "clock", "गूगल" to "google", "मैप्स" to "maps", "नक्शा" to "maps", "फोन" to "phone",
            "मैसेज" to "messages", "संदेश" to "messages", "फेसबुक" to "facebook", "टेलीग्राम" to "telegram",
            "स्नैपचैट" to "snapchat", "कॉन्टैक्ट्स" to "contacts", "प्ले स्टोर" to "play store"
        )
        private val CALL_STOP = setOf(
            "call", "dial", "please", "to", "a", "the", "कॉल", "काल", "डायल", "फोन", "फ़ोन",
            "करो", "लगाओ", "मिलाओ", "को", "जी", "पर", "कीजिए"
        )
        private val OPEN_STOP = setOf(
            "open", "launch", "start", "the", "app", "please", "खोलो", "खोलिए", "खोल", "ओपन", "करो",
            "ऐप", "एप", "एप्प", "ऐप्प", "को", "चालू", "शुरू", "दो", "कीजिए", "जरा", "ज़रा"
        )
        private val MSG_STOP = setOf(
            "send", "a", "the", "message", "messages", "msg", "sms", "text", "whatsapp", "to", "please", "on", "via",
            "मैसेज", "मेसेज", "संदेश", "भेजो", "भेज", "दो", "करो", "कर", "को", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप",
            "व्हाट्सअप", "पर", "से", "एक", "कीजिए", "भेजिए"
        )
        private val NOTE_STOP = setOf(
            "make", "a", "an", "note", "notes", "down", "that", "add", "take", "save", "my", "the", "please", "to",
            "नोट", "नोट्स", "करो", "कर", "लिखो", "लिख", "लो", "ले", "लीजिए", "कि", "मेरा", "मेरे", "मुझे", "एक", "दो"
        )
        private val REM_STOP = setOf(
            "remind", "me", "to", "in", "at", "after", "minutes", "minute", "min", "mins", "hour", "hours", "second",
            "seconds", "day", "days", "tomorrow", "today", "tonight", "morning", "evening", "pm", "am", "a", "an",
            "about", "that", "please", "set", "reminder", "the", "of", "for", "p", "m", "o'clock", "later",
            "याद", "दिलाओ", "दिला", "दिलाना", "मुझे", "मिनट", "घंटे", "घंटा", "सेकंड", "सेकेंड", "बाद", "में",
            "बजे", "कल", "आज", "सुबह", "शाम", "रात", "दोपहर", "रिमाइंडर", "रिमाइंड", "करो", "कर", "दो", "को",
            "का", "की", "के", "लिए", "दिन", "साढ़े", "साढे", "सवा", "एक", "करा", "कराओ"
        )
        private val FILLER = setOf(
            "what", "is", "whats", "how", "much", "calculate", "the", "of", "की", "क्या", "होता", "है", "कितना",
            "कितने", "बताओ", "बताइए", "कैलकुलेट"
        )
    }

    private var hi = false
    private var pending: ((String) -> Reply)? = null

    private fun r(en: String, hiText: String) = if (hi) hiText else en
    private fun rep(en: String, hiText: String, follow: Boolean = false) = Reply(r(en, hiText), follow)
    private fun has(t: String, vararg k: String) = k.any { t.contains(it) }
    private fun go(i: Intent) = c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    private fun granted(p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun norm(s: String) = s.lowercase(Locale.ROOT)
        .replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), "").replace(Regex("\\s+"), " ").trim()

    private fun isYes(t: String): Boolean {
        val w = t.lowercase(Locale.ROOT).split(" ")
        return w.any { it in setOf("yes", "yeah", "yep", "sure", "ok", "okay", "send", "correct", "right") } ||
            has(t, "हाँ", "हां", "भेज दो", "भेजो", "ठीक", "सही", "कर दो")
    }

    private fun isCancel(t: String): Boolean {
        val w = t.split(" ")
        return w.any { it in setOf("no", "cancel", "stop", "nevermind") } ||
            has(t, "never mind", "रुको", "छोड़ो", "रहने दो", "नहीं", "मत")
    }

    private fun isCallCmd(t: String) = has(
        t, "call", "dial", "कॉल", "काल", "डायल", "फोन करो", "फोन लगाओ", "फोन मिलाओ", "फ़ोन करो", "फ़ोन लगाओ"
    )

    // =====================================================================
    fun handle(raw: String, hindi: Boolean, locked: Boolean, depth: Int = 0): Reply {
        hi = hindi
        val t = raw.lowercase(Locale.ROOT).trim()
        val w = t.split(Regex("\\s+")).filter { it.isNotEmpty() }

        // lock screen: ONLY calls
        if (locked) {
            pending = null
            return if (isCallCmd(t)) Reply(call(w))
            else rep(
                "The phone is locked. Only calls work right now.",
                "फोन लॉक है। अभी सिर्फ कॉल हो सकती है।"
            )
        }

        val p = pending
        if (p != null) {
            pending = null
            if (isCancel(t) && !isYes(t)) return rep("Okay, cancelled.", "ठीक है, रद्द कर दिया।")
            return p(raw)
        }

        if (depth == 0) {
            val n = norm(t)
            for ((trig, act) in Store.customs(c)) {
                val k = norm(trig)
                if (k.isNotEmpty() && (n == k || (k.length >= 4 && n.contains(k)))) return runCustom(act, hindi)
            }
        }

        val isOpen = w.any { it == "open" || it == "launch" } || has(t, "खोलो", "खोलिए", "ओपन", "खोल दो")

        if (has(t, "new command", "create command", "add command", "नया कमांड", "कमांड बनाओ", "कमांड बना")) return newCommand()
        if (has(t, "forget everything", "new topic", "reset chat", "नई बात", "सब भूल जाओ")) {
            llm.reset()
            return rep("Okay, starting fresh.", "ठीक है, नई शुरुआत।")
        }
        media(t, w)?.let { return it }
        if (t == "stop" || has(t, "never mind", "cancel", "रुको", "छोड़ो", "रहने दो")) return rep("Okay.", "ठीक है।")
        if (isMessage(t, isOpen)) return messageFlow(t, w)
        if (isCallCmd(t)) return Reply(call(w))
        if (has(t, "torch", "flashlight", "flash light", "टॉर्च", "टोर्च", "फ्लैश", "फ़्लैश")) return Reply(torch(t, w))
        if (has(t, "remind", "reminder", "याद दिला", "याद करा", "रिमाइंड", "रिमाइंडर")) return reminder(t, w)
        if (has(t, "alarm", "अलार्म")) return Reply(alarm(t, w))
        if (has(t, "timer", "टाइमर")) return Reply(timer(t, w))
        if (has(t, "note", "नोट", "लिख लो")) return notes(t, w)
        if (isMath(t, w)) return Reply(math(t, w))
        camera(t, w, isOpen)?.let { return it }
        screen(t, w)?.let { return it }
        if (has(t, "brightness", "ब्राइटनेस", "चमक")) return Reply(brightness(t, w))
        if (has(t, "volume", "वॉल्यूम", "आवाज")) return Reply(volume(t, w))
        if (has(t, "battery", "बैटरी")) return Reply(battery())
        if (has(t, "wifi", "wi-fi", "wi fi", "वाईफाई", "वाई फाई", "वाईफ़ाई")) {
            go(Intent(Settings.ACTION_WIFI_SETTINGS)); return rep("Opening Wi-Fi.", "वाईफाई खोल रहा हूँ।")
        }
        if (has(t, "bluetooth", "ब्लूटूथ")) {
            go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return rep("Opening Bluetooth.", "ब्लूटूथ खोल रहा हूँ।")
        }
        if (has(t, "date", "what day", "तारीख", "तारिख", "कौन सा दिन")) return Reply(date())
        if (has(t, "time", "समय", "टाइम", "बजे हैं", "कितने बजे")) return Reply(time())
        if (isOpen || w.firstOrNull() == "start") return Reply(open(w))

        // anything else -> offline AI
        if (!LlmEngine.supported()) {
            return rep(
                "Sorry, I can't do that. The offline AI doesn't run on this phone.",
                "माफ़ कीजिए, मैं यह नहीं कर सकता। इस फ़ोन पर ऑफ़लाइन AI नहीं चलता।"
            )
        }
        if (!llm.ready()) {
            return rep(
                "Sorry, I can't do that yet. Add an AI model in the app so I can answer questions.",
                "माफ़ कीजिए, अभी मैं यह नहीं कर सकता। सवालों के जवाब के लिए ऐप में AI मॉडल जोड़िए।"
            )
        }
        return try {
            Reply(llm.ask(raw, hi).ifEmpty { r("Sorry, I couldn't answer that.", "माफ़ कीजिए, जवाब नहीं दे पाया।") }, true)
        } catch (e: Throwable) {
            llm.reset()
            rep("Sorry, the AI had a problem.", "माफ़ कीजिए, AI में दिक्कत आई।")
        }
    }

    // ---------------------------------------------------------------- custom commands
    private fun runCustom(act: String, hindi: Boolean): Reply {
        val a = act.trim()
        val low = a.lowercase(Locale.ROOT)
        for (p in listOf("say ", "bolo ", "बोलो ", "कहो ")) {
            if (low.startsWith(p)) return Reply(a.substring(p.length))
        }
        return handle(a, hindi, false, 1)
    }

    private fun newCommand(): Reply {
        pending = { trig ->
            pending = { act ->
                val list = Store.customs(c)
                list.add(trig.trim() to act.trim())
                Store.saveCustoms(c, list)
                rep("Done. When you say $trig, I will do that.", "हो गया। जब आप $trig बोलेंगे, मैं वो करूँगा।")
            }
            rep("What should I do when you say $trig?", "$trig बोलने पर क्या करूँ?", true)
        }
        return rep("What should I listen for?", "किस बात पर सुनूँ?", true)
    }

    // ---------------------------------------------------------------- numbers
    private fun numWord(w: String): Int? {
        val u = UNITS.indexOf(w)
        if (u >= 0) return u
        TENS[w]?.let { return it }
        return HI_NUM[w]
    }

    private fun nums(words: List<String>): List<Int> {
        val out = ArrayList<Int>()
        var cur = 0L
        var total = 0L
        var active = false
        var prevTens = false
        var afterScale = false
        fun flush() {
            if (active) out.add((total + cur).toInt())
            cur = 0; total = 0; active = false; prevTens = false; afterScale = false
        }
        for (w in words) {
            val d = w.toLongOrNull()
            val sp = if (d == null) numWord(w) else null
            when {
                d != null -> { flush(); cur = d; active = true }
                w == "hundred" || w == "सौ" -> {
                    if (!active) { cur = 1; active = true }
                    cur *= 100; afterScale = true; prevTens = false
                }
                w == "thousand" || w == "हजार" || w == "हज़ार" -> {
                    if (!active) { cur = 1; active = true }
                    total += cur * 1000; cur = 0; afterScale = true; prevTens = false
                }
                sp != null -> {
                    val isUnit = sp in 1..9
                    if (active && ((prevTens && isUnit) || afterScale)) {
                        cur += sp
                    } else {
                        flush(); cur = sp.toLong(); active = true
                    }
                    prevTens = sp in 20..90 && sp % 10 == 0
                }
                else -> flush()
            }
        }
        flush()
        return out
    }

    private fun digitOf(s: String): Int? {
        s.toIntOrNull()?.let { if (it in 0..9) return it }
        if (s == "oh") return 0
        return numWord(s)?.takeIf { it in 0..9 }
    }

    // ---------------------------------------------------------------- calculator
    private fun isMath(t: String, w: List<String>): Boolean {
        val n = nums(w).size
        return n >= 2 && (w.any { it in OPS } || has(t, "percent", "प्रतिशत", "परसेंट"))
    }

    private fun math(t: String, w: List<String>): String {
        if (has(t, "percent", "प्रतिशत", "परसेंट")) {
            val n = nums(w)
            val v = n[0] * n[1] / 100.0
            return ans(v)
        }
        val vals = ArrayList<Double>()
        val ops = ArrayList<Char>()
        var seg = ArrayList<String>()
        fun flush() {
            val v = nums(seg).firstOrNull()
            if (v != null) vals.add(v.toDouble())
            seg = ArrayList()
        }
        for (x in w) {
            if (x in FILLER) continue
            val op = OPS[x]
            if (op != null) { flush(); ops.add(op) } else seg.add(x)
        }
        flush()
        if (vals.size != ops.size + 1) return r("I didn't understand the numbers.", "संख्याएँ समझ नहीं आईं।")
        var i = 0
        while (i < ops.size) {
            if (ops[i] == '*' || ops[i] == '/') {
                val a = vals[i]
                val b = vals[i + 1]
                if (ops[i] == '/' && b == 0.0) return r("I can't divide by zero.", "शून्य से भाग नहीं हो सकता।")
                vals[i] = if (ops[i] == '*') a * b else a / b
                vals.removeAt(i + 1)
                ops.removeAt(i)
            } else i++
        }
        var res = vals[0]
        for (j in ops.indices) res = if (ops[j] == '+') res + vals[j + 1] else res - vals[j + 1]
        return ans(res)
    }

    private fun ans(v: Double): String {
        val s = if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else "%.2f".format(v)
        return r("The answer is $s.", "जवाब $s है।")
    }

    // ---------------------------------------------------------------- torch / alarm / timer
    private fun torch(t: String, w: List<String>): String {
        val off = "off" in w || has(t, "बंद", "बुझा", "ऑफ")
        val on = "on" in w || has(t, "चालू", "जला", "ऑन")
        val target = if (off) false else if (on) true else !torchOn
        val cm = c.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return r("No flashlight found.", "फ्लैश नहीं मिला।")
        cm.setTorchMode(id, target)
        torchOn = target
        return if (target) r("Torch on.", "टॉर्च चालू।") else r("Torch off.", "टॉर्च बंद।")
    }

    private fun alarm(t: String, w: List<String>): String {
        val n = nums(w)
        if (n.isEmpty()) return r("For what time?", "किस समय के लिए?")
        var h = n[0]
        var m = n.getOrElse(1) { 0 }
        if (has(t, "साढ़े", "साढे", "half past")) m = 30
        if (has(t, "सवा", "quarter past")) m = 15
        if (has(t, " pm", "p m", "शाम", "रात", "दोपहर") && h < 12) h += 12
        if (h > 23 || m > 59) return r("I didn't get the time.", "समय समझ नहीं आया।")
        go(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return r("Alarm set for %d:%02d.".format(h, m), "अलार्म %d बजकर %d मिनट पर लगा दिया।".format(h, m))
    }

    private fun timer(t: String, w: List<String>): String {
        val n = nums(w).firstOrNull() ?: return r("For how long?", "कितने समय के लिए?")
        val secs = when {
            has(t, "hour", "घंटे", "घंटा") -> n * 3600
            has(t, "second", "सेकंड", "सेकेंड") -> n
            else -> n * 60
        }
        go(
            Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return r("Timer started.", "टाइमर शुरू कर दिया।")
    }

    // ---------------------------------------------------------------- reminders
    private fun parseWhen(t: String, w: List<String>): Long? {
        val n = nums(w)
        if (n.isEmpty()) return null
        val now = System.currentTimeMillis()
        val abs = has(t, " pm", "p m", " am", "a m", "बजे", " at ", "o'clock")
        val unitMs: Long? = when {
            has(t, "second", "सेकंड", "सेकेंड") -> 1000L
            has(t, "minute", "mins", " min", "मिनट") -> 60_000L
            has(t, "hour", "घंटे", "घंटा") -> 3_600_000L
            has(t, "day", "दिन") -> 86_400_000L
            else -> null
        }
        val rel = has(t, " in ", "after", "बाद", "later") || t.startsWith("in ")
        if (unitMs != null && (rel || !abs)) return now + n[0] * unitMs
        var h = n[0]
        val m = n.getOrElse(1) { 0 }
        if (h > 23 || m > 59) return null
        val pm = has(t, " pm", "p m", "शाम", "रात", "दोपहर")
        val am = has(t, " am", "a m", "सुबह")
        if (pm && h < 12) h += 12
        val cal = Calendar.getInstance()
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.set(Calendar.MINUTE, m)
        cal.set(Calendar.HOUR_OF_DAY, h)
        if (has(t, "tomorrow", "कल")) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        } else if (cal.timeInMillis <= now) {
            if (!pm && !am && h < 12) {
                cal.add(Calendar.HOUR_OF_DAY, 12)
                if (cal.timeInMillis <= now) cal.add(Calendar.HOUR_OF_DAY, 12)
            } else cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun reminder(t: String, w: List<String>): Reply {
        val whenMs = parseWhen(t, w)
        if (whenMs == null) {
            pending = { x ->
                val t2 = t + " " + x.lowercase(Locale.ROOT)
                reminder(t2, t2.split(Regex("\\s+")).filter { it.isNotEmpty() })
            }
            return rep("When should I remind you?", "कब याद दिलाऊँ?", true)
        }
        val task = w.filter { it !in REM_STOP && it.toIntOrNull() == null && numWord(it) == null }.joinToString(" ")
        if (task.isEmpty()) {
            pending = { x -> addReminder(whenMs, x) }
            return rep("What should I remind you about?", "किस बारे में याद दिलाऊँ?", true)
        }
        return addReminder(whenMs, task)
    }

    private fun addReminder(whenMs: Long, text: String): Reply {
        Reminders.add(c, whenMs, text)
        val at = SimpleDateFormat("h:mm a", Locale.US).format(Date(whenMs))
        return rep("Okay, I'll remind you at $at.", "ठीक है, $at पर याद दिला दूँगा।")
    }

    // ---------------------------------------------------------------- notes
    private fun notes(t: String, w: List<String>): Reply {
        val list = Store.notes(c)
        if (has(t, "delete", "clear", "remove", "हटाओ", "मिटाओ", "डिलीट", "साफ")) {
            Store.saveNotes(c, emptyList())
            return rep("All notes deleted.", "सारे नोट्स हटा दिए।")
        }
        if (has(t, "read", "list", "show", "my notes", "सुनाओ", "पढ़", "बताओ", "दिखाओ")) {
            if (list.isEmpty()) return rep("You have no notes.", "आपका कोई नोट नहीं है।")
            val last = list.takeLast(5)
            val s = last.mapIndexed { i, x -> r("Note ${i + 1}: $x.", "नोट ${i + 1}: $x।") }.joinToString(" ")
            return Reply(s)
        }
        val body = w.filter { it !in NOTE_STOP }.joinToString(" ")
        if (body.isEmpty()) {
            pending = { x -> saveNote(x) }
            return rep("What should I note down?", "क्या नोट करूँ?", true)
        }
        return saveNote(body)
    }

    private fun saveNote(x: String): Reply {
        val list = Store.notes(c)
        list.add(x.trim())
        Store.saveNotes(c, list)
        return rep("Noted.", "नोट कर लिया।")
    }

    // ---------------------------------------------------------------- media
    private fun key(code: Int) {
        val am = c.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun media(t: String, w: List<String>): Reply? {
        if (has(t, "pause", "stop music", "stop the music", "stop song", "गाना बंद", "गाना रोक", "म्यूजिक बंद", "संगीत बंद")) {
            key(KeyEvent.KEYCODE_MEDIA_PAUSE); return rep("Paused.", "रोक दिया।")
        }
        if (has(t, "next song", "next track", "skip song", "अगला गाना", "नेक्स्ट सॉन्ग") || t == "next" || t == "अगला") {
            key(KeyEvent.KEYCODE_MEDIA_NEXT); return rep("Next song.", "अगला गाना।")
        }
        if (has(t, "previous song", "previous track", "last song", "पिछला गाना", "प्रीवियस") || t == "previous" || t == "पिछला") {
            key(KeyEvent.KEYCODE_MEDIA_PREVIOUS); return rep("Previous song.", "पिछला गाना।")
        }
        if (has(t, "resume", "continue music", "फिर से चलाओ")) {
            key(KeyEvent.KEYCODE_MEDIA_PLAY); return rep("Playing.", "चला रहा हूँ।")
        }
        val playWord = w.firstOrNull() == "play" || has(t, "चलाओ", "बजाओ", "प्ले")
        if (!playWord) return null
        val stop = setOf(
            "play", "music", "song", "the", "some", "please", "a", "चलाओ", "बजाओ", "प्ले", "गाना", "गाने",
            "संगीत", "म्यूजिक", "चला", "दो", "कर", "करो"
        )
        val q = w.filter { it !in stop }.joinToString(" ")
        if (q.isEmpty()) {
            key(KeyEvent.KEYCODE_MEDIA_PLAY); return rep("Playing music.", "म्यूजिक चला रहा हूँ।")
        }
        try {
            go(
                Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                    .putExtra(SearchManager.QUERY, q)
                    .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            )
        } catch (e: Exception) {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        }
        return rep("Playing $q.", "$q चला रहा हूँ।")
    }

    // ---------------------------------------------------------------- camera
    private fun needAcc(): Reply {
        try { go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) {}
        return rep(
            "Please turn on the Chanit Assistant accessibility service, then ask again.",
            "कृपया Chanit Assistant की एक्सेसिबिलिटी सेवा चालू कीजिए, फिर दोबारा बोलिए।"
        )
    }

    private fun camera(t: String, w: List<String>, isOpen: Boolean): Reply? {
        val selfie = has(t, "selfie", "सेल्फी")
        val photo = has(t, "photo", "picture", "फोटो", "फ़ोटो", "तस्वीर") &&
            has(t, "take", "click", "capture", "खींच", "लो", "क्लिक", "खिंच")
        val video = has(t, "video", "वीडियो") && has(t, "record", "shoot", "start", "बना", "रिकॉर्ड", "शूट")
        val stopRec = has(t, "stop recording", "रिकॉर्डिंग बंद", "रिकॉर्डिंग रोक")
        if (stopRec) {
            val acc = ScreenService.instance ?: return needAcc()
            acc.clickText("stop", "shutter", "record")
            return rep("Stopped recording.", "रिकॉर्डिंग बंद कर दी।")
        }
        if (isOpen && !selfie) return null
        if (selfie || photo) {
            val i = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            if (selfie) {
                i.putExtra("android.intent.extras.CAMERA_FACING", 1)
                i.putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
            }
            go(i)
            val acc = ScreenService.instance
            if (acc != null) {
                Thread {
                    Thread.sleep(3500)
                    acc.clickText("shutter", "capture", "take photo", "take picture")
                }.start()
                return rep("Smile! Taking the photo in 3 seconds.", "मुस्कुराइए! 3 सेकंड में फोटो लेता हूँ।")
            }
            return rep(
                "Camera opened. Turn on accessibility so I can press the shutter.",
                "कैमरा खोल दिया। शटर दबाने के लिए एक्सेसिबिलिटी चालू कीजिए।"
            )
        }
        if (video) {
            go(Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA))
            val acc = ScreenService.instance
            if (acc != null) {
                Thread {
                    Thread.sleep(3000)
                    acc.clickText("record", "shutter", "start recording")
                }.start()
                return rep("Recording will start in 3 seconds.", "3 सेकंड में रिकॉर्डिंग शुरू होगी।")
            }
            return rep("Video camera opened.", "वीडियो कैमरा खोल दिया।")
        }
        return null
    }

    // ---------------------------------------------------------------- screen control
    private fun screen(t: String, w: List<String>): Reply? {
        val action: Int? = when {
            has(t, "go home", "home screen", "होम स्क्रीन", "होम पर") || t == "home" || t == "होम" ->
                AccessibilityService.GLOBAL_ACTION_HOME
            has(t, "go back", "पीछे जाओ", "वापस जाओ", "बैक") || t == "back" ->
                AccessibilityService.GLOBAL_ACTION_BACK
            has(t, "recent apps", "recents", "रीसेंट", "रिसेंट") -> AccessibilityService.GLOBAL_ACTION_RECENTS
            has(t, "notification", "नोटिफिकेशन") -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            has(t, "quick settings", "क्विक सेटिंग") -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            has(t, "screenshot", "screen shot", "स्क्रीनशॉट", "स्क्रीन शॉट") ->
                AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
            has(t, "lock screen", "lock the phone", "lock phone", "स्क्रीन लॉक", "फोन लॉक", "फ़ोन लॉक") ->
                AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
            has(t, "power menu", "पावर मेन्यू") -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
            else -> null
        }
        if (action != null) {
            val acc = ScreenService.instance ?: return needAcc()
            acc.global(action)
            return rep("Done.", "हो गया।")
        }
        if (has(t, "scroll", "स्क्रॉल")) {
            val acc = ScreenService.instance ?: return needAcc()
            acc.scroll(has(t, "down", "नीचे"))
            return rep("Scrolling.", "स्क्रॉल कर रहा हूँ।")
        }
        val clickWord = w.firstOrNull() in setOf("click", "tap", "press") ||
            has(t, "दबाओ", "क्लिक करो", "टैप करो", "क्लिक कर")
        if (clickWord) {
            val stop = setOf("click", "tap", "press", "on", "the", "button", "दबाओ", "क्लिक", "करो", "टैप", "बटन", "पर", "कर")
            val target = w.filter { it !in stop }.joinToString(" ")
            if (target.isEmpty()) return null
            val acc = ScreenService.instance ?: return needAcc()
            return if (acc.clickText(target, ALIAS[target] ?: target)) rep("Tapped $target.", "$target दबा दिया।")
            else rep("I couldn't find $target on the screen.", "स्क्रीन पर $target नहीं मिला।")
        }
        return null
    }

    private fun brightness(t: String, w: List<String>): String {
        if (!Settings.System.canWrite(c)) {
            go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.packageName)))
            return r("Please allow modify system settings, then ask again.", "सिस्टम सेटिंग बदलने की अनुमति दीजिए, फिर दोबारा बोलिए।")
        }
        val cr = c.contentResolver
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val up = "up" in w || has(t, "increase", "more", "बढ़ा", "बढा", "ज्यादा", "ज़्यादा")
        val down = "down" in w || has(t, "decrease", "less", "dim", "कम", "घटा")
        val v = when {
            has(t, "full", "max", "फुल", "पूरी") -> 255
            up -> cur + 50
            down -> cur - 50
            has(t, "low", "minimum") -> 25
            else -> return r("Say brightness up or down.", "ब्राइटनेस बढ़ाओ या कम करो बोलिए।")
        }
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v.coerceIn(10, 255))
        return r("Brightness changed.", "ब्राइटनेस बदल दी।")
    }

    private fun volume(t: String, w: List<String>): String {
        val am = c.getSystemService(AudioManager::class.java)
        return when {
            has(t, "mute", "म्यूट") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                r("Muted.", "म्यूट कर दिया।")
            }
            "up" in w || has(t, "increase", "louder", "बढ़ा", "बढा", "ज्यादा", "ज़्यादा") -> {
                repeat(3) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, if (it == 2) AudioManager.FLAG_SHOW_UI else 0)
                }
                r("Volume up.", "आवाज़ बढ़ा दी।")
            }
            "down" in w || has(t, "decrease", "lower", "कम", "घटा") -> {
                repeat(3) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, if (it == 2) AudioManager.FLAG_SHOW_UI else 0)
                }
                r("Volume down.", "आवाज़ कम कर दी।")
            }
            else -> r("Say volume up or volume down.", "आवाज़ बढ़ाओ या आवाज़ कम करो बोलिए।")
        }
    }

    private fun battery(): String {
        val p = c.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return r("Battery is at $p percent.", "बैटरी $p प्रतिशत है।")
    }

    private fun time(): String {
        val cal = Calendar.getInstance()
        var h = cal.get(Calendar.HOUR)
        if (h == 0) h = 12
        val m = cal.get(Calendar.MINUTE)
        return r("It's " + SimpleDateFormat("h:mm a", Locale.US).format(Date()) + ".", "अभी $h बजकर $m मिनट हुए हैं।")
    }

    private fun date(): String {
        val loc = if (hi) Locale("hi", "IN") else Locale.US
        val d = SimpleDateFormat("EEEE, d MMMM", loc).format(Date())
        return r("Today is $d.", "आज $d है।")
    }

    // ---------------------------------------------------------------- calls
    private fun call(w: List<String>): String {
        val rest = w.filter { it !in CALL_STOP }
        val digits = rest.map { if (it.all(Char::isDigit)) it else digitOf(it)?.toString() }
        if (rest.isNotEmpty() && digits.all { it != null } && digits.joinToString("").length >= 6) {
            return dial(digits.joinToString(""), null)
        }
        val name = rest.joinToString(" ")
        if (name.isEmpty()) return r("Whom should I call?", "किसे कॉल करूँ?")
        if (!granted(Manifest.permission.READ_CONTACTS)) {
            return r("Please allow contacts permission in the app.", "ऐप में कॉन्टैक्ट्स की अनुमति दे दीजिए।")
        }
        val found = findContact(name)
            ?: return r("I couldn't find $name in your contacts.", "$name कॉन्टैक्ट्स में नहीं मिला।")
        return dial(found.second, found.first)
    }

    private fun findContact(name: String): Pair<String, String>? {
        val key = skel(name)
        val low = name.lowercase(Locale.ROOT)
        var part: Pair<String, String>? = null
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, cols, null, null, null)?.use { cur ->
            while (cur.moveToNext()) {
                val n = cur.getString(0) ?: continue
                val num = cur.getString(1) ?: continue
                val k = skel(n)
                if (n.lowercase(Locale.ROOT) == low || (key.isNotEmpty() && k == key)) return n to num
                if (part == null && key.length >= 2 && k.startsWith(key)) part = n to num
            }
        }
        return part
    }

    private fun dial(num: String, name: String?): String {
        if (!granted(Manifest.permission.CALL_PHONE)) {
            return r("Please allow the phone permission in the app.", "ऐप में फोन की अनुमति दे दीजिए।")
        }
        // TelecomManager works from the background and over the lock screen
        c.getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel", num, null), Bundle())
        val who = name ?: num
        return r("Calling $who.", "$who को कॉल कर रहा हूँ।")
    }

    // ---------------------------------------------------------------- messages
    private fun isMessage(t: String, isOpen: Boolean): Boolean {
        if (isOpen) return false
        val wa = has(t, "whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "व्हाट्सअप")
        return has(t, "message", "sms", "मैसेज", "मेसेज", "संदेश", "text ") || (wa && has(t, "send", "भेज", "लिख", "bol"))
    }

    private fun messageFlow(t: String, w: List<String>): Reply {
        val wa = has(t, "whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "व्हाट्सअप")
        val marker = w.indexOfFirst { it in setOf("saying", "says", "that", "कि", "लिखो", "बोलो") }
        val head = if (marker >= 0) w.subList(0, marker) else w
        val body = if (marker >= 0) w.subList(marker + 1, w.size).joinToString(" ") else ""
        val name = head.filter { it !in MSG_STOP }.joinToString(" ")
        if (name.isEmpty()) {
            pending = { x -> messageTo(x.lowercase(Locale.ROOT), body, wa) }
            return rep("Whom should I message?", "किसे मैसेज भेजूँ?", true)
        }
        return messageTo(name, body, wa)
    }

    private fun messageTo(name: String, body: String, wa: Boolean): Reply {
        if (!granted(Manifest.permission.READ_CONTACTS)) {
            return rep("Please allow contacts permission in the app.", "ऐप में कॉन्टैक्ट्स की अनुमति दे दीजिए।")
        }
        val found = findContact(name)
            ?: return rep("I couldn't find $name in your contacts.", "$name कॉन्टैक्ट्स में नहीं मिला।")
        if (body.isEmpty()) {
            pending = { x -> confirmMsg(found, x, wa) }
            return rep("What should I say to ${found.first}?", "${found.first} को क्या भेजूँ?", true)
        }
        return confirmMsg(found, body, wa)
    }

    private fun confirmMsg(found: Pair<String, String>, body: String, wa: Boolean): Reply {
        pending = { x ->
            if (isYes(x)) doSend(found, body, wa) else rep("Okay, not sent.", "ठीक है, नहीं भेजा।")
        }
        return rep(
            "Message to ${found.first}: $body. Should I send it?",
            "${found.first} को मैसेज: $body। भेज दूँ?",
            true
        )
    }

    private fun waNumber(num: String): String {
        var d = num.filter { it.isDigit() }
        if (num.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.substring(2)
        val cc = (c.getSystemService(TelephonyManager::class.java)?.simCountryIso ?: "").lowercase(Locale.ROOT)
        if (cc == "in") {
            if (d.length == 10) d = "91$d" else if (d.startsWith("0")) d = "91" + d.trimStart('0')
        }
        return d
    }

    private fun doSend(found: Pair<String, String>, body: String, wa: Boolean): Reply {
        if (wa) {
            val uri = Uri.parse("https://wa.me/" + waNumber(found.second) + "?text=" + Uri.encode(body))
            try {
                go(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
            } catch (e: Exception) {
                go(Intent(Intent.ACTION_VIEW, uri))
            }
            val acc = ScreenService.instance
            return if (acc != null) {
                Thread {
                    Thread.sleep(3200)
                    acc.clickText("com.whatsapp:id/send", "send", "भेजें")
                }.start()
                rep("Sending on WhatsApp.", "व्हाट्सएप पर भेज रहा हूँ।")
            } else {
                rep("WhatsApp is open. Tap send.", "व्हाट्सएप खुल गया है। भेजें दबाइए।")
            }
        }
        if (!granted(Manifest.permission.SEND_SMS)) {
            return rep("Please allow the SMS permission in the app.", "ऐप में SMS की अनुमति दे दीजिए।")
        }
        val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()
        sm.sendMultipartTextMessage(found.second, null, sm.divideMessage(body), null, null)
        return rep("Message sent to ${found.first}.", "${found.first} को मैसेज भेज दिया।")
    }

    // ---------------------------------------------------------------- open apps
    private fun open(w: List<String>): String {
        var name = w.filter { it !in OPEN_STOP }.joinToString(" ")
        name = ALIAS[name] ?: name
        if (name.isEmpty()) return r("Which app?", "कौन सा ऐप?")
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        fun lbl(ri: ResolveInfo) = ri.loadLabel(pm).toString().lowercase(Locale.ROOT).replace(" ", "")
        val key = name.lowercase(Locale.ROOT).replace(" ", "")
        val sk = skel(name)
        val hit = apps.firstOrNull { lbl(it) == key }
            ?: apps.firstOrNull { key.length >= 3 && lbl(it).contains(key) }
            ?: apps.firstOrNull { sk.length >= 2 && skel(lbl(it)) == sk }
            ?: return r("I couldn't find an app called $name.", "$name नाम का ऐप नहीं मिला।")
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return r("I couldn't open $name.", "$name नहीं खुल पाया।")
        go(intent)
        return r("Opening $name.", "$name खोल रहा हूँ।")
    }
}
