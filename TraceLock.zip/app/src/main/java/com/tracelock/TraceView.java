package com.tracelock;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/** Photo view: 1 finger = move, 2 fingers = zoom + rotate + move. When locked, all touches are ignored. */
public class TraceView extends View {
    boolean locked;
    private Bitmap bmp;
    private final Matrix m = new Matrix();
    private final Paint paint = new Paint();
    private final float[] v = new float[9];
    private boolean needFit;
    private int cnt;
    private float lx, ly, lcx, lcy, ld, la;

    public TraceView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        paint.setFilterBitmap(true);
    }

    boolean hasImage() { return bmp != null; }

    void setImage(Bitmap b, float[] mv) {
        bmp = b;
        cnt = 0;
        if (mv != null && mv.length == 9) {
            m.setValues(mv);
            needFit = false;
            invalidate();
        } else {
            fit();
        }
    }

    void fit() {
        if (bmp == null) return;
        float w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) { needFit = true; return; }
        float s = Math.min(w / bmp.getWidth(), h / bmp.getHeight());
        m.reset();
        m.postScale(s, s);
        m.postTranslate((w - bmp.getWidth() * s) / 2f, (h - bmp.getHeight() * s) / 2f);
        needFit = false;
        invalidate();
    }

    void rotate90() {
        if (bmp == null) return;
        m.postRotate(90, getWidth() / 2f, getHeight() / 2f);
        invalidate();
    }

    void flip() {
        if (bmp == null) return;
        m.postScale(-1, 1, getWidth() / 2f, getHeight() / 2f);
        invalidate();
    }

    String matrixString() {
        m.getValues(v);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 9; i++) {
            if (i > 0) sb.append(',');
            sb.append(v[i]);
        }
        return sb.toString();
    }

    static float[] parse(String s) {
        if (s == null) return null;
        try {
            String[] p = s.split(",");
            if (p.length != 9) return null;
            float[] f = new float[9];
            for (int i = 0; i < 9; i++) f[i] = Float.parseFloat(p[i]);
            return f;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (needFit) fit();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (bmp != null) c.drawBitmap(bmp, m, paint);
    }

    private float scale() {
        m.getValues(v);
        return (float) Math.hypot(v[Matrix.MSCALE_X], v[Matrix.MSKEW_Y]);
    }

    private void track(MotionEvent e, int skip, boolean apply) {
        int c = 0;
        float x0 = 0, y0 = 0, x1 = 0, y1 = 0;
        for (int i = 0; i < e.getPointerCount(); i++) {
            if (i == skip) continue;
            if (c == 0) { x0 = e.getX(i); y0 = e.getY(i); }
            else if (c == 1) { x1 = e.getX(i); y1 = e.getY(i); }
            c++;
        }
        if (c == 0) { cnt = 0; return; }
        if (c == 1) {
            if (apply) m.postTranslate(x0 - lx, y0 - ly);
            lx = x0; ly = y0; cnt = 1;
        } else {
            float cx = (x0 + x1) / 2f, cy = (y0 + y1) / 2f;
            float dx = x1 - x0, dy = y1 - y0;
            float d = (float) Math.hypot(dx, dy);
            float a = (float) Math.toDegrees(Math.atan2(dy, dx));
            if (apply && ld > 1f) {
                m.postTranslate(cx - lcx, cy - lcy);
                float s = d / ld;
                float cur = scale();
                float base = Math.min(getWidth() / (float) bmp.getWidth(), getHeight() / (float) bmp.getHeight());
                float ns = cur * s;
                if (ns < base * 0.1f) s = base * 0.1f / cur;
                else if (ns > base * 25f) s = base * 25f / cur;
                m.postScale(s, s, cx, cy);
                float da = a - la;
                if (da > 180f) da -= 360f; else if (da < -180f) da += 360f;
                m.postRotate(da, cx, cy);
            }
            lcx = cx; lcy = cy; ld = d; la = a; cnt = 2;
        }
        if (apply) invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (locked || bmp == null) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                track(e, -1, false);
                break;
            case MotionEvent.ACTION_POINTER_UP:
                track(e, e.getActionIndex(), false);
                break;
            case MotionEvent.ACTION_MOVE:
                track(e, -1, Math.min(e.getPointerCount(), 2) == cnt);
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                cnt = 0;
                break;
        }
        return true;
    }
}
