package com.tracelock;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int REQ = 11;
    private static final int ACCENT = 0xFF0A84FF;

    private TraceView tv;
    private LinearLayout panel, empty;
    private TextView badge;
    private ImageView sun;
    private SharedPreferences sp;
    private boolean locked, bright = true, hasImg, eatUp;
    private int presses;
    private long lastVol;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("s", MODE_PRIVATE);
        bright = sp.getBoolean("bright", true);

        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams a = w.getAttributes();
            a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(a);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        tv = new TraceView(this);
        root.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        root.addView(buildEmpty());
        root.addView(buildPanel());
        root.addView(buildBadge());
        setContentView(root);

        applyBright();
        refresh();
        if (photoFile().exists()) load(true);
    }

    // ---------- UI ----------

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable bg(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView txt(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private View buildEmpty() {
        empty = new LinearLayout(this);
        empty.setOrientation(LinearLayout.VERTICAL);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(32), 0, dp(32), 0);

        ImageView i = new ImageView(this);
        i.setImageResource(R.drawable.ic_gallery);
        empty.addView(i, new LinearLayout.LayoutParams(dp(64), dp(64)));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(16);
        empty.addView(txt("Diagram ki photo chuno", 20, Color.WHITE, true), lp);

        TextView s = txt("Gallery se photo lo, zoom karke set karo, phir Lock dabao", 14, 0xFF9A9AA2, false);
        s.setGravity(Gravity.CENTER);
        lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(8);
        empty.addView(s, lp);

        TextView btn = txt("Gallery kholo", 16, Color.WHITE, true);
        btn.setBackground(bg(ACCENT, 26));
        btn.setPadding(dp(28), dp(14), dp(28), dp(14));
        btn.setOnClickListener(v -> pick());
        lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(24);
        empty.addView(btn, lp);

        empty.setLayoutParams(new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        return empty;
    }

    private LinearLayout tool(int icon, String label, View.OnClickListener l) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(8), 0, dp(8));
        ImageView iv = new ImageView(this);
        iv.setImageResource(icon);
        t.addView(iv, new LinearLayout.LayoutParams(dp(24), dp(24)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(4);
        t.addView(txt(label, 11, 0xFFB5B5BD, false), lp);
        t.setOnClickListener(l);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        return t;
    }

    private View buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(bg(0xF21C1C1E, 28));
        panel.setPadding(dp(10), dp(6), dp(10), dp(12));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(tool(R.drawable.ic_gallery, "Gallery", v -> pick()));
        row.addView(tool(R.drawable.ic_rotate, "Rotate", v -> tv.rotate90()));
        row.addView(tool(R.drawable.ic_flip, "Flip", v -> tv.flip()));
        row.addView(tool(R.drawable.ic_reset, "Fit", v -> tv.fit()));
        LinearLayout br = tool(R.drawable.ic_sun, "Bright", v -> { bright = !bright; applyBright(); });
        sun = (ImageView) br.getChildAt(0);
        row.addView(br);
        panel.addView(row, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout lock = new LinearLayout(this);
        lock.setOrientation(LinearLayout.HORIZONTAL);
        lock.setGravity(Gravity.CENTER);
        lock.setBackground(bg(ACCENT, 26));
        ImageView li = new ImageView(this);
        li.setImageResource(R.drawable.ic_lock);
        lock.addView(li, new LinearLayout.LayoutParams(dp(20), dp(20)));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = dp(8);
        lock.addView(txt("Lock karo", 16, Color.WHITE, true), tp);
        lock.setOnClickListener(v -> setLocked(true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(6);
        panel.addView(lock, lp);

        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        plp.setMargins(dp(14), 0, dp(14), dp(26));
        panel.setLayoutParams(plp);
        return panel;
    }

    private View buildBadge() {
        badge = txt("", 16, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(28), dp(22), dp(28), dp(22));
        badge.setCompoundDrawablePadding(dp(10));
        badge.setBackground(bg(0xEB1C1C1E, 24));
        badge.setVisibility(View.GONE);
        badge.setLayoutParams(new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        return badge;
    }

    private void flash(int icon, String msg) {
        badge.animate().cancel();
        badge.setText(msg);
        badge.setCompoundDrawablesWithIntrinsicBounds(0, icon, 0, 0);
        badge.setAlpha(1f);
        badge.setVisibility(View.VISIBLE);
        badge.animate().alpha(0f).setStartDelay(1800).setDuration(500)
                .withEndAction(() -> badge.setVisibility(View.GONE)).start();
    }

    private void refresh() {
        empty.setVisibility(hasImg ? View.GONE : View.VISIBLE);
        panel.setVisibility(hasImg && !locked ? View.VISIBLE : View.GONE);
    }

    private void applyBright() {
        WindowManager.LayoutParams a = getWindow().getAttributes();
        a.screenBrightness = bright ? 1f : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        getWindow().setAttributes(a);
        sun.setColorFilter(bright ? 0xFFFFD60A : 0xFFFFFFFF);
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideBars();
    }

    // ---------- lock / unlock ----------

    private void setLocked(boolean l) {
        if (l && !hasImg) return;
        locked = l;
        tv.locked = l;
        presses = 0;
        refresh();
        if (l) flash(R.drawable.ic_lock, "Locked\nUnlock: Volume button 3 baar dabao");
        else flash(R.drawable.ic_unlock, "Unlocked\nAb adjust kar sakte ho");
    }

    private boolean isVol(int k) { return k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN; }

    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        if (locked && isVol(k)) {
            eatUp = true;
            if (e.getRepeatCount() == 0) {
                long now = SystemClock.uptimeMillis();
                if (now - lastVol > 2000) presses = 0;
                lastVol = now;
                if (++presses >= 3) setLocked(false);
            }
            return true;
        }
        return super.onKeyDown(k, e);
    }

    @Override
    public boolean onKeyUp(int k, KeyEvent e) {
        if (isVol(k) && eatUp) {
            eatUp = false;
            return true;
        }
        return super.onKeyUp(k, e);
    }

    @Override
    public void onBackPressed() {
        if (locked) flash(R.drawable.ic_lock, "Locked\nUnlock: Volume button 3 baar dabao");
        else super.onBackPressed();
    }

    // ---------- photo ----------

    private File photoFile() { return new File(getFilesDir(), "photo.bin"); }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(i, "Photo chuno"), REQ);
        } catch (Exception ex) {
            flash(0, "Gallery nahi khuli");
        }
    }

    @Override
    protected void onActivityResult(int rc, int res, Intent d) {
        super.onActivityResult(rc, res, d);
        if (rc != REQ || res != RESULT_OK || d == null || d.getData() == null) return;
        final Uri u = d.getData();
        new Thread(() -> {
            final boolean ok = copy(u);
            runOnUiThread(() -> {
                if (ok) load(false);
                else flash(0, "Photo load nahi hui");
            });
        }).start();
    }

    private boolean copy(Uri u) {
        File tmp = new File(getFilesDir(), "photo.tmp");
        try (InputStream in = getContentResolver().openInputStream(u);
             FileOutputStream out = new FileOutputStream(tmp)) {
            if (in == null) return false;
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (Exception ex) {
            return false;
        }
        return tmp.renameTo(photoFile());
    }

    private void load(final boolean restore) {
        new Thread(() -> {
            final Bitmap bm = decode(photoFile().getPath());
            runOnUiThread(() -> {
                if (bm == null) { flash(0, "Photo khul nahi payi"); return; }
                tv.setImage(bm, restore ? TraceView.parse(sp.getString("m", null)) : null);
                hasImg = true;
                if (restore && sp.getBoolean("locked", false)) { locked = true; tv.locked = true; }
                else { locked = false; tv.locked = false; }
                refresh();
            });
        }).start();
    }

    private static Bitmap decode(String path) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            int max = Math.max(o.outWidth, o.outHeight), s = 1;
            while (max / s > 2400) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            Bitmap b = BitmapFactory.decodeFile(path, o);
            if (b == null) return null;

            int ori = new ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
            Matrix t = new Matrix();
            switch (ori) {
                case 2: t.postScale(-1, 1); break;
                case 3: t.postRotate(180); break;
                case 4: t.postScale(1, -1); break;
                case 5: t.postRotate(90); t.postScale(-1, 1); break;
                case 6: t.postRotate(90); break;
                case 7: t.postRotate(-90); t.postScale(-1, 1); break;
                case 8: t.postRotate(-90); break;
                default: return b;
            }
            Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), t, true);
            if (r != b) b.recycle();
            return r;
        } catch (Throwable e) {
            return null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor e = sp.edit();
        e.putBoolean("bright", bright);
        e.putBoolean("locked", locked && hasImg);
        if (hasImg) e.putString("m", tv.matrixString());
        e.apply();
    }
}
