package com.fastlink.browser;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Built-in music player support. The player is a normal page (assets/flb_player.html) that the browser opens at
 * https://flb.local/player. Nothing goes over the network: the WebView asks the app for
 *   /player        the player page
 *   /api/list      JSON list of the songs on the phone (MediaStore)
 *   /f/ID          the audio file, with HTTP Range support so seeking works
 * Because the page plays through a normal <audio> element, the same volume boost / limiter (up to 500%),
 * background play and notification controls as every other page apply automatically.
 */
public final class MusicHost {

    public static final String HOST = "flb.local";
    public static final String PLAYER_URL = "https://" + HOST + "/player";

    private MusicHost() {
    }

    public static boolean isPlayerUrl(String url) {
        if (url == null) return false;
        return url.startsWith("https://" + HOST + "/") || url.equals("https://" + HOST);
    }

    public static boolean isHost(Uri u) {
        return u != null && HOST.equalsIgnoreCase(u.getHost());
    }

    public static String permName() {
        return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    public static boolean hasPerm(Context c) {
        return c.checkSelfPermission(permName()) == PackageManager.PERMISSION_GRANTED;
    }

    private static Uri collection() {
        if (Build.VERSION.SDK_INT >= 29) return MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        return MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
    }

    private static final Map<Long, String> MIMES = new HashMap<>();

    // ------------------------------------------------------------------ entry point

    /** Returns a response when the request is for flb.local, else null (the browser handles it as usual). */
    public static WebResourceResponse serve(Context c, WebResourceRequest r) {
        Uri u = r.getUrl();
        if (!isHost(u)) return null;
        String path = u.getPath() == null ? "" : u.getPath();
        try {
            if (path.isEmpty() || path.equals("/") || path.equals("/player")) return page(c);
            if (path.equals("/api/list")) return list(c);
            if (path.startsWith("/f/")) return file(c, path.substring(3), r.getRequestHeaders());
        } catch (Throwable t) {
            return plain(500, "Server Error", "error");
        }
        return plain(404, "Not Found", "not found");
    }

    private static Map<String, String> noCache() {
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        return h;
    }

    private static WebResourceResponse plain(int code, String reason, String body) {
        return new WebResourceResponse("text/plain", "utf-8", code, reason, noCache(),
                new ByteArrayInputStream(body.getBytes()));
    }

    private static WebResourceResponse page(Context c) throws IOException {
        InputStream in = c.getAssets().open("flb_player.html");
        return new WebResourceResponse("text/html", "utf-8", 200, "OK", noCache(), in);
    }

    // ------------------------------------------------------------------ song list

    private static WebResourceResponse list(Context c) throws Exception {
        boolean perm = hasPerm(c);
        JSONArray arr = new JSONArray();
        String[] proj;
        if (Build.VERSION.SDK_INT >= 29) {
            proj = new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.MIME_TYPE,
                    MediaStore.Audio.Media.IS_RINGTONE, MediaStore.Audio.Media.IS_NOTIFICATION,
                    MediaStore.Audio.Media.IS_ALARM, MediaStore.MediaColumns.RELATIVE_PATH};
        } else {
            proj = new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.MIME_TYPE,
                    MediaStore.Audio.Media.IS_RINGTONE, MediaStore.Audio.Media.IS_NOTIFICATION,
                    MediaStore.Audio.Media.IS_ALARM, MediaStore.Audio.Media.DATA};
        }
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(collection(), proj, null, null,
                    MediaStore.Audio.Media.DATE_ADDED + " DESC");
            if (cur != null) {
                while (cur.moveToNext() && arr.length() < 8000) {
                    if (cur.getInt(6) == 1 || cur.getInt(7) == 1 || cur.getInt(8) == 1) continue;
                    long id = cur.getLong(0);
                    String name = cur.getString(4);
                    if (name == null) name = "";
                    String title = cur.getString(1);
                    if (title == null || title.trim().isEmpty()) {
                        int dot = name.lastIndexOf('.');
                        title = dot > 0 ? name.substring(0, dot) : name;
                    }
                    String artist = cur.getString(2);
                    if (artist == null || artist.contains("<unknown>")) artist = "";
                    String mime = cur.getString(5);
                    if (mime != null) {
                        synchronized (MIMES) {
                            MIMES.put(id, mime);
                        }
                    }
                    String where = cur.getString(9);
                    if (where == null) where = "";
                    boolean dl = where.contains("Nixu Browse");
                    String folder = folderOf(where);
                    JSONObject o = new JSONObject();
                    o.put("i", id);
                    o.put("t", title);
                    o.put("a", artist);
                    o.put("d", cur.getLong(3));
                    o.put("n", name);
                    o.put("f", folder);
                    o.put("dl", dl ? 1 : 0);
                    arr.put(o);
                }
            }
        } catch (Throwable ignored) {
            // no permission on an old Android: the page shows the "allow" button
        } finally {
            if (cur != null) {
                try {
                    cur.close();
                } catch (Throwable ignored) {
                }
            }
        }
        JSONObject out = new JSONObject();
        out.put("perm", perm);
        out.put("songs", arr);
        return new WebResourceResponse("application/json", "utf-8", 200, "OK", noCache(),
                new ByteArrayInputStream(out.toString().getBytes("UTF-8")));
    }

    /** "Music/Nixu Browse/" or "/storage/emulated/0/Music/x.mp3" -> the last folder name. */
    private static String folderOf(String where) {
        String w = where;
        int q = w.lastIndexOf('/');
        if (q >= 0 && q == w.length() - 1) w = w.substring(0, q);
        else if (q >= 0 && w.indexOf('.', q) > 0) w = w.substring(0, q);   // a file path: drop the file name
        int k = w.lastIndexOf('/');
        return k >= 0 ? w.substring(k + 1) : w;
    }

    // ------------------------------------------------------------------ audio file with Range

    private static String mimeOf(ContentResolver cr, Uri uri, long id) {
        synchronized (MIMES) {
            String m = MIMES.get(id);
            if (m != null) return m;
        }
        String m = null;
        Cursor cur = null;
        try {
            cur = cr.query(uri, new String[]{MediaStore.Audio.Media.MIME_TYPE, MediaStore.Audio.Media.DISPLAY_NAME},
                    null, null, null);
            if (cur != null && cur.moveToFirst()) {
                m = cur.getString(0);
                if (m == null || m.isEmpty()) {
                    String n = cur.getString(1);
                    m = byName(n);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (cur != null) {
                try {
                    cur.close();
                } catch (Throwable ignored) {
                }
            }
        }
        if (m == null || m.isEmpty()) m = "audio/mpeg";
        synchronized (MIMES) {
            MIMES.put(id, m);
        }
        return m;
    }

    private static String byName(String n) {
        if (n == null) return "audio/mpeg";
        String s = n.toLowerCase(Locale.ROOT);
        if (s.endsWith(".m4a") || s.endsWith(".mp4") || s.endsWith(".aac")) return "audio/mp4";
        if (s.endsWith(".ogg") || s.endsWith(".opus")) return "audio/ogg";
        if (s.endsWith(".wav")) return "audio/wav";
        if (s.endsWith(".flac")) return "audio/flac";
        return "audio/mpeg";
    }

    private static WebResourceResponse file(Context c, String idText, Map<String, String> req) {
        long id;
        try {
            int dot = idText.indexOf('.');
            id = Long.parseLong(dot > 0 ? idText.substring(0, dot) : idText);
        } catch (Exception e) {
            return plain(404, "Not Found", "bad id");
        }
        ContentResolver cr = c.getContentResolver();
        Uri uri = ContentUris.withAppendedId(collection(), id);
        ParcelFileDescriptor pfd;
        try {
            pfd = cr.openFileDescriptor(uri, "r");
        } catch (Throwable t) {
            return plain(404, "Not Found", "cannot open");
        }
        if (pfd == null) return plain(404, "Not Found", "cannot open");
        String mime = mimeOf(cr, uri, id);
        long len = pfd.getStatSize();
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Cache-Control", "no-store");
        try {
            if (len <= 0) {          // size unknown: send everything, no ranges
                return new WebResourceResponse(mime, null, 200, "OK", h,
                        new ParcelFileDescriptor.AutoCloseInputStream(pfd));
            }
            String range = null;
            if (req != null) {
                for (Map.Entry<String, String> e : req.entrySet()) {
                    if ("range".equalsIgnoreCase(e.getKey())) range = e.getValue();
                }
            }
            long start = 0, end = len - 1;
            boolean partial = false;
            if (range != null && range.startsWith("bytes=")) {
                String spec = range.substring(6).trim();
                int comma = spec.indexOf(',');
                if (comma > 0) spec = spec.substring(0, comma);
                int dash = spec.indexOf('-');
                if (dash >= 0) {
                    String a = spec.substring(0, dash).trim();
                    String b = spec.substring(dash + 1).trim();
                    try {
                        if (a.isEmpty()) {                               // "-N" = the last N bytes
                            long n = Long.parseLong(b);
                            start = Math.max(0, len - n);
                        } else {
                            start = Long.parseLong(a);
                            if (!b.isEmpty()) end = Math.min(len - 1, Long.parseLong(b));
                        }
                        partial = true;
                    } catch (NumberFormatException ignored) {
                        start = 0;
                        end = len - 1;
                    }
                }
            }
            if (start >= len || start > end) {
                try {
                    pfd.close();
                } catch (IOException ignored) {
                }
                h.put("Content-Range", "bytes */" + len);
                return new WebResourceResponse(mime, null, 416, "Range Not Satisfiable", h,
                        new ByteArrayInputStream(new byte[0]));
            }
            long count = end - start + 1;
            h.put("Content-Length", String.valueOf(count));
            InputStream in = new RangeStream(pfd, start, count);
            if (partial) {
                h.put("Content-Range", "bytes " + start + "-" + end + "/" + len);
                return new WebResourceResponse(mime, null, 206, "Partial Content", h, in);
            }
            return new WebResourceResponse(mime, null, 200, "OK", h, in);
        } catch (Throwable t) {
            try {
                pfd.close();
            } catch (IOException ignored) {
            }
            return plain(500, "Server Error", "read error");
        }
    }

    /** Reads `count` bytes starting at `start` from the file; closing it closes the descriptor. */
    private static final class RangeStream extends InputStream {
        private final FileInputStream in;
        private long left;

        RangeStream(ParcelFileDescriptor pfd, long start, long count) throws IOException {
            in = new ParcelFileDescriptor.AutoCloseInputStream(pfd);
            left = count;
            if (start > 0) in.getChannel().position(start);
        }

        @Override
        public int read() throws IOException {
            byte[] one = new byte[1];
            int n = read(one, 0, 1);
            return n < 0 ? -1 : (one[0] & 0xff);
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = in.read(b, off, (int) Math.min((long) len, left));
            if (n > 0) left -= n;
            return n;
        }

        @Override
        public int available() {
            return (int) Math.min(left, 65536L);
        }

        @Override
        public void close() throws IOException {
            in.close();
        }
    }
}
