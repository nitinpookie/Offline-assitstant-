package com.spudlab.tater

import android.graphics.Bitmap

/**
 * Re-encode path for textures without mip levels.
 * GPU decode → improved area downsample → ETC2 write + verify.
 */
object Reencode {
    /** data == null means "not converted", why says why, thumb is a small picture of the original (when it could be decoded). */
    class Out(val tf: Int, val k: Int, val data: ByteArray?, val why: String, val thumb: Bitmap?, val after: Bitmap? = null)

    fun canConvert(tf: Int): Boolean = Preview.gpuKnows(tf)

    fun convert(tf: Int, w: Int, h: Int, src: ByteArray, k0: Int, maxBytes: Int, minSide: Int, fx: ColorFx? = null): Out {
        val rgba = Preview.gpuRaw(w, h, tf, src)
            ?: return Out(tf, 0, null, "this phone cannot decode ${Preview.fmtName(tf)} at ${w}x$h", null)
        var hasA = false
        var i = 3
        while (i < rgba.size) {
            if ((rgba[i].toInt() and 255) != 255) { hasA = true; break }
            i += 4
        }
        val newTf = if (hasA) 47 else 45
        val bpb = if (hasA) 16 else 8
        var k = k0
        while (true) {
            val nw = maxOf(1, w shr k); val nh = maxOf(1, h shr k)
            if (k > 12 || maxOf(nw, nh) < minSide) return Out(tf, 0, null, "too small to shrink further inside the original size", thumb(rgba, w, h))
            if (((nw + 3) / 4) * ((nh + 3) / 4) * bpb <= maxBytes) break
            k++
        }
        val nw = maxOf(1, w shr k); val nh = maxOf(1, h shr k)
        val small = boxRgba(rgba, w, h, k)
        if (fx != null) fx.applyRgba(small)
        val data = if (hasA) encodeRgba8(small, nw, nh) else encodeRgb(small, nw, nh)
        val back = Preview.gpuRaw(nw, nh, newTf, data)
            ?: return Out(tf, 0, null, "the phone could not read back the new texture, original kept", thumb(rgba, w, h))
        if (!matches(small, back, nw, nh, hasA)) return Out(tf, 0, null, "re-encode check failed, original kept", thumb(rgba, w, h))
        return Out(newTf, k, data, "", thumb(rgba, w, h), thumb(small, nw, nh))
    }

    /** A texture written as ETC2 with a full mip chain (used by the colour filter). */
    class Chain(val tf: Int, val mips: Int, val data: ByteArray)

    /** RGBA data (rows in Unity order, bottom row first) written as ETC2 RGB, with or without the mip chain. Used by Gloo Vault. */
    fun encodeChain(rgba: ByteArray, w: Int, h: Int, mips: Boolean): Chain {
        val out = java.io.ByteArrayOutputStream()
        var cw = w; var chh = h
        var cur = rgba
        var n = 0
        while (true) {
            val enc = encodeRgb(cur, cw, chh)
            out.write(enc, 0, enc.size)
            n++
            if (!mips || (cw == 1 && chh == 1)) break
            cur = boxRgba(cur, cw, chh, 1)
            cw = maxOf(1, cw shr 1); chh = maxOf(1, chh shr 1)
        }
        return Chain(45, n, out.toByteArray())
    }

    /** Decodes one image (compressed format tf, w x h), changes its colours and writes it as ETC2 with a mip chain. null = not possible (kept as it was). */
    fun recolour(tf: Int, w: Int, h: Int, src: ByteArray, fx: ColorFx, maxBytes: Int): Chain? {
        val rgba = Preview.gpuRaw(w, h, tf, src) ?: return null
        var hasA = false
        var i = 3
        while (i < rgba.size) {
            if ((rgba[i].toInt() and 255) != 255) { hasA = true; break }
            i += 4
        }
        val want = rgba.copyOf()
        fx.applyRgba(want)
        val newTf = if (hasA) 47 else 45
        val out = java.io.ByteArrayOutputStream()
        var cw = w; var chh = h
        var cur = want
        var n = 0
        var first: ByteArray? = null
        while (true) {
            val enc = if (hasA) encodeRgba8(cur, cw, chh) else encodeRgb(cur, cw, chh)
            if (first == null) first = enc
            out.write(enc, 0, enc.size)
            n++
            if (out.size() > maxBytes) return null
            if (cw == 1 && chh == 1) break
            cur = boxRgba(cur, cw, chh, 1)
            cw = maxOf(1, cw shr 1); chh = maxOf(1, chh shr 1)
        }
        val f0 = first ?: return null
        val back = Preview.gpuRaw(w, h, newTf, f0) ?: return null
        if (!matches(want, back, w, h, hasA)) return null
        return Chain(newTf, n, out.toByteArray())
    }

    /** The GPU-decoded new texture must be clearly closer to the wanted picture than "one flat colour per 4x4 block" is. */
    private fun matches(want: ByteArray, got: ByteArray, w: Int, h: Int, alpha: Boolean): Boolean {
        if (got.size != want.size) return false
        val nc = if (alpha) 4 else 3
        var eEnc = 0L
        var eFlat = 0L
        for (by in 0 until (h + 3) / 4) for (bx in 0 until (w + 3) / 4) {
            val x0 = bx * 4; val y0 = by * 4
            val x1 = minOf(w, x0 + 4); val y1 = minOf(h, y0 + 4)
            val n = (x1 - x0) * (y1 - y0)
            for (c in 0 until nc) {
                var sum = 0
                for (y in y0 until y1) for (x in x0 until x1) sum += want[(y * w + x) * 4 + c].toInt() and 255
                val avg = (sum + n / 2) / n
                for (y in y0 until y1) for (x in x0 until x1) {
                    val j = (y * w + x) * 4 + c
                    val wv = want[j].toInt() and 255
                    eFlat += Math.abs(wv - avg)
                    eEnc += Math.abs(wv - (got[j].toInt() and 255))
                }
            }
        }
        val total = w.toLong() * h * nc
        return eEnc * 10 <= eFlat * 9 + total * 40
    }

    /**
     * Area downsample with mild center bias.
     * Same aggressive size reduction, but less pure blocky look than classic box filter.
     * Keeps the potato level the user wants while looking a bit more natural.
     */
    fun boxRgba(src: ByteArray, w: Int, h: Int, k: Int): ByteArray {
        val nw = maxOf(1, w shr k); val nh = maxOf(1, h shr k); val s = 1 shl k
        val out = ByteArray(nw * nh * 4)
        val half = s / 2
        for (y in 0 until nh) for (x in 0 until nw) {
            var r = 0; var g = 0; var b = 0; var a = 0; var n = 0
            for (dy in 0 until s) {
                val sy = minOf(h - 1, y * s + dy)
                for (dx in 0 until s) {
                    val sx = minOf(w - 1, x * s + dx)
                    val i = (sy * w + sx) * 4
                    var rv = src[i].toInt() and 255
                    var gv = src[i + 1].toInt() and 255
                    var bv = src[i + 2].toInt() and 255
                    var av = src[i + 3].toInt() and 255
                    if (kotlin.math.abs(dx - half) <= 1 && kotlin.math.abs(dy - half) <= 1) {
                        rv = (rv * 5) / 4; gv = (gv * 5) / 4; bv = (bv * 5) / 4
                    }
                    r += rv; g += gv; b += bv; a += av; n++
                }
            }
            val o = (y * nw + x) * 4
            out[o] = ((r + n / 2) / n).coerceIn(0, 255).toByte()
            out[o + 1] = ((g + n / 2) / n).coerceIn(0, 255).toByte()
            out[o + 2] = ((b + n / 2) / n).coerceIn(0, 255).toByte()
            out[o + 3] = ((a + n / 2) / n).coerceIn(0, 255).toByte()
        }
        return out
    }

    /** Small picture (max 256 px) of RGBA data whose rows are in Unity order (bottom row first). */
    fun thumb(rgba: ByteArray, w: Int, h: Int): Bitmap {
        val step = maxOf(1, (maxOf(w, h) + 255) / 256)
        val tw = maxOf(1, w / step); val th = maxOf(1, h / step)
        val px = IntArray(tw * th)
        for (y in 0 until th) for (x in 0 until tw) {
            val i = ((y * step) * w + x * step) * 4
            px[(th - 1 - y) * tw + x] = (255 shl 24) or ((rgba[i].toInt() and 255) shl 16) or
                ((rgba[i + 1].toInt() and 255) shl 8) or (rgba[i + 2].toInt() and 255)
        }
        return Bitmap.createBitmap(px, tw, th, Bitmap.Config.ARGB_8888)
    }

    // ---------------------------------------------------------------- ETC2 writer

    private val ETC_A = intArrayOf(2, 5, 9, 13, 18, 24, 33, 47)
    private val ETC_B = intArrayOf(8, 17, 29, 42, 60, 80, 106, 183)

    private val EAC = arrayOf(
        intArrayOf(-3, -6, -9, -15, 2, 5, 8, 14),
        intArrayOf(-3, -7, -10, -13, 2, 6, 9, 12),
        intArrayOf(-2, -5, -8, -13, 1, 4, 7, 12),
        intArrayOf(-2, -4, -6, -13, 1, 3, 5, 12),
        intArrayOf(-3, -6, -8, -12, 2, 5, 7, 11),
        intArrayOf(-3, -7, -9, -11, 2, 6, 8, 10),
        intArrayOf(-4, -7, -8, -11, 3, 6, 7, 10),
        intArrayOf(-3, -5, -8, -11, 2, 4, 7, 10),
        intArrayOf(-2, -6, -8, -10, 1, 5, 7, 9),
        intArrayOf(-2, -5, -8, -10, 1, 4, 7, 9),
        intArrayOf(-2, -4, -8, -10, 1, 3, 7, 9),
        intArrayOf(-2, -5, -7, -10, 1, 4, 6, 9),
        intArrayOf(-2, -4, -7, -10, 1, 3, 6, 9),
        intArrayOf(-1, -2, -3, -10, 0, 1, 2, 9),
        intArrayOf(-4, -6, -8, -9, 3, 5, 7, 8),
        intArrayOf(-3, -5, -7, -9, 2, 4, 6, 8))
    /** Tables the writer may use (11 and 12 are left out on purpose). Table 13 has a zero modifier at index 4. */
    private val EAC_USE = intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 13, 14, 15)
    private val EAC_MIN = IntArray(16) { t -> var m = 999; for (v in EAC[t]) if (v < m) m = v; m }
    private val EAC_MAX = IntArray(16) { t -> var m = -999; for (v in EAC[t]) if (v > m) m = v; m }

    private fun c8(v: Int): Int = if (v < 0) 0 else if (v > 255) 255 else v
    private fun ex5(q: Int): Int = (q shl 3) or (q shr 2)
    private fun ex4(q: Int): Int = (q shl 4) or q

    private fun mod(t: Int, j: Int): Int = when (j) {
        0 -> ETC_A[t]
        1 -> ETC_B[t]
        2 -> -ETC_A[t]
        else -> -ETC_B[t]
    }

    /** Pixel (index y*4+x) number i (0..7) of sub-block sb for the given flip (0 = left/right halves, 1 = top/bottom halves). */
    private fun subPixel(flip: Int, sb: Int, i: Int): Int =
        if (flip == 0) (i shr 1) * 4 + sb * 2 + (i and 1) else (sb * 2 + (i shr 2)) * 4 + (i and 3)

    private fun fillBlock(px: ByteArray, w: Int, h: Int, bx: Int, by: Int, blk: IntArray) {
        for (y in 0 until 4) {
            val sy = minOf(h - 1, by * 4 + y)
            for (x in 0 until 4) {
                val sx = minOf(w - 1, bx * 4 + x)
                val i = (sy * w + sx) * 4
                val o = (y * 4 + x) * 4
                blk[o] = px[i].toInt() and 255; blk[o + 1] = px[i + 1].toInt() and 255
                blk[o + 2] = px[i + 2].toInt() and 255; blk[o + 3] = px[i + 3].toInt() and 255
            }
        }
    }

    private fun encodeRgb(px: ByteArray, w: Int, h: Int): ByteArray {
        val bw = (w + 3) / 4; val bh = (h + 3) / 4
        val out = ByteArray(bw * bh * 8)
        val blk = IntArray(64)
        val s = Etc()
        for (by in 0 until bh) for (bx in 0 until bw) {
            fillBlock(px, w, h, bx, by, blk)
            etcColorBlock(blk, out, (by * bw + bx) * 8, s)
        }
        return out
    }

    private fun encodeRgba8(px: ByteArray, w: Int, h: Int): ByteArray {
        val bw = (w + 3) / 4; val bh = (h + 3) / 4
        val out = ByteArray(bw * bh * 16)
        val blk = IntArray(64)
        val s = Etc()
        val sel = IntArray(16)
        val trial = IntArray(16)
        for (by in 0 until bh) for (bx in 0 until bw) {
            fillBlock(px, w, h, bx, by, blk)
            val o = (by * bw + bx) * 16
            eacBlock(blk, out, o, sel, trial)
            etcColorBlock(blk, out, o + 8, s)
        }
        return out
    }

    private class Etc {
        val trial = IntArray(16)
        val flipSel = IntArray(16)
        val bestSel = IntArray(16)
        val q = IntArray(6)
        val bestQ = IntArray(6)
        val avg = IntArray(6)
        val base = IntArray(6)
    }

    /** One ETC1-style block (also valid ETC2): two sub-blocks, flat base colour each, intensity table + 2 bit selectors per pixel. */
    private fun etcColorBlock(blk: IntArray, out: ByteArray, off: Int, s: Etc) {
        var same = true
        for (p in 1 until 16) {
            val o = p * 4
            if (blk[o] != blk[0] || blk[o + 1] != blk[1] || blk[o + 2] != blk[2]) { same = false; break }
        }
        var bestErr = Long.MAX_VALUE
        var bestFlip = 0; var bestDiff = false; var bestT0 = 0; var bestT1 = 0
        val lastFlip = if (same) 0 else 1
        for (flip in 0..lastFlip) {
            for (sb in 0..1) {
                var r = 0; var g = 0; var b = 0
                for (i in 0 until 8) {
                    val p = subPixel(flip, sb, i)
                    r += blk[p * 4]; g += blk[p * 4 + 1]; b += blk[p * 4 + 2]
                }
                s.avg[sb * 3] = (r + 4) / 8; s.avg[sb * 3 + 1] = (g + 4) / 8; s.avg[sb * 3 + 2] = (b + 4) / 8
            }
            var diff = true
            for (c in 0 until 3) {
                val qa = (s.avg[c] * 31 + 127) / 255
                val qb = (s.avg[3 + c] * 31 + 127) / 255
                val d = qb - qa
                if (d < -4 || d > 3) diff = false
                s.q[c] = qa; s.q[3 + c] = qb
            }
            if (diff) {
                for (c in 0 until 6) s.base[c] = ex5(s.q[c])
            } else {
                for (c in 0 until 6) { s.q[c] = (s.avg[c] * 15 + 127) / 255; s.base[c] = ex4(s.q[c]) }
            }
            var total = 0L
            val tb = IntArray(2)
            for (sb in 0..1) {
                var bestSb = Long.MAX_VALUE
                for (t in 0 until 8) {
                    var e = 0L
                    for (i in 0 until 8) {
                        val p = subPixel(flip, sb, i)
                        val pr = blk[p * 4]; val pg = blk[p * 4 + 1]; val pb = blk[p * 4 + 2]
                        var m = Int.MAX_VALUE
                        var mj = 0
                        for (j in 0 until 4) {
                            val md = mod(t, j)
                            val dr = c8(s.base[sb * 3] + md) - pr
                            val dg = c8(s.base[sb * 3 + 1] + md) - pg
                            val db = c8(s.base[sb * 3 + 2] + md) - pb
                            val er = dr * dr + dg * dg + db * db
                            if (er < m) { m = er; mj = j }
                        }
                        e += m
                        s.trial[p] = mj
                    }
                    if (e < bestSb) {
                        bestSb = e; tb[sb] = t
                        for (i in 0 until 8) { val p = subPixel(flip, sb, i); s.flipSel[p] = s.trial[p] }
                    }
                }
                total += bestSb
            }
            if (total < bestErr) {
                bestErr = total; bestFlip = flip; bestDiff = diff; bestT0 = tb[0]; bestT1 = tb[1]
                for (c in 0 until 6) s.bestQ[c] = s.q[c]
                for (p in 0 until 16) s.bestSel[p] = s.flipSel[p]
            }
        }
        val q = s.bestQ
        val b0: Int; val b1: Int; val b2: Int
        if (bestDiff) {
            b0 = (q[0] shl 3) or ((q[3] - q[0]) and 7)
            b1 = (q[1] shl 3) or ((q[4] - q[1]) and 7)
            b2 = (q[2] shl 3) or ((q[5] - q[2]) and 7)
        } else {
            b0 = (q[0] shl 4) or q[3]
            b1 = (q[1] shl 4) or q[4]
            b2 = (q[2] shl 4) or q[5]
        }
        val b3 = (bestT0 shl 5) or (bestT1 shl 2) or ((if (bestDiff) 1 else 0) shl 1) or bestFlip
        var msb = 0; var lsb = 0
        for (y in 0 until 4) for (x in 0 until 4) {
            val v = s.bestSel[y * 4 + x]
            val p = x * 4 + y
            msb = msb or ((v shr 1) shl p)
            lsb = lsb or ((v and 1) shl p)
        }
        out[off] = b0.toByte(); out[off + 1] = b1.toByte(); out[off + 2] = b2.toByte(); out[off + 3] = b3.toByte()
        out[off + 4] = ((msb shr 8) and 255).toByte(); out[off + 5] = (msb and 255).toByte()
        out[off + 6] = ((lsb shr 8) and 255).toByte(); out[off + 7] = (lsb and 255).toByte()
    }

    /** EAC alpha block (8 bytes): base value, multiplier, table, 16 x 3 bit selectors. */
    private fun eacBlock(blk: IntArray, out: ByteArray, off: Int, sel: IntArray, trial: IntArray) {
        var mn = 255; var mx = 0
        for (p in 0 until 16) { val a = blk[p * 4 + 3]; if (a < mn) mn = a; if (a > mx) mx = a }
        var bBase = mn; var bMul = 1; var bTab = 13
        if (mn == mx) {
            for (p in 0 until 16) sel[p] = 4          // table 13, index 4 = modifier 0
        } else {
            var bestE = Int.MAX_VALUE
            val center = (mn + mx + 1) / 2
            val range = mx - mn
            for (t in EAC_USE) {
                val tab = EAC[t]
                val spread = EAC_MAX[t] - EAC_MIN[t]
                val m0 = (range + spread / 2) / spread
                val lo = minOf(15, maxOf(1, m0 - 1))
                val hi = minOf(15, maxOf(lo, m0 + 1))
                for (mul in lo..hi) {
                    val base = c8(center - ((EAC_MIN[t] + EAC_MAX[t]) * mul) / 2)
                    var e = 0
                    for (p in 0 until 16) {
                        val a = blk[p * 4 + 3]
                        var m = Int.MAX_VALUE
                        var mj = 0
                        for (j in 0 until 8) {
                            val d = Math.abs(c8(base + tab[j] * mul) - a)
                            if (d < m) { m = d; mj = j }
                        }
                        e += m * m
                        trial[p] = mj
                    }
                    if (e < bestE) {
                        bestE = e; bBase = base; bMul = mul; bTab = t
                        for (p in 0 until 16) sel[p] = trial[p]
                    }
                }
            }
        }
        out[off] = bBase.toByte()
        out[off + 1] = ((bMul shl 4) or bTab).toByte()
        var bits = 0L
        for (y in 0 until 4) for (x in 0 until 4) {
            val p = x * 4 + y
            bits = bits or ((sel[y * 4 + x].toLong() and 7L) shl (45 - 3 * p))
        }
        for (i in 0 until 6) out[off + 2 + i] = ((bits shr (40 - 8 * i)) and 255L).toByte()
    }
}
