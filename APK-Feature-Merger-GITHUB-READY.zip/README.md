# Feature Merger

Android app that reads APKs on the phone and

* lists every **overlay feature** inside them (floating menus, switches, sliders) with a traffic light:
  green = should work the same after the move, amber = check first, red = probably will not work
* lists everything the developer **switched off** (controls hidden with `visibility=gone/invisible`, disabled
  controls, disabled services/activities/receivers) and lets you **activate** it
* moves chosen features from one APK into another (the **base app**) and, if the base app has a switch menu,
  **adds a matching switch row** to that menu by cloning its last row, so it looks like every other option
* can turn off whole base-app features or hide single controls
* signs the result (v1 + v2) with a key generated on first use and offers Install / Share

Everything runs on the phone, pure Java (no native code, fine on armv7a), no internet needed.

## Build on GitHub

1. Create a repo and upload all files of this zip to the repo root (keep the `.github` folder).
2. Open the **Actions** tab, run **Build APK** (it also runs on every push).
3. Download the `FeatureMerger-APK` artifact: `app-debug.apk`.

## Use

1. **Apps** tab: Add APK (one or more). Tap **Details** to see features, risk colours and switched-off items.
2. **Merge** tab: pick the base app, tick what to activate / turn off / bring in, press **Build merged APK**.
3. Uninstall the original base app, then Install the merged APK (it is signed with your own key).

## How a moved feature works

The source APK is embedded unchanged in the base APK. A small bridge (extracted from this app's own dex)
loads it with its own code and resources, so the feature behaves like in the original app. A manifest
provider boots the bridge, shim services host the feature's overlay Service, and the cloned menu switch
(found at runtime through its `android:tag`) starts/stops it.

## Known limits

* Features that drive their own app's VPN engine are marked red; the engine cannot be moved.
* Overlays built inside an Activity (not a Service) are listed but cannot be moved yet.
* Only hidden/disabled items that exist in layouts or the manifest are found; flags inside code are not.
* Menus built entirely in code (no layout XML) cannot get a cloned switch; the feature then starts automatically.
