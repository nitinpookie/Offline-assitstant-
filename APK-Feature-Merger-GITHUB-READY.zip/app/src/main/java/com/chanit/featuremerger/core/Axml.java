package com.chanit.featuremerger.core;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal Android binary XML (AXML) model: parse -> edit -> build.
 * Used for AndroidManifest.xml and compiled layout files.
 */
public final class Axml {
    public static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";
    public static final int T_REF = 0x01, T_STRING = 0x03, T_DEC = 0x10, T_HEX = 0x11, T_BOOL = 0x12;

    public static final class Attr {
        public String ns, name, raw, str;
        public int resId, type, data;

        public String text() {
            switch (type) {
                case T_STRING: return str;
                case T_BOOL: return data != 0 ? "true" : "false";
                case T_REF: return "@0x" + Integer.toHexString(data);
                case T_DEC: return String.valueOf(data);
                case T_HEX: return "0x" + Integer.toHexString(data);
                default: return raw != null ? raw : String.valueOf(data);
            }
        }

        boolean same(Attr o) {
            return (ns == null ? o.ns == null : ns.equals(o.ns)) && name.equals(o.name);
        }
    }

    public static final class Elem {
        public String ns, name;
        public int line = 1;
        public final List<Attr> attrs = new ArrayList<>();
        public final List<Elem> kids = new ArrayList<>();

        public Elem(String name) { this.name = name; }

        public Attr attr(String androidName) {
            for (Attr a : attrs) if (ANDROID_NS.equals(a.ns) && androidName.equals(a.name)) return a;
            return null;
        }

        public Attr plain(String n) {
            for (Attr a : attrs) if (a.ns == null && n.equals(a.name)) return a;
            return null;
        }

        public String text(String androidName) {
            Attr a = attr(androidName);
            return a == null ? null : a.text();
        }

        /** Adds or replaces an attribute, keeping attributes sorted by resource id as aapt2 does. */
        public void put(Attr n) {
            for (int i = 0; i < attrs.size(); i++) {
                if (attrs.get(i).same(n)) {
                    attrs.set(i, n);
                    return;
                }
            }
            if (n.resId == 0) {
                attrs.add(n);
                return;
            }
            int pos = attrs.size();
            for (int i = 0; i < attrs.size(); i++) {
                Attr a = attrs.get(i);
                if (a.resId == 0 || cmpU(a.resId, n.resId) > 0) {
                    pos = i;
                    break;
                }
            }
            attrs.add(pos, n);
        }

        public Elem child(String tag) {
            for (Elem k : kids) if (tag.equals(k.name)) return k;
            return null;
        }

        public void remove(String androidName) {
            for (int i = attrs.size() - 1; i >= 0; i--) {
                Attr a = attrs.get(i);
                if (ANDROID_NS.equals(a.ns) && androidName.equals(a.name)) attrs.remove(i);
            }
        }

        public Elem copy() {
            Elem c = new Elem(name);
            c.ns = ns;
            c.line = line;
            for (Attr a : attrs) {
                Attr b = new Attr();
                b.ns = a.ns; b.name = a.name; b.raw = a.raw; b.str = a.str;
                b.resId = a.resId; b.type = a.type; b.data = a.data;
                c.attrs.add(b);
            }
            for (Elem k : kids) c.kids.add(k.copy());
            return c;
        }

        public void walk(Visitor v) {
            v.visit(this);
            for (Elem k : kids) k.walk(v);
        }
    }

    public interface Visitor {
        void visit(Elem e);
    }

    /** Finds the parent of target inside the tree rooted at e (null if none). */
    public static Elem parentOf(Elem e, Elem target) {
        for (Elem k : e.kids) {
            if (k == target) return e;
            Elem r = parentOf(k, target);
            if (r != null) return r;
        }
        return null;
    }

    static int cmpU(int a, int b) { return Long.compare(a & 0xffffffffL, b & 0xffffffffL); }

    public Elem root;
    public final List<String[]> namespaces = new ArrayList<>(); // {prefix, uri}

    // ---------- factories ----------
    public static Attr str(String name, int resId, String v) {
        Attr a = new Attr();
        a.ns = ANDROID_NS; a.name = name; a.resId = resId; a.type = T_STRING; a.str = v; a.raw = v;
        return a;
    }

    public static Attr bool(String name, int resId, boolean v) {
        Attr a = new Attr();
        a.ns = ANDROID_NS; a.name = name; a.resId = resId; a.type = T_BOOL; a.data = v ? -1 : 0;
        return a;
    }

    public static Attr hex(String name, int resId, int v) {
        Attr a = new Attr();
        a.ns = ANDROID_NS; a.name = name; a.resId = resId; a.type = T_HEX; a.data = v;
        return a;
    }

    // ---------- parse ----------
    public static Axml parse(byte[] buf) {
        ByteBuffer b = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
        if (Pool.u16(buf, 0) != 0x0003) throw new IllegalArgumentException("not a binary XML file");
        int fileSize = Math.min(b.getInt(4), buf.length);
        String[] pool = new String[0];
        int[] resMap = new int[0];
        Axml x = new Axml();
        Deque<Elem> stack = new ArrayDeque<>();
        int p = 8;
        while (p + 8 <= fileSize) {
            int type = Pool.u16(buf, p);
            int size = b.getInt(p + 4);
            if (size < 8) break;
            switch (type) {
                case 0x0001:
                    pool = Pool.read(buf, p).strings;
                    break;
                case 0x0180: {
                    int n = (size - 8) / 4;
                    resMap = new int[n];
                    for (int i = 0; i < n; i++) resMap[i] = b.getInt(p + 8 + 4 * i);
                    break;
                }
                case 0x0100:
                    x.namespaces.add(new String[]{s(pool, b.getInt(p + 16)), s(pool, b.getInt(p + 20))});
                    break;
                case 0x0102: {
                    Elem e = new Elem(s(pool, b.getInt(p + 20)));
                    e.ns = s(pool, b.getInt(p + 16));
                    e.line = b.getInt(p + 8);
                    int attrStart = Pool.u16(buf, p + 24);
                    int attrSize = Pool.u16(buf, p + 26);
                    int attrCount = Pool.u16(buf, p + 28);
                    int ap = p + 16 + attrStart;
                    for (int i = 0; i < attrCount; i++) {
                        int a = ap + i * attrSize;
                        Attr at = new Attr();
                        at.ns = s(pool, b.getInt(a));
                        int nameIdx = b.getInt(a + 4);
                        at.name = s(pool, nameIdx);
                        at.resId = (nameIdx >= 0 && nameIdx < resMap.length) ? resMap[nameIdx] : 0;
                        at.raw = s(pool, b.getInt(a + 8));
                        at.type = buf[a + 15] & 0xff;
                        at.data = b.getInt(a + 16);
                        if (at.type == T_STRING) at.str = s(pool, at.data);
                        e.attrs.add(at);
                    }
                    if (stack.isEmpty()) {
                        if (x.root == null) x.root = e;
                    } else {
                        stack.peek().kids.add(e);
                    }
                    stack.push(e);
                    break;
                }
                case 0x0103:
                    if (!stack.isEmpty()) stack.pop();
                    break;
                default:
                    break;
            }
            p += size;
        }
        if (x.root == null) throw new IllegalArgumentException("empty binary XML");
        return x;
    }

    private static String s(String[] pool, int i) {
        return (i >= 0 && i < pool.length) ? pool[i] : null;
    }

    // ---------- build ----------
    public byte[] build() {
        Map<String, Integer> resOf = new LinkedHashMap<>();
        collectRes(root, resOf);
        final Map<String, Integer> resRef = resOf;
        List<String> resNames = new ArrayList<>(resOf.keySet());
        Collections.sort(resNames, (a, c) -> cmpU(resRef.get(a), resRef.get(c)));

        List<String> pool = new ArrayList<>(resNames);
        Map<String, Integer> idx = new HashMap<>();
        for (int i = 0; i < pool.size(); i++) idx.put(pool.get(i), i);
        for (String[] n : namespaces) { add(pool, idx, n[0]); add(pool, idx, n[1]); }
        collectStrings(root, pool, idx);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] poolChunk = Pool.write(pool);
        out.write(poolChunk, 0, poolChunk.length);

        ByteBuffer rm = ByteBuffer.allocate(8 + 4 * resNames.size()).order(ByteOrder.LITTLE_ENDIAN);
        rm.putShort((short) 0x0180).putShort((short) 8).putInt(8 + 4 * resNames.size());
        for (String n : resNames) rm.putInt(resOf.get(n));
        out.write(rm.array(), 0, rm.capacity());

        for (String[] n : namespaces) writeNs(out, 0x0100, idx.get(n[0]), idx.get(n[1]));
        writeElem(out, root, idx);
        for (int i = namespaces.size() - 1; i >= 0; i--) {
            String[] n = namespaces.get(i);
            writeNs(out, 0x0101, idx.get(n[0]), idx.get(n[1]));
        }
        byte[] body = out.toByteArray();
        ByteBuffer all = ByteBuffer.allocate(8 + body.length).order(ByteOrder.LITTLE_ENDIAN);
        all.putShort((short) 0x0003).putShort((short) 8).putInt(8 + body.length).put(body);
        return all.array();
    }

    private static void collectRes(Elem e, Map<String, Integer> m) {
        for (Attr a : e.attrs) if (a.resId != 0 && !m.containsKey(a.name)) m.put(a.name, a.resId);
        for (Elem k : e.kids) collectRes(k, m);
    }

    private static void add(List<String> pool, Map<String, Integer> idx, String s) {
        if (s == null || idx.containsKey(s)) return;
        idx.put(s, pool.size());
        pool.add(s);
    }

    private static void collectStrings(Elem e, List<String> pool, Map<String, Integer> idx) {
        add(pool, idx, e.ns);
        add(pool, idx, e.name);
        for (Attr a : e.attrs) {
            add(pool, idx, a.ns);
            add(pool, idx, a.name);
            if (a.type == T_STRING) add(pool, idx, a.str);
            else add(pool, idx, a.raw);
        }
        for (Elem k : e.kids) collectStrings(k, pool, idx);
    }

    private static int ix(Map<String, Integer> idx, String s) {
        return s == null ? -1 : idx.get(s);
    }

    private static void writeNs(ByteArrayOutputStream o, int type, int prefix, int uri) {
        ByteBuffer b = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        b.putShort((short) type).putShort((short) 16).putInt(24).putInt(1).putInt(-1).putInt(prefix).putInt(uri);
        o.write(b.array(), 0, 24);
    }

    private static void writeElem(ByteArrayOutputStream o, Elem e, Map<String, Integer> idx) {
        int n = e.attrs.size();
        int idI = 0, clsI = 0, styI = 0;
        for (int i = 0; i < n; i++) {
            Attr a = e.attrs.get(i);
            if (a.ns == null) {
                if ("id".equals(a.name)) idI = i + 1;
                else if ("class".equals(a.name)) clsI = i + 1;
                else if ("style".equals(a.name)) styI = i + 1;
            }
        }
        int size = 36 + 20 * n;
        ByteBuffer b = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        b.putShort((short) 0x0102).putShort((short) 16).putInt(size).putInt(e.line <= 0 ? 1 : e.line).putInt(-1);
        b.putInt(ix(idx, e.ns)).putInt(ix(idx, e.name));
        b.putShort((short) 20).putShort((short) 20).putShort((short) n);
        b.putShort((short) idI).putShort((short) clsI).putShort((short) styI);
        for (Attr a : e.attrs) {
            b.putInt(ix(idx, a.ns)).putInt(ix(idx, a.name));
            if (a.type == T_STRING) {
                int si = ix(idx, a.str);
                b.putInt(si);
                b.putShort((short) 8).put((byte) 0).put((byte) T_STRING).putInt(si);
            } else {
                b.putInt(ix(idx, a.raw));
                b.putShort((short) 8).put((byte) 0).put((byte) a.type).putInt(a.data);
            }
        }
        o.write(b.array(), 0, size);
        for (Elem k : e.kids) writeElem(o, k, idx);
        ByteBuffer en = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        en.putShort((short) 0x0103).putShort((short) 16).putInt(24).putInt(e.line <= 0 ? 1 : e.line).putInt(-1);
        en.putInt(ix(idx, e.ns)).putInt(ix(idx, e.name));
        o.write(en.array(), 0, 24);
    }
}
