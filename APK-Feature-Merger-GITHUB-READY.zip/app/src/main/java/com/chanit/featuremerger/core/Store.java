package com.chanit.featuremerger.core;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/** Keeps imported APK copies and their analysis results on the phone. */
public final class Store {
    private final File apkDir, cacheDir;

    public Store(Context ctx) {
        apkDir = new File(ctx.getFilesDir(), "apks");
        cacheDir = new File(ctx.getFilesDir(), "analysis");
        //noinspection ResultOfMethodCallIgnored
        apkDir.mkdirs();
        //noinspection ResultOfMethodCallIgnored
        cacheDir.mkdirs();
    }

    public File apkDir() { return apkDir; }

    public File[] listApks() {
        File[] f = apkDir.listFiles((d, n) -> n.endsWith(".apk"));
        return f == null ? new File[0] : f;
    }

    public File uniqueFile(String name) {
        String base = name.replaceAll("[^A-Za-z0-9._-]", "_");
        if (base.toLowerCase().endsWith(".apk")) base = base.substring(0, base.length() - 4);
        File f = new File(apkDir, base + ".apk");
        int i = 2;
        while (f.exists()) f = new File(apkDir, base + "_" + (i++) + ".apk");
        return f;
    }

    private File cacheFile(File apk) { return new File(cacheDir, apk.getName() + ".ser"); }

    public Model.Apk loadCached(File apk) {
        File c = cacheFile(apk);
        if (!c.exists()) return null;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(c))) {
            Model.Apk a = (Model.Apk) in.readObject();
            if (a.size == apk.length() && a.stamp == apk.lastModified()) return a;
        } catch (Throwable ignored) { }
        return null;
    }

    public void save(Model.Apk a) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(cacheFile(new File(a.path))))) {
            out.writeObject(a);
        } catch (Throwable ignored) { }
    }

    public void delete(Model.Apk a) {
        File f = new File(a.path);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
        //noinspection ResultOfMethodCallIgnored
        cacheFile(f).delete();
        if (a.iconPath != null) //noinspection ResultOfMethodCallIgnored
            new File(a.iconPath).delete();
    }
}
