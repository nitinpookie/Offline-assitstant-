package com.chanit.featuremerger.bridge;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Runtime side of the merge. Reads assets/fm/config.json, wires the menu switches that were cloned into
 * the base app's layout (found by their android:tag "fm:N"), and starts / stops the guest features.
 */
public final class FmBoot {
    static final String TAG = "FeatureMerger";
    private static final String SHIM = "com.chanit.featuremerger.bridge.FmShim";

    private static boolean inited, started, asked, suppress;
    private static JSONArray features;
    private static Context appCtx;
    private static Activity current;
    private static Handler handler;
    private static boolean anyMenu;
    private static final boolean[] running = new boolean[8];
    private static final Map<String, FmGuest> guests = new HashMap<String, FmGuest>();
    private static final WeakHashMap<View, Boolean> bound = new WeakHashMap<View, Boolean>();

    public static synchronized void init(Context ctx) {
        if (inited || ctx == null) return;
        inited = true;
        appCtx = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
        try {
            features = new JSONObject(readAsset(appCtx, "fm/config.json")).getJSONArray("features");
            for (int i = 0; i < features.length(); i++) if (features.getJSONObject(i).optBoolean("menu")) anyMenu = true;
        } catch (Throwable t) {
            Log.e(TAG, "config", t);
            return;
        }
        handler = new Handler(Looper.getMainLooper());
        if (appCtx instanceof Application) {
            ((Application) appCtx).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override public void onActivityResumed(Activity a) {
                    current = a;
                    autoStart(a);
                }
                @Override public void onActivityPaused(Activity a) { if (current == a) current = null; }
                @Override public void onActivityCreated(Activity a, Bundle b) { }
                @Override public void onActivityStarted(Activity a) { }
                @Override public void onActivityStopped(Activity a) { }
                @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                @Override public void onActivityDestroyed(Activity a) { }
            });
        }
        if (anyMenu) handler.post(SCAN);
    }

    static JSONObject feature(Context c, int slot) {
        try {
            if (features == null) init(c);
            for (int i = 0; i < features.length(); i++) {
                JSONObject o = features.getJSONObject(i);
                if (o.getInt("slot") == slot) return o;
            }
        } catch (Throwable t) {
            Log.e(TAG, "feature", t);
        }
        return null;
    }

    static synchronized FmGuest guest(Context c, JSONObject f) throws Exception {
        String asset = f.getString("asset");
        FmGuest g = guests.get(asset);
        if (g == null) {
            g = FmGuest.load(c, asset, f.optString("app", ""));
            guests.put(asset, g);
        }
        return g;
    }

    static void setRunning(int slot, boolean on) {
        if (slot >= 0 && slot < running.length) running[slot] = on;
    }

    // ---------------------------------------------------------------- features without a menu switch start by themselves
    private static void autoStart(Context c) {
        if (started || features == null) return;
        try {
            boolean need = false;
            for (int i = 0; i < features.length(); i++) if (!features.getJSONObject(i).optBoolean("menu")) need = true;
            if (!need) {
                started = true;
                return;
            }
            if (!canOverlay()) {
                askOverlay();
                return;
            }
            started = true;
            for (int i = 0; i < features.length(); i++) {
                JSONObject o = features.getJSONObject(i);
                if (!o.optBoolean("menu")) start(o.getInt("slot"));
            }
        } catch (Throwable t) {
            Log.e(TAG, "autostart", t);
        }
    }

    private static boolean canOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(appCtx);
    }

    private static void askOverlay() {
        if (asked) return;
        asked = true;
        try {
            Toast.makeText(appCtx, "Allow \"Display over other apps\" to use the added features", Toast.LENGTH_LONG).show();
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + appCtx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            appCtx.startActivity(i);
        } catch (Throwable ignored) { }
    }

    private static void start(int slot) {
        try {
            Intent i = new Intent();
            i.setClassName(appCtx.getPackageName(), SHIM + slot);
            appCtx.startService(i);
            running[slot] = true;
        } catch (Throwable t) {
            Log.e(TAG, "start", t);
            running[slot] = false;
        }
    }

    private static void stop(int slot) {
        try {
            Intent i = new Intent();
            i.setClassName(appCtx.getPackageName(), SHIM + slot);
            appCtx.stopService(i);
        } catch (Throwable t) {
            Log.e(TAG, "stop", t);
        }
        running[slot] = false;
    }

    // ---------------------------------------------------------------- menu switches
    private static final Runnable SCAN = new Runnable() {
        @Override public void run() {
            try {
                scanOnce();
            } catch (Throwable t) {
                Log.w(TAG, "scan: " + t);
            }
            handler.postDelayed(this, 700);
        }
    };

    @SuppressWarnings("unchecked")
    private static void scanOnce() throws Exception {
        List<View> roots = new ArrayList<View>();
        try {
            Class<?> c = Class.forName("android.view.WindowManagerGlobal");
            Object g = c.getMethod("getInstance").invoke(null);
            Field f = c.getDeclaredField("mViews");
            f.setAccessible(true);
            Object v = f.get(g);
            if (v instanceof List) roots.addAll((List<View>) v);
        } catch (Throwable ignored) { }
        Activity a = current;
        if (a != null) roots.add(a.getWindow().getDecorView());
        for (int i = 0; i < features.length(); i++) {
            JSONObject o = features.getJSONObject(i);
            if (!o.optBoolean("menu")) continue;
            int slot = o.getInt("slot");
            for (View r : roots) {
                View v = r.findViewWithTag("fm:" + slot);
                if (v != null) bind(v, slot);
            }
        }
    }

    private static void bind(View v, final int slot) {
        if (bound.containsKey(v)) return;
        bound.put(v, Boolean.TRUE);
        if (v instanceof CompoundButton) {
            CompoundButton cb = (CompoundButton) v;
            suppress = true;
            cb.setChecked(running[slot]);
            suppress = false;
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    if (suppress) return;
                    toggle(slot, on, b);
                }
            });
        } else {
            v.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View x) {
                    toggle(slot, !running[slot], null);
                }
            });
        }
    }

    private static void toggle(int slot, boolean on, CompoundButton b) {
        if (on) {
            if (!canOverlay()) {
                askOverlay();
                asked = false; // ask again next time the user flips the switch
                if (b != null) {
                    suppress = true;
                    b.setChecked(false);
                    suppress = false;
                }
                return;
            }
            start(slot);
        } else {
            stop(slot);
        }
    }

    private static String readAsset(Context c, String name) throws Exception {
        InputStream in = c.getAssets().open(name);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
            return bo.toString("UTF-8");
        } finally {
            in.close();
        }
    }
}
