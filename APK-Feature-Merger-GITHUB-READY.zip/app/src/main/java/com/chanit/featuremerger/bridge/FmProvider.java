package com.chanit.featuremerger.bridge;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;

/** Declared in the merged APK's manifest; Android creates it at process start, which boots the bridge. */
public class FmProvider extends ContentProvider {
    @Override public boolean onCreate() {
        try {
            FmBoot.init(getContext());
        } catch (Throwable t) {
            android.util.Log.e(FmBoot.TAG, "init failed", t);
        }
        return true;
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
