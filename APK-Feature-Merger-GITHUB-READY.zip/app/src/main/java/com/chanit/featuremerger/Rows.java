package com.chanit.featuremerger;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chanit.featuremerger.core.Model;
import com.google.android.material.checkbox.MaterialCheckBox;

import java.util.ArrayList;
import java.util.List;

/** Builds the feature / switched-off rows used in the app cards and on the merge page. */
final class Rows {
    private Rows() {}

    static final class FeatureRow {
        View view;
        MaterialCheckBox main;
        Model.Apk apk;
        Model.Feature feature;
        final List<MaterialCheckBox> boxes = new ArrayList<>();
        final List<Model.Control> controls = new ArrayList<>();
    }

    static int dp(Context c, int v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    static int color(Context c, int level) {
        int res = level == Model.GREEN ? R.color.fm_green : level == Model.AMBER ? R.color.fm_amber : R.color.fm_red;
        return c.getColor(res);
    }

    static String levelName(int level) {
        return level == Model.GREEN ? "Safe to move" : level == Model.AMBER ? "Check first" : "Probably will not work";
    }

    private static void paintDot(View dot, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        dot.setBackground(g);
    }

    /**
     * @param mainText   text of the main checkbox, null = no checkbox
     * @param mainEnable whether the main checkbox can be ticked
     * @param ctlBoxes   true = controls are checkboxes, false = plain text lines
     * @param ctlChecked initial state of the control checkboxes
     */
    static FeatureRow feature(Context c, ViewGroup parent, Model.Apk apk, Model.Feature f,
                              String mainText, boolean mainEnable, boolean ctlBoxes, boolean ctlChecked) {
        FeatureRow r = new FeatureRow();
        r.apk = apk;
        r.feature = f;
        View v = LayoutInflater.from(c).inflate(R.layout.row_feature, parent, false);
        r.view = v;
        r.main = v.findViewById(R.id.cbMain);
        View dot = v.findViewById(R.id.dot);
        TextView title = v.findViewById(R.id.tvTitle);
        TextView sub = v.findViewById(R.id.tvSub);
        TextView why = v.findViewById(R.id.tvWhy);
        TextView toggle = v.findViewById(R.id.tvToggle);
        LinearLayout host = v.findViewById(R.id.ctlHost);

        paintDot(dot, color(c, f.level));
        title.setText(f.label);
        sub.setText(levelName(f.level) + "  |  " + f.classCount + " classes, " + f.controls.size() + " controls");
        sub.setTextColor(color(c, f.level));
        StringBuilder sb = new StringBuilder();
        for (String s : f.reasons) sb.append("- ").append(s).append('\n');
        why.setText(sb.toString().trim());

        if (mainText == null) {
            r.main.setVisibility(View.GONE);
        } else {
            r.main.setText(mainText);
            r.main.setEnabled(mainEnable);
            // title carries the label; checkbox only shows the action
            r.main.setTextSize(12);
            if (!mainEnable) v.setAlpha(0.6f);
        }

        if (f.controls.isEmpty()) {
            toggle.setVisibility(View.GONE);
        } else {
            for (Model.Control ct : f.controls) {
                String text = ct.label + "  (" + ct.tag + ")";
                if (ctlBoxes) {
                    MaterialCheckBox cb = new MaterialCheckBox(c);
                    cb.setText(text);
                    cb.setChecked(ctlChecked);
                    cb.setEnabled(mainEnable || mainText == null);
                    host.addView(cb);
                    r.boxes.add(cb);
                    r.controls.add(ct);
                } else {
                    TextView t = new TextView(c);
                    t.setText("- " + text);
                    t.setPadding(0, dp(c, 3), 0, dp(c, 3));
                    host.addView(t);
                }
            }
            final String label = "Controls (" + f.controls.size() + ")";
            toggle.setText(label);
            toggle.setOnClickListener(x -> {
                boolean open = host.getVisibility() == View.VISIBLE;
                host.setVisibility(open ? View.GONE : View.VISIBLE);
                toggle.setText(open ? label : "Hide list");
            });
        }
        parent.addView(v);
        return r;
    }

    static TextView header(Context c, ViewGroup parent, String text) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_LabelLarge);
        t.setTextColor(c.getColor(R.color.fm_on_surface_variant));
        t.setPadding(0, dp(c, 14), 0, dp(c, 2));
        parent.addView(t);
        return t;
    }

    static TextView note(Context c, ViewGroup parent, String text) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodySmall);
        t.setTextColor(c.getColor(R.color.fm_on_surface_variant));
        t.setPadding(0, dp(c, 8), 0, dp(c, 4));
        parent.addView(t);
        return t;
    }

    /** One switched-off item. Returns its checkbox (null when read-only). */
    static MaterialCheckBox hidden(Context c, ViewGroup parent, Model.Hidden h, boolean selectable) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(c, 4), 0, dp(c, 4));
        MaterialCheckBox cb = null;
        if (selectable) {
            cb = new MaterialCheckBox(c);
            cb.setText("Activate: " + h.label);
            box.addView(cb);
        } else {
            TextView t = new TextView(c);
            t.setText(h.label);
            t.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodyLarge);
            box.addView(t);
        }
        TextView d = new TextView(c);
        d.setText(h.detail);
        d.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodySmall);
        d.setTextColor(c.getColor(R.color.fm_on_surface_variant));
        d.setPadding(selectable ? dp(c, 48) : 0, 0, 0, 0);
        box.addView(d);
        parent.addView(box);
        return cb;
    }
}
