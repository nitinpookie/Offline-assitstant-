package com.chanit.featuremerger.bridge;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.view.LayoutInflater;

/** Context handed to guest code: host services and package name, but the guest's own resources and classes. */
final class FmGuestContext extends ContextWrapper {
    private final FmGuest g;
    private Resources.Theme theme;

    FmGuestContext(Context base, FmGuest g) {
        super(base);
        this.g = g;
    }

    @Override public Resources getResources() { return g.res; }

    @Override public AssetManager getAssets() { return g.res.getAssets(); }

    @Override public Resources.Theme getTheme() {
        if (theme == null) {
            theme = g.res.newTheme();
            if (g.ai != null && g.ai.theme != 0) theme.applyStyle(g.ai.theme, true);
        }
        return theme;
    }

    @Override public ClassLoader getClassLoader() { return g.cl; }

    @Override public Context getApplicationContext() { return g.app != null ? g.app : this; }

    @Override public Object getSystemService(String name) {
        if (Context.LAYOUT_INFLATER_SERVICE.equals(name)) {
            return LayoutInflater.from(getBaseContext()).cloneInContext(this);
        }
        return super.getSystemService(name);
    }
}
