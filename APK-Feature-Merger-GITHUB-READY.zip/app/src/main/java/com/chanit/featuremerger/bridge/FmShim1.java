package com.chanit.featuremerger.bridge;

public class FmShim1 extends FmShimBase {
    @Override protected int slot() { return 1; }
}
