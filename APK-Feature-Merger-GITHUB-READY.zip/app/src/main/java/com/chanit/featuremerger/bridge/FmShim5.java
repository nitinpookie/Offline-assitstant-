package com.chanit.featuremerger.bridge;

public class FmShim5 extends FmShimBase {
    @Override protected int slot() { return 5; }
}
