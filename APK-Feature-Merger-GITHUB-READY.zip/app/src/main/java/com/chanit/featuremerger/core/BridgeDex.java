package com.chanit.featuremerger.core;

import android.content.Context;

import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Pulls the runtime bridge classes out of this app's own dex files into a small stand-alone dex. */
final class BridgeDex {
    private BridgeDex() {}

    static final String PREFIX = "Lcom/chanit/featuremerger/bridge/";

    static int extract(Context ctx, File out) throws IOException {
        DexPool pool = new DexPool(Opcodes.forApi(23));
        int count = 0;
        try (ZipFile zf = new ZipFile(new File(ctx.getPackageCodePath()))) {
            int i = 0;
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                if (!e.getName().matches("classes\\d*\\.dex")) continue;
                File tmp = new File(ctx.getCacheDir(), "bridge_src_" + (i++) + ".dex");
                try (InputStream in = zf.getInputStream(e); FileOutputStream o = new FileOutputStream(tmp)) {
                    byte[] buf = new byte[1 << 16];
                    int r;
                    while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                }
                try {
                    DexFile df = DexFileFactory.loadDexFile(tmp, Opcodes.getDefault());
                    for (ClassDef cd : df.getClasses()) {
                        if (cd.getType().startsWith(PREFIX)) {
                            pool.internClass(cd);
                            count++;
                        }
                    }
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                }
            }
        }
        if (count == 0) throw new IOException("Bridge classes not found inside this app");
        pool.writeTo(new FileDataStore(out));
        return count;
    }
}
