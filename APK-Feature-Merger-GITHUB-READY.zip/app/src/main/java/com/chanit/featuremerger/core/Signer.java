package com.chanit.featuremerger.core;

import com.android.apksig.ApkSigner;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Collections;
import java.util.Date;

/** Signs the merged APK (v1 + v2) with a key that is generated once and kept on the phone. */
final class Signer {
    private Signer() {}

    static void sign(File keyDir, File in, File out) throws Exception {
        //noinspection ResultOfMethodCallIgnored
        keyDir.mkdirs();
        File kf = new File(keyDir, "fm.key");
        File cf = new File(keyDir, "fm.crt");
        if (!kf.exists() || !cf.exists()) generate(kf, cf);
        PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(readAll(kf)));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(readAll(cf)));
        ApkSigner.SignerConfig cfg = new ApkSigner.SignerConfig.Builder("featuremerger", key, Collections.singletonList(cert)).build();
        new ApkSigner.Builder(Collections.singletonList(cfg))
                .setInputApk(in)
                .setOutputApk(out)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(false)
                .build()
                .sign();
    }

    private static void generate(File kf, File cf) throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        X500Name name = new X500Name("CN=Feature Merger, O=Chanit");
        Date from = new Date(System.currentTimeMillis() - 86400000L);
        Date to = new Date(from.getTime() + 36500L * 86400000L);
        JcaX509v3CertificateBuilder b = new JcaX509v3CertificateBuilder(name, BigInteger.valueOf(System.currentTimeMillis()), from, to, name, kp.getPublic());
        ContentSigner cs = new JcaContentSignerBuilder("SHA256withRSA").build(kp.getPrivate());
        X509CertificateHolder h = b.build(cs);
        try (FileOutputStream o = new FileOutputStream(kf)) { o.write(kp.getPrivate().getEncoded()); }
        try (FileOutputStream o = new FileOutputStream(cf)) { o.write(h.getEncoded()); }
    }

    private static byte[] readAll(File f) throws IOException {
        byte[] b = new byte[(int) f.length()];
        try (FileInputStream in = new FileInputStream(f)) {
            int o = 0;
            while (o < b.length) {
                int r = in.read(b, o, b.length - o);
                if (r < 0) break;
                o += r;
            }
        }
        return b;
    }
}
