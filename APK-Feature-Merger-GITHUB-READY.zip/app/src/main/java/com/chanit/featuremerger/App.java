package com.chanit.featuremerger;

import android.app.Application;

import com.google.android.material.color.DynamicColors;

public class App extends Application {
    @Override public void onCreate() {
        super.onCreate();
        // Material You colours on Android 12+, our own palette elsewhere
        DynamicColors.applyToActivitiesIfAvailable(this);
    }
}
