package com.chanit.featuremerger.bridge;

public class FmShim0 extends FmShimBase {
    @Override protected int slot() { return 0; }
}
