package com.chanit.featuremerger.core;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Builds the merged APK:
 *  - the chosen features stay intact inside their own APK (code + resources) and are loaded by a small
 *    bridge that is injected into the base app, so they behave exactly like in the original app;
 *  - a matching switch row is cloned into the base app's existing menu so it looks like every other option;
 *  - unwanted base-app controls / services can be hidden, hidden or disabled items can be activated.
 */
public final class Merger {
    private Merger() {}

    public static final int MAX_FEATURES = 6;
    private static final int A_NAME = 0x01010003, A_ENABLED = 0x0101000e, A_EXPORTED = 0x01010010,
            A_AUTH = 0x01010018, A_VIS = 0x010100dc, A_TAG = 0x010100d1, A_TEXT = 0x0101014f, A_CHECKED = 0x01010106;

    public static final class Pick {
        public Model.Apk apk;
        public Model.Feature feature;
        public List<Model.Control> hide = new ArrayList<>();
    }

    public static final class Plan {
        public Model.Apk base;
        public List<Pick> picks = new ArrayList<>();
        public List<Model.Control> hideInBase = new ArrayList<>();
        public Set<String> disableServices = new HashSet<>();
        public List<Model.Hidden> activate = new ArrayList<>();
        public boolean copyPermissions = true;
        public boolean addToMenu = true;
    }

    public interface Sink {
        void step(int pct, String msg);
        void log(String line);
    }

    public static File run(Context ctx, Plan plan, Sink s) throws Exception {
        if (plan.picks.size() > MAX_FEATURES) throw new IOException("At most " + MAX_FEATURES + " features can be added at once.");
        File work = new File(ctx.getCacheDir(), "merge");
        deleteTree(work);
        //noinspection ResultOfMethodCallIgnored
        work.mkdirs();
        File baseApk = new File(plan.base.path);

        s.step(3, "Reading base app: " + plan.base.label);
        Axml mf;
        Arsc arsc = null;
        int dexCount = 0;
        try (ZipFile zf = new ZipFile(baseApk)) {
            ZipEntry me = zf.getEntry("AndroidManifest.xml");
            if (me == null) throw new IOException("Base app has no AndroidManifest.xml");
            mf = Axml.parse(ApkZip.readAll(zf, me));
            ZipEntry ae = zf.getEntry("resources.arsc");
            if (ae != null) {
                try { arsc = Arsc.parse(ApkZip.readAll(zf, ae)); } catch (Exception ex) { s.log("Resources not readable: " + ex.getMessage()); }
            }
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); )
                if (en.nextElement().getName().matches("classes\\d*\\.dex")) dexCount++;
        }
        if (dexCount == 0) throw new IOException("Base app has no code (classes.dex)");
        String pkg = mf.root.plain("package").text();
        Axml.Elem app = mf.root.child("application");
        if (app == null) throw new IOException("Base app manifest has no <application>");

        // ---------- layout edits on the base app
        Map<String, Axml> layouts = new LinkedHashMap<>();
        try (ZipFile zf = new ZipFile(baseApk)) {
            s.step(10, "Editing base app layouts");
            for (Model.Control c : plan.hideInBase) {
                int n = 0;
                for (String p : c.layoutPaths) n += editLayout(zf, layouts, p, c.viewId, "hide");
                s.log("Hid \"" + c.label + "\" (" + n + " place" + (n == 1 ? "" : "s") + ")");
            }
            for (Model.Hidden h : plan.activate) {
                if (!"CONTROL".equals(h.kind)) continue;
                int n = 0;
                for (String p : h.layoutPaths) n += editLayout(zf, layouts, p, h.viewId, "show");
                s.log("Activated \"" + h.label + "\" (" + n + " place" + (n == 1 ? "" : "s") + ")");
            }
        }

        // ---------- menu rows for added features
        List<Integer> menuSlots = new ArrayList<>();
        if (plan.addToMenu && !plan.picks.isEmpty()) {
            s.step(18, "Looking for the base app's menu");
            try (ZipFile zf = new ZipFile(baseApk)) {
                MenuSpot spot = findMenu(zf, arsc, plan.base, layouts);
                if (spot == null) {
                    s.log("No switch menu found in the base app. Added features will start automatically.");
                } else {
                    s.log("Menu found: layout " + spot.name + " (" + spot.toggles + " switches). Adding rows there.");
                    for (int i = 0; i < plan.picks.size(); i++) {
                        Pick p = plan.picks.get(i);
                        if (injectRow(spot, "fm:" + i, p.feature.label)) menuSlots.add(i);
                    }
                    layouts.put(spot.paths.get(0), spot.axml);
                    for (int pi = 1; pi < spot.paths.size(); pi++) { // other config variants of the same layout
                        String path = spot.paths.get(pi);
                        Axml x = layouts.get(path);
                        if (x == null) {
                            ZipEntry ze = zf.getEntry(path);
                            if (ze == null) continue;
                            x = Axml.parse(ApkZip.readAll(zf, ze));
                            layouts.put(path, x);
                        }
                        MenuSpot v = spotFor(x, spot.name, spot.paths);
                        if (v != null) for (int i : menuSlots) injectRow(v, "fm:" + i, plan.picks.get(i).feature.label);
                    }
                }
            }
        }

        // ---------- guest APKs (source apps)
        s.step(28, "Preparing source apps");
        Map<String, File> guestFiles = new LinkedHashMap<>();
        Map<String, List<Model.Control>> hideBySource = new LinkedHashMap<>();
        for (Pick p : plan.picks) {
            List<Model.Control> l = hideBySource.get(p.apk.path);
            if (l == null) { l = new ArrayList<>(); hideBySource.put(p.apk.path, l); }
            l.addAll(p.hide);
        }
        int gi = 0;
        Map<String, String> assetOf = new LinkedHashMap<>();
        for (Map.Entry<String, List<Model.Control>> e : hideBySource.entrySet()) {
            File src = new File(e.getKey());
            File use = src;
            if (!e.getValue().isEmpty()) {
                Map<String, Axml> gl = new LinkedHashMap<>();
                try (ZipFile zf = new ZipFile(src)) {
                    for (Model.Control c : e.getValue()) for (String path : c.layoutPaths) editLayout(zf, gl, path, c.viewId, "hide");
                }
                Map<String, byte[]> rep = new LinkedHashMap<>();
                for (Map.Entry<String, Axml> g : gl.entrySet()) rep.put(g.getKey(), g.getValue().build());
                use = new File(work, "guest_" + gi + ".apk");
                try (ApkZip.Writer w = new ApkZip.Writer(use)) { w.copy(src, rep, false); }
                s.log("Trimmed " + e.getValue().size() + " control(s) from " + src.getName());
            }
            String asset = "fm/g" + gi + ".apk";
            guestFiles.put(asset, use);
            assetOf.put(e.getKey(), asset);
            gi++;
        }

        // ---------- manifest
        s.step(42, "Editing manifest");
        Set<String> have = new HashSet<>();
        for (Axml.Elem k : mf.root.kids) if ("uses-permission".equals(k.name) && k.text("name") != null) have.add(k.text("name"));
        Set<String> want = new LinkedHashSet<>();
        if (!plan.picks.isEmpty()) {
            want.add("android.permission.SYSTEM_ALERT_WINDOW");
            want.add("android.permission.FOREGROUND_SERVICE");
            if (plan.copyPermissions) for (Pick p : plan.picks) want.addAll(p.apk.permissions);
        }
        int at = mf.root.kids.indexOf(app);
        int added = 0;
        for (String perm : want) {
            if (have.contains(perm)) continue;
            Axml.Elem pe = new Axml.Elem("uses-permission");
            pe.put(Axml.str("name", A_NAME, perm));
            mf.root.kids.add(at++, pe);
            added++;
        }
        if (added > 0) s.log("Added " + added + " permission(s)");

        for (Axml.Elem k : app.kids) {
            String n = k.text("name");
            if (n == null) continue;
            String full = n.startsWith(".") ? pkg + n : (n.indexOf('.') < 0 ? pkg + "." + n : n);
            if ("service".equals(k.name) && plan.disableServices.contains(full)) {
                k.put(Axml.bool("enabled", A_ENABLED, false));
                s.log("Turned off service " + full);
            }
            for (Model.Hidden h : plan.activate) {
                if ("COMPONENT".equals(h.kind) && h.tag.equals(k.name) && h.name.equals(full)) {
                    k.put(Axml.bool("enabled", A_ENABLED, true));
                    s.log("Activated " + h.tag + " " + h.name);
                }
            }
        }

        JSONArray feats = new JSONArray();
        for (int i = 0; i < plan.picks.size(); i++) {
            Pick p = plan.picks.get(i);
            JSONObject o = new JSONObject();
            o.put("slot", i);
            o.put("asset", assetOf.get(p.apk.path));
            o.put("service", p.feature.serviceName);
            o.put("app", p.apk.appClass == null ? "" : p.apk.appClass);
            o.put("label", p.feature.label);
            o.put("menu", menuSlots.contains(i));
            feats.put(o);
        }
        if (!plan.picks.isEmpty()) {
            Axml.Elem prov = new Axml.Elem("provider");
            prov.put(Axml.str("name", A_NAME, "com.chanit.featuremerger.bridge.FmProvider"));
            prov.put(Axml.bool("enabled", A_ENABLED, true));
            prov.put(Axml.bool("exported", A_EXPORTED, false));
            prov.put(Axml.str("authorities", A_AUTH, pkg + ".fmboot"));
            app.kids.add(prov);
            for (int i = 0; i < plan.picks.size(); i++) {
                Axml.Elem sv = new Axml.Elem("service");
                sv.put(Axml.str("name", A_NAME, "com.chanit.featuremerger.bridge.FmShim" + i));
                sv.put(Axml.bool("enabled", A_ENABLED, true));
                sv.put(Axml.bool("exported", A_EXPORTED, false));
                app.kids.add(sv);
            }
        }

        // ---------- bridge dex
        File bridge = new File(work, "bridge.dex");
        if (!plan.picks.isEmpty()) {
            s.step(50, "Building bridge code");
            int n = BridgeDex.extract(ctx, bridge);
            s.log("Bridge: " + n + " classes");
        }

        // ---------- write unsigned apk
        s.step(60, "Writing new APK");
        File unsigned = new File(work, "unsigned.apk");
        Map<String, byte[]> rep = new LinkedHashMap<>();
        rep.put("AndroidManifest.xml", mf.build());
        for (Map.Entry<String, Axml> e : layouts.entrySet()) rep.put(e.getKey(), e.getValue().build());
        try (ApkZip.Writer w = new ApkZip.Writer(unsigned)) {
            w.copy(baseApk, rep, true);
            if (!plan.picks.isEmpty()) {
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                try (java.io.FileInputStream in = new java.io.FileInputStream(bridge)) {
                    byte[] buf = new byte[1 << 16];
                    int r;
                    while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
                }
                w.put("classes" + (dexCount + 1) + ".dex", bo.toByteArray(), false);
                JSONObject cfg = new JSONObject();
                cfg.put("features", feats);
                cfg.put("overlay", true);
                w.put("assets/fm/config.json", cfg.toString().getBytes("UTF-8"), false);
                for (Map.Entry<String, File> g : guestFiles.entrySet()) {
                    s.log("Embedding " + g.getValue().getName() + " (" + (g.getValue().length() / 1024) + " KB)");
                    w.putFile("assets/" + g.getKey(), g.getValue());
                }
            }
        }

        // ---------- sign
        s.step(80, "Signing (first time creates your key, a few seconds)");
        File outDir = ctx.getExternalFilesDir("Output");
        if (outDir == null) outDir = new File(ctx.getFilesDir(), "Output");
        //noinspection ResultOfMethodCallIgnored
        outDir.mkdirs();
        String safe = plan.base.label.replaceAll("[^A-Za-z0-9._-]", "_");
        File out = new File(outDir, safe + "_merged.apk");
        Signer.sign(new File(ctx.getFilesDir(), "keys"), unsigned, out);

        // ---------- verify
        s.step(94, "Checking the result");
        PackageInfo pi = ctx.getPackageManager().getPackageArchiveInfo(out.getAbsolutePath(), PackageManager.GET_PROVIDERS | PackageManager.GET_SERVICES);
        if (pi == null) throw new IOException("Android cannot read the new APK (manifest problem). Nothing was installed.");
        if (!plan.picks.isEmpty()) {
            boolean ok = false;
            if (pi.providers != null)
                for (android.content.pm.ProviderInfo p : pi.providers) if (p.name.endsWith("FmProvider")) ok = true;
            if (!ok) throw new IOException("Bridge provider missing in the new APK.");
        }
        deleteTree(work);
        s.step(100, "Done");
        s.log("Saved: " + out.getAbsolutePath());
        return out;
    }

    // ------------------------------------------------------------------ layout helpers
    private static int editLayout(ZipFile zf, Map<String, Axml> cache, String path, int viewId, String op) throws IOException {
        Axml x = cache.get(path);
        if (x == null) {
            ZipEntry ze = zf.getEntry(path);
            if (ze == null) return 0;
            x = Axml.parse(ApkZip.readAll(zf, ze));
            cache.put(path, x);
        }
        return apply(x.root, viewId, op);
    }

    private static int apply(Axml.Elem e, int id, String op) {
        int n = 0;
        Axml.Attr a = e.attr("id");
        if (a != null && a.type == Axml.T_REF && a.data == id) {
            if ("hide".equals(op)) e.put(Axml.hex("visibility", A_VIS, 2));
            else {
                Axml.Attr v = e.attr("visibility");
                if (v != null) e.put(Axml.hex("visibility", A_VIS, 0));
                Axml.Attr en = e.attr("enabled");
                if (en != null) e.put(Axml.bool("enabled", A_ENABLED, true));
            }
            n++;
        }
        for (Axml.Elem k : e.kids) n += apply(k, id, op);
        return n;
    }

    // ------------------------------------------------------------------ menu injection
    private static final class MenuSpot {
        String name;
        List<String> paths;
        Axml axml;
        int toggles;
    }

    private static int countToggles(Axml.Elem e) {
        final int[] n = {0};
        e.walk(x -> { if (ApkAnalyzer.isToggle(x.name)) n[0]++; });
        return n[0];
    }

    private static MenuSpot spotFor(Axml x, String name, List<String> paths) {
        MenuSpot m = new MenuSpot();
        m.name = name;
        m.paths = paths;
        m.axml = x;
        m.toggles = countToggles(x.root);
        return m.toggles > 0 ? m : null;
    }

    /** Picks the layout of the base app that holds the most on/off switches (its feature menu). */
    private static MenuSpot findMenu(ZipFile zf, Arsc arsc, Model.Apk base, Map<String, Axml> edited) throws IOException {
        Map<String, ArrayList<String>> candidates = new LinkedHashMap<>();
        for (Model.Feature f : base.features) candidates.putAll(f.layoutFiles);
        if (candidates.isEmpty() && arsc != null) {
            for (Arsc.Entry e : arsc.byId.values()) {
                if (!"layout".equals(e.type)) continue;
                ArrayList<String> ps = new ArrayList<>();
                for (String s : e.strings) if (s.endsWith(".xml")) ps.add(s);
                if (!ps.isEmpty()) candidates.put(e.name, ps);
            }
        }
        MenuSpot best = null;
        for (Map.Entry<String, ArrayList<String>> c : candidates.entrySet()) {
            String path = c.getValue().get(0);
            Axml x = edited.get(path);
            if (x == null) {
                ZipEntry ze = zf.getEntry(path);
                if (ze == null) continue;
                try { x = Axml.parse(ApkZip.readAll(zf, ze)); } catch (Exception ex) { continue; }
            }
            MenuSpot m = spotFor(x, c.getKey(), c.getValue());
            if (m != null && (best == null || m.toggles > best.toggles)) best = m;
        }
        return best;
    }

    private static boolean containsToggle(Axml.Elem e) { return countToggles(e) > 0; }

    /** Clones the last switch row of the menu so the new option has exactly the same look. */
    private static boolean injectRow(MenuSpot spot, String tag, String label) {
        final List<Axml.Elem> toggles = new ArrayList<>();
        spot.axml.root.walk(x -> { if (ApkAnalyzer.isToggle(x.name)) toggles.add(x); });
        if (toggles.isEmpty()) return false;
        Axml.Elem last = toggles.get(toggles.size() - 1);
        Axml.Elem row = last;
        Axml.Elem parent = Axml.parentOf(spot.axml.root, last);
        if (parent != null) {
            Axml.Elem gp = Axml.parentOf(spot.axml.root, parent);
            if (gp != null && parent.kids.size() <= 4) {
                int sib = 0;
                for (Axml.Elem k : gp.kids) if (containsToggle(k)) sib++;
                if (sib >= 2) row = parent;
            }
        }
        Axml.Elem container = Axml.parentOf(spot.axml.root, row);
        if (container == null) return false;
        Axml.Elem clone = row.copy();
        final boolean[] textSet = {false};
        clone.walk(x -> {
            x.remove("id");
            x.remove("onClick");
            x.remove("tag");
            Axml.Attr t = x.attr("text");
            if (t != null && (t.type == Axml.T_STRING || t.type == Axml.T_REF)) {
                x.put(Axml.str("text", A_TEXT, label));
                textSet[0] = true;
            }
        });
        // find the toggle inside the clone and mark it
        final Axml.Elem[] t2 = {null};
        clone.walk(x -> { if (t2[0] == null && ApkAnalyzer.isToggle(x.name)) t2[0] = x; });
        if (t2[0] == null) return false;
        t2[0].put(Axml.str("tag", A_TAG, tag));
        t2[0].put(Axml.bool("checked", A_CHECKED, false));
        if (!textSet[0]) {
            final Axml.Elem[] tv = {null};
            clone.walk(x -> { if (tv[0] == null && x != t2[0] && x.name.toLowerCase().contains("textview")) tv[0] = x; });
            Axml.Elem target = tv[0] != null ? tv[0] : t2[0];
            target.put(Axml.str("text", A_TEXT, label));
        }
        int pos = container.kids.indexOf(row);
        container.kids.add(pos + 1, clone);
        return true;
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] k = f.listFiles();
        if (k != null) for (File c : k) deleteTree(c);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
