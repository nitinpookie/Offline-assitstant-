package com.chanit.featuremerger;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.chanit.featuremerger.core.Merger;
import com.chanit.featuremerger.core.Model;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Drives the Merge page: choose base app, tick what to activate / remove / bring in, build. */
final class MergeController {
    private final MainActivity a;
    private final MaterialAutoCompleteTextView dd;
    private final LinearLayout hiddenHost, removeHost, addHost;
    private final MaterialSwitch swMenu, swPerms;
    private final MaterialButton btnBuild, btnInstall, btnShare;
    private final View cardProgress, cardResult;
    private final TextView tvStep, tvTail, tvResult;
    private final LinearProgressIndicator bar;

    private Model.Apk base;
    private boolean building;
    private File lastOut;
    private final List<Rows.FeatureRow> removeRows = new ArrayList<>(), addRows = new ArrayList<>();
    private final List<Model.Hidden> hiddenItems = new ArrayList<>();
    private final List<MaterialCheckBox> hiddenBoxes = new ArrayList<>();
    private final ArrayList<String> tail = new ArrayList<>();

    MergeController(MainActivity act) {
        a = act;
        dd = a.findViewById(R.id.ddBase);
        hiddenHost = a.findViewById(R.id.hiddenHost);
        removeHost = a.findViewById(R.id.removeHost);
        addHost = a.findViewById(R.id.addHost);
        swMenu = a.findViewById(R.id.swMenu);
        swPerms = a.findViewById(R.id.swPerms);
        btnBuild = a.findViewById(R.id.btnBuild);
        btnInstall = a.findViewById(R.id.btnInstall);
        btnShare = a.findViewById(R.id.btnShare);
        cardProgress = a.findViewById(R.id.cardProgress);
        cardResult = a.findViewById(R.id.cardResult);
        tvStep = a.findViewById(R.id.tvStep);
        tvTail = a.findViewById(R.id.tvTail);
        tvResult = a.findViewById(R.id.tvResult);
        bar = a.findViewById(R.id.barBuild);

        dd.setOnItemClickListener((p, v, i, id) -> {
            if (i >= 0 && i < a.apks.size()) select(a.apks.get(i));
        });
        a.findViewById(R.id.btnSafe).setOnClickListener(v -> {
            int n = 0;
            for (Rows.FeatureRow r : addRows) {
                if (r.main != null && r.main.isEnabled() && r.feature.level == Model.GREEN) {
                    r.main.setChecked(true);
                    n++;
                }
            }
            Toast.makeText(a, n == 0 ? "No green features to pick" : n + " picked", Toast.LENGTH_SHORT).show();
        });
        btnBuild.setOnClickListener(v -> build());
        btnInstall.setOnClickListener(v -> install());
        btnShare.setOnClickListener(v -> share());
        rebuild();
    }

    void refresh() {
        String[] names = new String[a.apks.size()];
        for (int i = 0; i < names.length; i++) names[i] = a.apks.get(i).label;
        dd.setSimpleItems(names);
        if (base != null && a.apks.contains(base)) {
            rebuild();
        } else if (!a.apks.isEmpty()) {
            select(a.apks.get(0));
        } else {
            base = null;
            dd.setText("", false);
            rebuild();
        }
    }

    void select(Model.Apk apk) {
        base = apk;
        dd.setText(apk.label, false);
        rebuild();
    }

    private void rebuild() {
        hiddenHost.removeAllViews();
        removeHost.removeAllViews();
        addHost.removeAllViews();
        removeRows.clear();
        addRows.clear();
        hiddenItems.clear();
        hiddenBoxes.clear();
        if (base == null) {
            Rows.note(a, hiddenHost, "Add an APK on the Apps tab first.");
            return;
        }
        if (base.hidden.isEmpty()) Rows.note(a, hiddenHost, "Nothing hidden or disabled was found in " + base.label + ".");
        for (Model.Hidden h : base.hidden) {
            hiddenItems.add(h);
            hiddenBoxes.add(Rows.hidden(a, hiddenHost, h, true));
        }
        if (base.features.isEmpty()) Rows.note(a, removeHost, "No overlay features found in " + base.label + ".");
        for (Model.Feature f : base.features) {
            boolean svc = "SERVICE".equals(f.kind);
            removeRows.add(Rows.feature(a, removeHost, base, f, svc ? "Turn off whole feature" : null, true, true, false));
        }
        boolean any = false;
        for (Model.Apk o : a.apks) {
            if (o == base || o.features.isEmpty()) continue;
            any = true;
            Rows.header(a, addHost, o.label);
            for (Model.Feature f : o.features)
                addRows.add(Rows.feature(a, addHost, o, f, "Add to base app", f.movable, true, true));
        }
        if (!any) Rows.note(a, addHost, "Add a second APK that has overlay features to bring them in.");
    }

    // ------------------------------------------------------------------ build
    private void build() {
        if (building) return;
        if (base == null) {
            Toast.makeText(a, "Choose a base app first", Toast.LENGTH_SHORT).show();
            return;
        }
        final Merger.Plan p = new Merger.Plan();
        p.base = base;
        p.copyPermissions = swPerms.isChecked();
        p.addToMenu = swMenu.isChecked();
        for (Rows.FeatureRow r : removeRows) {
            if (r.main != null && r.main.getVisibility() == View.VISIBLE && r.main.isChecked()) {
                p.disableServices.add(r.feature.serviceName);
            } else {
                for (int i = 0; i < r.boxes.size(); i++) if (r.boxes.get(i).isChecked()) p.hideInBase.add(r.controls.get(i));
            }
        }
        for (int i = 0; i < hiddenBoxes.size(); i++)
            if (hiddenBoxes.get(i) != null && hiddenBoxes.get(i).isChecked()) p.activate.add(hiddenItems.get(i));
        for (Rows.FeatureRow r : addRows) {
            if (r.main == null || !r.main.isChecked()) continue;
            Merger.Pick pick = new Merger.Pick();
            pick.apk = r.apk;
            pick.feature = r.feature;
            for (int i = 0; i < r.boxes.size(); i++) if (!r.boxes.get(i).isChecked()) pick.hide.add(r.controls.get(i));
            p.picks.add(pick);
        }
        if (p.picks.isEmpty() && p.hideInBase.isEmpty() && p.disableServices.isEmpty() && p.activate.isEmpty()) {
            Toast.makeText(a, "Nothing selected yet", Toast.LENGTH_SHORT).show();
            return;
        }
        if (p.picks.size() > Merger.MAX_FEATURES) {
            Toast.makeText(a, "Pick at most " + Merger.MAX_FEATURES + " features at once", Toast.LENGTH_LONG).show();
            return;
        }
        building = true;
        btnBuild.setEnabled(false);
        cardResult.setVisibility(View.GONE);
        cardProgress.setVisibility(View.VISIBLE);
        tail.clear();
        tvTail.setText("");
        bar.setProgress(0);
        tvStep.setText("Starting");
        a.log("---- Build started: base " + base.label + ", " + p.picks.size() + " feature(s) to add ----");

        a.exec.execute(() -> {
            try {
                File out = Merger.run(a, p, new Merger.Sink() {
                    @Override public void step(int pct, String msg) {
                        a.ui.post(() -> {
                            bar.setProgress(pct);
                            tvStep.setText(msg);
                        });
                        a.log(msg);
                    }

                    @Override public void log(String line) {
                        a.ui.post(() -> {
                            tail.add(line);
                            while (tail.size() > 6) tail.remove(0);
                            StringBuilder tb = new StringBuilder();
                            for (String t : tail) tb.append(t).append('\n');
                            tvTail.setText(tb.toString().trim());
                        });
                        a.log(line);
                    }
                });
                a.ui.post(() -> finish(out, null, p));
            } catch (Throwable t) {
                StringBuilder sb = new StringBuilder(t.toString());
                for (StackTraceElement e : t.getStackTrace()) {
                    sb.append("\n   at ").append(e);
                    if (sb.length() > 2500) break;
                }
                a.log("BUILD FAILED: " + sb);
                a.ui.post(() -> finish(null, t, p));
            }
        });
    }

    private void finish(File out, Throwable err, Merger.Plan p) {
        building = false;
        btnBuild.setEnabled(true);
        cardProgress.setVisibility(View.GONE);
        cardResult.setVisibility(View.VISIBLE);
        if (err != null) {
            lastOut = null;
            btnInstall.setVisibility(View.GONE);
            btnShare.setVisibility(View.GONE);
            tvResult.setText("The build stopped: " + err.getMessage()
                    + "\n\nNothing was changed. The full details are on the Log tab; copy them from there if you need to report it.");
            return;
        }
        lastOut = out;
        btnInstall.setVisibility(View.VISIBLE);
        btnShare.setVisibility(View.VISIBLE);
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(Locale.US, "Done: %s (%.1f MB)\n", out.getName(), out.length() / 1048576.0));
        if (!p.picks.isEmpty()) {
            sb.append("\nAdded: ");
            for (int i = 0; i < p.picks.size(); i++) sb.append(i > 0 ? ", " : "").append(p.picks.get(i).feature.label);
            sb.append("\nFirst launch asks for \"Display over other apps\" if it is not allowed yet.\n");
        }
        sb.append("\nBefore installing: uninstall the original ").append(base.pkg)
                .append(" first. The new APK is signed with your own key, so Android will not update the original with it, and the merged app keeps the same package name.");
        tvResult.setText(sb.toString());
    }

    // ------------------------------------------------------------------ install / share
    private Uri uri() {
        return FileProvider.getUriForFile(a, a.getPackageName() + ".files", lastOut);
    }

    private void install() {
        if (lastOut == null) return;
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(a, "Allow installs from this app, then tap Install again", Toast.LENGTH_LONG).show();
            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())));
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri(), "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        a.startActivity(i);
    }

    private void share() {
        if (lastOut == null) return;
        Intent i = new Intent(Intent.ACTION_SEND)
                .setType("application/vnd.android.package-archive")
                .putExtra(Intent.EXTRA_STREAM, uri())
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        a.startActivity(Intent.createChooser(i, "Share merged APK"));
    }
}
