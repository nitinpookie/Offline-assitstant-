package com.chanit.featuremerger.bridge;

public class FmShim3 extends FmShimBase {
    @Override protected int slot() { return 3; }
}
