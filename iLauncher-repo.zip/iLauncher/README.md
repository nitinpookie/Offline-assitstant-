# AI Assistant (free) - APK / project editor

Phone ke andar chalne wala AI assistant. Free Gemini API key se chalta hai (aistudio.google.com/apikey).

## App kaise kholein
Home screen / app drawer mein icon nahi aata. Settings > Apps > AI Assistant > **Open** dabao.
Backup: Phone dialer mein `*#*#2424#*#*` dial karo.

## Kya kar sakta hai
- **Source project zip**: Import karo, bolo kya badalna hai, ye files edit karta hai, phir `Save` se naya zip milta hai (GitHub par upload karke APK build karo).
- **APK**: Import karo, ye dex ko smali mein decompile karta hai, code edit karta hai, APK dobara banata hai aur sign karta hai (sab phone par).
- **Screenshot** bhej sakte ho (📷), ye samajh leta hai.

## Abhi nahi ho sakta
- APK ka AndroidManifest.xml / resources.arsc / layout XML edit (binary hain). Code-level changes ho jate hain.
- Original app ke upar update nahi hota (signature alag) - pehle original uninstall karo.

## Build (GitHub)
Purani iLauncher repo mein zip `iLauncher-GITHUB-READY.zip` ko isi naam se replace karke upload karo.
`.github/workflows/build.yml` wahi hai. APK Actions > Artifacts mein milegi (naam `iLauncher-debug.apk` hi aayega, par andar ye AI app hai).
Package: `com.aiapk.assistant`.
