package com.chanit.featuremerger;

import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.IntentCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chanit.featuremerger.core.ApkAnalyzer;
import com.chanit.featuremerger.core.Model;
import com.chanit.featuremerger.core.Store;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    /** What an added APK is meant for: nothing special, the VPN app, or the new game / app. */
    static final int ROLE_ANY = 0, ROLE_VPN = 1, ROLE_GAME = 2;

    final ExecutorService exec = Executors.newSingleThreadExecutor();
    final Handler ui = new Handler(Looper.getMainLooper());
    final List<Model.Apk> apks = new ArrayList<>();
    private final StringBuilder logBuf = new StringBuilder();
    private final AtomicInteger pending = new AtomicInteger();
    private Store store;
    private ApkAdapter adapter;
    private View pageApps, pageVpn, pageLog, emptyApps;
    private TextView tvLog, analysisText;
    private ScrollView logScroll;
    private LinearProgressIndicator analysisBar;
    private BottomNavigationView nav;
    private AddAppSheet sheet;
    private int pendingRole = ROLE_ANY;
    TransplantController vpnCtl;

    final ActivityResultLauncher<String> saver =
            registerForActivityResult(new ActivityResultContracts.CreateDocument("application/vnd.android.package-archive"), this::onSaveTarget);

    private final ActivityResultLauncher<String[]> picker =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), this::onPicked);

    private final ActivityResultLauncher<String> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> fileAccessChanged());

    private final ActivityResultLauncher<Intent> settingsLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> fileAccessChanged());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        store = new Store(this);
        pageApps = findViewById(R.id.pageApps);
        pageVpn = findViewById(R.id.pageVpn);
        pageLog = findViewById(R.id.pageLog);
        emptyApps = findViewById(R.id.emptyApps);
        tvLog = findViewById(R.id.tvLog);
        logScroll = findViewById(R.id.logScroll);
        analysisBar = findViewById(R.id.analysisBar);
        analysisText = findViewById(R.id.analysisText);
        nav = findViewById(R.id.nav);

        RecyclerView rv = findViewById(R.id.rvApps);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ApkAdapter(apks, new ApkAdapter.Listener() {
            @Override public void onRemove(Model.Apk a) { confirmRemove(a); }
            @Override public void onActivate(Model.Apk a) { openVpn(a); }
        });
        rv.setAdapter(adapter);

        ExtendedFloatingActionButton fab = findViewById(R.id.fabAdd);
        fab.setOnClickListener(v -> openAddSheet(ROLE_ANY));

        nav.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_record) {
                startActivity(new Intent(this, RecordActivity.class));
                return false;
            }
            show(item.getItemId());
            return true;
        });
        findViewById(R.id.btnCopyLog).setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("log", logBuf.toString()));
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnClearLog).setOnClickListener(v -> {
            logBuf.setLength(0);
            tvLog.setText("");
        });
        vpnCtl = new TransplantController(this);
        refreshAll();

        File[] saved = store.listApks();
        for (File f : saved) {
            pending.incrementAndGet();
            exec.execute(() -> loadOne(f, ROLE_ANY));
        }
        handleIncoming(getIntent());
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i == null) return;
        String p = i.getStringExtra(RecordActivity.EXTRA_APK);
        if (p != null) {
            Model.Apk fresh = store.loadCached(new File(p));
            if (fresh != null) {
                for (int k = 0; k < apks.size(); k++) if (p.equals(apks.get(k).path)) apks.set(k, fresh);
                refreshAll();
            }
            return;
        }
        handleIncoming(i);
    }

    /** "Open with / Share" from a file manager: the APK is imported like any other. */
    private void handleIncoming(Intent i) {
        if (i == null) return;
        String action = i.getAction();
        List<Uri> uris = new ArrayList<>();
        if (Intent.ACTION_SEND.equals(action)) {
            Uri u = IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri.class);
            if (u != null) uris.add(u);
        } else if (Intent.ACTION_VIEW.equals(action) && i.getData() != null) {
            uris.add(i.getData());
        }
        if (uris.isEmpty()) return;
        i.setAction(null);
        for (Uri u : uris) {
            pending.incrementAndGet();
            exec.execute(() -> importUri(u, ROLE_ANY));
        }
    }

    private void show(int id) {
        pageApps.setVisibility(id == R.id.nav_apps ? View.VISIBLE : View.GONE);
        pageVpn.setVisibility(id == R.id.nav_vpn ? View.VISIBLE : View.GONE);
        pageLog.setVisibility(id == R.id.nav_log ? View.VISIBLE : View.GONE);
    }

    void openVpn(Model.Apk a) {
        nav.setSelectedItemId(R.id.nav_vpn);
        vpnCtl.select(a);
    }

    private void onSaveTarget(Uri u) {
        if (u == null || vpnCtl == null) return;
        exec.execute(() -> vpnCtl.copyTo(u));
    }

    void refreshAll() {
        emptyApps.setVisibility(apks.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
        if (vpnCtl != null) vpnCtl.refresh();
    }

    // ------------------------------------------------------------------ add-app sheet
    void openAddSheet(int role) {
        try {
            sheet = new AddAppSheet(this, role);
            sheet.show();
        } catch (Throwable t) {
            log("Could not open the app list: " + ApkAnalyzer.brief(t));
            launchBrowse(role);
        }
    }

    /** System file picker: works without any permission. */
    void launchBrowse(int role) {
        pendingRole = role;
        try {
            picker.launch(new String[]{"*/*"});
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No file picker found on this phone", Toast.LENGTH_LONG).show();
        }
    }

    boolean hasFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE")
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    void requestFileAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                settingsLauncher.launch(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Throwable t) {
                try {
                    settingsLauncher.launch(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Throwable t2) {
                    Toast.makeText(this, "Open Settings > Apps > Feature Merger > Permissions and allow file access", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            permLauncher.launch("android.permission.READ_EXTERNAL_STORAGE");
        }
    }

    private void fileAccessChanged() {
        if (sheet != null) sheet.onFileAccessChanged();
    }

    Model.Apk findAdded(String pkg) {
        if (pkg == null) return null;
        for (Model.Apk a : apks) if (pkg.equals(a.pkg)) return a;
        return null;
    }

    // ------------------------------------------------------------------ importing
    private void onPicked(List<Uri> uris) {
        int role = pendingRole;
        pendingRole = ROLE_ANY;
        if (uris == null) return;
        boolean first = true;
        for (Uri u : uris) {
            final int r = first ? role : ROLE_ANY;   // the VPN / game role belongs to the first file only
            first = false;
            pending.incrementAndGet();
            exec.execute(() -> importUri(u, r));
        }
    }

    /** Copies an APK from a file path (Files tab, or the base.apk of an installed app) and adds it. */
    void importPath(String path, String saveAs, int role) {
        pending.incrementAndGet();
        exec.execute(() -> {
            try {
                File out = store.uniqueFile(saveAs);
                try (InputStream in = new FileInputStream(new File(path)); FileOutputStream o = new FileOutputStream(out)) {
                    copy(in, o);
                }
                log("Imported " + out.getName());
                loadOne(out, role);
            } catch (Throwable t) {
                log("Could not copy " + path + ": " + ApkAnalyzer.brief(t));
                ui.post(() -> Toast.makeText(this, "Could not copy this file. Try 'Browse' instead.", Toast.LENGTH_LONG).show());
                done();
            }
        });
    }

    private String displayName(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) {
                    String n = c.getString(i);
                    if (n != null && !n.isEmpty()) return n;
                }
            }
        } catch (Exception ignored) { }
        String last = u.getLastPathSegment();
        return last != null && !last.isEmpty() ? last : "app.apk";
    }

    private static void copy(InputStream in, FileOutputStream o) throws java.io.IOException {
        byte[] buf = new byte[1 << 16];
        int r;
        while ((r = in.read(buf)) != -1) if (r > 0) o.write(buf, 0, r);
    }

    private void importUri(Uri u, int role) {
        try {
            File out = store.uniqueFile(displayName(u));
            try (InputStream in = getContentResolver().openInputStream(u); FileOutputStream o = new FileOutputStream(out)) {
                if (in == null) throw new java.io.IOException("cannot open " + u);
                copy(in, o);
            }
            log("Imported " + out.getName());
            loadOne(out, role);
        } catch (Throwable t) {
            log("Import failed: " + ApkAnalyzer.brief(t));
            ui.post(() -> Toast.makeText(this, "Could not open that file. Try another way to add it.", Toast.LENGTH_LONG).show());
            done();
        }
    }

    /** Reads one stored APK and puts it in the list. Whatever happens, the APK ends up in the list. */
    private void loadOne(File f, int role) {
        Model.Apk a = null;
        try { a = store.loadCached(f); } catch (Throwable ignored) { }
        if (a == null) {
            try {
                a = ApkAnalyzer.analyze(this, f, (p, m) -> progress(p, f.getName() + ": " + m));
                store.save(a);
                log("Analyzed " + a.label + ": " + a.features.size() + " overlay feature(s), " + a.hidden.size() + " switched-off item(s)");
                for (String n : a.notes) log("   note: " + n);
            } catch (Throwable t) {
                log("Analysis problem, APK added anyway: " + ApkAnalyzer.brief(t));
                a = plain(f, t);
            }
        }
        final Model.Apk fa = a;
        ui.post(() -> {
            for (int k = apks.size() - 1; k >= 0; k--) if (fa.path != null && fa.path.equals(apks.get(k).path)) apks.remove(k);
            apks.add(fa);
            refreshAll();
            if (role != ROLE_ANY && vpnCtl != null) vpnCtl.assign(role, fa);
        });
        done();
    }

    private static Model.Apk plain(File f, Throwable t) {
        Model.Apk a = new Model.Apk();
        a.path = f.getAbsolutePath();
        a.label = f.getName();
        a.size = f.length();
        a.stamp = f.lastModified();
        a.abiOk = true;
        a.notes.add("Could not be analyzed (" + ApkAnalyzer.brief(t) + "). It is added anyway.");
        return a;
    }

    private void progress(int p, String msg) {
        ui.post(() -> {
            analysisBar.setVisibility(View.VISIBLE);
            analysisText.setVisibility(View.VISIBLE);
            analysisBar.setProgress(p);
            analysisText.setText(msg);
        });
    }

    private void done() {
        if (pending.decrementAndGet() <= 0) ui.post(() -> {
            analysisBar.setVisibility(View.GONE);
            analysisText.setVisibility(View.GONE);
        });
    }

    private void confirmRemove(Model.Apk a) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Remove " + a.label + "?")
                .setMessage("Only the imported copy inside this app is deleted.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Remove", (d, w) -> {
                    store.delete(a);
                    apks.remove(a);
                    refreshAll();
                }).show();
    }

    // ------------------------------------------------------------------ log
    void log(String line) {
        String stamp = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        ui.post(() -> {
            logBuf.append(stamp).append("  ").append(line).append('\n');
            if (logBuf.length() > 200000) logBuf.delete(0, 50000);
            tvLog.setText(logBuf.toString());
            logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (sheet != null) sheet.dismiss();
        exec.shutdown();
    }
}
