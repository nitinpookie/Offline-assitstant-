package com.liveedit.patcher;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Writes the edited timer delays into the code files of the APK (same length, so nothing else moves). */
final class TimerPatch {

    private TimerPatch() {}

    /**
     * Returns the changed dex files by entry name. done gets one line per edit that worked, failed one per edit that
     * could not be applied (the app is then left as it was for that edit).
     */
    static Map<String, byte[]> apply(File apk, Map<String, Long> edits, List<String> done, List<String> failed)
            throws Exception {
        Map<String, byte[]> out = new LinkedHashMap<String, byte[]>();
        if (edits.isEmpty()) return out;
        Map<String, List<Map.Entry<String, Long>>> byDex = new LinkedHashMap<String, List<Map.Entry<String, Long>>>();
        for (Map.Entry<String, Long> e : edits.entrySet()) {
            String[] k = e.getKey().split(":");
            if (k.length < 3) {
                failed.add("bad edit " + e.getKey());
                continue;
            }
            List<Map.Entry<String, Long>> l = byDex.get(k[0]);
            if (l == null) {
                l = new ArrayList<Map.Entry<String, Long>>();
                byDex.put(k[0], l);
            }
            l.add(e);
        }
        ZipFile z = new ZipFile(apk);
        try {
            for (Map.Entry<String, List<Map.Entry<String, Long>>> d : byDex.entrySet()) {
                ZipEntry ze = z.getEntry(d.getKey());
                if (ze == null) {
                    failed.add(d.getKey() + " is not in this APK (edits are for another app version)");
                    continue;
                }
                byte[] dex = read(z.getInputStream(ze));
                // find the places again, so each edit is checked against the real code
                List<TimerScan.Hit> hits = new ArrayList<TimerScan.Hit>();
                TimerScan.scan(d.getKey(), dex, hits);
                boolean changed = false;
                for (Map.Entry<String, Long> e : d.getValue()) {
                    TimerScan.Hit h = null;
                    for (TimerScan.Hit x : hits) {
                        if (x.editable && x.key().equals(e.getKey())) h = x;
                    }
                    if (h == null) {
                        failed.add(e.getKey() + ": place not found (edits are for another app version)");
                        continue;
                    }
                    String why = TimerScan.patch(dex, h, e.getValue().longValue());
                    if (why.length() == 0) {
                        changed = true;
                        if (h.type == 2) {
                            done.add(h.label.replaceFirst("^BEEP: ", "") + ": sound removed");
                        } else if (h.type == 1) {
                            done.add(h.label.replaceAll(", nearby number.*", "") + ": " + h.asFloat() + " -> "
                                    + Float.intBitsToFloat((int) e.getValue().longValue()));
                        } else {
                            done.add(h.label.replaceAll(" ~ .*", "") + ": " + h.value + " ms -> "
                                    + (e.getValue().longValue() < 0 ? "never" : e.getValue() + " ms"));
                        }
                    } else {
                        failed.add(h.label + ": " + why);
                    }
                }
                if (changed) {
                    TimerScan.fixHeader(dex);
                    out.put(d.getKey(), dex);
                }
            }
        } finally {
            z.close();
        }
        return out;
    }

    private static byte[] read(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream(1 << 20);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return b.toByteArray();
        } finally {
            in.close();
        }
    }
}
