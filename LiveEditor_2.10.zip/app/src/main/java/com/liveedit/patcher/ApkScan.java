package com.liveedit.patcher;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Looks inside an APK (without changing it): CPU types, dex files, and the server addresses written in it. */
final class ApkScan {

    static final class Result {
        final Set<String> abis = new LinkedHashSet<String>();
        int dexCount;
        long dexBytes;
        int entries;
        int nativeLibs;
        /** Server host names found inside the app, most used first. */
        final List<String> hosts = new ArrayList<String>();
        final Map<String, Integer> hostCount = new HashMap<String, Integer>();
        /** Places in the app's code that start something after a delay (timers), best guesses first. */
        final List<String> timers = new ArrayList<String>();
        /** The same places with their exact position, so a delay can be edited. */
        final List<TimerScan.Hit> hits = new ArrayList<TimerScan.Hit>();
    }

    private static final Pattern DEX = Pattern.compile("classes\\d*\\.dex");
    private static final Pattern TEXT_EXT = Pattern.compile(".*\\.(json|txt|xml|js|html|htm|properties|cfg|conf|yml|yaml|ini|csv)$");

    private static final String[] IGNORE_EXACT = {
            "schemas.android.com", "www.w3.org", "w3.org", "xmlpull.org", "www.xmlpull.org", "schemas.microsoft.com",
            "ns.adobe.com", "www.apache.org", "apache.org", "localhost", "example.com", "www.example.com",
            "purl.org", "java.sun.com", "xml.org", "developer.android.com", "source.android.com",
            "www.android.com", "android.com", "issuetracker.google.com", "www.googleapis.com.invalid"
    };
    private static final String[] IGNORE_SUFFIX = {".w3.org", ".apache.org", ".xmlpull.org", ".example.com", ".invalid"};

    private ApkScan() {}

    static Result scan(File apk) throws Exception {
        Result r = new Result();
        Map<String, Integer> counts = new HashMap<String, Integer>();
        long budget = 200L * 1024 * 1024;
        ZipFile z = new ZipFile(apk);
        try {
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String n = e.getName();
                r.entries++;
                if (n.startsWith("lib/")) {
                    int s = n.indexOf('/', 4);
                    if (s > 4) {
                        r.abis.add(n.substring(4, s));
                        r.nativeLibs++;
                    }
                    continue;
                }
                boolean dex = DEX.matcher(n).matches();
                if (dex) {
                    r.dexCount++;
                    r.dexBytes += Math.max(0, e.getSize());
                }
                boolean scan = dex || n.equals("resources.arsc")
                        || ((n.startsWith("assets/") || n.startsWith("res/raw/"))
                        && e.getSize() >= 0 && e.getSize() <= 3L * 1024 * 1024
                        && TEXT_EXT.matcher(n.toLowerCase(Locale.US)).matches());
                if (!scan) continue;
                long size = e.getSize();
                if (size < 0 || size > 80L * 1024 * 1024 || budget < size) continue;
                budget -= size;
                byte[] data = readAll(z.getInputStream(e), (int) size);
                findHosts(data, data.length, counts);
                if (dex) TimerScan.scan(n, data, r.hits);
            }
        } finally {
            z.close();
        }
        TimerScan.sort(r.hits);
        r.timers.clear();
        for (int i = 0; i < r.hits.size(); i++) r.timers.add(r.hits.get(i).label);
        r.hostCount.putAll(counts);
        r.hosts.addAll(counts.keySet());
        final Map<String, Integer> cc = counts;
        Collections.sort(r.hosts, new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                int d = cc.get(b).intValue() - cc.get(a).intValue();
                return d != 0 ? d : a.compareTo(b);
            }
        });
        while (r.hosts.size() > 200) r.hosts.remove(r.hosts.size() - 1);
        return r;
    }

    private static byte[] readAll(InputStream in, int expected) throws Exception {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(expected, 1024));
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    /** Finds http(s):// and ws(s):// addresses in raw bytes (dex strings, resources and text files are plain ASCII/UTF-8). */
    static void findHosts(byte[] d, int len, Map<String, Integer> out) {
        for (int i = 3; i + 8 < len; i++) {
            if (d[i] != ':' || d[i + 1] != '/' || d[i + 2] != '/') continue;
            int s = i;
            while (s > 0 && i - s < 6 && isAlpha(d[s - 1])) s--;
            String scheme = new String(d, s, i - s, StandardCharsets.ISO_8859_1).toLowerCase(Locale.US);
            if (!scheme.equals("http") && !scheme.equals("https") && !scheme.equals("ws") && !scheme.equals("wss")) continue;
            int h = i + 3;
            int e = h;
            while (e < len && e - h < 100 && isHostChar(d[e])) e++;
            String host = new String(d, h, e - h, StandardCharsets.ISO_8859_1).toLowerCase(Locale.US);
            while (host.endsWith(".") || host.endsWith("-")) host = host.substring(0, host.length() - 1);
            if (!validHost(host) || ignored(host)) continue;
            Integer c = out.get(host);
            out.put(host, Integer.valueOf(c == null ? 1 : c.intValue() + 1));
        }
    }

    static boolean validHost(String h) {
        if (h.length() < 4 || h.startsWith(".") || h.startsWith("-") || h.indexOf("..") >= 0) return false;
        int dot = h.lastIndexOf('.');
        if (dot < 1) return false;
        String tld = h.substring(dot + 1);
        boolean allDigits = true;
        for (int i = 0; i < tld.length(); i++) {
            char c = tld.charAt(i);
            if (c < '0' || c > '9') allDigits = false;
        }
        if (allDigits) return h.split("\\.").length == 4; // IPv4
        if (tld.length() < 2 || tld.length() > 24) return false;
        for (int i = 0; i < tld.length(); i++) {
            char c = tld.charAt(i);
            if (c < 'a' || c > 'z') return false;
        }
        return true;
    }

    private static boolean ignored(String h) {
        for (int i = 0; i < IGNORE_EXACT.length; i++) if (h.equals(IGNORE_EXACT[i])) return true;
        for (int i = 0; i < IGNORE_SUFFIX.length; i++) if (h.endsWith(IGNORE_SUFFIX[i])) return true;
        return h.startsWith("127.") || h.startsWith("0.0.0.0") || h.startsWith("10.") || h.startsWith("192.168.");
    }

    private static boolean isAlpha(byte b) {
        return (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z');
    }

    private static boolean isHostChar(byte b) {
        return (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') || b == '.' || b == '-';
    }
}
