package com.liveedit.agent;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import java.util.regex.Pattern;

/**
 * Everything that is changed on screen after the app has drawn it: floating overlay windows (menus, buttons, icons)
 * and, for theme / names / timers / per-item rules, the normal app screens too.
 *
 * Every view is remembered once, in its ORIGINAL state ({@link Orig}). What should be on screen is always computed
 * from that original plus the global settings and the per-item {@link Rules.Rule}, so moving a slider back (or
 * clearing a rule) restores the app. A view that nothing asks to change is never touched.
 *
 * Floating buttons and menus are separate on purpose: "button" size/opacity settings never reach a menu window.
 */
final class Overlays {

    /** The original state of one view, plus what we changed on it. */
    static final class Orig {
        String key;
        boolean isRoot;
        boolean overlay;
        /** Roots only: "menu", "button", "icon" or "app". */
        String kind;
        int lw, lh, ml, mt, mr, mb, pl, pt, pr, pb;
        /** positive base sizes in px used for scaling (0 = wrap/match, cannot be scaled directly). */
        int bw, bh;
        /** size on screen when first seen. */
        int mw, mh;
        float alpha = 1f;
        float winAlpha = 1f;
        float textPx;
        CharSequence text;
        ColorStateList tcl;
        Drawable bg;
        int vis;
        /** A full screen app window (never removed), and whether we made this window untouchable while hidden. */
        boolean screen;
        /** Window hide state (a removed interface): what we added / removed so it can be put back exactly. */
        boolean winHidden, dimWas;
        int flagsAdded;
        float alphaWas = 1f;
        int hideFails;
        /** Same as key but without any text (a toggle changes its text): kept for finding the same item again. */
        String lk;
        long lastStroke;
        /** original position inside the parent, and whether the content of this window is scaled by transform */
        int ol, ot;
        boolean xformed;
        boolean layDirty, alphaDirty, tsDirty, tcDirty, textDirty, bgDirty, tintDirty, hidden, timerHit;
        /** Timer detection: last value of this text, how often it changed lately, and when. */
        String tSeen;
        int tChanges;
        long tAt;
        String lastSet;
        Drawable ours;
        int oursColor;
        int tintColor;
        /** The background colour we put on this view (theme or rule), or NONE: used to pick a readable text colour. */
        int appliedBg = Rules.NONE;
        /** Pictures: the original scale type, whether we changed it, and the picture we put in (and what was there). */
        ImageView.ScaleType scaleType;
        boolean scaleDirty;
        Drawable imgOrig;
        Drawable iconOurs;
        String iconSrc;
        boolean iconDirty;
        /** Original size of the picture (px), kept so a replacement picture takes exactly the old place. */
        int idw, idh;
        /** Compound drawables (icons in front of a text): the originals, their sizes, and whether we changed them. */
        Drawable[] cdOrig;
        int[] cdW, cdH;
        Drawable cdIcon;
        boolean cdDirty;
        /** Loop guard: how often the app undid our text / background within the last second, and the give-up flags. */
        int tFights, bFights;
        long tFightT0, bFightT0;
        boolean giveText, giveBg;
        /** What was last noted for the edit guard, per category. */
        int[] sig;
    }

    /** A category of this item was applied or changed: tell the edit guard (only when its value really changed). */
    private static void sig(Orig o, int cat, int hash) {
        if (o.sig == null) o.sig = new int[EditGuard.CATS.length];
        int h = hash * 31 + 7;
        if (o.sig[cat] != h) {
            o.sig[cat] = h;
            EditGuard.note(o.key, cat);
        }
    }

    private static void noteEdits(Orig o, Rules.Rule r) {
        if (r == null) return;
        if (r.alpha != Rules.NONE) sig(o, EditGuard.ALPHA, r.alpha);
        if (r.w != Rules.NONE || r.h != Rules.NONE) sig(o, EditGuard.SIZE, r.w * 31 + r.h);
        if (r.textColor != Rules.NONE || r.bgColor != Rules.NONE) sig(o, EditGuard.COLOR, r.textColor * 31 + r.bgColor);
        if (r.thick != Rules.NONE) sig(o, EditGuard.LINE, r.thick);
        if (r.quiet) sig(o, EditGuard.SOUND, 1);
        if (r.icon != null) sig(o, EditGuard.ICON, r.icon.hashCode());
        if (r.name != null || r.text != Rules.NONE) {
            sig(o, EditGuard.TEXT, (r.name == null ? 0 : r.name.hashCode()) * 31 + r.text);
        }
    }

    /**
     * Sets a text without letting the app's own TextWatchers hear about it (an app that reacts to its texts changing,
     * for example by reading them back or setting them again, is the usual reason a renamed text crashes it).
     */
    private static Field fTextListeners;
    private static boolean textListenersFailed;

    private static void setTextQuiet(TextView tv, CharSequence text) {
        Object saved = null;
        boolean swapped = false;
        if (!textListenersFailed) {
            try {
                if (fTextListeners == null) {
                    fTextListeners = TextView.class.getDeclaredField("mListeners");
                    fTextListeners.setAccessible(true);
                }
                saved = fTextListeners.get(tv);
                if (saved != null) {
                    fTextListeners.set(tv, null);
                    swapped = true;
                }
            } catch (Throwable t) {
                textListenersFailed = true;
            }
        }
        try {
            tv.setText(text);
        } finally {
            if (swapped) {
                try {
                    fTextListeners.set(tv, saved);
                } catch (Throwable t) {
                    // ignore
                }
            }
        }
    }

    /** One entry of the editor's list. */
    static final class El {
        View view;
        Orig o;
        String name = "";
        String sub = "";
        /** "menu", "button", "icon" or "app" (children belong to the group of their window). */
        String group = "app";
        boolean root;
        boolean isText;
        boolean isImage;
        /** a thin line (window or view): gets a thickness slider that may go thinner or thicker */
        boolean line;
        int wDp, hDp;
        /** original size and text size in dp (before any change of ours), used as the lowest slider value */
        int owDp, ohDp, otDp;
    }

    /** One window (menu, floating button, popup, dialog, screen) in the "Interfaces" list. */
    static final class Win {
        View root;
        Orig o;
        String name = "";
        String sub = "";
        String kind = "";
        boolean gone;
        /** Removing this one closed the app (or failed) before: it is kept visible. */
        boolean unsafe;
        /** Bringing this one BACK closed the app before: it is kept removed, never auto-restored again. */
        boolean unsafeShow;
        /** The main screen of the app: it can be styled but never removed. */
        boolean locked;
        /** A small picture of the window as it looks now (null when closed or not drawable). */
        android.graphics.Bitmap thumb;
    }

    private static final class Pass {
        float f = 1f;
        float d = 1f;
        boolean overlay;
        int textPct = 100;
        int textDelta;
        float lineDp;
        int budget = 3000;
        /** An item above this one has "No beep": everything inside it is quiet too. */
        boolean quiet;
    }

    private static final WeakHashMap<View, Orig> ORIG = new WeakHashMap<View, Orig>();
    private static final WeakHashMap<View, Boolean> HOOKED = new WeakHashMap<View, Boolean>();
    /** Counts every real change we make to a view, so a frame that was changed can be redrawn before it is shown. */
    private static int mods;
    /** The first small floating window of the app is its menu icon (launcher); the others are buttons. */
    private static boolean launcherTaken;
    /** Every window that was ever seen (key -> name, kind, sub), so a popup can be removed while it is closed. */
    private static final java.util.LinkedHashMap<String, String[]> SEEN = new java.util.LinkedHashMap<String, String[]>();

    private static final Pattern CLOCK = Pattern.compile("^\\D{0,24}(\\d{1,3}\\s*:\\s*){1,2}\\d{1,2}\\D{0,12}$");
    private static final Pattern UNIT = Pattern.compile(
            "(?i)\\d+\\s*(days?|d|hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b");
    private static final Pattern WORD = Pattern.compile(
            "(?i)(left|remaining|remain|expire|expires|expiry|valid|ends|timer|countdown)");
    /** Things that look like a clock but are not a countdown: "10:30 AM", "2025-11-04", "12/05/24". */
    private static final Pattern AMPM = Pattern.compile("(?i)\\b[ap]\\.?\\s?m\\b");
    private static final Pattern DATE = Pattern.compile("\\d{1,4}\\s*[/.-]\\s*\\d{1,2}\\s*[/.-]\\s*\\d{1,4}");

    private Overlays() {}

    // ---- windows -----------------------------------------------------------------------------

    /** All window root views of this process, or an empty list if Android does not allow reading them. */
    static List<View> roots() {
        ArrayList<View> out = new ArrayList<View>();
        try {
            Class<?> c = Class.forName("android.view.WindowManagerGlobal");
            Object g = c.getMethod("getInstance").invoke(null);
            Field f = c.getDeclaredField("mViews");
            f.setAccessible(true);
            Object o = f.get(g);
            if (o instanceof List) {
                List<Object> copy = new ArrayList<Object>((List<?>) o);
                for (int i = 0; i < copy.size(); i++) {
                    if (copy.get(i) instanceof View) out.add((View) copy.get(i));
                }
            }
        } catch (Throwable t) {
            U.err("cannot read app windows", t);
        }
        if (out.isEmpty()) {
            View d = Agent.topDecor();
            if (d != null) out.add(d);
        }
        return out;
    }

    static boolean isOverlay(View root) {
        ViewGroup.LayoutParams lp = root.getLayoutParams();
        if (!(lp instanceof WindowManager.LayoutParams)) return false;
        int t = ((WindowManager.LayoutParams) lp).type;
        return t >= 2000 && t < 3000 && t != 2005; // system-level windows, not toasts
    }

    /** Called about once a second, and right after something is changed in the editor. */
    static void tick(Context ctx) {
        if (!Config.needsTicker()) return;
        try {
            List<View> all = roots();
            for (int i = 0; i < all.size(); i++) {
                View r = all.get(i);
                if (Panel.isOwn(r)) continue;
                try {
                    if (Config.mute) mute(r);
                    hook(r);
                    handleRoot(ctx, r);
                } catch (Throwable t) {
                    U.err("window apply", t);
                }
            }
        } catch (Throwable t) {
            U.err("tick", t);
        }
    }

    // ---- no flicker: change a window before its first frame, and before every later frame ------

    /** A window list that tells us the moment the app adds a window, so it is changed before it is ever drawn. */
    private static final class Watched extends ArrayList<View> {
        private static final long serialVersionUID = 1L;

        Watched(List<View> from) {
            super(from);
        }

        @Override
        public boolean add(View v) {
            boolean r = super.add(v);
            added(v);
            return r;
        }

        @Override
        public void add(int i, View v) {
            super.add(i, v);
            added(v);
        }
    }

    private static void added(View v) {
        try {
            if (v != null && Config.needsTicker() && !Panel.isOwn(v)) hook(v);
        } catch (Throwable t) {
            U.err("window added", t);
        }
    }

    /** The window list we installed (same order as the list of window params). */
    private static Watched viewList;

    /**
     * The list of window params. When the app calls updateViewLayout (for example to refresh a floating button when
     * an option is switched), Android stores the app's own params here a moment before the window is laid out again:
     * the size and opacity we want are written into those params right now, so the original look is never shown, not
     * even for one frame (that was the small flicker of a button's icon).
     */
    private static final class WatchedParams extends ArrayList<WindowManager.LayoutParams> {
        private static final long serialVersionUID = 1L;

        WatchedParams(List<WindowManager.LayoutParams> from) {
            super(from);
        }

        @Override
        public boolean add(WindowManager.LayoutParams p) {
            boolean r = super.add(p);
            fix(size() - 1, p);
            return r;
        }

        @Override
        public void add(int i, WindowManager.LayoutParams p) {
            super.add(i, p);
            fix(i, p);
        }

        private void fix(int index, WindowManager.LayoutParams p) {
            try {
                Watched views = viewList;
                if (views == null || p == null || views.size() != size() || index < 0 || index >= views.size()) return;
                View v = views.get(index);
                if (v == null || Panel.isOwn(v) || !Config.needsTicker()) return;
                Orig ro = ORIG.get(v);
                if (ro == null || !ro.overlay || ro.screen) return;
                if (!EditGuard.ready()) return;
                Rules.Rule rr = EditGuard.mask(ro.key, Rules.get(ro.key));
                boolean removed = rr != null && rr.hide;
                planWindow(v.getContext(), v, ro, rr, removed, p);
                if (removed || ro.winHidden) hideParams(ro, removed, p);
            } catch (Throwable t) {
                U.err("window params", t);
            }
        }
    }

    /** Called once at start: from now on new windows are noticed at once (the 0.7 s timer stays as a safety net). */
    static void watchWindows() {
        try {
            Class<?> c = Class.forName("android.view.WindowManagerGlobal");
            Object g = c.getMethod("getInstance").invoke(null);
            Field f = c.getDeclaredField("mViews");
            f.setAccessible(true);
            Object o = f.get(g);
            if (o instanceof Watched || !(o instanceof ArrayList)) return;
            ArrayList<View> copy = new ArrayList<View>();
            for (Object x : (ArrayList<?>) o) {
                if (x instanceof View) copy.add((View) x);
            }
            Watched w = new Watched(copy);
            f.set(g, w);
            viewList = w;
            for (int i = 0; i < copy.size(); i++) hook(copy.get(i));
            try {
                Field fp = c.getDeclaredField("mParams");
                fp.setAccessible(true);
                Object po = fp.get(g);
                if (po instanceof ArrayList && !(po instanceof WatchedParams)) {
                    ArrayList<WindowManager.LayoutParams> pc = new ArrayList<WindowManager.LayoutParams>();
                    boolean ok = true;
                    for (Object x : (ArrayList<?>) po) {
                        if (x instanceof WindowManager.LayoutParams) pc.add((WindowManager.LayoutParams) x);
                        else ok = false;
                    }
                    if (ok && pc.size() == copy.size()) fp.set(g, new WatchedParams(pc));
                }
            } catch (Throwable t) {
                U.err("cannot watch window params (the pre-draw fix still works)", t);
            }
        } catch (Throwable t) {
            U.err("cannot watch windows (the timer still works)", t);
        }
    }

    static void hook(final View root) {
        if (root == null || Panel.isOwn(root) || HOOKED.containsKey(root)) return;
        HOOKED.put(root, Boolean.TRUE);
        try {
            root.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                private int cancels;
                private long last;

                @Override
                public boolean onPreDraw() {
                    try {
                        if (!Config.needsTicker() || Panel.isOwn(root)) return true;
                        boolean screen = isScreen(root);
                        long now = SystemClock.uptimeMillis();
                        if (screen && now - last < 120L) return true; // big app screens: not on every frame
                        last = now;
                        int before = mods;
                        handleRoot(root.getContext(), root);
                        if (mods != before && !screen && cancels < 3) {
                            cancels++;
                            return false; // changed: draw again so the unchanged look is never shown
                        }
                        cancels = 0;
                    } catch (Throwable t) {
                        U.err("pre-draw", t);
                    }
                    return true;
                }
            });
        } catch (Throwable t) {
            U.err("hook window", t);
        }
    }

    /** The window of an activity (a full app screen), as opposed to dialogs, popups and floating overlays. */
    static boolean isScreen(View root) {
        if (isOverlay(root)) return false;
        ViewGroup.LayoutParams lp = root.getLayoutParams();
        if (lp instanceof WindowManager.LayoutParams) {
            int type = ((WindowManager.LayoutParams) lp).type;
            // An activity's own window has this type. (On Android 8+ its view context is NOT the Activity, so the
            // context check below alone missed it and the main screen could be "removed", which closes the app.)
            if (type == WindowManager.LayoutParams.TYPE_BASE_APPLICATION) return true;
            if (type >= 1000) return false;
        }
        return root.getContext() instanceof Activity;
    }

    private static void mute(View v) {
        if (v.isSoundEffectsEnabled()) v.setSoundEffectsEnabled(false);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) mute(g.getChildAt(i));
        }
    }

    // ---- remembering views -------------------------------------------------------------------

    private static void capture(View v, Orig o) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        o.lw = lp == null ? ViewGroup.LayoutParams.WRAP_CONTENT : lp.width;
        o.lh = lp == null ? ViewGroup.LayoutParams.WRAP_CONTENT : lp.height;
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
            o.ml = m.leftMargin;
            o.mt = m.topMargin;
            o.mr = m.rightMargin;
            o.mb = m.bottomMargin;
        }
        o.pl = v.getPaddingLeft();
        o.pt = v.getPaddingTop();
        o.pr = v.getPaddingRight();
        o.pb = v.getPaddingBottom();
        o.mw = v.getWidth();
        o.mh = v.getHeight();
        o.ol = v.getLeft();
        o.ot = v.getTop();
        o.bw = (lp != null && lp.width > 0) ? lp.width : 0;
        o.bh = (lp != null && lp.height > 0) ? lp.height : 0;
        // Images (and single-view windows) that wrap their picture: use the size they have now.
        if (v instanceof ImageView || (o.isRoot && !(v instanceof ViewGroup))) {
            if (o.bw <= 0 && v.getWidth() > 0) o.bw = v.getWidth();
            if (o.bh <= 0 && v.getHeight() > 0) o.bh = v.getHeight();
        }
        o.alpha = v.getAlpha();
        o.vis = v.getVisibility();
        o.bg = v.getBackground();
        if (v instanceof ImageView) {
            Drawable d0 = ((ImageView) v).getDrawable();
            if (d0 != null) {
                o.idw = d0.getIntrinsicWidth();
                o.idh = d0.getIntrinsicHeight();
            }
        }
        if (v instanceof TextView) {
            TextView t = (TextView) v;
            o.textPx = t.getTextSize();
            o.text = t.getText();
            o.tcl = t.getTextColors();
        }
    }

    private static Orig rootOrig(View root, boolean overlay) {
        Orig o = ORIG.get(root);
        if (o != null) return o;
        o = new Orig();
        o.isRoot = true;
        o.overlay = overlay;
        capture(root, o);
        ViewGroup.LayoutParams lp = root.getLayoutParams();
        if (lp instanceof WindowManager.LayoutParams) o.winAlpha = ((WindowManager.LayoutParams) lp).alpha;
        String where = overlay ? "" : activityName(root.getContext());
        o.key = (overlay ? "ov:" : "app:") + where + ":" + root.getClass().getSimpleName() + ":"
                + norm(firstText(root, 0));
        o.lk = (overlay ? "ov:" : "app:") + where + ":" + root.getClass().getSimpleName();
        o.screen = !overlay && isScreen(root);
        o.kind = overlay ? classify(root) : "app";
        ORIG.put(root, o);
        return o;
    }

    private static Orig childOrig(View v, Orig parent, int idx) {
        Orig o = ORIG.get(v);
        if (o != null) return o;
        String parentKey = parent.key;
        o = new Orig();
        capture(v, o);
        o.lk = (parent.lk == null ? parentKey : parent.lk) + "/" + idx + v.getClass().getSimpleName();
        String t = null;
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null) t = cs.toString();
        }
        if (t == null || t.trim().length() == 0) {
            CharSequence cd = v.getContentDescription();
            if (cd != null) t = cd.toString();
        }
        o.key = parentKey + "/" + idx + v.getClass().getSimpleName() + ":" + norm(t);
        ORIG.put(v, o);
        return o;
    }

    /** Text without digits (so a ticking clock keeps the same key), lower case, short. */
    static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (Character.isDigit(ch)) continue;
            b.append(Character.toLowerCase(ch));
            if (b.length() >= 20) break;
        }
        return b.toString().trim();
    }

    private static String activityName(Context c) {
        int guard = 0;
        while (c instanceof ContextWrapper && guard++ < 8) {
            if (c instanceof Activity) return c.getClass().getSimpleName();
            c = ((ContextWrapper) c).getBaseContext();
        }
        return c == null ? "" : c.getClass().getSimpleName();
    }

    private static String firstText(View v, int depth) {
        if (depth > 8) return null;
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null && cs.toString().trim().length() > 0) return cs.toString();
        }
        CharSequence cd = v.getContentDescription();
        if (cd != null && cd.toString().trim().length() > 0) return cd.toString();
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount() && i < 30; i++) {
                String s = firstText(g.getChildAt(i), depth + 1);
                if (s != null) return s;
            }
        }
        return null;
    }

    /**
     * A window with many views is a menu; a thin one without text is a line; a screen-sized one without text is a
     * canvas (drawn by the app, never scaled); the first small window is the menu icon; the rest are buttons.
     */
    private static String classify(View root) {
        int[] n = new int[2]; // views, texts
        count(root, n, 0);
        int w = root.getWidth(), h = root.getHeight();
        android.util.DisplayMetrics dm = root.getResources().getDisplayMetrics();
        if (n[0] >= 7) return "menu";
        if (n[1] == 0 && w > 0 && h > 0) {
            int thin = Math.min(w, h), long_ = Math.max(w, h);
            if (thin <= Math.round(10 * dm.density) && long_ >= 4 * thin) return "line";
            if (w >= dm.widthPixels * 0.8f && h >= dm.heightPixels * 0.8f) return "canvas";
        }
        if (!launcherTaken) {
            launcherTaken = true;
            return "icon";
        }
        return "button";
    }

    private static void count(View v, int[] n, int depth) {
        if (depth > 12 || n[0] > 200) return;
        n[0]++;
        if (v instanceof TextView && ((TextView) v).getText() != null
                && ((TextView) v).getText().length() > 0) n[1]++;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) count(g.getChildAt(i), n, depth + 1);
        }
    }

    // ---- applying ---------------------------------------------------------------------------

    /** What one overlay window should look like now, and what the walk over its views needs to know. */
    private static final class Plan {
        boolean changed;
        float f = 1f;
        boolean xform;
        int textPct = 100;
        int textDelta;
        float lineDp;
        boolean line;
        boolean canvas;
    }

    /**
     * Works out the size and opacity of an overlay window from its ORIGINAL state, the settings of its group and the
     * rule of the item, and writes them into wlp (changed = true when something differs). It does not talk to the
     * window manager: the caller does (handleRoot), or nobody has to because the params are about to be used anyway
     * (the hook on the app's own updateViewLayout).
     */
    private static Plan planWindow(Context ctx, View root, Orig ro, Rules.Rule rr, boolean removed,
                                   WindowManager.LayoutParams wlp) {
        float d = U.density(ctx);
        Plan pl = new Plan();
        String kind = effectiveKind(ro);
        int pct = 100;
        int galpha = 100;
        int gdp = 0;
        if ("menu".equals(kind)) {
            pct = Config.menuPct;
            galpha = Config.menuAlpha;
            pl.textPct = Config.menuTextPct;
            gdp = Config.menuDp;
            pl.textDelta = Config.menuTextDp;
        } else if ("icon".equals(kind)) {
            pct = Config.iconPct;
            galpha = Config.iconAlpha;
            pl.textPct = Config.iconTextPct;
            gdp = Config.iconDp;
            pl.textDelta = Config.iconTextDp;
        } else if ("button".equals(kind)) {
            pct = Config.btnPct;
            galpha = Config.btnAlpha;
            pl.textPct = Config.btnTextPct;
            gdp = Config.btnDp;
            pl.textDelta = Config.btnTextDp;
        }
        boolean line = "line".equals(kind);
        boolean canvasK = "canvas".equals(kind);
        pl.line = line;
        pl.canvas = canvasK;
        float subAlpha = 1f;
        if (line || canvasK) {
            // all lines that start at the same origin share ONE thickness: the global one wins, a single item's
            // own number is only used while there is no global one
            pl.lineDp = (Config.lineT > 0 && !EditGuard.blocked("*", "line")) ? Config.lineT / 10f
                    : ((rr != null && rr.thick != Rules.NONE && rr.thick > 0) ? rr.thick / 10f : 0f);
        }
        boolean sizeable = !canvasK && !line;
        float f = pct / 100f;
        // a size in dp (new) wins over the old percent: every window of the group gets this width
        if (sizeable && gdp > 0 && ro.mw > 0) f = gdp * d / ro.mw;
        if (sizeable && rr != null && rr.w != Rules.NONE && rr.w > 0 && ro.mw > 0) f = rr.w * d / ro.mw;
        if (!sizeable) f = 1f;
        f = Math.max(0.1f, Math.min(8f, f));
        // A small window (menu icon, floating button) is made bigger or smaller by scaling its content, so it
        // works whatever its layout is (wrap content, fixed sizes, pictures): the window gets the matching size.
        boolean xform = sizeable && ("icon".equals(kind) || "button".equals(kind)) && root instanceof ViewGroup
                && ((ViewGroup) root).getChildCount() > 0 && ro.mw > 0 && ro.mh > 0;
        pl.f = f;
        pl.xform = xform;
        int ap = Rules.NONE;
        if (rr != null && rr.alpha != Rules.NONE) ap = rr.alpha;
        else if (galpha < 100) ap = galpha;

        boolean ch = false;
        int nw = (f == 1f || ro.bw <= 0) ? ro.lw : Math.round(ro.bw * f);
        int nh = (f == 1f || ro.bh <= 0) ? ro.lh : Math.round(ro.bh * f);
        if (xform) {
            nw = f == 1f ? ro.lw : Math.round(ro.mw * f);
            nh = f == 1f ? ro.lh : Math.round(ro.mh * f);
        }
        if (line && pl.lineDp > 0f && ro.mw > 0 && ro.mh > 0) {
            float raw = pl.lineDp * d;
            int px = Math.max(1, Math.round(raw));
            // thinner than one pixel cannot be a smaller window: it is one pixel that is fainter, like a hairline
            if (raw < 1f) subAlpha = Math.max(0.05f, raw);
            if (ro.mw <= ro.mh) nw = px;
            else nh = px;
        }
        boolean sizeMod = nw != ro.lw || nh != ro.lh;
        if (sizeMod || ro.layDirty) {
            if (wlp.width != nw) {
                wlp.width = nw;
                ch = true;
            }
            if (wlp.height != nh) {
                wlp.height = nh;
                ch = true;
            }
            ro.layDirty = sizeMod;
        }
        boolean alphaMod = ap != Rules.NONE || subAlpha < 1f;
        // a removed window keeps its alpha at 0 (see hideParams), so the opacity is left alone meanwhile
        if (!removed && !ro.winHidden && (alphaMod || ro.alphaDirty)) {
            float base = ap != Rules.NONE ? ap / 100f : ro.winAlpha;
            float na = alphaMod ? base * subAlpha : ro.winAlpha;
            if (Math.abs(wlp.alpha - na) > 0.001f) {
                wlp.alpha = na;
                ch = true;
            }
            ro.alphaDirty = alphaMod;
        }
        pl.changed = ch;
        return pl;
    }

    private static void handleRoot(Context ctx, View root) {
        if (ORIG.get(root) == null && (root.getWidth() <= 0 || root.getHeight() <= 0)) return; // not drawn yet
        if (!EditGuard.ready()) return; // the app gets its first moments in peace
        boolean overlay = isOverlay(root);
        Orig ro = rootOrig(root, overlay);
        Rules.Rule rr = EditGuard.mask(ro.key, Rules.get(ro.key));
        if (Config.themeOn) EditGuard.noteGlobal(EditGuard.COLOR, Config.themeBg ^ Config.themeAccent ^ Config.themeText);
        if (Config.lineT > 0) EditGuard.noteGlobal(EditGuard.LINE, Config.lineT);
        float d = U.density(ctx);
        boolean removed = rr != null && rr.hide && !ro.screen;

        Plan pl = new Plan();
        if (overlay) {
            WindowManager.LayoutParams wlp = (WindowManager.LayoutParams) root.getLayoutParams();
            pl = planWindow(ctx, root, ro, rr, removed, wlp);
            if (pl.f != 1f || pl.textPct != 100 || pl.textDelta != 0) {
                int gs = Float.floatToIntBits(pl.f) ^ (pl.textPct * 31) ^ (pl.textDelta * 131);
                if (ro.sig == null) ro.sig = new int[EditGuard.CATS.length];
                if (ro.sig[EditGuard.SIZE] != gs * 31 + 7) {
                    ro.sig[EditGuard.SIZE] = gs * 31 + 7;
                    EditGuard.note(ro.key, EditGuard.SIZE);
                }
            }
            if (pl.line || pl.canvas) {
                // lines the app paints itself (and thin line windows that are painted): set the Paint width
                long nowS = SystemClock.uptimeMillis();
                if ((pl.lineDp > 0f || !PAINT_ORIG.isEmpty()) && nowS - ro.lastStroke > (pl.canvas ? 60L : 200L)) {
                    ro.lastStroke = nowS;
                    strokeTree(root, pl.lineDp > 0f ? pl.lineDp * d : 0f, 0);
                }
            }
            if (pl.changed) {
                WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
                wm.updateViewLayout(root, wlp);
                mods++;
            }
        }

        // A removed interface is BYPASSED, never detached and never made invisible: the window stays alive
        // (so the app and its game surface never notice), but it is fully transparent, cannot be touched, cannot
        // take focus and does not dim the screen. The app under it gets every touch.
        ViewGroup.LayoutParams wl0 = root.getLayoutParams();
        if (wl0 instanceof WindowManager.LayoutParams && !ro.screen) {
            try {
                hideWindow(ctx, root, ro, removed);
            } catch (Throwable t) {
                U.err("remove interface", t);
                ro.hideFails++;
                if (ro.hideFails >= 2 && removed) {
                    // it cannot be bypassed safely: keep it visible instead of risking the app
                    HideGuard.markUnsafe(ro.key);
                    Rules.edit(ro.key).hide = false;
                    Config.saveLive(ctx);
                }
            }
        }

        if (pl.xform || ro.xformed) {
            try {
                scaleContent((ViewGroup) root, ro, pl.xform ? pl.f : 1f);
                ro.xformed = pl.xform && pl.f != 1f;
            } catch (Throwable t) {
                U.err("scale content", t);
            }
        }
        Pass p = new Pass();
        p.f = pl.xform ? 1f : pl.f;
        p.d = d;
        p.overlay = overlay;
        p.textPct = pl.textPct;
        p.textDelta = pl.textDelta;
        p.lineDp = pl.lineDp;
        walk(root, ro, p);
    }

    /**
     * Scales the direct children of a window root around the top-left corner so that each looks f times its original
     * size, and moves it to f times its original place. Touches follow the scaled picture (Android maps them back).
     */
    private static void scaleContent(ViewGroup g, Orig ro, float f) {
        boolean changed = false;
        for (int i = 0; i < g.getChildCount() && i < 40; i++) {
            View c = g.getChildAt(i);
            Orig co = childOrig(c, ro, i);
            if (c.getWidth() <= 0 || c.getHeight() <= 0 || co.mw <= 0 || co.mh <= 0) continue;
            float sx = f == 1f ? 1f : co.mw * f / c.getWidth();
            float sy = f == 1f ? 1f : co.mh * f / c.getHeight();
            float tx = f == 1f ? 0f : co.ol * f - c.getLeft();
            float ty = f == 1f ? 0f : co.ot * f - c.getTop();
            if (Math.abs(c.getScaleX() - sx) > 0.002f || Math.abs(c.getScaleY() - sy) > 0.002f
                    || Math.abs(c.getTranslationX() - tx) > 0.5f || Math.abs(c.getTranslationY() - ty) > 0.5f) {
                c.setPivotX(0f);
                c.setPivotY(0f);
                c.setScaleX(sx);
                c.setScaleY(sy);
                c.setTranslationX(tx);
                c.setTranslationY(ty);
                changed = true;
            }
        }
        if (changed) mods++;
    }

    /** Hides (bypasses) or brings back one window, without ever touching its view tree or detaching it. */
    private static void hideWindow(Context ctx, View root, Orig ro, boolean gone) throws Exception {
        WindowManager.LayoutParams wl = (WindowManager.LayoutParams) root.getLayoutParams();
        if (hideParams(ro, gone, wl)) {
            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            wm.updateViewLayout(root, wl);
            mods++;
        }
    }

    /** The flags and opacity of a removed (bypassed) window, written into wl. True when something changed. */
    private static boolean hideParams(Orig ro, boolean gone, WindowManager.LayoutParams wl) {
        int add = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        int dim = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        boolean upd = false;
        if (gone) {
            if (!ro.winHidden) {
                ro.flagsAdded = add & ~wl.flags;
                ro.dimWas = (wl.flags & dim) != 0;
                ro.alphaWas = wl.alpha;
                ro.winHidden = true;
                HideGuard.note(ro.key);
            }
            int nf = (wl.flags | add) & ~dim;
            if (nf != wl.flags) {
                wl.flags = nf;
                upd = true;
            }
            if (wl.alpha != 0f) {
                wl.alpha = 0f;
                upd = true;
            }
        } else if (ro.winHidden) {
            int nf = wl.flags & ~ro.flagsAdded;
            if (ro.dimWas) nf |= dim;
            wl.flags = nf;
            wl.alpha = ro.alphaWas;
            ro.winHidden = false;
            ro.flagsAdded = 0;
            upd = true;
            HideGuard.noteShow(ro.key);
        }
        return upd;
    }

    private static void walk(View v, Orig o, Pass p) {
        if (p.budget-- <= 0) return;
        Rules.Rule r = EditGuard.mask(o.key, Rules.get(o.key));
        try {
            applyView(v, o, r, p);
        } catch (Throwable t) {
            U.err("apply view", t);
        }
        boolean quietWas = p.quiet;
        boolean quiet = quietWas || (r != null && r.quiet);
        try {
            if (quiet) Quiet.apply(v);
            else Quiet.undo(v);
        } catch (Throwable t) {
            U.err("quiet", t);
        }
        if (v instanceof ViewGroup) {
            p.quiet = quiet;
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View c = g.getChildAt(i);
                if (c == null) continue;
                walk(c, childOrig(c, o, i), p);
            }
            p.quiet = quietWas;
        }
    }

    // ---- lines drawn by the app itself (canvas): change the thickness of its Paint objects ---------

    private static final WeakHashMap<android.graphics.Paint, Float> PAINT_ORIG =
            new WeakHashMap<android.graphics.Paint, Float>();

    /**
     * An app that draws a line itself keeps the Paint (with its stroke width) in a field of its view. Those paints are
     * found by reflection and their stroke width is set; 0 puts the original width back. Paints that are created
     * fresh on every draw cannot be reached this way.
     */
    private static void strokeTree(View v, float px, int depth) {
        if (v == null || depth > 6) return;
        strokeFields(v, px);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount() && i < 60; i++) strokeTree(g.getChildAt(i), px, depth + 1);
        }
    }

    private static boolean appClass(Class<?> c) {
        String n = c.getName();
        return !(n.startsWith("android.") || n.startsWith("androidx.") || n.startsWith("java.")
                || n.startsWith("javax.") || n.startsWith("kotlin.") || n.startsWith("dalvik.")
                || n.startsWith("libcore.") || c.isPrimitive() || c.isArray() || c.isEnum());
    }

    private static void strokeFields(View v, float px) {
        boolean changed = strokeObject(v, px, 0);
        try {
            android.graphics.drawable.Drawable bg = v.getBackground();
            if (bg != null && appClass(bg.getClass())) changed |= strokeObject(bg, px, 1);
        } catch (Throwable t) {
            // skip
        }
        if (changed) {
            v.invalidate();
            mods++;
        }
    }

    /** Looks for Paint objects in the fields of an app's view (and, two levels deep, of the objects it holds). */
    private static boolean strokeObject(Object target, float px, int depth) {
        boolean changed = false;
        Class<?> c = target.getClass();
        int guard = 0;
        while (c != null && c != View.class && c != Object.class && guard++ < 6) {
            if (!appClass(c)) break;
            Field[] fs;
            try {
                fs = c.getDeclaredFields();
            } catch (Throwable t) {
                break;
            }
            for (int i = 0; i < fs.length && i < 200; i++) {
                try {
                    Field f = fs[i];
                    if (java.lang.reflect.Modifier.isStatic(f.getModifiers()) || f.getType().isPrimitive()) continue;
                    f.setAccessible(true);
                    Object o = f.get(target);
                    if (o == null) continue;
                    if (o instanceof android.graphics.Paint) {
                        changed |= strokePaint((android.graphics.Paint) o, px);
                    } else if (o instanceof android.graphics.Paint[]) {
                        android.graphics.Paint[] arr = (android.graphics.Paint[]) o;
                        for (int k = 0; k < arr.length; k++) if (arr[k] != null) changed |= strokePaint(arr[k], px);
                    } else if (depth < 2 && !(o instanceof View) && !(o instanceof Context)
                            && appClass(o.getClass())) {
                        changed |= strokeObject(o, px, depth + 1);
                    }
                } catch (Throwable t) {
                    // field not readable: skip
                }
            }
            c = c.getSuperclass();
        }
        return changed;
    }

    private static boolean strokePaint(android.graphics.Paint p, float px) {
        Float orig = PAINT_ORIG.get(p);
        if (orig == null) {
            // only paints that draw lines: stroke style, or a stroke width that is already set
            boolean stroke = p.getStyle() != android.graphics.Paint.Style.FILL || p.getStrokeWidth() > 0f;
            if (!stroke) return false;
            orig = Float.valueOf(p.getStrokeWidth());
            PAINT_ORIG.put(p, orig);
        }
        float want = px > 0 ? px : orig.floatValue();
        if (Math.abs(p.getStrokeWidth() - want) < 0.05f) return false;
        p.setStrokeWidth(want);
        return true;
    }

    /** A thin picture-less line view: no text, no children, one side short and the other much longer. */
    private static boolean isThin(View v, Orig o, float d) {
        if (v instanceof TextView || v instanceof ViewGroup || o.mw <= 0 || o.mh <= 0) return false;
        int thin = Math.min(o.mw, o.mh), len = Math.max(o.mw, o.mh);
        return thin <= Math.round(10 * d) && len >= 4 * thin;
    }

    /** A button or an on / off switch: something you tap that has a background. */
    private static boolean buttonLike(View v, Orig o) {
        if (v instanceof EditText) return false;
        if (v.getBackground() == null && (o == null || o.bg == null)) return false;
        if (v instanceof Button) return true;
        if (!(v.isClickable() || v.isLongClickable())) return false;
        // a big clickable container is a panel, not a button
        android.util.DisplayMetrics dm = v.getResources().getDisplayMetrics();
        return v.getWidth() <= 0 || v.getWidth() < dm.widthPixels * 0.9f;
    }

    /** Video, game and web surfaces are never repainted by the theme. */
    private static boolean isMedia(View v) {
        return v instanceof android.view.SurfaceView || v instanceof android.view.TextureView
                || v instanceof android.webkit.WebView;
    }

    private static int contrast(int c) {
        double lum = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
        return lum > 0.6 ? 0xFF111111 : 0xFFFFFFFF;
    }

    /** Only the SHAPE of the text (looks like 00:59 or "3 days left"). Whether it really counts is checked in timerNow. */
    static boolean isTimer(String s) {
        if (s == null) return false;
        int n = s.length();
        if (n == 0 || n > 60) return false;
        if (AMPM.matcher(s).find() || DATE.matcher(s).find()) return false;
        if (CLOCK.matcher(s).matches()) return true;
        return UNIT.matcher(s).find() && WORD.matcher(s).find();
    }

    /**
     * True when this text is a countdown. Words like "left" / "expires" count at once. A bare 00:59 only counts after
     * it changed a few times within seconds (a real countdown ticks; a fixed time, a score or a label does not).
     * Once found it stays a timer for as long as the text keeps the timer shape.
     */
    private static boolean timerNow(Orig o, String cur) {
        if (!isTimer(cur)) {
            o.tSeen = null;
            o.tChanges = 0;
            return false;
        }
        if (UNIT.matcher(cur).find() && WORD.matcher(cur).find()) return true;
        if (o.timerHit) return true;
        long now = SystemClock.elapsedRealtime();
        if (o.tSeen == null) {
            o.tSeen = cur;
            o.tChanges = 1;
            o.tAt = now;
            return false;
        }
        if (!cur.equals(o.tSeen)) {
            o.tChanges = (now - o.tAt > 6000L) ? 1 : o.tChanges + 1;
            o.tSeen = cur;
            o.tAt = now;
        }
        return o.tChanges >= 3;
    }

    private static void applyView(View v, Orig o, Rules.Rule r, Pass p) {
        noteEdits(o, r);
        final boolean themeOk = !EditGuard.blocked("*", "color") && !EditGuard.blocked(o.key, "color");
        final float d = p.d;

        // ---- size, margins, padding (a window root is sized through its window instead)
        if (!o.isRoot) {
            int nw = o.lw;
            int nh = o.lh;
            if (r != null && r.w != Rules.NONE && r.w > 0) nw = Math.round(r.w * d);
            else if (p.f != 1f && o.bw > 0) nw = Math.round(o.bw * p.f);
            if (r != null && r.h != Rules.NONE && r.h > 0) nh = Math.round(r.h * d);
            else if (p.f != 1f && o.bh > 0) nh = Math.round(o.bh * p.f);
            // all lines share one thickness: the global one wins on overlays, a single item's own number only
            // counts where there is no global one (app screens)
            float thickDp = (p.overlay && Config.lineT > 0 && !EditGuard.blocked("*", "line")) ? Config.lineT / 10f
                    : ((r != null && r.thick != Rules.NONE && r.thick > 0) ? r.thick / 10f : 0f);
            float subA = 1f;
            if (thickDp > 0f && isThin(v, o, d) && o.mw > 0 && o.mh > 0) {
                float raw = thickDp * d;
                int px = Math.max(1, Math.round(raw));
                if (raw < 1f) subA = Math.max(0.05f, raw); // thinner than a pixel: a fainter one-pixel line
                if (o.mw <= o.mh) nw = px;
                else nh = px;
            }
            float sf = p.f;
            int ml = Math.round(o.ml * sf), mt = Math.round(o.mt * sf), mr = Math.round(o.mr * sf), mb = Math.round(o.mb * sf);
            int pl = Math.round(o.pl * sf), pt = Math.round(o.pt * sf), pr = Math.round(o.pr * sf), pb = Math.round(o.pb * sf);
            boolean mod = nw != o.lw || nh != o.lh || ml != o.ml || mt != o.mt || mr != o.mr || mb != o.mb
                    || pl != o.pl || pt != o.pt || pr != o.pr || pb != o.pb;
            if (mod || o.layDirty) {
                ViewGroup.LayoutParams lp = v.getLayoutParams();
                if (lp != null) {
                    boolean ch = false;
                    if (lp.width != nw) {
                        lp.width = nw;
                        ch = true;
                    }
                    if (lp.height != nh) {
                        lp.height = nh;
                        ch = true;
                    }
                    if (lp instanceof ViewGroup.MarginLayoutParams) {
                        ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
                        if (m.leftMargin != ml || m.topMargin != mt || m.rightMargin != mr || m.bottomMargin != mb) {
                            m.setMargins(ml, mt, mr, mb);
                            ch = true;
                        }
                    }
                    if (ch) {
                        v.setLayoutParams(lp);
                        mods++;
                    }
                }
                if (v.getPaddingLeft() != pl || v.getPaddingTop() != pt
                        || v.getPaddingRight() != pr || v.getPaddingBottom() != pb) {
                    v.setPadding(pl, pt, pr, pb);
                    mods++;
                }
                o.layDirty = mod;
            }

            // ---- opacity
            if ((r != null && r.alpha != Rules.NONE) || subA < 1f) {
                float wa = ((r != null && r.alpha != Rules.NONE) ? r.alpha / 100f : o.alpha) * subA;
                if (Math.abs(v.getAlpha() - wa) > 0.001f) {
                    v.setAlpha(wa);
                    mods++;
                }
                o.alphaDirty = true;
            } else if (o.alphaDirty) {
                v.setAlpha(o.alpha);
                mods++;
                o.alphaDirty = false;
            }
        }

        // a window root is removed through its window (hideWindow), never by changing its view visibility
        boolean hideIt = r != null && r.hide && !o.isRoot;

        // ---- pictures (icons): replaced by the user's PNG, and fitted so a smaller view never crops them
        if (v instanceof ImageView) {
            ImageView iv = (ImageView) v;
            applyPicture(iv, o, r, p);
            if (r != null && r.bgColor != Rules.NONE) {
                if (!o.tintDirty || o.tintColor != r.bgColor) {
                    iv.setColorFilter(r.bgColor, PorterDuff.Mode.SRC_IN);
                    mods++;
                }
                o.tintColor = r.bgColor;
                o.tintDirty = true;
            } else if (o.tintDirty) {
                iv.clearColorFilter();
                mods++;
                o.tintDirty = false;
            }
        } else {
            int exact = (r != null && r.bgColor != Rules.NONE) ? r.bgColor : Rules.NONE;
            boolean themed = exact == Rules.NONE && Config.themeOn && themeOk && !isMedia(v) && !o.giveBg;
            applyBg(v, o, exact, themed);
        }

        // ---- texts: size, name / timers, colour
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            applyCompound(tv, o, r, p);
            boolean edit = v instanceof EditText;

            float want = o.textPx;
            if (r != null && r.text != Rules.NONE && r.text > 0) want = r.text * d;
            else if (p.f != 1f || p.textPct != 100 || p.textDelta != 0) {
                want = o.textPx * p.f * (p.textPct / 100f) + p.textDelta * d;
                if (want < 4f * d) want = 4f * d;
            }
            boolean tsMod = Math.abs(want - o.textPx) > 0.5f;
            if (tsMod || o.tsDirty) {
                if (Math.abs(tv.getTextSize() - want) > 0.5f) {
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, want);
                    mods++;
                }
                o.tsDirty = tsMod;
            }

            CharSequence cs = tv.getText();
            String cur = cs == null ? "" : cs.toString();
            boolean ours = o.textDirty && cur.equals(o.lastSet);
            String wantText = null;
            if (!edit) {
                if (r != null && r.name != null) {
                    wantText = r.name;
                } else if (Config.timers != 0) {
                    boolean isT = ours ? o.timerHit : timerNow(o, cur);
                    o.timerHit = isT;
                    if (isT) {
                        if (Config.timers == 2) wantText = Config.timerText;
                        else hideIt = true;
                    }
                }
            }
            if (wantText != null && o.giveText) wantText = null; // the app keeps undoing it: left alone
            if (wantText != null) {
                if (!wantText.equals(cur)) {
                    if (o.textDirty) { // we set it before and the app changed it back: count it (loop guard)
                        long nowF = SystemClock.elapsedRealtime();
                        if (nowF - o.tFightT0 > 1000L) {
                            o.tFightT0 = nowF;
                            o.tFights = 0;
                        }
                        if (++o.tFights > 12) {
                            o.giveText = true;
                            U.log("text loop: giving up on " + o.key);
                        }
                    }
                    if (!o.giveText) {
                        setTextQuiet(tv, wantText);
                        mods++;
                    }
                }
                o.lastSet = wantText;
                o.textDirty = true;
            } else if (o.textDirty) {
                setTextQuiet(tv, o.text);
                mods++;
                o.textDirty = false;
                o.lastSet = null;
            }

            int tc = Rules.NONE;
            if (r != null && r.textColor != Rules.NONE) tc = r.textColor;
            else if (Config.themeOn && themeOk) {
                if (buttonLike(v, o)) tc = contrast(o.appliedBg != Rules.NONE ? o.appliedBg : Config.themeAccent);
                else tc = Config.themeText;
            }
            if (tc != Rules.NONE) {
                if (tv.getCurrentTextColor() != tc) {
                    tv.setTextColor(tc);
                    mods++;
                }
                o.tcDirty = true;
            } else if (o.tcDirty) {
                if (o.tcl != null) {
                    tv.setTextColor(o.tcl);
                    mods++;
                }
                o.tcDirty = false;
            }
        }

        // ---- hide
        if (hideIt) {
            int hv = o.isRoot ? View.INVISIBLE : View.GONE;
            if (v.getVisibility() != hv) {
                v.setVisibility(hv);
                mods++;
            }
            o.hidden = true;
        } else if (o.hidden) {
            v.setVisibility(o.vis);
            mods++;
            o.hidden = false;
        }
    }

    // ---- background colour -------------------------------------------------------------------

    private static final int UNKNOWN = Rules.NONE;

    /** The flat colour of a drawable, or UNKNOWN when it has none we can read (state lists, pictures ...). */
    static int colorOf(Drawable d) {
        try {
            if (d instanceof ColorDrawable) return ((ColorDrawable) d).getColor();
            if (d instanceof GradientDrawable && android.os.Build.VERSION.SDK_INT >= 24) {
                ColorStateList cl = ((GradientDrawable) d).getColor();
                if (cl != null) return cl.getDefaultColor();
            }
        } catch (Throwable t) {
            // unknown
        }
        return UNKNOWN;
    }

    /** Grey, black or white: the "off" look of a switch. A real colour (blue, green ...) is its "on" look. */
    private static boolean isNeutral(int c) {
        float[] hsv = new float[3];
        Color.colorToHSV(c, hsv);
        return hsv[1] < 0.22f;
    }

    private static int mix(int a, int b, float t) {
        int r = Math.round(Color.red(a) * (1f - t) + Color.red(b) * t);
        int g = Math.round(Color.green(a) * (1f - t) + Color.green(b) * t);
        int bl = Math.round(Color.blue(a) * (1f - t) + Color.blue(b) * t);
        return Color.rgb(r, g, bl);
    }

    /** The theme's "off" colour of a switch: a soft grey-ish step between the theme background and its text. */
    static int themeOff() {
        return mix(Config.themeBg, Config.themeText, 0.28f);
    }

    /**
     * The colour the theme wants for a view whose own background is inner. Panels get the theme background. A button
     * keeps its on / off difference: grey (off) stays a soft neutral, a coloured one (on) gets the theme's button
     * colour, so on and off never look the same. Returns UNKNOWN to leave the drawable alone (transparent ones).
     */
    static int themedColor(View v, Drawable inner) {
        int c0 = colorOf(inner);
        if (c0 != UNKNOWN && Color.alpha(c0) == 0) return UNKNOWN;
        int want;
        if (!buttonLike(v, null)) {
            want = Config.themeBg;
        } else if (c0 != UNKNOWN) {
            want = isNeutral(c0) ? themeOff() : Config.themeAccent;
        } else {
            boolean on = (v instanceof android.widget.Checkable && ((android.widget.Checkable) v).isChecked())
                    || v.isSelected() || v.isActivated();
            want = on ? Config.themeAccent : themeOff();
        }
        want |= 0xFF000000;
        if (c0 != UNKNOWN && Color.alpha(c0) < 255) want = (want & 0x00FFFFFF) | (Color.alpha(c0) << 24);
        return want;
    }

    /**
     * The background of a view in the theme. It draws the app's own drawable (so its shape, corners and padding stay)
     * but in the colour the theme wants, and it asks the app's drawable for its colour on EVERY draw: an app that
     * changes the colour of its own drawable for on / off still shows the difference.
     */
    static final class Themed extends Drawable implements Drawable.Callback {
        final Drawable inner;
        final java.lang.ref.WeakReference<View> view;
        private boolean drawing;
        private int filterColor;
        private android.graphics.PorterDuffColorFilter filter;
        private final android.graphics.Paint fill = new android.graphics.Paint();
        int lastWant = UNKNOWN;

        Themed(Drawable inner, View v) {
            this.inner = inner;
            this.view = new java.lang.ref.WeakReference<View>(v);
            inner.setCallback(this);
        }

        void release() {
            try {
                inner.setColorFilter(null);
            } catch (Throwable t) {
                // ignore
            }
        }

        int wantNow() {
            View v = view.get();
            lastWant = v == null ? UNKNOWN : themedColor(v, inner);
            return lastWant;
        }

        @Override
        public void draw(android.graphics.Canvas c) {
            int want = wantNow();
            if (want == UNKNOWN) {
                inner.draw(c);
                return;
            }
            drawing = true;
            try {
                if (inner instanceof ColorDrawable) {
                    fill.setColor(want);
                    c.drawRect(getBounds(), fill);
                } else {
                    if (filter == null || filterColor != want) {
                        filter = new android.graphics.PorterDuffColorFilter(want, PorterDuff.Mode.SRC_IN);
                        filterColor = want;
                    }
                    inner.setColorFilter(filter);
                    inner.draw(c);
                }
            } finally {
                drawing = false;
            }
        }

        @Override
        protected void onBoundsChange(android.graphics.Rect b) {
            inner.setBounds(b);
        }

        @Override
        public boolean getPadding(android.graphics.Rect padding) {
            return inner.getPadding(padding);
        }

        @Override
        public int getIntrinsicWidth() {
            return inner.getIntrinsicWidth();
        }

        @Override
        public int getIntrinsicHeight() {
            return inner.getIntrinsicHeight();
        }

        @Override
        public boolean isStateful() {
            return inner.isStateful();
        }

        @Override
        protected boolean onStateChange(int[] state) {
            return inner.setState(state);
        }

        @Override
        protected boolean onLevelChange(int level) {
            return inner.setLevel(level);
        }

        @Override
        public boolean setVisible(boolean visible, boolean restart) {
            inner.setVisible(visible, restart);
            return super.setVisible(visible, restart);
        }

        @Override
        public void jumpToCurrentState() {
            inner.jumpToCurrentState();
        }

        @Override
        public void setAlpha(int alpha) {
            inner.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter cf) {
            // the filter is ours; a filter from outside is ignored
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }

        @Override
        public void invalidateDrawable(Drawable who) {
            if (!drawing) invalidateSelf();
        }

        @Override
        public void scheduleDrawable(Drawable who, Runnable what, long when) {
            scheduleSelf(what, when);
        }

        @Override
        public void unscheduleDrawable(Drawable who, Runnable what) {
            unscheduleSelf(what);
        }
    }

    /**
     * exact != NONE: a flat colour chosen for this one item. themed: the theme colours (see Themed). Neither: the
     * app's own background is put back.
     */
    private static void applyBg(View v, Orig o, int exact, boolean themed) {
        if (o.giveBg) {
            o.appliedBg = Rules.NONE;
            return;
        }
        if (exact == Rules.NONE && !themed) {
            if (o.bgDirty) {
                if (o.ours instanceof Themed) ((Themed) o.ours).release();
                v.setBackground(o.bg);
                mods++;
                o.bgDirty = false;
                o.ours = null;
            }
            o.appliedBg = Rules.NONE;
            return;
        }
        Drawable cur = v.getBackground();
        if (o.ours != null && cur != o.ours) { // the app put its own background back over ours: loop guard
            long nowF = SystemClock.elapsedRealtime();
            if (nowF - o.bFightT0 > 1000L) {
                o.bFightT0 = nowF;
                o.bFights = 0;
            }
            if (++o.bFights > 12) {
                o.giveBg = true;
                o.ours = null;
                o.bgDirty = false;
                o.appliedBg = Rules.NONE;
                return;
            }
        }
        if (o.ours == null || cur != o.ours) o.bg = cur; // the app set its own background: that is the new original
        if (exact != Rules.NONE) {
            o.appliedBg = exact;
            if (o.ours instanceof ColorDrawable && cur == o.ours && o.oursColor == exact) return;
            Drawable made = new ColorDrawable(exact);
            if (o.ours instanceof Themed) ((Themed) o.ours).release();
            v.setBackground(made);
            mods++;
            o.ours = made;
            o.oursColor = exact;
            o.bgDirty = true;
            return;
        }
        Drawable base = o.bg;
        if (base == null) {
            o.appliedBg = Rules.NONE;
            return;
        }
        if (o.ours instanceof Themed && cur == o.ours) {
            int w = ((Themed) o.ours).wantNow();
            o.appliedBg = w == UNKNOWN ? Rules.NONE : w;
            return;
        }
        if (o.ours instanceof Themed) ((Themed) o.ours).release();
        Themed made = new Themed(base, v);
        v.setBackground(made);
        mods++;
        o.ours = made;
        o.oursColor = 0;
        o.bgDirty = true;
        int w = made.wantNow();
        o.appliedBg = w == UNKNOWN ? Rules.NONE : w;
    }

    // ---- pictures ----------------------------------------------------------------------------

    private static final java.util.HashMap<String, android.graphics.Bitmap> BMP =
            new java.util.HashMap<String, android.graphics.Bitmap>();

    /** The picture a user chose (PNG, base64): decoded once and kept. */
    static android.graphics.Bitmap iconBitmap(String b64) {
        if (b64 == null || b64.length() == 0) return null;
        String key = Integer.toHexString(b64.hashCode()) + ":" + b64.length();
        android.graphics.Bitmap bm = BMP.get(key);
        if (bm != null) return bm;
        try {
            byte[] raw = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            bm = android.graphics.BitmapFactory.decodeByteArray(raw, 0, raw.length);
            if (bm == null) return null;
            if (BMP.size() > 40) BMP.clear();
            BMP.put(key, bm);
        } catch (Throwable t) {
            U.err("icon decode", t);
        }
        return bm;
    }

    /**
     * A user's picture in the place of an old icon: whatever its own size, it reports the OLD icon's size (so a view
     * that wraps its picture keeps its size) and is drawn whole, centred and scaled to fit, keeping its shape.
     */
    static final class IconDrawable extends Drawable {
        private final android.graphics.Bitmap bmp;
        private final int w, h;
        private final android.graphics.Paint paint = new android.graphics.Paint(
                android.graphics.Paint.ANTI_ALIAS_FLAG | android.graphics.Paint.FILTER_BITMAP_FLAG);
        private final android.graphics.Rect src = new android.graphics.Rect();
        private final android.graphics.RectF dst = new android.graphics.RectF();

        IconDrawable(android.graphics.Bitmap bmp, int w, int h) {
            this.bmp = bmp;
            this.w = Math.max(1, w);
            this.h = Math.max(1, h);
            src.set(0, 0, bmp.getWidth(), bmp.getHeight());
        }

        @Override
        public void draw(android.graphics.Canvas c) {
            android.graphics.Rect b = getBounds();
            if (b.width() <= 0 || b.height() <= 0) return;
            float s = Math.min(b.width() / (float) bmp.getWidth(), b.height() / (float) bmp.getHeight());
            float dw = bmp.getWidth() * s, dh = bmp.getHeight() * s;
            float l = b.left + (b.width() - dw) / 2f, t = b.top + (b.height() - dh) / 2f;
            dst.set(l, t, l + dw, t + dh);
            c.drawBitmap(bmp, src, dst, paint);
        }

        @Override
        public int getIntrinsicWidth() {
            return w;
        }

        @Override
        public int getIntrinsicHeight() {
            return h;
        }

        @Override
        public void setAlpha(int a) {
            paint.setAlpha(a);
            invalidateSelf();
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter cf) {
            paint.setColorFilter(cf);
            invalidateSelf();
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }
    }

    private static boolean sameDrawables(Drawable[] a, Drawable[] b) {
        for (int i = 0; i < 4; i++) if (a[i] != b[i]) return false;
        return true;
    }

    /** An ImageView: the user's picture instead of the icon, and a picture that never gets cropped when resized. */
    private static void applyPicture(ImageView iv, Orig o, Rules.Rule r, Pass p) {
        boolean hasIcon = r != null && r.icon != null && r.icon.length() > 0;
        boolean resized = p.f != 1f
                || (r != null && ((r.w != Rules.NONE && r.w > 0) || (r.h != Rules.NONE && r.h > 0)));
        ImageView.ScaleType cur = iv.getScaleType();
        if (hasIcon || resized) {
            if (!o.scaleDirty) {
                o.scaleType = cur;
                o.scaleDirty = true;
            }
            ImageView.ScaleType want = o.scaleType;
            // a picture that is only centred (not scaled) is cut off when its view gets smaller: fit it instead
            if (hasIcon || want == ImageView.ScaleType.CENTER || want == ImageView.ScaleType.MATRIX) {
                want = ImageView.ScaleType.FIT_CENTER;
            }
            if (cur != want) {
                iv.setScaleType(want);
                mods++;
            }
        } else if (o.scaleDirty) {
            if (o.scaleType != null && cur != o.scaleType) {
                iv.setScaleType(o.scaleType);
                mods++;
            }
            o.scaleDirty = false;
        }
        if (hasIcon) {
            if (o.iconOurs == null || !r.icon.equals(o.iconSrc)) {
                android.graphics.Bitmap bm = iconBitmap(r.icon);
                if (bm == null) return;
                float dd = U.density(iv.getContext());
                int w = o.idw > 0 ? o.idw : Math.max(1, o.mw - o.pl - o.pr);
                int h = o.idh > 0 ? o.idh : Math.max(1, o.mh - o.pt - o.pb);
                if (o.mw <= 0 && o.idw <= 0) w = h = Math.round(40 * dd);
                o.iconOurs = new IconDrawable(bm, w, h);
                o.iconSrc = r.icon;
            }
            Drawable now = iv.getDrawable();
            if (now != o.iconOurs) {
                if (now != null) o.imgOrig = now; // the app's own picture: kept to put back
                iv.setImageDrawable(o.iconOurs);
                mods++;
            }
            o.iconDirty = true;
        } else if (o.iconDirty) {
            iv.setImageDrawable(o.imgOrig);
            mods++;
            o.iconDirty = false;
            o.iconOurs = null;
            o.iconSrc = null;
        }
    }

    /**
     * A text with icons beside it (compound drawables): the icons shrink and grow with the view (they kept their old
     * size and looked cropped), and the first one can be replaced by the user's picture.
     */
    private static void applyCompound(TextView tv, Orig o, Rules.Rule r, Pass p) {
        Drawable[] cur = tv.getCompoundDrawables();
        boolean any = false;
        for (int i = 0; i < 4; i++) if (cur[i] != null) any = true;
        if (o.cdOrig != null) {
            for (int i = 0; i < 4; i++) { // the app put other icons: those are the new originals
                if (cur[i] != null && cur[i] != o.cdOrig[i] && cur[i] != o.cdIcon) {
                    o.cdOrig = null;
                    o.cdDirty = false;
                    o.cdIcon = null;
                    break;
                }
            }
        }
        if (o.cdOrig == null) {
            if (!any) return;
            o.cdOrig = cur.clone();
            o.cdW = new int[4];
            o.cdH = new int[4];
            for (int i = 0; i < 4; i++) {
                if (cur[i] == null) continue;
                android.graphics.Rect b = cur[i].getBounds();
                int w = b.width() > 0 ? b.width() : cur[i].getIntrinsicWidth();
                int h = b.height() > 0 ? b.height() : cur[i].getIntrinsicHeight();
                o.cdW[i] = Math.max(0, w);
                o.cdH[i] = Math.max(0, h);
            }
        }
        boolean wantIcon = r != null && r.icon != null && r.icon.length() > 0;
        float f = p.f;
        boolean wantScale = f != 1f;
        if (!wantIcon && !wantScale && !o.cdDirty) return;
        if (!wantIcon) o.cdIcon = null;
        int first = -1;
        for (int i = 0; i < 4; i++) {
            if (o.cdOrig[i] != null) {
                first = i;
                break;
            }
        }
        Drawable[] nd = new Drawable[4];
        boolean sized = false;
        for (int i = 0; i < 4; i++) {
            Drawable base = o.cdOrig[i];
            if (base == null) continue;
            Drawable use = base;
            if (wantIcon && i == first) {
                android.graphics.Bitmap bm = iconBitmap(r.icon);
                if (bm != null) {
                    if (o.cdIcon == null || !r.icon.equals(o.iconSrc)) {
                        o.cdIcon = new IconDrawable(bm, o.cdW[i], o.cdH[i]);
                        o.iconSrc = r.icon;
                    }
                    use = o.cdIcon;
                }
            }
            nd[i] = use;
            if (o.cdW[i] <= 0 || o.cdH[i] <= 0) continue; // size unknown: leave as it is
            int w = Math.max(1, Math.round(o.cdW[i] * (wantScale ? f : 1f)));
            int h = Math.max(1, Math.round(o.cdH[i] * (wantScale ? f : 1f)));
            android.graphics.Rect b = use.getBounds();
            if (b.width() != w || b.height() != h) {
                use.setBounds(0, 0, w, h);
                sized = true;
            }
        }
        if (sized || !sameDrawables(cur, nd)) {
            tv.setCompoundDrawables(nd[0], nd[1], nd[2], nd[3]);
            mods++;
        }
        o.cdDirty = wantIcon || wantScale;
    }

    // ---- facts shown in the panel ------------------------------------------------------------

    /** Original width in dp of the first floating window of this group (menu / button / icon), or 0 if none yet. */
    static int originalWidthDp(Context ctx, String group) {
        try {
            for (java.util.Map.Entry<View, Orig> en : new ArrayList<java.util.Map.Entry<View, Orig>>(ORIG.entrySet())) {
                Orig o = en.getValue();
                if (o == null || !o.isRoot || !o.overlay || o.mw <= 0) continue;
                if (group.equals(effectiveKind(o))) return U.toDp(ctx, o.mw);
            }
        } catch (Throwable t) {
            // none
        }
        return 0;
    }

    /** Stroke width in px that the app's own Paint had before we changed it (0 = none found). */
    static float originalStrokePx() {
        try {
            for (Float f : PAINT_ORIG.values()) {
                if (f != null && f.floatValue() > 0f) return f.floatValue();
            }
        } catch (Throwable t) {
            // none
        }
        return 0f;
    }

    // ---- the list shown in the live editor ---------------------------------------------------

    static String effectiveKind(Orig ro) {
        Rules.Rule r = Rules.get(ro.key);
        return (r != null && r.kind != null) ? r.kind : ro.kind;
    }

    /** Everything visible that has a name: menus, buttons, icons and texts of overlays and of the app screens. */
    static List<El> collect(Context ctx) {
        ArrayList<El> out = new ArrayList<El>();
        List<View> all = roots();
        for (int i = 0; i < all.size() && out.size() < 400; i++) {
            View root = all.get(i);
            if (Panel.isOwn(root)) continue;
            if (ORIG.get(root) == null && (root.getWidth() <= 0 || root.getHeight() <= 0)) continue;
            boolean overlay = isOverlay(root);
            Orig ro = rootOrig(root, overlay);
            String group = overlay ? effectiveKind(ro) : "app";
            if (overlay) {
                El e = new El();
                e.view = root;
                e.o = ro;
                e.root = true;
                e.group = group;
                e.name = rootName(root, group);
                e.line = "line".equals(group) || "canvas".equals(group);
                e.wDp = U.toDp(ctx, root.getWidth());
                e.hDp = U.toDp(ctx, root.getHeight());
                fillOriginal(e, ro, root, ctx);
                e.sub = group + " window  \u2022  " + e.wDp + " x " + e.hDp + " dp";
                out.add(e);
            }
            collectChildren(root, ro, ctx, out, group, 0);
        }
        return out;
    }

    private static void fillOriginal(El e, Orig o, View v, Context ctx) {
        e.owDp = U.toDp(ctx, o.mw > 0 ? o.mw : v.getWidth());
        e.ohDp = U.toDp(ctx, o.mh > 0 ? o.mh : v.getHeight());
        e.otDp = o.textPx > 0 ? Math.round(o.textPx / U.density(ctx)) : 0;
    }

    /** Every window of the app that can be kept or removed, visible or not. */
    static List<Win> windows(Context ctx) {
        ArrayList<Win> out = new ArrayList<Win>();
        List<View> all = roots();
        for (int i = 0; i < all.size() && out.size() < 250; i++) {
            View root = all.get(i);
            if (Panel.isOwn(root)) continue;
            if (ORIG.get(root) == null && (root.getWidth() <= 0 || root.getHeight() <= 0)) continue;
            boolean overlay = isOverlay(root);
            Orig ro = rootOrig(root, overlay);
            Win w = new Win();
            w.root = root;
            w.o = ro;
            w.locked = ro.screen;
            Rules.Rule r = Rules.get(ro.key);
            w.gone = r != null && r.hide;
            w.unsafe = HideGuard.isUnsafe(ro.key);
            w.unsafeShow = HideGuard.isUnsafeShow(ro.key);
            String t = firstText(root, 0);
            if (t != null) {
                t = t.trim();
                if (t.length() > 24) t = t.substring(0, 24);
            }
            if (overlay) {
                w.kind = effectiveKind(ro);
                String label = "menu".equals(w.kind) ? "Menu" : ("icon".equals(w.kind) ? "Menu icon"
                        : ("line".equals(w.kind) ? "Line" : ("canvas".equals(w.kind) ? "Drawing layer" : "Floating button")));
                w.name = t == null ? label : label + ": " + t;
                w.sub = "floating window";
            } else if (ro.screen) {
                w.kind = "screen";
                w.name = "Screen: " + activityName(root.getContext());
                w.sub = "main screen (cannot be removed, only styled)";
            } else {
                w.kind = "popup";
                w.name = t == null ? "Popup / dialog" : "Popup: " + t;
                w.sub = "popup or dialog";
            }
            w.thumb = snapshot(root, 72f, ctx);
            out.add(w);
            if (!w.locked) SEEN.put(ro.key, new String[] {w.name, w.kind, w.sub});
        }
        // windows seen earlier (this run or before) that are closed right now
        for (java.util.Map.Entry<String, String[]> en : SEEN.entrySet()) {
            boolean open = false;
            for (int i = 0; i < out.size(); i++) {
                if (out.get(i).o.key.equals(en.getKey())) {
                    open = true;
                    break;
                }
            }
            if (open) continue;
            Win w = new Win();
            w.o = new Orig();
            w.o.key = en.getKey();
            w.name = en.getValue()[0];
            w.kind = en.getValue()[1];
            w.sub = en.getValue()[2] + "  \u2022  not open now";
            Rules.Rule r = Rules.get(en.getKey());
            w.gone = r != null && r.hide;
            w.unsafe = HideGuard.isUnsafe(en.getKey());
            w.unsafeShow = HideGuard.isUnsafeShow(en.getKey());
            out.add(w);
        }
        return out;
    }

    /** A small picture of a window (drawn in software, never shown on screen). */
    static android.graphics.Bitmap snapshot(View root, float maxDp, Context ctx) {
        try {
            int w = root.getWidth(), h = root.getHeight();
            if (w <= 0 || h <= 0) return null;
            float sc = Math.min(1f, maxDp * U.density(ctx) / Math.max(w, h));
            int bw = Math.max(1, Math.round(w * sc)), bh = Math.max(1, Math.round(h * sc));
            android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(bw, bh,
                    android.graphics.Bitmap.Config.ARGB_8888);
            android.graphics.Canvas c = new android.graphics.Canvas(bmp);
            c.drawColor(0xFF3A3F63);
            c.scale(sc, sc);
            root.draw(c);
            return bmp;
        } catch (Throwable t) {
            return null;
        }
    }

    static org.json.JSONArray seenArray() {
        org.json.JSONArray a = new org.json.JSONArray();
        try {
            for (java.util.Map.Entry<String, String[]> en : SEEN.entrySet()) {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("k", en.getKey());
                o.put("n", en.getValue()[0]);
                o.put("kd", en.getValue()[1]);
                o.put("s", en.getValue()[2]);
                a.put(o);
            }
        } catch (Throwable t) {
            U.err("seen", t);
        }
        return a;
    }

    static void loadSeen(org.json.JSONArray a) {
        if (a == null) return;
        for (int i = 0; i < a.length() && i < 400; i++) {
            org.json.JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String k = o.optString("k", "");
            if (k.length() == 0) continue;
            SEEN.put(k, new String[] {o.optString("n", k), o.optString("kd", "popup"), o.optString("s", "")});
        }
    }

    private static String rootName(View root, String group) {
        String t = firstText(root, 0);
        String label = "menu".equals(group) ? "Menu" : ("icon".equals(group) ? "Floating icon" : "Floating button");
        if (t == null) return label;
        t = t.trim();
        if (t.length() > 24) t = t.substring(0, 24);
        return label + ": " + t;
    }

    private static void collectChildren(View v, Orig o, Context ctx, ArrayList<El> out, String group, int depth) {
        if (!(v instanceof ViewGroup) || depth > 25) return;
        ViewGroup g = (ViewGroup) v;
        for (int i = 0; i < g.getChildCount() && out.size() < 400; i++) {
            View c = g.getChildAt(i);
            if (c == null) continue;
            Orig co = childOrig(c, o, i);
            El e = listed(c, co, ctx, group);
            if (e != null) out.add(e);
            collectChildren(c, co, ctx, out, group, depth + 1);
        }
    }

    private static El listed(View v, Orig o, Context ctx, String group) {
        boolean text = v instanceof TextView;
        boolean image = v instanceof ImageView;
        boolean thin = false;
        boolean visible = (v.isShown() && v.getWidth() > 0 && v.getHeight() > 0) || o.hidden;
        if (!visible) return null;
        String name = null;
        if (text) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null && cs.toString().trim().length() > 0) name = cs.toString().trim();
            if (name == null && v.getContentDescription() != null) name = v.getContentDescription().toString();
            if (name == null && !o.hidden) return null;
        } else if (image) {
            // every visible picture is listed (icons in front of menu options too), so its icon can be replaced
            CharSequence cd = v.getContentDescription();
            if (!v.isClickable() && cd == null && v.getWidth() < U.dp(ctx, 8)) return null;
            name = cd != null ? cd.toString() : "Icon";
        } else if (v.isClickable() && !(v instanceof ViewGroup)) {
            name = v.getClass().getSimpleName();
        } else if (isThin(v, o, U.density(ctx))) {
            name = "Line";
            thin = true;
        } else {
            return null;
        }
        if (name == null) name = text ? "(empty text)" : "Item";
        if (name.length() > 40) name = name.substring(0, 40);
        El e = new El();
        e.view = v;
        e.o = o;
        e.group = group;
        e.isText = text;
        e.isImage = image;
        e.line = thin;
        e.name = name;
        e.wDp = U.toDp(ctx, v.getWidth());
        e.hDp = U.toDp(ctx, v.getHeight());
        fillOriginal(e, o, v, ctx);
        String what = text ? ((v instanceof Button) ? "button" : "text") : (image ? "icon" : "view");
        String id = resName(v);
        e.sub = what + "  \u2022  " + e.wDp + " x " + e.hDp + " dp" + (id == null ? "" : "  \u2022  " + id);
        return e;
    }

    private static ImageView firstImage(ViewGroup g, int depth) {
        if (depth > 3) return null;
        for (int i = 0; i < g.getChildCount() && i < 20; i++) {
            View c = g.getChildAt(i);
            if (c instanceof ImageView && c.getVisibility() == View.VISIBLE) return (ImageView) c;
        }
        for (int i = 0; i < g.getChildCount() && i < 20; i++) {
            View c = g.getChildAt(i);
            if (c instanceof ViewGroup) {
                ImageView r = firstImage((ViewGroup) c, depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    /**
     * The item whose picture a new icon replaces: this item itself when it is a picture or a text with its own icon;
     * otherwise the picture beside the text (same row) or inside the button. Returns its rule key, or null.
     */
    static String iconKeyFor(El e) {
        try {
            View v = e.view;
            if (v == null) return null;
            if (v instanceof ImageView) return e.o.key;
            if (v instanceof TextView) {
                Drawable[] cd = ((TextView) v).getCompoundDrawables();
                for (int i = 0; i < 4; i++) if (cd[i] != null) return e.o.key;
                View up = v;
                for (int lvl = 0; lvl < 2 && up.getParent() instanceof ViewGroup; lvl++) {
                    ViewGroup g = (ViewGroup) up.getParent();
                    for (int i = 0; i < g.getChildCount() && i < 20; i++) {
                        View c = g.getChildAt(i);
                        if (c instanceof ImageView && c.getVisibility() == View.VISIBLE) {
                            Orig bo = ORIG.get(c);
                            if (bo != null) return bo.key;
                        }
                    }
                    up = g;
                }
            }
            if (v instanceof ViewGroup) {
                ImageView iv = firstImage((ViewGroup) v, 0);
                if (iv != null) {
                    Orig bo = ORIG.get(iv);
                    if (bo != null) return bo.key;
                }
            }
        } catch (Throwable t) {
            // none
        }
        return null;
    }

    /** A small picture of one item as it looks now (null when it cannot be drawn). */
    static android.graphics.Bitmap preview(El e, Context ctx, float maxDp) {
        try {
            View v = e.view;
            if (v == null || !v.isAttachedToWindow()) return null;
            return snapshot(v, maxDp, ctx);
        } catch (Throwable t) {
            return null;
        }
    }

    private static String resName(View v) {
        try {
            int id = v.getId();
            if (id == View.NO_ID || id == 0) return null;
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return null;
        }
    }
}
