package com.liveedit.agent;

import android.content.Context;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.lang.reflect.Field;
import java.util.WeakHashMap;

/**
 * "No beep" for one item (button / menu entry) chosen in the pencil panel.
 * - The normal Android click sound of the item is switched off.
 * - A beep that the app plays itself (ToneGenerator, SoundPool, MediaPlayer) cannot be cut out of the code while the
 *   app runs, so a touch on the item mutes the media stream for a split second (until 0.5 s after the finger lifts) and
 *   puts it back. The item's own touch listener is kept: ours only watches and passes every touch on.
 */
final class Quiet {

    /** How long the sound stays muted after the last touch event of the item. */
    private static final int HOLD_MS = 700;
    private static final int[] STREAMS = {AudioManager.STREAM_MUSIC, AudioManager.STREAM_DTMF,
            AudioManager.STREAM_ALARM, AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION};

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final WeakHashMap<View, Mark> MARKS = new WeakHashMap<View, Mark>();
    private static final boolean[] OURS = new boolean[STREAMS.length];

    private static AudioManager audio;
    private static boolean holding;
    private static boolean reflFailed;
    private static Field fListenerInfo;
    private static Field fTouch;

    private Quiet() {}

    private static final class Mark {
        boolean soundWas = true;
        Watch watch;
        /** Sound makers found in the item's code and set to volume 0, to be put back on undo. */
        final java.util.ArrayList<Object[]> zeroed = new java.util.ArrayList<Object[]>();
        long scanned;
    }

    /** Sits in front of the item's own touch listener, only opens the quiet window, then hands the touch on. */
    private static final class Watch implements View.OnTouchListener {
        final View.OnTouchListener inner;

        Watch(View.OnTouchListener inner) {
            this.inner = inner;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            try {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_UP) begin(v.getContext());
            } catch (Throwable t) {
                U.err("quiet touch", t);
            }
            return inner != null && inner.onTouch(v, e);
        }
    }

    /** This one view has "No beep" ticked (its children get it from the walk). Safe to call again and again. */
    static void apply(View v) {
        if (v == null) return;
        try {
            Mark m = MARKS.get(v);
            if (m == null) {
                m = new Mark();
                m.soundWas = v.isSoundEffectsEnabled();
                MARKS.put(v, m);
            }
            if (v.isSoundEffectsEnabled()) v.setSoundEffectsEnabled(false);
            if (reflFailed) return;
            long now = android.os.SystemClock.uptimeMillis();
            if (now - m.scanned > 2000L) { // the sound makers of this item's code: volume 0
                m.scanned = now;
                zeroVolume(v, m);
            }
            View.OnTouchListener cur = touchOf(v);
            if (cur instanceof Watch) {
                m.watch = (Watch) cur;
            } else if (cur != null || v.isClickable() || v.isLongClickable()) {
                Watch w = new Watch(cur);
                v.setOnTouchListener(w);
                m.watch = w;
            }
        } catch (Throwable t) {
            reflFailed = true;
            U.err("quiet apply", t);
        }
    }

    /** "No beep" was unticked (or never ticked): put the click sound and the touch listener back. */
    static void undo(View v) {
        if (v == null) return;
        Mark m = MARKS.get(v);
        if (m == null) return;
        MARKS.remove(v);
        restoreVolume(m);
        try {
            v.setSoundEffectsEnabled(m.soundWas);
            if (m.watch != null && !reflFailed && touchOf(v) == m.watch) v.setOnTouchListener(m.watch.inner);
        } catch (Throwable t) {
            U.err("quiet undo", t);
        }
    }

    /**
     * Finds what makes the sound of this item in its own code (the fields of its click / touch listeners and of the
     * objects they hold) and sets the VOLUME of that to zero: a MediaPlayer gets volume 0, a ToneGenerator is swapped
     * for a silent one. They are put back on undo. What cannot be reached this way (a SoundPool kept somewhere else)
     * is still covered by the short mute of the sound streams while the item is touched.
     */
    private static void zeroVolume(View v, Mark m) {
        try {
            if (fListenerInfo == null) {
                fListenerInfo = View.class.getDeclaredField("mListenerInfo");
                fListenerInfo.setAccessible(true);
            }
            Object li = fListenerInfo.get(v);
            if (li == null) return;
            java.util.IdentityHashMap<Object, Boolean> seen = new java.util.IdentityHashMap<Object, Boolean>();
            Field[] fs = li.getClass().getDeclaredFields();
            for (int i = 0; i < fs.length; i++) {
                try {
                    fs[i].setAccessible(true);
                    Object o = fs[i].get(li);
                    if (o instanceof Watch) o = ((Watch) o).inner;
                    if (o != null) walk(o, 0, seen, m);
                } catch (Throwable t) {
                    // skip
                }
            }
        } catch (Throwable t) {
            U.err("quiet volume", t);
        }
    }

    private static boolean ours(Class<?> c) {
        String n = c.getName();
        return !(n.startsWith("android.") || n.startsWith("androidx.") || n.startsWith("java.")
                || n.startsWith("javax.") || n.startsWith("kotlin.") || n.startsWith("dalvik.")
                || n.startsWith("com.liveedit.") || c.isPrimitive() || c.isArray());
    }

    private static void walk(Object o, int depth, java.util.IdentityHashMap<Object, Boolean> seen, Mark m) {
        if (o == null || depth > 3 || seen.containsKey(o) || seen.size() > 200) return;
        seen.put(o, Boolean.TRUE);
        Class<?> c = o.getClass();
        int guard = 0;
        while (c != null && c != Object.class && guard++ < 5) {
            if (!ours(c)) break;
            Field[] fs;
            try {
                fs = c.getDeclaredFields();
            } catch (Throwable t) {
                break;
            }
            for (int i = 0; i < fs.length && i < 120; i++) {
                try {
                    Field f = fs[i];
                    if (java.lang.reflect.Modifier.isStatic(f.getModifiers()) || f.getType().isPrimitive()) continue;
                    f.setAccessible(true);
                    Object x = f.get(o);
                    if (x == null) continue;
                    if (x instanceof android.media.MediaPlayer) {
                        try {
                            ((android.media.MediaPlayer) x).setVolume(0f, 0f);
                            m.zeroed.add(new Object[] {x, null, null});
                        } catch (Throwable t) {
                            // wrong state: skip
                        }
                    } else if (x instanceof android.media.ToneGenerator) {
                        android.media.ToneGenerator silent = new android.media.ToneGenerator(
                                AudioManager.STREAM_MUSIC, 0);
                        f.set(o, silent);
                        m.zeroed.add(new Object[] {x, f, o});
                    } else if (x instanceof View || x instanceof Context) {
                        continue;
                    } else if (ours(x.getClass())) {
                        walk(x, depth + 1, seen, m);
                    }
                } catch (Throwable t) {
                    // not readable: skip
                }
            }
            c = c.getSuperclass();
        }
    }

    private static void restoreVolume(Mark m) {
        for (int i = 0; i < m.zeroed.size(); i++) {
            Object[] z = m.zeroed.get(i);
            try {
                if (z[0] instanceof android.media.MediaPlayer) {
                    ((android.media.MediaPlayer) z[0]).setVolume(1f, 1f);
                } else if (z[1] != null) {
                    ((Field) z[1]).set(z[2], z[0]);
                }
            } catch (Throwable t) {
                // ignore
            }
        }
        m.zeroed.clear();
        m.scanned = 0;
    }

    private static View.OnTouchListener touchOf(View v) throws Exception {
        if (fListenerInfo == null) {
            fListenerInfo = View.class.getDeclaredField("mListenerInfo");
            fListenerInfo.setAccessible(true);
        }
        Object li = fListenerInfo.get(v);
        if (li == null) return null;
        if (fTouch == null) {
            fTouch = li.getClass().getDeclaredField("mOnTouchListener");
            fTouch.setAccessible(true);
        }
        return (View.OnTouchListener) fTouch.get(li);
    }

    private static void begin(Context ctx) {
        if (Build.VERSION.SDK_INT < 23 || ctx == null) return;
        try {
            if (audio == null) audio = (AudioManager) ctx.getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
            if (audio == null) return;
            if (!holding) {
                holding = true;
                for (int i = 0; i < STREAMS.length; i++) {
                    try {
                        if (!audio.isStreamMute(STREAMS[i])) {
                            audio.adjustStreamVolume(STREAMS[i], AudioManager.ADJUST_MUTE, 0);
                            OURS[i] = true;
                        }
                    } catch (Throwable t) {
                        OURS[i] = false;
                    }
                }
            }
            H.removeCallbacks(RELEASE);
            H.postDelayed(RELEASE, HOLD_MS);
        } catch (Throwable t) {
            U.err("quiet begin", t);
        }
    }

    private static final Runnable RELEASE = new Runnable() {
        @Override
        public void run() {
            for (int i = 0; i < STREAMS.length; i++) {
                if (!OURS[i]) continue;
                OURS[i] = false;
                try {
                    audio.adjustStreamVolume(STREAMS[i], AudioManager.ADJUST_UNMUTE, 0);
                } catch (Throwable t) {
                    U.err("quiet release", t);
                }
            }
            holding = false;
        }
    };
}
