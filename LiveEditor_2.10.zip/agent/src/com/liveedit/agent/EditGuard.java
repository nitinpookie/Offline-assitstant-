package com.liveedit.agent;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Keeps an app alive when one of our edits does not agree with it (a changed text, a colour, a size, an icon, a sound).
 *
 * - Every edit is grouped in a category (alpha, size, colour, line, sound, icon, text). When one is applied or changed
 *   it is written down (with the time). If the app is still running a few seconds later, the note is dropped.
 * - If the app closed in that time, the next start finds the note and switches off THAT category of THAT item (the
 *   most risky one of the last changes first). Everything else you edited keeps working, so the app can still be
 *   customised, just without the one thing it cannot take. Items > the item > "Try again" brings it back.
 * - Leaving the app on purpose (home button, swipe away) is not a crash: the notes are dropped when the last screen is
 *   stopped.
 * - Edits wait about two seconds after the app starts, so they never meet the app's own start-up checks.
 */
final class EditGuard {
    /** Order = how risky: the last ones are blamed first when several were applied together. */
    static final String[] CATS = {"alpha", "size", "color", "line", "sound", "icon", "text"};
    static final int ALPHA = 0, SIZE = 1, COLOR = 2, LINE = 3, SOUND = 4, ICON = 5, TEXT = 6;

    private static final String STAMP = "liveedit_edit_stamp.txt";
    private static final String BLOCK = "liveedit_edit_blocked.txt";
    private static final long SAFE_AFTER_MS = 7000L;
    private static final long START_DELAY_MS = 2000L;

    private static Context app;
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static long t0 = SystemClock.elapsedRealtime();
    private static final HashSet<String> blocked = new HashSet<String>();
    private static final LinkedHashMap<String, Long> recent = new LinkedHashMap<String, Long>();
    private static long lastNote;
    private static boolean writePending;
    private static boolean beating;
    private static final int[] gsig = new int[CATS.length];

    private EditGuard() {}

    private static final Runnable WRITE = new Runnable() {
        @Override
        public void run() {
            writePending = false;
            writeStamp();
        }
    };

    private static final Runnable BEAT = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.elapsedRealtime();
            if (recent.isEmpty() || now - lastNote > SAFE_AFTER_MS) {
                recent.clear();
                beating = false;
                delete(STAMP);
                return;
            }
            writeStamp();
            H.postDelayed(this, 1000);
        }
    };

    /** Called once at start (before any edit is applied). */
    static void init(Context c) {
        app = c.getApplicationContext() == null ? c : c.getApplicationContext();
        t0 = SystemClock.elapsedRealtime();
        try {
            for (String l : readLines(BLOCK)) {
                if (l.length() > 0) blocked.add(l);
            }
            ArrayList<String[]> notes = new ArrayList<String[]>();
            long maxT = 0;
            long beat = -1;
            for (String l : readLines(STAMP)) {
                String[] p = l.split("\t");
                if (p.length >= 3 && p[0].equals("N")) {
                    notes.add(p);
                    maxT = Math.max(maxT, parse(p[2]));
                } else if (p.length >= 2 && p[0].equals("H")) {
                    beat = parse(p[1]);
                }
            }
            if (!notes.isEmpty()) {
                if (beat > maxT) maxT = beat;
                // the app closed within seconds of these changes: blame the riskiest of the latest ones
                String pick = null;
                int bestPri = -1;
                for (int i = 0; i < notes.size(); i++) {
                    String[] p = notes.get(i);
                    if (parse(p[2]) < maxT - 1500L) continue;
                    int pri = catIndex(p[1]);
                    if (pri >= bestPri) {
                        bestPri = pri;
                        pick = p[1];
                    }
                }
                if (pick != null) {
                    blocked.add(pick);
                    writeBlocked();
                    final String cat = pick.substring(pick.lastIndexOf('|') + 1);
                    H.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Toast.makeText(app, "Live Editor: the app closed right after a " + cat
                                        + " change. That one change is switched off for that item now; everything "
                                        + "else stays. (Items > the item > Try again)", Toast.LENGTH_LONG).show();
                            } catch (Throwable t) {
                                // ignore
                            }
                        }
                    }, 4500);
                }
                delete(STAMP);
            }
        } catch (Throwable t) {
            U.err("edit guard init", t);
        }
    }

    /** Edits are applied only after the app had its first moments in peace. */
    static boolean ready() {
        return SystemClock.elapsedRealtime() - t0 >= START_DELAY_MS;
    }

    static boolean blocked(String key, String cat) {
        return !blocked.isEmpty() && key != null && blocked.contains(key + "|" + cat);
    }

    /** True when any category of this item is switched off. */
    static boolean blockedKey(String key) {
        if (blocked.isEmpty() || key == null) return false;
        String pre = key + "|";
        for (String b : blocked) if (b.startsWith(pre)) return true;
        return false;
    }

    /** "text, colour" of the switched-off categories of an item (empty when none). */
    static String blockedNames(String key) {
        StringBuilder sb = new StringBuilder();
        if (blocked.isEmpty() || key == null) return "";
        for (int i = 0; i < CATS.length; i++) {
            if (blocked.contains(key + "|" + CATS[i])) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(CATS[i]);
            }
        }
        return sb.toString();
    }

    static int count() {
        return blocked.size();
    }

    static void unblockKey(String key) {
        if (key == null) return;
        String pre = key + "|";
        for (String b : new ArrayList<String>(blocked)) if (b.startsWith(pre)) blocked.remove(b);
        writeBlocked();
    }

    static void forgetAll() {
        blocked.clear();
        recent.clear();
        delete(BLOCK);
        delete(STAMP);
    }

    /** The edits of this item that are switched off are taken out of the rule (a copy; the real rule is kept). */
    static Rules.Rule mask(String key, Rules.Rule r) {
        if (r == null || blocked.isEmpty() || !blockedKey(key)) return r;
        Rules.Rule c = r.copy();
        if (blocked(key, "text")) {
            c.name = null;
            c.text = Rules.NONE;
        }
        if (blocked(key, "size")) {
            c.w = Rules.NONE;
            c.h = Rules.NONE;
        }
        if (blocked(key, "color")) {
            c.textColor = Rules.NONE;
            c.bgColor = Rules.NONE;
        }
        if (blocked(key, "line")) c.thick = Rules.NONE;
        if (blocked(key, "sound")) c.quiet = false;
        if (blocked(key, "icon")) c.icon = null;
        if (blocked(key, "alpha")) c.alpha = Rules.NONE;
        return c;
    }

    /** An edit of category cat was applied or changed on this item. */
    static void note(String key, int cat) {
        if (app == null || key == null || blocked(key, CATS[cat])) return;
        long now = SystemClock.elapsedRealtime();
        recent.put(key + "|" + CATS[cat], Long.valueOf(now));
        lastNote = now;
        if (!writePending) {
            writePending = true;
            H.postDelayed(WRITE, 300);
        }
        if (!beating) {
            beating = true;
            H.postDelayed(BEAT, 1000);
        }
    }

    /** A setting that applies to the whole app (theme colours, one line thickness): key "*". */
    static void noteGlobal(int cat, int hash) {
        int h = hash * 31 + 7;
        if (gsig[cat] != h) {
            gsig[cat] = h;
            note("*", cat);
        }
    }

    /** The user left the app on purpose: whatever happens to the process now is not a crash. */
    static void settle() {
        recent.clear();
        delete(STAMP);
    }

    // ---- tiny storage ---------------------------------------------------------------------

    private static int catIndex(String keyCat) {
        String c = keyCat.substring(keyCat.lastIndexOf('|') + 1);
        for (int i = 0; i < CATS.length; i++) if (CATS[i].equals(c)) return i;
        return 0;
    }

    private static long parse(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (Throwable t) {
            return 0L;
        }
    }

    private static ArrayList<String> readLines(String name) {
        ArrayList<String> out = new ArrayList<String>();
        try {
            File f = new File(app.getFilesDir(), name);
            if (!f.exists()) return out;
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f),
                    StandardCharsets.UTF_8));
            try {
                String l;
                int n = 0;
                while ((l = r.readLine()) != null && n++ < 4000) out.add(l);
            } finally {
                r.close();
            }
        } catch (Throwable t) {
            // unreadable: empty
        }
        return out;
    }

    private static void writeFile(String name, String text) {
        try {
            FileOutputStream out = new FileOutputStream(new File(app.getFilesDir(), name));
            try {
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.getFD().sync(); // reaches the disk even if the app is killed a moment later
            } finally {
                out.close();
            }
        } catch (Throwable t) {
            U.err("edit guard write", t);
        }
    }

    private static void writeStamp() {
        if (app == null || recent.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Long> e : new ArrayList<Map.Entry<String, Long>>(recent.entrySet())) {
            sb.append("N\t").append(e.getKey().replace('\t', ' ').replace('\n', ' ')).append('\t')
                    .append(e.getValue()).append('\n');
        }
        sb.append("H\t").append(SystemClock.elapsedRealtime()).append('\n');
        writeFile(STAMP, sb.toString());
    }

    private static void writeBlocked() {
        if (app == null) return;
        StringBuilder sb = new StringBuilder();
        for (String b : blocked) sb.append(b.replace('\t', ' ').replace('\n', ' ')).append('\n');
        writeFile(BLOCK, sb.toString());
    }

    private static void delete(String name) {
        try {
            if (app != null) new File(app.getFilesDir(), name).delete();
        } catch (Throwable t) {
            // ignore
        }
    }
}
