# Chanit Assistant (offline voice assistant)

Bolo "oye pookie" -> beep -> command. Sab offline. Hindi + English + Hinglish.

## Build (purani repo se)
Repo ke root mein is zip ko (`iLauncher-GITHUB-READY.zip`) upload karo (purana zip replace ho jayega).
Wahi purana workflow (`Build iLauncher APK`) isko build karega. Actions > artifact `iLauncher-APK-run...`.

## Pehli baar setup (app ke andar steps 1-8)
1 permissions, 2 overlay, 3 voice models (net chahiye, ek baar), 4 AI model (optional, sawal-jawab),
5 battery, 6 accessibility (screen control / camera / WhatsApp send), 7 brightness, 8 default assistant.
Phir "Train wake word" dabao aur 3 baar "oye pookie" bolo. Phir Start.

## Icon hide karna
"Hide from home screen" dabao. Wapas kholne ke liye: Settings > Apps > Chanit Assistant > App settings,
ya Quick Settings mein "Assistant" tile, ya dialer mein *#*#2580#*#*.

## Lock screen
Phone lock hone par sirf call chalega ("Rahul ko call karo"). Baaki sab "phone lock hai" bolega.
Checkbox se poora band bhi kar sakte ho.

## Commands
call / message / whatsapp, open app, torch, alarm, timer, reminder, notes, calculator, music (play/pause/next),
photo/selfie/video, home/back/screenshot/lock/scroll/click <name>, volume, brightness, battery, time, date,
"new command" (apne commands), baaki sab AI se.

## Voice
App mein "Voice (how I sound)": English (India) voice choose karo, speed / pitch / pause sliders, "hmm" filler, Test button.
Behtar voice ke liye: Settings > System > Languages > Text-to-speech > Google > Install voice data > English (India).

## New black UI
- Big ON/OFF switch (green = listening), live download bars for the Hindi + English voice pack.
- Only missing permissions are shown; once granted they disappear.
- Siri-style pill (animated waves + glowing edge) appears over any app when the wake phrase is heard.
- Say "oye pookie" once -> "Hmm, bolo ji, kya kaam hai?" -> speak the command.
- Language is fixed to Hindi + English + Hinglish (no language options).
