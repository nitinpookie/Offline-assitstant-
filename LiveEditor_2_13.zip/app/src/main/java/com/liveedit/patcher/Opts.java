package com.liveedit.patcher;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Everything the user can choose before patching. Plain values, so the screen can read and write them freely. */
final class Opts {

    // ---- app identity (empty text = keep the original) --------------------------------------
    String appName = "";
    String versionName = "";
    String versionCode = "";

    // ---- permissions and parts of the app ---------------------------------------------------
    final Set<String> removePerms = new LinkedHashSet<String>();
    final Set<String> disableComps = new LinkedHashSet<String>();

    // ---- screen and system flags (manifest) -------------------------------------------------
    /** 0 keep, 1 portrait, 2 landscape, 3 auto-rotate always, 4 follow phone setting. */
    int orientation;
    /** 0 keep, 1 on, 2 off. */
    int debuggable;
    int backup;
    int cleartext;
    int largeHeap;

    // ---- APK size ---------------------------------------------------------------------------
    /** Only this CPU type stays in the APK. Null keeps all. */
    String keepAbi;
    /** Rebuild the zip cleanly (fake-encryption flags, wrong sizes) so tools like MT Manager can open every file. */
    boolean normalize;
    /** Best effort: let an app run on this phone although none of its native libraries fit the phone's CPU. */
    boolean armCompat;
    /** Set while patching (never by the screen): the engine keeps the app alive when a native library is missing. */
    boolean guard;

    // ---- engine inside the app (no screen, just carries these out) ----------------------------
    /** Live Editor (pencil handle) inside the patched app. */
    boolean live;
    /** Sizes are percent of the original (100 = original, never smaller); opacity percent; text size percent. */
    int iconPct = 100;
    int iconAlpha = 100;
    int iconText = 100;
    int btnPct = 100;
    int btnAlpha = 100;
    int btnText = 100;
    int menuPct = 100;
    int menuAlpha = 100;
    int menuText = 100;
    /** Sizes in dp: every window of the group gets this width (0 = keep the original / use the old percent). */
    int iconDp;
    int btnDp;
    int menuDp;
    /** Text size change in dp (-20 .. +60) for the texts of each group (0 = original). */
    int iconTextDp;
    int btnTextDp;
    int menuTextDp;
    /** Thickness of line overlays in TENTHS of a dp (5 = 0.5 dp, 0 = keep). */
    int lineT;
    /** Origin lines: PNG marker on every line end (1..20 dp, upright), distance in meters, red when close. */
    boolean tipOn;
    int tipDp = 8;
    int tipAnchor;
    String tipPng = "";
    boolean distOn;
    int distScale = 30;
    int distPos;
    boolean nearRed = true;
    int nearM = 10;
    /** 0 keep, 1 block links at app start, 2 block all links that leave the app. */
    int links;
    /** 0 keep, 1 hide timer texts, 2 replace timer texts. */
    int timers;
    String timerText = "";
    boolean themeOn;
    int themeBg = 0xFF101418;
    int themeText = 0xFFECEFF4;
    int themeAccent = 0xFF7C5CFF;
    /** Per-item rules made in the live editor (JSON array text). */
    String rules = "[]";
    boolean mute;
    boolean keepOn;
    boolean allowShot;
    boolean immersive;
    boolean hideAds;
    /** 0 normal, 1 faster, 2 off. */
    int anim;
    boolean blockAds;
    boolean blockTrackers;
    final Set<String> blockHosts = new LinkedHashSet<String>();
    /** Edited timers: key "dex:offset:originalMs" (from the timer scan) -> new delay in ms, -1 = never fires. */
    final java.util.Map<String, Long> timerEdits = new java.util.LinkedHashMap<String, Long>();
    String customHosts = "";

    void reset() {
        appName = "";
        versionName = "";
        versionCode = "";
        removePerms.clear();
        disableComps.clear();
        orientation = 0;
        debuggable = 0;
        backup = 0;
        cleartext = 0;
        largeHeap = 0;
        keepAbi = null;
        normalize = false;
        armCompat = false;
        guard = false;
        live = false;
        iconPct = 100;
        iconAlpha = 100;
        iconText = 100;
        btnPct = 100;
        btnAlpha = 100;
        btnText = 100;
        menuPct = 100;
        menuAlpha = 100;
        menuText = 100;
        iconDp = 0;
        btnDp = 0;
        menuDp = 0;
        iconTextDp = 0;
        btnTextDp = 0;
        menuTextDp = 0;
        lineT = 0;
        tipOn = false;
        tipDp = 8;
        tipAnchor = 0;
        tipPng = "";
        distOn = false;
        distScale = 30;
        distPos = 0;
        nearRed = true;
        nearM = 10;
        links = 0;
        timers = 0;
        timerText = "";
        themeOn = false;
        themeBg = 0xFF101418;
        themeText = 0xFFECEFF4;
        themeAccent = 0xFF7C5CFF;
        rules = "[]";
        mute = false;
        keepOn = false;
        allowShot = false;
        immersive = false;
        hideAds = false;
        anim = 0;
        blockAds = false;
        blockTrackers = false;
        blockHosts.clear();
        customHosts = "";
        timerEdits.clear();
    }

    /** Every server the engine must keep the app away from (clean names, no duplicates). */
    List<String> allHosts() {
        LinkedHashSet<String> out = new LinkedHashSet<String>();
        if (blockAds) for (String h : Presets.AD_HOSTS) out.add(h);
        if (blockTrackers) for (String h : Presets.TRACKER_HOSTS) out.add(h);
        for (String h : blockHosts) addHost(out, h);
        for (String h : customHosts.split("[,;\\s]+")) addHost(out, h);
        return new ArrayList<String>(out);
    }

    private static void addHost(Set<String> out, String raw) {
        String h = cleanHost(raw);
        if (h.length() > 3 && h.indexOf('.') > 0) out.add(h);
    }

    static String cleanHost(String s) {
        String h = s == null ? "" : s.trim().toLowerCase(Locale.US);
        int p = h.indexOf("://");
        if (p >= 0) h = h.substring(p + 3);
        int slash = h.indexOf('/');
        if (slash >= 0) h = h.substring(0, slash);
        int colon = h.indexOf(':');
        if (colon >= 0) h = h.substring(0, colon);
        while (h.startsWith("*") || h.startsWith(".")) h = h.substring(1);
        return h;
    }

    boolean lookChanged() {
        return iconPct != 100 || iconAlpha != 100 || iconText != 100 || btnPct != 100 || btnAlpha != 100
                || btnText != 100 || menuPct != 100 || menuAlpha != 100 || menuText != 100 || lineT != 0 || tipOn || distOn
                || iconDp != 0 || btnDp != 0 || menuDp != 0 || iconTextDp != 0 || btnTextDp != 0 || menuTextDp != 0;
    }

    int ruleCount() {
        try {
            return new JSONArray(rules).length();
        } catch (Exception e) {
            return 0;
        }
    }

    boolean needsEngine() {
        return live || lookChanged() || links != 0 || timers != 0 || themeOn || ruleCount() > 0
                || mute || keepOn || allowShot || immersive || hideAds || anim != 0 || !allHosts().isEmpty() || guard;
    }

    static String hexOf(int c) {
        return String.format(Locale.US, "#%06X", c & 0xFFFFFF);
    }

    /** "#RRGGBB" or "RRGGBB"; anything else keeps the old colour. */
    static int hex(String s, int old) {
        try {
            String t = s.trim();
            if (t.startsWith("#")) t = t.substring(1);
            if (t.length() != 6) return old;
            return 0xFF000000 | Integer.parseInt(t, 16);
        } catch (Exception e) {
            return old;
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Reads a settings text (from the live editor's "Copy settings" or from inside a live APK). */
    void importJson(String text) throws Exception {
        JSONObject o = new JSONObject(text.trim());
        live = o.optBoolean("live", live);
        iconPct = clamp(o.optInt("iconPct", iconPct), 20, 500);
        iconAlpha = clamp(o.optInt("iconAlpha", iconAlpha), 10, 100);
        iconText = clamp(o.optInt("iconTextPct", iconText), 50, 400);
        btnPct = clamp(o.optInt("btnPct", btnPct), 20, 500);
        btnAlpha = clamp(o.optInt("btnAlpha", btnAlpha), 10, 100);
        btnText = clamp(o.optInt("btnTextPct", btnText), 50, 400);
        menuPct = clamp(o.optInt("menuPct", menuPct), 20, 500);
        menuAlpha = clamp(o.optInt("menuAlpha", menuAlpha), 10, 100);
        menuText = clamp(o.optInt("menuTextPct", menuText), 50, 400);
        iconDp = clamp(o.optInt("iconDp", iconDp), 0, 900);
        btnDp = clamp(o.optInt("btnDp", btnDp), 0, 900);
        menuDp = clamp(o.optInt("menuDp", menuDp), 0, 1200);
        iconTextDp = clamp(o.optInt("iconTextDp", iconTextDp), -20, 60);
        btnTextDp = clamp(o.optInt("btnTextDp", btnTextDp), -20, 60);
        menuTextDp = clamp(o.optInt("menuTextDp", menuTextDp), -20, 60);
        if (o.has("lineT")) lineT = clamp(o.optInt("lineT", lineT), 0, 600);
        else if (o.has("lineDp")) lineT = clamp(o.optInt("lineDp", 0) * 10, 0, 600);
        tipOn = o.optBoolean("tipOn", tipOn);
        tipDp = clamp(o.optInt("tipDp", tipDp), 1, 20);
        tipAnchor = clamp(o.optInt("tipAnchor", tipAnchor), 0, 1);
        if (o.has("tipPng")) tipPng = o.optString("tipPng", "");
        distOn = o.optBoolean("distOn", distOn);
        distScale = clamp(o.optInt("distScale", distScale), 1, 600);
        distPos = clamp(o.optInt("distPos", distPos), 0, 1);
        nearRed = o.optBoolean("nearRed", nearRed);
        nearM = clamp(o.optInt("nearM", nearM), 1, 500);
        mute = o.optBoolean("mute", mute);
        keepOn = o.optBoolean("keepOn", keepOn);
        allowShot = o.optBoolean("allowShot", allowShot);
        immersive = o.optBoolean("immersive", immersive);
        hideAds = o.optBoolean("hideAds", hideAds);
        anim = clamp(o.optInt("anim", anim), 0, 2);
        links = clamp(o.optInt("links", links), 0, 2);
        timers = clamp(o.optInt("timers", timers), 0, 2);
        timerText = o.optString("timerText", timerText);
        JSONObject th = o.optJSONObject("theme");
        if (th != null) {
            themeOn = th.optBoolean("on", themeOn);
            themeBg = th.optInt("bg", themeBg) | 0xFF000000;
            themeText = th.optInt("text", themeText) | 0xFF000000;
            themeAccent = th.optInt("accent", themeAccent) | 0xFF000000;
        }
        JSONArray b = o.optJSONArray("block");
        if (b != null) {
            blockHosts.clear();
            for (int i = 0; i < b.length(); i++) {
                String h = cleanHost(b.optString(i, ""));
                if (h.length() > 3 && h.indexOf('.') > 0) blockHosts.add(h);
            }
        }
        JSONArray r = o.optJSONArray("rules");
        if (r != null) rules = r.toString();
        JSONArray te = o.optJSONArray("timerEdits");
        if (te != null) {
            timerEdits.clear();
            for (int i = 0; i < te.length(); i++) {
                JSONObject t = te.optJSONObject(i);
                if (t != null && t.optString("k", "").length() > 0) timerEdits.put(t.optString("k"), t.optLong("ms", -1));
            }
        }
    }

    /** The file that is baked into the APK for the engine to read. */
    String configJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("v", 3);
        o.put("live", live);
        o.put("iconPct", iconPct);
        o.put("iconAlpha", iconAlpha);
        o.put("iconTextPct", iconText);
        o.put("btnPct", btnPct);
        o.put("btnAlpha", btnAlpha);
        o.put("btnTextPct", btnText);
        o.put("menuPct", menuPct);
        o.put("menuAlpha", menuAlpha);
        o.put("menuTextPct", menuText);
        o.put("iconDp", iconDp);
        o.put("btnDp", btnDp);
        o.put("menuDp", menuDp);
        o.put("iconTextDp", iconTextDp);
        o.put("btnTextDp", btnTextDp);
        o.put("menuTextDp", menuTextDp);
        o.put("lineT", lineT);
        o.put("tipOn", tipOn);
        o.put("tipDp", tipDp);
        o.put("tipAnchor", tipAnchor);
        o.put("tipPng", tipPng == null ? "" : tipPng);
        o.put("distOn", distOn);
        o.put("distScale", distScale);
        o.put("distPos", distPos);
        o.put("nearRed", nearRed);
        o.put("nearM", nearM);
        JSONArray tea = new JSONArray();
        for (java.util.Map.Entry<String, Long> e : timerEdits.entrySet()) {
            JSONObject t = new JSONObject();
            t.put("k", e.getKey());
            t.put("ms", e.getValue().longValue());
            tea.put(t);
        }
        if (tea.length() > 0) o.put("timerEdits", tea);
        o.put("links", links);
        o.put("timers", timers);
        o.put("timerText", timerText);
        o.put("guard", guard);
        JSONObject th = new JSONObject();
        th.put("on", themeOn);
        th.put("bg", themeBg);
        th.put("text", themeText);
        th.put("accent", themeAccent);
        o.put("theme", th);
        o.put("rules", new JSONArray(rules));
        o.put("mute", mute);
        o.put("keepOn", keepOn);
        o.put("allowShot", allowShot);
        o.put("immersive", immersive);
        o.put("hideAds", hideAds);
        o.put("anim", anim);
        JSONArray a = new JSONArray();
        for (String h : allHosts()) a.put(h);
        o.put("block", a);
        return o.toString(2);
    }

    /** How many separate choices are different from "keep original". Shown on the Patch button. */
    int changeCount() {
        int n = 0;
        if (appName.trim().length() > 0) n++;
        if (versionName.trim().length() > 0) n++;
        if (versionCode.trim().length() > 0) n++;
        if (!removePerms.isEmpty()) n++;
        if (!disableComps.isEmpty()) n++;
        if (orientation != 0) n++;
        if (debuggable != 0) n++;
        if (backup != 0) n++;
        if (cleartext != 0) n++;
        if (largeHeap != 0) n++;
        if (keepAbi != null) n++;
        if (normalize) n++;
        if (armCompat) n++;
        if (live) n++;
        if (iconPct != 100 || iconAlpha != 100 || iconText != 100 || iconDp != 0 || iconTextDp != 0) n++;
        if (btnPct != 100 || btnAlpha != 100 || btnText != 100 || btnDp != 0 || btnTextDp != 0) n++;
        if (menuPct != 100 || menuAlpha != 100 || menuText != 100 || menuDp != 0 || menuTextDp != 0) n++;
        if (lineT != 0) n++;
        if (tipOn) n++;
        if (distOn) n++;
        if (links != 0) n++;
        if (timers != 0) n++;
        if (!timerEdits.isEmpty()) n++;
        if (themeOn) n++;
        if (ruleCount() > 0) n++;
        if (mute) n++;
        if (keepOn) n++;
        if (allowShot) n++;
        if (immersive) n++;
        if (hideAds) n++;
        if (anim != 0) n++;
        if (blockAds) n++;
        if (blockTrackers) n++;
        if (!blockHosts.isEmpty() || customHosts.trim().length() > 0) n++;
        return n;
    }
}
