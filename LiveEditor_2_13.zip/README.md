# Live Editor

Pro APK patcher for Android. Pick an app, tick the options you want, tap **Patch**.

## What you can change (no coding)
- App name, version name, version code
- Remove permissions (internet, location, contacts, camera ... or any you tick)
- Switch off parts of the app (auto-start after boot, services, screens)
- Block ad servers, tracker servers, servers found inside the app, or your own list
- Hide ad banners, mute click sounds, fullscreen, keep screen on, allow screenshots
- Lock rotation, faster or no animations
- Debuggable / backup / plain HTTP / large heap flags
- Keep only one CPU type (smaller APK) + a "compatible with this phone" check (ARMv7 etc.)
- One-tap presets: Privacy, Ads off, Smaller, Faster UI

### New in 2.0
- **Floating buttons and Menu are separate.** Size (in **dp**), opacity (%), text size (dp). Changing the buttons no
  longer makes the menu huge (the old single "overlay size" scaled everything in every overlay window).
- **Live Editor inside the app** (optional switch): a pencil handle appears in the patched app. It lists everything
  that is visible (menus, floating buttons, icons, texts of overlays AND app screens / login page; background-only
  parts are not listed). Tap any item to change **size (dp), text size (dp), colour, name, opacity, hide**.
  Global button / menu sliders and a theme editor are in the same panel. Values are shown in dp, opacity in %.
- **App theme**: background, text and button colours for the whole app (ready-made themes or your own hex colours).
- **Links**: block links that throw you out of the app (browser, Telegram, Play Store ...) at app start or always.
  The link is skipped, the app keeps running (no crash).
- **Timers**: hide or replace countdown-like texts (00:59, "3 days left" ...).
- **Convert live APK to normal**: in the pencil panel tap *More > Copy settings*. In Live Editor choose
  *Convert live APK to normal*, pick that app, tap *Paste settings*, leave "Live Editor inside the app" off, Patch.
  You get a normal APK with all edits baked in and no handle.
- **ARMv7 / your CPU**: the options screen tells if the app has libraries for your phone and can keep only that CPU type.
  Native libraries cannot be converted from one CPU type to another (an arm64-only app cannot run on an ARMv7 phone).

### New in 2.1
- **Normal structure (for MT Manager)**: options screen > *Normal APK*. Every file is opened and checked; zip tricks that stop
  tools from opening the code files (a fake "encrypted" flag, a wrong size or checksum in the header) are repaired. The files
  themselves are not changed. An APK that Android's zip reader refuses is repaired automatically when you pick it.
  Code that is packed or encrypted by a protection tool is NOT unpacked (it only unpacks while the app runs): it stays as it is.
- **ARMv7 best-effort mode** (only shown when the app has no libraries for this phone and the phone is ARMv7): the app's native
  libraries are replaced by empty stand-ins (stored, aligned) so it installs and starts. Anything that needs those libraries
  stops working, and the engine keeps the app alive when such a call fails. Some apps will still close.
  The stand-in is an empty 32-bit ARM library built in code (`StubElf.java`); it was checked with `readelf`, not on a real phone.
- **Settings without copy and paste**: when you pick an installed app that was patched with this version, its settings
  (baked edits plus pencil edits) are read straight from it (the engine has a small provider that only answers Live Editor).
  The *Load settings from the installed app* button does the same later. Pasting still works.
- **Timers**: a bare 00:59 is only treated as a timer after it changed a few times within seconds; "10:30 AM", dates and fixed
  labels are left alone. Texts with words like "left" or "expires" still count at once.

### New in 2.2
- **Four separate size groups**: menu icon (the first small floating window = the button that opens the menu), floating
  buttons, menu panels, and line overlays. Each has its own size, opacity and text size. Change one, the others stay.
- **Sizes can go smaller and bigger**: icon, buttons and menu use percent (100% = original, 20% to 400%); every single
  item in the pencil panel shows its original dp and can go below or above it. Text size 50% to 300%.
- **Line thickness**: a thin line window or thin view gets a thickness slider (global and per item) that can go thinner
  or thicker. A line the app paints itself on a canvas cannot be re-drawn from outside.
- **Windows tab (pencil panel)**: a list of every menu, floating button, popup and dialog with a *Keep this interface*
  switch. Removed = hidden and untouchable (touches pass through), never detached, so the app cannot crash from it.
  Popups that are closed now stay in the list. The main screen can be styled but not removed.
- **No flicker**: windows are changed before their first frame (the engine is told the moment the app adds a window)
  and before every later frame of floating windows and popups, so the original look / colour / opacity is never shown
  for a moment. The 0.7 s timer stays as a safety net.
- **Lines drawn by the app itself** (a line from the top origin painted on a canvas): the engine finds the app's Paint
  objects by reflection and sets their stroke width (global *Lines* slider or per item). Works when the app keeps its
  Paint in a field; a Paint created fresh on every draw cannot be reached.
- **Timer editor** (options screen > *Timers in this app*): lists the places in the app's code that start something
  after a delay (Handler.postDelayed, Timer, CountDownTimer, scheduled executors) with the delay in ms. Tap one to set a
  new delay or *Never*; the number is written into classes.dex when you tap Patch (same length, dex checksum and SHA-1
  fixed, APK re-signed). Places up to 32767 ms are edited in place (or Never); a delay that is calculated by the app
  cannot be edited. *LINE:* entries are the numbers next to `Paint.setStrokeWidth` (line thickness): edit them the same
  way (for example 1.5 -> 1). Edits are checked against the real code at patch time and skipped if they do not match.
- **Components list** (*Switch off parts of the app*): the main screen, services and providers are marked, and a
  warning with an *Undo these (safe)* button appears when one of them is switched off (it can crash the app).
- **Windows tab** shows a small picture of each window, so it is clear which interface is which.
- Old settings with sizes in dp are not carried over (sizes are percent now).

### New in 2.3: nixu cn mode (MT Manager style)
Top right of the home screen there is a **nixu cn** switch. ON = the simple options are hidden and the app opens APKs in an
MT Manager style editor (`NixuActivity`). OFF = everything works as before.

- **File list**: every entry of the APK is shown (assets, lib, res, META-INF, classes*.dex, resources.arsc, AndroidManifest.xml ...).
  Nothing is hidden. Folders first, size and date per row, long-press to select, add / replace / rename / delete / extract.
- **Open with...** per file type:
  - `AndroidManifest.xml` and every compiled `res/*.xml`: *XML editor* (compiled XML shown as text, compiled again on save;
    values keep their exact type: `true`, `123`, `0x7f`, `#ffffff`, `16dp`, `@0x7f010001`, `f:1.5`; plain text that looks like
    one of those gets a leading backslash).
  - `resources.arsc`: *Arsc Editor plus* (package > type > resource > configuration), *Arsc Editor* (flat list with search),
    *Translation mode* (every text value, edit once = everywhere), *Resource querier* (search by name, id or value).
    Strings, numbers, booleans, colours, dimensions and references can be changed. A string shared by several entries is
    copied (the other entries keep their text).
  - `classes*.dex`: *Dex Editor Plus* (class list with search, fields, methods, bytecode of a method as text with the address of
    each instruction), *Dex strings*, *Dex method search*.
    Instruction edit: tap a line, type one instruction (`const/4 v0, 0x1`, `if-nez v0, :0012`, `invoke-static {v0}, Lcom/Foo;->bar(I)V`,
    `const-string v0, "text"` ...). It must fit the old instruction (same size or smaller, the rest becomes `nop`), registers must
    exist, references must already exist in this dex (or use `string@12`, `method@34`).
    Quick patches in the menu: return void / true / false / null / a number.
    Strings can be changed in place (same size; a shorter text can be padded with spaces).
  - Text editor, hex editor (tap a row, change the bytes), image viewer.
- **Save**: builds a new APK (untouched entries are copied byte for byte, resources.arsc is stored and aligned), signs it with the
  built-in key (v1 + v2) and offers Install / Share / Save a copy.
- **Export for Claude**: one `.nixu.txt` file with the file list, the manifest as text, all resources, the dex class list
  (optionally methods, or full smali text of the classes whose name contains a filter). Send that file to be read.

Limits of nixu cn (honest):
- The dex editor patches inside the existing file, so nothing can grow: no new classes, methods or strings, no full smali recompile.
  Edit a string only to a text that fits the old size. Keeping dex strings sorted is not re-checked.
- Old signature files (META-INF/*.SF, *.RSA, MANIFEST.MF) are dropped on Save; the new signature replaces them.
- Code packed or encrypted by a protection tool is not unpacked.
- Not run on a phone yet: the file-format engines (`NixuPool/NixuAxml/NixuArsc/NixuDex/NixuZip/NixuExport`) were tested on the
  PC with generated sample files; the screens (`NixuActivity`) were only compile-checked against stand-ins for the Android classes.

### New in 2.4: files are recognised by their bytes, not their names (nixu cn mode)
- **Any file can be a dex.** Long-press / tap a file with an odd name (for example `OoooooOooo`, `d_shell_data_001`): the editor now
  reads it and, if it holds a dex, offers *Dex Editor Plus / Dex strings / Dex method search* even though the name does not end in `.dex`.
- **Damaged dex header** (magic bytes wiped or changed, rest of the header fine): offered as *Dex Editor Plus (repair header)*.
  The editor works on a repaired copy; saving writes the repaired header back.
- **Dex hidden inside another file**: *Open dex found inside, at 0x...* (up to 4 hits per file). It is copied out as
  `<file>_dex_<offset>.dex`, added to the APK file list and opened. Delete that entry if you do not want it in the APK.
- **File info** (new entry in *Open with...* for files with unknown names): size, entropy, first bytes, type by content and
  every dex offset found. It also says plainly when a file is encrypted or compressed.
- *Open with > Dex ...* on a normal `.dex` also repairs a damaged header now.
- **Export for Claude** has a new section *FILES CHECKED BY CONTENT*: every file with an unknown name gets size, entropy, type and
  its first 16 bytes. Files that turn out to be dex are listed with their classes like `classes.dex`.

Still true (honest): if a file is encrypted, no editor can read it from the APK. Packed apps keep their real code encrypted
(for example in `assets/`) and only decrypt it in memory while the app runs, with a loader that sits in the small `classes.dex`.
*File info* shows which of the two cases a file is. Checked on the PC with generated files (valid, damaged-magic, hidden-inside,
random data); the new screens were only syntax-checked, not run on a phone.

### New in 2.5
- **Line thickness can go much thinner**: values are now in tenths of a dp (0.1 dp steps, down to 0.1 dp, up to 20 dp) with
  `- 0.1` / `+ 0.1` buttons, in the patcher app and in the pencil panel (global and per item). The panel also shows the
  original width of a line the app paints itself, in px and in dp (a line drawn with `setStrokeWidth(1.5f)` is 1.5 px, which
  is already thinner than the old 1 dp minimum on most phones). Canvas lines are re-applied every 60 ms.
- **Sizes are in dp, not percent**: icon / floating buttons / menu "Size" is the width in dp every window of that group gets
  (its height follows); the pencil panel shows the original width next to it. "Text size" is now a change in dp
  (-10 ... +30, 0 = original). Old percent settings still load and still work until a dp value is set.
- **Removed interfaces are bypassed, they cannot crash the app any more**:
  - The main screen was not recognised as the main screen on Android 8+ (the activity window's view context is not the
    Activity), so it could be "removed" and the app closed. It is now recognised by its window type and can never be removed.
  - A removed window is no longer made INVISIBLE (which tears down its surface). It stays alive, fully transparent
    (window alpha 0), not touchable, not focusable and without a dim background; every touch goes to the app under it.
  - If bypassing throws an error, the window is kept visible automatically.
  - Crash guard: if the app closes within 5 seconds of a removal, the next start remembers that window as unsafe, keeps it
    visible and shows a message. Windows tab > *Allow removing the kept-visible windows again* clears the marks.
- **Auto on / off timer removed (2.4.1).** The timer that switched a button on and off by itself, with its seconds, chips and
  pictures, is gone from the patcher app and from the pencil panel. Buttons are manual: ON stays ON, OFF stays OFF.
  To get rid of a button's own auto-off time use the patcher card *Button that turns itself off, and its beep*: the
  delay becomes "never", so the button only changes when you press it.
- **No beep on a button (pencil panel).** Items > pick the button > tick *No beep / click sound on this button*. The
  normal Android click sound of that item (and everything inside it) is switched off. A beep the app plays itself
  (ToneGenerator, SoundPool, MediaPlayer) cannot be cut out while the app runs, so touching the item mutes the media
  sound for 0.5 s and puts it back (`Quiet.java`); the app's own touch handling is kept. A beep on another sound
  channel is not covered: use the patcher card *Button that turns itself off, and its beep* for that.
- Not run on a phone here: the code was syntax-checked with the JDK compiler on a PC only (no Android SDK in this environment).
  Build it with the usual workflow and test the four changes.

### New in 2.6
- **Button that turns itself off, and its beep** (patcher app, options: card *Button that turns itself off, and its beep*):
  *Find the auto-off timer and the beep, then remove them* searches the code of the app for a plain delay of 1 to 3 seconds
  (`postDelayed`, `Thread.sleep`, Kotlin `delay()`, `Timer`, `CountDownTimer`, scheduled tasks) and for sounds
  (`ToneGenerator.startTone`, `MediaPlayer.start`, `SoundPool.play`, `AudioTrack.play`, `Ringtone.play`,
  `playSoundEffect`). You get the list with the likely ones already ticked (timers of 1-3 s; beeps in the same class as a
  ticked timer, or all of them when the app has only a few). *Remove ticked* sets each delay to **never** (the number in
  the code becomes a delay of hundreds of millions of years) and cuts the sound call out (the call and a `move-result` after
  it become `nop`). It is written into `classes*.dex` when you tap Patch (same length, dex checksum and SHA-1 fixed).
  The full list (*Timers in this app*) shows `BEEP:` entries too, tap one to remove only that sound.
  Tested on the PC with generated dex files (the delay, the sound call and the `move-result` after it); not run on a phone.
  If the search finds nothing (the delay is calculated by the app, or the code is packed), export the file list from the
  nixu cn editor and send it.
- **Menu icon and floating buttons now shrink as well as grow**, whatever their layout: the content of the window is scaled
  (each child about the top-left corner, with the matching move) and the window gets the matching size, so a picture that
  wraps its size or a view with a fixed size can no longer stay big inside a small window. Touches follow the scaled picture.
- **Pencil panel**: a touch outside the panel closes it (the touch still reaches the app), the Back key closes it, and the
  *Close* button is now first on the left; the tabs sit in a row that scrolls sideways, so the button can no longer be pushed
  off a narrow screen.

### New in 2.7: the pencil shows up in every app
- **Why it did not show before:** the pencil was an overlay window, and an app can only be allowed to draw over other
  apps if its manifest asks for `SYSTEM_ALERT_WINDOW`. Live Editor never added that line, so in most apps Android
  had nothing to allow and the pencil never appeared. Now, with *Live Editor inside the app* on, the patcher adds the
  permission to the manifest (nothing is added if the app already has it, or if you removed it yourself).
- **Pencil works at once, without any permission:** if overlay is not allowed, the pencil (and its panel) opens inside
  the app's own window as a popup (`PopupWindow`), so it is there the moment the app opens. It follows you from
  screen to screen of the app.
- **Live Editor permission popup:** when the app opens and overlay is not allowed, a Live Editor dialog asks for
  *Display over other apps* and its *Allow* button opens Android's page for that app. It comes once per start;
  long-press the pencil to get it again. When you come back with the permission on, the pencil switches to the
  floating one within a second.
- **Pencil stays on top:** if the app adds a floating window above the pencil later, the pencil is added again on top.
  If a phone refuses the overlay window even with the permission, the in-app pencil is used instead.
- **Patcher:** the finished screen has *Allow overlay for the patched app* (opens that app's overlay page after you
  install it).
- Checked: the manifest edit on the PC with generated manifests (UTF-8 and UTF-16 pools, decoded by a separate
  program). Not run on a phone: the pencil and popup code was only syntax-checked (no Android SDK here).

### New in 2.8 (pencil panel + origin lines)
- **Pick a colour with one tap.** The three R/G/B sliders are gone: every colour is a swatch palette (item colours and theme).
- **Preview of what you edit.** While one item is open in *Items*, a picture of it stays pinned at the top of the panel
  (outside the scrolling part) and follows every change.
- **Replace the icon with a PNG.** Items > pick a text, icon or button > *Replace icon (PNG)*. Any PNG, any size: it is
  scaled down once (192 px), fitted into the old icon's place and keeps its shape. It works on pictures, on icons set as
  compound drawables of a text, and, from a text, on the picture beside it in the same row. Every visible picture is now
  listed in Items. The PNG is kept inside the settings, so *Copy settings* / *Convert live APK to normal* carry it along.
  (The file picker is started from an invisible fragment, `Picker.java`, so the app's manifest does not change.)
- **Sound of a button = volume 0.** *Sound of this button: volume 0* looks into the code behind the item (listeners and the
  objects they hold): a `MediaPlayer` gets volume 0, a `ToneGenerator` is swapped for a silent one (both put back when
  unticked). Anything it cannot reach (a `SoundPool` kept elsewhere) is still muted on more streams (music, DTMF, alarm,
  system, notification) while the item is touched.
- **Theme colours reach the menu and keep on / off apart.** The theme now repaints any kind of background (state lists,
  layers, pictures), not only flat and gradient ones. A button keeps its difference: grey (off) becomes a soft neutral of the
  theme, a coloured one (on) gets the button colour. The app's own drawable is asked for its colour on every draw, so a
  switch that recolours its drawable still shows on / off. Text colour on a button follows the colour it really has.
- **Shrinking a menu shrinks its icons too.** Pictures that were only centred (cropped when smaller) are fitted, and icons
  beside a text (compound drawables) are scaled with the menu.
- **Less flicker.** When an app refreshes a floating button with its own `updateViewLayout`, size and opacity are written
  into the params before Android lays the window out again, so the original look is not shown for a frame.
- **All origin lines are one width.** Line thickness is one shared number: changing it on one line (or in Global) changes
  every line; per-item thickness is dropped. Quick values 0.1 / 0.2 / 0.3 / 0.5 / 1 / 1.5 dp. Lines thinner than one pixel
  are drawn as a fainter one-pixel line (hairline).
- **Patcher, timer list:** the place of the top-origin lines (class `n1`, `<init>`, `Paint.setStrokeWidth`, number 1.5 x
  density) is listed first as *ORIGIN LINES (top)*. Editing it (or any LINE entry) can change all places of the same class
  that hold the same number in one go (checkbox, on by default). The smallest number is now 0.05.
- Not run on a phone here: syntax-checked on a PC only (no Android SDK). Test: theme colours, icon replace, sound, line width.

### New in 2.9 (save button + crash-safe window removal)
- **Save button on every edit screen.** Items, Global and Theme each now have their own **💾 Save** button right below
  their controls. Every change already applies and saves on its own; this button just confirms it with a clear "Saved"
  message, for when you want to edit several sliders and then save deliberately.
- **Two-way crash guard for the Windows list.** Removing a window was already undone automatically if the app closed
  right after; now the same protection also covers bringing a window BACK: if un-hiding one closes the app, that exact
  window is left removed and is never auto-restored again, instead of being retried on every start and crashing the
  app each time. Each direction is remembered separately, so a window that is safe to show but unsafe to hide (or the
  reverse) is handled correctly, and the Windows tab explains which state each frozen window is stuck in.
- **Windows tab is more complete:** up to 250 windows are listed at once (was 80), and more are remembered across app
  screens (400, was 200), so a busy app does not run out of room before everything it has shown gets listed.
- Not run on a phone here: syntax-checked on a PC only (no Android SDK). Test: Save buttons, and removing/restoring a
  few different windows to see the crash guard in the Windows tab.

### New in 2.10 (apps that crash when you edit them)
- **Per-item crash guard (`EditGuard`).** Every edit (text, size, colour, line, sound, icon, opacity) is written down when it
  is applied. If the app closes within a few seconds, the next start switches off only THAT kind of change for THAT item
  (the riskiest of the latest ones first); everything else keeps working. Items > the item > *Try these changes again*, or
  the Windows tab button, brings it back. Leaving the app with Home / recents is not counted as a crash.
- **Text changes are silent.** A renamed text is set while the app's own TextWatchers are detached, so an app that reacts to
  its texts changing (reads them back, sets them again) does not notice. If the app keeps undoing a text or a background more
  than 12 times a second, that one is left alone (loop guard).
- **Edits wait 2 s after the app starts**, so they never meet the app's start-up checks.
- Not run on a phone here: syntax-checked on a PC only.

### New in 2.11 (auto-off timer: never, in the pencil)
- **Items > the button > *Auto-off timer: never (button stays manual)*.** After each tap on that button, the delayed jobs the
  app's own code starts (`Handler.postDelayed`, `View.postDelayed`, a delayed Handler message, a `CountDownTimer`, a Kotlin
  `delay`) are taken out of the main queue again (`Manual.java`), so the button only changes when you press it. Only jobs that
  are new since the finger touched down, belong to the app's own classes and are due in 0.3 to 6 seconds are cancelled. The
  3 2 1 count text on the button is hidden as well. A timer kept in another thread (`java.util.Timer`, `Thread.sleep`, an
  executor) is not in the queue and cannot be reached this way: use the patch card *Button that turns itself off, and its
  beep* (it sets that delay to never inside the code). Guarded by the edit guard like every other edit (category "timer").
- Not run on a phone here: syntax-checked on a PC only.

### New in 2.12 (every APK opens)
- **No APK is refused any more because of a zip trick or a scanner crash.** Reading the app now has three steps: the
  phone's own zip reader, then Live Editor's own zip reader (it ignores fake "encrypted" flags, wrong checksums and
  damaged headers), and as a last resort only the file names. The server list and timer search are a bonus: if they cannot
  be made, the app still opens and can be patched.
- Any error while opening the zip (not only `ZipException`) now makes the repaired copy; if even that fails, the original is
  read with the own reader.
- A manifest with a styled string pool, junk string slots or junk bytes after the document is read instead of rejected.
- When something still fails, the log now shows the first lines of the stack trace (`at ...`), so the exact place is visible.
- Not run on a phone here: the zip and scan code was tested on a PC with fake "encrypted" and damaged zips.

### New in 2.13 (PNG marker on the line ends, distance in meters, red when close)
Pencil panel > **Global > Lines** (and **Items > the line / drawing layer**), section *Marker on the end of the lines (PNG)*.
- **PNG marker on every line.** *Marker: ON* puts a picture on the end of EVERY line that starts at the origin. *Choose PNG*
  takes any PNG (scaled down once, transparency kept); *Built-in marker* is the small triangle that points down. The picture is
  never rotated: it stays upright, tip down, wherever the line goes (up, down, left, right). Size 1 - 20 dp with exact
  `- 1` / `+ 1` buttons. *Tip on the line end* (the point of the picture touches the end of the line; the tip is found from the
  visible pixels, so transparent borders do not matter) or *Centered on the end*.
- **Distance in meters.** *Distance: ON* writes the distance of each line next to its marker (for example `23m`): above the marker
  and a bit to the side, or below the line end. The digits are a little smaller than the marker (never below 8 dp, so they stay
  readable). The phone only sees the line on the screen, not the real game distance, so meters = length of the line on screen /
  the scale *1 meter = X dp* (0.1 dp steps). Set it once: a line that is really 20 m but shows 40 m needs a scale twice as big.
- **Red marker when close.** *Red when close: ON*: a line at or inside the red range (default 10 m, 1 - 200 m, quick values
  5 / 10 / 20 / 30 / 50) gets the same picture in red. The test uses the same rounded meters as the number shown.
- **Why there is no flicker or lag:** before every frame, the view that draws the lines is drawn once more onto a recording
  canvas that paints nothing and only writes down each `drawLine` (start, end). Marker and distance are placed from those very
  numbers and painted in the overlay of that view, in the same frame the app draws its lines (`LineTips.java`). Nothing is added
  to the app's layout.
- **Fixed: the marker was gone after closing the app with Back and opening it again.** The marker was tied to the edit crash
  guard, and an app that ends its process on Back looked like a crash of the edit, so the marker was switched off at the next
  start. The marker no longer uses that guard (it has its own: an error while reading a view switches it off for that view
  only), and a screen that is finished with Back / finish() now counts as a deliberate exit for the guard. The line view is
  also looked for again every 0.4 s (at once when the old one is gone), so a line view the app creates again is found.
- The origin is the point that most lines share (it is remembered, so a frame with one single line still works). Box edges or
  other lines that do not touch the origin get no marker. A line the app draws twice gets one marker.
- Settings are saved with the live edits and carried by *Copy settings* and *Convert live APK to normal* (keys `tipOn`, `tipDp`,
  `tipAnchor`, `tipPng`, `distOn`, `distScale`, `distPos`, `nearRed`, `nearM`).
- Honest limits: the line view is drawn one extra time per frame, so an app that moves its lines INSIDE `onDraw` (smoothing that
  advances on every call) would move a little faster; switch the marker off then. Lines drawn with `drawLine`, `drawLines` or a
  straight `drawPath` are read; curves are not. A view with a hardware layer draws into its own bitmap, so its lines cannot be
  read. The fade-out idea from the first 2.13 draft was removed.
- Not run on a phone here: the engine compiled against stand-ins for the Android classes; the origin / line logic and the meter
  maths were tested on a PC. Test: marker on, close the app with Back, open it again and switch the lines on: the marker must be
  there. Then distance on, a line closer than 10 m must be red.

## How it works
- Manifest options are written straight into the binary `AndroidManifest.xml` (no apktool).
- Options that need code at run time are saved as `assets/liveedit_config.json` inside the APK, and a small engine
  (`agent.dex`) reads it at start. If no such option is ticked, no engine is added at all.
- The patched APK is signed with the key in `app/src/main/assets` (v1 + v2), checked with Android's own
  package parser, then installed from the same screen.

## Limits (honest)
- It changes the phone side only. It cannot change what a server sends back, or how an app counts a timer.
- Server blocking covers HttpURLConnection and OkHttp. WebView pages, Cronet/QUIC and raw sockets can still connect.
- Link blocking works on links the app starts itself (Intent). Links opened inside a WebView are not covered.
- The pencil appears in every patched app as soon as it opens. With "Display over other apps" it floats above
  everything (including the app's own floating windows); without it, it sits inside the app's own screen and can
  edit those screens, but cannot sit above other apps. Item list reads the app's windows through Android
  internals: on some Android versions it may only see the visible screen.
- Apps patched with an older Live Editor do not have the overlay permission in their manifest and keep their old
  engine: pick the original app again and patch it with this version.
- Compose / Flutter / game UIs only partly work (they draw without normal views).
- ARMv7 best-effort mode cannot give an app the code it needs: games and apps built around native libraries will not work.
- Auto-loading settings needs an app patched with this version (older patched apps: use copy and paste).
- Single APK only (no XAPK/APKS/split apps). System apps without code inside their APK cannot be patched.
- Apps that check their own signature may refuse to start. The original must be uninstalled first (data is lost).

## Build (GitHub Actions)
Same as the other projects: upload this zip to the repo root, the existing workflow unzips it and builds.
The project module is called `app`. The engine (`agent.dex`) is compiled by `app/build.gradle`
(it runs `tools/build_agent.sh` when Gradle starts), so no extra workflow step is needed.
There is no workflow file inside this zip on purpose: the one already in your repo is used.
