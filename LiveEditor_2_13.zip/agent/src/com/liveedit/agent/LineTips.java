package com.liveedit.agent;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.WeakHashMap;

/**
 * Origin lines: a PNG marker on the end of every line, the distance of that line in meters next to the marker, and a
 * red marker when the line is close.
 *
 * How it works (no change to the app's code):
 * - The app draws its lines itself on a canvas. Right before every frame (the same moment the window is already
 *   checked for size / opacity) the view that draws them is drawn ONE extra time onto a recording canvas that does
 *   not paint anything, only writes down every line it is asked to draw (start, end, colour, width). So the marker is
 *   always placed from the very same numbers the app draws with, in the same frame: it can neither lag nor flicker.
 * - The origin is the point that most lines share. Every line has two ends; the one that is not the origin is the
 *   end that gets the marker. The marker is never rotated: it stays upright (tip down) wherever the line goes.
 * - A small drawable in the view's overlay (not a real child view, so the app's layout is untouched) draws the markers
 *   and the distance texts after the app has drawn its lines, in that same frame.
 * - Distance = length of the line on screen / the scale you set (dp per meter). The phone cannot know the real game
 *   distance, only what is drawn, so the scale is yours to set.
 */
final class LineTips {
    private static final String BUILTIN_B64 =
            "iVBORw0KGgoAAAANSUhEUgAAAB0AAAAYCAYAAAAGXva8AAAEYElEQVR42rWWf0xWZRTHv+fcFw2bioQ4qVSy2DC0SPu5cmtWaDM2"
            + "cbxrpnPmcGM2araW5AzfmbPQNCttJgZZLseVZLKiYAoqUjr74RSCHPgLTFHAF15+3Pfe5zn98b64V8IYgt/t7Nm99zzPc87u55zn"
            + "IQRkAJgAYBQAwdCLAPgAnAfguJgZWuvJq1ev/X7evOR7oQEioYDfICUCAQkZJAV7C698sG7tq8zqpEspRUR04fEZj3kTE6c93NrY"
            + "Bm0LiGnQOYsIyAAi7x+N+rr6esCuU0rI5Xa7mYi613+48Z3ExEfKR46I4AuX/iGXy6BBbUqAYyuZEDtOGi42SvaGTZlE5HO73YbL"
            + "NE0lIkxElYX79ue9kZGeFt5yt+rsspiZby9bArQWDA8fpseMHWl8vSlv97Fjh0uD+6ieH8ciIkQU8+fvJ3+LT0iIPlF9VsJcLr6d"
            + "TYkAy2/L9CmxqKk63frUMzOf6O721hOtIcCjOeinATCAxp2536wzoCk6KkI6tIKfBdYAzM8Cn1a4J2q0HmaAcnJyN1pWW11gfY/u"
            + "QflGgIFkKezHouKKOXNnzzhQVa/BxITerrdEBwCglNYvJkzm4qKfTr+cPOdpEekkIulx4NAZbrdJzGxlb9my8urlJhV3XzTalSM2"
            + "AxZJv2Yz0K4cPBgzFteuXJUNmz9Zxcw+0zQptP5doXGaprsHqgN7Cwq/S1++bGFt83DV5rcNF/UPsxZB+F3DVGzkKOOLrV/uKyv7"
            + "eX8PPKF+Ru+JHg9IpBzPzZz1x/zk5EVxkyeNqGpuBrkMckigCH2aJkKHcmRm7AQ0VNf6UhcvWeBYnVdFhA4dOnRTvPzfeD0aAFuW"
            + "9+z2r/KyxzDTxMgI3S4KNgH+PswmwCcKMaNH6rFhYbw9d9envpbL1Uopw+MJwNO7J/ZJfRCq8NLi0l+en/3C1J01NTpQuL1mSbAR"
            + "OEoviY/noyUHz8xKmvWkiFwnIvTVy/lWGJqmSczUkb1py6q2pmsyPToazd1dsJSDLttGlx0YLeWgpasL06KiYLd68fHn27KIqNU0"
            + "Tb7V4UH99E4mIr19W07BsvSlKduqq9R12zbCQqBSIgg3DPVWwlQjN2dXyetpi+eICEJLpLeM/ppLRcURqag8dmr+3LmL4mInDa9o"
            + "bAAzkV8rKBF4uy1JfSgOvnMXu19LS1vY2e691Bc8Az0pDABYsWKlR0RkR81fTkblEXnv+K/yZmWFfHb6lCMisipzzeZQ/0EfwCLC"
            + "ACLKSspqvVpL+uEylXH0iCwrP6iabFtXlh89DyBaROh/OBmY8vPzDSJCUtIr7o6W61J47qx6qahQ7z7zt7J9nZKSsmApESE/P98Y"
            + "0utGMFvOy9n1g4jIRyeO+x0R2fPtnsMAwoLfaUgvOVlZWczMiImZ+GjVqWqfiDh1Z+qsKVOmPcvMSE1NHdIsbyohAFi+/O31dfXn"
            + "JDPz/a2h7++UKAjLmPHjH3gXwLjgM+FOK9jebowD1b8xmXHSM2iU3QAAAABJRU5ErkJggg==";

    private static final int MAX = 192;
    private static final int RED = 0xFFFF2020;
    private static final PorterDuffColorFilter RED_FILTER = new PorterDuffColorFilter(RED, PorterDuff.Mode.SRC_IN);

    private LineTips() {}

    // ---- data ------------------------------------------------------------------------------

    /** One line the app drew in one frame. */
    private static final class Seg {
        float x0, y0, x1, y1;
    }

    /** One origin line that is on screen right now (origin -> end). */
    private static final class Track {
        float ox, oy, ex, ey;
    }

    private static final class Owner {
        final WeakReference<View> view;
        final Rec rec = new Rec();
        final Track[] live = new Track[MAX];
        int liveN;
        float ox, oy;
        boolean haveOrigin;
        Tip tip;
        boolean attached, dead;
        long recAt;
        int fails;
        float density = 1f;

        Owner(View v) {
            view = new WeakReference<View>(v);
            for (int i = 0; i < MAX; i++) live[i] = new Track();
        }
    }

    private static final class RootState {
        final ArrayList<WeakReference<View>> views = new ArrayList<WeakReference<View>>();
        long scanAt;
    }

    private static final WeakHashMap<View, RootState> ROOTS = new WeakHashMap<View, RootState>();
    private static final WeakHashMap<View, Owner> OWNERS = new WeakHashMap<View, Owner>();
    private static final WeakHashMap<View, Boolean> PAINTY = new WeakHashMap<View, Boolean>();

    // ---- recording canvas ------------------------------------------------------------------

    /**
     * A canvas that paints nothing for lines: it writes them down. Everything else the app draws lands on a 1 x 1
     * bitmap and costs nothing. Width, height and clip bounds are those of the view, so an app that places its
     * lines from canvas.getWidth() gets the same numbers as in the real frame.
     */
    private static final class Rec extends Canvas {
        int w = 1, h = 1, n;
        final Seg[] segs = new Seg[MAX];
        private final Matrix m = new Matrix();
        private final float[] p = new float[4];
        private final PathMeasure pm = new PathMeasure();
        private final float[] pos = new float[2];

        Rec() {
            super(Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8));
            for (int i = 0; i < MAX; i++) segs[i] = new Seg();
        }

        @Override
        public int getWidth() {
            return w;
        }

        @Override
        public int getHeight() {
            return h;
        }

        @Override
        public boolean getClipBounds(Rect r) {
            if (r != null) r.set(0, 0, w, h);
            return true;
        }

        @Override
        public void drawLine(float x0, float y0, float x1, float y1, Paint paint) {
            add(x0, y0, x1, y1, paint);
        }

        @Override
        public void drawLines(float[] pts, int offset, int count, Paint paint) {
            if (pts == null) return;
            for (int i = offset; i + 3 < offset + count && i + 3 < pts.length; i += 4) {
                add(pts[i], pts[i + 1], pts[i + 2], pts[i + 3], paint);
            }
        }

        @Override
        public void drawLines(float[] pts, Paint paint) {
            if (pts != null) drawLines(pts, 0, pts.length, paint);
        }

        @Override
        public void drawPath(Path path, Paint paint) {
            if (path == null || paint == null || paint.getStyle() == Paint.Style.FILL) return;
            try {
                pm.setPath(path, false);
                float len = pm.getLength();
                if (len <= 0.5f) return;
                pm.getPosTan(0f, pos, null);
                float sx = pos[0], sy = pos[1];
                pm.getPosTan(len, pos, null);
                float ex = pos[0], ey = pos[1];
                if ((float) Math.hypot(ex - sx, ey - sy) < len * 0.98f) return; // a curve, not a line
                if (pm.nextContour()) return;
                add(sx, sy, ex, ey, paint);
            } catch (Throwable t) {
                // not a line we can read
            }
        }

        private void add(float x0, float y0, float x1, float y1, Paint paint) {
            if (paint == null || n >= MAX) return;
            if (Color.alpha(paint.getColor()) == 0) return;
            p[0] = x0;
            p[1] = y0;
            p[2] = x1;
            p[3] = y1;
            try {
                getMatrix(m);
                m.mapPoints(p);
            } catch (Throwable t) {
                p[0] = x0;
                p[1] = y0;
                p[2] = x1;
                p[3] = y1;
            }
            if (Float.isNaN(p[0]) || Float.isNaN(p[1]) || Float.isNaN(p[2]) || Float.isNaN(p[3])) return;
            Seg s = segs[n++];
            s.x0 = p[0];
            s.y0 = p[1];
            s.x1 = p[2];
            s.y1 = p[3];
        }
    }

    // ---- public entry points ---------------------------------------------------------------

    /**
     * Something to do at all. The marker has its own safety (an error while reading a view switches it off for that
     * view only), so it is NOT tied to the edit guard: leaving the app with Back must never switch it off.
     */
    static boolean wanted() {
        return Config.tipOn || Config.distOn;
    }

    /** A big window (a full screen drawing layer that also holds some texts or pictures). */
    static boolean bigWindow(View root, float density) {
        try {
            android.util.DisplayMetrics dm = root.getResources().getDisplayMetrics();
            return root.getWidth() >= dm.widthPixels * 0.6f && root.getHeight() >= dm.heightPixels * 0.6f;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Called for a window root before each frame (and at the 1 s tick). strict = a line / canvas window. */
    static void frame(View root, float d, boolean strict) {
        try {
            RootState st = ROOTS.get(root);
            if (st == null) {
                st = new RootState();
                ROOTS.put(root, st);
            }
            long now = SystemClock.uptimeMillis();
            // look for the line view again often (the app may swap it when the feature is switched off and on),
            // and at once when the one we know is gone
            int valid = 0;
            for (int i = 0; i < st.views.size(); i++) {
                View v = st.views.get(i).get();
                if (v != null && v.isAttachedToWindow() && v.getWidth() > 0 && v.getHeight() > 0) valid++;
            }
            long gap = valid == 0 ? 120L : 400L;
            if (now - st.scanAt > gap) {
                st.scanAt = now;
                scan(root, st, strict);
            }
            for (int i = 0; i < st.views.size(); i++) {
                View v = st.views.get(i).get();
                if (v == null || !v.isAttachedToWindow() || v.getWidth() <= 0 || v.getHeight() <= 0) continue;
                step(v, d, now);
            }
        } catch (Throwable t) {
            U.err("line tips", t);
        }
    }

    /** The marker is off (or this window is not a drawing layer): take everything away again. */
    static void release(View root) {
        try {
            RootState st = ROOTS.get(root);
            if (st == null) return;
            ROOTS.remove(root);
            for (int i = 0; i < st.views.size(); i++) {
                View v = st.views.get(i).get();
                if (v == null) continue;
                Owner o = OWNERS.get(v);
                if (o != null) detach(v, o);
            }
        } catch (Throwable t) {
            U.err("line tips off", t);
        }
    }

    /** A setting (size, picture, scale, range) changed: draw again at once. */
    static void refresh() {
        try {
            ArrayList<Owner> all = new ArrayList<Owner>(OWNERS.values());
            for (int i = 0; i < all.size(); i++) {
                View v = all.get(i).view.get();
                if (v != null) v.invalidate();
            }
        } catch (Throwable t) {
            // ignore
        }
    }

    /** Distance in whole meters: the length of the line on screen divided by the scale (dp per meter). */
    static int meters(float ox, float oy, float ex, float ey, float density) {
        float lenPx = (float) Math.hypot(ex - ox, ey - oy);
        float perM = Math.max(1, Config.distScale) / 10f * Math.max(0.1f, density);
        return Math.min(9999, Math.round(lenPx / perM));
    }

    // ---- finding the view that draws the lines ---------------------------------------------

    private static boolean appClass(Class<?> c) {
        String n = c.getName();
        return !(n.startsWith("android.") || n.startsWith("androidx.") || n.startsWith("java.")
                || n.startsWith("javax.") || n.startsWith("kotlin.") || n.startsWith("dalvik.")
                || n.startsWith("libcore.") || c.isPrimitive() || c.isArray() || c.isEnum());
    }

    private static void scan(View root, RootState st, boolean strict) {
        st.views.clear();
        ArrayList<View> paint = new ArrayList<View>();
        ArrayList<View> leaves = new ArrayList<View>();
        int[] budget = {160};
        collect(root, 0, paint, leaves, budget);
        ArrayList<View> use = !paint.isEmpty() ? paint : (strict ? leaves : new ArrayList<View>());
        for (int i = 0; i < use.size() && i < 8; i++) st.views.add(new WeakReference<View>(use.get(i)));
    }

    private static void collect(View v, int depth, ArrayList<View> paint, ArrayList<View> leaves, int[] budget) {
        if (v == null || depth > 8 || budget[0]-- <= 0) return;
        boolean leaf = !(v instanceof ViewGroup) || ((ViewGroup) v).getChildCount() == 0;
        if (leaf && !(v instanceof TextView) && !(v instanceof ImageView) && appClass(v.getClass())
                && v.getWidth() > 0 && v.getHeight() > 0) {
            leaves.add(v);
            if (hasPaint(v)) paint.add(v);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount() && i < 60; i++) {
                collect(g.getChildAt(i), depth + 1, paint, leaves, budget);
            }
        }
    }

    /** A custom view that keeps a Paint (or several) in a field is the one that draws lines. Only "yes" is remembered. */
    private static boolean hasPaint(View v) {
        if (PAINTY.get(v) != null) return true;
        boolean r = false;
        try {
            r = paintIn(v, 0);
        } catch (Throwable t) {
            // not readable
        }
        if (r) PAINTY.put(v, Boolean.TRUE);
        return r;
    }

    private static boolean paintIn(Object target, int depth) {
        Class<?> c = target.getClass();
        int guard = 0;
        while (c != null && c != View.class && c != Object.class && guard++ < 6) {
            if (!appClass(c)) break;
            Field[] fs;
            try {
                fs = c.getDeclaredFields();
            } catch (Throwable t) {
                break;
            }
            for (int i = 0; i < fs.length && i < 200; i++) {
                try {
                    Field f = fs[i];
                    if (java.lang.reflect.Modifier.isStatic(f.getModifiers()) || f.getType().isPrimitive()) continue;
                    f.setAccessible(true);
                    Object o = f.get(target);
                    if (o == null) continue;
                    if (o instanceof Paint || o instanceof Paint[]) return true;
                    if (depth < 1 && !(o instanceof View) && !(o instanceof android.content.Context)
                            && appClass(o.getClass()) && paintIn(o, depth + 1)) return true;
                } catch (Throwable t) {
                    // skip
                }
            }
            c = c.getSuperclass();
        }
        return false;
    }

    // ---- one frame -------------------------------------------------------------------------

    private static void step(View v, float d, long now) {
        Owner o = OWNERS.get(v);
        if (o == null) {
            o = new Owner(v);
            OWNERS.put(v, o);
        }
        if (o.dead) return;
        o.density = d;
        if (!o.attached) attach(v, o);
        Rect b = o.tip.getBounds();
        if (b.width() != v.getWidth() || b.height() != v.getHeight()) o.tip.setBounds(0, 0, v.getWidth(), v.getHeight());
        if (o.recAt != 0 && now - o.recAt < 4L) return; // already written down for this frame
        Rec r = o.rec;
        r.w = v.getWidth();
        r.h = v.getHeight();
        r.n = 0;
        try {
            v.draw(r);
        } catch (Throwable t) {
            U.err("line tips record", t);
            o.fails++;
            if (o.fails >= 3) {
                o.dead = true;
                detach(v, o);
            }
            return;
        }
        o.recAt = now;
        update(o, r, d);
    }

    private static void attach(View v, Owner o) {
        o.tip = new Tip(o);
        v.getOverlay().add(o.tip);
        o.tip.setBounds(0, 0, v.getWidth(), v.getHeight());
        o.attached = true;
        Overlays.bump(); // the window is drawn once more, so the first frame already has the marker
    }

    private static void detach(View v, Owner o) {
        try {
            if (o.attached && o.tip != null) v.getOverlay().remove(o.tip);
        } catch (Throwable t) {
            // ignore
        }
        o.attached = false;
        o.tip = null;
        o.liveN = 0;
        v.invalidate();
    }

    private static boolean near(float ax, float ay, float bx, float by, float tol) {
        float dx = ax - bx, dy = ay - by;
        return dx * dx + dy * dy <= tol * tol;
    }

    /** Finds the origin lines in what was just drawn (origin -> end). */
    private static void update(Owner o, Rec r, float d) {
        int n = r.n;
        Seg[] s = r.segs;
        float tol = Math.max(3f, 2f * d);

        // 1. the origin = the point most lines share
        int lim = Math.min(n, 96);
        int best = 0;
        float bx = 0f, by = 0f;
        for (int i = 0; i < lim; i++) {
            for (int e = 0; e < 2; e++) {
                float px = e == 0 ? s[i].x0 : s[i].x1;
                float py = e == 0 ? s[i].y0 : s[i].y1;
                int c = 0;
                for (int j = 0; j < lim; j++) {
                    if (near(px, py, s[j].x0, s[j].y0, tol) || near(px, py, s[j].x1, s[j].y1, tol)) c++;
                }
                if (c > best || (c == best && c >= 2 && py < by - 0.5f)) {
                    best = c;
                    bx = px;
                    by = py;
                }
            }
        }
        int cr = 0;
        if (o.haveOrigin) {
            for (int j = 0; j < lim; j++) {
                if (near(o.ox, o.oy, s[j].x0, s[j].y0, tol) || near(o.ox, o.oy, s[j].x1, s[j].y1, tol)) cr++;
            }
        }
        boolean haveO = false;
        float ox = 0f, oy = 0f;
        if (o.haveOrigin && (cr >= 2 || (cr == 1 && best < 2))) {
            ox = o.ox;
            oy = o.oy;
            haveO = true;
        } else if (best >= 2) {
            ox = bx;
            oy = by;
            haveO = true;
            if (best >= 3 || !o.haveOrigin) {
                o.ox = bx;
                o.oy = by;
                o.haveOrigin = true;
            }
        } else if (n == 1) {
            ox = s[0].x0;
            oy = s[0].y0;
            haveO = true;
        }

        // 2. the origin lines of this frame
        Track[] cur = o.live;
        int cn = 0;
        if (haveO) {
            for (int i = 0; i < n && cn < MAX; i++) {
                Seg g = s[i];
                boolean a = near(g.x0, g.y0, ox, oy, tol), b = near(g.x1, g.y1, ox, oy, tol);
                if (a == b) continue; // does not start at the origin (or has no length)
                float sx = a ? g.x0 : g.x1, sy = a ? g.y0 : g.y1;
                float ex = a ? g.x1 : g.x0, ey = a ? g.y1 : g.y0;
                boolean dup = false;
                for (int k = 0; k < cn; k++) {
                    if (near(cur[k].ex, cur[k].ey, ex, ey, 1f)) { // the same line drawn twice: one marker
                        dup = true;
                        break;
                    }
                }
                if (dup) continue;
                Track t = cur[cn++];
                t.ox = sx;
                t.oy = sy;
                t.ex = ex;
                t.ey = ey;
            }
        }
        o.liveN = cn;
    }

    // ---- the marker picture ----------------------------------------------------------------

    private static Bitmap srcBmp;
    private static String srcRef;
    private static boolean srcBuiltin = true;
    private static float srcAx, srcAy;
    private static Bitmap scaled;
    private static int scaledW;
    private static float tipX, tipY;

    private static Bitmap decode(String b64) {
        try {
            byte[] raw = Base64.decode(b64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(raw, 0, raw.length);
        } catch (Throwable t) {
            return null;
        }
    }

    /** The picture to use (the user's PNG, or the built-in triangle), with the point of it that touches the line end. */
    private static Bitmap source() {
        String want = (Config.tipPng == null || Config.tipPng.length() == 0) ? null : Config.tipPng;
        if (srcBmp != null && want == srcRef) return srcBmp;
        Bitmap b = want == null ? null : decode(want);
        boolean builtin = false;
        if (b == null) {
            b = decode(BUILTIN_B64);
            builtin = true;
        }
        if (b == null) return null;
        srcBmp = b;
        srcRef = want;
        srcBuiltin = builtin;
        scaled = null;
        // the tip = bottom centre of what is visible (transparent borders do not count)
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        int yl = -1;
        for (int y = h - 1; y >= 0 && yl < 0; y--) {
            for (int x = 0; x < w; x++) {
                if ((px[y * w + x] >>> 24) > 24) {
                    yl = y;
                    break;
                }
            }
        }
        if (yl < 0) {
            srcAx = w / 2f;
            srcAy = h;
        } else {
            double sx = 0, sa = 0;
            int rows = 0;
            for (int y = yl; y >= 0 && rows < 3; y--) {
                boolean any = false;
                for (int x = 0; x < w; x++) {
                    int a = px[y * w + x] >>> 24;
                    if (a > 24) {
                        sx += (x + 0.5) * a;
                        sa += a;
                        any = true;
                    }
                }
                if (!any) break;
                rows++;
            }
            srcAx = sa > 0 ? (float) (sx / sa) : w / 2f;
            srcAy = yl + 0.75f;
        }
        return b;
    }

    /** The marker at the size in dp (1 .. 20), scaled down in steps so it stays sharp. */
    private static Bitmap sized(float density) {
        Bitmap b = source();
        if (b == null) return null;
        int tw = Math.max(1, Math.round(U.clamp(Config.tipDp, 1, 20) * density));
        if (scaled != null && scaledW == tw) return scaled;
        int th = Math.max(1, Math.round(tw * (float) b.getHeight() / b.getWidth()));
        Bitmap cur = b;
        try {
            while (cur.getWidth() >= tw * 2 && cur.getHeight() >= th * 2) {
                cur = Bitmap.createScaledBitmap(cur, cur.getWidth() / 2, cur.getHeight() / 2, true);
            }
            scaled = Bitmap.createScaledBitmap(cur, tw, th, true);
        } catch (Throwable t) {
            U.err("line tip picture", t);
            return null;
        }
        scaledW = tw;
        tipX = srcAx * tw / b.getWidth();
        tipY = srcAy * th / b.getHeight();
        return scaled;
    }

    // ---- the drawable that paints the markers and the distances ------------------------------

    private static final class Tip extends Drawable {
        private final Owner o;
        private final Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint op = new Paint(Paint.ANTI_ALIAS_FLAG);

        Tip(Owner o) {
            this.o = o;
            tp.setColor(0xFFFFFFFF);
            tp.setTypeface(Typeface.DEFAULT_BOLD);
            op.setColor(0xFF000000);
            op.setTypeface(Typeface.DEFAULT_BOLD);
            op.setStyle(Paint.Style.STROKE);
        }

        @Override
        public void draw(Canvas c) {
            if (c instanceof Rec) return; // the recording pass: nothing to paint
            try {
                if (o.liveN == 0) return;
                float d = o.density;
                Bitmap b = sized(d);
                if (b == null) return;
                for (int i = 0; i < o.liveN; i++) {
                    Track t = o.live[i];
                    int m = meters(t.ox, t.oy, t.ex, t.ey, d);
                    boolean close = Config.nearRed && m <= Config.nearM;
                    float top = Config.tipAnchor == 1 ? t.ey - b.getHeight() / 2f : t.ey - tipY;
                    if (Config.tipOn) {
                        float left = Config.tipAnchor == 1 ? t.ex - b.getWidth() / 2f : t.ex - tipX;
                        mp.setColorFilter(close ? RED_FILTER : null); // the picture turns red, its shape stays
                        c.drawBitmap(b, left, top, mp);
                    }
                    if (Config.distOn) text(c, t, m, b, top, d);
                }
            } catch (Throwable t) {
                U.err("line tips draw", t);
            }
        }

        /** The distance, a bit smaller than the marker: above it and slightly to the side, or below the line end. */
        private void text(Canvas c, Track t, int meters, Bitmap b, float top, float d) {
            float ts = Math.max(8f * d, 1.05f * b.getHeight());
            tp.setTextSize(ts);
            op.setTextSize(ts);
            op.setStrokeWidth(Math.max(1.2f, ts * 0.16f));
            String s = meters + "m";
            float x, y;
            if (Config.distPos == 1) {
                tp.setTextAlign(Paint.Align.CENTER);
                op.setTextAlign(Paint.Align.CENTER);
                x = t.ex;
                y = (Config.tipAnchor == 1 ? t.ey + b.getHeight() / 2f : t.ey) + ts + 2f * d;
            } else {
                tp.setTextAlign(Paint.Align.LEFT);
                op.setTextAlign(Paint.Align.LEFT);
                x = t.ex + b.getWidth() * 0.25f;
                y = top - 2f * d;
            }
            c.drawText(s, x, y, op);
            c.drawText(s, x, y, tp);
        }

        @Override
        public void setAlpha(int alpha) {}

        @Override
        public void setColorFilter(ColorFilter cf) {}

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    /** True while a marker picture is the user's own (for the panel text). */
    static boolean customPicture() {
        return Config.tipPng != null && Config.tipPng.length() > 0 && !srcBuiltin;
    }
}
