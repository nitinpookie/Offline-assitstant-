package com.fastlink.browser;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.TrafficStats;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.util.Base64;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {

    // speed modes: 0 = off, 1 = smart (speeds up only on pages that look like a link-shortener step), 2 = turbo (always)
    private static final int[] RATES = {1, 10, 25};
    private static final String[] MODE_NAMES = {"Speed OFF", "Smart speed", "Turbo (har page par)"};
    private static final String[] MODE_DONE = {
            "Speed band ho gayi \u2705",
            "Smart speed chalu ho gayi \u26A1",
            "Turbo chalu ho gaya \uD83D\uDE80"};
    // lines shown (in the black pill) after an automatic tap
    private static final String[] TAP_LINES = {
            "Step # complete \u2705",
            "Step # ho gaya, ye bhi ho gaya \u2728",
            "Step # done, aage badh rahe hain \uD83D\uDE80",
            "Step # complete, ek dum smooth \uD83D\uDE0E"};

    // Ad / popup network domains (sub-resources are answered with harmless stubs, main-frame jumps are blocked)
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "googletagservices.com", "2mdn.net",
            "adnxs.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "pubmatic.com", "rubiconproject.com", "openx.net", "amazon-adsystem.com",
            "adsafeprotected.com", "moatads.com", "advertising.com", "adform.net",
            "smartadserver.com", "casalemedia.com", "indexww.com", "teads.tv",
            "mgid.com", "revcontent.com", "adskeeper.com", "adsrvr.org",
            "serving-sys.com", "lijit.com", "sharethrough.com", "yieldmo.com",
            "media.net", "zedo.com", "adition.com",
            "popads.net", "popcash.net", "propellerads.com", "exoclick.com",
            "exosrv.com", "exdynsrv.com", "realsrv.com", "juicyads.com", "adsterra.com", "hilltopads.net",
            "clickadu.com", "adcash.com", "bidvertiser.com", "onclickads.net",
            "a-ads.com", "ad-maven.com", "admaven.com", "monetag.com",
            "profitablecpmrate.com", "effectivegatecpm.com", "highperformanceformat.com",
            "yllix.com", "trafficjunky.net", "tsyndicate.com", "adtng.com",
            "trafficstars.com", "galaksion.com", "richads.com", "bidgear.com",
            "onclickalgo.com", "onclckmn.com", "pushame.com", "pushsar.com",
            "mondiad.com", "adspyglass.com", "clickaine.com", "wpadmngr.com", "adsco.re",
            "kueezrtb.com", "bidswitch.net", "33across.com", "smaato.net"
    };

    // Hosts that are known link-shortener / gate sites (used only as a hint; page content is checked too)
    private static final String[] SHORT_HOSTS = {
            "ouo.io", "ouo.press", "shrinkme.io", "shrinkearn.com", "shrtfly.com", "exe.io", "exey.io",
            "fc.lc", "fcc.lc", "clk.sh", "gplinks.co", "gplinks.in", "vplinks.in", "earnlinks.in", "droplink.co", "linkvertise.com",
            "link-to.net", "lootlabs.gg", "loot-link.com", "loot-links.com", "work.ink", "adfoc.us", "za.gl",
            "earnlink.io", "tnlink.in", "tnshort.net", "shortingly.in", "arolinks.com", "ez4short.com",
            "earn4link.in", "adrinolinks.in", "cuty.io", "shorte.st", "sh.st", "bc.vc", "adf.ly",
            "boost.ink", "rekonise.com", "shareus.io", "gyanilinks.com", "indiurl.in", "kpslink.in",
            "linkpays.in", "rocklinks.net", "urlpay.in", "inshorturl.com", "dalink.in", "vplink.in",
            "safelinku.com", "linkshrink.net", "adshrink.it", "short2url.in", "urlshortx.com"
    };

    // Final-destination hosts: a new tab to one of these is opened straight away
    private static final String[] FILE_HOSTS = {
            "drive.google.com", "docs.google.com", "mega.nz", "mediafire.com", "t.me", "telegram.me",
            "dropbox.com", "terabox.com", "1024terabox.com", "github.com", "play.google.com", "gofile.io", "pixeldrain.com",
            "workupload.com", "1fichier.com", "krakenfiles.com", "send.cm"
    };

    // Share / social endpoints that use ?u= or ?url= and must never be treated as redirects
    private static final String[] SOCIAL_HOSTS = {
            "facebook.com", "twitter.com", "x.com", "whatsapp.com", "wa.me", "linkedin.com", "pinterest.com",
            "reddit.com", "t.me", "telegram.me", "tumblr.com", "vk.com"
    };

    private static final String[] REDIR_PARAMS = {
            "r", "u", "url", "link", "go", "goto", "dest", "destination", "target", "to", "out",
            "redirect", "redirect_url", "redir", "next", "l", "d", "href", "q"
    };

    private static final String ADS_STUB =
            "(window.adsbygoogle=window.adsbygoogle||[]);window.adsbygoogle.loaded=true;window.adsbygoogle.push=function(){return 0};";

    private static final String GPT_STUB =
            "(function(){var w=window,g=w.googletag=w.googletag||{};var q=g.cmd||[];"
            + "var ch=new Proxy(function(){},{get:function(t,p){if(p==='then')return undefined;"
            + "if(p===Symbol.toPrimitive)return function(){return ''};return ch},apply:function(){return ch}});"
            + "g.apiReady=true;g.pubadsReady=true;"
            + "g.cmd={push:function(f){try{if(typeof f==='function')f.call(g)}catch(e){}return 1}};"
            + "['defineSlot','defineOutOfPageSlot','pubads','companionAds','content','sizeMapping','enableServices',"
            + "'display','destroySlots','setTargeting','addEventListener'].forEach(function(n){g[n]=function(){return ch}});"
            + "if(q.forEach)q.forEach(function(f){try{f.call(g)}catch(e){}})})();";

    // 1x1 transparent GIF
    private static final byte[] GIF = Base64.decode("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", Base64.DEFAULT);

    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private LinearLayout barBox;
    private View topBar;            // url bar row (hidden while a video plays fullscreen)

    // ---- fullscreen video / rotate support ----
    private View fsView;                                   // video view handed over by WebView
    private WebChromeClient.CustomViewCallback fsCb;
    private FrameLayout fsBox;
    private boolean manualLand;                            // user rotated to landscape from the menu
    private boolean landFs;                                // "video only" layout active (no real fullscreen)
    private String rotJs = "";

    // ---- history ----
    private static class Hist {
        final String title, url;
        final long time;

        Hist(String t, String u, long d) {
            title = t;
            url = u;
            time = d;
        }
    }

    private final ArrayList<Hist> hist = new ArrayList<>();
    private boolean histLoaded;
    private TextView barMsg, barAct;
    private Runnable hideBar;
    private TextView pill;
    private Runnable hidePill;
    private long lastTapMsgAt;
    private int msgIdx;
    private volatile boolean flowActive;
    private volatile int stepCount;
    private boolean copyFinal;
    private String stuckUrl;
    private int linkType;                       // 0 auto, 1 key, 2 file/apk (menu override)
    private volatile int flowKind;              // what the running flow is for: 0 unknown, 1 key, 2 file/apk
    private volatile int hops;
    private volatile String curPage, prevPage, flowOrigin;
    // flow recorder: last steps of the current link flow, copied from the menu
    private final java.util.ArrayDeque<String> flogBuf = new java.util.ArrayDeque<>();
    private long flogT0;
    private volatile long recUntil;
    private volatile String xrwStatus = "not-set";
    private final Set<String> seenHosts = new HashSet<>();
    private final Set<String> freshTried = new HashSet<>();
    private BroadcastReceiver dlReceiver;
    private final Set<Long> myDownloads = new HashSet<>();
    private SharedPreferences prefs;
    private volatile int speedMode;
    private volatile boolean autoOn, adOn;
    private boolean desktop, defaultWide, defaultOverview;
    private ScriptHandler scriptHandler;
    private boolean docStartSupported;
    private String videoUrl;
    private String bridgeName;
    private String mobileUa, desktopUa;
    private String coreJs = "", engineJs = "";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final Set<String> slowHosts = new HashSet<>();
    // per-site speed (learned after an "anomaly" or chosen by hand); 1x lives in slowHosts
    private final Map<String, Integer> hostRate = new HashMap<>();
    private static final int[] LADDER = {25, 10, 5, 3, 2, 1};
    private String chromeMajor = "124";
    private final LinkedHashMap<String, String> radar = new LinkedHashMap<>();
    private volatile long trustPopupUntil;
    private String allowOnceUrl, lastDecoded;
    private long lastAnomalyAt;

    // ---- v5.2: stop button, data saver, video focus / quality, incognito ----
    private volatile boolean userStopped;               // X pressed: no automatic taps / reloads / redirects until a real navigation
    private String stoppedUrl;
    private volatile boolean saverOn, imgOff, focusOn, focusActive, focusStalled;
    private volatile int vqCap;                         // 0 = no limit, else max video height (720 / 480 / 360 / 240 / 144)
    private final java.util.concurrent.CopyOnWriteArrayList<String> mediaDirs = new java.util.concurrent.CopyOnWriteArrayList<>();
    private final ArrayList<DownloadCenter.Task> focusPaused = new ArrayList<>();
    private long dataBase;
    private boolean incog, profileOk;
    private WebView webNormal, webPriv;
    private CookieManager privCm;
    private ScriptHandler scriptHandlerNormal;
    private WebViewClient wvClient;
    private WebChromeClient wcClient;
    private android.webkit.DownloadListener dlListener;
    private volatile boolean capApplied;                // the quality limit was applied to this page's manifest
    private int stripHiddenId = -1;                     // download the user swiped away from the top strip
    private boolean cleanBackOn;
    private final java.util.HashSet<String> hopUrls = new java.util.HashSet<>();   // pages that redirected on by themselves
    private volatile int pageTouches;                   // real finger taps on the page since it started loading (0 = nobody touched it)
    private TextView qBadge;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("fastlink", MODE_PRIVATE);
        watchAudioOut();
        speedMode = prefs.getInt("speedMode", 1);
        autoOn = prefs.getBoolean("auto", true);
        adOn = prefs.getBoolean("ads", true);
        copyFinal = prefs.getBoolean("copyFinal", true);
        linkType = prefs.getInt("linkType", 0);
        saverOn = prefs.getBoolean("saver", false);
        imgOff = prefs.getBoolean("imgoff", false);
        focusOn = prefs.getBoolean("focus", false);
        vqCap = prefs.getInt("vq", 0);
        favName = prefs.getString("favName", "");
        favUrl = prefs.getString("favUrl", "");
        cleanBackOn = prefs.getBoolean("cleanback", false);
        DownloadCenter.hlsCap = vqCap;
        dataBase = rxBytes();
        profileOk = WebViewFeature.isFeatureSupported("MULTI_PROFILE");
        slowHosts.addAll(prefs.getStringSet("slow", Collections.<String>emptySet()));
        for (String e : prefs.getStringSet("hr", Collections.<String>emptySet())) {
            int i = e.lastIndexOf('|');
            if (i > 0) {
                try {
                    hostRate.put(e.substring(0, i), Integer.parseInt(e.substring(i + 1)));
                } catch (Exception ignored) {
                }
            }
        }
        bridgeName = "_f" + Long.toString(Math.abs(rnd.nextLong()), 36);
        coreJs = asset("flb_core.js");
        bridgeJs = asset("flb_bridge.js");
        mediaJs = asset("flb_media.js");
        igJs = asset("flb_insta.js");
        engineJs = asset("flb_engine.js");
        rotJs = asset("flb_rotate.js");
        loadIgPrefs();

        buildUi();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        // true on purpose: every window.open is caught in onCreateWindow and filtered there,
        // so the real "get link" popup is no longer silently dropped.
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        defaultWide = s.getUseWideViewPort();
        defaultOverview = s.getLoadWithOverviewMode();
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        // look like normal Chrome: no "wv" marker, no X-Requested-With header
        String ua = s.getUserAgentString();
        mobileUa = ua.replace("; wv)", ")").replace(" Version/4.0", "");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("Chrome/(\\d+)").matcher(mobileUa);
        String major = m.find() ? m.group(1) : "124";
        chromeMajor = major;
        desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + major + ".0.0.0 Safari/537.36";
        applyUa();
        try {
            // reflection on purpose: if this androidx.webkit version lacks the API, the build still works
            if (WebViewFeature.isFeatureSupported("REQUESTED_WITH_HEADER_ALLOW_LIST")) {
                WebSettingsCompat.class.getMethod("setRequestedWithHeaderOriginAllowList",
                        WebSettings.class, Set.class).invoke(null, s, Collections.<String>emptySet());
                xrwStatus = "off";
            } else {
                xrwStatus = "UNSUPPORTED (header is sent)";
            }
        } catch (Throwable t) {
            xrwStatus = "ERROR " + t.getClass().getSimpleName() + " (header may be sent)";
        }

        web.addJavascriptInterface(new Bridge(), bridgeName);
        docStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);

        wvClient = new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (MusicHost.isHost(r.getUrl())) {
                    String mp = r.getUrl().getPath();
                    if (mp != null && mp.startsWith("/cmd/")) musicCmd(mp.substring(5));
                    return mp != null && mp.startsWith("/cmd/");
                }
                if (userStopped) {
                    // X was pressed: scripts of the page must not push us somewhere else (a real tap on a link is fine)
                    if (r.hasGesture()) userStopped = false;
                    else return true;
                }
                Uri u = r.getUrl();
                String sc = u.getScheme();
                // only http/https; blocks intent:// and app-open redirects
                if (!("http".equals(sc) || "https".equals(sc))) {
                    externalApp(u.toString());
                    return true;
                }
                if (!r.isForMainFrame()) return false;
                final String s = u.toString();
                // automatic = no gesture, or nobody has touched this page since it opened (a page cannot be left by the user without a tap)
                final boolean autoNav = !r.hasGesture() || pageTouches == 0;
                if (!autoNav) hopUrls.remove(s);        // the user went here on purpose: Back must not skip it later
                if (s.equals(allowOnceUrl)) {
                    allowOnceUrl = null;
                    return false;
                }
                if (adOn) {
                    if (isAdUrl(u)) {
                        blockedJump(u);
                        return true;
                    }
                    if (isSearchPage(u) && !isSearchHost(hostOf(v.getUrl()))) {
                        blockedJump(u); // fake "continue" that throws you to a Google search
                        return true;
                    }
                }
                if (autoOn) {
                    final String d = decodeRedirect(u);
                    if (d != null && !d.equals(lastDecoded)) {
                        lastDecoded = d;
                        if (autoNav) markHop();
                        ui.post(() -> web.loadUrl(d));
                        return true;
                    }
                }
                // the page moved on by itself (script / meta redirect): remember it, Back will skip it
                if (autoNav && !r.isRedirect()) markHop();
                return false;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                WebResourceResponse mw = MusicHost.serve(MainActivity.this, r);
                if (mw != null) return mw;
                sniffMedia(r.getUrl());
                boolean ad = !r.isForMainFrame() && isAdUrl(r.getUrl());
                boolean relax = flowActive && SystemClock.elapsedRealtime() < recUntil;
                logHostOnce(r.getUrl(), ad, relax);
                if (adOn && ad && !relax) {
                    return stub(r);
                }
                if (igNow && igLite) {
                    WebResourceResponse lr = igLiteRule(r);
                    if (lr != null) return lr;
                }
                return dataRules(r);
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                if (v != web) return;
                if (userStopped && url != null && !url.equals(stoppedUrl)) userStopped = false;
                pageTouches = 0;
                focusReset();
                boolean wasIg = igNow;
                igNow = InstaLite.isIgUrl(url);
                navPeek = false;
                igTargetCode = "";
                igTargetType = "";
                if (igNow && !wasIg && igLite) {
                    say("Insta Lite ON \u26A1  Autoplay band, photos halki, reels " + (igRq == 0 ? "Auto" : igRq + "p"));
                }
                onPlayer = MusicHost.isPlayerUrl(url);
                urlBar.setText(onPlayer ? "Music player" : url);
                updateChrome();
                updateQualityBadge();
                updateNav();
                if (landFs) applyLandFs(false);
                if (url != null && !url.equals(curPage)) {
                    prevPage = curPage;
                    curPage = url;
                }
                flog("NAV " + url);
                if (flowActive && hostIs(hostOf(url), FILE_HOSTS)) {
                    flog("FINAL file host reached");
                    flowEnded();
                    int n = prefs.getInt("flows", 0) + 1;
                    prefs.edit().putInt("flows", n).apply();
                    boolean copied = false;
                    if (copyFinal) {
                        try {
                            ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            if (cmb != null) {
                                cmb.setPrimaryClip(ClipData.newPlainText("link", url));
                                copied = true;
                            }
                        } catch (Exception ignored) {
                        }
                    }
                    say("Link mil gaya, ye complete ho gaya \uD83C\uDF89 (#" + n + (copied ? ", copy ho gaya" : "") + ")");
                }
                mediaItems.clear();
                boostSkipped = false;
                updateFab();
                loadingNow = true;
                updateReloadIc();
                web.getSettings().setMediaPlaybackRequiresUserGesture(!isLightHost(hostOf(url)));
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (!docStartSupported) {
                    v.evaluateJavascript(script(), null);
                }
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (v != web) return;
                loadingNow = false;
                updateReloadIc();
                if (MusicHost.isPlayerUrl(url)) pushBoostToPlayer();
                else addHistory(url, v.getTitle());
            }
        };
        web.setWebViewClient(wvClient);

        wcClient = new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                enterFullscreen(view, cb);
            }

            @Override
            public void onHideCustomView() {
                exitFullscreen();
            }

            @Override
            public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }

            @Override
            public void onProgressChanged(WebView v, int p) {
                if (v != web) return;
                progress.setProgress(p);
                progress.setVisibility(p >= 100 || userStopped ? View.INVISIBLE : View.VISIBLE);
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message m) {
                if (userStopped) return false;
                return capturePopup(m);
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                result.confirm();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String message, JsResult result) {
                result.confirm();
                return true;
            }

            @Override
            public boolean onJsBeforeUnload(WebView v, String url, String message, JsResult result) {
                result.confirm(); // "Leave site?" prompts must never stop an automatic redirect
                return true;
            }
        };
        web.setWebChromeClient(wcClient);

        dlListener = (url, ua2, cd, mime, len) -> {
            if (flowActive) {
                flowEnded();
                prefs.edit().putInt("flows", prefs.getInt("flows", 0) + 1).apply();
            }
            if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                startDownload(url, URLUtil.guessFileName(url, cd, mime), mime, false, ua2);
            }
        };
        web.setDownloadListener(dlListener);

        applyMode();


        Uri data = getIntent() != null ? getIntent().getData() : null;
        startRecording();
        flog("START " + (data != null ? data.toString() : "home"));
        if (data != null) {
            showHome(false);
            web.loadUrl(data.toString());
        } else if (igStart) {
            showHome(false);
            web.loadUrl("https://www.instagram.com/");
        } else {
            showHome(true);
        }
        askNotifPermission();
        igLastRx = rxBytes();
        ui.postDelayed(igTick, 2000);
        screenRx = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                String a = i == null ? null : i.getAction();
                if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                    screenOff = true;
                    keepBgAlive();
                } else if (Intent.ACTION_SCREEN_ON.equals(a)) {
                    screenOff = false;
                }
            }
        };
        IntentFilter sf = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        sf.addAction(Intent.ACTION_SCREEN_ON);
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenRx, sf, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(screenRx, sf);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getData() != null) {
            userStopped = false;
            startRecording();
            flog("START " + intent.getData());
            showHome(false);
            web.loadUrl(intent.getData().toString());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacks(igTick);
        MediaService.controller = null;
        MediaService.hold = false;
        MediaService.playing = false;
        MediaService.sync(this);
        if (dc != null) dc.setListener(null);
        try {
            if (screenRx != null) unregisterReceiver(screenRx);
        } catch (Throwable ignored) {
        }
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null && audioCb != null) am.unregisterAudioDeviceCallback(audioCb);
        } catch (Exception ignored) {
        }
        try {
            if (dlReceiver != null) unregisterReceiver(dlReceiver);
        } catch (Exception ignored) {
        }
        try {
            destroyFloat();
        } catch (Throwable ignored) {
        }
        try {
            web.destroy();
        } catch (Exception ignored) {
        }
        try {
            WebView other = web == webNormal ? webPriv : webNormal;
            if (other != null) other.destroy();
        } catch (Exception ignored) {
        }
        deleteProfile();
    }

    // ---------- JS bridge ----------

    private class Bridge {
        @JavascriptInterface
        public void videoFound(String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(() -> addMedia(url));
        }

        @JavascriptInterface
        public void mediaState(int playing, String title) {
            runOnUiThread(() -> onMediaState(playing == 1, title));
        }

        @JavascriptInterface
        public void boostSkip(int x) {
            runOnUiThread(() -> boostSkipped = true);
        }

        // v5.12: the hall watchdog switched the hall off (it was eating the sound on this page)
        @JavascriptInterface
        public void hallFail(String why) {
            runOnUiThread(() -> MainActivity.this.onHallFail());
        }

        @JavascriptInterface
        public void noVideo() {
        }

        // long press on a playing video: open the download sheet (instead of the site's own menu)
        @JavascriptInterface
        public void videoHold(final String src) {
            runOnUiThread(() -> {
                try {
                    web.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                } catch (Throwable ignored) {
                }
                if (igNow) {
                    openInstaSheet();
                    return;
                }
                if (src != null && (src.startsWith("http://") || src.startsWith("https://"))) addMedia(src);
                showMediaSheet();
            });
        }

        // the quality limit could not be applied to the video that is playing (no manifest / menu / other file found)
        @JavascriptInterface
        public void qFail() {
            runOnUiThread(() -> {
                if (!capApplied && vqCap > 0) {
                    say("Is video par " + vqCap + "p limit nahi lag payi (site sirf ek hi quality deti hai)");
                }
            });
        }

        // video focus: the video starved for a while, so the app stops blocking the rest of the page
        @JavascriptInterface
        public void focusStall() {
            runOnUiThread(() -> {
                if (!focusActive) return;
                focusStalled = true;
                updateFocus();
                say("Video atak raha tha, is page par Video focus band kar diya");
            });
        }

        // Instagram helper (flb_insta.js): files of the post / reel / story that is on screen
        @JavascriptInterface
        public void igReset(int x) {
            runOnUiThread(() -> MainActivity.this.igReset());
        }

        @JavascriptInterface
        public void igMedia(String url, String kind, String name) {
            runOnUiThread(() -> igAdd(url, kind, name));
        }

        @JavascriptInterface
        public void igFail(String why) {
            runOnUiThread(() -> MainActivity.this.igFail(why));
        }

        // v5.9: the post that is on screen / the info the download sheet asked for
        @JavascriptInterface
        public void igTarget(String code, String type) {
            runOnUiThread(() -> MainActivity.this.igTarget(code, type));
        }

        @JavascriptInterface
        public void igWant(String code) {
            runOnUiThread(() -> MainActivity.this.igWant(code));
        }

        @JavascriptInterface
        public void igInfo(String code, String json) {
            runOnUiThread(() -> MainActivity.this.igInfo(code, json));
        }

        // a real touch (isTrusted = true) at page coordinates already converted to view pixels
        @JavascriptInterface
        public void tap(final float x, final float y, final int tier) {
            ui.post(() -> {
                if (userStopped) return;
                if (x < 0 || y < 0 || x > web.getWidth() || y > web.getHeight()) return;
                if (tier >= 2) trustPopupUntil = SystemClock.uptimeMillis() + 5000;
                final long t = SystemClock.uptimeMillis();
                final float jx = x + (rnd.nextFloat() - 0.5f) * 2f;
                final float jy = y + (rnd.nextFloat() - 0.5f) * 2f;
                final int dur = 70 + rnd.nextInt(90);
                sendTouch(MotionEvent.ACTION_DOWN, t, t, jx, jy);
                ui.postDelayed(() -> sendTouch(MotionEvent.ACTION_MOVE, t, SystemClock.uptimeMillis(),
                        jx + (rnd.nextFloat() - 0.5f) * 3f, jy + (rnd.nextFloat() - 0.5f) * 3f), dur / 2);
                ui.postDelayed(() -> {
                    sendTouch(MotionEvent.ACTION_UP, t, SystemClock.uptimeMillis(), jx, jy);
                    tapDone();
                }, dur);
            });
        }

        // the engine recognised a link-shortener page and started working on it (kind: 0 unknown, 1 key, 2 file/apk)
        @JavascriptInterface
        public void started(final int rate, final int kind) {
            if (userStopped) return;
            if (!flowActive) {
                stepCount = 0;
                hops = 0;
                flowOrigin = prevPage;
            }
            flowActive = true;
            flowKind = kind;
            hops++;
            recUntil = SystemClock.elapsedRealtime() + 180000L;
            flog("ENGINE started kind=" + kind + " rate=" + rate + " hop=" + hops);
            ui.post(() -> {
                updateReloadIc();
                applyMode();
                String sp = rate > 1 ? ", " + rate + "x speed" : "";
                if (kind == 1) say("Key wala link pakda \uD83D\uDD11 checkpoint " + hops + sp);
                else if (kind == 2) say("File/APK wala link pakda \uD83D\uDCE6 step " + hops + sp);
                else say(rate > 1
                        ? "Link page pakad liya, " + rate + "x speed chalu ho gayi \u26A1"
                        : "Link page pakad liya, ye chalu ho gaya \u26A1");
            });
        }

        // the engine changed its mind about what this flow is for
        @JavascriptInterface
        public void kind(final int k) {
            if (!flowActive || k == flowKind) return;
            flowKind = k;
            flog("KIND changed to " + k);
            ui.post(() -> {
                applyMode();
                if (k == 1) say("Ye key wala link lag raha hai \uD83D\uDD11 key mode chalu");
                else if (k == 2) say("Ye file/APK wala link lag raha hai \uD83D\uDCE6 file mode chalu");
            });
        }

        @JavascriptInterface
        public void cp(final int n, final int of) {
            if (!flowActive) return;
            flog("CHECKPOINT " + n + "/" + of);
            ui.post(() -> say(flowKind == 1 ? "Checkpoint " + n + "/" + of + " \uD83D\uDD11" : "Step " + n + "/" + of));
        }

        // a key was found on the page: save it, copy it, stop the auto-clicking
        @JavascriptInterface
        public void key(final String key, final String host, final String info) {
            if (key == null || key.isEmpty()) return;
            flog("KEY found len=" + key.length() + " host=" + host);
            ui.post(() -> {
                saveKey(key, host);
                boolean copied = false;
                try {
                    ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cmb != null) {
                        cmb.setPrimaryClip(ClipData.newPlainText("key", key));
                        copied = true;
                    }
                } catch (Exception ignored) {
                }
                prefs.edit().putInt("keysDone", prefs.getInt("keysDone", 0) + 1).apply();
                flowEnded();
                String pv = key.length() > 24 ? key.substring(0, 24) + "\u2026" : key;
                say("Key mil gayi \uD83D\uDD11 " + (copied ? "copy ho gayi" : "") + "\n" + pv
                        + (info == null || info.isEmpty() ? "" : "\n(valid: " + info + ")"));
            });
        }

        // page the user came from before this flow started (full URL, the browser Referer is often cut to the origin)
        @JavascriptInterface
        public String origin() {
            String o = flowActive && flowOrigin != null ? flowOrigin : prevPage;
            return o == null ? "" : o;
        }

        @JavascriptInterface
        public void log(final String line) {
            if (line == null) return;
            flog(line.length() > 700 ? line.substring(0, 700) : line);
        }

        @JavascriptInterface
        public boolean recOn() {
            return flowActive || SystemClock.elapsedRealtime() < recUntil;
        }

        // real (trusted) finger drag, eased like a human swipe
        @JavascriptInterface
        public void swipe(final float x, final float y0, final float y1, final int ms) {
            ui.post(() -> {
                if (userStopped) return;
                if (x < 0 || y0 < 0 || y1 < 0 || x > web.getWidth() || y0 > web.getHeight() || y1 > web.getHeight()) return;
                final long t = SystemClock.uptimeMillis();
                final int steps = Math.max(6, Math.min(30, ms / 16));
                sendTouch(MotionEvent.ACTION_DOWN, t, t, x, y0);
                for (int k = 1; k <= steps; k++) {
                    final float f = k / (float) steps;
                    final float e = f * f * (3f - 2f * f);
                    final boolean last = k == steps;
                    final float yy = y0 + (y1 - y0) * e;
                    final float xx = x + (rnd.nextFloat() - 0.5f) * 3f;
                    ui.postDelayed(() -> sendTouch(last ? MotionEvent.ACTION_UP : MotionEvent.ACTION_MOVE,
                            t, SystemClock.uptimeMillis(), xx, yy), (long) (ms * f));
                }
            });
        }

        // the engine has been idle for a long time: reload once per page, then fall back to a hint
        @JavascriptInterface
        public void stuck() {
            ui.post(() -> {
                if (userStopped) return;
                String u = web.getUrl();
                if (u == null) return;
                flog("STUCK (30s without progress) url=" + u);
                if (flowKind == 1 || u.equals(stuckUrl)) {
                    say("Auto ruk gaya. \u22EE menu \u2192 Link Radar dekho");
                    return;
                }
                stuckUrl = u;
                say("Atak gaya tha, dobara try kar raha hoon \uD83D\uDD01");
                web.reload();
            });
        }

        @JavascriptInterface
        public void hint(final String msg) {
            if (msg == null) return;
            flog("HINT " + msg);
            ui.post(() -> showBar(msg, null, null));
        }

        @JavascriptInterface
        public void busy(final boolean on) {
            ui.post(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        // the site complained about our speed -> step that site one level slower (25 -> 10 -> 5 -> 3 -> 2 -> real-time) and retry
        @JavascriptInterface
        public void anomaly(final String host) {
            ui.post(() -> {
                if (userStopped || host == null || host.isEmpty()) return;
                long now = SystemClock.uptimeMillis();
                if (now - lastAnomalyAt < 8000) return;
                lastAnomalyAt = now;
                int cur = effectiveRate(host);
                flog("ANOMALY host=" + host + " rate=" + cur);
                if (cur <= 1) {
                    if (flowKind != 1 && freshTried.add(host)) {
                        freshSession(web.getUrl());
                        say("Real-time par bhi anomaly, fresh session ke saath dobara try \uD83D\uDD01");
                        web.reload();
                    } else {
                        showBar(flowKind == 1
                                ? host + ": real-time par bhi anomaly. Key flow hai, isliye session saaf nahi kiya (checkpoints reset ho jaate)"
                                : host + ": real-time + fresh session par bhi anomaly. Ye server-side check hai", null, null);
                    }
                    return;
                }
                int next = nextLower(cur);
                setHostRate(host, next);
                applyMode();
                showBar("Anomaly: " + host + " " + cur + "x \u2192 " + (next <= 1 ? "real-time" : next + "x") + ", dobara try", null, null);
                web.reload();
            });
        }
    }

    private void sendTouch(int action, long down, long now, float x, float y) {
        MotionEvent.PointerProperties pp = new MotionEvent.PointerProperties();
        pp.id = 0;
        pp.toolType = MotionEvent.TOOL_TYPE_FINGER;
        MotionEvent.PointerCoords pc = new MotionEvent.PointerCoords();
        pc.x = x;
        pc.y = y;
        pc.pressure = action == MotionEvent.ACTION_UP ? 0f : 0.55f + rnd.nextFloat() * 0.3f;
        pc.size = 0.4f + rnd.nextFloat() * 0.3f;
        MotionEvent e = MotionEvent.obtain(down, now, action, 1,
                new MotionEvent.PointerProperties[]{pp}, new MotionEvent.PointerCoords[]{pc},
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
        web.dispatchTouchEvent(e);
        e.recycle();
    }

    // ---------- toggles / scripts ----------

    private TextView toggle(String label, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(20);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        t.setOnClickListener(l);
        return t;
    }

    // v5.2: an option flip no longer reloads the page; the open page is updated live
    private void changed(String msg) {
        applyMode();
        pushCfg();
        say(msg);
    }

    private void applyMode() {
        if (docStartSupported) {
            if (scriptHandler != null) {
                scriptHandler.remove();
                scriptHandler = null;
            }
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(
                    web, script(), Collections.singleton("*"));
        }
    }

    private void applyUa() {
        WebSettings s = web.getSettings();
        s.setUserAgentString(desktop ? desktopUa : mobileUa);
        s.setUseWideViewPort(desktop || defaultWide);
        s.setLoadWithOverviewMode(desktop || defaultOverview);
        applyUaMetadata();
    }

    // Sec-CH-UA headers + navigator.userAgentData say "Google Chrome" instead of "Android WebView".
    // Done by reflection so the build still works if this androidx.webkit lacks the API.
    private void applyUaMetadata() {
        try {
            if (!WebViewFeature.isFeatureSupported("USER_AGENT_METADATA")) return;
            Class<?> bvB = Class.forName("androidx.webkit.UserAgentMetadata$BrandVersion$Builder");
            Class<?> umB = Class.forName("androidx.webkit.UserAgentMetadata$Builder");
            Class<?> umC = Class.forName("androidx.webkit.UserAgentMetadata");
            String full = chromeMajor + ".0.0.0";
            String[][] brands = {{"Chromium", chromeMajor, full}, {"Google Chrome", chromeMajor, full},
                    {"Not-A.Brand", "99", "99.0.0.0"}};
            ArrayList<Object> list = new ArrayList<>();
            for (String[] b : brands) {
                Object bb = bvB.getConstructor().newInstance();
                bvB.getMethod("setBrand", String.class).invoke(bb, b[0]);
                bvB.getMethod("setMajorVersion", String.class).invoke(bb, b[1]);
                bvB.getMethod("setFullVersion", String.class).invoke(bb, b[2]);
                list.add(bvB.getMethod("build").invoke(bb));
            }
            Object mb = umB.getConstructor().newInstance();
            umB.getMethod("setBrandVersionList", List.class).invoke(mb, list);
            trySet(mb, "setFullVersion", String.class, full);
            trySet(mb, "setPlatform", String.class, desktop ? "Linux" : "Android");
            trySet(mb, "setMobile", boolean.class, !desktop);
            trySet(mb, "setModel", String.class, desktop ? "" : android.os.Build.MODEL);
            if (!desktop) trySet(mb, "setPlatformVersion", String.class, android.os.Build.VERSION.RELEASE + ".0.0");
            Object md = umB.getMethod("build").invoke(mb);
            WebSettingsCompat.class.getMethod("setUserAgentMetadata", WebSettings.class, umC)
                    .invoke(null, web.getSettings(), md);
        } catch (Throwable ignored) {
        }
    }

    private static void trySet(Object b, String method, Class<?> type, Object value) {
        try {
            b.getClass().getMethod(method, type).invoke(b, value);
        } catch (Throwable ignored) {
        }
    }

    // ---------- per-site speed ----------

    private int effectiveRate(String root) {
        if (speedMode == 0) return 1;
        if (slowHosts.contains(root)) return 1;
        Integer r = hostRate.get(root);
        return r != null ? r : RATES[speedMode];
    }

    private static int nextLower(int r) {
        for (int x : LADDER) {
            if (x < r) return x;
        }
        return 1;
    }

    private void setHostRate(String host, int r) {
        if (r <= 1) {
            hostRate.remove(host);
            slowHosts.add(host);
        } else {
            slowHosts.remove(host);
            hostRate.put(host, r);
        }
        saveSlow();
        saveRates();
    }

    private void saveRates() {
        Set<String> out = new HashSet<>();
        for (Map.Entry<String, Integer> e : hostRate.entrySet()) out.add(e.getKey() + "|" + e.getValue());
        prefs.edit().putStringSet("hr", out).apply();
    }

    private void showSiteSpeed(final String root) {
        if (root.isEmpty()) return;
        final int[] opts = {0, 1, 2, 3, 5, 10, 25};
        String[] names = new String[opts.length];
        for (int i = 0; i < opts.length; i++) {
            names[i] = opts[i] == 0 ? "Auto (app khud seekhegi)" : opts[i] == 1 ? "1x (real-time)" : opts[i] + "x";
        }
        new AlertDialog.Builder(this)
                .setTitle(root + " \u2014 abhi: " + effectiveRate(root) + "x")
                .setItems(names, (d, which) -> {
                    int r = opts[which];
                    slowHosts.remove(root);
                    hostRate.remove(root);
                    if (r == 1) slowHosts.add(root);
                    else if (r > 1) hostRate.put(root, r);
                    saveSlow();
                    saveRates();
                    applyMode();
                    say(r == 0 ? "Auto speed set ho gayi \u2705" : "Is site par " + r + "x set ho gaya \u2705");
                    pushCfg();
                })
                .show();
    }

    private String script() {
        JSONObject c = new JSONObject();
        try {
            c.put("n", bridgeName);
            c.put("mode", speedMode);
            c.put("rate", RATES[speedMode]);
            c.put("auto", autoOn);
            c.put("ads", adOn);
            c.put("lt", linkType);
            c.put("fk", flowActive ? flowKind : 0);
            c.put("fa", flowActive ? 1 : 0);
            c.put("slow", new JSONArray(new ArrayList<>(slowHosts)));
            JSONObject hr = new JSONObject();
            for (Map.Entry<String, Integer> e : hostRate.entrySet()) hr.put(e.getKey(), e.getValue());
            c.put("hr", hr);
            c.put("adh", new JSONArray(Arrays.asList(AD_HOSTS)));
            c.put("sh", new JSONArray(Arrays.asList(SHORT_HOSTS)));
            c.put("boost", effBoost());
            c.put("lim", limOn);
            c.put("hall", hallLvl);
            c.put("drift", driftOn);
            c.put("bg", bgOn);
            c.put("lh", new JSONArray(Arrays.asList(LIGHT_HOSTS)));
            c.put("sv", saverOn);
            c.put("io", imgOff);
            c.put("fx", focusActive);
            c.put("vq", vqCap);
            c.put("il", igLite);
            c.put("rq", igRq);
            c.put("sq", igSq);
            c.put("ap", !igNoAuto);
            c.put("pv", !igNoPrev);
        } catch (Exception ignored) {
        }
        return "(function(){var K='" + bridgeName + "x';if(window[K])return;"
                + "Object.defineProperty(window,K,{value:1});\nvar C=" + c + ";\n"
                + bridgeJs + "\n" + mediaJs + "\n" + igJs + "\n"
                + "var LH=C.lh,HN=location.hostname.toLowerCase();"
                + "for(var li=0;li<LH.length;li++){if(HN===LH[li]||HN.endsWith('.'+LH[li]))return;}\n"
                + coreJs + "\n" + engineJs + "\n})();";
    }

    private String asset(String name) {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            copy(in, bo);
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void saveSlow() {
        prefs.edit().putStringSet("slow", new HashSet<>(slowHosts)).apply();
    }

    // ---------- host helpers ----------

    private static String hostOf(String url) {
        if (url == null) return "";
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? "" : h.toLowerCase();
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean hostIs(String h, String... list) {
        if (h == null) return false;
        for (String d : list) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    private static String rootHost(String h) {
        if (h == null) return "";
        String[] p = h.toLowerCase().split("\\.");
        if (p.length <= 2) return h.toLowerCase();
        String l = p[p.length - 1], s = p[p.length - 2];
        if (l.length() == 2 && s.matches("co|com|org|net|gov|ac|edu|nic")) {
            return p[p.length - 3] + "." + s + "." + l;
        }
        return s + "." + l;
    }

    private boolean isAdUrl(Uri u) {
        String h = u.getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        if (hostIs(h, AD_HOSTS)) return true;
        if (h.equals("youtube.com") || h.endsWith(".youtube.com")) {
            String p = u.getPath();
            if (p != null && (p.startsWith("/pagead/") || p.startsWith("/api/stats/ads")
                    || p.startsWith("/get_midroll_") || p.contains("/ptracking"))) {
                return true;
            }
        }
        return false;
    }

    private static boolean isSearchHost(String h) {
        return h.matches("(.*\\.)?google\\.[a-z.]+") || hostIs(h, "bing.com", "duckduckgo.com", "search.yahoo.com");
    }

    private static boolean isSearchPage(Uri u) {
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        String p = u.getPath() == null ? "" : u.getPath();
        if (h.matches("(.*\\.)?google\\.[a-z.]+") && p.startsWith("/search")) return true;
        if (hostIs(h, "bing.com") && p.startsWith("/search")) return true;
        if (hostIs(h, "duckduckgo.com") && u.getQueryParameter("q") != null) return true;
        return hostIs(h, "search.yahoo.com");
    }

    private void blockedJump(final Uri u) {
        final String s = u.toString();
        ui.post(() -> showBar("Fake redirect roka: " + hostOf(s), "Allow", () -> {
            allowOnceUrl = s;
            web.loadUrl(s);
        }));
    }

    // Reads the real target out of ?r=<base64>, ?url=<encoded url> and similar redirect parameters
    private String decodeRedirect(Uri u) {
        try {
            String host = u.getHost();
            if (host == null) return null;
            host = host.toLowerCase();
            if (hostIs(host, SOCIAL_HOSTS)) return null;
            String path = u.getPath() == null ? "" : u.getPath().toLowerCase();
            boolean googleUrl = host.matches("(.*\\.)?google\\.[a-z.]+") && path.equals("/url");
            boolean ytRedirect = hostIs(host, "youtube.com") && path.equals("/redirect");
            boolean pathHint = path.matches(".*/(go|out|redirect|redir|away|link|l|r|click|safe|skip|exit|jump|bridge|visit)(/.*)?");
            boolean shortHost = hostIs(host, SHORT_HOSTS);
            for (String name : u.getQueryParameterNames()) {
                boolean listed = false;
                for (String p : REDIR_PARAMS) {
                    if (p.equalsIgnoreCase(name)) {
                        listed = true;
                        break;
                    }
                }
                if (!listed) continue;
                String v = u.getQueryParameter(name);
                if (v == null || v.length() < 12) continue;
                String dec = null;
                if (v.startsWith("aHR0")) {
                    dec = b64(v);
                } else if ((v.startsWith("http://") || v.startsWith("https://"))
                        && (pathHint || googleUrl || ytRedirect || shortHost)) {
                    dec = v;
                }
                if (dec == null) continue;
                Uri d = Uri.parse(dec);
                String dh = d.getHost();
                if (dh == null || !dh.contains(".") || dh.equalsIgnoreCase(host)) continue;
                if (isAdUrl(d) || isSearchPage(d)) continue;
                return dec;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String b64(String v) {
        try {
            String s = v.replace('-', '+').replace('_', '/');
            while (s.length() % 4 != 0) s += "=";
            String r = new String(Base64.decode(s, Base64.DEFAULT), "UTF-8").trim();
            return r.startsWith("http://") || r.startsWith("https://") ? r : null;
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- harmless answers for blocked ad requests (so anti-adblock checks pass) ----------

    private WebResourceResponse stub(WebResourceRequest r) {
        Uri u = r.getUrl();
        String p = u.getPath() == null ? "" : u.getPath().toLowerCase();
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        Map<String, String> req = r.getRequestHeaders();
        String accept = req == null ? null : req.get("Accept");
        byte[] body;
        String mime;
        if (p.endsWith("adsbygoogle.js") || p.contains("/show_ads")) {
            body = ADS_STUB.getBytes();
            mime = "application/javascript";
        } else if (p.endsWith("/gpt.js") || p.contains("pubads_impl") || h.contains("googletagservices")) {
            body = GPT_STUB.getBytes();
            mime = "application/javascript";
        } else if (p.matches(".*\\.(gif|png|jpe?g|webp|svg)$") || (accept != null && accept.startsWith("image/"))) {
            body = GIF;
            mime = "image/gif";
        } else if (accept != null && accept.contains("text/html")) {
            body = "<!doctype html><html><body></body></html>".getBytes();
            mime = "text/html";
        } else if (p.endsWith(".css")) {
            body = "/* */".getBytes();
            mime = "text/css";
        } else if (accept != null && accept.contains("application/json")) {
            body = "{}".getBytes();
            mime = "application/json";
        } else {
            body = "/* */".getBytes();
            mime = "application/javascript";
        }
        Map<String, String> hd = new HashMap<>();
        hd.put("Access-Control-Allow-Origin", "*");
        hd.put("Cache-Control", "no-store");
        return new WebResourceResponse(mime, "utf-8", 200, "OK", hd, new ByteArrayInputStream(body));
    }

    // ====================================================================== v5.2 additions

    private static long rxBytes() {
        try {
            return TrafficStats.getUidRxBytes(android.os.Process.myUid());
        } catch (Throwable t) {
            return -1;
        }
    }

    private static String fmtData(long b) {
        if (b < 0) return "n/a";
        if (b < 1024L) return b + " B";
        if (b < 1024L * 1024L) return (b / 1024L) + " KB";
        return String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0);
    }

    private CookieManager curCookies() {
        return incog && privCm != null ? privCm : CookieManager.getInstance();
    }

    private void copyText(String text, String msg) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("link", text));
                say(msg);
            }
        } catch (Exception e) {
            say("Copy nahi ho paya");
        }
    }

    // ---- X button: really stops the page and the automation ----

    private void updateReloadIc() {
        if (reloadIc == null) return;
        boolean busy = loadingNow || flowActive;
        reloadIc.setImageDrawable(new Ic(busy ? Ic.CLOSE : Ic.REFRESH, Ui.SUB));
    }

    private void stopPage() {
        stoppedUrl = curPage != null ? curPage : web.getUrl();
        userStopped = true;
        try {
            web.stopLoading();
        } catch (Exception ignored) {
        }
        try {
            web.evaluateJavascript("try{window.stop()}catch(e){}", null);
        } catch (Exception ignored) {
        }
        if (flowActive) {
            flog("STOP by user");
            flowEnded();
        }
        loadingNow = false;
        updateReloadIc();
        progress.setVisibility(View.INVISIBLE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        say("Loading ruk gayi \u2705");
    }

    // ---- live settings (no reload) ----

    private String cfgJson() {
        JSONObject c = new JSONObject();
        try {
            c.put("mode", speedMode);
            c.put("rate", RATES[speedMode]);
            c.put("auto", autoOn);
            c.put("ads", adOn);
            c.put("lt", linkType);
            c.put("bg", bgOn);
            c.put("slow", new JSONArray(new ArrayList<>(slowHosts)));
            JSONObject hr = new JSONObject();
            for (Map.Entry<String, Integer> e : hostRate.entrySet()) hr.put(e.getKey(), e.getValue());
            c.put("hr", hr);
            c.put("sv", saverOn);
            c.put("io", imgOff);
            c.put("fx", focusActive);
            c.put("vq", vqCap);
            c.put("il", igLite);
            c.put("rq", igRq);
            c.put("sq", igSq);
            c.put("ap", !igNoAuto);
            c.put("pv", !igNoPrev);
        } catch (Exception ignored) {
        }
        return c.toString();
    }

    private void pushCfg() {
        if (web == null) return;
        try {
            web.evaluateJavascript("(function(){var f=window['" + bridgeName + "c'];return f?f(" + cfgJson()
                    + "):-1})()", null);
        } catch (Exception ignored) {
        }
    }

    // ---- data saver / video focus / video quality (runs on the network thread of the WebView) ----

    private static final java.util.regex.Pattern MEDIA_PATH = java.util.regex.Pattern.compile(
            ".*\\.(mp4|m4v|webm|mkv|mov|flv|f4v|3gp|m3u8|mpd|ts|m4s|cmfv|cmfa|m4a|aac|mp3|ogg|opus|vtt|key)$");
    private static final java.util.regex.Pattern IMG_PATH = java.util.regex.Pattern.compile(
            ".*\\.(jpe?g|png|gif|webp|avif|bmp|ico|svg)$");
    private static final java.util.regex.Pattern FONT_PATH = java.util.regex.Pattern.compile(
            ".*\\.(woff2?|ttf|otf|eot)$");
    private static final java.util.regex.Pattern CODE_PATH = java.util.regex.Pattern.compile(
            ".*\\.(js|css|html?|json|woff2?|ttf|otf|eot|svg|ico)$");

    private static String hdr(Map<String, String> h, String name) {
        if (h == null) return null;
        for (Map.Entry<String, String> e : h.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) return e.getValue();
        }
        return null;
    }

    private static String pathLower(Uri u) {
        String p = u.getPath();
        return p == null ? "" : p.toLowerCase();
    }

    private static boolean isPlaylistReq(Uri u, Map<String, String> h) {
        String p = pathLower(u);
        String q = u.getQuery() == null ? "" : u.getQuery().toLowerCase();
        if (p.contains(".m3u8") || p.contains(".mpd") || q.contains(".m3u8") || q.contains(".mpd")) return true;
        String acc = hdr(h, "Accept");
        return acc != null && (acc.contains("mpegurl") || acc.contains("dash+xml"));
    }

    private boolean isMediaReq(Uri u, Map<String, String> h) {
        if (isPlaylistReq(u, h)) return true;
        String p = pathLower(u);
        if (MEDIA_PATH.matcher(p).matches()) return true;
        if (p.contains("/videoplayback") || p.contains(".m3u8") || p.contains(".mpd")) return true;
        if (hdr(h, "Range") != null && !IMG_PATH.matcher(p).matches()) return true;
        String acc = hdr(h, "Accept");
        return acc != null && (acc.startsWith("video/") || acc.startsWith("audio/"));
    }

    private static String dirKey(Uri u) {
        String host = u.getHost() == null ? "" : u.getHost().toLowerCase();
        String p = u.getPath() == null ? "/" : u.getPath();
        int i = p.lastIndexOf('/');
        return host + (i >= 0 ? p.substring(0, i + 1) : "/");
    }

    private boolean inMediaDir(Uri u) {
        String k = dirKey(u);
        for (String d : mediaDirs) {
            if (k.startsWith(d)) return true;
        }
        return false;
    }

    private WebResourceResponse dataRules(WebResourceRequest r) {
        if (r.isForMainFrame()) return null;
        Uri u = r.getUrl();
        Map<String, String> h = r.getRequestHeaders();
        String p = pathLower(u);
        if (isMediaReq(u, h)) {
            String dk = dirKey(u);
            if (!mediaDirs.contains(dk)) {
                mediaDirs.add(dk);
                while (mediaDirs.size() > 40) mediaDirs.remove(0);
            }
            int capN = capNow();
            if (capN > 0 && isPlaylistReq(u, h) && "GET".equalsIgnoreCase(r.getMethod())) {
                WebResourceResponse x = capPlaylist(r, capN);
                if (x != null) return x;
            }
            return null;
        }
        if (focusActive) {
            // video focus: only the video itself gets data (files in the same folder as the video stay: some sites hide segments)
            if (inMediaDir(u) && !CODE_PATH.matcher(p).matches()) return null;
            return stub(r);
        }
        String acc = hdr(h, "Accept");
        if (imgOff && (IMG_PATH.matcher(p).matches() || (acc != null && acc.startsWith("image/")))) return stub(r);
        if (saverOn && (FONT_PATH.matcher(p).matches() || p.endsWith(".gif"))) return stub(r);
        return null;
    }

    /** Answers an HLS / DASH manifest request with a copy that only lists renditions up to the chosen height. */
    private WebResourceResponse capPlaylist(WebResourceRequest r, int cap) {
        final String url = r.getUrl().toString();
        try {
            Map<String, String> rh = r.getRequestHeaders();
            String ck = null;
            try {
                ck = curCookies().getCookie(url);
            } catch (Throwable ignored) {
            }
            VideoCap.Result res = VideoCap.fetch(url, rh, ck, 8000);
            if (res == null || res.code != 200 || res.body == null) return null;
            for (String sc : res.setCookies) {
                try {
                    curCookies().setCookie(url, sc);
                } catch (Throwable ignored) {
                }
            }
            String txt = new String(res.body, "UTF-8");
            boolean moved = res.finalUrl != null && !res.finalUrl.equals(url);
            String out;
            String mime;
            if (VideoCap.looksHls(txt)) {
                out = VideoCap.capHlsMaster(txt, cap, moved ? res.finalUrl : null);
                mime = "application/vnd.apple.mpegurl";
            } else if (!moved && VideoCap.looksDash(txt)) {
                out = VideoCap.capDash(txt, cap);
                mime = "application/dash+xml";
            } else {
                return null;          // a normal media playlist: let the WebView fetch it itself
            }
            if (!capApplied) {
                capApplied = true;
                if (!out.equals(txt)) say("Video quality " + cap + "p tak limit lag gayi \u2705");
            }
            Map<String, String> hd = new HashMap<>();
            String origin = hdr(rh, "Origin");
            if (origin != null && !origin.isEmpty() && !"null".equals(origin)) {
                hd.put("Access-Control-Allow-Origin", origin);
                hd.put("Access-Control-Allow-Credentials", "true");
                hd.put("Vary", "Origin");
            } else {
                hd.put("Access-Control-Allow-Origin", "*");
            }
            hd.put("Cache-Control", "no-cache");
            return new WebResourceResponse(mime, "utf-8", 200, "OK", hd, new ByteArrayInputStream(out.getBytes("UTF-8")));
        } catch (Throwable t) {
            return null;
        }
    }

    // ---- video focus state ----

    private void updateFocus() {
        boolean want = focusOn && playingNow && !focusStalled;
        if (want == focusActive) return;
        focusActive = want;
        pushCfg();
        if (want) {
            focusPauseDownloads();
            say("Video focus: ab sirf is video ko data mil raha hai \uD83C\uDFAC");
        } else {
            focusResumeDownloads();
        }
    }

    private void focusReset() {
        playingNow = false;
        focusStalled = false;
        capApplied = false;
        mediaDirs.clear();
        if (focusActive) {
            focusActive = false;
            focusResumeDownloads();
        }
    }

    private void focusPauseDownloads() {
        if (dc == null) return;
        for (DownloadCenter.Task t : dc.list()) {
            if (t.state == DownloadCenter.RUNNING || t.state == DownloadCenter.QUEUED) {
                dc.pause(t);
                focusPaused.add(t);
            }
        }
    }

    private void focusResumeDownloads() {
        if (dc == null) return;
        for (DownloadCenter.Task t : focusPaused) {
            if (t.state == DownloadCenter.PAUSED) dc.resume(t);
        }
        focusPaused.clear();
    }

    // ---- menu helpers ----

    /** A chip that flips an option and recolours itself, the menu stays open and the page is not touched. */
    private void addToggle(Ui.Flow f, String label, boolean active, final Runnable flip,
                           final java.util.function.BooleanSupplier state) {
        final TextView c = Ui.chip(this, label, active);
        c.setOnClickListener(v -> {
            flip.run();
            Ui.styleChip(c, state.getAsBoolean());
        });
        f.addView(c, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void updateQualityBadge() {
        if (qBadge == null) return;
        int cap = capNow();
        boolean on = cap > 0;
        qBadge.setText(on ? cap + "p" : "Auto");
        qBadge.setTextColor(on ? Color.WHITE : (incog ? 0xFFE6E6EE : Ui.INK));
        qBadge.setBackground(Ui.round(on ? Ui.ACCENT : (incog ? 0x44FFFFFF : 0x22808090), dp(12)));
    }

    /** Quality picker (like the YouTube one): a list, the current choice has a tick. */
    // ---- Star: favourite site in a small floating window ----

    private static final String FILE_EXT = ".*\\.(mp4|m4v|mkv|webm|mov|avi|3gp|flv|mp3|m4a|aac|wav|flac|ogg|opus|zip|rar|7z|apk|pdf)$";

    // fills the focused text box (or the first visible one) with the copied link, the way a real paste would
    private static final String PASTE_JS = "(function(t){var ok=function(x){if(!x)return false;var n=x.tagName;"
            + "if(n==='TEXTAREA')return true;"
            + "if(n==='INPUT'){var ty=(x.type||'text').toLowerCase();return ty==='text'||ty==='url'||ty==='search'||ty==='';}"
            + "return !!x.isContentEditable;};"
            + "var e=document.activeElement;"
            + "if(!ok(e)){e=null;var l=document.querySelectorAll('input,textarea');"
            + "for(var i=0;i<l.length;i++){var c=l[i];if(!ok(c))continue;var r=c.getBoundingClientRect();"
            + "if(r.width>40&&r.height>12&&c.offsetParent!==null&&!c.disabled&&!c.readOnly){e=c;break;}}}"
            + "if(!e)return 0;"
            + "try{e.focus();}catch(x){}"
            + "if(e.isContentEditable){e.textContent=t;}else{"
            + "var pr=e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;"
            + "var d=Object.getOwnPropertyDescriptor(pr,'value');"
            + "if(d&&d.set){d.set.call(e,t);}else{e.value=t;}}"
            + "e.dispatchEvent(new Event('input',{bubbles:true}));"
            + "e.dispatchEvent(new Event('change',{bubbles:true}));"
            + "return 1;})(";

    private static boolean isFileUrl(Uri u) {
        String p = u.getPath();
        return p != null && p.toLowerCase().matches(FILE_EXT);
    }

    private void updateStarBtn() {
        if (starBtn == null) return;
        boolean set = !favUrl.isEmpty();
        boolean open = floatBox != null && floatBox.getVisibility() == View.VISIBLE;
        int col = set ? 0xFFFFA000 : (incog ? 0xFFB8B8C4 : Ui.SUB);
        starBtn.setImageDrawable(new Ic(set ? Ic.STAR_FILL : Ic.STAR, col));
        starBtn.setBackground(open ? Ui.round(0x33FFA000, dp(12)) : null);
    }

    private void setFav(String name, String url, boolean openNow) {
        String u = normalizeUrl(url);
        if (u == null) {
            say("Sahi link daalo (jaise y2mate.com)");
            return;
        }
        String h = hostOf(u);
        if (h.startsWith("www.")) h = h.substring(4);
        favName = (name == null || name.trim().isEmpty()) ? h : name.trim();
        favUrl = u;
        prefs.edit().putString("favName", favName).putString("favUrl", favUrl).apply();
        destroyFloat();
        updateStarBtn();
        if (openNow) {
            showFloat();
            say("Star site set: " + favName + " \u2605 Ab star dabao, ye site kisi bhi page ke upar floating window mein khulegi");
        }
    }

    private void clearFav() {
        favName = "";
        favUrl = "";
        prefs.edit().remove("favName").remove("favUrl").apply();
        destroyFloat();
        updateStarBtn();
        say("Star site hata di");
    }

    private View favRow(String title, String sub, boolean tick, View.OnClickListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(22), dp(11), dp(22), dp(11));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.addView(Ui.label(this, title, 16, Ui.INK, tick));
        if (sub != null && !sub.isEmpty()) txt.addView(Ui.label(this, sub, 12, Ui.SUB, false));
        row.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (tick) row.addView(Ui.label(this, "\u2713", 20, Ui.ACCENT, true));
        row.setOnClickListener(l);
        Ui.press(row);
        return row;
    }

    private void showFavPicker() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(22));
        TextView note = Ui.label(this, "Star wali site kisi bhi page ke upar chhoti floating window mein khulti hai. "
                + "Wahan apna link paste karke kaam khud kar lo (Paste button). "
                + "Star dabao = kholo / band karo, star par lamba dabao = site badlo.", 12.5f, Ui.SUB, false);
        note.setPadding(dp(22), dp(2), dp(22), dp(8));
        col.addView(note);
        if (!favUrl.isEmpty()) {
            col.addView(Ui.section(this, "Abhi star par"));
            col.addView(favRow(favName, hostOf(favUrl), true, v -> {
                sheet.hide();
                showFloat();
            }));
        }
        final String cur = web == null ? null : web.getUrl();
        if (!homeShown && cur != null && (cur.startsWith("http://") || cur.startsWith("https://")) && !cur.equals(favUrl)) {
            col.addView(Ui.section(this, "Abhi khuli site"));
            col.addView(favRow(hostOf(cur), "Is site ko star banao", false, v -> {
                sheet.hide();
                setFav("", cur, true);
            }));
        }
        if (!homeSites.isEmpty()) {
            col.addView(Ui.section(this, "Home ki favourite sites"));
            for (final String[] s : new ArrayList<>(homeSites)) {
                col.addView(favRow(s[0], hostOf(s[1]), s[1].equals(favUrl), v -> {
                    sheet.hide();
                    setFav(s[0], s[1], true);
                }));
            }
        }
        col.addView(Ui.section(this, "Ya apni site ka link"));
        col.addView(favRow("Link daalo...", "jaise y2mate.com", false, v -> {
            sheet.hide();
            askFavLink();
        }));
        if (!favUrl.isEmpty()) {
            col.addView(favRow("Star hatao", null, false, v -> {
                sheet.hide();
                clearFav();
            }));
        }
        sheet.show("Star site (floating)", col, true, false);
    }

    private void askFavLink() {
        final EditText u = new EditText(this);
        u.setHint("Site link (jaise y2mate.com)");
        u.setSingleLine(true);
        u.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), 0);
        box.addView(u);
        new AlertDialog.Builder(this).setTitle("Star wali site ka link")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> setFav("", u.getText().toString(), true))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleFloat() {
        if (floatBox != null && floatBox.getVisibility() == View.VISIBLE) hideFloat();
        else showFloat();
    }

    private void showFloat() {
        if (favUrl.isEmpty()) {
            showFavPicker();
            return;
        }
        ensureFloat();
        if (floatWeb == null || floatBox == null) {
            say("Floating window nahi khul payi");
            return;
        }
        floatBox.setVisibility(View.VISIBLE);
        floatBox.bringToFront();
        try {
            floatWeb.onResume();
        } catch (Throwable ignored) {
        }
        if (floatLoaded == null) {
            floatLoaded = favUrl;
            floatWeb.loadUrl(favUrl);
        }
        layoutFloat();
        content.post(this::layoutFloat);
        updateStarBtn();
    }

    private void hideFloat() {
        if (floatBox == null) return;
        floatBox.setVisibility(View.GONE);
        parkWeb(floatWeb);
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(floatWeb.getWindowToken(), 0);
        } catch (Throwable ignored) {
        }
        updateStarBtn();
    }

    private void destroyFloat() {
        floatLoaded = null;
        floatBig = false;
        WebView fw = floatWeb;
        FrameLayout fb = floatBox;
        floatBox = null;
        floatWeb = null;
        floatTitle = null;
        floatProg = null;
        floatBigTv = null;
        if (fb != null && content != null) {
            try {
                content.removeView(fb);
            } catch (Throwable ignored) {
            }
        }
        if (fw != null) {
            try {
                if (fw.getParent() instanceof ViewGroup) ((ViewGroup) fw.getParent()).removeView(fw);
                fw.stopLoading();
                fw.destroy();
            } catch (Throwable ignored) {
            }
        }
        updateStarBtn();
    }

    private void saveFloatRect() {
        if (floatBig || floatW <= 0) return;
        prefs.edit().putInt("fl_x", floatX).putInt("fl_y", floatY).putInt("fl_w", floatW).putInt("fl_h", floatH).apply();
    }

    private void clampFloatPos() {
        if (floatBox == null || content == null) return;
        int cw = content.getWidth(), ch = content.getHeight();
        floatX = Math.max(0, Math.min(floatX, cw - floatBox.getWidth()));
        floatY = Math.max(0, Math.min(floatY, ch - floatBox.getHeight()));
    }

    /** Applies the wanted position / size, kept inside the visible area (also when the keyboard shrinks it). */
    private void layoutFloat() {
        if (floatBox == null || content == null) return;
        int cw = content.getWidth(), ch = content.getHeight();
        if (cw <= 0 || ch <= 0) return;
        if (floatW <= 0 || floatH <= 0) {
            floatW = (int) (cw * 0.94f);
            floatH = (int) (ch * 0.5f);
            floatX = (cw - floatW) / 2;
            floatY = ch - floatH - dp(8);
        }
        int maxW = cw - dp(4), maxH = ch - dp(4);
        int w = Math.max(Math.min(dp(220), maxW), Math.min(floatW, maxW));
        int h = Math.max(Math.min(dp(170), maxH), Math.min(floatH, maxH));
        int x = Math.max(0, Math.min(floatX, cw - w));
        int y = Math.max(0, Math.min(floatY, ch - h));
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) floatBox.getLayoutParams();
        if (lp.width != w || lp.height != h) {
            lp.width = w;
            lp.height = h;
            floatBox.setLayoutParams(lp);
        }
        floatBox.setTranslationX(x);
        floatBox.setTranslationY(y);
    }

    private void toggleFloatBig() {
        if (floatBox == null || content == null) return;
        int cw = content.getWidth(), ch = content.getHeight();
        if (!floatBig) {
            floatSaved = new int[]{floatX, floatY, floatW, floatH};
            floatX = dp(4);
            floatY = dp(4);
            floatW = cw - dp(8);
            floatH = ch - dp(8);
            floatBig = true;
        } else {
            if (floatSaved != null) {
                floatX = floatSaved[0];
                floatY = floatSaved[1];
                floatW = floatSaved[2];
                floatH = floatSaved[3];
            }
            floatBig = false;
        }
        if (floatBigTv != null) floatBigTv.setText(floatBig ? "Chhota" : "Bada");
        layoutFloat();
    }

    private void floatDownload(String url, String name, String mime, String ua) {
        if (dc == null || floatWeb == null) return;
        stripTask = dc.add(url, name, ua != null ? ua : floatWeb.getSettings().getUserAgentString(),
                floatWeb.getUrl(), mime, false);
        say("Download shuru");
    }

    private void pasteIntoFloat() {
        if (floatWeb == null) return;
        CharSequence t = null;
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData cd = cm == null ? null : cm.getPrimaryClip();
            if (cd != null && cd.getItemCount() > 0) t = cd.getItemAt(0).coerceToText(this);
        } catch (Throwable ignored) {
        }
        if (t == null || t.toString().trim().isEmpty()) {
            say("Clipboard khali hai, pehle link copy karo");
            return;
        }
        floatWeb.evaluateJavascript(PASTE_JS + JSONObject.quote(t.toString().trim()) + ")", value -> {
            if ("1".equals(value)) say("Link paste ho gaya \u2705");
            else say("Koi text box nahi mila. Pehle site ke box par tap karo, phir Paste dabao");
        });
    }

    /** A link the floating page tried to open in a new window: open it inside the same window (or download it). */
    private boolean floatPopup(Message m, boolean gesture) {
        if (!gesture || floatWeb == null) return false;     // pop-up ads (no tap) stay blocked
        final WebView tmp = new WebView(this);
        tmp.getSettings().setJavaScriptEnabled(true);
        final boolean[] done = {false};
        final WebViewClient wc = new WebViewClient() {
            private void got(final String url) {
                if (done[0] || url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
                done[0] = true;
                ui.post(() -> {
                    try {
                        Uri uu = Uri.parse(url);
                        if (floatWeb != null && !(adOn && isAdUrl(uu))) {
                            if (isFileUrl(uu)) floatDownload(url, URLUtil.guessFileName(url, null, null), null, null);
                            else floatWeb.loadUrl(url);
                        }
                    } catch (Throwable ignored) {
                    }
                    try {
                        tmp.stopLoading();
                        tmp.destroy();
                    } catch (Throwable ignored) {
                    }
                });
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                got(r.getUrl().toString());
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                got(url);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (r.isForMainFrame()) got(r.getUrl().toString());
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
        };
        tmp.setWebViewClient(wc);
        ui.postDelayed(() -> {
            try {
                tmp.destroy();
            } catch (Throwable ignored) {
            }
        }, 12000);
        WebView.WebViewTransport tr = (WebView.WebViewTransport) m.obj;
        tr.setWebView(tmp);
        m.sendToTarget();
        return true;
    }

    private void ensureFloat() {
        if (floatBox != null) return;
        final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
        WebView fw = null;
        if (incog && profileOk) fw = newWebView("flb_private");
        if (fw == null) fw = new WebView(this);
        floatWeb = fw;
        WebSettings s = fw.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        if (mobileUa != null) s.setUserAgentString(mobileUa);
        try {
            CookieManager.getInstance().setAcceptThirdPartyCookies(fw, true);
        } catch (Throwable ignored) {
        }
        try {
            if (WebViewFeature.isFeatureSupported("REQUESTED_WITH_HEADER_ALLOW_LIST")) {
                WebSettingsCompat.class.getMethod("setRequestedWithHeaderOriginAllowList",
                        WebSettings.class, Set.class).invoke(null, s, Collections.<String>emptySet());
            }
        } catch (Throwable ignored) {
        }

        fw.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                if (!("http".equals(sc) || "https".equals(sc))) return true;     // no "open in app" jumps
                if (!r.isForMainFrame()) return false;
                if (adOn && isAdUrl(u)) return true;
                if (isFileUrl(u)) {
                    floatDownload(u.toString(), URLUtil.guessFileName(u.toString(), null, null), null, null);
                    return true;
                }
                return false;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (adOn && isAdUrl(r.getUrl())) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                if (floatTitle != null) {
                    String h = hostOf(url);
                    if (h.startsWith("www.")) h = h.substring(4);
                    if (!h.isEmpty()) floatTitle.setText(h);
                }
            }
        });
        fw.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (floatProg == null) return;
                floatProg.setProgress(p);
                floatProg.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message m) {
                return floatPopup(m, isUserGesture);
            }
        });
        fw.setDownloadListener((url, ua2, cd, mime, len) -> {
            if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                floatDownload(url, URLUtil.guessFileName(url, cd, mime), mime, ua2);
            }
        });

        floatBox = new FrameLayout(this);
        floatBox.setBackground(Ui.stroked(Color.WHITE, dp(14), 0xFF2B2B33, dp(2)));
        floatBox.setElevation(dp(14));
        floatBox.setClipToOutline(true);
        LinearLayout colv = new LinearLayout(this);
        colv.setOrientation(LinearLayout.VERTICAL);
        floatBox.addView(colv, new FrameLayout.LayoutParams(MP, MP));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF2B2B33);
        bar.setPadding(dp(12), 0, dp(4), 0);
        floatTitle = Ui.label(this, favName, 13, Color.WHITE, true);
        floatTitle.setSingleLine(true);
        floatTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        floatTitle.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(floatTitle, new LinearLayout.LayoutParams(0, MP, 1f));

        TextView pasteTv = Ui.label(this, "Paste", 12, Color.WHITE, true);
        pasteTv.setGravity(Gravity.CENTER);
        pasteTv.setBackground(Ui.round(Ui.ACCENT, dp(12)));
        pasteTv.setPadding(dp(11), dp(5), dp(11), dp(5));
        pasteTv.setOnClickListener(v -> pasteIntoFloat());
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.setMargins(dp(4), 0, dp(4), 0);
        bar.addView(pasteTv, plp);

        floatBigTv = Ui.label(this, floatBig ? "Chhota" : "Bada", 12, Color.WHITE, true);
        floatBigTv.setGravity(Gravity.CENTER);
        floatBigTv.setBackground(Ui.round(0x33FFFFFF, dp(12)));
        floatBigTv.setPadding(dp(10), dp(5), dp(10), dp(5));
        floatBigTv.setOnClickListener(v -> toggleFloatBig());
        bar.addView(floatBigTv, plp);

        ImageView rl = Ui.icon(this, Ic.REFRESH, Color.WHITE);
        rl.setPadding(dp(8), dp(8), dp(8), dp(8));
        rl.setOnClickListener(v -> {
            if (floatWeb != null) floatWeb.reload();
        });
        bar.addView(rl, new LinearLayout.LayoutParams(dp(36), dp(36)));
        ImageView cl = Ui.icon(this, Ic.CLOSE, Color.WHITE);
        cl.setPadding(dp(8), dp(8), dp(8), dp(8));
        cl.setOnClickListener(v -> hideFloat());
        bar.addView(cl, new LinearLayout.LayoutParams(dp(36), dp(36)));
        colv.addView(bar, new LinearLayout.LayoutParams(MP, dp(38)));

        floatProg = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        floatProg.setMax(100);
        floatProg.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
        floatProg.setProgressBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        colv.addView(floatProg, new LinearLayout.LayoutParams(MP, dp(3)));
        colv.addView(fw, new LinearLayout.LayoutParams(MP, 0, 1f));

        // drag by the title bar
        final View.OnTouchListener drag = new View.OnTouchListener() {
            float dx, dy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (floatBox == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = floatBox.getTranslationX() - e.getRawX();
                        dy = floatBox.getTranslationY() - e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        floatX = (int) (e.getRawX() + dx);
                        floatY = (int) (e.getRawY() + dy);
                        clampFloatPos();
                        layoutFloat();
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        saveFloatRect();
                        return true;
                    default:
                        return false;
                }
            }
        };
        bar.setOnTouchListener(drag);
        floatTitle.setOnTouchListener(drag);

        // resize by the corner grip
        View grip = new View(this) {
            private final android.graphics.Paint gp = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

            @Override
            protected void onDraw(android.graphics.Canvas c) {
                gp.setColor(0xFF8E8E93);
                gp.setStrokeWidth(dp(2));
                gp.setStrokeCap(android.graphics.Paint.Cap.ROUND);
                int w = getWidth(), h = getHeight(), m = dp(6);
                for (int i = 0; i < 3; i++) {
                    int o = dp(5) * i;
                    c.drawLine(w - m - dp(14) + o, h - m, w - m, h - m - dp(14) + o, gp);
                }
            }
        };
        grip.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int sw, sh;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (floatBox == null || content == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        sw = floatBox.getWidth();
                        sh = floatBox.getHeight();
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        int cw = content.getWidth(), ch = content.getHeight();
                        floatW = Math.max(dp(220), Math.min(sw + (int) (e.getRawX() - sx), cw - floatX));
                        floatH = Math.max(dp(170), Math.min(sh + (int) (e.getRawY() - sy), ch - floatY));
                        layoutFloat();
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        saveFloatRect();
                        return true;
                    default:
                        return false;
                }
            }
        });
        floatBox.addView(grip, new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM | Gravity.END));

        floatX = prefs.getInt("fl_x", 0);
        floatY = prefs.getInt("fl_y", 0);
        floatW = prefs.getInt("fl_w", 0);
        floatH = prefs.getInt("fl_h", 0);
        floatBox.setVisibility(View.GONE);
        content.addView(floatBox, new FrameLayout.LayoutParams(dp(300), dp(300), Gravity.TOP | Gravity.START));
        if (!floatHooked) {
            floatHooked = true;
            content.addOnLayoutChangeListener((v, l, t, r, b, oL, oT, oR, oB) -> {
                if (floatBox != null && floatBox.getVisibility() == View.VISIBLE
                        && ((r - l) != (oR - oL) || (b - t) != (oB - oT))) {
                    layoutFloat();
                }
            });
        }
    }

    private void showQualitySheet() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(22));
        final int[] caps = {0, 720, 480, 360, 240, 144};
        final String[] names = {"Auto", "720p", "480p", "360p", "240p", "144p"};
        final String[] hints = {"koi limit nahi, site jo de", "HD, zyada data", "theek-thaak", "kam data",
                "bahut kam data", "sabse kam data"};
        for (int i = 0; i < caps.length; i++) {
            final int cap = caps[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(22), dp(13), dp(22), dp(13));
            LinearLayout txt = new LinearLayout(this);
            txt.setOrientation(LinearLayout.VERTICAL);
            txt.addView(Ui.label(this, names[i], 16, Ui.INK, vqCap == cap));
            txt.addView(Ui.label(this, hints[i], 12, Ui.SUB, false));
            row.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (vqCap == cap) row.addView(Ui.label(this, "\u2713", 20, Ui.ACCENT, true));
            row.setOnClickListener(v -> {
                vqCap = cap;
                DownloadCenter.hlsCap = cap;
                prefs.edit().putInt("vq", cap).apply();
                applyMode();
                pushCfg();
                updateQualityBadge();
                sheet.hide();
                say(cap == 0 ? "Video quality: Auto (koi limit nahi)"
                        : "Video quality " + cap + "p tak limit \u2705 Chal rahi video par poori tarah lagane ke liye page ek baar refresh karo. Download bhi isi quality mein hoga");
            });
            Ui.press(row);
            col.addView(row);
        }
        TextView note = Ui.label(this, "m3u8 / mpd wali videos par seedha lagta hai. Seedhi MP4 wali sites par app page mein "
                + "likhi doosri quality ki file ya player ka quality menu dhoondhti hai. Jis site par ek hi quality hai wahan limit nahi lag sakti.",
                12, Ui.SUB, false);
        note.setPadding(dp(22), dp(10), dp(22), 0);
        col.addView(note);
        sheet.show("Video quality", col, true, false);
    }

    // ---- Back: skip the pages that redirected on by themselves ----

    private boolean cleanBack() {
        return incog || cleanBackOn;
    }

    private void markHop() {
        try {
            android.webkit.WebHistoryItem it = web.copyBackForwardList().getCurrentItem();
            if (it != null && it.getUrl() != null) {
                hopUrls.add(it.getUrl());
                if (hopUrls.size() > 400) hopUrls.clear();
            }
        } catch (Throwable ignored) {
        }
    }

    private boolean isHopAt(android.webkit.WebBackForwardList l, int i) {
        android.webkit.WebHistoryItem it = l.getItemAtIndex(i);
        return it != null && it.getUrl() != null && hopUrls.contains(it.getUrl());
    }

    private static String urlKey(String u) {
        if (u == null) return null;
        int i = u.indexOf('#');
        return i >= 0 ? u.substring(0, i) : u;
    }

    private boolean sameUrlAt(android.webkit.WebBackForwardList l, int i, String curKey) {
        if (curKey == null) return false;
        android.webkit.WebHistoryItem it = l.getItemAtIndex(i);
        return it != null && curKey.equals(urlKey(it.getUrl()));
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        try {
            if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && web != null) {
                android.graphics.Rect r = new android.graphics.Rect();
                if (web.getGlobalVisibleRect(r) && r.contains((int) ev.getRawX(), (int) ev.getRawY())) pageTouches++;
            }
        } catch (Throwable ignored) {
        }
        return super.dispatchTouchEvent(ev);
    }

    private void backSmart() {
        if (cleanBack()) {
            try {
                android.webkit.WebBackForwardList l = web.copyBackForwardList();
                int cur = l.getCurrentIndex();
                final String curKey = urlKey(web.getUrl());
                int t = cur - 1;
                // skip redirect pages and also earlier copies of the page we are on (an ad bounced us away and back to the same video page)
                while (t >= 0 && (isHopAt(l, t) || sameUrlAt(l, t, curKey))) t--;
                if (t < 0) {                          // everything before is a redirect page: it would only bounce forward again
                    homeByBack = true;
                    showHome(true);
                    return;
                }
                if (t < cur - 1) {
                    userStopped = false;
                    web.goBackOrForward(t - cur);
                    return;
                }
            } catch (Throwable ignored) {
            }
        }
        web.goBack();
    }

    // ---- incognito ----

    private WebView newWebView(String profile) {
        WebView w = new BgWebView(this);
        try {
            Class<?> ps = Class.forName("androidx.webkit.ProfileStore");
            Object store = ps.getMethod("getInstance").invoke(null);
            Object prof = ps.getMethod("getOrCreateProfile", String.class).invoke(store, profile);
            try {
                privCm = (CookieManager) Class.forName("androidx.webkit.Profile")
                        .getMethod("getCookieManager").invoke(prof);
            } catch (Throwable t) {
                privCm = null;
            }
            WebViewCompat.class.getMethod("setProfile", WebView.class, String.class).invoke(null, w, profile);
            return w;
        } catch (Throwable t) {
            privCm = null;
            try {
                w.destroy();
            } catch (Throwable ignored) {
            }
            return null;
        }
    }

    private void deleteProfile() {
        if (!profileOk) return;
        try {
            Class<?> ps = Class.forName("androidx.webkit.ProfileStore");
            Object store = ps.getMethod("getInstance").invoke(null);
            ps.getMethod("deleteProfile", String.class).invoke(store, "flb_private");
        } catch (Throwable ignored) {
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void applyWebSettings(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(desktop ? desktopUa : mobileUa);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        try {
            CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        } catch (Throwable ignored) {
        }
        try {
            if (WebViewFeature.isFeatureSupported("REQUESTED_WITH_HEADER_ALLOW_LIST")) {
                WebSettingsCompat.class.getMethod("setRequestedWithHeaderOriginAllowList",
                        WebSettings.class, Set.class).invoke(null, s, Collections.<String>emptySet());
            }
        } catch (Throwable ignored) {
        }
        w.addJavascriptInterface(new Bridge(), bridgeName);
    }

    private void parkWeb(WebView w) {
        try {
            w.evaluateJavascript("(function(){var l=document.querySelectorAll('video,audio');"
                    + "for(var i=0;i<l.length;i++){try{l[i].pause()}catch(e){}}})()", null);
            w.onPause();
        } catch (Throwable ignored) {
        }
    }

    private void applyIncogUi() {
        if (topBar == null) return;
        topBar.setBackgroundColor(incog ? 0xFF22222A : Color.WHITE);
        urlPill.setBackground(Ui.round(incog ? 0xFF3B3B46 : Ui.BG, dp(24)));
        urlBar.setTextColor(incog ? Color.WHITE : Ui.INK);
        urlBar.setHintTextColor(incog ? 0xFFB8B8C4 : Ui.SUB);
        urlBar.setHint(incog ? "\uD83D\uDD76 Incognito \u2014 search or enter URL" : "Search or enter URL");
        updateQualityBadge();
        updateStarBtn();
        applyBars();
    }

    private void setIncognito(boolean on) {
        if (on == incog) return;
        destroyFloat();                                 // the floating window belongs to the old (normal / private) profile
        final FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        userStopped = false;
        if (on) {
            deleteProfile();                              // leftovers of an older private session
            WebView pw = profileOk ? newWebView("flb_private") : null;
            if (pw != null) {
                parkWeb(web);
                webNormal = web;
                applyWebSettings(pw);
                pw.setWebViewClient(wvClient);
                pw.setWebChromeClient(wcClient);
                pw.setDownloadListener(dlListener);
                content.addView(pw, 0, lp);
                webNormal.setVisibility(View.GONE);
                web = pw;
                webPriv = pw;
                scriptHandlerNormal = scriptHandler;
                scriptHandler = null;
                applyUa();
                applyMode();
                mediaItems.clear();
                updateFab();
                loadingNow = false;
                updateReloadIc();
                showHome(true);
                say("Incognito chalu \uD83D\uDD76 naya private tab: history, cookies aur cache save nahi honge");
            } else {
                web.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
                say("Incognito (lite) chalu: history save nahi hogi. Is phone ka WebView alag private profile nahi deta, "
                        + "isliye login / cookies purane hi rahenge");
            }
            incog = true;
        } else {
            if (webPriv != null && webNormal != null) {
                WebView pw = webPriv;
                web = webNormal;
                webNormal = null;
                webPriv = null;
                web.setVisibility(View.VISIBLE);
                try {
                    web.onResume();
                } catch (Throwable ignored) {
                }
                content.removeView(pw);
                try {
                    pw.stopLoading();
                    pw.destroy();
                } catch (Throwable ignored) {
                }
                privCm = null;
                deleteProfile();
                scriptHandler = scriptHandlerNormal;
                scriptHandlerNormal = null;
                applyUa();
                applyMode();
                mediaItems.clear();
                updateFab();
                loadingNow = false;
                updateReloadIc();
                showHome(web.getUrl() == null);
            } else {
                web.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
                try {
                    web.clearCache(true);
                    web.clearFormData();
                    web.clearHistory();
                } catch (Throwable ignored) {
                }
            }
            incog = false;
            say("Incognito band, private data hat gaya");
        }
        applyIncogUi();
        updateChrome();
    }

    // ---------- popups (window.open): ads dropped, the real "get link" popup kept ----------

    private boolean capturePopup(Message m) {
        if (m == null || !(m.obj instanceof WebView.WebViewTransport)) return false;
        final WebView tmp = new WebView(this);
        tmp.setWebViewClient(new WebViewClient() {
            private volatile boolean done;

            private void got(final String url) {
                if (done || url == null || url.startsWith("about:") || url.startsWith("blob:")
                        || url.startsWith("data:") || url.startsWith("javascript:")) return;
                done = true;
                ui.post(() -> {
                    handlePopup(url);
                    try {
                        tmp.stopLoading();
                        tmp.destroy();
                    } catch (Exception ignored) {
                    }
                });
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                got(r.getUrl().toString());
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                got(url);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (r.isForMainFrame()) got(r.getUrl().toString());
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        ui.postDelayed(() -> {
            try {
                tmp.destroy();
            } catch (Exception ignored) {
            }
        }, 12000);
        WebView.WebViewTransport tr = (WebView.WebViewTransport) m.obj;
        tr.setWebView(tmp);
        m.sendToTarget();
        return true;
    }

    private void handlePopup(final String url) {
        if (userStopped) return;
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        flog("POPUP " + url);
        Uri u = Uri.parse(url);
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        if (h.isEmpty()) return;
        String curHost = hostOf(web.getUrl());
        if (adOn && (isAdUrl(u) || isSearchPage(u))) {
            showBar("Popup roka: " + h, "Open", () -> web.loadUrl(url));
            return;
        }
        boolean trusted = autoOn && SystemClock.uptimeMillis() < trustPopupUntil;
        boolean sameSite = rootHost(h).equals(rootHost(curHost));
        if (sameSite || trusted || hostIs(h, FILE_HOSTS) || hostIs(h, SHORT_HOSTS)) {
            web.loadUrl(url);
            return;
        }
        addRadar(url, "popup");
        showBar("Naya tab roka: " + h, "Open", () -> web.loadUrl(url));
    }

    private void addRadar(String url, String label) {
        radar.put(url, label);
        while (radar.size() > 30) {
            String first = radar.keySet().iterator().next();
            radar.remove(first);
        }
    }

    // ---------- bottom bar, menu, link radar ----------

    private void showBar(String msg, String action, final Runnable r) {
        if (action == null || r == null) {
            say(msg);
            return;
        }
        barMsg.setText(msg);
        barAct.setText(action);
        barAct.setVisibility(View.VISIBLE);
        barAct.setOnClickListener(v -> {
            barBox.setVisibility(View.GONE);
            r.run();
        });
        barBox.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideBar);
        ui.postDelayed(hideBar, 9000);
    }

    // toast-style message (dark rounded pill at the bottom); safe to call from any thread
    private void say(final String msg) {
        if (msg == null || msg.isEmpty()) return;
        runOnUiThread(() -> {
            pill.animate().cancel();
            ui.removeCallbacks(hidePill);
            pill.setText(msg);
            pill.setAlpha(0f);
            pill.setVisibility(View.VISIBLE);
            pill.animate().alpha(1f).setDuration(160).start();
            ui.postDelayed(hidePill, Math.min(6000, 2200 + 45L * msg.length()));
        });
    }

    // feedback after an automatic tap (not more than one line every 2.5 s)
    private void tapDone() {
        stepCount++;
        flog("TAP landed, step=" + stepCount);
        long now = SystemClock.uptimeMillis();
        if (now - lastTapMsgAt < 1800) return;
        lastTapMsgAt = now;
        say(TAP_LINES[(msgIdx++) % TAP_LINES.length].replace("#", String.valueOf(stepCount)));
    }

    private void flog(String line) {
        if (!flowActive && SystemClock.elapsedRealtime() > recUntil) return;
        synchronized (flogBuf) {
            long now = SystemClock.elapsedRealtime();
            if (flogBuf.isEmpty()) flogT0 = now;
            flogBuf.addLast(String.format(java.util.Locale.US, "[%5.1fs] ", (now - flogT0) / 1000.0) + line);
            while (flogBuf.size() > 300) flogBuf.removeFirst();
        }
    }

    private void logHostOnce(Uri u, boolean ad, boolean relax) {
        if (!flowActive && SystemClock.elapsedRealtime() > recUntil) return;
        String h = u.getHost();
        if (h == null) return;
        synchronized (flogBuf) {
            if (seenHosts.size() > 80 || !seenHosts.add(h)) return;
        }
        flog("REQ " + h + (ad ? (relax ? " [ad: allowed during flow]" : " [ad: blocked]") : ""));
    }

    private void startRecording() {
        synchronized (flogBuf) {
            flogBuf.clear();
            seenHosts.clear();
        }
        recUntil = SystemClock.elapsedRealtime() + 180000L;
    }

    private int flogSize() {
        synchronized (flogBuf) {
            return flogBuf.size();
        }
    }

    private void copyFlowLog() {
        StringBuilder sb = new StringBuilder();
        String wv = "?";
        try {
            android.content.pm.PackageInfo pi = WebView.getCurrentWebViewPackage();
            if (pi != null) wv = pi.versionName;
        } catch (Throwable ignored) {
        }
        sb.append("NixuBrowse v4.3 | speedMode=").append(speedMode).append(" auto=").append(autoOn)
                .append(" ads=").append(adOn).append(" type=").append(linkType)
                .append(" | webview=").append(wv).append(" | xrw=").append(xrwStatus).append(" | android=").append(Build.VERSION.SDK_INT).append("\n");
        synchronized (flogBuf) {
            for (String l : flogBuf) sb.append(l).append("\n");
        }
        try {
            ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cmb != null) cmb.setPrimaryClip(ClipData.newPlainText("flowlog", sb.toString()));
            say("Flow log copy ho gaya \uD83D\uDCDD (" + flogSize() + " lines), ab chat mein paste karo");
        } catch (Exception e) {
            say("Log copy nahi ho paaya");
        }
    }

    private void flowEnded() {
        flowActive = false;
        flowKind = 0;
        hops = 0;
        flowOrigin = null;
        applyMode();
        updateReloadIc();
    }

    private void saveKey(String key, String host) {
        try {
            JSONArray old = new JSONArray(prefs.getString("keys", "[]"));
            JSONArray out = new JSONArray();
            JSONObject nj = new JSONObject();
            nj.put("k", key);
            nj.put("h", host == null ? "" : host);
            nj.put("t", System.currentTimeMillis());
            out.put(nj);
            for (int k = 0; k < old.length() && out.length() < 20; k++) {
                JSONObject o = old.getJSONObject(k);
                if (key.equals(o.optString("k"))) continue;
                out.put(o);
            }
            prefs.edit().putString("keys", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private int keyCount() {
        try {
            return new JSONArray(prefs.getString("keys", "[]")).length();
        } catch (Exception e) {
            return 0;
        }
    }

    // ====================================================================== v5: pill UI, sheets, downloads, sound

    private static final String[] LIGHT_HOSTS = {"youtube.com", "youtu.be", "googlevideo.com", "ytimg.com",
            "instagram.com", "facebook.com", "fb.com", "twitter.com", "x.com", "whatsapp.com", "telegram.org",
            "spotify.com", "soundcloud.com", "jiosaavn.com", "gaana.com", "wynk.in", "netflix.com",
            "primevideo.com", "hotstar.com", "reddit.com", "wikipedia.org", "github.com", "linkedin.com",
            MusicHost.HOST};

    private boolean isLightHost(String h) {
        return hostIs(h, LIGHT_HOSTS);
    }

    private FrameLayout rootFrame, content, navHomeCell, navDlCell;
    private Ui.Sheet sheet;
    private Ui.Fab fab;
    private View navBox, homeView, strip, stripFill, stripRest;
    private LinearLayout urlPill, homeGrid;
    private ImageView reloadIc, stripPause;
    private ImageView starBtn;                       // favourite-site star next to the video quality badge
    private FrameLayout floatBox;
    private WebView floatWeb;
    private TextView floatTitle, floatBigTv;
    private ProgressBar floatProg;
    private boolean floatBig, floatHooked;
    private int floatX, floatY, floatW, floatH;
    private int[] floatSaved;
    private String floatLoaded;
    private String favName = "", favUrl = "";
    private TextView navBadge, stripName, stripInfo;
    private DownloadCenter dc;
    private DownloadCenter.Task stripTask, stripShown;
    private final LinkedHashMap<String, String[]> mediaItems = new LinkedHashMap<>();
    private final ArrayList<String[]> homeSites = new ArrayList<>();
    private int boostPct = 100, maxRootH;
    private static final int BOOST_MAX = 500, BOOST_MAX_NO_BT = 250;   // 500% only while a Bluetooth output is connected
    private boolean btOut;
    private AudioDeviceCallback audioCb;
    private boolean limOn = true, bgOn = true, fabOn = true;
    private int hallLvl = 0;                       // 16D Hall: 0 off, 1 Halka, 2 Medium, 3 Concert
    private boolean driftOn = true;                // slow drift of the reverb only (the dry sound never moves)
    private boolean homeShown, homeByBack, kbOpen, loadingNow, playingNow, boostSkipped, intentDlgOpen;
    private long lastIntentAt;
    private String lastIntentUrl;
    private String bridgeJs = "", mediaJs = "", igJs = "";

    private static class DlRow {
        LinearLayout card;
        TextView name, info, b1, b2, b3;
        View fill, rest;
    }

    private final HashMap<Integer, DlRow> dlRows = new HashMap<>();
    private final ArrayList<Integer> dlOrder = new ArrayList<>();
    private LinearLayout dlList;

    private void applyBars() {
        getWindow().setStatusBarColor(incog ? 0xFF22222A : Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(incog
                ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));
    }

    private FrameLayout navItem(LinearLayout row, int kind, View.OnClickListener l) {
        FrameLayout cell = new FrameLayout(this);
        ImageView iv = Ui.icon(this, kind, Ui.INK);
        cell.addView(iv, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        cell.setOnClickListener(l);
        Ui.press(cell);
        cell.setTag(iv);
        row.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        return cell;
    }

    private void buildUi() {
        final int MP = ViewGroup.LayoutParams.MATCH_PARENT, WC = ViewGroup.LayoutParams.WRAP_CONTENT;
        boostPct = prefs.getInt("boost", 100);
        limOn = prefs.getBoolean("lim", true);
        hallLvl = Math.max(0, Math.min(3, prefs.getInt("hall", 0)));
        driftOn = prefs.getBoolean("drift", true);
        bgOn = prefs.getBoolean("bg", true);
        BgWebView.allow = bgOn;
        fabOn = prefs.getBoolean("fab", true);
        applyBars();
        navHideRun = () -> {
            if (!navPeek) return;
            if (sheet != null && sheet.isShowing()) {
                ui.postDelayed(navHideRun, 4000);
                return;
            }
            navPeek = false;
            updateChrome();
        };

        rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        rootFrame.addView(root, new FrameLayout.LayoutParams(MP, MP));

        // ---- top: pill url / search field
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setBackgroundColor(Color.WHITE);
        top.setPadding(dp(12), dp(8), dp(12), dp(8));
        urlPill = new LinearLayout(this);
        urlPill.setOrientation(LinearLayout.HORIZONTAL);
        urlPill.setGravity(Gravity.CENTER_VERTICAL);
        urlPill.setBackground(Ui.round(Ui.BG, dp(24)));
        urlPill.setPadding(dp(14), 0, dp(6), 0);
        urlLead = Ui.icon(this, Ic.SEARCH, Ui.SUB);
        urlLead.setPadding(dp(5), dp(5), dp(5), dp(5));
        urlLead.setOnClickListener(v -> {
            if (leadBack) navBack();
        });
        urlPill.addView(urlLead, new LinearLayout.LayoutParams(dp(30), dp(30)));
        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setHint("Search or enter URL");
        urlBar.setHintTextColor(Ui.SUB);
        urlBar.setTextColor(Ui.INK);
        urlBar.setTextSize(15);
        urlBar.setBackground(null);
        urlBar.setPadding(dp(10), 0, dp(6), 0);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                return true;
            }
            return false;
        });
        urlPill.addView(urlBar, new LinearLayout.LayoutParams(0, MP, 1f));
        reloadIc = Ui.icon(this, Ic.REFRESH, Ui.SUB);
        reloadIc.setPadding(dp(9), dp(9), dp(9), dp(9));
        reloadIc.setOnClickListener(v -> {
            if (loadingNow || flowActive) {
                stopPage();
            } else if (!homeShown) {
                userStopped = false;
                web.reload();
            }
        });
        starBtn = new ImageView(this);
        starBtn.setScaleType(ImageView.ScaleType.FIT_CENTER);
        starBtn.setPadding(dp(7), dp(7), dp(7), dp(7));
        starBtn.setOnClickListener(v -> {
            if (favUrl.isEmpty()) showFavPicker();
            else toggleFloat();
        });
        starBtn.setOnLongClickListener(v -> {
            showFavPicker();
            return true;
        });
        urlPill.addView(starBtn, new LinearLayout.LayoutParams(dp(36), dp(36)));
        updateStarBtn();
        qBadge = Ui.label(this, "Auto", 11.5f, Ui.INK, true);
        qBadge.setGravity(Gravity.CENTER);
        qBadge.setSingleLine(true);
        qBadge.setPadding(dp(9), dp(4), dp(9), dp(4));
        qBadge.setOnClickListener(v -> {
            if (igNow) showInstaPanel();
            else showQualitySheet();
        });
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(WC, WC);
        qlp.setMargins(dp(4), 0, dp(2), 0);
        urlPill.addView(qBadge, qlp);
        updateQualityBadge();
        urlPill.addView(reloadIc, new LinearLayout.LayoutParams(dp(40), dp(40)));
        top.addView(urlPill, new LinearLayout.LayoutParams(MP, dp(46)));
        root.addView(top);
        topBar = top;

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        root.addView(progress, new LinearLayout.LayoutParams(MP, dp(3)));

        // ---- content: web + home + floating things
        content = new FrameLayout(this);
        web = new BgWebView(this);
        content.addView(web, new FrameLayout.LayoutParams(MP, MP));
        buildHome();
        content.addView(homeView, new FrameLayout.LayoutParams(MP, MP));

        fab = new Ui.Fab(this);
        fab.setOnClickListener(v -> {
            if (igNow) openInstaSheet();
            else showMediaSheet();
        });
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM | Gravity.END);
        flp.setMargins(0, 0, dp(16), dp(92));
        content.addView(fab, flp);
        // small tab above the download button: brings the bottom bar back (the bar hides itself while a site is open)
        navHandle = new ImageView(this);
        navHandle.setImageDrawable(new Ic(Ic.UP, Color.WHITE));
        navHandle.setBackground(Ui.round(Color.argb(215, 28, 30, 36), dp(12)));
        navHandle.setPadding(dp(11), dp(3), dp(11), dp(3));
        navHandle.setElevation(dp(6));
        navHandle.setOnClickListener(v -> toggleNavPeek());
        navHandle.setVisibility(View.GONE);
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(dp(40), dp(24), Gravity.BOTTOM | Gravity.END);
        hlp.setMargins(0, 0, dp(25), dp(92 + 58 + 6));
        content.addView(navHandle, hlp);
        fab.onMoved = this::syncHandle;

        // download strip (top): name, speed, progress, pause / cancel
        LinearLayout st = new LinearLayout(this) {
            private float ix, iy;

            @Override
            public boolean onInterceptTouchEvent(MotionEvent e) {
                // a sideways drag that starts on the pause / cancel buttons must also swipe the strip away
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    ix = e.getRawX();
                    iy = e.getRawY();
                } else if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    float dx = e.getRawX() - ix, dy = e.getRawY() - iy;
                    if (Math.abs(dx) > dp(12) && Math.abs(dx) > Math.abs(dy) * 1.5f) return true;
                }
                return false;
            }
        };
        st.setOrientation(LinearLayout.VERTICAL);
        st.setBackground(Ui.round(Color.argb(244, 28, 30, 36), dp(22)));
        st.setElevation(dp(8));
        st.setPadding(dp(16), dp(10), dp(8), dp(12));
        LinearLayout srow = new LinearLayout(this);
        srow.setOrientation(LinearLayout.HORIZONTAL);
        srow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout stxt = new LinearLayout(this);
        stxt.setOrientation(LinearLayout.VERTICAL);
        stripName = Ui.label(this, "", 13.5f, Color.WHITE, true);
        stripName.setSingleLine(true);
        stripName.setEllipsize(TextUtils.TruncateAt.END);
        stripInfo = Ui.label(this, "", 12, 0xFFB0B0B8, false);
        stripInfo.setSingleLine(true);
        stxt.addView(stripName);
        stxt.addView(stripInfo);
        srow.addView(stxt, new LinearLayout.LayoutParams(0, WC, 1f));
        stripPause = Ui.icon(this, Ic.PAUSE, Color.WHITE);
        stripPause.setPadding(dp(9), dp(9), dp(9), dp(9));
        stripPause.setOnClickListener(v -> {
            DownloadCenter.Task t = stripShown;
            if (t == null) return;
            if (t.state == DownloadCenter.RUNNING || t.state == DownloadCenter.QUEUED) dc.pause(t);
            else {
                stripTask = t;
                dc.resume(t);
            }
        });
        srow.addView(stripPause, new LinearLayout.LayoutParams(dp(38), dp(38)));
        ImageView stripX = Ui.icon(this, Ic.CLOSE, Color.WHITE);
        stripX.setPadding(dp(9), dp(9), dp(9), dp(9));
        stripX.setOnClickListener(v -> {
            DownloadCenter.Task t = stripShown;
            if (t != null) {
                dc.cancel(t);
                say("Download cancel ho gaya");
            }
        });
        srow.addView(stripX, new LinearLayout.LayoutParams(dp(38), dp(38)));
        st.addView(srow);
        LinearLayout track = new LinearLayout(this);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setBackground(Ui.round(0x33FFFFFF, dp(3)));
        stripFill = new View(this);
        stripFill.setBackground(Ui.round(Ui.ACCENT, dp(3)));
        stripRest = new View(this);
        track.addView(stripFill, new LinearLayout.LayoutParams(0, MP, 0f));
        track.addView(stripRest, new LinearLayout.LayoutParams(0, MP, 100f));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(MP, dp(5));
        tlp.setMargins(0, dp(8), dp(8), 0);
        st.addView(track, tlp);
        st.setOnClickListener(v -> showDownloads());
        st.setVisibility(View.GONE);
        strip = st;
        st.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private boolean drag, have;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        drag = false;
                        have = true;
                        return false;
                    case MotionEvent.ACTION_MOVE: {
                        if (!have) {                  // the strip took over from a button: the drag has already started
                            have = true;
                            downX = e.getRawX();
                            downY = e.getRawY();
                            drag = true;
                        }
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (!drag && Math.abs(dx) > dp(12) && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                            drag = true;
                            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                        }
                        if (drag) {
                            v.setTranslationX(dx);
                            v.setAlpha(Math.max(0.15f, 1f - Math.abs(dx) / (v.getWidth() * 0.9f)));
                            return true;
                        }
                        return false;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        have = false;
                        if (!drag) return false;
                        float dx = e.getRawX() - downX;
                        drag = false;
                        if (Math.abs(dx) > v.getWidth() * 0.22f) {
                            final View sv = v;
                            sv.animate().translationX(dx > 0 ? sv.getWidth() : -sv.getWidth()).alpha(0f).setDuration(160)
                                    .withEndAction(() -> {
                                        if (stripShown != null) stripHiddenId = stripShown.id;
                                        sv.setVisibility(View.GONE);
                                        sv.setTranslationX(0f);
                                        sv.setAlpha(1f);
                                    }).start();
                        } else {
                            v.animate().translationX(0f).alpha(1f).setDuration(160).start();
                        }
                        return true;
                    }
                    default:
                        return false;
                }
            }
        });
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(MP, WC, Gravity.TOP);
        slp.setMargins(dp(12), dp(6), dp(12), 0);
        content.addView(st, slp);

        // bottom info bar (blocked redirect, hints, "Allow"/"Open" actions)
        barBox = new LinearLayout(this);
        barBox.setOrientation(LinearLayout.HORIZONTAL);
        barBox.setGravity(Gravity.CENTER_VERTICAL);
        barBox.setPadding(dp(16), dp(10), dp(16), dp(10));
        barBox.setBackground(Ui.round(Color.argb(240, 28, 30, 36), dp(22)));
        barBox.setElevation(dp(8));
        barMsg = new TextView(this);
        barMsg.setTextColor(Color.WHITE);
        barMsg.setTextSize(13);
        barBox.addView(barMsg, new LinearLayout.LayoutParams(0, WC, 1f));
        barAct = new TextView(this);
        barAct.setTextColor(Color.rgb(120, 190, 255));
        barAct.setTextSize(14);
        barAct.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        barAct.setPadding(dp(14), dp(4), dp(4), dp(4));
        barBox.addView(barAct);
        barBox.setVisibility(View.GONE);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(MP, WC, Gravity.BOTTOM);
        blp.setMargins(dp(14), 0, dp(14), dp(86));
        content.addView(barBox, blp);
        hideBar = () -> barBox.setVisibility(View.GONE);

        // toast-style pill
        pill = new TextView(this);
        pill.setTextColor(Color.WHITE);
        pill.setTextSize(14.5f);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxWidth(getResources().getDisplayMetrics().widthPixels - dp(40));
        pill.setPadding(dp(20), dp(12), dp(20), dp(12));
        pill.setBackground(Ui.round(Color.argb(242, 28, 30, 36), dp(24)));
        pill.setElevation(dp(12));
        pill.setVisibility(View.GONE);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(WC, WC,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        plp.setMargins(dp(20), 0, dp(20), dp(92));
        content.addView(pill, plp);

        // Instagram data counter (small pill, drag it anywhere, the arrow resets it)
        dataPill = new LinearLayout(this);
        dataPill.setOrientation(LinearLayout.HORIZONTAL);
        dataPill.setGravity(Gravity.CENTER_VERTICAL);
        dataPill.setBackground(Ui.round(Color.argb(215, 28, 30, 36), dp(14)));
        dataPill.setElevation(dp(6));
        dataTv = Ui.label(this, "IG 0 B", 11.5f, Color.WHITE, true);
        dataTv.setPadding(dp(10), dp(4), dp(4), dp(4));
        dataPill.addView(dataTv);
        ImageView dataReset = Ui.icon(this, Ic.REFRESH, Color.WHITE);
        dataReset.setPadding(dp(4), dp(4), dp(6), dp(4));
        dataReset.setOnClickListener(v -> {
            igBytes = 0;
            igLastRx = rxBytes();
            updateDataPill();
            say("Instagram data counter zero ho gaya");
        });
        dataPill.addView(dataReset, new LinearLayout.LayoutParams(dp(26), dp(26)));
        dataPill.setVisibility(View.GONE);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.START);
        dlp.setMargins(dp(12), 0, 0, dp(92));
        content.addView(dataPill, dlp);
        makeDraggable(dataTv, dataPill);
        hidePill = () -> pill.animate().alpha(0f).setDuration(220)
                .withEndAction(() -> pill.setVisibility(View.GONE)).start();

        // ---- bottom floating pill navigation (Home / Back / Downloads / Sound / Menu)
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setBackground(Ui.stroked(Color.argb(248, 255, 255, 255), dp(30), Ui.LINE, 1));
        nav.setElevation(dp(10));
        navHomeCell = navItem(nav, Ic.HOME, v -> {
            homeByBack = false;
            showHome(true);
        });
        navInstaCell = navItem(nav, Ic.INSTA, v -> showInstaPanel());
        navDlCell = navItem(nav, Ic.DOWNLOAD, v -> showDownloads());
        navBadge = Ui.label(this, "", 10, Color.WHITE, true);
        navBadge.setGravity(Gravity.CENTER);
        navBadge.setBackground(Ui.oval(Ui.RED));
        navBadge.setVisibility(View.GONE);
        FrameLayout.LayoutParams nbp = new FrameLayout.LayoutParams(dp(17), dp(17), Gravity.TOP | Gravity.END);
        nbp.setMargins(0, dp(10), dp(20), 0);
        navDlCell.addView(navBadge, nbp);
        navItem(nav, Ic.SOUND, v -> showSound());
        navItem(nav, Ic.MENU, v -> showMenu());
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(MP, dp(60), Gravity.BOTTOM);
        nlp.setMargins(dp(18), 0, dp(18), dp(12));
        content.addView(nav, nlp);
        navBox = nav;

        root.addView(content, new LinearLayout.LayoutParams(MP, 0, 1f));
        sheet = new Ui.Sheet(this, rootFrame);
        setContentView(rootFrame);

        // keyboard open -> hide the floating things
        rootFrame.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            int h = rootFrame.getHeight();
            if (h > maxRootH) maxRootH = h;
            boolean kb = maxRootH > 0 && h < maxRootH * 0.8f;
            if (kb != kbOpen) {
                kbOpen = kb;
                updateChrome();
            }
        });

        dc = DownloadCenter.get(this);
        dc.setListener(new DownloadCenter.Listener() {
            @Override
            public void changed() {
                updateStrip();
                updateFab();
                updateNav();
                renderDownloads();
            }

            @Override
            public void finished(DownloadCenter.Task t) {
                onDownloadDone(t);
            }

            @Override
            public void failed(DownloadCenter.Task t) {
                say("Download fail: " + (t.err == null ? "kuch gadbad" : t.err));
            }
        });
        MediaService.controller = cmd -> ui.post(() -> {
            userPaused = "pause".equals(cmd) || ("toggle".equals(cmd) && playingNow);
            if (userPaused) jsCall("g", "false");
            if (web != null) {
                web.evaluateJavascript("(function(){var f=window['" + bridgeName + "m'];return f?f('"
                        + cmd + "'):-1})()", null);
            }
        });
        updateNav();
        updateFab();
        updateChrome();
    }

    private void updateChrome() {
        boolean hide = kbOpen || landFs;
        // v5.9: while a site is open the bottom bar hides itself; the small tab above the download button brings it back
        boolean navShow = !hide && (homeShown || onPlayer || !navAuto || navPeek);
        if (navBox != null) navBox.setVisibility(navShow ? View.VISIBLE : View.GONE);
        if (fab != null) fab.setVisibility(hide || homeShown || !fabOn || onPlayer ? View.GONE : View.VISIBLE);
        if (navHandle != null) {
            boolean hv = !hide && navAuto && !homeShown && !onPlayer && fsView == null;
            navHandle.setVisibility(hv ? View.VISIBLE : View.GONE);
            navHandle.setImageDrawable(new Ic(navPeek ? Ic.DOWN : Ic.UP, Color.WHITE));
        }
        layoutFloating(navShow);
        updateDataPill();
        updateLead();
    }

    private void updateNav() {
        if (navHomeCell != null) {
            ((ImageView) navHomeCell.getTag()).setImageDrawable(new Ic(Ic.HOME, homeShown ? Ui.ACCENT : Ui.INK));
        }
        if (navInstaCell != null) {
            ((ImageView) navInstaCell.getTag()).setImageDrawable(new Ic(Ic.INSTA, igNow && igLite ? Ui.ACCENT : Ui.INK));
        }
        if (navBadge != null && dc != null) {
            int n = dc.activeCount();
            navBadge.setText(String.valueOf(n));
            navBadge.setVisibility(n > 0 ? View.VISIBLE : View.GONE);
        }
    }

    private void updateFab() {
        if (fab == null || dc == null) return;
        fab.setState(!mediaItems.isEmpty() || (igNow && !igTargetCode.isEmpty()), mediaItems.size(), dc.overall());
    }

    private static String two(long v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    private static String fmtEta(long sec) {
        if (sec < 0) return "";
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        return h > 0 ? h + ":" + two(m) + ":" + two(s) : m + ":" + two(s);
    }

    private static void setW(View v, float w) {
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) v.getLayoutParams();
        if (lp.weight != w) {
            lp.weight = w;
            v.setLayoutParams(lp);
        }
    }

    private String infoLine(DownloadCenter.Task t) {
        String sz = t.total > 0 ? fmtSize(t.done) + " / " + fmtSize(t.total) : fmtSize(t.done);
        switch (t.state) {
            case DownloadCenter.RUNNING: {
                if (t.note != null) return t.note;
                String s = sz;
                if (t.speed > 0) {
                    s += "  \u2022  " + fmtSize(t.speed) + "/s";
                    if (t.total > t.done) s += "  \u2022  " + fmtEta((t.total - t.done) / Math.max(1, t.speed)) + " left";
                }
                return s;
            }
            case DownloadCenter.QUEUED:
                return "Line mein...";
            case DownloadCenter.PAUSED:
                return "Paused  \u2022  " + sz;
            case DownloadCenter.DONE:
                return "Complete  \u2022  " + fmtSize(Math.max(t.total, t.done));
            case DownloadCenter.FAILED:
                return "Fail: " + (t.err == null ? "" : t.err);
            default:
                return "";
        }
    }

    private void updateStrip() {
        if (strip == null || dc == null) return;
        DownloadCenter.Task pick = null;
        if (stripTask != null && (stripTask.state == DownloadCenter.RUNNING
                || stripTask.state == DownloadCenter.QUEUED || stripTask.state == DownloadCenter.PAUSED)) {
            pick = stripTask;
        } else {
            for (DownloadCenter.Task t : dc.list()) {
                if (t.state == DownloadCenter.RUNNING || t.state == DownloadCenter.QUEUED) {
                    pick = t;
                    break;
                }
            }
        }
        stripShown = pick;
        if (pick == null) stripHiddenId = -1;
        if (pick == null || landFs || fsView != null || pick.id == stripHiddenId) {
            strip.setVisibility(View.GONE);
            return;
        }
        strip.setVisibility(View.VISIBLE);
        stripName.setText(pick.name == null ? "" : pick.name);
        stripInfo.setText(infoLine(pick));
        int pct = pick.total > 0 ? (int) Math.min(100, pick.done * 100 / pick.total) : 0;
        setW(stripFill, pct);
        setW(stripRest, 100 - pct);
        boolean running = pick.state == DownloadCenter.RUNNING || pick.state == DownloadCenter.QUEUED;
        stripPause.setImageDrawable(new Ic(running ? Ic.PAUSE : Ic.PLAY, Color.WHITE));
    }

    // ---------------------------------------------------------------- home page (favourites)

    private void loadHome() {
        homeSites.clear();
        String raw = prefs.getString("home_sites", null);
        if (raw == null) {
            homeSites.add(new String[]{"YouTube", "https://m.youtube.com"});
            return;
        }
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                homeSites.add(new String[]{o.optString("n"), o.optString("u")});
            }
        } catch (Exception ignored) {
        }
    }

    private void saveHome() {
        try {
            JSONArray a = new JSONArray();
            for (String[] s : homeSites) {
                JSONObject o = new JSONObject();
                o.put("n", s[0]);
                o.put("u", s[1]);
                a.put(o);
            }
            prefs.edit().putString("home_sites", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void buildHome() {
        loadHome();
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.WHITE);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(34), dp(18), dp(120));
        TextView title = Ui.label(this, "Nixu Browse", 32, Ui.INK, true);
        TextView sub = Ui.label(this, "Fast. Clean. Ad-free.", 14, Ui.SUB, false);
        sub.setPadding(0, dp(2), 0, dp(22));
        col.addView(title);
        col.addView(sub);
        LinearLayout sp = new LinearLayout(this);
        sp.setOrientation(LinearLayout.HORIZONTAL);
        sp.setGravity(Gravity.CENTER_VERTICAL);
        sp.setBackground(Ui.round(Ui.BG, dp(26)));
        sp.setPadding(dp(18), 0, dp(18), 0);
        sp.addView(Ui.icon(this, Ic.SEARCH, Ui.SUB), new LinearLayout.LayoutParams(dp(20), dp(20)));
        TextView sh = Ui.label(this, "Search or enter URL", 15, Ui.SUB, false);
        sh.setPadding(dp(12), 0, 0, 0);
        sp.addView(sh);
        sp.setOnClickListener(v -> {
            urlBar.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(urlBar, 0);
        });
        Ui.press(sp);
        col.addView(sp, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        TextView music = Ui.label(this, "\u266B  Music player  \u2022  500% tak awaaz", 15, Ui.ACCENT, true);
        music.setBackground(Ui.round(0x1A0A84FF, dp(26)));
        music.setGravity(Gravity.CENTER_VERTICAL);
        music.setPadding(dp(18), 0, dp(18), 0);
        music.setOnClickListener(v -> openMusicPlayer());
        Ui.press(music);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        mlp.topMargin = dp(12);
        col.addView(music, mlp);
        TextView fav = Ui.section(this, "Favourites");
        fav.setPadding(dp(2), dp(26), 0, dp(10));
        col.addView(fav);
        homeGrid = new LinearLayout(this);
        homeGrid.setOrientation(LinearLayout.VERTICAL);
        col.addView(homeGrid);
        sv.addView(col);
        homeView = sv;
        refreshHome();
    }

    private static final int[] TILE_COLORS = {0xFF0A84FF, 0xFF34C759, 0xFFFF9F0A, 0xFFAF52DE, 0xFFFF375F, 0xFF30B0C7};

    private void refreshHome() {
        homeGrid.removeAllViews();
        int tileW = (getResources().getDisplayMetrics().widthPixels - dp(36)) / 4;
        Ui.Flow flow = new Ui.Flow(this, 0);
        flow.addView(instaTile(), new ViewGroup.LayoutParams(tileW, ViewGroup.LayoutParams.WRAP_CONTENT));
        for (int i = 0; i < homeSites.size(); i++) {
            flow.addView(homeTile(i, tileW), new ViewGroup.LayoutParams(tileW, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        flow.addView(plusTile(), new ViewGroup.LayoutParams(tileW, ViewGroup.LayoutParams.WRAP_CONTENT));
        homeGrid.addView(flow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private View tileBox(View inner, String label) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(dp(4), dp(8), dp(4), dp(8));
        t.addView(inner, new LinearLayout.LayoutParams(dp(60), dp(60)));
        TextView l = Ui.label(this, label, 12, Ui.INK, false);
        l.setSingleLine(true);
        l.setEllipsize(TextUtils.TruncateAt.END);
        l.setGravity(Gravity.CENTER);
        l.setPadding(0, dp(6), 0, 0);
        t.addView(l, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        Ui.press(t);
        return t;
    }

    private View homeTile(final int idx, int tileW) {
        final String[] s = homeSites.get(idx);
        boolean yt = hostIs(hostOf(s[1]), "youtube.com", "youtu.be");
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(Ui.round(yt ? 0xFFFF0033 : TILE_COLORS[Math.abs(s[0].hashCode()) % TILE_COLORS.length],
                dp(18)));
        if (yt) {
            badge.addView(Ui.icon(this, Ic.PLAY, Color.WHITE), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        } else {
            TextView lt = Ui.label(this, s[0].isEmpty() ? "?" : s[0].substring(0, 1).toUpperCase(), 26, Color.WHITE, true);
            lt.setGravity(Gravity.CENTER);
            badge.addView(lt, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
        View t = tileBox(badge, s[0]);
        t.setOnClickListener(v -> go(s[1]));
        t.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this).setTitle(s[0]).setItems(new String[]{"Edit", "Star (floating) banao", "Hatao"}, (d, which) -> {
                if (which == 0) {
                    editHomeSite(idx);
                } else if (which == 1) {
                    setFav(s[0], s[1], true);
                } else {
                    homeSites.remove(idx);
                    saveHome();
                    refreshHome();
                }
            }).show();
            return true;
        });
        return t;
    }

    private View plusTile() {
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(Ui.round(Ui.BG, dp(18)));
        badge.addView(Ui.icon(this, Ic.PLUS, Ui.SUB), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        View t = tileBox(badge, "Add");
        t.setOnClickListener(v -> editHomeSite(-1));
        return t;
    }

    private static String normalizeUrl(String in) {
        String s = in == null ? "" : in.trim();
        if (s.isEmpty() || s.contains(" ")) return null;
        if (s.startsWith("http://") || s.startsWith("https://")) return s;
        return s.contains(".") ? "https://" + s : null;
    }

    private void editHomeSite(final int idx) {
        final EditText n = new EditText(this);
        n.setHint("Name (jaise YouTube)");
        final EditText u = new EditText(this);
        u.setHint("Site link (youtube.com)");
        u.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        if (idx >= 0) {
            n.setText(homeSites.get(idx)[0]);
            u.setText(homeSites.get(idx)[1]);
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), 0);
        box.addView(n);
        box.addView(u);
        new AlertDialog.Builder(this).setTitle(idx >= 0 ? "Favourite edit karo" : "Favourite site jodo")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    String url = normalizeUrl(u.getText().toString());
                    if (url == null) {
                        say("Sahi link daalo (jaise youtube.com)");
                        return;
                    }
                    String nm = n.getText().toString().trim();
                    if (nm.isEmpty()) nm = hostOf(url).replaceFirst("^www\\.", "");
                    if (idx >= 0) homeSites.set(idx, new String[]{nm, url});
                    else homeSites.add(new String[]{nm, url});
                    saveHome();
                    refreshHome();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showHome(boolean on) {
        homeShown = on;
        if (homeView != null) homeView.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) {
            urlBar.setText("");
            urlBar.clearFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        } else if (web != null && web.getUrl() != null) {
            urlBar.setText(MusicHost.isPlayerUrl(web.getUrl()) ? "Music player" : web.getUrl());
        }
        updateNav();
        updateChrome();
    }

    private void navBack() {
        if (homeShown) {
            if (web.getUrl() != null) showHome(false);
            return;
        }
        if (web.canGoBack()) backSmart();
        else {
            homeByBack = true;
            showHome(true);
        }
    }

    // ---------------------------------------------------------------- menu (chips in a bottom sheet)

    private Ui.Flow chipFlow() {
        Ui.Flow f = new Ui.Flow(this, dp(8));
        f.setPadding(dp(16), 0, dp(16), 0);
        return f;
    }

    private void addChip(Ui.Flow f, String label, boolean active, final Runnable r) {
        TextView c = Ui.chip(this, label, active);
        c.setOnClickListener(v -> {
            sheet.hide();
            r.run();
        });
        f.addView(c, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void showMenu() {
        final String cur = web.getUrl();
        final String root = rootHost(hostOf(cur));
        final boolean slow = slowHosts.contains(root);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(22));

        col.addView(Ui.section(this, "Quick"));
        Ui.Flow q = chipFlow();
        addChip(q, speedMode == 0 ? "Speed OFF" : speedMode == 1 ? "Smart speed" : "Turbo", speedMode > 0, () -> {
            speedMode = (speedMode + 1) % 3;
            prefs.edit().putInt("speedMode", speedMode).apply();
            changed(MODE_DONE[speedMode]);
        });
        addChip(q, "Auto-click", autoOn, () -> {
            autoOn = !autoOn;
            prefs.edit().putBoolean("auto", autoOn).apply();
            changed(autoOn ? "Auto-click chalu ho gaya" : "Auto-click band ho gaya");
        });
        addChip(q, "Ad block", adOn, () -> {
            adOn = !adOn;
            prefs.edit().putBoolean("ads", adOn).apply();
            changed(adOn ? "Ad block chalu ho gaya" : "Ad block band ho gaya");
        });
        addChip(q, "Desktop site", desktop, () -> {
            desktop = !desktop;
            applyUa();
            say(desktop ? "Desktop site chalu ho gayi" : "Mobile site wapas aa gayi");
            web.reload();
        });
        addChip(q, manualLand ? "Rotate: Landscape" : "Rotate screen", manualLand, this::toggleRotate);
        addChip(q, "Background play", bgOn, () -> {
            bgOn = !bgOn;
            prefs.edit().putBoolean("bg", bgOn).apply();
            BgWebView.allow = bgOn;
            if (!bgOn) jsCall("g", "false");
            changed(bgOn ? "Background play chalu (lock screen par bhi chalega)" : "Background play band");
        });
        addChip(q, "Battery fix", false, this::openBatterySettings);
        addChip(q, "Music player", MusicHost.isPlayerUrl(cur), this::openMusicPlayer);
        addChip(q, "Floating download", fabOn, () -> {
            fabOn = !fabOn;
            prefs.edit().putBoolean("fab", fabOn).apply();
            updateChrome();
            say(fabOn ? "Download button wapas aa gaya" : "Download button chhup gaya");
        });
        col.addView(q);

        col.addView(Ui.section(this, "Data saver & privacy"));
        Ui.Flow sx = chipFlow();
        addToggle(sx, "Data saver", saverOn, () -> {
            saverOn = !saverOn;
            prefs.edit().putBoolean("saver", saverOn).apply();
            applyMode();
            pushCfg();
            say(saverOn ? "Data saver chalu \uD83D\uDCC9 (fonts, GIF aur auto-preview video band)" : "Data saver band");
        }, () -> saverOn);
        addToggle(sx, "Video focus", focusOn, () -> {
            focusOn = !focusOn;
            prefs.edit().putBoolean("focus", focusOn).apply();
            focusStalled = false;
            updateFocus();
            say(focusOn ? "Video focus chalu \uD83C\uDFAC jab video chalegi tab baaki sab ko data band"
                    : "Video focus band");
        }, () -> focusOn);
        addToggle(sx, "Images band", imgOff, () -> {
            imgOff = !imgOff;
            prefs.edit().putBoolean("imgoff", imgOff).apply();
            applyMode();
            pushCfg();
            say(imgOff ? "Images band, ab photos load nahi hongi" : "Images wapas chalu");
        }, () -> imgOff);
        addToggle(sx, "Clean back", cleanBackOn || incog, () -> {
            cleanBackOn = !cleanBackOn;
            prefs.edit().putBoolean("cleanback", cleanBackOn).apply();
            say(incog ? "Incognito mein Clean back hamesha chalu rehta hai"
                    : cleanBackOn ? "Clean back chalu: Back dabane par redirect wali sites skip hongi"
                    : "Clean back band");
        }, () -> cleanBackOn || incog);
        final TextView qchip = Ui.chip(this, vqCap == 0 ? "Video quality: Auto" : "Video quality: " + vqCap + "p", vqCap > 0);
        qchip.setOnClickListener(x -> showQualitySheet());
        sx.addView(qchip, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        final TextView fchip = Ui.chip(this, favUrl.isEmpty() ? "Star site: set karo" : "Star site: " + favName, !favUrl.isEmpty());
        fchip.setOnClickListener(x -> showFavPicker());
        sx.addView(fchip, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        addChip(sx, "Incognito", incog, () -> setIncognito(!incog));
        final TextView dchip = Ui.chip(this, "Data used: " + fmtData(rxBytes() - dataBase), false);
        dchip.setOnClickListener(x -> {
            dchip.setText("Data used: " + fmtData(rxBytes() - dataBase));
            say("App shuru hone se ab tak itna data laga (lamba dabao = zero karo)");
        });
        dchip.setOnLongClickListener(x -> {
            dataBase = rxBytes();
            dchip.setText("Data used: 0 B");
            say("Data counter zero ho gaya");
            return true;
        });
        sx.addView(dchip, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(sx);

        col.addView(Ui.section(this, "Insta Lite"));
        col.addView(instaQuickChips());

        col.addView(Ui.section(this, "Browse"));
        Ui.Flow b = chipFlow();
        addChip(b, "History (" + histCount() + ")", false, this::showHistory);
        addChip(b, "Back", false, this::navBack);
        addChip(b, "Forward", false, () -> {
            if (web.canGoForward()) web.goForward();
        });
        addChip(b, "Reload", false, () -> {
            userStopped = false;
            web.reload();
        });
        addChip(b, "Copy URL", false, () -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cur != null) cm.setPrimaryClip(ClipData.newPlainText("url", cur));
            say("URL copy ho gaya");
        });
        addChip(b, "Home mein jodo", false, () -> {
            String u = web.getUrl();
            if (u == null || !u.startsWith("http")) {
                say("Pehle koi site kholo");
                return;
            }
            String t = web.getTitle();
            String nm = t == null || t.trim().isEmpty() ? hostOf(u).replaceFirst("^www\\.", "") : t.trim();
            if (nm.length() > 18) nm = nm.substring(0, 18);
            homeSites.add(new String[]{nm, u});
            saveHome();
            refreshHome();
            say("Home mein jod di");
        });
        col.addView(b);

        col.addView(Ui.section(this, "Link tools"));
        Ui.Flow t = chipFlow();
        addChip(t, "Link Radar", false, this::showRadar);
        addChip(t, "Page unlock", false, () -> web.evaluateJavascript("(function(){var f=window['" + bridgeName
                + "u'];return f?f():-1})()", v -> showBar(
                "0".equals(v) ? "Hatane layak overlay nahi mila" : "Overlay hat gaya, page unlock ho gaya", null, null)));
        addChip(t, slow ? "Real-time: ON" : "Real-time: OFF", slow, () -> {
            if (root.isEmpty()) return;
            if (slow) slowHosts.remove(root);
            else slowHosts.add(root);
            saveSlow();
            applyMode();
            say(slow ? "Is site par speed wapas chalu ho gayi" : "Is site par real-time chalu ho gaya");
            pushCfg();
        });
        addChip(t, "Site speed " + effectiveRate(root) + "x", false, () -> showSiteSpeed(root));
        addChip(t, "Fresh session", false, () -> {
            freshSession(cur);
            say("Fresh session ho gayi, is site ke cookies saaf");
            web.reload();
        });
        addChip(t, "Link type: " + (linkType == 1 ? "Key" : linkType == 2 ? "File/APK" : "Auto"), linkType != 0, () -> {
            linkType = (linkType + 1) % 3;
            prefs.edit().putInt("linkType", linkType).apply();
            applyMode();
            say(linkType == 1 ? "Link type: Key" : linkType == 2 ? "Link type: File/APK" : "Link type: Auto");
            pushCfg();
        });
        addChip(t, "Final link copy", copyFinal, () -> {
            copyFinal = !copyFinal;
            prefs.edit().putBoolean("copyFinal", copyFinal).apply();
            say(copyFinal ? "Final link auto-copy chalu" : "Final link auto-copy band");
        });
        col.addView(t);

        col.addView(Ui.section(this, "Data"));
        Ui.Flow d = chipFlow();
        addChip(d, "Saved keys (" + keyCount() + ")", false, this::showKeys);
        addChip(d, "Links done: " + prefs.getInt("flows", 0), false, () ->
                say("Ab tak " + prefs.getInt("flows", 0) + " links complete ho chuke"));
        addChip(d, "Flow log copy (" + flogSize() + ")", false, this::copyFlowLog);
        addChip(d, "Flow log saaf", false, () -> {
            startRecording();
            say("Flow log saaf ho gaya, ab naya link kholo");
        });
        addChip(d, "Seekhi sites reset", false, () -> {
            slowHosts.clear();
            hostRate.clear();
            saveSlow();
            saveRates();
            applyMode();
            say("Reset ho gaya, sab saaf");
        });
        col.addView(d);
        sheet.show("Menu", col, true, false);
    }

    // ---------------------------------------------------------------- sound boost

    /** True while the phone's audio is going out over Bluetooth (A2DP / SCO / LE Audio). No permission needed. */
    private boolean isBtOutput() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return false;
            for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int t = d.getType();
                if (t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return true;
                if (Build.VERSION.SDK_INT >= 31
                        && (t == AudioDeviceInfo.TYPE_BLE_HEADSET || t == AudioDeviceInfo.TYPE_BLE_SPEAKER)) return true;
                if (Build.VERSION.SDK_INT >= 33 && t == AudioDeviceInfo.TYPE_BLE_BROADCAST) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    /** What the page actually gets: the chosen boost, but never above 250% when no Bluetooth is connected. */
    private int effBoost() {
        return Math.min(boostPct, btOut ? BOOST_MAX : BOOST_MAX_NO_BT);
    }

    private void watchAudioOut() {
        btOut = isBtOutput();
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return;
            audioCb = new AudioDeviceCallback() {
                @Override
                public void onAudioDevicesAdded(AudioDeviceInfo[] added) {
                    audioOutChanged();
                }

                @Override
                public void onAudioDevicesRemoved(AudioDeviceInfo[] removed) {
                    audioOutChanged();
                }
            };
            am.registerAudioDeviceCallback(audioCb, ui);
        } catch (Exception ignored) {
        }
    }

    private void audioOutChanged() {
        boolean now = isBtOutput();
        if (now == btOut) return;
        btOut = now;
        if (web == null || boostPct <= BOOST_MAX_NO_BT) return;     // nothing above 250% was asked for: nothing changes
        applyBoost(true);
        say(btOut ? "Bluetooth connected: boost " + boostPct + "%" : "Bluetooth nahi hai: boost 250% par");
    }

    private void applyBoost(boolean persist) {
        if (persist) {
            prefs.edit().putInt("boost", boostPct).putBoolean("lim", limOn).apply();
            applyMode();    // new page loads start with the same boost
        }
        if (web != null) {
            web.evaluateJavascript("(function(){var f=window['" + bridgeName + "b'];return f?f(" + effBoost() + ","
                    + limOn + "):-1})()", null);
            pushBoostToPlayer();
        }
    }

    /** 16D Hall: level 0-3 + slow drift. Applies to the open page at once and to every page that loads later. */
    private void applyHall(boolean persist) {
        if (persist) {
            prefs.edit().putInt("hall", hallLvl).putBoolean("drift", driftOn).apply();
            applyMode();    // new page loads start with the same hall
        }
        if (web != null) {
            web.evaluateJavascript("(function(){var f=window['" + bridgeName + "hl'];return f?f(" + hallLvl + ","
                    + driftOn + "):-1})()", null);
        }
    }

    private void onHallFail() {
        if (hallLvl == 0) return;
        hallLvl = 0;
        applyHall(true);
        say("16D Hall is page par sahi nahi chal raha tha, isliye band kar diya");
    }

    private void pushBoostToPlayer() {
        if (web == null || !MusicHost.isPlayerUrl(web.getUrl())) return;
        web.evaluateJavascript("window.flbBoost&&window.flbBoost(" + effBoost() + "," + boostPct + ")", null);
    }

    // ---------------------------------------------------------------- music player

    private boolean onPlayer;

    private void openMusicPlayer() {
        userStopped = false;
        showHome(false);
        if (web != null && !MusicHost.isPlayerUrl(web.getUrl())) web.loadUrl(MusicHost.PLAYER_URL);
    }

    /** Buttons inside the player page (links to https://flb.local/cmd/NAME) land here. */
    private void musicCmd(final String name) {
        if ("sound".equals(name)) {
            ui.post(this::showSound);
        } else if ("perm".equals(name)) {
            ui.post(() -> {
                if (MusicHost.hasPerm(this)) {
                    if (web != null) web.evaluateJavascript("window.flbReload&&window.flbReload()", null);
                } else {
                    requestPermissions(new String[]{MusicHost.permName()}, 78);
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 78 && web != null) {
            web.evaluateJavascript("window.flbReload&&window.flbReload()", null);
            if (res.length == 0 || res[0] != PackageManager.PERMISSION_GRANTED) {
                say("Music access nahi mila: sirf app ke download kiye gaane dikhenge");
            }
        }
    }

    private void showSound() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(4), dp(20), dp(24));
        btOut = isBtOutput();
        final TextView val = Ui.label(this, effBoost() + "%", 38, Ui.ACCENT, true);
        col.addView(val);
        final TextView btState = Ui.label(this, btOut
                ? "Bluetooth connected: 500% tak chalega"
                : "Bluetooth nahi hai: yahan max 250%. 500% sirf Bluetooth par chalta hai"
                + (boostPct > BOOST_MAX_NO_BT ? " (Bluetooth lagte hi " + boostPct + "% wapas aa jayega)" : "."),
                12.5f, btOut ? Ui.ACCENT : Ui.RED, true);
        btState.setPadding(0, dp(2), 0, dp(4));
        col.addView(btState);
        TextView hint = Ui.label(this, "Bluetooth speaker / DJ par awaaz tez karne ke liye. Limiter ON rakho: "
                + "awaaz phat'ti nahi. 400-500% par gaane ki dynamics thodi dab jati hai, yeh normal hai.",
                12.5f, Ui.SUB, false);
        hint.setPadding(0, dp(2), 0, dp(14));
        col.addView(hint);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(BOOST_MAX - 100);
        sb.setProgress(Math.max(0, Math.min(BOOST_MAX - 100, effBoost() - 100)));
        sb.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(Ui.ACCENT));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = 100 + p;
                if (!btOut && v > BOOST_MAX_NO_BT) {        // no Bluetooth: the slider stops at 250%
                    v = BOOST_MAX_NO_BT;
                    s.setProgress(v - 100);
                    if (fromUser) say("500% sirf Bluetooth par");
                }
                boostPct = v;
                val.setText(boostPct + "%");
                if (fromUser) applyBoost(false);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                applyBoost(true);
            }
        });
        col.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        Ui.Flow pre = new Ui.Flow(this, dp(8));
        pre.setPadding(0, dp(14), 0, 0);
        int[] presets = {100, 150, 200, 250, 300, 350, 400, 500};
        for (final int pv : presets) {
            final boolean locked = !btOut && pv > BOOST_MAX_NO_BT;
            TextView c = Ui.chip(this, pv + "%", pv == effBoost());
            if (locked) c.setAlpha(0.4f);
            c.setOnClickListener(v -> {
                if (locked) {
                    say(pv + "% sirf Bluetooth par chalta hai");
                    return;
                }
                boostPct = pv;
                sb.setProgress(pv - 100);
                val.setText(pv + "%");
                applyBoost(true);
            });
            pre.addView(c, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        col.addView(pre);
        Ui.Flow more = new Ui.Flow(this, dp(8));
        more.setPadding(0, dp(12), 0, 0);
        final TextView lim = Ui.chip(this, limOn ? "Limiter: ON" : "Limiter: OFF", limOn);
        lim.setOnClickListener(v -> {
            limOn = !limOn;
            Ui.styleChip(lim, limOn);
            lim.setText(limOn ? "Limiter: ON" : "Limiter: OFF");
            applyBoost(true);
        });
        more.addView(lim, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView mx = Ui.chip(this, "System volume MAX", false);
        mx.setOnClickListener(v -> {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                        AudioManager.FLAG_SHOW_UI);
            }
        });
        more.addView(mx, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(more);

        TextView hallTitle = Ui.label(this, "16D Hall (speaker / Bluetooth DJ ke liye)", 15, Ui.ACCENT, true);
        hallTitle.setPadding(0, dp(22), 0, dp(2));
        col.addView(hallTitle);
        TextView hallHint = Ui.label(this, "Gaana concert hall jaisa goonjta hai. Awaaz kabhi upar-neeche nahi hoti: "
                + "asli gaana beech mein sthir rehta hai, sirf hall ki goonj dheere dheere idhar-udhar ghumti hai. "
                + "Earphone mein bhi chalta hai. Hall ON karne par awaaz thodi halki lag sakti hai, slider se badha lo.",
                12.5f, Ui.SUB, false);
        hallHint.setPadding(0, dp(2), 0, dp(10));
        col.addView(hallHint);
        Ui.Flow hallRow = new Ui.Flow(this, dp(8));
        final String[] hallNames = {"Hall OFF", "Halka", "Medium", "Concert"};
        final TextView[] hallChips = new TextView[hallNames.length];
        for (int i = 0; i < hallNames.length; i++) {
            final int lv = i;
            hallChips[i] = Ui.chip(this, hallNames[i], i == hallLvl);
            hallChips[i].setOnClickListener(v -> {
                hallLvl = lv;
                for (int j = 0; j < hallChips.length; j++) Ui.styleChip(hallChips[j], j == hallLvl);
                applyHall(true);
            });
            hallRow.addView(hallChips[i], new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        col.addView(hallRow);
        Ui.Flow driftRow = new Ui.Flow(this, dp(8));
        driftRow.setPadding(0, dp(10), 0, 0);
        final TextView driftChip = Ui.chip(this, driftOn ? "Slow ghumna: ON" : "Slow ghumna: OFF", driftOn);
        driftChip.setOnClickListener(v -> {
            driftOn = !driftOn;
            Ui.styleChip(driftChip, driftOn);
            driftChip.setText(driftOn ? "Slow ghumna: ON" : "Slow ghumna: OFF");
            applyHall(true);
        });
        driftRow.addView(driftChip, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(driftRow);

        if (boostSkipped) {
            TextView w = Ui.label(this, "Note: is page ka player doosri site ka hai, uspar boost nahi lag sakta.",
                    12, Ui.RED, false);
            w.setPadding(0, dp(12), 0, 0);
            col.addView(w);
        }
        sheet.show("Sound boost", col, true, false);
    }

    // ---------------------------------------------------------------- media found on the page + download

    private static final java.util.regex.Pattern MEDIA_EXT = java.util.regex.Pattern.compile(
            ".*\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|mp4|webm|mkv|mov|m3u8)$");

    /** Called from the network thread for every request: remembers direct audio / video file URLs. */
    private void sniffMedia(Uri u) {
        String p = u.getPath();
        if (p == null || !MEDIA_EXT.matcher(p.toLowerCase()).matches()) return;
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        if (hostIs(h, "googlevideo.com", "youtube.com", "ytimg.com", "youtu.be", "cdninstagram.com", "fbcdn.net", "instagram.com")
                || hostIs(h, AD_HOSTS)) return;
        final String url = u.toString();
        ui.post(() -> addMedia(url));
    }

    private static String kindOf(String url) {
        String p = url;
        int q = p.indexOf('?');
        if (q >= 0) p = p.substring(0, q);
        p = p.toLowerCase();
        if (p.endsWith(".m3u8")) return "hls";
        if (p.matches(".*\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac)$")) return "audio";
        if (p.matches(".*\\.(jpg|jpeg|png|webp|heic|gif)$")) return "image";
        return "video";
    }

    private String niceName(String url) {
        String g = URLUtil.guessFileName(url, null, null);
        int dot = g.lastIndexOf('.');
        String ext = dot >= 0 ? g.substring(dot + 1) : "";
        String base = dot > 0 ? g.substring(0, dot) : g;
        boolean generic = base.length() < 5
                || base.matches("(?i)(videoplayback|index|playlist|master|stream|media|audio|video|file|download|chunk.*|seg.*)")
                || base.matches("[0-9a-fA-F_\\-]{16,}");
        if (generic && web != null) {
            String t = web.getTitle();
            if (t != null && !t.trim().isEmpty()) {
                String c = t.trim().replaceAll("[\\\\/:*?\"<>|]+", " ");
                if (c.length() > 70) c = c.substring(0, 70);
                return c + (ext.isEmpty() ? "" : "." + ext);
            }
        }
        return g;
    }

    private void addMedia(String url) {
        if (mediaItems.containsKey(url)) return;
        if (hostIs(hostOf(web.getUrl()), "youtube.com", "youtu.be")) return;
        mediaItems.put(url, new String[]{kindOf(url), niceName(url)});
        while (mediaItems.size() > 30) {
            String eldest = mediaItems.keySet().iterator().next();
            mediaItems.remove(eldest);
        }
        updateFab();
        if (fab != null) fab.bounce();
    }

    // ---------------------------------------------------------------- Instagram (own login) -> download button

    private final HashSet<String> igKeys = new HashSet<>();
    private long igFailAt;

    private void igReset() {
        if (igKeys.isEmpty()) return;
        for (String k : igKeys) mediaItems.remove(k);
        igKeys.clear();
        updateFab();
    }

    private void igAdd(String url, String kind, String name) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        if (mediaItems.containsKey(url)) return;
        mediaItems.put(url, new String[]{"image".equals(kind) ? "image" : "video",
                name == null || name.isEmpty() ? niceName(url) : name});
        igKeys.add(url);
        updateFab();
        if (fab != null) fab.bounce();
    }

    private void igFail(String why) {
        if (igLoading) {                                  // the download sheet is waiting: tell it there
            igShowError(why);
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (now - igFailAt < 20000) return;
        igFailAt = now;
        if ("login".equals(why)) {
            say("Instagram mein login karo, phir post / reel / story ka download button chalega");
        } else {
            say("Instagram se file nahi mili (" + why + "). Post khol kar thodi der ruko");
        }
    }

    private void startDownload(String url, String name, String mime, boolean audioOnly, String ua) {
        if (flowActive) {
            flowEnded();
            prefs.edit().putInt("flows", prefs.getInt("flows", 0) + 1).apply();
        }
        stripTask = dc.add(url, name, ua != null ? ua : web.getSettings().getUserAgentString(),
                web.getUrl(), mime, audioOnly);
        say(audioOnly ? "Audio download shuru" : "Download shuru");
    }

    private void showMediaSheet() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(22));
        if (mediaItems.isEmpty()) {
            TextView h = Ui.label(this, "Abhi is page par koi seedhi audio / video file nahi mili.\n\n"
                    + "Song ya video play karo, file mil jayegi to ye button neela ho jayega.\n\n"
                    + "Instagram: login karke post / reel / story kholo, button khud neela ho jayega.\n\n"
                    + "Dhyan rahe: YouTube, Spotify, Netflix jaise protected streams download nahi hote.",
                    13.5f, Ui.SUB, false);
            h.setPadding(dp(20), dp(8), dp(20), dp(6));
            col.addView(h);
        } else {
            ArrayList<String> keys = new ArrayList<>(mediaItems.keySet());
            Collections.reverse(keys);
            int shown = 0;
            for (final String url : keys) {
                if (shown++ >= 20) break;
                final String[] it = mediaItems.get(url);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(18), dp(10), dp(14), dp(10));
                row.addView(Ui.icon(this, "audio".equals(it[0]) ? Ic.MUSIC : Ic.VIDEO, Ui.INK),
                        new LinearLayout.LayoutParams(dp(24), dp(24)));
                LinearLayout txt = new LinearLayout(this);
                txt.setOrientation(LinearLayout.VERTICAL);
                txt.setPadding(dp(12), 0, dp(8), 0);
                TextView nm = Ui.label(this, it[1], 14.5f, Ui.INK, true);
                nm.setSingleLine(true);
                nm.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                TextView sb = Ui.label(this, ("audio".equals(it[0]) ? "Audio" : "hls".equals(it[0]) ? "Stream (HLS)"
                        : "image".equals(it[0]) ? "Photo" : "Video") + "  \u2022  " + hostOf(url), 12, Ui.SUB, false);
                sb.setSingleLine(true);
                sb.setEllipsize(TextUtils.TruncateAt.END);
                txt.addView(nm);
                txt.addView(sb);
                row.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                if (!"audio".equals(it[0]) && !"image".equals(it[0])) {
                    TextView ba = Ui.chip(this, "Audio", false);
                    ba.setOnClickListener(v -> {
                        sheet.hide();
                        startDownload(url, it[1], null, true, null);
                    });
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMargins(0, 0, dp(6), 0);
                    row.addView(ba, lp);
                }
                TextView bv = Ui.chip(this, "audio".equals(it[0]) ? "Download" : "image".equals(it[0]) ? "Photo" : "Video", true);
                bv.setOnClickListener(v -> {
                    sheet.hide();
                    startDownload(url, it[1], null, false, null);
                });
                row.addView(bv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
                col.addView(row);
            }
        }
        col.addView(Ui.section(this, "Link se download"));
        LinearLayout pr = new LinearLayout(this);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        pr.setGravity(Gravity.CENTER_VERTICAL);
        pr.setPadding(dp(16), 0, dp(16), 0);
        final EditText pe = new EditText(this);
        pe.setSingleLine(true);
        pe.setHint("Direct file / .m3u8 link paste karo");
        pe.setTextSize(14);
        pe.setBackground(Ui.round(Ui.BG, dp(20)));
        pe.setPadding(dp(16), dp(10), dp(16), dp(10));
        pe.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        pr.addView(pe, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView go = Ui.chip(this, "Download", true);
        go.setOnClickListener(v -> {
            String u = normalizeUrl(pe.getText().toString());
            if (u == null) {
                say("Sahi link paste karo");
                return;
            }
            sheet.hide();
            startDownload(u, null, null, false, null);
        });
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        glp.setMargins(dp(8), 0, 0, 0);
        pr.addView(go, glp);
        col.addView(pr);
        sheet.show("Download", col, true, false);
    }

    private void onDownloadDone(DownloadCenter.Task t) {
        String igKey = igPending.remove(t.id);
        if (igKey != null) igMarkDone(igKey, t.outUri);
        String sz = t.total > 0 ? " (" + fmtSize(t.total) + ")" : "";
        String nm = t.name == null ? "" : t.name.toLowerCase();
        final boolean isApk = nm.endsWith(".apk") || "application/vnd.android.package-archive".equals(t.mime);
        if (isApk && t.total > 0 && t.total < 200 * 1024) {
            say("\u26A0 Ye APK bohot chhoti hai" + sz + ", shayad asli file nahi (ad page ho sakta hai)");
            return;
        }
        if (t.outUri == null) {
            say("Download complete ho gaya" + sz);
            return;
        }
        final Uri u = Uri.parse(t.outUri);
        final String mt = t.mime == null ? "*/*" : t.mime;
        showBar((isApk ? "APK" : "File") + " download complete ho gaya" + sz,
                isApk ? "Install" : "Open", () -> openDownloaded(u, mt));
    }

    // ---------------------------------------------------------------- downloads screen

    private DlRow newRow() {
        final DlRow r = new DlRow();
        r.card = new LinearLayout(this);
        r.card.setOrientation(LinearLayout.VERTICAL);
        r.card.setBackground(Ui.round(Ui.BG, dp(18)));
        r.card.setPadding(dp(16), dp(14), dp(16), dp(12));
        r.name = Ui.label(this, "", 14.5f, Ui.INK, true);
        r.name.setSingleLine(true);
        r.name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        r.card.addView(r.name);
        LinearLayout track = new LinearLayout(this);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setBackground(Ui.round(Ui.LINE, dp(3)));
        r.fill = new View(this);
        r.rest = new View(this);
        track.addView(r.fill, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0f));
        track.addView(r.rest, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 100f));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6));
        tl.setMargins(0, dp(10), 0, dp(8));
        r.card.addView(track, tl);
        r.info = Ui.label(this, "", 12.5f, Ui.SUB, false);
        r.info.setSingleLine(true);
        r.info.setEllipsize(TextUtils.TruncateAt.END);
        r.card.addView(r.info);
        LinearLayout br = new LinearLayout(this);
        br.setOrientation(LinearLayout.HORIZONTAL);
        br.setPadding(0, dp(10), 0, 0);
        r.b1 = Ui.chip(this, "Pause", true);
        r.b2 = Ui.chip(this, "Cancel", false);
        r.b3 = Ui.chip(this, "Delete file", false);
        for (TextView b : new TextView[]{r.b1, r.b2, r.b3}) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(8), 0);
            br.addView(b, lp);
        }
        r.card.addView(br);
        return r;
    }

    private void bindRow(DlRow r, final DownloadCenter.Task t) {
        r.name.setText(t.name == null ? "" : t.name);
        int pct = t.state == DownloadCenter.DONE ? 100
                : t.total > 0 ? (int) Math.min(100, t.done * 100 / t.total) : 0;
        setW(r.fill, pct);
        setW(r.rest, 100 - pct);
        int col = t.state == DownloadCenter.DONE ? Ui.GREEN : t.state == DownloadCenter.FAILED ? Ui.RED
                : t.state == DownloadCenter.PAUSED ? 0xFFFF9F0A : Ui.ACCENT;
        r.fill.setBackground(Ui.round(col, dp(3)));
        r.info.setText(infoLine(t));
        boolean active = t.state == DownloadCenter.RUNNING || t.state == DownloadCenter.QUEUED;
        if (active) {
            r.b1.setText("Pause");
            r.b1.setOnClickListener(v -> dc.pause(t));
            r.b2.setText("Cancel");
            r.b2.setOnClickListener(v -> dc.cancel(t));
            r.b3.setVisibility(View.GONE);
        } else if (t.state == DownloadCenter.PAUSED) {
            r.b1.setText("Resume");
            r.b1.setOnClickListener(v -> {
                stripTask = t;
                dc.resume(t);
            });
            r.b2.setText("Cancel");
            r.b2.setOnClickListener(v -> dc.cancel(t));
            r.b3.setVisibility(View.GONE);
        } else if (t.state == DownloadCenter.FAILED) {
            r.b1.setText("Retry");
            r.b1.setOnClickListener(v -> {
                stripTask = t;
                dc.resume(t);
            });
            r.b2.setText("Hatao");
            r.b2.setOnClickListener(v -> dc.remove(t, false));
            r.b3.setVisibility(View.GONE);
        } else {
            r.b1.setText("Open");
            r.b1.setOnClickListener(v -> {
                if (t.outUri != null) openDownloaded(Uri.parse(t.outUri), t.mime == null ? "*/*" : t.mime);
            });
            r.b2.setText("Hatao");
            r.b2.setOnClickListener(v -> dc.remove(t, false));
            r.b3.setVisibility(View.VISIBLE);
            r.b3.setOnClickListener(v -> {
                dc.remove(t, true);
                say("File delete ho gayi");
            });
        }
    }

    private void showDownloads() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(20));
        Ui.Flow top = chipFlow();
        TextView clr = Ui.chip(this, "Finished saaf karo", false);
        clr.setOnClickListener(v -> dc.clearFinished());
        top.addView(clr, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(top);
        dlList = new LinearLayout(this);
        dlList.setOrientation(LinearLayout.VERTICAL);
        dlList.setPadding(dp(14), dp(8), dp(14), 0);
        col.addView(dlList);
        dlRows.clear();
        dlOrder.clear();
        sheet.setOnHidden(() -> {
            dlList = null;
            dlRows.clear();
            dlOrder.clear();
        });
        sheet.show("Downloads", col, true, true);
        renderDownloads();
    }

    private void renderDownloads() {
        if (dlList == null || dc == null) return;
        List<DownloadCenter.Task> ts = dc.list();
        ArrayList<Integer> ids = new ArrayList<>();
        for (DownloadCenter.Task t : ts) ids.add(t.id);
        if (!ids.equals(dlOrder)) {
            dlList.removeAllViews();
            dlRows.clear();
            dlOrder.clear();
            dlOrder.addAll(ids);
            if (ts.isEmpty()) {
                TextView e = Ui.label(this, "Abhi koi download nahi.\nFloating download button se ya kisi file link se shuru karo.",
                        13.5f, Ui.SUB, false);
                e.setPadding(dp(8), dp(16), dp(8), dp(16));
                dlList.addView(e);
            }
            for (DownloadCenter.Task t : ts) {
                DlRow r = newRow();
                dlRows.put(t.id, r);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, 0, dp(10));
                dlList.addView(r.card, lp);
            }
        }
        for (DownloadCenter.Task t : ts) {
            DlRow r = dlRows.get(t.id);
            if (r != null) bindRow(r, t);
        }
    }

    // ---------------------------------------------------------------- app links (Play Store blocked, others ask)

    private static String friendlyApp(String sc, String pkg) {
        String x = ((sc == null ? "" : sc) + " " + (pkg == null ? "" : pkg)).toLowerCase();
        if (x.contains("whatsapp")) return "WhatsApp";
        if (x.contains("telegram") || x.startsWith("tg ")) return "Telegram";
        if (x.contains("instagram")) return "Instagram";
        if (x.contains("facebook") || x.startsWith("fb ")) return "Facebook";
        if (x.contains("twitter")) return "Twitter / X";
        if (x.contains("youtube")) return "YouTube";
        if (x.contains("snssdk") || x.contains("tiktok")) return "TikTok";
        if (x.contains("spotify")) return "Spotify";
        if (x.contains("mailto")) return "Email";
        if (x.startsWith("tel")) return "Phone";
        if (x.startsWith("sms")) return "Messages";
        if (pkg != null && !pkg.isEmpty()) return pkg;
        return sc == null || sc.isEmpty() ? "ek app" : sc;
    }

    private void externalApp(final String url) {
        if (flowActive || url == null) return;
        long now = SystemClock.elapsedRealtime();
        if (intentDlgOpen || (url.equals(lastIntentUrl) && now - lastIntentAt < 4000)) return;
        lastIntentUrl = url;
        lastIntentAt = now;
        Intent in;
        try {
            if (url.startsWith("intent:")) in = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
            else in = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        } catch (Exception e) {
            return;
        }
        String sc = in.getScheme() == null ? "" : in.getScheme().toLowerCase();
        String pkg = in.getPackage();
        String dsc = in.getData() == null || in.getData().getScheme() == null ? "" : in.getData().getScheme().toLowerCase();
        if (sc.equals("market") || dsc.equals("market") || "com.android.vending".equals(pkg)) {
            say("Play Store ka link roka \uD83D\uDEAB");
            return;
        }
        in.addCategory(Intent.CATEGORY_BROWSABLE);
        in.setComponent(null);
        in.setSelector(null);
        final Intent launch = in;
        final String fb = in.getStringExtra("browser_fallback_url");
        final String app = friendlyApp(dsc.isEmpty() ? sc : dsc, pkg);
        intentDlgOpen = true;
        ui.post(() -> new AlertDialog.Builder(this)
                .setTitle("App mein kholna hai?")
                .setMessage("Ye link " + app + " kholna chahta hai.")
                .setPositiveButton("Kholo", (d, w) -> {
                    try {
                        startActivity(launch);
                    } catch (Exception e) {
                        if (fb != null && (fb.startsWith("http://") || fb.startsWith("https://"))) web.loadUrl(fb);
                        else say(app + " installed nahi hai");
                    }
                })
                .setNegativeButton("Nahi", null)
                .setOnDismissListener(d -> intentDlgOpen = false)
                .show());
    }

    // ---------------------------------------------------------------- media state (lock screen / background)

    // ---------------------------------------------------------------- background play (home / screen lock)

    private boolean fg = true;
    private volatile boolean userPaused, screenOff;
    private BroadcastReceiver screenRx;

    private void jsCall(String fn, String args) {
        if (web == null) return;
        web.evaluateJavascript("(function(){var f=window['" + bridgeName + fn + "'];return f?f(" + args
                + "):-1})()", null);
    }

    private boolean bgActive() {
        return bgOn && MediaService.hold && !userPaused;
    }

    /** Screen locked / app left while media plays: keep the page alive and nudge the player if it pauses itself. */
    private void keepBgAlive() {
        if (web == null || !bgActive()) return;
        try {
            web.onResume();
            web.resumeTimers();
        } catch (Throwable ignored) {
        }
        jsCall("g", "true");
        long[] delays = {400, 1200, 2500, 5000, 9000};
        for (long ms : delays) {
            ui.postDelayed(() -> {
                if (bgActive() && (!fg || screenOff)) jsCall("r", "");
            }, ms);
        }
    }

    private void openBatterySettings() {
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            say("Nixu Browse ko \"Don't optimize\" / Unrestricted kar do");
        } catch (Throwable t) {
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null && bgActive()) {
            try {
                web.onResume();
                web.resumeTimers();
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        fg = false;
        keepBgAlive();
    }

    @Override
    protected void onResume() {
        super.onResume();
        fg = true;
        if (web != null) {
            try {
                web.onResume();
                web.resumeTimers();
            } catch (Throwable ignored) {
            }
            jsCall("g", "false");
        }
    }

    private void onMediaState(boolean play, String title) {
        playingNow = play;
        if (play) userPaused = false;
        updateFocus();
        if (!bgOn) return;
        if (!play && !MediaService.hold) return;
        if (play) {
            MediaService.hold = true;
            MediaService.playing = true;
        } else {
            MediaService.playing = false;
        }
        if (title != null && !title.isEmpty()) MediaService.title = title;
        MediaService.music = web != null && MusicHost.isPlayerUrl(web.getUrl());
        MediaService.sync(this);
    }

    private void askNotifPermission() {
        // Android 8/9 (e.g. Galaxy J6): saving into Downloads needs the old storage permission.
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 78);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !prefs.getBoolean("notifAsked", false)) {
            prefs.edit().putBoolean("notifAsked", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
        }
    }

    // ---------- history ----------

    private void loadHist() {
        if (histLoaded) return;
        histLoaded = true;
        try {
            JSONArray a = new JSONArray(prefs.getString("history", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String u = o.optString("u");
                if (!u.isEmpty()) hist.add(new Hist(o.optString("t"), u, o.optLong("d")));
            }
        } catch (Exception ignored) {
        }
    }

    private void saveHist() {
        try {
            JSONArray a = new JSONArray();
            for (Hist h : hist) {
                JSONObject o = new JSONObject();
                o.put("t", h.title);
                o.put("u", h.url);
                o.put("d", h.time);
                a.put(o);
            }
            prefs.edit().putString("history", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private int histCount() {
        loadHist();
        return hist.size();
    }

    private void addHistory(String url, String title) {
        if (incog) return;
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        loadHist();
        for (int i = 0; i < hist.size(); i++) {
            if (hist.get(i).url.equals(url)) {
                hist.remove(i);
                break;
            }
        }
        hist.add(0, new Hist(title == null ? "" : title.trim(), url, System.currentTimeMillis()));
        while (hist.size() > 500) hist.remove(hist.size() - 1);
        saveHist();
    }

    private Button histBtn(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(6), dp(8), dp(6), dp(8));
        return b;
    }

    /** History: tap = open, long-press or "Select" = choose items, then Select all / Delete / Sab hatao. */
    private void showHistory() {
        loadHist();
        if (hist.isEmpty()) {
            say("History abhi khaali hai \uD83D\uDCDC");
            return;
        }
        final boolean[] selMode = {false};
        final HashSet<Hist> sel = new HashSet<>();
        final AlertDialog[] dlg = new AlertDialog[1];
        final Runnable[] refresh = new Runnable[1];

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(4), dp(12), 0);

        final Button bSel = histBtn("\u2611 Select");
        final Button bAll = histBtn("Select all");
        final Button bDel = histBtn("\uD83D\uDDD1 Delete");
        final Button bClr = histBtn("\uD83D\uDDD1 Sab hatao");
        final Button bCpy = histBtn("\uD83D\uDCCB Copy");
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        for (Button x : new Button[]{bSel, bAll, bCpy, bDel, bClr}) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(2), 0, dp(2), dp(4));
            btns.addView(x, lp);
        }
        box.addView(btns);

        final ListView lv = new ListView(this);
        final BaseAdapter ad = new BaseAdapter() {
            @Override
            public int getCount() {
                return hist.size();
            }

            @Override
            public Object getItem(int i) {
                return hist.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View cv, ViewGroup parent) {
                if (cv == null) {
                    LinearLayout row = new LinearLayout(MainActivity.this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(dp(4), dp(8), dp(4), dp(8));
                    CheckBox cb = new CheckBox(MainActivity.this);
                    cb.setFocusable(false);
                    cb.setClickable(false);
                    row.addView(cb, new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    LinearLayout col = new LinearLayout(MainActivity.this);
                    col.setOrientation(LinearLayout.VERTICAL);
                    TextView t1 = new TextView(MainActivity.this);
                    t1.setTextSize(15);
                    t1.setTextColor(Color.BLACK);
                    t1.setSingleLine(true);
                    t1.setEllipsize(TextUtils.TruncateAt.END);
                    TextView t2 = new TextView(MainActivity.this);
                    t2.setTextSize(12);
                    t2.setTextColor(0xFF666666);
                    t2.setSingleLine(true);
                    t2.setEllipsize(TextUtils.TruncateAt.END);
                    col.addView(t1);
                    col.addView(t2);
                    row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    TextView cp = new TextView(MainActivity.this);
                    cp.setText("\uD83D\uDCCB");
                    cp.setTextSize(19);
                    cp.setGravity(Gravity.CENTER);
                    cp.setFocusable(false);
                    cp.setFocusableInTouchMode(false);
                    cp.setPadding(dp(12), dp(6), dp(8), dp(6));
                    row.addView(cp, new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    row.setTag(new View[]{cb, t1, t2, cp});
                    cv = row;
                }
                View[] vs = (View[]) cv.getTag();
                Hist it = hist.get(i);
                CheckBox cb2 = (CheckBox) vs[0];
                cb2.setVisibility(selMode[0] ? View.VISIBLE : View.GONE);
                cb2.setChecked(sel.contains(it));
                ((TextView) vs[1]).setText(it.title.isEmpty() ? it.url : it.title);
                CharSequence ago = DateUtils.getRelativeTimeSpanString(
                        it.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS);
                ((TextView) vs[2]).setText(ago + "  \u2022  " + it.url);
                final String copyUrl = it.url;
                vs[3].setOnClickListener(x -> copyText(copyUrl, "Link copy ho gaya \u2705"));
                return cv;
            }
        };
        lv.setAdapter(ad);
        int listH = Math.min(dp(420), getResources().getDisplayMetrics().heightPixels * 55 / 100);
        box.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, listH));

        refresh[0] = () -> {
            bSel.setText(selMode[0] ? "\u2716 Cancel" : "\u2611 Select");
            bAll.setVisibility(selMode[0] ? View.VISIBLE : View.GONE);
            bDel.setVisibility(selMode[0] ? View.VISIBLE : View.GONE);
            bClr.setVisibility(selMode[0] ? View.GONE : View.VISIBLE);
            bAll.setText(!hist.isEmpty() && sel.size() == hist.size() ? "Unselect all" : "Select all");
            bDel.setText("\uD83D\uDDD1 Delete (" + sel.size() + ")");
            bDel.setEnabled(!sel.isEmpty());
            bCpy.setVisibility(selMode[0] ? View.VISIBLE : View.GONE);
            bCpy.setText("\uD83D\uDCCB Copy (" + sel.size() + ")");
            bCpy.setEnabled(!sel.isEmpty());
            if (dlg[0] != null) dlg[0].setTitle("History (" + hist.size() + ")");
            ad.notifyDataSetChanged();
        };

        lv.setOnItemClickListener((parent, view, pos, id) -> {
            if (pos < 0 || pos >= hist.size()) return;
            Hist it = hist.get(pos);
            if (selMode[0]) {
                if (!sel.remove(it)) sel.add(it);
                refresh[0].run();
            } else {
                dlg[0].dismiss();
                go(it.url);
            }
        });
        lv.setOnItemLongClickListener((parent, view, pos, id) -> {
            if (pos >= 0 && pos < hist.size()) {
                selMode[0] = true;
                sel.add(hist.get(pos));
                refresh[0].run();
            }
            return true;
        });
        bSel.setOnClickListener(x -> {
            selMode[0] = !selMode[0];
            sel.clear();
            refresh[0].run();
        });
        bAll.setOnClickListener(x -> {
            boolean all = sel.size() == hist.size();
            sel.clear();
            if (!all) sel.addAll(hist);
            refresh[0].run();
        });
        bDel.setOnClickListener(x -> {
            if (sel.isEmpty()) return;
            int n = sel.size();
            hist.removeAll(sel);
            saveHist();
            sel.clear();
            selMode[0] = false;
            say(n + " history hata di \u2705");
            if (hist.isEmpty()) {
                dlg[0].dismiss();
                return;
            }
            refresh[0].run();
        });
        bCpy.setOnClickListener(x -> {
            if (sel.isEmpty()) return;
            StringBuilder sb = new StringBuilder();
            int n = 0;
            for (Hist h : hist) {
                if (sel.contains(h)) {
                    if (n++ > 0) sb.append('\n');
                    sb.append(h.url);
                }
            }
            copyText(sb.toString(), n == 1 ? "Link copy ho gaya \u2705" : n + " links copy ho gaye \u2705");
        });
        bClr.setOnClickListener(x -> new AlertDialog.Builder(this)
                .setTitle("Poori history hata dein?")
                .setMessage(hist.size() + " pages ki history hamesha ke liye hat jaayegi.")
                .setPositiveButton("Haan, sab hatao", (d2, w2) -> {
                    hist.clear();
                    saveHist();
                    say("Poori history saaf ho gayi \u2728");
                    dlg[0].dismiss();
                })
                .setNegativeButton("Nahi", null)
                .show());

        dlg[0] = new AlertDialog.Builder(this)
                .setTitle("History (" + hist.size() + ")")
                .setView(box)
                .setNegativeButton("Band karo", null)
                .create();
        dlg[0].show();
        refresh[0].run();
    }

    private void showKeys() {
        final ArrayList<String> keys = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString("keys", "[]"));
            long now = System.currentTimeMillis();
            for (int k = 0; k < arr.length(); k++) {
                JSONObject o = arr.getJSONObject(k);
                keys.add(o.optString("k"));
                CharSequence ago = DateUtils.getRelativeTimeSpanString(o.optLong("t"), now, DateUtils.MINUTE_IN_MILLIS);
                labels.add(o.optString("h") + "  \u2022  " + ago + "\n" + o.optString("k"));
            }
        } catch (Exception ignored) {
        }
        if (keys.isEmpty()) {
            say("Abhi koi key save nahi hui \uD83D\uDD11");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Saved keys (tap = copy)")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("key", keys.get(which)));
                    say("Key copy ho gayi \u2705");
                })
                .setNegativeButton("Sab hatao", (d, w) -> {
                    prefs.edit().remove("keys").apply();
                    say("Saved keys saaf ho gayi \u2728");
                })
                .show();
    }

    private void openDownloaded(Uri uri, String mime) {
        try {
            Intent in = new Intent(Intent.ACTION_VIEW);
            in.setDataAndType(uri, mime);
            in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(in);
        } catch (Exception e) {
            say("Open nahi ho paaya, Downloads mein dekho");
        }
    }

    private static String fmtSize(long b) {
        if (b >= 1073741824L) return String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0);
        if (b >= 1048576L) return String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0);
        return (b / 1024L) + " KB";
    }

    private void freshSession(String url) {
        String host = hostOf(url);
        String root = rootHost(host);
        if (host.isEmpty()) return;
        try {
            CookieManager cm = curCookies();
            for (String u : new String[]{"https://" + host, "https://" + root, "https://www." + root}) {
                String ck = cm.getCookie(u);
                if (ck == null) continue;
                for (String part : ck.split(";")) {
                    String nm = part.trim();
                    int eq = nm.indexOf('=');
                    if (eq <= 0) continue;
                    nm = nm.substring(0, eq);
                    cm.setCookie(u, nm + "=; Max-Age=0; Path=/");
                    cm.setCookie(u, nm + "=; Max-Age=0; Path=/; Domain=" + root);
                    cm.setCookie(u, nm + "=; Max-Age=0; Path=/; Domain=." + root);
                }
            }
            cm.flush();
        } catch (Throwable ignored) {
        }
        try {
            WebStorage ws = WebStorage.getInstance();
            ws.deleteOrigin("https://" + host);
            ws.deleteOrigin("https://" + root);
            ws.deleteOrigin("https://www." + root);
        } catch (Throwable ignored) {
        }
        try {
            web.clearCache(true);
        } catch (Throwable ignored) {
        }
    }


    private void showRadar() {
        web.evaluateJavascript("(function(){var f=window['" + bridgeName + "h'];return f?f():'[]'})()", value -> {
            final ArrayList<String> urls = new ArrayList<>();
            final ArrayList<String> labels = new ArrayList<>();
            try {
                Object o = new JSONTokener(value == null ? "\"[]\"" : value).nextValue();
                JSONArray arr = new JSONArray(o instanceof String ? (String) o : "[]");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject j = arr.getJSONObject(i);
                    String u = j.getString("u");
                    urls.add(u);
                    labels.add((j.optInt("g") == 1 ? "\u2B50 " : "") + hostOf(u) + shortPath(u)
                            + (j.optString("l").isEmpty() ? "" : "  [" + j.optString("l") + "]"));
                }
            } catch (Exception ignored) {
            }
            for (Map.Entry<String, String> e : radar.entrySet()) {
                if (!urls.contains(e.getKey())) {
                    urls.add(0, e.getKey());
                    labels.add(0, "\uD83D\uDD17 " + hostOf(e.getKey()) + shortPath(e.getKey()) + "  [" + e.getValue() + "]");
                }
            }
            if (urls.isEmpty()) {
                showBar("Abhi koi link nahi mila. Thoda ruk kar dobara dekho", null, null);
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Link Radar")
                    .setItems(labels.toArray(new String[0]), (d, which) -> web.loadUrl(urls.get(which)))
                    .setNegativeButton("Copy all", (d, w) -> {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("links", android.text.TextUtils.join("\n", urls)));
                    })
                    .show();
        });
    }

    private static String shortPath(String url) {
        try {
            String p = Uri.parse(url).getPath();
            if (p == null || p.equals("/")) return "";
            return p.length() > 28 ? p.substring(0, 28) + "\u2026" : p;
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- downloads ----------

    private void showDownloadDialog() {
        final String url = videoUrl;
        if (url == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Download")
                .setItems(new String[]{"\uD83C\uDFAC Video", "\uD83C\uDFB5 Audio only"}, (d, which) -> {
                    if (which == 0) downloadVideo(url);
                    else downloadAudio(url);
                })
                .show();
    }

    private String fileNameFor(String url) {
        String name = URLUtil.guessFileName(url, null, null);
        if (name == null || !name.contains(".") || name.endsWith(".bin")) {
            name = "video_" + System.currentTimeMillis() + ".mp4";
        }
        return name;
    }

    private void downloadVideo(String url) {
        try {
            enqueue(url, fileNameFor(url), web.getSettings().getUserAgentString(),
                    curCookies().getCookie(url), web.getUrl());
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    private void enqueue(String url, String name, String ua, String cookie, String ref) {
        flog("DOWNLOAD " + name + " <- " + url);
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (ref != null) r.addRequestHeader("Referer", ref);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            long id = ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
            myDownloads.add(id);
            toast("Download shuru ho gaya \u2B07 " + name);
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    // Audio only: downloads the file, copies out its audio track (no re-encoding) and saves it to Downloads.
    private void downloadAudio(String url) {
        if (url.toLowerCase().matches(".*\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac)(\\?.*)?$")) {
            downloadVideo(url); // already an audio file
            return;
        }
        final String ua = web.getSettings().getUserAgentString();
        final String cookie = curCookies().getCookie(url);
        final String ref = web.getUrl();
        final String baseName = fileNameFor(url).replaceAll("\\.[^.]*$", "");
        toast("Audio ban raha hai, thoda ruko \u23F3");

        new Thread(() -> {
            File tmp = null, out = null;
            try {
                long ts = System.currentTimeMillis();
                tmp = new File(getCacheDir(), "dl_" + ts + ".tmp");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                if (ua != null) c.setRequestProperty("User-Agent", ua);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                if (ref != null) c.setRequestProperty("Referer", ref);
                try (InputStream in = c.getInputStream(); OutputStream fo = new FileOutputStream(tmp)) {
                    copy(in, fo);
                }

                MediaExtractor ex = new MediaExtractor();
                ex.setDataSource(tmp.getAbsolutePath());
                int track = -1;
                MediaFormat fmt = null;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    MediaFormat f = ex.getTrackFormat(i);
                    String m = f.getString(MediaFormat.KEY_MIME);
                    if (m != null && m.startsWith("audio/")) {
                        track = i;
                        fmt = f;
                        break;
                    }
                }
                if (track < 0) throw new Exception("is video mein audio track nahi mila");

                String mime = fmt.getString(MediaFormat.KEY_MIME);
                int muxFmt;
                String ext, outMime;
                if ("audio/mp4a-latm".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4;
                    ext = "m4a";
                    outMime = "audio/mp4";
                } else if ("audio/opus".equals(mime) || "audio/vorbis".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM;
                    ext = "webm";
                    outMime = "audio/webm";
                } else {
                    throw new Exception("audio format (" + mime + ") support nahi hai");
                }

                out = new File(getCacheDir(), "out_" + ts + "." + ext);
                MediaMuxer mux = new MediaMuxer(out.getAbsolutePath(), muxFmt);
                ex.selectTrack(track);
                int outTrack = mux.addTrack(fmt);
                mux.start();
                ByteBuffer buf = ByteBuffer.allocate(1 << 20);
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                while (true) {
                    buf.clear();
                    int n = ex.readSampleData(buf, 0);
                    if (n < 0) break;
                    info.set(0, n, ex.getSampleTime(), ex.getSampleFlags());
                    mux.writeSampleData(outTrack, buf, info);
                    ex.advance();
                }
                mux.stop();
                mux.release();
                ex.release();

                String fileName = baseName + "." + ext;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, outMime);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) throw new Exception("file save nahi ho paayi");
                    try (OutputStream os = getContentResolver().openOutputStream(uri);
                         InputStream is = new FileInputStream(out)) {
                        copy(is, os);
                    }
                } else {
                    File dlDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dlDir.exists() && !dlDir.mkdirs() && !dlDir.exists()) {
                        throw new Exception("Downloads folder nahi mila - Storage permission allow karo");
                    }
                    File dest = new File(dlDir, fileName);
                    int k = 1;
                    while (dest.exists() && k < 1000) {
                        dest = new File(dlDir, baseName + " (" + (k++) + ")." + ext);
                    }
                    try (OutputStream os = new FileOutputStream(dest);
                         InputStream is = new FileInputStream(out)) {
                        copy(is, os);
                    }
                    android.media.MediaScannerConnection.scanFile(MainActivity.this,
                            new String[]{dest.getAbsolutePath()}, null, null);
                }
                toast("Audio complete ho gaya \uD83C\uDF89 Downloads mein save: " + fileName);
            } catch (Exception e) {
                toast("Audio nahi ban paya: " + e.getMessage());
            } finally {
                if (tmp != null) tmp.delete();
                if (out != null) out.delete();
            }
        }).start();
    }

    private static void copy(InputStream in, OutputStream out) throws java.io.IOException {
        byte[] b = new byte[64 * 1024];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }

    private void toast(String msg) {
        say(msg);
    }

    // ---------- navigation ----------

    private void go(String input) {
        String s = input.trim();
        if (s.isEmpty()) return;
        userStopped = false;
        showHome(false);
        String url;
        if (s.startsWith("http://") || s.startsWith("https://")) {
            url = s;
        } else if (s.contains(".") && !s.contains(" ")) {
            url = "https://" + s;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(s);
        }
        radar.clear();
        lastDecoded = null;
        flowEnded();
        stepCount = 0;
        startRecording();
        flog("START " + url);
        web.loadUrl(url);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (sheet != null && sheet.isShowing()) {
            sheet.hide();
            return;
        }
        if (fsView != null) {
            exitFullscreen();
            return;
        }
        if (landFs) {
            web.evaluateJavascript("(" + rotJs + ")(false)", null);
            applyLandFs(false);
            manualLand = false;
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            return;
        }
        if (floatBox != null && floatBox.getVisibility() == View.VISIBLE) {
            // the floating window is on top: Back goes inside it first, then closes it
            if (floatWeb != null && floatWeb.canGoBack()) floatWeb.goBack();
            else hideFloat();
            return;
        }
        if (homeShown) {
            if (homeByBack || web.getUrl() == null) super.onBackPressed();
            else showHome(false);
            return;
        }
        if (web.canGoBack()) {
            backSmart();
        } else {
            homeByBack = true;
            showHome(true);
        }
    }

    // ---------- fullscreen video + rotate ----------

    private void immersive(boolean on) {
        View d = getWindow().getDecorView();
        if (on) {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            if (Build.VERSION.SDK_INT >= 28) {
                getWindow().getAttributes().layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            applyBars();
            if (Build.VERSION.SDK_INT >= 28) {
                getWindow().getAttributes().layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
            }
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        getWindow().setAttributes(getWindow().getAttributes());
    }

    /** Page asked for fullscreen video (YouTube's fullscreen button, or our rotate trigger). */
    private void enterFullscreen(View view, WebChromeClient.CustomViewCallback cb) {
        if (fsView != null) {
            cb.onCustomViewHidden();
            return;
        }
        if (landFs) applyLandFs(false);
        fsView = view;
        fsCb = cb;
        fsBox = new FrameLayout(this);
        fsBox.setBackgroundColor(Color.BLACK);
        fsBox.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ((ViewGroup) getWindow().getDecorView()).addView(fsBox, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        immersive(true);
        // user tapped fullscreen -> landscape. (App is otherwise locked to portrait: no auto-rotate.)
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }

    private void exitFullscreen() {
        if (fsView == null) return;
        ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        if (fsBox != null) {
            fsBox.removeAllViews();
            decor.removeView(fsBox);
        }
        fsBox = null;
        fsView = null;
        immersive(false);
        // 1) let the page leave fullscreen first (while the screen is still landscape)
        WebChromeClient.CustomViewCallback cb = fsCb;
        fsCb = null;
        if (cb != null) cb.onCustomViewHidden();
        // 2) then leave landscape -> back to portrait (or stay landscape if it was rotated from the menu)
        setRequestedOrientation(manualLand ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        // 3) the page can keep the old landscape layout: re-sync it once the rotation is done
        scheduleRelayout();
    }

    // ---- v5.1: page stays in the old (landscape) layout after fullscreen / rotate -> force a fresh layout ----
    private static final String RELAYOUT_JS = "(function(){try{"
            + "window.dispatchEvent(new Event('resize'));window.dispatchEvent(new Event('orientationchange'));"
            + "var s=document.getElementById('__flb_land_css');if(s)s.remove();"
            + "var a=document.querySelectorAll('.__flb_fs,.__flb_anc');"
            + "for(var i=0;i<a.length;i++)a[i].classList.remove('__flb_fs','__flb_anc');"
            + "return window.innerWidth;}catch(e){return -1;}})()";
    private int relayoutWait, relayoutMis;
    private final Runnable relayoutRun = new Runnable() {
        @Override
        public void run() {
            relayoutWeb();
        }
    };

    private void scheduleRelayout() {
        ui.removeCallbacks(relayoutRun);
        relayoutWait = 0;
        relayoutMis = 0;
        ui.postDelayed(relayoutRun, 350);
    }

    private void relayoutWeb() {
        if (web == null || fsView != null || landFs) return;
        if (getResources().getConfiguration().orientation != Configuration.ORIENTATION_PORTRAIT) {
            if (relayoutWait++ < 8) ui.postDelayed(relayoutRun, 250);   // rotation not finished yet
            return;
        }
        ViewGroup.LayoutParams p = web.getLayoutParams();
        if (!(p instanceof ViewGroup.MarginLayoutParams)) return;
        final ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) p;
        // shrink by 2 px and grow back: the page gets two real resize events and measures itself again
        lp.rightMargin = dp(2);
        web.setLayoutParams(lp);
        ui.postDelayed(() -> {
            if (web == null) return;
            lp.rightMargin = 0;
            web.setLayoutParams(lp);
            web.evaluateJavascript(RELAYOUT_JS, v -> checkRelayout(v));
        }, 120);
    }

    private void checkRelayout(String v) {
        if (web == null || fsView != null || landFs || desktop || v == null) return;
        double iw;
        try {
            iw = Double.parseDouble(v.replace("\"", "").trim());
        } catch (Exception e) {
            return;
        }
        double want = web.getWidth() / getResources().getDisplayMetrics().density;
        if (iw <= 0 || want <= 0 || Math.abs(iw - want) <= want * 0.08) return;   // layout is fine
        if (relayoutMis++ < 2) {
            ui.postDelayed(relayoutRun, 600);
            return;
        }
        if (isLightHost(hostOf(web.getUrl()))) {      // responsive sites only: last resort = fresh load
            say("Page ka layout bigad gaya tha, dobara load kar raha hun");
            web.reload();
        }
    }

    /** Menu -> Rotate screen: portrait <-> landscape by hand. The sensor never rotates the app. */
    private void toggleRotate() {
        manualLand = !manualLand;
        if (manualLand) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            say("Screen landscape ho gayi \uD83D\uDD04 (wapas portrait: menu mein dobara Rotate)");
        } else {
            if (landFs) {
                web.evaluateJavascript("(" + rotJs + ")(false)", null);
                applyLandFs(false);
            }
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            say("Screen portrait ho gayi \uD83D\uDD04");
        }
    }

    /** "Video only" layout: url bar and system bars hidden, page shows just the player. */
    private void applyLandFs(boolean on) {
        landFs = on;
        topBar.setVisibility(on ? View.GONE : View.VISIBLE);
        progress.setVisibility(on ? View.GONE : View.INVISIBLE);
        immersive(on);
        updateChrome();
        updateStrip();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        maxRootH = 0;
        if (fab != null) {
            fab.setTranslationX(0f);
            fab.setTranslationY(0f);
        }
        if (fsView != null) return; // real fullscreen manages itself
        if (c.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // only when the user chose "Rotate screen" in the menu (never from the phone's sensor):
            // if a video is playing, show it fullscreen
            if (!manualLand) return;
            web.evaluateJavascript("(" + rotJs + ")(true)", v -> {
                if (v == null) return;
                if (v.contains("css")) {
                    applyLandFs(true);
                } else if (v.contains("trying")) {
                    // real fullscreen may still be refused by the page -> check again shortly
                    web.postDelayed(() -> {
                        if (fsView != null || landFs) return;
                        web.evaluateJavascript(
                                "!!document.getElementById('__flb_land_css')", r -> {
                                    if ("true".equals(r) && fsView == null) applyLandFs(true);
                                });
                    }, 700);
                }
            });
        } else {
            // back to portrait: normal browser again
            if (landFs) {
                web.evaluateJavascript("(" + rotJs + ")(false)", null);
                applyLandFs(false);
            }
            scheduleRelayout();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && (fsView != null || landFs)) immersive(true);
    }

    // ====================================================================== v5.9: Insta Lite Pro

    private boolean igLite = true, igNoAuto = true, igNoPrev = true, igStart = true, navAuto = true, igCounter = true;
    private int igRq = 480, igSq = 480, igDlQ;
    private volatile boolean igNow;                       // the page on screen is on instagram.com
    private String igTargetCode = "", igTargetType = "", igWantCode;
    private boolean igLoading, leadBack, navPeek;
    private InstaLite.Post igPost;
    private int igSel, igQ;
    private long igSheetToken;
    private TextView igSizeTv, dataTv;
    private LinearLayout dataPill;
    private ImageView navHandle, urlLead;
    private FrameLayout navInstaCell;
    private Runnable navHideRun;
    private long igBytes, igLastRx = -1;
    private final HashMap<Integer, String> igPending = new HashMap<>();
    private final android.util.LruCache<String, Bitmap> thumbCache = new android.util.LruCache<>(16);

    private void loadIgPrefs() {
        igLite = prefs.getBoolean("ig_lite", true);
        igNoAuto = prefs.getBoolean("ig_noauto", true);
        igNoPrev = prefs.getBoolean("ig_noprev", true);
        igStart = prefs.getBoolean("ig_start", true);
        navAuto = prefs.getBoolean("nav_auto", true);
        igCounter = prefs.getBoolean("ig_counter", true);
        igRq = prefs.getInt("ig_rq", 480);
        igSq = prefs.getInt("ig_sq", 480);
        igDlQ = prefs.getInt("ig_dlq", 0);
    }

    /** Quality cap that applies to the page on screen (Instagram + Insta Lite: its own Reel quality, else the global one). */
    private int capNow() {
        return igNow && igLite ? igRq : vqCap;
    }

    /** Insta Lite: analytics, logging, prefetch and web fonts of Instagram are answered with an empty reply. */
    private WebResourceResponse igLiteRule(WebResourceRequest r) {
        Uri u = r.getUrl();
        Map<String, String> h = r.getRequestHeaders();
        String purpose = hdr(h, "Sec-Purpose");
        if (purpose == null) purpose = hdr(h, "Purpose");
        if (purpose == null) purpose = hdr(h, "X-Purpose");
        int k = InstaLite.rule(u.getHost(), u.getPath(), r.isForMainFrame(), purpose);
        if (k == InstaLite.ALLOW) return null;
        if (k == InstaLite.STUB) return stub(r);
        Map<String, String> hd = new HashMap<>();
        hd.put("Access-Control-Allow-Origin", "*");
        hd.put("Cache-Control", "no-store");
        if (k == InstaLite.NO_CONTENT) {
            return new WebResourceResponse("text/plain", "utf-8", 204, "No Content", hd, new ByteArrayInputStream(new byte[0]));
        }
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", hd, new ByteArrayInputStream(new byte[0]));
    }

    // ---- Instagram page <-> app (called from flb_insta.js)

    private void igTarget(String code, String type) {
        igTargetCode = code == null ? "" : code;
        igTargetType = type == null ? "" : type;
        updateFab();
    }

    private void igWant(String code) {
        igWantCode = code;
        if (!(igLoading && sheet != null && sheet.isShowing())) showInstaLoading();
    }

    private void showInstaLoading() {
        igLoading = true;
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(8), dp(20), dp(26));
        col.addView(Ui.label(this, "Post ki info la raha hoon...", 14.5f, Ui.SUB, false));
        sheet.setOnHidden(() -> {
            igLoading = false;
            igWantCode = null;
        });
        sheet.show("Instagram download", col, false, false);
        final long tk = ++igSheetToken;
        ui.postDelayed(() -> {
            if (igLoading && tk == igSheetToken) igShowError("net");
        }, 15000);
    }

    /** Download button / chip tapped on an Instagram page. */
    private void openInstaSheet() {
        igWantCode = "";
        showInstaLoading();
        if (web == null) return;
        web.evaluateJavascript("(function(){var f=window['" + bridgeName + "i'];return f?f('open',''):-1})()", v -> {
            if ("-1".equals(v) && igLoading) igShowError("page abhi load ho raha hai");
        });
    }

    private void igInfo(String code, String json) {
        InstaLite.Post p = InstaLite.parse(json);
        if (p == null) {
            if (igLoading) igShowError("file nahi mili");
            return;
        }
        if (p.code.isEmpty()) p.code = code;
        if (!igLoading || igWantCode == null) return;
        if (!igWantCode.isEmpty() && !igWantCode.equals(code)) return;
        igPost = p;
        igSel = 0;
        igQ = igDlQ;
        renderInstaSheet();
    }

    private void igShowError(String why) {
        igLoading = false;
        igWantCode = null;
        String m;
        if ("login".equals(why)) m = "Instagram mein login karo, phir download chalega.";
        else if ("post nahi mili".equals(why)) m = "Screen par koi post / reel / story nahi mili. Post khol kar dobara dabao.";
        else m = "Instagram se file nahi mili (" + why + "). Thodi der baad dobara try karo.";
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(8), dp(20), dp(26));
        col.addView(Ui.label(this, m, 14.5f, Ui.INK, false));
        TextView retry = Ui.chip(this, "Dobara try", true);
        retry.setOnClickListener(v -> openInstaSheet());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(14);
        col.addView(retry, lp);
        sheet.show("Instagram download", col, false, false);
    }

    // ---- download sheet

    private void igPickQ(int q) {
        igQ = q;
        igDlQ = q;
        prefs.edit().putInt("ig_dlq", q).apply();
        renderInstaSheet();
    }

    private void renderInstaSheet() {
        final InstaLite.Post p = igPost;
        if (p == null) return;
        igLoading = false;
        igSheetToken++;
        final long tok = igSheetToken;
        if (igSel >= p.items.size()) igSel = 0;
        final InstaLite.Item cur = p.items.get(igSel);
        final int q = (igQ < 0 && !cur.video) ? 0 : igQ;
        final boolean audio = q < 0;
        final int n = p.items.size();
        final boolean multi = n > 1;
        final int WC = ViewGroup.LayoutParams.WRAP_CONTENT, MP = ViewGroup.LayoutParams.MATCH_PARENT;

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(20));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(20), dp(6), dp(20), dp(10));
        ImageView th = new ImageView(this);
        th.setScaleType(ImageView.ScaleType.CENTER_CROP);
        th.setBackground(Ui.round(Ui.BG, dp(14)));
        th.setClipToOutline(true);
        head.addView(th, new LinearLayout.LayoutParams(dp(72), dp(72)));
        loadThumb(th, cur.thumb.isEmpty() ? p.thumb : cur.thumb, dp(72));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14), 0, 0, 0);
        TextView who = Ui.label(this, "@" + p.user, 16, Ui.INK, true);
        who.setSingleLine(true);
        who.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(who);
        info.addView(Ui.label(this, InstaLite.typeLine(p), 13, Ui.SUB, false));
        final InstaLite.Var cv = audio ? null : InstaLite.chosen(cur, q);
        final String res = audio ? (cur.audio.isEmpty() ? "Sirf awaaz (video se nikalegi)" : "Sirf awaaz (M4A)")
                : InstaLite.resLabel(cv);
        igSizeTv = Ui.label(this, res, 12, Ui.SUB, false);
        info.addView(igSizeTv);
        final String key = InstaLite.doneKey(p, igSel, audio);
        final boolean done = igIsDone(key);
        TextView dn = Ui.label(this, "\u2713 Pehle se download hai", 12, Ui.GREEN, true);
        dn.setVisibility(done ? View.VISIBLE : View.GONE);
        info.addView(dn);
        head.addView(info, new LinearLayout.LayoutParams(0, WC, 1f));
        col.addView(head);

        if (multi) {
            android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(dp(16), dp(2), dp(16), dp(6));
            for (int i = 0; i < n && i < 30; i++) {
                final int idx = i;
                ImageView s = new ImageView(this);
                s.setScaleType(ImageView.ScaleType.CENTER_CROP);
                s.setClipToOutline(true);
                s.setBackground(Ui.stroked(Ui.BG, dp(10), i == igSel ? Ui.ACCENT : Color.TRANSPARENT, dp(2)));
                loadThumb(s, p.items.get(i).thumb, dp(48));
                s.setOnClickListener(v -> {
                    igSel = idx;
                    renderInstaSheet();
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(52), dp(52));
                lp.setMargins(0, 0, dp(8), 0);
                row.addView(s, lp);
            }
            hs.addView(row);
            col.addView(hs, new LinearLayout.LayoutParams(MP, WC));
        }

        col.addView(Ui.section(this, "Quality"));
        Ui.Flow qf = chipFlow();
        for (int qq : InstaLite.QUALITIES) {
            final int fq = qq;
            TextView ch = Ui.chip(this, InstaLite.qualityName(qq), q == qq);
            ch.setOnClickListener(v -> igPickQ(fq));
            qf.addView(ch, new ViewGroup.LayoutParams(WC, WC));
        }
        if (cur.video) {
            TextView ca = Ui.chip(this, InstaLite.qualityName(-1), q < 0);
            ca.setOnClickListener(v -> igPickQ(-1));
            qf.addView(ca, new ViewGroup.LayoutParams(WC, WC));
        }
        col.addView(qf);

        LinearLayout br = new LinearLayout(this);
        br.setOrientation(LinearLayout.HORIZONTAL);
        br.setPadding(dp(20), dp(16), dp(20), 0);
        TextView dl = Ui.label(this, done ? "Dobara download" : (multi ? "Download (" + (igSel + 1) + "/" + n + ")" : "Download"),
                15, Color.WHITE, true);
        dl.setGravity(Gravity.CENTER);
        dl.setBackground(Ui.round(Ui.ACCENT, dp(24)));
        dl.setPadding(dp(10), dp(13), dp(10), dp(13));
        Ui.press(dl);
        dl.setOnClickListener(v -> {
            sheet.hide();
            if (igDownload(p, igSel, q, true)) say("Download shuru \u2B07  " + InstaLite.fileBase(p, igSel));
            else say("Ye download pehle se chal raha hai");
        });
        br.addView(dl, new LinearLayout.LayoutParams(0, WC, 1f));
        if (multi) {
            TextView all = Ui.label(this, "Download all (" + n + ")", 15, Ui.INK, true);
            all.setGravity(Gravity.CENTER);
            all.setBackground(Ui.round(Ui.BG, dp(24)));
            all.setPadding(dp(10), dp(13), dp(10), dp(13));
            Ui.press(all);
            all.setOnClickListener(v -> {
                sheet.hide();
                igDownloadAll(p, q);
            });
            LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(0, WC, 1f);
            alp.leftMargin = dp(10);
            br.addView(all, alp);
        }
        col.addView(br);
        sheet.setOnHidden(() -> {
            igLoading = false;
            igWantCode = null;
        });
        sheet.show("Instagram download", col, true, false);

        // file size (a HEAD request, only if the sheet is still the same one)
        final String sizeUrl = audio ? (cur.audio.isEmpty() ? null : cur.audio) : (cv == null ? null : cv.url);
        if (sizeUrl != null) igFetchSize(sizeUrl, tok, res);
    }

    private void igFetchSize(final String url, final long tok, final String res) {
        new Thread(() -> {
            long len = -1;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestMethod("HEAD");
                c.setConnectTimeout(6000);
                c.setReadTimeout(6000);
                c.setRequestProperty("User-Agent", mobileUa);
                len = c.getContentLengthLong();
            } catch (Throwable ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
            final long sz = len;
            ui.post(() -> {
                if (tok == igSheetToken && igSizeTv != null && sz > 0) {
                    igSizeTv.setText((res.isEmpty() ? "" : res + "  \u2022  ") + "\u2248 " + fmtSize(sz));
                }
            });
        }).start();
    }

    private void loadThumb(final ImageView iv, final String url, final int px) {
        if (url == null || url.isEmpty()) return;
        final String ck = url + "#" + px;
        Bitmap hit = thumbCache.get(ck);
        if (hit != null) {
            iv.setImageBitmap(hit);
            return;
        }
        iv.setTag(url);
        new Thread(() -> {
            Bitmap bm = null;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                c.setRequestProperty("User-Agent", mobileUa);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                try (InputStream in = c.getInputStream()) {
                    byte[] buf = new byte[8192];
                    int k;
                    while ((k = in.read(buf)) > 0) {
                        bo.write(buf, 0, k);
                        if (bo.size() > 700 * 1024) break;           // thumbnails are small; never read a huge file
                    }
                }
                byte[] data = bo.toByteArray();
                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length, o);
                int s = 1;
                while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2;
                o.inJustDecodeBounds = false;
                o.inSampleSize = s;
                o.inPreferredConfig = Bitmap.Config.RGB_565;      // half the memory (old phone)
                bm = android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length, o);
            } catch (Throwable ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
            final Bitmap fb = bm;
            if (fb != null) {
                ui.post(() -> {
                    thumbCache.put(ck, fb);
                    if (url.equals(iv.getTag())) iv.setImageBitmap(fb);
                });
            }
        }).start();
    }

    // ---- download + "already downloaded" list

    private JSONObject igDoneObj() {
        try {
            return new JSONObject(prefs.getString("ig_done", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private boolean igIsDone(String key) {
        JSONObject o = igDoneObj();
        if (!o.has(key)) return false;
        String u = o.optString(key, "");
        if (u.isEmpty()) return true;
        android.database.Cursor cur = null;
        try {
            cur = getContentResolver().query(Uri.parse(u), new String[]{"_id"}, null, null, null);
            return cur != null && cur.moveToFirst();           // the file may have been deleted since
        } catch (Throwable t) {
            return false;
        } finally {
            if (cur != null) cur.close();
        }
    }

    private void igMarkDone(String key, String uri) {
        try {
            JSONObject o = igDoneObj();
            o.remove(key);
            o.put(key, uri == null ? "" : uri);
            while (o.length() > 400) {
                java.util.Iterator<String> it = o.keys();
                if (!it.hasNext()) break;
                o.remove(it.next());
            }
            prefs.edit().putString("ig_done", o.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private boolean igDownload(InstaLite.Post p, int idx, int q, boolean force) {
        if (p == null || idx < 0 || idx >= p.items.size()) return false;
        InstaLite.Item it = p.items.get(idx);
        boolean audio = q < 0 && it.video;
        String key = InstaLite.doneKey(p, idx, audio);
        if (igPending.containsValue(key)) return false;
        if (!force && igIsDone(key)) return false;
        String url, name, ext;
        boolean audioOnly = false;
        if (audio) {
            if (!it.audio.isEmpty()) {
                url = it.audio;
                ext = "m4a";
                name = InstaLite.fileBase(p, idx) + "_audio.m4a";
            } else {                                           // no separate audio stream: the app takes the sound out of the video
                InstaLite.Var v0 = InstaLite.chosen(it, 0);
                if (v0 == null) return false;
                url = v0.url;
                ext = "mp4";
                name = InstaLite.fileBase(p, idx) + "_audio.mp4";
                audioOnly = true;
            }
        } else {
            InstaLite.Var v = InstaLite.chosen(it, q);
            if (v == null) return false;
            url = v.url;
            ext = InstaLite.extOf(url, it.video, false);
            name = InstaLite.fileBase(p, idx) + "." + ext;
        }
        DownloadCenter.Task t = dc.add(url, name, web.getSettings().getUserAgentString(), "https://www.instagram.com/",
                InstaLite.mimeOf(ext), audioOnly);
        stripTask = t;
        igPending.put(t.id, key);
        return true;
    }

    private void igDownloadAll(InstaLite.Post p, int q) {
        int ok = 0, skip = 0;
        for (int i = 0; i < p.items.size(); i++) {
            if (igDownload(p, i, q, false)) ok++;
            else skip++;
        }
        if (ok == 0) say("Sab pehle se download hain \u2713");
        else say(ok + " download shuru \u2B07" + (skip > 0 ? "  (" + skip + " pehle se the)" : ""));
    }

    // ---- Insta Lite panel (address-bar badge / nav button) and the quick chips

    private void openInstagram() {
        userStopped = false;
        showHome(false);
        web.loadUrl("https://www.instagram.com/");
    }

    private void addQualityChips(Ui.Flow f, final boolean story) {
        final int[] caps = {0, 720, 480, 360, 240};
        final ArrayList<TextView> chips = new ArrayList<>();
        for (int cap : caps) {
            final int c = cap;
            final TextView ch = Ui.chip(this, c == 0 ? "Auto" : c + "p", (story ? igSq : igRq) == c);
            ch.setOnClickListener(v -> {
                if (story) igSq = c;
                else igRq = c;
                prefs.edit().putInt(story ? "ig_sq" : "ig_rq", c).apply();
                for (int i = 0; i < chips.size(); i++) Ui.styleChip(chips.get(i), caps[i] == c);
                applyMode();
                pushCfg();
                updateQualityBadge();
                say((story ? "Story" : "Reel") + " quality: " + (c == 0 ? "Auto" : c + "p") + " \u2705"
                        + (c > 0 ? "  Naye videos par lagegi, khuli video ke liye page refresh karo" : ""));
            });
            chips.add(ch);
            f.addView(ch, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }

    /** Chips shared by the menu section "Insta Lite" and the Insta Lite panel. */
    private Ui.Flow instaQuickChips() {
        Ui.Flow f = chipFlow();
        addToggle(f, "Insta Lite", igLite, () -> {
            igLite = !igLite;
            prefs.edit().putBoolean("ig_lite", igLite).apply();
            applyMode();
            pushCfg();
            updateQualityBadge();
            updateChrome();
            say(igLite ? "Insta Lite chalu \u26A1 Instagram halka aur data-saver mode mein" : "Insta Lite band, Instagram normal chalega");
        }, () -> igLite);
        addToggle(f, "Autoplay off", igNoAuto, () -> {
            igNoAuto = !igNoAuto;
            prefs.edit().putBoolean("ig_noauto", igNoAuto).apply();
            applyMode();
            pushCfg();
            say(igNoAuto ? "Autoplay band: video tap karne par hi chalegi" : "Autoplay wapas chalu");
        }, () -> igNoAuto);
        addToggle(f, "Preview off", igNoPrev, () -> {
            igNoPrev = !igNoPrev;
            prefs.edit().putBoolean("ig_noprev", igNoPrev).apply();
            applyMode();
            pushCfg();
            say(igNoPrev ? "Preview band: grid / explore ke chhote clips nahi chalenge" : "Preview wapas chalu");
        }, () -> igNoPrev);
        addToggle(f, "Images off", imgOff, () -> {
            imgOff = !imgOff;
            prefs.edit().putBoolean("imgoff", imgOff).apply();
            applyMode();
            pushCfg();
            say(imgOff ? "Images band, ab photos load nahi hongi" : "Images wapas chalu");
        }, () -> imgOff);
        addToggle(f, "Data saver", saverOn, () -> {
            saverOn = !saverOn;
            prefs.edit().putBoolean("saver", saverOn).apply();
            applyMode();
            pushCfg();
            say(saverOn ? "Data saver chalu \uD83D\uDCC9 (fonts, GIF aur auto-preview video band)" : "Data saver band");
        }, () -> saverOn);
        final TextView rq = Ui.chip(this, "Reel: " + (igRq == 0 ? "Auto" : igRq + "p"), igRq > 0 && igLite);
        rq.setOnClickListener(v -> showInstaPanel());
        f.addView(rq, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final TextView sq = Ui.chip(this, "Story: " + (igSq == 0 ? "Auto" : igSq + "p"), igSq > 0 && igLite);
        sq.setOnClickListener(v -> showInstaPanel());
        f.addView(sq, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        addToggle(f, "Insta par seedha kholo", igStart, () -> {
            igStart = !igStart;
            prefs.edit().putBoolean("ig_start", igStart).apply();
            say(igStart ? "Ab app kholte hi seedha Instagram khulega" : "Ab app kholte hi Home screen aayegi");
        }, () -> igStart);
        addToggle(f, "Nav bar auto-hide", navAuto, () -> {
            navAuto = !navAuto;
            prefs.edit().putBoolean("nav_auto", navAuto).apply();
            navPeek = false;
            updateChrome();
            say(navAuto ? "Site khulte hi neeche ka bar chhup jayega, download button ke upar wale chhote tab se wapas aayega"
                    : "Neeche ka bar hamesha dikhega");
        }, () -> navAuto);
        return f;
    }

    private void showInstaPanel() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(22));
        TextView st = Ui.label(this, igNow ? (igLite ? "Insta Lite chalu \u26A1  Instagram halka aur data-saver mode mein chal raha hai"
                : "Insta Lite band hai, Instagram normal chal raha hai")
                : "Instagram kholte hi Insta Lite apne aap chalu ho jata hai", 13, Ui.SUB, false);
        st.setPadding(dp(20), dp(4), dp(20), dp(4));
        col.addView(st);
        col.addView(Ui.section(this, "Reel / feed quality"));
        Ui.Flow rf = chipFlow();
        addQualityChips(rf, false);
        col.addView(rf);
        col.addView(Ui.section(this, "Story quality"));
        Ui.Flow sf = chipFlow();
        addQualityChips(sf, true);
        col.addView(sf);
        col.addView(Ui.section(this, "Quick"));
        col.addView(instaQuickChips());
        col.addView(Ui.section(this, "Data"));
        Ui.Flow df = chipFlow();
        final TextView used = Ui.chip(this, "Is session mein: " + fmtData(igBytes), false);
        used.setOnClickListener(v -> used.setText("Is session mein: " + fmtData(igBytes)));
        df.addView(used, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        addChip(df, "Counter zero", false, () -> {
            igBytes = 0;
            igLastRx = rxBytes();
            updateDataPill();
            say("Instagram data counter zero ho gaya");
        });
        addToggle(df, "Counter dikhao", igCounter, () -> {
            igCounter = !igCounter;
            prefs.edit().putBoolean("ig_counter", igCounter).apply();
            updateDataPill();
        }, () -> igCounter);
        col.addView(df);
        Ui.Flow go = chipFlow();
        addChip(go, "Instagram kholo", false, this::openInstagram);
        col.addView(go);
        sheet.setOnHidden(null);
        sheet.show("Insta Lite", col, true, true);
    }

    // ---- home tile

    private View instaTile() {
        FrameLayout badge = new FrameLayout(this);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFF58529, 0xFFDD2A7B, 0xFF8134AF});
        g.setCornerRadius(dp(18));
        badge.setBackground(g);
        badge.addView(Ui.icon(this, Ic.INSTA, Color.WHITE), new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        View t = tileBox(badge, "Insta Lite");
        t.setOnClickListener(v -> openInstagram());
        t.setOnLongClickListener(v -> {
            showInstaPanel();
            return true;
        });
        return t;
    }

    // ---- bottom bar auto-hide + floating things

    private void toggleNavPeek() {
        navPeek = !navPeek;
        ui.removeCallbacks(navHideRun);
        if (navBox != null) navBox.setTranslationY(0f);
        updateChrome();
        if (navPeek) {
            if (navBox != null) {
                navBox.setTranslationY(dp(70));
                navBox.animate().translationY(0f).setDuration(200).start();
            }
            ui.postDelayed(navHideRun, 7000);
        }
    }

    private void setBottom(View v, int dpVal) {
        if (v == null) return;
        ViewGroup.LayoutParams p = v.getLayoutParams();
        if (!(p instanceof FrameLayout.LayoutParams)) return;
        FrameLayout.LayoutParams l = (FrameLayout.LayoutParams) p;
        int m = dp(dpVal);
        if (l.bottomMargin != m) {
            l.bottomMargin = m;
            v.setLayoutParams(l);
        }
    }

    /** Floating things sit above the bottom bar; with the bar hidden they drop down (above Instagram's own bar on Instagram). */
    private void layoutFloating(boolean navShown) {
        if (fab == null) return;
        int base = navShown ? 92 : (igNow ? 66 : 24);
        setBottom(fab, base);
        setBottom(navHandle, base + 58 + 6);
        setBottom(dataPill, base);
        setBottom(pill, base);
        setBottom(barBox, Math.max(20, base - 6));
        syncHandle();
    }

    private void syncHandle() {
        if (navHandle == null || fab == null || content == null) return;
        float ty = fab.getTranslationY();
        ViewGroup.LayoutParams lp = navHandle.getLayoutParams();
        int bm = lp instanceof FrameLayout.LayoutParams ? ((FrameLayout.LayoutParams) lp).bottomMargin : dp(100);
        float top = content.getHeight() - bm - dp(24) + ty;
        if (content.getHeight() > 0 && top < dp(4)) ty += dp(58 + 30);   // button dragged to the very top: the tab goes below it
        navHandle.setTranslationX(fab.getTranslationX());
        navHandle.setTranslationY(ty);
    }

    private void updateLead() {
        if (urlLead == null) return;
        boolean back = !homeShown;
        if (back != leadBack) {
            leadBack = back;
            urlLead.setImageDrawable(new Ic(back ? Ic.BACK : Ic.SEARCH, Ui.SUB));
        }
    }

    private void makeDraggable(final View handle, final View moving) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            private float sx, sy, tx, ty;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        tx = moving.getTranslationX();
                        ty = moving.getTranslationY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                        if (!moved && Math.hypot(dx, dy) > dp(8)) moved = true;
                        if (moved) {
                            View par = (View) moving.getParent();
                            float nx = tx + dx, ny = ty + dy;
                            if (par != null) {
                                nx = Math.max(-moving.getLeft(), Math.min(par.getWidth() - moving.getRight(), nx));
                                ny = Math.max(-moving.getTop(), Math.min(par.getHeight() - moving.getBottom(), ny));
                            }
                            moving.setTranslationX(nx);
                            moving.setTranslationY(ny);
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (!moved) say("Instagram par is session mein itna data laga (\u27F3 dabao = zero)");
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    // ---- Instagram data counter (real network bytes of this app while an Instagram page is open)

    private final Runnable igTick = new Runnable() {
        @Override
        public void run() {
            long cur = rxBytes();
            if (cur >= 0) {
                if (igNow && igLastRx >= 0 && cur >= igLastRx) igBytes += cur - igLastRx;
                igLastRx = cur;
            }
            updateDataPill();
            ui.postDelayed(this, 2000);
        }
    };

    private void updateDataPill() {
        if (dataPill == null) return;
        boolean show = igNow && igCounter && !homeShown && !kbOpen && !landFs && !onPlayer && fsView == null;
        dataPill.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            String t = "IG " + fmtData(igBytes);
            if (!t.contentEquals(dataTv.getText())) dataTv.setText(t);
        }
    }
}
