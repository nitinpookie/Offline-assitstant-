package com.fastlink.browser;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Insta Lite Pro (v5.9): the parts that do not need any Android UI.
 * <ul>
 *   <li>which requests an Instagram page may do while Insta Lite is ON (analytics, logging, prefetch, web fonts ... are answered
 *   with an empty reply; login, cookies, feed, DM and posting are never touched)</li>
 *   <li>the post model that flb_insta.js sends to the app (photo / video / reel / carousel / story / highlight / profile)</li>
 *   <li>quality picking (Original / 720p / 480p / 360p), file names, labels</li>
 * </ul>
 * Everything here is plain Java (only org.json from Android), so it can be tested on a normal JVM.
 */
final class InstaLite {

    private InstaLite() {
    }

    // ------------------------------------------------------------------ hosts

    static String hostOf(String url) {
        if (url == null) return "";
        int s = url.indexOf("://");
        if (s < 0) return "";
        s += 3;
        int e = url.length();
        for (int i = s; i < url.length(); i++) {
            char c = url.charAt(i);
            if (c == '/' || c == '?' || c == '#') {
                e = i;
                break;
            }
        }
        String a = url.substring(s, e);
        int at = a.lastIndexOf('@');
        if (at >= 0) a = a.substring(at + 1);
        int col = a.indexOf(':');
        if (col >= 0) a = a.substring(0, col);
        return a.toLowerCase(Locale.US);
    }

    static boolean isIgHost(String h) {
        if (h == null) return false;
        return h.equals("instagram.com") || h.endsWith(".instagram.com");
    }

    static boolean isIgUrl(String url) {
        return isIgHost(hostOf(url));
    }

    // ------------------------------------------------------------------ request rules (Insta Lite ON)

    static final int ALLOW = 0, STUB = 1, NO_CONTENT = 2, NOT_FOUND = 3;

    /** Third-party analytics / pixels / tag managers: never needed to browse Instagram. */
    private static final String[] TRACK_HOSTS = {
            "connect.facebook.net", "googletagmanager.com", "google-analytics.com", "analytics.google.com",
            "sentry.io", "browser-intake-datadoghq.com", "bat.bing.com", "analytics.tiktok.com",
            "app-measurement.com", "scorecardresearch.com", "hotjar.com", "clarity.ms"
    };

    /** First-party logging / telemetry endpoints (POST beacons). Login, feed, DM, upload are NOT in this list. */
    private static final String[] LOG_PATHS = {
            "/logging/", "/ajax/bz", "/api/v1/logging/", "/logging_client_events", "/ajax/qm/",
            "/ajax/pigeon", "/api/v1/web/logging/"
    };

    private static boolean hostIs(String h, String d) {
        return h.equals(d) || h.endsWith("." + d);
    }

    /**
     * @param purpose value of the Purpose / Sec-Purpose request header (may be null)
     * @return ALLOW = let it through; STUB = harmless empty script / image / json; NO_CONTENT = 204; NOT_FOUND = 404
     */
    static int rule(String host, String path, boolean mainFrame, String purpose) {
        if (mainFrame || host == null) return ALLOW;
        String h = host.toLowerCase(Locale.US);
        String p = path == null ? "" : path.toLowerCase(Locale.US);
        for (String t : TRACK_HOSTS) {
            if (hostIs(h, t)) return STUB;
        }
        if (hostIs(h, "facebook.com") && (p.equals("/tr") || p.equals("/tr/") || p.startsWith("/tr/"))) return STUB;
        if (isIgHost(h) || hostIs(h, "facebook.com")) {
            for (String lp : LOG_PATHS) {
                if (p.startsWith(lp)) return NO_CONTENT;
            }
        }
        if (h.equals("graph.instagram.com") && p.startsWith("/logging")) return NO_CONTENT;
        if (purpose != null) {
            String q = purpose.toLowerCase(Locale.US);
            if (q.contains("prefetch") || q.contains("prerender") || q.contains("preview")) return NO_CONTENT;
        }
        if (p.endsWith(".woff2") || p.endsWith(".woff") || p.endsWith(".ttf") || p.endsWith(".otf") || p.endsWith(".eot")) {
            return NOT_FOUND;                        // system fonts are used instead
        }
        return ALLOW;
    }

    // ------------------------------------------------------------------ model

    static final class Var {
        final String url;
        final int w, h;

        Var(String url, int w, int h) {
            this.url = url;
            this.w = w;
            this.h = h;
        }

        /** Quality number as people say it: the short side (720x1280 = "720p"). 0 = unknown. */
        int q() {
            if (w > 0 && h > 0) return Math.min(w, h);
            return Math.max(w, h);
        }
    }

    static final class Item {
        boolean video;
        String id = "";
        String thumb = "";
        int dur;                                     // seconds, 0 = unknown
        String audio = "";                           // audio-only stream (DASH), "" = none
        final List<Var> vs = new ArrayList<>();      // video files, biggest first
        final List<Var> im = new ArrayList<>();      // picture files, biggest first
    }

    static final class Post {
        String type = "photo";                       // photo video reel carousel story highlight profile
        String user = "instagram";
        String code = "";
        String thumb = "";
        final List<Item> items = new ArrayList<>();
    }

    private static final Comparator<Var> BIG_FIRST = (a, b) -> Integer.compare(b.q(), a.q());

    private static List<Var> vars(JSONArray a) {
        List<Var> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            JSONArray v = a.optJSONArray(i);
            if (v == null) continue;
            String u = v.optString(0, "");
            if (u.isEmpty()) continue;
            boolean dup = false;
            for (Var x : out) {
                if (x.url.equals(u)) {
                    dup = true;
                    break;
                }
            }
            if (!dup) out.add(new Var(u, v.optInt(1, 0), v.optInt(2, 0)));
        }
        Collections.sort(out, BIG_FIRST);
        return out;
    }

    /** Parses the JSON that flb_insta.js sends. Returns null when it is unusable. */
    static Post parse(String json) {
        try {
            JSONObject o = new JSONObject(json);
            Post p = new Post();
            p.type = o.optString("t", "photo");
            p.user = o.optString("u", "instagram");
            p.code = o.optString("c", "");
            p.thumb = o.optString("th", "");
            JSONArray a = o.optJSONArray("items");
            if (a == null) return null;
            for (int i = 0; i < a.length() && i < 60; i++) {
                JSONObject x = a.optJSONObject(i);
                if (x == null) continue;
                Item it = new Item();
                it.video = "v".equals(x.optString("k"));
                it.id = x.optString("id", "");
                it.thumb = x.optString("th", "");
                it.dur = (int) Math.round(x.optDouble("d", 0));
                it.audio = x.optString("au", "");
                it.vs.addAll(vars(x.optJSONArray("vs")));
                it.im.addAll(vars(x.optJSONArray("im")));
                if (it.thumb.isEmpty() && !it.im.isEmpty()) it.thumb = smallest(it.im, 240).url;
                if ((it.video && it.vs.isEmpty()) || (!it.video && it.im.isEmpty())) continue;
                p.items.add(it);
            }
            if (p.items.isEmpty()) return null;
            if (p.thumb.isEmpty()) p.thumb = p.items.get(0).thumb;
            return p;
        } catch (Exception e) {
            return null;
        }
    }

    /** Smallest picture that is still at least {@code min} pixels (else the biggest one). */
    static Var smallest(List<Var> l, int min) {
        Var best = null;
        for (Var v : l) {
            if (v.q() >= min && (best == null || v.q() < best.q())) best = v;
        }
        return best != null ? best : (l.isEmpty() ? null : l.get(0));
    }

    // ------------------------------------------------------------------ quality

    /** Download qualities shown as chips. 0 = Original, -1 = Audio only. */
    static final int[] QUALITIES = {0, 720, 480, 360};

    static String qualityName(int q) {
        return q == 0 ? "Original" : q < 0 ? "Audio M4A" : q + "p";
    }

    /**
     * Best file for a quality: the biggest one that is not above {@code cap}; if every file is bigger than the cap the
     * smallest one is used. cap 0 = the biggest file.
     */
    static Var pick(List<Var> list, int cap) {
        if (list == null || list.isEmpty()) return null;
        List<Var> l = new ArrayList<>(list);
        Collections.sort(l, BIG_FIRST);
        if (cap <= 0) return l.get(0);
        for (Var v : l) {
            if (v.q() > 0 && v.q() <= cap) return v;
        }
        return l.get(l.size() - 1);
    }

    static Var chosen(Item it, int cap) {
        return it.video ? pick(it.vs, cap) : pick(it.im, cap);
    }

    static String resLabel(Var v) {
        if (v == null) return "";
        return v.w > 0 && v.h > 0 ? v.w + "\u00D7" + v.h : "";
    }

    // ------------------------------------------------------------------ names / labels

    static String safe(String s) {
        String r = s == null ? "" : s.replaceAll("[^A-Za-z0-9._-]+", "_");
        if (r.length() > 40) r = r.substring(0, 40);
        return r.isEmpty() ? "x" : r;
    }

    static String extOf(String url, boolean video, boolean audio) {
        if (audio) return "m4a";
        if (video) return "mp4";
        String p = url == null ? "" : url;
        int q = p.indexOf('?');
        if (q >= 0) p = p.substring(0, q);
        p = p.toLowerCase(Locale.US);
        if (p.endsWith(".webp")) return "webp";
        if (p.endsWith(".png")) return "png";
        return "jpg";
    }

    static String mimeOf(String ext) {
        switch (ext) {
            case "m4a":
                return "audio/mp4";
            case "mp4":
                return "video/mp4";
            case "webp":
                return "image/webp";
            case "png":
                return "image/png";
            default:
                return "image/jpeg";
        }
    }

    /** Name without extension: username + shortcode (+ slide number). Quality is not part of it on purpose (no double downloads). */
    static String fileBase(Post p, int idx) {
        String u = safe(p.user);
        Item it = idx >= 0 && idx < p.items.size() ? p.items.get(idx) : null;
        switch (p.type) {
            case "story":
                return u + "_story_" + safe(it != null && !it.id.isEmpty() ? it.id : p.code.replaceFirst("^s", "") + "_" + (idx + 1));
            case "highlight":
                return u + "_highlight_" + safe(it != null && !it.id.isEmpty() ? it.id : p.code.replaceFirst("^h", "") + "_" + (idx + 1));
            case "profile":
                return u + "_profile";
            default:
                return u + "_" + safe(p.code) + (p.items.size() > 1 ? "_" + (idx + 1) : "");
        }
    }

    static String fileName(Post p, int idx, boolean audio) {
        Item it = p.items.get(idx);
        Var v = chosen(it, 0);
        return fileBase(p, idx) + (audio ? "_audio" : "") + "." + extOf(v == null ? "" : v.url, it.video, audio);
    }

    /** Key for the "already downloaded" list. Same for every quality of the same file. */
    static String doneKey(Post p, int idx, boolean audio) {
        return fileBase(p, idx) + (audio ? "#a" : "");
    }

    static String fmtDur(int s) {
        if (s <= 0) return "";
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    /** "Reel  •  0:23", "Carousel  •  5 items" ... */
    static String typeLine(Post p) {
        int n = p.items.size();
        String bullet = "  \u2022  ";
        switch (p.type) {
            case "reel":
                return "Reel" + (p.items.get(0).dur > 0 ? bullet + fmtDur(p.items.get(0).dur) : "");
            case "video":
                return "Video" + (p.items.get(0).dur > 0 ? bullet + fmtDur(p.items.get(0).dur) : "");
            case "carousel":
                return "Carousel" + bullet + n + " items";
            case "story":
                return n > 1 ? "Story" + bullet + n + " items" : (p.items.get(0).video ? "Story (video)" : "Story (photo)");
            case "highlight":
                return "Highlight" + bullet + n + " items";
            case "profile":
                return "Profile photo";
            default:
                return "Photo";
        }
    }

    static boolean hasAudio(Post p, int idx) {
        return idx >= 0 && idx < p.items.size() && p.items.get(idx).video;
    }

    static String fmtSize(long b) {
        if (b <= 0) return "";
        if (b < 1024L * 1024L) return Math.max(1, b / 1024L) + " KB";
        return String.format(Locale.US, "%.1f MB", b / 1048576.0);
    }
}
