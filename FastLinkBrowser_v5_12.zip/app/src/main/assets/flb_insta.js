/* FastLink Instagram helper (v5.9 "Insta Lite Pro"). Runs only on instagram.com and only uses the person's OWN login session.
   v5.1 part (kept): finds the post / reel / story that is on screen and asks Instagram's own web API (the same call the website
   makes) for the original files. v5.9 adds: Insta Lite rules (autoplay off, small images, no animations, no prefetch), a quality
   cap on the video lists Instagram's own pages receive, richer post info for the app's download sheet (type, thumbnail, qualities,
   audio, carousel / story / highlight / profile photo) and a small download chip on every feed post.
   Needs: logged in to Instagram inside this browser. Public + followed-private posts both work. */
var IGH = (function () {
  if (!/(^|\.)instagram\.com$/.test(location.hostname)) return 0;
  var D = document, TOP = (W.top === W);
  var NSI = W.setInterval, NST = W.setTimeout;      // natives (the core script that follows patches the timers)
  var ABC = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  var cache = {}, cacheKeys = [], busy = {}, lastKey = '', loginSaid = 0, want = '';
  var RESERVED = /^(explore|reels|reel|p|tv|stories|direct|accounts|about|legal|privacy|directory|web|api|challenge|emails|press|developer|oauth|nametag|session|ads|lite|download|download_app|qr|shop|topics|locations|tags|ar|igtv|business|creators|safety|terms|cookie|help)$/i;

  function idOf(code) {                         // shortcode (the part in /p/XXXX/) -> numeric media id
    try {
      if (code.length > 28) code = code.slice(0, code.length - 28);
      var n = BigInt(0), b = BigInt(64);
      for (var i = 0; i < code.length; i++) {
        var k = ABC.indexOf(code.charAt(i));
        if (k < 0) return '';
        n = n * b + BigInt(k);
      }
      return n.toString();
    } catch (e) { return ''; }
  }
  function cookie(n) {
    var m = D.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }
  function short(w, h) { w = w | 0; h = h | 0; return (w > 0 && h > 0) ? Math.min(w, h) : Math.max(w, h); }
  function capFor(story) { return C.il ? ((story ? C.sq : C.rq) | 0) : (C.vq | 0); }
  function storyPath() { return /^\/stories\//.test(location.pathname); }

  /* ================================================================ quality cap (JSON that Instagram's own page receives) */
  function capVersions(arr, cap) {                // keep files up to cap (short side); if all are bigger keep the smallest
    if (!cap || !arr || arr.length < 2) return arr;
    var keep = [], low = null, i, q;
    for (i = 0; i < arr.length; i++) {
      var v = arr[i]; if (!v) continue;
      q = short(v.width, v.height);
      if (q > 0 && q <= cap) keep.push(v);
      if (!low || (q > 0 && q < short(low.width, low.height))) low = v;
    }
    if (!keep.length && low) keep.push(low);
    return keep.length === arr.length ? arr : keep;
  }
  function capDash(xml, cap) {                    // same job as VideoCap.capDash in the app
    if (!cap || typeof xml !== 'string') return xml;
    return xml.replace(/<AdaptationSet\b[\s\S]*?<\/AdaptationSet>/g, function (set) {
      var reps = [], m, re = /<Representation\b[^>]*?(?:\/>|>[\s\S]*?<\/Representation>)/g;
      while ((m = re.exec(set))) {
        var h = /\sheight="(\d+)"/.exec(m[0]), w = /\swidth="(\d+)"/.exec(m[0]);
        reps.push({ s: m.index, e: m.index + m[0].length, q: short(w ? +w[1] : 0, h ? +h[1] : 0) });
      }
      var withQ = 0, fit = 0, low = 1e9, i;
      for (i = 0; i < reps.length; i++) {
        if (reps[i].q > 0) { withQ++; if (reps[i].q <= cap) fit++; if (reps[i].q < low) low = reps[i].q; }
      }
      if (withQ < 2 || fit === withQ) return set;
      var out = '', pos = 0;
      for (i = 0; i < reps.length; i++) {
        var r = reps[i], remove = r.q > 0 && (fit > 0 ? r.q > cap : r.q !== low);
        if (remove) { out += set.slice(pos, r.s); pos = r.e; }
      }
      return out + set.slice(pos);
    });
  }

  /* ================================================================ post model (what the app's download sheet shows) */
  function vlist(m) {
    var a = m.video_versions || [], out = [], seen = {};
    for (var i = 0; i < a.length; i++) {
      var v = a[i];
      if (v && v.url && !seen[v.url]) { seen[v.url] = 1; out.push([v.url, v.width | 0, v.height | 0]); }
    }
    out.sort(function (x, y) { return short(y[1], y[2]) - short(x[1], x[2]); });
    return out;
  }
  function ilist(m) {
    var c = (m.image_versions2 && m.image_versions2.candidates) || [], out = [], seen = {};
    for (var i = 0; i < c.length; i++) {
      var v = c[i];
      if (v && v.url && !seen[v.url]) { seen[v.url] = 1; out.push([v.url, v.width | 0, v.height | 0]); }
    }
    out.sort(function (x, y) { return short(y[1], y[2]) - short(x[1], x[2]); });
    return out;
  }
  function thumbOf(im) {                          // smallest picture that is still >= 240 px
    var best = null, i;
    for (i = 0; i < im.length; i++) {
      var q = short(im[i][1], im[i][2]);
      if (q >= 240 && (!best || q < short(best[1], best[2]))) best = im[i];
    }
    return best ? best[0] : (im.length ? im[0][0] : '');
  }
  function audioOf(m) {                           // audio-only stream out of the DASH manifest (Instagram keeps it separate)
    var x = m && m.video_dash_manifest;
    if (typeof x !== 'string' || x.length < 50) return '';
    var sets = x.match(/<AdaptationSet\b[\s\S]*?<\/AdaptationSet>/g) || [], bestU = '', bestB = -1;
    for (var i = 0; i < sets.length; i++) {
      if (!/contentType="audio"|mimeType="audio\//.test(sets[i].slice(0, 500))) continue;
      var re = /<Representation\b[^>]*?bandwidth="(\d+)"[^>]*>[\s\S]*?<BaseURL>([^<]+)<\/BaseURL>/g, mm;
      while ((mm = re.exec(sets[i]))) {
        var b = +mm[1];
        if (b > bestB) { bestB = b; bestU = mm[2].replace(/&amp;/g, '&'); }
      }
    }
    return /^https?:/.test(bestU) ? bestU : '';
  }
  function itemOf(m) {
    var vs = vlist(m), im = ilist(m), isV = vs.length > 0 && m.media_type !== 1;
    var o = { k: isV ? 'v' : 'i', id: String(m.pk || m.id || ''), th: thumbOf(im), vs: isV ? vs : [], im: im };
    if (isV) {
      o.d = +m.video_duration || 0;
      var a = audioOf(m);
      if (a) o.au = a;
    }
    return o;
  }
  function modelOf(it, kind) {                    // kind: reel / story / highlight / '' (from the page address)
    var user = (it.user && it.user.username) || (it.owner && it.owner.username) || 'instagram';
    var items = [], t;
    if (it.carousel_media && it.carousel_media.length) {
      for (var i = 0; i < it.carousel_media.length; i++) {
        var x = itemOf(it.carousel_media[i]);
        if (x.vs.length || x.im.length) items.push(x);
      }
      t = 'carousel';
    } else {
      var one = itemOf(it);
      if (one.vs.length || one.im.length) items.push(one);
      t = kind || (one.k === 'v' ? (it.product_type === 'clips' ? 'reel' : 'video') : 'photo');
    }
    if (!items.length) return null;
    return { t: t, u: user, c: it.code || String(it.pk || it.id || ''), th: items[0].th, items: items };
  }
  function remember(code, model) {
    if (!model) return;
    if (!cache[code]) { cacheKeys.push(code); if (cacheKeys.length > 80) delete cache[cacheKeys.shift()]; }
    cache[code] = model;
  }

  /* ================================================================ Instagram's own JSON: index + cap (fetch / XHR of the page) */
  var WANT = /\/api\/v1\/(feed|clips|media|discover|stories|highlights|reels|users|tags|locations|fbsearch)|\/graphql\/query|\/api\/graphql/;
  var STORYKEY = /reels_media|story|stories|highlight|reel_items/i;
  var nodes = 0;
  function walk(o, story, depth) {                // index every post once (original quality), then cap the video lists
    if (!o || typeof o !== 'object' || depth > 28 || nodes > 400000) return false;
    var ch = false, i, k;
    nodes++;
    if (Array.isArray(o)) {
      for (i = 0; i < o.length; i++) { if (o[i] && typeof o[i] === 'object' && walk(o[i], story, depth + 1)) ch = true; }
      return ch;
    }
    if ((o.video_versions || o.image_versions2 || o.carousel_media) && (o.user || o.owner || o.pk)) {
      try {
        if (o.code) remember(o.code, modelOf(o, ''));
        else if (story && o.pk) remember('s' + o.pk, modelOf(o, 'story'));
      } catch (e) {}
    }
    var cap = capFor(story);
    if (cap) {
      if (o.video_versions && Array.isArray(o.video_versions)) {
        var nv = capVersions(o.video_versions, cap);
        if (nv !== o.video_versions) { o.video_versions = nv; ch = true; }
      }
      if (typeof o.video_dash_manifest === 'string') {
        var nd = capDash(o.video_dash_manifest, cap);
        if (nd !== o.video_dash_manifest) { o.video_dash_manifest = nd; ch = true; }
      }
    }
    for (k in o) {
      var v = o[k];
      if (v && typeof v === 'object' && walk(v, story || STORYKEY.test(k), depth + 1)) ch = true;
    }
    return ch;
  }
  function rewriteText(t, url, body) {
    if (typeof t !== 'string' || t.length < 20 || t.length > 4000000 || t.charCodeAt(0) !== 123) return t;
    if (t.indexOf('"video_versions"') < 0 && t.indexOf('"video_dash_manifest"') < 0 && t.indexOf('"image_versions2"') < 0) return t;
    var j;
    try { j = JSON.parse(t); } catch (e) { return t; }
    nodes = 0;
    var story = /reels_media|stories|highlight/i.test(url || '') || /Stor|Highlight/.test(body || '');
    var changed = false;
    try { changed = walk(j, story, 0); } catch (e) { return t; }
    if (!changed) return t;
    try { return JSON.stringify(j); } catch (e) { return t; }
  }
  var OF = W.fetch;
  if (TOP && OF && !OF.__flbi) {
    var nf = function (input, init) {
      var p = OF.apply(this, arguments), url = '';
      try { url = typeof input === 'string' ? input : ((input && input.url) || ''); } catch (e) {}
      if (!WANT.test(url)) return p;
      var body = '';
      try { body = init && typeof init.body === 'string' ? init.body.slice(0, 600) : ''; } catch (e) {}
      return p.then(function (r) {
        try {
          var ct = (r.headers && r.headers.get && r.headers.get('content-type')) || '';
          if (!r.ok || ct.indexOf('json') < 0) return r;
          return r.clone().text().then(function (t) {
            var o = rewriteText(t, url, body);
            if (o === t) return r;
            return new Response(o, { status: r.status, statusText: r.statusText, headers: r.headers });
          }, function () { return r; });
        } catch (e) { return r; }
      });
    };
    try { nf.__flbi = 1; W.fetch = nf; } catch (e) {}
  }
  var XP = W.XMLHttpRequest && W.XMLHttpRequest.prototype;
  if (TOP && XP && !XP.__flbi) {
    try {
      var xo = XP.open, xs = XP.send;
      XP.open = function (m, u) { try { this.__flbu = String(u); } catch (e) {} return xo.apply(this, arguments); };
      XP.send = function (b) { try { if (typeof b === 'string') this.__flbb = b.slice(0, 600); } catch (e) {} return xs.apply(this, arguments); };
      ['responseText', 'response'].forEach(function (n) {
        var d = Object.getOwnPropertyDescriptor(XP, n);
        if (!d || !d.get) return;
        Object.defineProperty(XP, n, {
          configurable: true, enumerable: d.enumerable,
          get: function () {
            var v = d.get.call(this);
            try {
              if (this.readyState !== 4 || typeof v !== 'string' || !this.__flbu || !WANT.test(this.__flbu)) return v;
              if (this.__flbT === v) return this.__flbR;
              var r = rewriteText(v, this.__flbu, this.__flbb);
              this.__flbT = v; this.__flbR = r;
              return r;
            } catch (e) { return v; }
          }
        });
      });
      XP.__flbi = 1;
    } catch (e) {}
  }

  /* ================================================================ Insta Lite: small pictures, autoplay off, no animations */
  var HI = W.HTMLImageElement && W.HTMLImageElement.prototype;
  function liteSet(v) {                           // srcset -> the smallest candidate that is still ~480 px wide
    try {
      if (!C.il || typeof v !== 'string' || v.indexOf(',') < 0) return v;
      var parts = v.split(/,\s+/), c = [], i;
      for (i = 0; i < parts.length; i++) {
        var s = parts[i].trim(), sp = s.lastIndexOf(' ');
        if (sp < 1) continue;
        var d = s.slice(sp + 1), w = /w$/.test(d) ? parseInt(d, 10) : 0;
        if (w > 0) c.push({ u: s.slice(0, sp), w: w });
      }
      if (c.length < 2) return v;
      var pick = null, big = c[0];
      for (i = 0; i < c.length; i++) {
        if (c[i].w > big.w) big = c[i];
        if (c[i].w >= 480 && (!pick || c[i].w < pick.w)) pick = c[i];
      }
      pick = pick || big;
      return pick.u + ' ' + pick.w + 'w';
    } catch (e) { return v; }
  }
  if (TOP && HI) {
    try {
      var sd = Object.getOwnPropertyDescriptor(HI, 'srcset'), sa = HI.setAttribute;
      var lite = function (img, v) {
        if (!C.il || img.__flbUp) return v;
        var s = liteSet(v);
        if (s !== v) { img.__flbFull = v; }
        try { if (img.loading !== 'lazy') img.loading = 'lazy'; img.decoding = 'async'; } catch (e) {}
        return s;
      };
      if (sd && sd.set) {
        Object.defineProperty(HI, 'srcset', {
          configurable: true, enumerable: sd.enumerable, get: sd.get,
          set: function (v) { sd.set.call(this, lite(this, v)); }
        });
      }
      HI.setAttribute = function (n, v) {         // React sets srcSet through setAttribute
        try { if (typeof n === 'string' && n.toLowerCase() === 'srcset') v = lite(this, v); } catch (e) {}
        return sa.call(this, n, v);
      };
      D.addEventListener('click', function (ev) { // tap on a small picture -> the full one loads
        try {
          if (!C.il || !D.elementsFromPoint) return;
          var l = D.elementsFromPoint(ev.clientX, ev.clientY);
          for (var i = 0; i < l.length && i < 6; i++) {
            var im = l[i];
            if (im.tagName === 'IMG' && im.__flbFull && !im.__flbUp) {
              im.__flbUp = 1;
              if (sd && sd.set) sd.set.call(im, im.__flbFull); else sa.call(im, 'srcset', im.__flbFull);
              break;
            }
          }
        } catch (e) {}
      }, true);
    } catch (e) {}
  }

  var lastClick = 0;                              // only a real tap (click) may start a video; scrolling never does
  ['click', 'keydown'].forEach(function (n) {
    D.addEventListener(n, function (ev) { if (ev.isTrusted) lastClick = Date.now(); }, true);
  });
  D.addEventListener('loadstart', function (ev) { try { if (ev.target) ev.target.__flbU = 0; } catch (e) {} }, true);
  function isPrev(v) {                            // grid tile / small muted clip = preview
    try {
      if (v.closest && v.closest('a[href*="/reel/"],a[href*="/p/"]')) return true;
      var r = v.getBoundingClientRect();
      return r.width < W.innerWidth * 0.6 || r.height < W.innerHeight * 0.25;
    } catch (e) { return false; }
  }
  var HM = W.HTMLMediaElement && W.HTMLMediaElement.prototype, p0 = HM && HM.play;
  if (TOP && p0) {
    HM.play = function () {
      try {
        if (C.il && this.tagName === 'VIDEO' && !storyPath()) {
          if (Date.now() - lastClick < 1500) {
            this.__flbU = 1;                      // one video at a time: the others stop
            var all = D.querySelectorAll('video');
            for (var i = 0; i < all.length; i++) { if (all[i] !== this && !all[i].paused) { try { all[i].pause(); } catch (e) {} } }
          } else if (!this.__flbU) {
            var pre = isPrev(this);
            if (pre ? !C.pv : !C.ap) {
              try { this.pause(); } catch (e) {}
              return Promise.reject(new DOMException('Autoplay band (Insta Lite)', 'NotAllowedError'));
            }
          }
        }
      } catch (e) {}
      return p0.apply(this, arguments);
    };
  }

  var styleOn = 0;
  function injectStyle() {
    if (styleOn || !D.head) return;
    styleOn = 1;
    var s = D.createElement('style');
    s.textContent = 'html.flbl-na *,html.flbl-na *::before,html.flbl-na *::after{animation-duration:.001s!important;animation-delay:0s!important;' +
      'animation-iteration-count:1!important;transition-duration:.001s!important;transition-delay:0s!important;scroll-behavior:auto!important}' +
      '.flbl-chip{position:absolute;top:10px;right:54px;z-index:6;width:30px;height:30px;border-radius:15px;border:0;padding:0;background:#0A84FF;' +
      'display:flex;align-items:center;justify-content:center;box-shadow:0 1px 4px rgba(0,0,0,.35);opacity:.92}';
    D.head.appendChild(s);
  }
  function liteTick() {
    var on = !!C.il;
    try {
      D.documentElement.classList.toggle('flbl-na', on && !storyPath());    // the story timer needs its animations
      if (!on) return;
      var v = D.querySelectorAll('video'), i;
      for (i = 0; i < v.length; i++) { if (v[i].paused && v[i].preload !== 'none') v[i].preload = 'none'; }
      var lk = D.querySelectorAll('link[rel=prefetch],link[rel=prerender]');
      for (i = 0; i < lk.length; i++) lk[i].parentNode && lk[i].parentNode.removeChild(lk[i]);
    } catch (e) {}
  }

  /* ================================================================ which post is the person looking at right now? */
  function codeFromHref(h) { var m = (h || '').match(/\/(?:p|reel|tv)\/([\w-]+)/); return m ? m[1] : ''; }
  function target() {
    var p = location.pathname, m;
    if ((m = p.match(/^\/stories\/highlights\/(\d+)/))) return { t: 'highlight', code: 'h' + m[1], hid: m[1] };
    if ((m = p.match(/^\/stories\/([^\/]+)\/(\d+)/))) return { t: 'story', code: 's' + m[2], user: m[1], mid: m[2] };
    if ((m = p.match(/^\/(?:[\w.]+\/)?(reels|reel)\/(?!audio\b)([\w-]+)/))) return { t: 'reel', code: m[2], pk: idOf(m[2]) };
    if ((m = p.match(/^\/(?:[\w.]+\/)?(?:p|tv)\/([\w-]+)/))) return { t: '', code: m[1], pk: idOf(m[1]) };
    if ((m = p.match(/^\/([A-Za-z0-9._]{1,30})(?:\/(?:reels|tagged|saved|channel)?)?\/?$/)) && !RESERVED.test(m[1])) {
      return { t: 'profile', code: 'u:' + m[1].toLowerCase(), user: m[1] };
    }
    // home feed: the post that sits closest to the middle of the screen
    var arts = D.querySelectorAll('article'), best = null, bd = 1e9, mid = W.innerHeight / 2;
    for (var i = 0; i < arts.length; i++) {
      var r = arts[i].getBoundingClientRect();
      if (r.bottom < 0 || r.top > W.innerHeight) continue;
      var d = Math.abs((r.top + r.bottom) / 2 - mid);
      if (d < bd) { bd = d; best = arts[i]; }
    }
    if (best) {
      var l = best.querySelector('a[href*="/p/"],a[href*="/reel/"]'), c = l && codeFromHref(l.getAttribute('href'));
      if (c) return { t: '', code: c, pk: idOf(c) };
    }
    // reels feed: the video that sits in the middle, its reel link
    var vs = D.querySelectorAll('video');
    for (var j = 0; j < vs.length; j++) {
      var vr = vs[j].getBoundingClientRect();
      if (vr.top < mid && vr.bottom > mid && vr.height > 200) {
        var up = vs[j].closest && vs[j].closest('div[role="presentation"],article,main');
        var a = up && up.querySelector('a[href*="/reel/"]'), cc = a && codeFromHref(a.getAttribute('href'));
        if (cc) return { t: 'reel', code: cc, pk: idOf(cc) };
      }
    }
    return null;
  }

  /* ================================================================ Instagram web API (own login) */
  function api(path, cb) {
    var claim = '0';
    try { claim = sessionStorage.getItem('www-claim-v2') || '0'; } catch (e) {}
    OF.call(W, path, {
      credentials: 'include',
      headers: {
        'X-IG-App-ID': '936619743392459', 'X-ASBD-ID': '129477', 'X-IG-WWW-Claim': claim,
        'X-CSRFToken': cookie('csrftoken'), 'X-Requested-With': 'XMLHttpRequest', 'Accept': '*/*'
      }
    }).then(function (r) {
      if (r.redirected && r.url.indexOf('/accounts/login') >= 0) { cb('login'); return null; }
      if (r.status === 401 || r.status === 403) { cb('login'); return null; }
      if (!r.ok) { cb('http ' + r.status); return null; }
      return r.json();
    }).then(function (j) { if (j) cb(null, j); })
      .catch(function () { cb('net'); });
  }
  function reelsMedia(id, kind, user, mid, cb) {
    api('/api/v1/feed/reels_media/?reel_ids=' + encodeURIComponent(id), function (err, j) {
      if (err) { cb(err); return; }
      var r = (j.reels_media && j.reels_media[0]) || (j.reels && j.reels[id]) || null, a = (r && r.items) || [], items = [], u = user || (r && r.user && r.user.username) || 'instagram';
      for (var i = 0; i < a.length; i++) {
        var x = itemOf(a[i]);
        if (!x.vs.length && !x.im.length) continue;
        if (mid && (String(a[i].pk) === mid || String(a[i].id || '').indexOf(mid + '_') === 0)) { items = [x]; break; }
        items.push(x);
      }
      if (!items.length) { cb('file nahi mili'); return; }
      cb(null, { t: kind, u: u, c: id, th: items[0].th, items: items });
    });
  }
  function resolve(t, cb) {
    if (cache[t.code] && cache[t.code].u !== 'instagram') { cb(null, cache[t.code]); return; }   // indexed from the page's own data: no extra request
    if (t.t === 'profile') {
      api('/api/v1/users/web_profile_info/?username=' + encodeURIComponent(t.user), function (err, j) {
        if (err) { cb(err); return; }
        var u = j && j.data && j.data.user;
        if (!u) { cb('file nahi mili'); return; }
        var hd = u.profile_pic_url_hd || u.profile_pic_url;
        if (!hd) { cb('file nahi mili'); return; }
        cb(null, { t: 'profile', u: u.username || t.user, c: t.code, th: u.profile_pic_url || hd, items: [{ k: 'i', id: String(u.id || ''), th: u.profile_pic_url || hd, vs: [], im: [[hd, 0, 0]] }] });
      });
      return;
    }
    if (t.t === 'highlight') { reelsMedia('highlight:' + t.hid, 'highlight', '', '', cb); return; }
    if (t.t === 'story') {
      api('/api/v1/media/' + t.mid + '/info/', function (err, j) {
        var it = !err && j && j.items && j.items[0], m = it && modelOf(it, 'story');
        if (m) { cb(null, m); return; }
        if (err === 'login') { cb(err); return; }
        api('/api/v1/users/web_profile_info/?username=' + encodeURIComponent(t.user), function (e2, j2) {      // fallback: stories of that user
          var uid = !e2 && j2 && j2.data && j2.data.user && j2.data.user.id;
          if (!uid) { cb(e2 || 'file nahi mili'); return; }
          reelsMedia(String(uid), 'story', t.user, t.mid, cb);
        });
      });
      return;
    }
    if (!t.pk) { cb('file nahi mili'); return; }
    api('/api/v1/media/' + t.pk + '/info/', function (err, j) {
      if (err) { cb(err); return; }
      var it = j && j.items && j.items[0], m = it && modelOf(it, t.t === 'reel' ? 'reel' : '');
      if (!m) { cb('file nahi mili'); return; }
      cb(null, m);
    });
  }
  function fail(why) {
    if (why === 'login') { if (loginSaid) { want = ''; return; } loginSaid = 1; }
    want = '';
    call('igFail', why);
  }
  function open(t) {                              // the app asked for this post (download button / chip tapped)
    if (!t) { fail('post nahi mili'); return; }
    if (!cookie('ds_user_id')) { fail('login'); return; }
    want = t.code;
    call('igWant', t.code);
    if (busy[t.code]) return;
    busy[t.code] = 1;
    resolve(t, function (err, m) {
      busy[t.code] = 0;
      if (err) { if (want === t.code) fail(err); return; }
      if (!m.u || m.u === 'instagram') { if (t.user) m.u = t.user; }
      m.c = t.code;
      remember(t.code, m);
      if (want === t.code) { want = ''; call('igInfo', t.code, JSON.stringify(m)); }
    });
  }
  expose('i', function (cmd, arg) {
    try {
      if (cmd === 'open') {
        var t = null;
        if (arg) { var c = String(arg); t = { t: '', code: c, pk: idOf(c) }; }
        var cur = target();
        if (!t || (cur && cur.code === arg)) t = cur || t;
        loginSaid = 0;
        open(t);
        return 1;
      }
    } catch (e) {}
    return 0;
  });

  /* ================================================================ small download chip on every feed post */
  var CHIP_SVG = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11"/><path d="M7 11l5 5 5-5"/><path d="M5 20h14"/></svg>';
  function chipTick() {
    if (!D.body) return;
    var arts = D.querySelectorAll('article'), n = 0;
    for (var i = 0; i < arts.length && n < 8; i++) {
      var a = arts[i];
      if (a.__flbc) continue;
      var r = a.getBoundingClientRect();
      if (r.bottom < -300 || r.top > W.innerHeight + 300) continue;
      var l = a.querySelector('a[href*="/p/"],a[href*="/reel/"]'), code = l && codeFromHref(l.getAttribute('href'));
      if (!code) continue;
      a.__flbc = 1; n++;
      try {
        if (W.getComputedStyle(a).position === 'static') a.style.position = 'relative';
        var b = D.createElement('button');
        b.className = 'flbl-chip'; b.type = 'button'; b.innerHTML = CHIP_SVG;
        b.setAttribute('aria-label', 'Download');
        (function (art, c0) {
          b.addEventListener('click', function (ev) {
            ev.stopPropagation(); ev.preventDefault();
            loginSaid = 0;
            var ln = art.querySelector('a[href*="/p/"],a[href*="/reel/"]'), c = (ln && codeFromHref(ln.getAttribute('href'))) || c0;
            open({ t: '', code: c, pk: idOf(c) });
          }, true);
        })(a, code);
        a.appendChild(b);
      } catch (e) {}
    }
  }

  /* ================================================================ tick: tells the app which post is on screen */
  function tick() {
    try {
      if (D.hidden) return;
      injectStyle();
      liteTick();
      chipTick();
      var t = target(), key = t ? t.code : '';
      if (key !== lastKey) { lastKey = key; call('igTarget', key, t ? (t.t || 'post') : ''); }
    } catch (e) {}
  }
  CFG_HOOKS.push(function (o) { try { liteTick(); } catch (e) {} });
  if (TOP) {
    NSI.call(W, tick, 1500);
    NST.call(W, tick, 800);
  }
  if (C.test) W.__flbIgT = { capDash: capDash, capVersions: capVersions, liteSet: liteSet, modelOf: modelOf, audioOf: audioOf, rewriteText: rewriteText, target: target, idOf: idOf, cache: cache };
  return 1;
})();
