# Live Editor

Pro APK patcher for Android. Pick an app, tick the options you want, tap **Patch**.

## What you can change (no coding)
- App name, version name, version code
- Remove permissions (internet, location, contacts, camera ... or any you tick)
- Switch off parts of the app (auto-start after boot, services, screens)
- Block ad servers, tracker servers, servers found inside the app, or your own list
- Hide ad banners, mute click sounds, fullscreen, keep screen on, allow screenshots
- Lock rotation, faster or no animations
- Debuggable / backup / plain HTTP / large heap flags
- Keep only one CPU type (smaller APK) + a "compatible with this phone" check (ARMv7 etc.)
- One-tap presets: Privacy, Ads off, Smaller, Faster UI

### New in 2.0
- **Floating buttons and Menu are separate.** Size (in **dp**), opacity (%), text size (dp). Changing the buttons no
  longer makes the menu huge (the old single "overlay size" scaled everything in every overlay window).
- **Live Editor inside the app** (optional switch): a pencil handle appears in the patched app. It lists everything
  that is visible (menus, floating buttons, icons, texts of overlays AND app screens / login page; background-only
  parts are not listed). Tap any item to change **size (dp), text size (dp), colour, name, opacity, hide**.
  Global button / menu sliders and a theme editor are in the same panel. Values are shown in dp, opacity in %.
- **App theme**: background, text and button colours for the whole app (ready-made themes or your own hex colours).
- **Links**: block links that throw you out of the app (browser, Telegram, Play Store ...) at app start or always.
  The link is skipped, the app keeps running (no crash).
- **Timers**: hide or replace countdown-like texts (00:59, "3 days left" ...).
- **Convert live APK to normal**: in the pencil panel tap *More > Copy settings*. In Live Editor choose
  *Convert live APK to normal*, pick that app, tap *Paste settings*, leave "Live Editor inside the app" off, Patch.
  You get a normal APK with all edits baked in and no handle.
- **ARMv7 / your CPU**: the options screen tells if the app has libraries for your phone and can keep only that CPU type.
  Native libraries cannot be converted from one CPU type to another (an arm64-only app cannot run on an ARMv7 phone).

### New in 2.1
- **Normal structure (for MT Manager)**: options screen > *Normal APK*. Every file is opened and checked; zip tricks that stop
  tools from opening the code files (a fake "encrypted" flag, a wrong size or checksum in the header) are repaired. The files
  themselves are not changed. An APK that Android's zip reader refuses is repaired automatically when you pick it.
  Code that is packed or encrypted by a protection tool is NOT unpacked (it only unpacks while the app runs): it stays as it is.
- **ARMv7 best-effort mode** (only shown when the app has no libraries for this phone and the phone is ARMv7): the app's native
  libraries are replaced by empty stand-ins (stored, aligned) so it installs and starts. Anything that needs those libraries
  stops working, and the engine keeps the app alive when such a call fails. Some apps will still close.
  The stand-in is an empty 32-bit ARM library built in code (`StubElf.java`); it was checked with `readelf`, not on a real phone.
- **Settings without copy and paste**: when you pick an installed app that was patched with this version, its settings
  (baked edits plus pencil edits) are read straight from it (the engine has a small provider that only answers Live Editor).
  The *Load settings from the installed app* button does the same later. Pasting still works.
- **Timers**: a bare 00:59 is only treated as a timer after it changed a few times within seconds; "10:30 AM", dates and fixed
  labels are left alone. Texts with words like "left" or "expires" still count at once.

### New in 2.2
- **Four separate size groups**: menu icon (the first small floating window = the button that opens the menu), floating
  buttons, menu panels, and line overlays. Each has its own size, opacity and text size. Change one, the others stay.
- **Sizes can go smaller and bigger**: icon, buttons and menu use percent (100% = original, 20% to 400%); every single
  item in the pencil panel shows its original dp and can go below or above it. Text size 50% to 300%.
- **Line thickness**: a thin line window or thin view gets a thickness slider (global and per item) that can go thinner
  or thicker. A line the app paints itself on a canvas cannot be re-drawn from outside.
- **Windows tab (pencil panel)**: a list of every menu, floating button, popup and dialog with a *Keep this interface*
  switch. Removed = hidden and untouchable (touches pass through), never detached, so the app cannot crash from it.
  Popups that are closed now stay in the list. The main screen can be styled but not removed.
- **No flicker**: windows are changed before their first frame (the engine is told the moment the app adds a window)
  and before every later frame of floating windows and popups, so the original look / colour / opacity is never shown
  for a moment. The 0.7 s timer stays as a safety net.
- **Lines drawn by the app itself** (a line from the top origin painted on a canvas): the engine finds the app's Paint
  objects by reflection and sets their stroke width (global *Lines* slider or per item). Works when the app keeps its
  Paint in a field; a Paint created fresh on every draw cannot be reached.
- **Timer editor** (options screen > *Timers in this app*): lists the places in the app's code that start something
  after a delay (Handler.postDelayed, Timer, CountDownTimer, scheduled executors) with the delay in ms. Tap one to set a
  new delay or *Never*; the number is written into classes.dex when you tap Patch (same length, dex checksum and SHA-1
  fixed, APK re-signed). Places up to 32767 ms are edited in place (or Never); a delay that is calculated by the app
  cannot be edited. *LINE:* entries are the numbers next to `Paint.setStrokeWidth` (line thickness): edit them the same
  way (for example 1.5 -> 1). Edits are checked against the real code at patch time and skipped if they do not match.
- **Components list** (*Switch off parts of the app*): the main screen, services and providers are marked, and a
  warning with an *Undo these (safe)* button appears when one of them is switched off (it can crash the app).
- **Windows tab** shows a small picture of each window, so it is clear which interface is which.
- Old settings with sizes in dp are not carried over (sizes are percent now).

### New in 2.3: nixu cn mode (MT Manager style)
Top right of the home screen there is a **nixu cn** switch. ON = the simple options are hidden and the app opens APKs in an
MT Manager style editor (`NixuActivity`). OFF = everything works as before.

- **File list**: every entry of the APK is shown (assets, lib, res, META-INF, classes*.dex, resources.arsc, AndroidManifest.xml ...).
  Nothing is hidden. Folders first, size and date per row, long-press to select, add / replace / rename / delete / extract.
- **Open with...** per file type:
  - `AndroidManifest.xml` and every compiled `res/*.xml`: *XML editor* (compiled XML shown as text, compiled again on save;
    values keep their exact type: `true`, `123`, `0x7f`, `#ffffff`, `16dp`, `@0x7f010001`, `f:1.5`; plain text that looks like
    one of those gets a leading backslash).
  - `resources.arsc`: *Arsc Editor plus* (package > type > resource > configuration), *Arsc Editor* (flat list with search),
    *Translation mode* (every text value, edit once = everywhere), *Resource querier* (search by name, id or value).
    Strings, numbers, booleans, colours, dimensions and references can be changed. A string shared by several entries is
    copied (the other entries keep their text).
  - `classes*.dex`: *Dex Editor Plus* (class list with search, fields, methods, bytecode of a method as text with the address of
    each instruction), *Dex strings*, *Dex method search*.
    Instruction edit: tap a line, type one instruction (`const/4 v0, 0x1`, `if-nez v0, :0012`, `invoke-static {v0}, Lcom/Foo;->bar(I)V`,
    `const-string v0, "text"` ...). It must fit the old instruction (same size or smaller, the rest becomes `nop`), registers must
    exist, references must already exist in this dex (or use `string@12`, `method@34`).
    Quick patches in the menu: return void / true / false / null / a number.
    Strings can be changed in place (same size; a shorter text can be padded with spaces).
  - Text editor, hex editor (tap a row, change the bytes), image viewer.
- **Save**: builds a new APK (untouched entries are copied byte for byte, resources.arsc is stored and aligned), signs it with the
  built-in key (v1 + v2) and offers Install / Share / Save a copy.
- **Export for Claude**: one `.nixu.txt` file with the file list, the manifest as text, all resources, the dex class list
  (optionally methods, or full smali text of the classes whose name contains a filter). Send that file to be read.

Limits of nixu cn (honest):
- The dex editor patches inside the existing file, so nothing can grow: no new classes, methods or strings, no full smali recompile.
  Edit a string only to a text that fits the old size. Keeping dex strings sorted is not re-checked.
- Old signature files (META-INF/*.SF, *.RSA, MANIFEST.MF) are dropped on Save; the new signature replaces them.
- Code packed or encrypted by a protection tool is not unpacked.
- Not run on a phone yet: the file-format engines (`NixuPool/NixuAxml/NixuArsc/NixuDex/NixuZip/NixuExport`) were tested on the
  PC with generated sample files; the screens (`NixuActivity`) were only compile-checked against stand-ins for the Android classes.

### New in 2.4: files are recognised by their bytes, not their names (nixu cn mode)
- **Any file can be a dex.** Long-press / tap a file with an odd name (for example `OoooooOooo`, `d_shell_data_001`): the editor now
  reads it and, if it holds a dex, offers *Dex Editor Plus / Dex strings / Dex method search* even though the name does not end in `.dex`.
- **Damaged dex header** (magic bytes wiped or changed, rest of the header fine): offered as *Dex Editor Plus (repair header)*.
  The editor works on a repaired copy; saving writes the repaired header back.
- **Dex hidden inside another file**: *Open dex found inside, at 0x...* (up to 4 hits per file). It is copied out as
  `<file>_dex_<offset>.dex`, added to the APK file list and opened. Delete that entry if you do not want it in the APK.
- **File info** (new entry in *Open with...* for files with unknown names): size, entropy, first bytes, type by content and
  every dex offset found. It also says plainly when a file is encrypted or compressed.
- *Open with > Dex ...* on a normal `.dex` also repairs a damaged header now.
- **Export for Claude** has a new section *FILES CHECKED BY CONTENT*: every file with an unknown name gets size, entropy, type and
  its first 16 bytes. Files that turn out to be dex are listed with their classes like `classes.dex`.

Still true (honest): if a file is encrypted, no editor can read it from the APK. Packed apps keep their real code encrypted
(for example in `assets/`) and only decrypt it in memory while the app runs, with a loader that sits in the small `classes.dex`.
*File info* shows which of the two cases a file is. Checked on the PC with generated files (valid, damaged-magic, hidden-inside,
random data); the new screens were only syntax-checked, not run on a phone.

### New in 2.5
- **Line thickness can go much thinner**: values are now in tenths of a dp (0.1 dp steps, down to 0.1 dp, up to 20 dp) with
  `- 0.1` / `+ 0.1` buttons, in the patcher app and in the pencil panel (global and per item). The panel also shows the
  original width of a line the app paints itself, in px and in dp (a line drawn with `setStrokeWidth(1.5f)` is 1.5 px, which
  is already thinner than the old 1 dp minimum on most phones). Canvas lines are re-applied every 60 ms.
- **Sizes are in dp, not percent**: icon / floating buttons / menu "Size" is the width in dp every window of that group gets
  (its height follows); the pencil panel shows the original width next to it. "Text size" is now a change in dp
  (-10 ... +30, 0 = original). Old percent settings still load and still work until a dp value is set.
- **Removed interfaces are bypassed, they cannot crash the app any more**:
  - The main screen was not recognised as the main screen on Android 8+ (the activity window's view context is not the
    Activity), so it could be "removed" and the app closed. It is now recognised by its window type and can never be removed.
  - A removed window is no longer made INVISIBLE (which tears down its surface). It stays alive, fully transparent
    (window alpha 0), not touchable, not focusable and without a dim background; every touch goes to the app under it.
  - If bypassing throws an error, the window is kept visible automatically.
  - Crash guard: if the app closes within 5 seconds of a removal, the next start remembers that window as unsafe, keeps it
    visible and shows a message. Windows tab > *Allow removing the kept-visible windows again* clears the marks.
- **Auto on / off timer removed (2.4.1).** The timer that switched a button on and off by itself, with its seconds, chips and
  pictures, is gone from the patcher app and from the pencil panel. Buttons are manual: ON stays ON, OFF stays OFF.
  To get rid of a button's own auto-off time use the patcher card *Button that turns itself off, and its beep*: the
  delay becomes "never", so the button only changes when you press it.
- **No beep on a button (pencil panel).** Items > pick the button > tick *No beep / click sound on this button*. The
  normal Android click sound of that item (and everything inside it) is switched off. A beep the app plays itself
  (ToneGenerator, SoundPool, MediaPlayer) cannot be cut out while the app runs, so touching the item mutes the media
  sound for 0.5 s and puts it back (`Quiet.java`); the app's own touch handling is kept. A beep on another sound
  channel is not covered: use the patcher card *Button that turns itself off, and its beep* for that.
- Not run on a phone here: the code was syntax-checked with the JDK compiler on a PC only (no Android SDK in this environment).
  Build it with the usual workflow and test the four changes.

### New in 2.6
- **Button that turns itself off, and its beep** (patcher app, options: card *Button that turns itself off, and its beep*):
  *Find the auto-off timer and the beep, then remove them* searches the code of the app for a plain delay of 1 to 3 seconds
  (`postDelayed`, `Thread.sleep`, Kotlin `delay()`, `Timer`, `CountDownTimer`, scheduled tasks) and for sounds
  (`ToneGenerator.startTone`, `MediaPlayer.start`, `SoundPool.play`, `AudioTrack.play`, `Ringtone.play`,
  `playSoundEffect`). You get the list with the likely ones already ticked (timers of 1-3 s; beeps in the same class as a
  ticked timer, or all of them when the app has only a few). *Remove ticked* sets each delay to **never** (the number in
  the code becomes a delay of hundreds of millions of years) and cuts the sound call out (the call and a `move-result` after
  it become `nop`). It is written into `classes*.dex` when you tap Patch (same length, dex checksum and SHA-1 fixed).
  The full list (*Timers in this app*) shows `BEEP:` entries too, tap one to remove only that sound.
  Tested on the PC with generated dex files (the delay, the sound call and the `move-result` after it); not run on a phone.
  If the search finds nothing (the delay is calculated by the app, or the code is packed), export the file list from the
  nixu cn editor and send it.
- **Menu icon and floating buttons now shrink as well as grow**, whatever their layout: the content of the window is scaled
  (each child about the top-left corner, with the matching move) and the window gets the matching size, so a picture that
  wraps its size or a view with a fixed size can no longer stay big inside a small window. Touches follow the scaled picture.
- **Pencil panel**: a touch outside the panel closes it (the touch still reaches the app), the Back key closes it, and the
  *Close* button is now first on the left; the tabs sit in a row that scrolls sideways, so the button can no longer be pushed
  off a narrow screen.

### New in 2.7: the pencil shows up in every app
- **Why it did not show before:** the pencil was an overlay window, and an app can only be allowed to draw over other
  apps if its manifest asks for `SYSTEM_ALERT_WINDOW`. Live Editor never added that line, so in most apps Android
  had nothing to allow and the pencil never appeared. Now, with *Live Editor inside the app* on, the patcher adds the
  permission to the manifest (nothing is added if the app already has it, or if you removed it yourself).
- **Pencil works at once, without any permission:** if overlay is not allowed, the pencil (and its panel) opens inside
  the app's own window as a popup (`PopupWindow`), so it is there the moment the app opens. It follows you from
  screen to screen of the app.
- **Live Editor permission popup:** when the app opens and overlay is not allowed, a Live Editor dialog asks for
  *Display over other apps* and its *Allow* button opens Android's page for that app. It comes once per start;
  long-press the pencil to get it again. When you come back with the permission on, the pencil switches to the
  floating one within a second.
- **Pencil stays on top:** if the app adds a floating window above the pencil later, the pencil is added again on top.
  If a phone refuses the overlay window even with the permission, the in-app pencil is used instead.
- **Patcher:** the finished screen has *Allow overlay for the patched app* (opens that app's overlay page after you
  install it).
- Checked: the manifest edit on the PC with generated manifests (UTF-8 and UTF-16 pools, decoded by a separate
  program). Not run on a phone: the pencil and popup code was only syntax-checked (no Android SDK here).

### New in 2.8 (pencil panel + origin lines)
- **Pick a colour with one tap.** The three R/G/B sliders are gone: every colour is a swatch palette (item colours and theme).
- **Preview of what you edit.** While one item is open in *Items*, a picture of it stays pinned at the top of the panel
  (outside the scrolling part) and follows every change.
- **Replace the icon with a PNG.** Items > pick a text, icon or button > *Replace icon (PNG)*. Any PNG, any size: it is
  scaled down once (192 px), fitted into the old icon's place and keeps its shape. It works on pictures, on icons set as
  compound drawables of a text, and, from a text, on the picture beside it in the same row. Every visible picture is now
  listed in Items. The PNG is kept inside the settings, so *Copy settings* / *Convert live APK to normal* carry it along.
  (The file picker is started from an invisible fragment, `Picker.java`, so the app's manifest does not change.)
- **Sound of a button = volume 0.** *Sound of this button: volume 0* looks into the code behind the item (listeners and the
  objects they hold): a `MediaPlayer` gets volume 0, a `ToneGenerator` is swapped for a silent one (both put back when
  unticked). Anything it cannot reach (a `SoundPool` kept elsewhere) is still muted on more streams (music, DTMF, alarm,
  system, notification) while the item is touched.
- **Theme colours reach the menu and keep on / off apart.** The theme now repaints any kind of background (state lists,
  layers, pictures), not only flat and gradient ones. A button keeps its difference: grey (off) becomes a soft neutral of the
  theme, a coloured one (on) gets the button colour. The app's own drawable is asked for its colour on every draw, so a
  switch that recolours its drawable still shows on / off. Text colour on a button follows the colour it really has.
- **Shrinking a menu shrinks its icons too.** Pictures that were only centred (cropped when smaller) are fitted, and icons
  beside a text (compound drawables) are scaled with the menu.
- **Less flicker.** When an app refreshes a floating button with its own `updateViewLayout`, size and opacity are written
  into the params before Android lays the window out again, so the original look is not shown for a frame.
- **All origin lines are one width.** Line thickness is one shared number: changing it on one line (or in Global) changes
  every line; per-item thickness is dropped. Quick values 0.1 / 0.2 / 0.3 / 0.5 / 1 / 1.5 dp. Lines thinner than one pixel
  are drawn as a fainter one-pixel line (hairline).
- **Patcher, timer list:** the place of the top-origin lines (class `n1`, `<init>`, `Paint.setStrokeWidth`, number 1.5 x
  density) is listed first as *ORIGIN LINES (top)*. Editing it (or any LINE entry) can change all places of the same class
  that hold the same number in one go (checkbox, on by default). The smallest number is now 0.05.
- Not run on a phone here: syntax-checked on a PC only (no Android SDK). Test: theme colours, icon replace, sound, line width.

### New in 2.9 (save button + crash-safe window removal)
- **Save button on every edit screen.** Items, Global and Theme each now have their own **💾 Save** button right below
  their controls. Every change already applies and saves on its own; this button just confirms it with a clear "Saved"
  message, for when you want to edit several sliders and then save deliberately.
- **Two-way crash guard for the Windows list.** Removing a window was already undone automatically if the app closed
  right after; now the same protection also covers bringing a window BACK: if un-hiding one closes the app, that exact
  window is left removed and is never auto-restored again, instead of being retried on every start and crashing the
  app each time. Each direction is remembered separately, so a window that is safe to show but unsafe to hide (or the
  reverse) is handled correctly, and the Windows tab explains which state each frozen window is stuck in.
- **Windows tab is more complete:** up to 250 windows are listed at once (was 80), and more are remembered across app
  screens (400, was 200), so a busy app does not run out of room before everything it has shown gets listed.
- Not run on a phone here: syntax-checked on a PC only (no Android SDK). Test: Save buttons, and removing/restoring a
  few different windows to see the crash guard in the Windows tab.

### New in 2.10 (apps that crash when you edit them)
- **Per-item crash guard (`EditGuard`).** Every edit (text, size, colour, line, sound, icon, opacity) is written down when it
  is applied. If the app closes within a few seconds, the next start switches off only THAT kind of change for THAT item
  (the riskiest of the latest ones first); everything else keeps working. Items > the item > *Try these changes again*, or
  the Windows tab button, brings it back. Leaving the app with Home / recents is not counted as a crash.
- **Text changes are silent.** A renamed text is set while the app's own TextWatchers are detached, so an app that reacts to
  its texts changing (reads them back, sets them again) does not notice. If the app keeps undoing a text or a background more
  than 12 times a second, that one is left alone (loop guard).
- **Edits wait 2 s after the app starts**, so they never meet the app's start-up checks.
- Not run on a phone here: syntax-checked on a PC only.

### New in 2.11 (auto-off timer: never, in the pencil)
- **Items > the button > *Auto-off timer: never (button stays manual)*.** After each tap on that button, the delayed jobs the
  app's own code starts (`Handler.postDelayed`, `View.postDelayed`, a delayed Handler message, a `CountDownTimer`, a Kotlin
  `delay`) are taken out of the main queue again (`Manual.java`), so the button only changes when you press it. Only jobs that
  are new since the finger touched down, belong to the app's own classes and are due in 0.3 to 6 seconds are cancelled. The
  3 2 1 count text on the button is hidden as well. A timer kept in another thread (`java.util.Timer`, `Thread.sleep`, an
  executor) is not in the queue and cannot be reached this way: use the patch card *Button that turns itself off, and its
  beep* (it sets that delay to never inside the code). Guarded by the edit guard like every other edit (category "timer").
- Not run on a phone here: syntax-checked on a PC only.

### New in 2.12 (every APK opens)
- **No APK is refused any more because of a zip trick or a scanner crash.** Reading the app now has three steps: the
  phone's own zip reader, then Live Editor's own zip reader (it ignores fake "encrypted" flags, wrong checksums and
  damaged headers), and as a last resort only the file names. The server list and timer search are a bonus: if they cannot
  be made, the app still opens and can be patched.
- Any error while opening the zip (not only `ZipException`) now makes the repaired copy; if even that fails, the original is
  read with the own reader.
- A manifest with a styled string pool, junk string slots or junk bytes after the document is read instead of rejected.
- When something still fails, the log now shows the first lines of the stack trace (`at ...`), so the exact place is visible.
- Not run on a phone here: the zip and scan code was tested on a PC with fake "encrypted" and damaged zips.

### New in 2.20.3 (both pencils always show, any pencil opens the full menu)
- **The app's own in-app pencil is never hidden any more.** Before, the engine took its pencil away as soon as Live Editor reported that
  its own overlay pencil was up (`Panel.tick`). When that overlay pencil could not be drawn on an app, no pencil was left at all. Now the
  in-app pencil, the Live Editor overlay pencil and the Accessibility pencil can all be on screen together.
- **Three places, so none sits on another:** in-app pencil 120 dp down, Live Editor overlay pencil 176 dp down, Accessibility pencil on a
  patched app 232 dp down (all 4 dp from the left; dragging and saved places are unchanged).
- **Any pencil opens the same full menu** (*Close, Items, Windows, Global, Theme, More*, *Refresh*, window list with previews and *Keep*).
  The engine now answers `panel` with `ok` only when the menu really opened (and starts the pencil if it never started in that run). Before
  it always said `ok`, so a tap could do nothing and the short fallback panel never appeared. Only when the engine does not answer (an app
  patched before 2.20.3) the short windows panel opens, with a note to patch the app again.
- **Pencil that did not show after patching:** a failed overlay pencil is tried again every 20 s (before: given up for the whole run), the
  in-app popup pencil stays up until the overlay one really works (no gap, no flicker), and the engine finds the screen that is on top
  through `ActivityThread` when the lifecycle callbacks never reported one (apps that swap their Application).
- **Apps patched with an older engine (the panel shows `Close 2.18`) must be patched again** to get this: the engine lives inside each app.
  The Live Editor app itself (the two outside pencils) changes at once after the update.
- Changed: `agent/Panel`, `agent/Agent` (engine 2.20.3), `agent/HostApi`, `agent/HostLink` (comment), `PencilHost` (default place, hint text),
  `PageLog` (default place of the Accessibility pencil). versionCode 30. Not run on a phone here, and no JDK compiler or Android SDK in this
  environment: braces and parentheses checked on every file, the changed code read through. Build the agent first (`tools/build_agent.sh`), then
  the app, as usual.

### New in 2.20.2 (the pencil opens the full 2.18-style menu)
- **Tap the pencil on a patched app: the full pencil menu opens inside the app**, the same menu as the app's own pencil in 2.18
  (*Close*, **Items, Windows, Global, Theme, More**, *Refresh*, the window list with previews and *Keep*). This holds for the Live Editor
  overlay pencil and for the Accessibility pencil. Before, the tap opened a short panel and the full menu needed one more tap on
  *Full pencil*.
- The short windows panel (opacity, filters, *Restore all removed*, *Save and patch*, *Pencil OFF*, *Full pencil*) is kept as a fallback:
  it opens only when the engine inside the app does not answer (an app patched before 2.19, or the app is not running).
- Needs an app patched with 2.19 or newer (this build). Apps patched with 2.18 keep their own in-app pencil and menu as before.
- Marker, Lock layer and line recording stay removed (as asked in 2.19).
- Changed: `PencilHost` only (`openFull`). versionCode 29. Not run on a phone here, no Android SDK: compiled with the JDK compiler on the
  source (no syntax errors, no unresolved names of our own code).

### New in 2.20.1 (2.20 + the always-on pencil of 2.27)
- This build is 2.20 with the permissions and the always-show code of 2.27 added. The pencil menu of 2.20 (windows with a preview,
  *Keep this interface*, *Full pencil*, *Save and patch*, opacity, filters, *Restore all removed*, *Pencil OFF*) is **not changed**.
- Added from 2.27: the always-on service (`PencilService`, one quiet notification, `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE`,
  `POST_NOTIFICATIONS`, `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`), the Accessibility pencil (`AccessPencil`, `PageLog`, `pencil_access.xml`,
  strings, notification icon) that shows on every app without "Display over other apps", and the pencil card on the home screen
  (Accessibility settings, Allow restricted settings, Battery: No restrictions).
- Files changed against 2.20: `AndroidManifest.xml`, `MainActivity`, `PencilHost` (only the hook that lets the panel open through the
  Accessibility pencil), `PencilPrefs`, `HostProvider`, new `AccessPencil`, `PageLog`, `PencilService` and the three resource files. The
  engine (`agent/`) and the patcher are identical to 2.20, so apps patched with 2.20 do not need patching again.
- versionCode 28 (higher than 2.27, installs over it). Not run on a phone here, no Android SDK: compiled with the JDK compiler on the
  source (no syntax errors, no unresolved names of our own code; only the Android classes are missing there).

### New in 2.27 (the old pencil menu is back on the Accessibility pencil of patched apps)
- **Tap the Accessibility pencil on a patched app: you get the old menu again** (`PencilHost` panel): every window and screen of the app
  with a preview, *open now / closed*, *Keep this interface* (remove a window, bypassed, never closes the app), opacity per window,
  filters, *Restore all removed*, *Save and patch (remove the pencil)*, *Pencil OFF*, and **Full pencil**, which opens the big in-app
  menu (Items, Global, Theme, More). Before 2.27 that pencil only showed the short *On this page / Pages / Covers* panel.
- It is drawn through the Accessibility service's own window type, so it needs no *Display over other apps*. A second tap on the pencil
  closes it; it also closes when you change app. If the app's own overlay pencil is up too, that one's panel is used.
- **Not changed:** how and where the pencils show (2.26 and every pencil setting stay exactly as they were), the pencil ON / OFF switch,
  the home menu, and the *On this page / Pages / Covers* panel, which is still what an app that is NOT patched (and Live Editor itself)
  gets: window removal, Items and Theme need the engine inside the app, so they cannot work there.
- Needs an app patched with 2.19 or newer (the panel reads the windows from the engine inside the app).
- Not run on a phone here, no Android SDK in this environment: compared with the 2.26 source by compiling both with the JDK compiler on a
  PC (no syntax errors, no unresolved names of our own code; only the Android classes are missing there).

### New in 2.26 (pencil on Live Editor and the launcher too; two pencils on a patched app)
- **The Accessibility pencil now shows on EVERY app, patched ones too, at once.** Before, it stayed away from patched apps ("they have their
  own pencil"), but that own pencil needs *Display over other apps* for Live Editor and can be hidden or blocked by the app itself, so a
  patched app could end up with no pencil at all. Now there is no waiting and nothing is hidden: the app's own pencil and this one show
  together.
- **Two places, so you can see both.** On a patched app the app's own pencil sits at its usual place (4 dp from the left, 140 dp down) and the
  Accessibility pencil sits lower (210 dp down) until you drag it; its place on patched apps is remembered separately from its place on
  normal apps.
- **The pencil also shows on Live Editor's own screens and on the launcher (home screen, recents).** Back to Live Editor or Home no longer
  removes it. Only the system bars (status bar, notification shade) get none. Turning the pencil switch ON in Live Editor shows it at once.
  On Live Editor's own screens the page list and covers work, but a cover does not follow scrolling there (its own overlay events are
  ignored on purpose, so the pencil cannot trigger itself).
- Not run on a phone here (no Android SDK, no JDK compiler in this environment): braces checked, code read through.

### New in 2.23 (small fix)
- An app that went from patched to normal (*Save and patch* without the pencil, or a reinstall of the original) was still counted as
  "patched" until Live Editor was restarted, so the new pencil stayed away from it. Live Editor now asks Android again every time an
  app's page opens. Patched app: its own pencil from the engine. Normal app: the Accessibility pencil.

### New in 2.22 (the pencil on apps that are NOT patched yet, and it remembers their pages)
- **Live Editor shows the pencil above any app you open, patched or not.** It uses an Accessibility service (`AccessPencil`, "Live Editor
  pencil"). Turn it on once: home screen > pencil card > *Open Accessibility settings* > Installed apps > Live Editor pencil. On Android 13+
  a sideloaded app is blocked from that switch until you tap *Allow restricted settings* (the card has a button to App info, three dots at
  the top right). It follows the pencil ON / OFF switch: OFF removes the pencil from every app.
- **Which page is open is tracked.** The service sees the app and its page (activity) every time they change, and remembers every page it saw
  in each app (visits, last time). Pages are listed in the pencil panel, tab *Pages*.
- **Pencil panel on an unpatched app:** tab *On this page* lists what is on the screen (texts, buttons, view ids) with *Show* (flashes it),
  *Hide* (a cover over it) and *Block taps* (stays visible, cannot be tapped). Tab *Covers* lists the covers of this page and removes them.
  A cover is saved for that page and comes back by itself every time the page opens again; it follows its element by view id (moves when the
  page scrolls) and stays at its place when the element has no unique id. *Hide pencil in this app* keeps the pencil away from one app
  (covers still work); the home card has *Show the pencil in hidden apps again*.
- **Honest limit:** an app that is not patched cannot be changed from outside. A cover is a Live Editor window drawn over the element, not a
  real edit. Size, remove, colours and the other pencil edits still need the patched app (*Live Editor inside the app*).
- **Patched apps** keep their own pencil (from the engine, as in 2.19 / 2.20); the new pencil stays away from them, from Live Editor itself,
  the launcher and the system bars.
- **Privacy:** the screen is read only when the *On this page* tab is opened or refreshed (and, for covers, to find their elements). Password
  fields are shown as "(password field)" without text. Pages and covers are saved only inside Live Editor on this phone.
- Not run on a phone here, and no Android SDK in this environment: the changed files were checked with the JDK compiler (no syntax errors, no
  unresolved names of our own code). Build it with the usual workflow and test: Accessibility switch, pencil on a plain app (not patched),
  open two pages of it (Pages tab), Hide a button (cover stays when you scroll, and comes back after leaving and re-opening the page),
  Pencil OFF, a patched app still gets its own pencil.

### New in 2.21 (always-on pencil service)
- **The pencil is ready the moment a patched app opens.** When Live Editor opens (and every time it comes to the front) with the pencil
  switch ON, it starts a foreground service (`PencilService`) with one quiet notification: *Live Editor pencil is ready*. The service keeps
  the Live Editor process alive, so a patched app finds Live Editor waiting instead of starting it cold (some phones delay or block that).
- **Stops with the switch.** Pencil switch OFF, *Pencil OFF* in the pencil panel, or the *Pencil OFF* button in the notification: the service
  stops and the notification goes away. The switch on the home card follows the real setting. The card says if the service is running.
- **Android 14 / 13:** the service is a foreground service of type `specialUse` (permissions `FOREGROUND_SERVICE`,
  `FOREGROUND_SERVICE_SPECIAL_USE`). Live Editor asks once for the notification permission (`POST_NOTIFICATIONS`, Android 13+) and then for
  "Display over other apps". The service also runs if you refuse notifications; you just do not see the card.
- **Battery:** when Live Editor is not free of battery limits, the pencil card shows *Battery: No restrictions*. On Xiaomi, Oppo, Vivo and
  similar phones also allow Auto-start for Live Editor in the phone's own settings, or the pencil can still come late.
- A patched app that wakes Live Editor in the background makes it try to start the service again (at most once every 20 s); Android may refuse
  that from the background, then nothing happens. Opening Live Editor once always brings it back. After a phone restart, open Live Editor once.
- Nothing changes inside the patched apps: no need to patch them again.
- Not run on a phone here, and no Android SDK in this environment: the changed files were checked with the JDK compiler (no syntax errors,
  no unresolved names of our own code). Build it with the usual workflow and test: open Live Editor (notification appears), open a patched app
  (pencil shows at once), switch the pencil OFF (notification goes), swipe Live Editor away from recents and open the patched app again.

### New in 2.20 (the pencil on EVERY patched app, ON / OFF switch, windows and screens with preview)
- **Pencil ON / OFF switch in Live Editor (home screen, top card). Default: ON.** Switch it off and every pencil goes away at once;
  switch it on and it comes back. When Live Editor opens with the pencil ON and without "Display over other apps", it asks for
  that permission once (the card has an *Allow* button as well). The card also says how many apps with the pencil it found.
- **Every patched app gets the pencil, not only the one patched last.** `HostProvider` answers any app that has the Live Editor
  engine inside (found through its content provider `<package>.liveeditagent`) and only for that app itself. The pencil is an
  overlay of Live Editor drawn above that app's screen. Each app remembers where you left the handle (it sticks to the nearer
  screen edge after a drag). The pencil puts itself on top again when the app adds a new floating window (the engine now sends the
  number of its floating windows with every 1.5 s report).
- **Pencil panel (overlay):** every window AND screen of the app with a bigger preview, *open now / closed*, *removed* mark,
  *Keep this interface* switch (bypass, never closes the app), an **opacity slider per window**, filters (All, Open now, Floating,
  Popups, Screens, Removed), *Restore all removed*, *Full pencil*, *Save and patch*, *Pencil OFF*. It refreshes itself every 3 s.
- **Previews of closed windows and screens.** The engine keeps a small picture (JPEG, `Thumbs.java`, folder `liveedit_thumbs`) of
  every window and screen, a few at a time, while Live Editor shows the pencil. Screens are remembered like popups now (one
  entry per screen), so the list stays complete when a screen is closed.
- **Windows and screens screen (Live Editor app):** *Pencil apps* on the home screen opens it for the app you tap (same list as the
  overlay, with *Refresh*, *Restore all removed*, *Open the app*, *Save and patch*). In the options screen, the card *Parts of the
  app* is now **Windows and screens**: *Windows and screens (with preview)* opens that list for the app (an app that is not patched
  yet shows the screens found in its manifest, without a picture). The old "switch off parts in the manifest" is kept below it as
  *Advanced*, with its crash warning.
- Patch the ORIGINAL app again with this version to get previews of closed windows, the opacity slider and *Restore all removed*
  (apps patched with 2.19 still get the pencil and the list, without those three).
- Not run on a phone here, and no Android SDK in this environment: the whole source was parsed with the JDK compiler (no syntax
  errors, no unresolved names of our own classes; only the Android classes themselves are missing there). Build it with the usual
  workflow and test: switch OFF / ON, two different patched apps, windows list with previews, opacity slider, restore all.

### New in 2.19 (Pencil apps, Save and patch from the pencil, no self-drawn lines)
- **The pencil comes from Live Editor, above the app you patched last.** After a patch with *Live Editor inside the app* on, Live Editor
  remembers that app (only that one, key `recent`). Allow "Display over other apps" for Live Editor once (button on the done screen).
  When you open the patched app, its engine tells Live Editor every 1.5 s that it is on screen (`HostLink` -> `HostProvider`,
  authority `com.liveedit.patcher.host`) and Live Editor shows the pencil as an overlay above it (`PencilHost`). The app's own pencil
  stays away while that works; if Live Editor cannot show it (no permission, not installed) the in-app pencil is used as before. The
  pencil goes away when the app leaves the screen or the reports stop (6 s).
  The panel has the **windows list** of the app: a small picture of every menu, floating button, popup and dialog, and a *Keep this
  interface* switch to remove it (bypassed, never closed, same crash guards as the in-app Windows tab). *Full pencil* opens the in-app
  panel (Items, Global, Theme, More). *Save and patch* builds the normal APK without the pencil. The engine answers only Live Editor
  (`AgentProvider.call`: `windows`, `keep`, `panel`). Needs an app patched with 2.19.
- **Pencil apps (Live Editor home).** A new card lists every installed app that has the Live Editor engine inside (apps with the
  pencil first, found through the engine's content provider `<package>.liveeditagent`). Tap an app: *Save edits and remove the pencil*,
  *Open the app*, *Uninstall*.
- **Save and patch from the pencil.** Pencil panel > **More > Save and patch (remove the pencil)**. The pencil sends the app's package
  name to the Live Editor app, which copies that app's APK, reads the current settings straight from it (nothing is copied or pasted),
  builds a normal APK without the pencil (every edit built in) and opens Android's install screen. The new APK has the same package
  and the same key, so it installs as an update and the app's data stays. You no longer patch the original again.
  If the read of the settings fails, nothing is built (so edits are never lost silently). If Android blocks the pencil from opening
  Live Editor (apps patched before 2.19 have no permission for it), open Live Editor > Pencil apps > the app instead.
- **Origin line width = the number in the code.** The marker, the distance, the Lock layer and the 8 s recording are gone: nothing draws
  or redraws lines any more (`LineTips.java` is deleted). The thickness set in the pencil (Global > Lines or Items > the line) is
  applied by finding the Paint of the app's own line and setting its stroke width, and when you Save and patch, the same number is
  also written into the app's code (the number next to `Paint.setStrokeWidth` that the scan marks *ORIGIN LINES (top)*, class `n1`).
- Old settings that contain `tipOn`, `tipPng`, `lockOn` ... are simply ignored.
- The patcher adds `QUERY_ALL_PACKAGES` to apps patched with the pencil, so the pencil can find and open Live Editor on Android 11+.
- Not run on a phone here, and no Android SDK in this environment: edited and checked by reading the code only. Build it with the usual
  workflow and test: Pencil apps list, More > Save and patch, line width after the update.

### New in 2.18 (fewer crashes, a stronger pencil, never-update)
- **Catches more crashes, not just a missing library (`Guard`).** Before, the always-safe fallback only caught a missing
  native library on the wrong CPU. Now it catches ANY crash on the main thread once the app has been running about 2
  seconds (so a genuine startup problem still shows), logs it and keeps the app open instead of closing it. It is
  always on now, not only in "Make it run on my phone" mode. It cannot catch a crash on an unguarded background
  thread, a hard native crash, or the app calling System.exit() / Process.killProcess() itself, and a crash that
  keeps looping still closes the app (so it does not freeze).
- **The pencil retries instead of giving up after one failure.** On some apps the very first attempt to add the
  floating pencil fails (a timing issue, not a real permission problem); before, that was permanent for the whole
  run and the pencil was stuck inside the app's own screens. It now retries up to 6 times on the normal tick (about
  4 seconds) before falling back, with a toast explaining what happened.
- **"Never update this app"** (patcher, card *Servers and ads*): blocks the app's own Play Store / "Update" page
  (even with Links set to OFF) and the common servers apps use to check for or fetch an update. It cannot stop an
  update you start yourself from the Play Store, and an app with its own update server outside the known list may
  still update.
- **Windows tab already does this**, in case it was missed: Items > Windows lists every window with a small picture
  and a *Keep this interface* switch; turning it off removes that window (bypassed, not force-closed, so it cannot
  crash the app).

### New in 2.15 (distance removed, Lock switch in its place)
- **The engine lives INSIDE each patched app.** Building a new Live Editor does not change an app you patched before: its pencil
  panel keeps the old engine (still showing Distance). Patch the ORIGINAL app again with the new Live Editor and install it.
  The pencil panel now shows the engine version on its Close button ("Close  2.16").
- Version 2.16 (versionCode 16). The patcher app shows its version under the title, so you can see at once which build is on
  the phone (2.14 = the old one with the distance meter). If a build still shows 2.14, the repo built an older zip.
- The distance counter is gone: no meters next to the marker, no 3D model, no flat scale, no reference points, no red marker
  when close, and the code that read numbers from the app's drawing. Old saved settings with those keys are ignored.
- **Lock lines to targets** is now a real ON / OFF switch in the place where Distance was (Global > Lines, and Items > the
  line layer), with a status line that says whether the lock is working (OFF / waiting for lines / N lines locked / refused
  by the screen). Turning the switch off and on tries again after a refusal (before, one refusal stayed until the app was
  restarted).
- **Fixed: held numbers were fed to the lock as new reports.** The app draws the numbers of its last report again on every
  frame; the filter took each of those for a new report, so its speed fell to zero between reports. Now numbers that did not
  change are skipped, and the gap between reports is measured only between two real reports.
- **Record 8 s of line data** (Lock section): switch Lock ON, press it, swipe in the app; frame pacing, report gaps, steps, the
  error of the current engine and a trace of 3 lines are copied as text (`LineTips.recordStop`). Paste it to tune the lock.
- **No lock settings any more.** The presets and the three sliders are gone.
- **2.17: the lock glides instead of guessing.** A real recording (com.m1nx.vip, 8 s) showed about 10 reports a second, 15 - 400 ms
  apart, big jumps while swiping and uneven frames (20 % slower than 24 ms). Guessing where a line goes next (dead reckoning)
  overshot there: it was 129 px off at each new report, worse than the app alone (86 px). Now every line end glides to the app's
  new number with a time constant of 0.4 x the measured report gap (25 - 70 ms): about 94 px off, never an overshoot, about 19 px
  behind the app. The app's own shake under 2.5 px is ignored. A jump of more than 300 dp (a target going behind you) snaps at
  once. A missing line is kept 1.8 x the report gap (60 - 260 ms). Replay of the recording: `Replay` harness in the chat.

### New in 2.14 (lines locked to targets, VR style)
Pencil panel > **Global > Lines** (and **Items > the line / drawing layer**).
- **Lock lines to targets (VR style).** The app reports where its targets are only now and then, so while you swipe the lines move
  in steps and flicker. *Lock: ON* hides the app's own line drawing (the line view is kept at alpha 0.004) and draws the lines,
  markers and numbers again on one transparent, untouchable layer window at EVERY screen refresh (`LineTips.Layer`, same window
  type / transparency as the app's own line window). Between two reports each line end keeps moving the way it was moving
  (dead reckoning, an alpha-beta filter for irregular reports, like pose prediction in VR); when a new report arrives the picture
  is blended to it with an exponential correction, so nothing jumps. A stop is believed at once (the speed follows the measured
  value immediately when the target moved less than expected). A line the app misses for a frame or two is kept for a moment, so
  it does not blink. Sliders: *Anti-lag prediction* 0 - 80 ms, *Smoothness* 0 - 150 ms, *Keep a missing line* 0 - 300 ms; presets
  Balanced / Max smooth / Snappy.
- Measured on a PC with a simulated stair-step feed (reports every 33 ms, target moving 2000 px/s): the position error falls from
  38.3 px (holding the last report) to 1.9 px; a standing target does not drift; the biggest step between two 16 ms frames stays
  below 2x the real motion; after a sudden stop the line settles on the real position, running past by at most speed x (report gap +
  prediction), for example 70 px at 2000 px/s with the Balanced preset (about 35 px at 1000 px/s). Lower the prediction if that
  bothers you.
- Honest limits: nothing can know where a target really is before the app does, so the very first instant of a sudden swipe can
  still lag a little. If an app shows its lines twice or not at all with Lock on (it resets the view's alpha, or the overlay window
  type is refused), switch Lock off: it puts the alpha back, and a failure while setting it up also puts everything back.
- Settings carried by *Copy settings* / *Convert live APK to normal*: `lockOn`.
- Not run on a phone here: compiled against stand-ins for the Android classes and tested on a PC (line / origin / track logic,
  hold, number reading, 3D model maths, red margin, the point filter as above). On the phone, test: Lock on, swipe left and right
  (steps should be gone); Lock off again (the app's own lines must come back); a text such as `23m` next to a target must be used.

### New in 2.13 (PNG marker on the line ends)
Pencil panel > **Global > Lines** (and **Items > the line / drawing layer**), section *Marker on the end of the lines (PNG)*. (The distance counting and the red marker of 2.13 / 2.14 were removed in 2.15.)
- **PNG marker on every line.** *Marker: ON* puts a picture on the end of EVERY line that starts at the origin. *Choose PNG*
  takes any PNG (scaled down once, transparency kept); *Built-in marker* is the small triangle that points down. The picture is
  never rotated: it stays upright, tip down, wherever the line goes (up, down, left, right). Size 1 - 20 dp with exact
  `- 1` / `+ 1` buttons. *Tip on the line end* (the point of the picture touches the end of the line; the tip is found from the
  visible pixels, so transparent borders do not matter) or *Centered on the end*.
- **Why there is no flicker or lag:** before every frame, the view that draws the lines is drawn once more onto a recording
  canvas that paints nothing and only writes down each `drawLine` (start, end). Marker and distance are placed from those very
  numbers and painted in the overlay of that view, in the same frame the app draws its lines (`LineTips.java`). Nothing is added
  to the app's layout.
- **Fixed: the marker was gone after closing the app with Back and opening it again.** The marker was tied to the edit crash
  guard, and an app that ends its process on Back looked like a crash of the edit, so the marker was switched off at the next
  start. The marker no longer uses that guard (it has its own: an error while reading a view switches it off for that view
  only), and a screen that is finished with Back / finish() now counts as a deliberate exit for the guard. The line view is
  also looked for again every 0.4 s (at once when the old one is gone), so a line view the app creates again is found.
- The origin is the point that most lines share (it is remembered, so a frame with one single line still works). Box edges or
  other lines that do not touch the origin get no marker. A line the app draws twice gets one marker.
- Settings are saved with the live edits and carried by *Copy settings* and *Convert live APK to normal* (keys `tipOn`, `tipDp`,
  `tipAnchor`, `tipPng`, `distOn`, `distScale`, `distPos`, `nearRed`, `nearM`).
- Honest limits: the line view is drawn one extra time per frame, so an app that moves its lines INSIDE `onDraw` (smoothing that
  advances on every call) would move a little faster; switch the marker off then. Lines drawn with `drawLine`, `drawLines` or a
  straight `drawPath` are read; curves are not. A view with a hardware layer draws into its own bitmap, so its lines cannot be
  read. The fade-out idea from the first 2.13 draft was removed.
- Not run on a phone here: the engine compiled against stand-ins for the Android classes; the origin / line logic and the meter
  maths were tested on a PC. Test: marker on, close the app with Back, open it again and switch the lines on: the marker must be
  there. Then distance on, a line closer than 10 m must be red.

## How it works
- Manifest options are written straight into the binary `AndroidManifest.xml` (no apktool).
- Options that need code at run time are saved as `assets/liveedit_config.json` inside the APK, and a small engine
  (`agent.dex`) reads it at start. If no such option is ticked, no engine is added at all.
- The patched APK is signed with the key in `app/src/main/assets` (v1 + v2), checked with Android's own
  package parser, then installed from the same screen.

## Limits (honest)
- It changes the phone side only. It cannot change what a server sends back, or how an app counts a timer.
- Server blocking covers HttpURLConnection and OkHttp. WebView pages, Cronet/QUIC and raw sockets can still connect.
- Link blocking works on links the app starts itself (Intent). Links opened inside a WebView are not covered.
- The pencil appears in every patched app as soon as it opens. With "Display over other apps" it floats above
  everything (including the app's own floating windows); without it, it sits inside the app's own screen and can
  edit those screens, but cannot sit above other apps. Item list reads the app's windows through Android
  internals: on some Android versions it may only see the visible screen.
- Apps patched with an older Live Editor do not have the overlay permission in their manifest and keep their old
  engine: pick the original app again and patch it with this version.
- Compose / Flutter / game UIs only partly work (they draw without normal views).
- ARMv7 best-effort mode cannot give an app the code it needs: games and apps built around native libraries will not work.
- Auto-loading settings needs an app patched with this version (older patched apps: use copy and paste).
- Single APK only (no XAPK/APKS/split apps). System apps without code inside their APK cannot be patched.
- Apps that check their own signature may refuse to start. The original must be uninstalled first (data is lost).

## Build (GitHub Actions)
Same as the other projects: upload this zip to the repo root, the existing workflow unzips it and builds.
The project module is called `app`. The engine (`agent.dex`) is compiled by `app/build.gradle`
(it runs `tools/build_agent.sh` when Gradle starts), so no extra workflow step is needed.
There is no workflow file inside this zip on purpose: the one already in your repo is used.
