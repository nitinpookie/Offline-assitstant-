package com.liveedit.patcher;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/**
 * The pencil on apps that are NOT patched. Live Editor watches (through Accessibility) which app and which page (activity)
 * is on screen, shows its pencil above it, and remembers the pages of every app. The panel lists what is on the page,
 * the pages seen so far, and the covers the user put on this page.
 *
 * Honest limit: an app that is not patched cannot be changed from outside. A cover is a window of Live Editor drawn over an
 * element (it hides it, or only blocks the taps on it). The real edits (size, remove, colours) need the patched app.
 * Patched apps (with the Live Editor engine inside) keep their own pencil (PencilHost); this one stays away from them.
 */
public final class AccessPencil extends AccessibilityService {

    private static final String SYSTEMUI = "com.android.systemui";
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    private static AccessPencil inst;

    private final Handler H = new Handler(Looper.getMainLooper());
    private final HashMap<String, Boolean> actCache = new HashMap<String, Boolean>();
    private WindowManager wm;

    private String curPkg;
    private String curPage;
    private String curLabel = "";
    private String homePkg = "";
    private long homeAt;
    private ArrayList<PageLog.Cover> curCovers = new ArrayList<PageLog.Cover>();

    private TextView handle;
    private WindowManager.LayoutParams hlp;

    private LinearLayout panel;
    private WindowManager.LayoutParams plp;
    private LinearLayout body;
    private TextView appLine;
    private TextView pageLine;
    private TextView classLine;
    private final TextView[] tabs = new TextView[3];
    private int tab;

    private final ArrayList<View> coverViews = new ArrayList<View>();
    private View hl;

    private final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            try {
                applyCovers();
            } catch (Throwable t) {
                // never hurt the app below
            }
        }
    };

    private final Runnable HL_OFF = new Runnable() {
        @Override
        public void run() {
            clearHl();
        }
    };

    // =======================================================================================
    // service
    // =======================================================================================

    /** True when the user has switched this service on in Accessibility settings. */
    static boolean isEnabled(Context c) {
        try {
            String v = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (v == null || v.length() == 0) return false;
            ComponentName me = new ComponentName(c, AccessPencil.class);
            for (String s : v.split(":")) {
                ComponentName cn = ComponentName.unflattenFromString(s);
                if (cn != null && cn.equals(me)) return true;
            }
        } catch (Throwable t) {
            // unknown: say off
        }
        return false;
    }

    /** The pencil switch went ON (it is switched in Live Editor itself): show the pencil on this screen without waiting for a page change. */
    static void showNow() {
        final AccessPencil a = inst;
        if (a == null) return;
        a.H.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (a.curPkg == null && PencilPrefs.isOn(a.getApplicationContext())) {
                        a.enter(a.getPackageName(), "com.liveedit.patcher.MainActivity");
                    }
                } catch (Throwable t) {
                    // never hurt the app below
                }
            }
        });
    }

    /** The pencil switch went OFF: take everything away at once. */
    static void hideAll() {
        final AccessPencil a = inst;
        if (a == null) return;
        a.H.post(new Runnable() {
            @Override
            public void run() {
                a.leave();
            }
        });
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
    }

    @Override
    public void onInterrupt() {
        // nothing to interrupt
    }

    @Override
    public boolean onUnbind(Intent intent) {
        leave();
        if (inst == this) inst = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        leave();
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        try {
            if (e == null || e.getPackageName() == null) return;
            String pkg = e.getPackageName().toString();
            int type = e.getEventType();
            String cls = e.getClassName() == null ? "" : e.getClassName().toString();
            if (pkg.equals(getPackageName())) {
                // our own overlays are quiet (no loop); a screen of Live Editor itself gets the pencil like any other app
                if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && isActivity(pkg, cls)) {
                    if (PencilPrefs.isOn(getApplicationContext())) enter(pkg, cls);
                    else if (curPkg != null) leave();
                }
                return;
            }
            if (!PencilPrefs.isOn(getApplicationContext())) {
                if (curPkg != null) leave();
                return;
            }
            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                if (isActivity(pkg, cls)) {
                    enter(pkg, cls);
                } else if (pkg.equals(curPkg)) {
                    later(); // a dialog or popup of the same app
                }
                return;
            }
            if (pkg.equals(curPkg)) later();
        } catch (Throwable t) {
            // never hurt the app below
        }
    }

    // =======================================================================================
    // which app and page
    // =======================================================================================

    private boolean isActivity(String pkg, String cls) {
        if (cls == null || cls.indexOf('.') < 0) return false;
        String key = pkg + "/" + cls;
        Boolean b = actCache.get(key);
        if (b != null) return b.booleanValue();
        boolean ok;
        try {
            getPackageManager().getActivityInfo(new ComponentName(pkg, cls), 0);
            ok = true;
        } catch (Throwable t) {
            ok = false;
        }
        if (actCache.size() > 400) actCache.clear();
        actCache.put(key, Boolean.valueOf(ok));
        return ok;
    }

    private String home() {
        long now = System.currentTimeMillis();
        if (now - homeAt > 60000L) {
            homeAt = now;
            try {
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_HOME);
                ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
                homePkg = ri != null && ri.activityInfo != null ? ri.activityInfo.packageName : "";
            } catch (Throwable t) {
                homePkg = "";
            }
        }
        return homePkg;
    }

    /**
     * Only the system bars (status bar, notification shade) get no pencil from here. Live Editor itself, the launcher and
     * patched apps DO get it (patched apps together with their own one from PencilHost / the engine): two pencils are fine,
     * none is not.
     */
    private boolean ignored(String pkg) {
        return pkg.equals(SYSTEMUI);
    }

    /** A patched app already shows its own pencil at the default place; this one gets its own place so they never sit on each other. */
    private boolean twin(String pkg) {
        return pkg != null && PencilPrefs.engineNow(getApplicationContext(), pkg);
    }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Throwable t) {
            return pkg;
        }
    }

    private static String simple(String cls) {
        if (cls == null || cls.length() == 0) return "?";
        int i = Math.max(cls.lastIndexOf('.'), cls.lastIndexOf('$'));
        return i >= 0 && i < cls.length() - 1 ? cls.substring(i + 1) : cls;
    }

    private void enter(String pkg, String cls) {
        if (ignored(pkg)) {
            leave();
            return;
        }
        boolean sameApp = pkg.equals(curPkg);
        boolean samePage = sameApp && cls.equals(curPage);
        if (!sameApp) {
            closePanel();
            dropCoverWins();
            removeHandle();
        } else if (!samePage) {
            dropCoverWins(); // covers belong to one page
        }
        curPkg = pkg;
        curPage = cls;
        if (!sameApp) curLabel = labelOf(pkg);
        if (!samePage) {
            PageLog.seen(this, pkg, cls);
            curCovers = PageLog.covers(this, pkg, cls);
        }
        showHandle();
        if (panel != null) render();
        later();
    }

    private void leave() {
        H.removeCallbacks(TICK);
        closePanel();
        clearHl();
        dropCoverWins();
        removeHandle();
        curPkg = null;
        curPage = null;
        curCovers = new ArrayList<PageLog.Cover>();
    }

    private void later() {
        H.removeCallbacks(TICK);
        H.postDelayed(TICK, 220L);
    }

    // =======================================================================================
    // windows
    // =======================================================================================

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private WindowManager.LayoutParams lp(int w, int h, int extraFlags) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                extraFlags | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return p;
    }

    /** Puts the pencil (and its panel) above every cover window. */
    private void raise() {
        if (wm == null) return;
        if (handle != null) {
            try {
                wm.removeView(handle);
                wm.addView(handle, hlp);
            } catch (Throwable t) {
                handle = null;
            }
        }
        if (panel != null) {
            try {
                wm.removeView(panel);
                wm.addView(panel, plp);
            } catch (Throwable t) {
                panel = null;
                body = null;
            }
        }
    }

    // ---- the handle -----------------------------------------------------------------------------

    private void showHandle() {
        if (handle != null || wm == null || curPkg == null) return;
        if (PageLog.isMuted(this, curPkg)) return;
        int[] pos = twin(curPkg) ? PageLog.posTwin(this) : PageLog.pos(this);
        handle = buildHandle();
        hlp = lp(dp(46), dp(46), WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        hlp.x = pos[0];
        hlp.y = pos[1];
        try {
            wm.addView(handle, hlp);
        } catch (Throwable t) {
            handle = null;
        }
    }

    private void removeHandle() {
        if (handle == null) return;
        try {
            wm.removeView(handle);
        } catch (Throwable t) {
            // already gone
        }
        handle = null;
    }

    private TextView buildHandle() {
        final TextView t = new TextView(this);
        t.setText("\u270E");
        t.setTextSize(20);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.round(this, Ui.ACCENT, 23));
        t.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;
            private int startX;
            private int startY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = hlp.x;
                        startY = hlp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        if (moved) {
                            hlp.x = Math.max(0, startX + Math.round(dx));
                            hlp.y = Math.max(0, startY + Math.round(dy));
                            try {
                                wm.updateViewLayout(t, hlp);
                            } catch (Throwable ex) {
                                // ignore
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel();
                        else snap(t);
                        return true;
                    default:
                        return true;
                }
            }
        });
        return t;
    }

    /** After a drag the handle sticks to the nearer side of the screen, and its place is remembered. */
    private void snap(View t) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int size = dp(46);
        hlp.x = hlp.x + size / 2 < dm.widthPixels / 2 ? dp(4) : dm.widthPixels - size - dp(4);
        hlp.y = Math.min(hlp.y, dm.heightPixels - size);
        try {
            wm.updateViewLayout(t, hlp);
        } catch (Throwable ex) {
            // ignore
        }
        if (twin(curPkg)) PageLog.savePosTwin(this, hlp.x, hlp.y);
        else PageLog.savePos(this, hlp.x, hlp.y);
    }

    // ---- the panel ------------------------------------------------------------------------------

    private void togglePanel() {
        if (panel != null) {
            closePanel();
            return;
        }
        // a patched app gets the old pencil menu (windows with previews, Keep this interface, Full pencil ...)
        if (curPkg != null && twin(curPkg)
                && PencilHost.toggleFor(this, wm, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, curPkg)) {
            return;
        }
        openPanel();
    }

    private void closePanel() {
        PencilHost.closeBorrowed();
        if (panel == null) return;
        try {
            wm.removeView(panel);
        } catch (Throwable t) {
            // already gone
        }
        panel = null;
        body = null;
    }

    private void openPanel() {
        if (panel != null || wm == null || curPkg == null) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = Math.min(dm.widthPixels - dp(24), dp(440));
        int h = Math.round(dm.heightPixels * 0.72f);

        panel = Ui.vbox(this);
        panel.setBackground(Ui.round(this, Ui.BG, 18));
        panel.setPadding(dp(12), dp(12), dp(12), dp(10));

        LinearLayout head = Ui.hbox(this);
        appLine = Ui.text(this, curLabel, 16, Ui.TEXT, true);
        appLine.setSingleLine(true);
        appLine.setEllipsize(TextUtils.TruncateAt.END);
        head.addView(appLine, new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView x = Ui.chip(this, "\u2715");
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closePanel();
            }
        });
        head.addView(x);
        panel.addView(head);

        pageLine = Ui.text(this, "", 13, Ui.SUB, false);
        pageLine.setPadding(0, dp(6), 0, 0);
        panel.addView(pageLine);
        classLine = Ui.text(this, "", 10.5f, Ui.SUB, false);
        panel.addView(classLine);

        LinearLayout tabRow = Ui.hbox(this);
        tabRow.setPadding(0, dp(8), 0, dp(8));
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            tabs[i] = Ui.chip(this, "");
            tabs[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tab = idx;
                    render();
                }
            });
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(WRAP, WRAP);
            tl.rightMargin = dp(6);
            tabRow.addView(tabs[i], tl);
        }
        panel.addView(tabRow);

        ScrollView sv = new ScrollView(this);
        body = Ui.vbox(this);
        sv.addView(body, new ViewGroup.LayoutParams(MATCH, WRAP));
        panel.addView(sv, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout foot = Ui.hbox(this);
        foot.setPadding(0, dp(8), 0, 0);
        TextView mute = Ui.chip(this, "Hide pencil in this app");
        mute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (curPkg != null) PageLog.mute(AccessPencil.this, curPkg);
                closePanel();
                removeHandle();
            }
        });
        TextView off = Ui.chip(this, "Pencil OFF");
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PencilPrefs.setOn(getApplicationContext(), false);
                leave();
            }
        });
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(WRAP, WRAP);
        fl.rightMargin = dp(8);
        foot.addView(mute, fl);
        foot.addView(off);
        panel.addView(foot);

        // a touch outside the panel closes it (the touch still reaches the app)
        panel.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_OUTSIDE) closePanel();
                return false;
            }
        });

        plp = lp(w, h, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);
        plp.gravity = Gravity.CENTER;
        try {
            wm.addView(panel, plp);
        } catch (Throwable t) {
            panel = null;
            body = null;
            return;
        }
        tab = 0;
        render();
    }

    private void header() {
        if (panel == null) return;
        appLine.setText(curLabel);
        pageLine.setText("Page: " + simple(curPage));
        classLine.setText(curPage == null ? "" : curPage);
        String[] names = {
            "On this page",
            "Pages (" + PageLog.pages(this, curPkg).size() + ")",
            "Covers (" + curCovers.size() + ")"
        };
        for (int i = 0; i < 3; i++) {
            tabs[i].setText(names[i]);
            tabs[i].setTextColor(i == tab ? Ui.WARN : Ui.TEXT);
        }
    }

    private void render() {
        if (panel == null || body == null || curPkg == null) return;
        header();
        body.removeAllViews();
        try {
            if (tab == 0) renderElements();
            else if (tab == 1) renderPages();
            else renderCovers();
        } catch (Throwable t) {
            body.addView(note("Could not read this page."));
        }
    }

    private TextView note(String s) {
        TextView t = Ui.text(this, s, 13, Ui.SUB, false);
        t.setPadding(dp(4), dp(10), dp(4), dp(10));
        return t;
    }

    private void addRow(View row) {
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(MATCH, WRAP);
        rl.topMargin = dp(8);
        body.addView(row, rl);
    }

    private LinearLayout card(String title, String sub, String sub2) {
        LinearLayout row = Ui.vbox(this);
        row.setBackground(Ui.round(this, Ui.CARD, 12));
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.addView(Ui.text(this, title, 14, Ui.TEXT, true));
        if (sub != null && sub.length() > 0) row.addView(Ui.text(this, sub, 11, Ui.SUB, false));
        if (sub2 != null && sub2.length() > 0) row.addView(Ui.text(this, sub2, 11, Ui.SUB, false));
        return row;
    }

    private TextView action(String label, View.OnClickListener l) {
        TextView c = Ui.chip(this, label);
        c.setOnClickListener(l);
        return c;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(WRAP, WRAP);
        p.rightMargin = dp(8);
        return p;
    }

    // ---- tab 0: what is on this page ---------------------------------------------------------------

    private void renderElements() {
        LinearLayout top = Ui.hbox(this);
        top.addView(action("Refresh list", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                render();
            }
        }));
        body.addView(top);
        ArrayList<El> els = scan();
        if (els.isEmpty()) {
            body.addView(note("Nothing readable on this page right now. Some screens (games, secure screens) hide "
                    + "themselves from Accessibility. Open the page and tap Refresh list."));
            return;
        }
        body.addView(note(els.size() + " things on this page. Show = flash it. Hide = cover it. Block taps = it stays "
                + "visible but cannot be tapped. Covers come back by themselves when this page opens again."));
        for (final El e : els) {
            LinearLayout row = card(e.label, e.sub, null);
            LinearLayout btns = Ui.hbox(this);
            btns.setPadding(0, dp(8), 0, 0);
            btns.addView(action("Show", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    highlight(e.r);
                }
            }), chipLp());
            btns.addView(action("Hide", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((TextView) v).setText("Done \u2713");
                    addCover(e, 0);
                }
            }), chipLp());
            btns.addView(action("Block taps", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((TextView) v).setText("Done \u2713");
                    addCover(e, 1);
                }
            }), chipLp());
            row.addView(btns);
            addRow(row);
        }
    }

    private static final class El {
        String label = "";
        String sub = "";
        String id;
        boolean dup;
        final Rect r = new Rect();
    }

    private static String str(CharSequence cs) {
        return cs == null ? "" : cs.toString().replace('\n', ' ').trim();
    }

    private static String shortId(String id) {
        if (id == null) return "";
        int i = id.indexOf('/');
        return i >= 0 ? id.substring(i + 1) : id;
    }

    private ArrayList<El> scan() {
        ArrayList<El> out = new ArrayList<El>();
        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
        } catch (Throwable t) {
            root = null;
        }
        if (root == null) return out;
        CharSequence rp = root.getPackageName();
        if (rp == null || curPkg == null || !curPkg.contentEquals(rp)) return out;
        walk(root, out, 0);
        Collections.sort(out, new Comparator<El>() {
            @Override
            public int compare(El a, El b) {
                if (a.r.top != b.r.top) return a.r.top < b.r.top ? -1 : 1;
                return a.r.left < b.r.left ? -1 : (a.r.left == b.r.left ? 0 : 1);
            }
        });
        // a view id used more than once (list rows) cannot be followed: such a cover stays at its place
        HashMap<String, Integer> seen = new HashMap<String, Integer>();
        for (El e : out) {
            if (e.id == null) continue;
            Integer n = seen.get(e.id);
            seen.put(e.id, n == null ? 1 : n + 1);
        }
        for (El e : out) {
            if (e.id != null && seen.get(e.id) > 1) e.dup = true;
        }
        return out;
    }

    private void walk(AccessibilityNodeInfo n, ArrayList<El> out, int depth) {
        if (n == null || depth > 40 || out.size() >= 150) return;
        if (!n.isVisibleToUser()) return;
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        boolean pass = n.isPassword();
        String text = pass ? "" : str(n.getText());
        String desc = pass ? "" : str(n.getContentDescription());
        String id = n.getViewIdResourceName();
        boolean click = n.isClickable();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        boolean huge = r.width() >= dm.widthPixels * 0.9f && r.height() >= dm.heightPixels * 0.6f;
        boolean keep = (pass || text.length() > 0 || desc.length() > 0 || click || id != null)
                && r.width() >= dp(8) && r.height() >= dp(8)
                && !(huge && text.length() == 0 && desc.length() == 0 && !click);
        if (keep) {
            El e = new El();
            String cn = n.getClassName() == null ? "" : simple(n.getClassName().toString());
            String label = pass ? "(password field)" : text.length() > 0 ? text : desc.length() > 0 ? desc
                    : id != null ? shortId(id) : cn;
            if (label.length() > 50) label = label.substring(0, 50) + "\u2026";
            e.label = label;
            e.sub = cn + (id != null ? " \u00b7 " + shortId(id) : "") + (click ? " \u00b7 clickable" : "");
            e.id = id;
            e.r.set(r);
            out.add(e);
        }
        int cnt = n.getChildCount();
        for (int i = 0; i < cnt; i++) {
            AccessibilityNodeInfo ch = n.getChild(i);
            if (ch != null) walk(ch, out, depth + 1);
        }
    }

    // ---- tab 1: the pages seen in this app ---------------------------------------------------------

    private static String ago(long t) {
        long s = Math.max(0L, (System.currentTimeMillis() - t) / 1000L);
        if (s < 90) return "just now";
        if (s < 5400) return (s / 60) + " min ago";
        if (s < 129600) return (s / 3600) + " h ago";
        return (s / 86400) + " days ago";
    }

    private void renderPages() {
        ArrayList<PageLog.Page> pages = PageLog.pages(this, curPkg);
        if (pages.isEmpty()) {
            body.addView(note("No pages yet. Open the pages of this app one by one; Live Editor remembers each one."));
            return;
        }
        body.addView(note("Pages of this app that Live Editor has seen (newest first)."));
        for (PageLog.Page p : pages) {
            int k = PageLog.coverCount(this, curPkg, p.cls);
            String title = simple(p.cls) + (p.cls.equals(curPage) ? "   \u2022 now" : "");
            String info = p.n + (p.n == 1 ? " visit" : " visits") + (k > 0 ? " \u00b7 " + k + (k == 1 ? " cover" : " covers") : "")
                    + " \u00b7 " + ago(p.t);
            addRow(card(title, p.cls, info));
        }
    }

    // ---- tab 2: covers on this page ----------------------------------------------------------------

    private void renderCovers() {
        if (curCovers.isEmpty()) {
            body.addView(note("No covers on this page. Open \"On this page\", pick a thing and tap Hide or Block taps."));
            return;
        }
        LinearLayout top = Ui.hbox(this);
        top.addView(action("Remove all on this page", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                curCovers = new ArrayList<PageLog.Cover>();
                saveCovers();
            }
        }));
        body.addView(top);
        for (int i = 0; i < curCovers.size(); i++) {
            final int idx = i;
            PageLog.Cover c = curCovers.get(i);
            LinearLayout row = card(c.label.length() > 0 ? c.label : "(no name)",
                    (c.mode == 0 ? "Hidden" : "Taps blocked") + (c.id.length() > 0 ? " \u00b7 follows " + shortId(c.id) : " \u00b7 fixed place"),
                    null);
            LinearLayout btns = Ui.hbox(this);
            btns.setPadding(0, dp(8), 0, 0);
            btns.addView(action("Remove", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (idx < curCovers.size()) curCovers.remove(idx);
                    saveCovers();
                }
            }));
            row.addView(btns);
            addRow(row);
        }
    }

    // =======================================================================================
    // covers and highlight
    // =======================================================================================

    private void addCover(El e, int mode) {
        if (curPkg == null || curPage == null) return;
        PageLog.Cover c = new PageLog.Cover();
        c.id = e.id == null || e.dup ? "" : e.id;
        c.l = e.r.left;
        c.t = e.r.top;
        c.r = e.r.right;
        c.b = e.r.bottom;
        c.mode = mode;
        c.label = e.label;
        curCovers.add(c);
        PageLog.saveCovers(this, curPkg, curPage, curCovers);
        header();
        applyCovers();
    }

    /** After a change of the list: save it, rebuild the cover windows and the panel. */
    private void saveCovers() {
        if (curPkg == null || curPage == null) return;
        PageLog.saveCovers(this, curPkg, curPage, curCovers);
        dropCoverWins();
        applyCovers();
        render();
    }

    private void dropCoverWins() {
        for (View v : coverViews) {
            if (v == null) continue;
            try {
                wm.removeView(v);
            } catch (Throwable t) {
                // already gone
            }
        }
        coverViews.clear();
    }

    private void removeCoverAt(int i) {
        if (i >= coverViews.size()) return;
        View v = coverViews.get(i);
        if (v == null) return;
        try {
            wm.removeView(v);
        } catch (Throwable t) {
            // already gone
        }
        coverViews.set(i, null);
    }

    /** Puts every cover of this page where its element is now (by view id), or at its saved place. */
    private void applyCovers() {
        if (curPkg == null || curPage == null || wm == null) return;
        if (curCovers.isEmpty()) {
            dropCoverWins();
            return;
        }
        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
        } catch (Throwable t) {
            root = null;
        }
        if (root == null) return;
        CharSequence rp = root.getPackageName();
        if (rp == null || !curPkg.contentEquals(rp)) return;
        boolean added = false;
        for (int i = 0; i < curCovers.size(); i++) {
            PageLog.Cover c = curCovers.get(i);
            Rect r = null;
            if (c.id.length() > 0) {
                try {
                    List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByViewId(c.id);
                    if (found != null) {
                        for (AccessibilityNodeInfo n : found) {
                            if (n.isVisibleToUser()) {
                                r = new Rect();
                                n.getBoundsInScreen(r);
                                break;
                            }
                        }
                    }
                } catch (Throwable t) {
                    r = null;
                }
            } else {
                r = new Rect(c.l, c.t, c.r, c.b);
            }
            if (r == null || r.width() < 2 || r.height() < 2) {
                removeCoverAt(i); // not on screen now
                continue;
            }
            if (placeCover(i, r, c.mode)) added = true;
        }
        while (coverViews.size() > curCovers.size()) {
            removeCoverAt(coverViews.size() - 1);
            coverViews.remove(coverViews.size() - 1);
        }
        if (added) raise();
    }

    private boolean placeCover(int i, Rect r, int mode) {
        while (coverViews.size() <= i) coverViews.add(null);
        View v = coverViews.get(i);
        int w = r.width();
        int h = r.height();
        if (v != null) {
            WindowManager.LayoutParams p = (WindowManager.LayoutParams) v.getTag();
            if (p.x != r.left || p.y != r.top || p.width != w || p.height != h) {
                p.x = r.left;
                p.y = r.top;
                p.width = w;
                p.height = h;
                try {
                    wm.updateViewLayout(v, p);
                } catch (Throwable t) {
                    // next tick
                }
            }
            return false;
        }
        v = new View(this);
        v.setBackgroundColor(mode == 0 ? 0xFF0E1013 : 0x00000000);
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                return true; // the cover keeps the touch: the element under it is not tapped
            }
        });
        WindowManager.LayoutParams p = lp(w, h, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        p.x = r.left;
        p.y = r.top;
        v.setTag(p);
        try {
            wm.addView(v, p);
        } catch (Throwable t) {
            return false;
        }
        coverViews.set(i, v);
        return true;
    }

    private void highlight(Rect r) {
        clearHl();
        if (wm == null || r.width() < 2 || r.height() < 2) return;
        View v = new View(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x33FBBF24);
        g.setStroke(dp(3), 0xFFFBBF24);
        v.setBackground(g);
        WindowManager.LayoutParams p = lp(r.width(), r.height(), WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        p.x = r.left;
        p.y = r.top;
        try {
            wm.addView(v, p);
            hl = v;
            H.postDelayed(HL_OFF, 1500L);
        } catch (Throwable t) {
            hl = null;
        }
    }

    private void clearHl() {
        H.removeCallbacks(HL_OFF);
        if (hl == null) return;
        try {
            wm.removeView(hl);
        } catch (Throwable t) {
            // already gone
        }
        hl = null;
    }
}
