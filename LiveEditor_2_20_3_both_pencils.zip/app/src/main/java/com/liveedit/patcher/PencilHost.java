package com.liveedit.patcher;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * The pencil of ANY patched app (every app that has the Live Editor engine inside), shown by Live Editor itself as an
 * overlay on top of that app's screen, so the patched app needs no overlay permission of its own. The app reports every
 * 1.5 s that it is on screen; when the reports stop, or it says it left, the pencil goes away. The pencil can be switched
 * off in Live Editor (PencilPrefs, default ON).
 *
 * The panel lists every window and screen of the app with a preview picture (also those that are closed right now),
 * a Keep switch to remove a window (bypassed, never closed) and an opacity slider, with filters; it can restore all
 * removed windows, open the full in-app pencil and start "Save and patch". It refreshes itself every 3 s while open.
 * The pencil puts itself on top again when the app adds a new floating window. All view work runs on the main thread.
 */
final class PencilHost {

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final HashMap<String, int[]> POS = new HashMap<String, int[]>();

    private static Context ctx;
    private static Context app;
    private static WindowManager wm;
    private static String pkg;
    private static String label = "";
    private static Drawable icon;
    private static long lastBeat;
    private static boolean watching;
    private static int lastN = -1;

    private static TextView handle;
    private static WindowManager.LayoutParams hlp;
    private static boolean dragging;

    private static LinearLayout panel;
    private static WindowManager.LayoutParams plp;
    private static LinearLayout list;
    private static TextView status;
    private static final ArrayList<TextView> chips = new ArrayList<TextView>();
    private static int filter;
    private static JSONArray lastArr;
    private static String lastRaw;
    private static boolean autoOn;
    /** The panel is shown through the Accessibility pencil (its window manager and overlay type), no overlay permission needed. */
    private static boolean borrowed;
    private static int borrowedType;

    private PencilHost() {}

    private static final Runnable WATCH = new Runnable() {
        @Override
        public void run() {
            watching = false;
            if (handle == null) return;
            if (SystemClock.uptimeMillis() - lastBeat > 6000L || (app != null && !PencilPrefs.isOn(app))) {
                hideNow();
                return;
            }
            watching = true;
            H.postDelayed(this, 2000L);
        }
    };

    private static final Runnable AUTO = new Runnable() {
        @Override
        public void run() {
            autoOn = false;
            if (panel == null) return;
            if (!WinRows.touching && !dragging) refresh();
            autoOn = true;
            H.postDelayed(this, 3000L);
        }
    };

    private static final WinRows.Cmd CMD = new WinRows.Cmd() {
        @Override
        public void run(String method, String arg, Bundle extras) {
            WinRows.call(app, pkg, method, arg, extras);
        }
    };

    // ---- the heartbeat of a patched app ---------------------------------------------------------

    /** The app is on screen. Returns true when the pencil is showing (then the app hides its own). */
    static boolean beat(final Context application, final String p, final int n) {
        if (!PencilPrefs.canOverlay(application)) return false;
        final boolean[] ok = new boolean[1];
        final CountDownLatch done = new CountDownLatch(1);
        H.post(new Runnable() {
            @Override
            public void run() {
                try {
                    ok[0] = showNow(application, p, n);
                } catch (Throwable t) {
                    ok[0] = false;
                } finally {
                    done.countDown();
                }
            }
        });
        try {
            done.await(2, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // answer what we have
        }
        return ok[0];
    }

    /** The app left the screen. */
    static void leave(final String p) {
        H.post(new Runnable() {
            @Override
            public void run() {
                if (p != null && p.equals(pkg)) hideNow();
            }
        });
    }

    /** The pencil switch of Live Editor went OFF: everything goes away at once. */
    static void shutdown() {
        H.post(new Runnable() {
            @Override
            public void run() {
                hideNow();
            }
        });
    }

    private static boolean showNow(Context application, String p, int n) {
        lastBeat = SystemClock.uptimeMillis();
        if (handle != null && p.equals(pkg)) {
            // the app added a floating window of its own: the pencil must stay above it
            if (lastN >= 0 && n > lastN && !dragging) raise();
            lastN = n;
            return true;
        }
        hideNow();
        app = application;
        ctx = new ContextThemeWrapper(application, android.R.style.Theme_Material);
        wm = (WindowManager) application.getSystemService(Context.WINDOW_SERVICE);
        pkg = p;
        lastN = n;
        label = p;
        icon = null;
        try {
            PackageManager pm = application.getPackageManager();
            label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(p, 0)));
            icon = pm.getApplicationIcon(p);
        } catch (Throwable t) {
            // the package name is enough
        }
        int[] pos = POS.get(p);
        if (pos == null) {
            pos = new int[] {Ui.dp(ctx, 4), Ui.dp(ctx, 176)}; // the app's own in-app pencil sits at 120 dp: both stay visible
            POS.put(p, pos);
        }
        lastArr = null;
        lastRaw = null;
        filter = 0;
        handle = buildHandle();
        hlp = new WindowManager.LayoutParams(Ui.dp(ctx, 46), Ui.dp(ctx, 46), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        hlp.gravity = Gravity.TOP | Gravity.LEFT;
        hlp.x = pos[0];
        hlp.y = pos[1];
        try {
            wm.addView(handle, hlp);
        } catch (Throwable t) {
            handle = null;
            return false;
        }
        if (!watching) {
            watching = true;
            H.postDelayed(WATCH, 2000L);
        }
        return true;
    }

    private static int overlayType() {
        if (borrowed) return borrowedType;
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : 2002;
    }

    /** Takes the pencil (and its panel) out and puts it in again, so it is above every window the app added meanwhile. */
    private static void raise() {
        if (handle == null || wm == null) return;
        try {
            wm.removeView(handle);
        } catch (Throwable t) {
            // already gone
        }
        try {
            wm.addView(handle, hlp);
        } catch (Throwable t) {
            handle = null;
            closePanel();
            return;
        }
        if (panel != null) {
            try {
                wm.removeView(panel);
            } catch (Throwable t) {
                // already gone
            }
            try {
                wm.addView(panel, plp);
            } catch (Throwable t) {
                panel = null;
                list = null;
                status = null;
            }
        }
    }

    private static void hideNow() {
        closePanel();
        if (handle != null) {
            try {
                wm.removeView(handle);
            } catch (Throwable t) {
                // already gone
            }
            handle = null;
        }
        pkg = null;
        lastN = -1;
        dragging = false;
        borrowed = false;
    }

    // ---- the handle ----------------------------------------------------------------------------

    private static TextView buildHandle() {
        final TextView t = new TextView(ctx);
        t.setText("\u270E");
        t.setTextSize(20);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.round(ctx, Ui.ACCENT, 23));
        t.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;
            private int startX;
            private int startY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = hlp.x;
                        startY = hlp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > Ui.dp(ctx, 6) || Math.abs(dy) > Ui.dp(ctx, 6)) moved = true;
                        if (moved) {
                            dragging = true;
                            hlp.x = Math.max(0, startX + Math.round(dx));
                            hlp.y = Math.max(0, startY + Math.round(dy));
                            try {
                                wm.updateViewLayout(t, hlp);
                            } catch (Throwable ex) {
                                // ignore
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        dragging = false;
                        if (!moved) {
                            togglePanel();
                        } else {
                            snapToEdge(t);
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        dragging = false;
                        return true;
                    default:
                        return true;
                }
            }
        });
        return t;
    }

    /** After a drag the handle sticks to the nearer side of the screen, and that place is remembered for this app. */
    private static void snapToEdge(View t) {
        try {
            int sw = ctx.getResources().getDisplayMetrics().widthPixels;
            int size = Ui.dp(ctx, 46);
            hlp.x = (hlp.x + size / 2 < sw / 2) ? Ui.dp(ctx, 2) : sw - size - Ui.dp(ctx, 2);
            wm.updateViewLayout(t, hlp);
            int[] pos = POS.get(pkg);
            if (pos != null) {
                pos[0] = hlp.x;
                pos[1] = hlp.y;
            }
        } catch (Throwable ex) {
            // stays where it is
        }
    }

    // ---- the panel -----------------------------------------------------------------------------

    private static void togglePanel() {
        if (panel != null) closePanel();
        else openFull();
    }

    /**
     * A tap on the pencil of a patched app opens the full pencil menu inside that app (Items, Windows, Global, Theme, More: the same
     * menu as the app's own pencil, like 2.18). Only when the engine of the app does not answer (an app patched before 2.19, or
     * the app is not running) the short windows panel opens instead, so a tap always shows something.
     */
    private static void openFull() {
        final String p = pkg;
        final Context a = app;
        if (p == null || a == null) {
            openPanel();
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean ok = false;
                try {
                    Bundle b = a.getContentResolver().call(Uri.parse("content://" + p + ".liveeditagent"), "panel", null, null);
                    ok = b != null && "ok".equals(b.getString("json"));
                } catch (Throwable t) {
                    ok = false;
                }
                if (ok) return;
                H.post(new Runnable() {
                    @Override
                    public void run() {
                        if (panel == null && p.equals(pkg)) openPanel();
                    }
                });
            }
        }, "pencil-full").start();
    }

    private static void closePanel() {
        H.removeCallbacks(AUTO);
        autoOn = false;
        if (panel != null) {
            try {
                wm.removeView(panel);
            } catch (Throwable t) {
                // already gone
            }
        }
        panel = null;
        list = null;
        status = null;
        chips.clear();
        if (borrowed) {
            borrowed = false;
            pkg = null;
        }
    }

    /**
     * The windows panel (every window and screen with a preview, Keep this interface, Full pencil, Save and patch) for a
     * patched app, opened from the Accessibility pencil. It is built with that service's window manager and overlay type, so it
     * needs no "Display over other apps". A second tap closes it. Main thread. Returns false when it could not be opened.
     */
    static boolean toggleFor(Context service, WindowManager serviceWm, int type, String p) {
        if (service == null || serviceWm == null || p == null) return false;
        try {
            if (panel != null) {
                closePanel();
                return true;
            }
            if (handle != null && p.equals(pkg)) {
                // the overlay pencil of this app is up as well: the full pencil menu opens as usual
                borrowed = false;
                openFull();
                return true;
            }
            if (handle != null) hideNow();
            app = service.getApplicationContext();
            ctx = new ContextThemeWrapper(service, android.R.style.Theme_Material);
            wm = serviceWm;
            pkg = p;
            label = p;
            icon = null;
            try {
                PackageManager pm = app.getPackageManager();
                label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(p, 0)));
                icon = pm.getApplicationIcon(p);
            } catch (Throwable t) {
                // the package name is enough
            }
            lastArr = null;
            lastRaw = null;
            filter = 0;
            borrowed = true;
            borrowedType = type;
            openFull();
            return true;
        } catch (Throwable t) {
            borrowed = false;
            return false;
        }
    }

    /** The Accessibility pencil changed app or went away: a panel that was opened through it goes too. */
    static void closeBorrowed() {
        if (borrowed) closePanel();
    }

    private static LinearLayout.LayoutParams wrap(int rightDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = Ui.dp(ctx, rightDp);
        return lp;
    }

    private static void openPanel() {
        try {
            int sw = ctx.getResources().getDisplayMetrics().widthPixels;
            int sh = ctx.getResources().getDisplayMetrics().heightPixels;
            LinearLayout box = Ui.vbox(ctx);
            box.setBackground(Ui.round(ctx, Ui.CARD, 16));
            box.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 10), Ui.dp(ctx, 12), Ui.dp(ctx, 10));

            LinearLayout head = Ui.hbox(ctx);
            if (icon != null) {
                ImageView iv = new ImageView(ctx);
                iv.setImageDrawable(icon);
                LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(Ui.dp(ctx, 28), Ui.dp(ctx, 28));
                il.rightMargin = Ui.dp(ctx, 8);
                head.addView(iv, il);
            }
            head.addView(Ui.text(ctx, label, 15, Ui.TEXT, true), new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView close = Ui.chip(ctx, "Close");
            close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closePanel();
                }
            });
            head.addView(close);
            box.addView(head);
            box.addView(Ui.text(ctx, "Every window and screen of this app, with a preview", 12, Ui.SUB, false));

            // actions
            HorizontalScrollView hs1 = new HorizontalScrollView(ctx);
            hs1.setHorizontalScrollBarEnabled(false);
            LinearLayout row1 = Ui.hbox(ctx);
            hs1.addView(row1);
            TextView refresh = Ui.chip(ctx, "\u21BB Refresh");
            refresh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    refresh();
                }
            });
            row1.addView(refresh, wrap(8));
            TextView full = Ui.chip(ctx, "Full pencil");
            full.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    WinRows.call(app, pkg, "panel", null, null);
                    closePanel();
                }
            });
            row1.addView(full, wrap(8));
            TextView restore = Ui.chip(ctx, "Restore all removed");
            restore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    WinRows.call(app, pkg, "restore", null, null);
                    Toast.makeText(app, "Bringing back every removed window...", Toast.LENGTH_SHORT).show();
                    H.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            refresh();
                        }
                    }, 700L);
                }
            });
            row1.addView(restore, wrap(8));
            TextView off = Ui.chip(ctx, "Pencil OFF");
            off.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(app, "Pencil is OFF. Switch it on again in Live Editor.", Toast.LENGTH_LONG).show();
                    PencilPrefs.setOn(app, false);
                }
            });
            row1.addView(off, wrap(0));
            Ui.add(box, hs1, 8);

            // filters
            HorizontalScrollView hs2 = new HorizontalScrollView(ctx);
            hs2.setHorizontalScrollBarEnabled(false);
            LinearLayout row2 = Ui.hbox(ctx);
            hs2.addView(row2);
            chips.clear();
            for (int i = 0; i < WinRows.FILTERS.length; i++) {
                final int fi = i;
                TextView c = Ui.chip(ctx, WinRows.FILTERS[i]);
                WinRows.styleChip(ctx, c, i == filter);
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        filter = fi;
                        for (int k = 0; k < chips.size(); k++) WinRows.styleChip(ctx, chips.get(k), k == filter);
                        render(true);
                    }
                });
                chips.add(c);
                row2.addView(c, wrap(8));
            }
            Ui.add(box, hs2, 8);

            android.widget.Button bake = Ui.button(ctx, "Save and patch (remove the pencil)", true);
            bake.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveAndPatch();
                }
            });
            Ui.add(box, bake, 8);

            status = Ui.text(ctx, "Reading the windows...", 12, Ui.SUB, false);
            Ui.add(box, status, 8);
            ScrollView sv = new ScrollView(ctx);
            list = Ui.vbox(ctx);
            sv.addView(list);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            slp.topMargin = Ui.dp(ctx, 6);
            box.addView(sv, slp);

            plp = new WindowManager.LayoutParams(Math.min(sw - Ui.dp(ctx, 24), Ui.dp(ctx, 440)),
                    Math.round(sh * 0.76f), overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            plp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            plp.y = Ui.dp(ctx, 50);
            wm.addView(box, plp);
            panel = box;
            lastRaw = null;
            refresh();
            if (!autoOn) {
                autoOn = true;
                H.postDelayed(AUTO, 3000L);
            }
        } catch (Throwable t) {
            panel = null;
        }
    }

    /** Asks the engine inside the patched app for its windows and screens (on a worker thread) and shows them. */
    private static void refresh() {
        final String p = pkg;
        if (p == null || app == null) return;
        if (status != null && lastArr == null) status.setText("Reading the windows...");
        WinRows.fetch(app, p, new WinRows.Result() {
            @Override
            public void got(JSONArray arr, String raw) {
                if (p.equals(pkg) && list != null) {
                    boolean same = raw != null && raw.equals(lastRaw);
                    lastArr = arr;
                    lastRaw = raw;
                    if (!same) render(false);
                }
            }
        });
    }

    private static void render(boolean force) {
        if (list == null || WinRows.touching) return;
        list.removeAllViews();
        if (lastArr == null) {
            if (status != null) status.setText("Could not open the full menu. This app must be patched again with this Live "
                    + "Editor (engine 2.20.3 or newer). Open the app, then tap Refresh.");
            return;
        }
        int shown = 0;
        for (int i = 0; i < lastArr.length(); i++) {
            JSONObject o = lastArr.optJSONObject(i);
            if (o == null || !WinRows.matches(o, filter)) continue;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(ctx, 8);
            list.addView(WinRows.row(ctx, o, CMD), lp);
            shown++;
        }
        if (status != null) {
            if (lastArr.length() == 0) {
                status.setText("No window found yet. Open the menus, popups and screens of the app once.");
            } else {
                status.setText(shown + " of " + lastArr.length() + " shown. Untick Keep to remove a window (it is "
                        + "bypassed, never closed). Updates every 3 s.");
            }
        }
    }

    private static void saveAndPatch() {
        final String p = pkg;
        if (p == null) return;
        try {
            Intent i = new Intent("com.liveedit.patcher.BAKE");
            i.setClassName(app.getPackageName(), MainActivity.class.getName());
            i.putExtra("pkg", p);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            hideNow();
            app.startActivity(i);
        } catch (Throwable t) {
            // Live Editor can still be opened by hand: Pencil apps > this app
        }
    }
}
