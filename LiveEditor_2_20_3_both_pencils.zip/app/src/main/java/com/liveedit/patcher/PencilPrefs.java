package com.liveedit.patcher;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * The ON / OFF switch of the Live Editor pencil (default: ON) and the list of apps that have the Live Editor engine
 * inside. Every such app gets the pencil on top of its screen, not only the one patched last.
 */
final class PencilPrefs {

    private static final String FILE = "liveeditor";
    private static final String ON = "pencil_on";
    private static final HashSet<String> ENGINE = new HashSet<String>();

    private PencilPrefs() {}

    /** The pencil switch. It is ON until the user switches it off. */
    static boolean isOn(Context c) {
        try {
            return c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ON, true);
        } catch (Throwable t) {
            return true;
        }
    }

    static void setOn(Context c, boolean on) {
        try {
            c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ON, on).apply();
        } catch (Throwable t) {
            // keep the old value
        }
        if (on) {
            PencilService.start(c);
            AccessPencil.showNow();
        } else {
            PencilHost.shutdown();
            AccessPencil.hideAll();
            PencilService.stop(c);
        }
    }

    static boolean canOverlay(Context c) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
    }

    /** True when this app carries the Live Editor engine (its content provider "package.liveeditagent" exists). */
    static boolean hasEngine(Context c, String pkg) {
        if (pkg == null || pkg.length() == 0) return false;
        synchronized (ENGINE) {
            if (ENGINE.contains(pkg)) return true;
        }
        try {
            if (c.getPackageManager().resolveContentProvider(pkg + ".liveeditagent", 0) != null) {
                synchronized (ENGINE) {
                    ENGINE.add(pkg);
                }
                return true;
            }
        } catch (Throwable t) {
            // not there
        }
        return false;
    }

    /**
     * Like {@link #hasEngine}, but asks Android again every time and keeps the list right: an app can go from patched to normal
     * ("Save and patch" without the pencil) and back, and the saved answer would be stale.
     */
    static boolean engineNow(Context c, String pkg) {
        if (pkg == null || pkg.length() == 0) return false;
        boolean has;
        try {
            has = c.getPackageManager().resolveContentProvider(pkg + ".liveeditagent", 0) != null;
        } catch (Throwable t) {
            has = false;
        }
        synchronized (ENGINE) {
            if (has) ENGINE.add(pkg);
            else ENGINE.remove(pkg);
        }
        return has;
    }

    /** Every installed app with the engine inside (found through its content provider), sorted by package name. */
    static List<String> scan(Context c) {
        ArrayList<String> out = new ArrayList<String>();
        try {
            PackageManager pm = c.getPackageManager();
            for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                try {
                    if (ai.packageName.equals(c.getPackageName())) continue;
                    if (pm.resolveContentProvider(ai.packageName + ".liveeditagent", 0) == null) continue;
                    out.add(ai.packageName);
                } catch (Throwable t) {
                    // skip this app
                }
            }
        } catch (Throwable t) {
            // empty list
        }
        Collections.sort(out);
        synchronized (ENGINE) {
            ENGINE.clear();
            ENGINE.addAll(out);
        }
        return out;
    }
}
