package com.liveedit.agent;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * What the Live Editor app may ask this app to do from its pencil overlay: list the windows (with small pictures),
 * keep or remove one, or open the full pencil panel. Runs on the main thread of this app; only called through
 * AgentProvider, which answers nobody but the Live Editor app.
 */
final class HostApi {

    private HostApi() {}

    static Bundle handle(final Context ctx, final String method, final String arg, final Bundle extras) {
        final Object[] box = new Object[1];
        final CountDownLatch done = new CountDownLatch(1);
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    box[0] = work(ctx, method, arg, extras);
                } catch (Throwable t) {
                    U.err("host api " + method, t);
                } finally {
                    done.countDown();
                }
            }
        });
        try {
            done.await(4, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // answer what we have
        }
        Bundle out = new Bundle();
        out.putString("json", box[0] == null ? "" : String.valueOf(box[0]));
        return out;
    }

    private static String work(Context ctx, String method, String arg, Bundle extras) throws Exception {
        if ("windows".equals(method)) return windows(ctx);
        if ("keep".equals(method)) {
            if (arg == null || arg.length() == 0) return "no key";
            boolean keep = extras == null || extras.getBoolean("keep", true);
            Rules.edit(arg).hide = !keep;
            Config.saveLive(ctx);
            Overlays.tick(ctx);
            return "ok";
        }
        if ("alpha".equals(method)) {
            if (arg == null || arg.length() == 0) return "no key";
            int pct = extras == null ? 100 : extras.getInt("alpha", 100);
            Rules.Rule r = Rules.edit(arg);
            r.alpha = pct >= 100 ? Rules.NONE : Math.max(10, pct);
            Config.saveLive(ctx);
            Overlays.tick(ctx);
            return "ok";
        }
        if ("restore".equals(method)) {
            Rules.showAll();
            Config.saveLive(ctx);
            Overlays.tick(ctx);
            return "ok";
        }
        if ("panel".equals(method)) {
            return Panel.showFromHost(ctx) ? "ok" : "no panel";
        }
        return "unknown";
    }

    private static String windows(Context ctx) throws Exception {
        List<Overlays.Win> all = Overlays.windows(ctx);
        JSONArray arr = new JSONArray();
        int used = 0;
        for (int i = 0; i < all.size(); i++) {
            Overlays.Win w = all.get(i);
            JSONObject o = new JSONObject();
            o.put("k", w.o.key);
            o.put("kind", w.kind);
            o.put("name", w.name);
            o.put("sub", w.sub);
            o.put("gone", w.gone);
            o.put("locked", w.locked);
            o.put("unsafe", w.unsafe);
            o.put("unsafeShow", w.unsafeShow);
            o.put("open", w.root != null);
            Rules.Rule rr = Rules.get(w.o.key);
            o.put("alpha", (rr == null || rr.alpha == Rules.NONE) ? 100 : rr.alpha);
            // a picture of the window as it is now; a closed one gets the picture saved earlier
            byte[] pb = null;
            Bitmap t = w.thumb;
            if (t != null && !t.isRecycled()) {
                if (w.root != null) {
                    Bitmap big = Overlays.snapshot(w.root, 110f, ctx);
                    if (big != null) {
                        Thumbs.put(ctx, w.tk, big);
                        pb = Thumbs.jpeg(big, 160, 78);
                        big.recycle();
                    }
                }
                if (pb == null) pb = Thumbs.jpeg(t, 160, 78);
            } else {
                pb = Thumbs.get(ctx, w.tk);
            }
            if (pb != null && pb.length < 30000 && used < 520000) {
                String b64 = Base64.encodeToString(pb, Base64.NO_WRAP);
                o.put("p", b64);
                used += b64.length();
            }
            arr.put(o);
        }
        return arr.toString();
    }
}
