package com.liveedit.patcher;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class MainActivity extends Activity {

    private static final int REQ_PICK = 42;
    private static final int REQ_SAVE = 43;
    private static final String INTERNET = "android.permission.INTERNET";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Opts opts = new Opts();
    private final List<Runnable> syncers = new ArrayList<Runnable>();
    private final StringBuilder logText = new StringBuilder();
    private final List<String> bootComps = new ArrayList<String>();
    private final List<String> privPerms = new ArrayList<String>();

    private FrameLayout root;
    private TextView barInfo;
    private TextView workLog;
    private ScrollView workScroll;
    private ProgressBar workBar;
    private ScrollView optScroll;

    private Patcher.Analysis an;
    private Patcher.Result last;
    private boolean busy;
    private boolean syncing;
    private int screen; // 0 home, 1 options, 2 working, 3 done / error
    private int scrollY;
    private String phoneAbi = "";
    private String fitAbi;
    private boolean convertMode;
    private boolean nixuMode;

    // =======================================================================================
    // lifecycle
    // =======================================================================================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        if (Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0) phoneAbi = Build.SUPPORTED_ABIS[0];
        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        setContentView(root);
        showHome();
    }

    @Override
    public void onBackPressed() {
        if (screen == 2) return; // working: wait
        if (screen == 1) {
            Ui.dialog(this).setTitle("Leave this app?")
                    .setMessage("Your selected options will be lost.")
                    .setPositiveButton("Leave", (d, w) -> showHome())
                    .setNegativeButton("Stay", null).show();
            return;
        }
        if (screen == 3 && an != null) {
            showOptions();
            return;
        }
        if (screen == 3) {
            showHome();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (req == REQ_PICK) {
            if (nixuMode) {
                final String nm = fileLabel(uri);
                openNixu(() -> {
                    File f = newInputFile();
                    InputStream is = getContentResolver().openInputStream(uri);
                    if (is == null) throw new IOException("Cannot open that file");
                    Patcher.copy(is, f);
                    return f;
                }, nm);
                return;
            }
            load(() -> {
                File f = newInputFile();
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open that file");
                Patcher.copy(is, f);
                return f;
            }, false);
        } else if (req == REQ_SAVE) {
            saveCopy(uri);
        }
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private void show(View v) {
        root.removeAllViews();
        root.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    // =======================================================================================
    // 1. home
    // =======================================================================================

    private SharedPreferences prefs() {
        return getSharedPreferences("liveeditor", MODE_PRIVATE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // the nixu cn editor can switch the mode off from its menu
        if (screen == 0 && root != null && prefs().getBoolean("nixu", false) != nixuMode) showHome();
    }

    private void showHome() {
        screen = 0;
        an = null;
        nixuMode = prefs().getBoolean("nixu", false);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(40), dp(18), dp(28));
        sv.addView(col);

        LinearLayout top = Ui.hbox(this);
        top.addView(Ui.text(this, "Live Editor", 32, Ui.TEXT, true), new LinearLayout.LayoutParams(0, WRAP, 1f));
        LinearLayout sw = Ui.vbox(this);
        sw.setGravity(Gravity.CENTER_HORIZONTAL);
        sw.addView(Ui.text(this, "nixu cn", 12, nixuMode ? Ui.GOOD : Ui.SUB, true));
        Switch nixuSwitch = new Switch(this);
        nixuSwitch.setChecked(nixuMode);
        nixuSwitch.setOnCheckedChangeListener((btn, on) -> {
            prefs().edit().putBoolean("nixu", on).apply();
            nixuMode = on;
            showHome();
        });
        sw.addView(nixuSwitch);
        top.addView(sw, new LinearLayout.LayoutParams(WRAP, WRAP));
        col.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));
        String verText = "";
        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            verText = "Version " + pi.versionName;
        } catch (Throwable t) {
            verText = "";
        }
        if (verText.length() > 0) col.addView(Ui.text(this, verText + "  (no distance meter, Lock switch)", 12, Ui.SUB, false));

        convertMode = false;
        if (nixuMode) {
            TextView nsub = Ui.text(this, "nixu cn mode is ON. The simple options are hidden. Open an APK to see every "
                    + "file inside it (classes.dex, resources.arsc, manifest, res, lib ...), edit them, then save and sign.",
                    14, Ui.SUB, false);
            nsub.setPadding(0, dp(6), 0, dp(22));
            col.addView(nsub);
            bigCard(col, "Open APK file", "From your phone storage or downloads", () -> pickFile());
            bigCard(col, "Open installed app", "Takes the APK straight from an app on this phone", () -> pickInstalled());
            LinearLayout ninfo = Ui.card(this);
            ninfo.setPadding(dp(16), dp(14), dp(16), dp(14));
            ninfo.addView(Ui.text(this, "Inside nixu cn", 15, Ui.TEXT, true));
            String[] nl = {
                    "MT Manager style file list: every entry is shown, nothing is hidden",
                    "AndroidManifest.xml and res/*.xml: edit as text (compiled again on save)",
                    "resources.arsc: Arsc Editor plus, Arsc Editor, Translation mode, Resource querier",
                    "classes*.dex: Dex Editor Plus (classes, methods, bytecode text, instruction edit), strings, method search",
                    "Text, hex and image viewers; add, replace, rename, delete, extract files",
                    "Save and sign, install or share; Export for Claude makes one text file of the whole APK"
            };
            for (String l : nl) {
                TextView t = Ui.text(this, "\u2022  " + l, 13.5f, Ui.SUB, false);
                t.setPadding(0, dp(6), 0, 0);
                ninfo.addView(t);
            }
            Ui.add(col, ninfo, 14);
            show(sv);
            return;
        }

        TextView sub = Ui.text(this, "Pro APK patcher. Pick an app, tick what you want changed, tap Patch. "
                + "No coding, no PC.", 14, Ui.SUB, false);
        sub.setPadding(0, dp(6), 0, dp(22));
        col.addView(sub);

        bigCard(col, "Choose an APK file", "From your phone storage or downloads", () -> {
            convertMode = false;
            pickFile();
        });
        bigCard(col, "Pick an installed app", "Takes the APK straight from an app on this phone", () -> {
            convertMode = false;
            pickInstalled();
        });
        bigCard(col, "Convert live APK to normal", "Take an app edited with the pencil handle and build a normal "
                + "APK (no handle) with your edits inside", () -> {
            final String[] ch = {"Choose an APK file", "Pick an installed app"};
            Ui.dialog(this).setTitle("Which live APK?").setItems(ch, (d, w) -> {
                convertMode = true;
                if (w == 0) pickFile();
                else pickInstalled();
            }).show();
        });

        LinearLayout info = Ui.card(this);
        info.setPadding(dp(16), dp(14), dp(16), dp(14));
        info.addView(Ui.text(this, "What you can change", 15, Ui.TEXT, true));
        String[] lines = {
                "App name and version",
                "Remove permissions (internet, location, contacts, camera...)",
                "Switch off parts of the app (auto-start after boot, services)",
                "Block ad, tracker or any other server the app talks to",
                "Hide ad banners, mute click sounds, fullscreen, keep screen on",
                "Lock rotation, allow screenshots, faster or no animations",
                "Live editor inside the app: size (dp), colour, name, opacity of every menu, button and icon",
                "Names list of everything visible (menu, screens, login page)",
                "Whole-app theme colours, hide or replace timers",
                "Block links that throw you out of the app (no crash)",
                "Convert a live-edited APK into a normal APK",
                "Keep only your phone's CPU type (ARMv7 check, smaller APK)",
                "Normal structure: repair zip tricks so MT Manager can open every file",
                "ARMv7 best-effort mode: try to run a 64-bit-only app on a 32-bit ARM phone"
        };
        for (String l : lines) {
            TextView t = Ui.text(this, "•  " + l, 13.5f, Ui.SUB, false);
            t.setPadding(0, dp(6), 0, 0);
            info.addView(t);
        }
        Ui.add(col, info, 14);

        TextView note = Ui.text(this, "Choose everything here before patching. Switch on \"Live Editor inside the app\" "
                + "only if you want the pencil handle to edit items while the app runs; otherwise the patched app "
                + "gets no editor, no button and no menu. Changes work on the phone side only: they cannot change "
                + "what a server sends back.", 12.5f, Ui.SUB, false);
        note.setPadding(dp(4), dp(16), dp(4), 0);
        col.addView(note);
        show(sv);
    }

    private void bigCard(LinearLayout col, String title, String sub, final Runnable click) {
        LinearLayout c = Ui.vbox(this);
        c.setBackground(Ui.ripple(this, Ui.CARD, 18));
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setClickable(true);
        c.addView(Ui.text(this, title, 18, Ui.TEXT, true));
        TextView s = Ui.text(this, sub, 13, Ui.SUB, false);
        s.setPadding(0, dp(4), 0, 0);
        c.addView(s);
        c.setOnClickListener(v -> click.run());
        Ui.add(col, c, 12);
    }

    private void pickFile() {
        if (busy) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK);
    }

    private void pickInstalled() {
        if (busy) return;
        Toast.makeText(this, "Loading apps...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            final List<Ui.Item> user = new ArrayList<Ui.Item>();
            final List<Ui.Item> sys = new ArrayList<Ui.Item>();
            final Map<String, ApplicationInfo> byPkg = new HashMap<String, ApplicationInfo>();
            for (ApplicationInfo ai : apps) {
                if (ai.sourceDir == null || ai.packageName.equals(getPackageName())) continue;
                boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                boolean split = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
                String sub = ai.packageName + (split ? "  •  split app" : "") + (system ? "  •  system" : "");
                Ui.Item it = new Ui.Item(ai.packageName, String.valueOf(ai.loadLabel(pm)), sub, ai.loadIcon(pm));
                byPkg.put(ai.packageName, ai);
                (system ? sys : user).add(it);
            }
            Collections.sort(user, (x, y) -> x.title.compareToIgnoreCase(y.title));
            Collections.sort(sys, (x, y) -> x.title.compareToIgnoreCase(y.title));
            final List<Ui.Item> items = new ArrayList<Ui.Item>(user);
            items.addAll(sys);
            runOnUiThread(() -> Ui.list(this, "Pick an app", items, null, it -> {
                final ApplicationInfo ai = byPkg.get(it.key);
                if (ai == null) return;
                final boolean split = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
                final Callable<File> copyApk = () -> {
                    File f = newInputFile();
                    Patcher.copy(new FileInputStream(ai.sourceDir), f);
                    return f;
                };
                if (nixuMode) openNixu(copyApk, it.title);
                else load(copyApk, split);
            }, null));
        }).start();
    }

    private String fileLabel(Uri uri) {
        String name = null;
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) name = c.getString(i);
            }
        } catch (Throwable t) {
            // the name is only for display
        } finally {
            if (c != null) c.close();
        }
        if (name == null || name.length() == 0) name = "app";
        if (name.toLowerCase(Locale.US).endsWith(".apk")) name = name.substring(0, name.length() - 4);
        return name;
    }

    /** nixu cn mode: copy the APK to the cache and open it in the MT Manager style editor. */
    private void openNixu(final Callable<File> getFile, final String name) {
        if (busy) return;
        busy = true;
        Toast.makeText(this, "Copying the APK...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                final File f = getFile.call();
                runOnUiThread(() -> {
                    busy = false;
                    Intent i = new Intent(MainActivity.this, NixuActivity.class);
                    i.putExtra("apk", f.getAbsolutePath());
                    i.putExtra("label", name);
                    startActivity(i);
                });
            } catch (final Throwable t) {
                runOnUiThread(() -> {
                    busy = false;
                    showError(t);
                });
            }
        }).start();
    }

    private File newInputFile() {
        File d = new File(getCacheDir(), "work");
        Patcher.deleteTree(d);
        if (!d.mkdirs()) throw new IllegalStateException("Cannot create cache folder (storage full?)");
        return new File(d, "input.apk");
    }

    // =======================================================================================
    // loading and patching (background work)
    // =======================================================================================

    private void load(final Callable<File> getFile, final boolean split) {
        if (busy) return;
        busy = true;
        synchronized (logText) {
            logText.setLength(0);
        }
        showWorking("Reading the app...");
        new Thread(() -> {
            try {
                line("Copying the APK...");
                File f = getFile.call();
                line("Looking inside (manifest, code, servers)...");
                final Patcher.Analysis a = Patcher.analyze(this, f);
                a.split = split;
                runOnUiThread(() -> {
                    busy = false;
                    an = a;
                    opts.reset();
                    if (a.alreadyPatched && !a.oldEngine && a.cfgJson != null) {
                        try {
                            opts.importJson(a.cfgJson);
                        } catch (Exception e) {
                            // settings inside the app could not be read: start empty
                        }
                        if (convertMode) opts.live = false;
                    }
                    prepareDerived();
                    scrollY = 0;
                    showOptions();
                    if (convertMode && a.alreadyPatched && !a.oldEngine) importFromApp(true);
                });
            } catch (final Throwable t) {
                line("ERROR: " + t);
                where(t);
                runOnUiThread(() -> {
                    busy = false;
                    showError(t);
                });
            }
        }).start();
    }

    private void startPatch() {
        if (busy || an == null) return;
        if (opts.changeCount() == 0) {
            Toast.makeText(this, "Select at least one option first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (an.alreadyPatched && an.oldEngine) {
            Ui.info(this, "Older engine inside",
                    "This APK was patched by an older Live Editor. Pick the original app again.");
            return;
        }
        busy = true;
        synchronized (logText) {
            logText.setLength(0);
        }
        showWorking("Patching...");
        final Patcher.Analysis a = an;
        new Thread(() -> {
            try {
                final Patcher.Result r = Patcher.run(this, a, opts, new Patcher.Log() {
                    @Override
                    public void line(String s) {
                        MainActivity.this.line(s);
                    }

                    @Override
                    public void progress(final int p) {
                        runOnUiThread(() -> {
                            if (workBar != null) {
                                workBar.setIndeterminate(false);
                                workBar.setProgress(p);
                            }
                        });
                    }
                });
                runOnUiThread(() -> {
                    busy = false;
                    last = r;
                    showDone();
                });
            } catch (final Throwable t) {
                line("ERROR: " + t);
                where(t);
                runOnUiThread(() -> {
                    busy = false;
                    showError(t);
                });
            }
        }).start();
    }

    /** Puts the first lines of the error's stack trace into the log, so the exact place of a crash can be seen. */
    private void where(Throwable t) {
        try {
            Throwable c = t;
            for (int d = 0; d < 4 && c != null; d++) {
                StackTraceElement[] st = c.getStackTrace();
                if (d > 0) line("caused by: " + c);
                for (int i = 0; i < st.length && i < 8; i++) line("   at " + st[i]);
                c = c.getCause();
            }
        } catch (Throwable ignore) {
            // the log is only for diagnosis
        }
    }

    private void line(final String s) {
        synchronized (logText) {
            logText.append(s).append('\n');
        }
        runOnUiThread(() -> {
            if (workLog != null) {
                workLog.append(s + "\n");
                if (workScroll != null) workScroll.post(() -> workScroll.fullScroll(View.FOCUS_DOWN));
            }
        });
    }

    private void prepareDerived() {
        bootComps.clear();
        privPerms.clear();
        for (Axml.Comp c : an.info.comps) {
            if (!"receiver".equals(c.type)) continue;
            for (String a : c.actions) {
                if (a.equals("android.intent.action.BOOT_COMPLETED")
                        || a.equals("android.intent.action.LOCKED_BOOT_COMPLETED")
                        || a.endsWith("QUICKBOOT_POWERON")) {
                    bootComps.add(c.name);
                    break;
                }
            }
        }
        for (String p : Presets.PRIVATE_PERMS) {
            if (an.info.perms.contains(p)) privPerms.add(p);
        }
        fitAbi = null;
        if (Build.SUPPORTED_ABIS != null) {
            for (String a : Build.SUPPORTED_ABIS) {
                if (an.scan.abis.contains(a)) {
                    fitAbi = a;
                    break;
                }
            }
        }
    }

    private String compatText() {
        StringBuilder phone = new StringBuilder();
        if (Build.SUPPORTED_ABIS != null) {
            for (String a : Build.SUPPORTED_ABIS) {
                if (phone.length() > 0) phone.append(", ");
                phone.append(a);
            }
        }
        if (an.scan.abis.isEmpty()) {
            return "This app has no native libraries, so it runs on any CPU. Your phone: " + phone + ".";
        }
        if (fitAbi != null) {
            return "Your phone (" + phone + ") can run this app: it contains " + fitAbi + " libraries. "
                    + "The app holds: " + join(an.scan.abis) + ".";
        }
        return "NOT compatible: this app only has " + join(an.scan.abis) + " libraries but your phone needs "
                + phone + ". Native libraries cannot be converted from one CPU type to another. "
                + (phoneIsArmv7()
                ? "Best-effort mode below can still make it install and start, but anything that needs those libraries "
                + "will not work."
                : "Look for a version of the app that has libraries for this phone.");
    }

    /** One text with everything needed to talk about this app: copy it, send it, ask for a change. */
    private void copyReport() {
        try {
            StringBuilder b = new StringBuilder();
            b.append("LIVE EDITOR REPORT\n");
            if (an != null && an.info != null) b.append("app: ").append(an.info.pkg).append("\n");
            if (an != null && an.scan != null) {
                b.append("cpu: ").append(join(an.scan.abis)).append("   code files: ").append(an.scan.dexCount).append("\n");
                b.append("\nTIMERS IN CODE (").append(an.scan.timers.size()).append("):\n");
                for (int i = 0; i < an.scan.timers.size() && i < 60; i++) b.append(an.scan.timers.get(i)).append("\n");
                b.append("\nSERVERS (top ").append(Math.min(30, an.scan.hosts.size())).append("):\n");
                for (int i = 0; i < an.scan.hosts.size() && i < 30; i++) b.append(an.scan.hosts.get(i)).append("\n");
            }
            b.append("\nSETTINGS JSON:\n").append(opts.configJson()).append("\n");
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Live Editor report", b.toString()));
            Toast.makeText(this, "Copied. Paste it to Claude and say what to change.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not copy: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private void importClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        String text = null;
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip() != null
                && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (cs != null) text = cs.toString();
        }
        if (text == null || text.indexOf('{') < 0) {
            Toast.makeText(this, "Nothing to paste. In the app tap the pencil, More, Copy settings.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        try {
            int jb = text.indexOf("SETTINGS JSON:");
            if (jb >= 0) text = text.substring(jb + 14);
            int fb = text.indexOf('{'), lb = text.lastIndexOf('}');
            if (fb >= 0 && lb > fb) text = text.substring(fb, lb + 1);
            opts.importJson(text);
            Toast.makeText(this, "Settings pasted: " + opts.ruleCount() + " item edits", Toast.LENGTH_SHORT).show();
            rerender();
        } catch (Exception e) {
            Toast.makeText(this, "Those are not live editor settings", Toast.LENGTH_LONG).show();
        }
    }

    private boolean phoneIsArmv7() {
        if (Build.SUPPORTED_ABIS == null) return false;
        for (String a : Build.SUPPORTED_ABIS) {
            if ("armeabi-v7a".equals(a)) return true;
        }
        return false;
    }

    /**
     * Asks the installed, patched app for its current settings (baked edits plus the ones made with the pencil handle).
     * Works when the engine inside that app is from this version of Live Editor.
     */
    private void importFromApp(final boolean quiet) {
        if (an == null || an.info == null || an.info.pkg == null) return;
        final String pkg = an.info.pkg;
        new Thread(() -> {
            String json = null;
            android.database.Cursor c = null;
            try {
                c = getContentResolver().query(Uri.parse("content://" + pkg + ".liveeditagent"), null, null, null, null);
                if (c != null && c.moveToFirst()) json = c.getString(0);
            } catch (Throwable t) {
                json = null;
            } finally {
                if (c != null) c.close();
            }
            final String j = json;
            runOnUiThread(() -> {
                if (j == null) {
                    if (!quiet) {
                        Toast.makeText(this, "Could not read the settings. The app must be installed and patched with "
                                + "this version of Live Editor. You can still paste them.", Toast.LENGTH_LONG).show();
                    }
                    return;
                }
                try {
                    opts.importJson(j);
                    Toast.makeText(this, "Settings loaded from the installed app: " + opts.ruleCount() + " item edits",
                            Toast.LENGTH_SHORT).show();
                    rerender();
                } catch (Exception e) {
                    if (!quiet) Toast.makeText(this, "Those are not live editor settings", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private static final String[] THEME_NAMES = {"Dark", "AMOLED", "Light", "Blue", "Green", "Purple", "Red"};
    private static final int[][] THEMES = {
            {0xFF101418, 0xFFECEFF4, 0xFF7C5CFF},
            {0xFF000000, 0xFFFFFFFF, 0xFF00E5FF},
            {0xFFF4F5F7, 0xFF111418, 0xFF2563EB},
            {0xFF0B1B33, 0xFFE6F0FF, 0xFF3B82F6},
            {0xFF0B2016, 0xFFE6FFF1, 0xFF22C55E},
            {0xFF1A1030, 0xFFF1E9FF, 0xFFA855F7},
            {0xFF240C0C, 0xFFFFECEC, 0xFFEF4444}
    };

    private View themeChips() {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, dp(6), 0, dp(10));
        for (int i = 0; i < THEME_NAMES.length; i++) {
            final int[] t = THEMES[i];
            TextView chip = Ui.chip(this, THEME_NAMES[i]);
            chip.setOnClickListener(v -> {
                opts.themeOn = true;
                opts.themeBg = t[0];
                opts.themeText = t[1];
                opts.themeAccent = t[2];
                rerender();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.rightMargin = dp(8);
            row.addView(chip, lp);
        }
        hs.addView(row);
        return hs;
    }

    // =======================================================================================
    // 2. options
    // =======================================================================================

    private void showOptions() {
        screen = 1;
        syncers.clear();
        LinearLayout page = Ui.vbox(this);

        optScroll = new ScrollView(this);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(14), dp(16), dp(14), dp(24));
        optScroll.addView(col);

        col.addView(appCard());
        col.addView(presetRow());

        // ---- live editing
        LinearLayout c = card(col, an.alreadyPatched ? "Live Editor APK" : "Live editing");
        switchRow(c, "Live Editor inside the app",
                "Adds a pencil handle. Tap it to list every menu, button, icon and text, and change size (dp), "
                        + "colour, name and opacity of each one while the app runs.",
                () -> opts.live, v -> opts.live = v);
        actionRow(c, "Copy report for Claude",
                () -> "Settings, timers, servers and app info as one text: send it, say what to change",
                this::copyReport);
        actionRow(c, "Paste changes (from Claude or the live editor)",
                () -> opts.ruleCount() + " single-item edits stored", this::importClipboard);
        if (an.alreadyPatched && !an.oldEngine) {
            actionRow(c, "Load settings from the installed app", () -> "No copy and paste: reads them straight from "
                    + "the app on this phone", () -> importFromApp(false));
        }
        if (opts.ruleCount() > 0) {
            actionRow(c, "Clear single-item edits", () -> "Removes all " + opts.ruleCount() + " edits", () -> {
                opts.rules = "[]";
                rerender();
            });
        }
        c.addView(note(an.alreadyPatched
                ? "Settings found inside this APK were loaded. To make a normal APK: turn the switch off, paste "
                + "the settings copied from the pencil panel (More, Copy settings), then Patch."
                : "Later: in the app tap the pencil, More, Copy settings. Come back here, use \"Convert live APK "
                + "to normal\", paste, switch this off and Patch."));

        // ---- identity
        c = card(col, "App identity");
        inputRow(c, "App name", "Keep: " + an.label, () -> opts.appName, v -> opts.appName = v,
                InputType.TYPE_CLASS_TEXT);
        inputRow(c, "Version name", "Keep: " + (an.info.versionName == null ? "unknown" : an.info.versionName),
                () -> opts.versionName, v -> opts.versionName = v, InputType.TYPE_CLASS_TEXT);
        inputRow(c, "Version code", "Keep: " + an.info.versionCode, () -> opts.versionCode,
                v -> opts.versionCode = v, InputType.TYPE_CLASS_NUMBER);

        // ---- permissions
        c = card(col, "Permissions");
        if (an.info.perms.isEmpty()) {
            c.addView(note("This app asks for no permissions."));
        } else {
            if (an.info.perms.contains(INTERNET)) {
                switchRow(c, "Remove internet access",
                        "App works offline. Anything that needs a server stops loading.",
                        () -> opts.removePerms.contains(INTERNET),
                        v -> setIn(opts.removePerms, INTERNET, v));
            }
            if (!privPerms.isEmpty()) {
                switchRow(c, "Remove private-data permissions",
                        privPerms.size() + " found: location, contacts, calls, SMS, camera, microphone, calendar",
                        () -> opts.removePerms.containsAll(privPerms),
                        v -> {
                            if (v) opts.removePerms.addAll(privPerms);
                            else opts.removePerms.removeAll(privPerms);
                        });
            }
            actionRow(c, "Choose permissions to remove",
                    () -> opts.removePerms.size() + " selected of " + an.info.perms.size(), this::pickPerms);
        }

        // ---- parts of the app
        c = card(col, "Parts of the app");
        if (!bootComps.isEmpty()) {
            switchRow(c, "Stop auto-start after phone boot",
                    bootComps.size() + " boot receiver" + (bootComps.size() == 1 ? "" : "s") + " found",
                    () -> opts.disableComps.containsAll(bootComps),
                    v -> {
                        if (v) opts.disableComps.addAll(bootComps);
                        else opts.disableComps.removeAll(bootComps);
                    });
        }
        actionRow(c, "Switch off parts of the app",
                () -> opts.disableComps.size() + " selected of " + an.info.comps.size()
                        + " (screens, services, receivers)", this::pickComps);

        // ---- screen & system
        c = card(col, "Screen and behaviour");
        choiceRow(c, "Screen rotation", new String[]{"Keep original", "Lock portrait", "Lock landscape",
                        "Auto-rotate always", "Follow phone setting"},
                () -> opts.orientation, v -> opts.orientation = v);
        switchRow(c, "Keep screen on", "Screen never turns off while the app is open",
                () -> opts.keepOn, v -> opts.keepOn = v);
        switchRow(c, "Allow screenshots", "Removes the \"can't take screenshot\" block",
                () -> opts.allowShot, v -> opts.allowShot = v);
        switchRow(c, "Fullscreen", "Hides status and navigation bars (swipe to show)",
                () -> opts.immersive, v -> opts.immersive = v);
        choiceRow(c, "Animations", new String[]{"Normal", "Faster", "Off"}, () -> opts.anim, v -> opts.anim = v);
        switchRow(c, "Mute click sounds", "Turns off the tap sound of buttons and lists",
                () -> opts.mute, v -> opts.mute = v);

        // ---- servers & ads
        c = card(col, "Servers and ads");
        switchRow(c, "Block ad servers", Presets.AD_HOSTS.length + " known ad networks",
                () -> opts.blockAds, v -> opts.blockAds = v);
        switchRow(c, "Block tracking and analytics servers", Presets.TRACKER_HOSTS.length + " known trackers",
                () -> opts.blockTrackers, v -> opts.blockTrackers = v);
        switchRow(c, "Hide ad banners", "Hides banner and native ad views from common ad SDKs",
                () -> opts.hideAds, v -> opts.hideAds = v);
        if (an.scan.hosts.isEmpty()) {
            c.addView(note("No server addresses were found written inside this app's code."));
        } else {
            actionRow(c, "Servers found in this app",
                    () -> an.scan.hosts.size() + " found, " + opts.allHosts().size() + " blocked in total",
                    this::pickHosts);
        }
        inputRow(c, "Block other servers", "ads.example.com, tracker.site.net",
                () -> opts.customHosts, v -> opts.customHosts = v, InputType.TYPE_CLASS_TEXT);
        c.addView(note("Blocking stops the app from reaching a server. It cannot change what a server sends. "
                + "WebView pages and apps that use their own network code may still connect."));

        // ---- the auto-off timer and the beep of a button (found by itself)
        c = card(col, "Button that turns itself off, and its beep");
        actionRow(c, "Find the auto-off timer and the beep, then remove them",
                () -> {
                    int t = 0, b = 0;
                    for (TimerScan.Hit h : an.scan.hits) {
                        Long e = opts.timerEdits.get(h.key());
                        if (e == null) continue;
                        if (h.type == 2) b++;
                        else if (h.type == 0) t++;
                    }
                    return t + b == 0 ? "tap to search the app's code" : t + " timer(s) set to never, " + b + " beep(s) removed";
                }, this::autoFind);
        c.addView(note("Searches the app's code for a delay of 1 to 3 seconds (the part that switches a button off by "
                + "itself) and for sounds (beeps). You see the list and tick what to remove: the delay becomes "
                + "\"never\" and the sound call is cut out. It is written into the code when you tap Patch."));

        // ---- timers found in the code (editable)
        c = card(col, "Timers in this app");
        actionRow(c, "Edit timers and line thickness found in the app's code",
                () -> an.scan.hits.isEmpty() ? "none found (or the code is packed)"
                        : an.scan.hits.size() + " found, " + opts.timerEdits.size() + " edited",
                this::pickTimers);
        c.addView(note("Lists the places in the app's code that start something after a delay, for example a "
                + "button that turns itself off after 3 seconds (1-10 second ones come first), and the number next to "
                + "a line's Paint.setStrokeWidth (LINE: ..., the line thickness). Tap one to change it; a delay can "
                + "also be set to Never. The new number is written into the code when you tap Patch. A delay that "
                + "is calculated by the app (not a plain number) is shown but cannot be edited."));

        // ---- menu icon, floating buttons, menu panel and lines (four separate groups), sizes in dp
        c = card(col, "Menu icon (the button that opens the menu)");
        sliderRow(c, "Size (width)", 0, 300, () -> opts.iconDp, v -> {
            opts.iconDp = v;
            opts.iconPct = 100;
        }, " dp", "original");
        sliderRow(c, "Opacity", 10, 100, () -> opts.iconAlpha, v -> opts.iconAlpha = v, "%", null);
        sliderRow(c, "Text size change", -10, 30, () -> opts.iconTextDp, v -> {
            opts.iconTextDp = v;
            opts.iconText = 100;
        }, "\u00B1 dp", "original", 0);
        c.addView(note("The first small floating window of the app is taken as the menu icon. Size is the width in dp "
                + "that the window gets (its height follows); 'original' keeps it. Text size change adds or removes dp."));
        c = card(col, "Floating buttons (on / off buttons that appear)");
        sliderRow(c, "Size (width)", 0, 400, () -> opts.btnDp, v -> {
            opts.btnDp = v;
            opts.btnPct = 100;
        }, " dp", "original");
        sliderRow(c, "Opacity", 10, 100, () -> opts.btnAlpha, v -> opts.btnAlpha = v, "%", null);
        sliderRow(c, "Text size change", -10, 30, () -> opts.btnTextDp, v -> {
            opts.btnTextDp = v;
            opts.btnText = 100;
        }, "\u00B1 dp", "original", 0);
        c = card(col, "Menu panel");
        sliderRow(c, "Size (width)", 0, 900, () -> opts.menuDp, v -> {
            opts.menuDp = v;
            opts.menuPct = 100;
        }, " dp", "original");
        sliderRow(c, "Opacity", 10, 100, () -> opts.menuAlpha, v -> opts.menuAlpha = v, "%", null);
        sliderRow(c, "Text size change", -10, 30, () -> opts.menuTextDp, v -> {
            opts.menuTextDp = v;
            opts.menuText = 100;
        }, "\u00B1 dp", "original", 0);
        c = card(col, "Line overlays");
        sliderRowTenths(c, "Thickness", 200, () -> opts.lineT, v -> opts.lineT = v, "original");
        c.addView(note("Thickness goes down to 0.1 dp and up to 20 dp; use the - 0.1 / + 0.1 buttons for exact steps "
                + "(0.5 dp = a hairline). It works for thin line windows and for lines the app paints itself when "
                + "it keeps its Paint in a field. Icon, buttons, menu and lines never change each other. For one single "
                + "item use the live editor (pencil)."));

        // ---- theme
        c = card(col, "App theme");
        switchRow(c, "Change the app's colours", "Backgrounds, texts and buttons of every screen and overlay",
                () -> opts.themeOn, v -> opts.themeOn = v);
        c.addView(themeChips());
        inputRow(c, "Background colour (hex)", "#101418", () -> Opts.hexOf(opts.themeBg),
                v -> {
                    opts.themeBg = Opts.hex(v, opts.themeBg);
                    opts.themeOn = true;
                }, InputType.TYPE_CLASS_TEXT);
        inputRow(c, "Text colour (hex)", "#ECEFF4", () -> Opts.hexOf(opts.themeText),
                v -> {
                    opts.themeText = Opts.hex(v, opts.themeText);
                    opts.themeOn = true;
                }, InputType.TYPE_CLASS_TEXT);
        inputRow(c, "Button colour (hex)", "#7C5CFF", () -> Opts.hexOf(opts.themeAccent),
                v -> {
                    opts.themeAccent = Opts.hex(v, opts.themeAccent);
                    opts.themeOn = true;
                }, InputType.TYPE_CLASS_TEXT);
        c.addView(note("Pictures stay as they are. Colours set on a single item in the live editor win over the theme."));

        // ---- links and timers
        c = card(col, "Links and timers");
        choiceRow(c, "Links that leave the app", new String[]{"Keep", "Block at app start", "Block always"},
                () -> opts.links, v -> opts.links = v);
        c.addView(note("Stops the app from opening a browser, Telegram, Play Store ... by itself. The link is just "
                + "skipped, the app keeps running. Links opened inside a WebView are not covered."));
        choiceRow(c, "Timers on buttons and menus", new String[]{"Keep", "Hide timer texts", "Replace timer texts"},
                () -> opts.timers, v -> opts.timers = v);
        inputRow(c, "Replacement text", "empty = blank", () -> opts.timerText, v -> opts.timerText = v,
                InputType.TYPE_CLASS_TEXT);
        c.addView(note("Finds texts that look like a countdown (00:59, 3 days left ...) and hides or replaces them. "
                + "It changes what is shown; it cannot change how the app counts. This is NOT the button's auto-off "
                + "time: for that use \"Button that turns itself off\" above."));

        // ---- app flags
        c = card(col, "Advanced app flags");
        String[] tri = {"Keep", "On", "Off"};
        choiceRow(c, "Debuggable", tri, () -> opts.debuggable, v -> opts.debuggable = v);
        choiceRow(c, "Allow backup", tri, () -> opts.backup, v -> opts.backup = v);
        choiceRow(c, "Allow plain HTTP", tri, () -> opts.cleartext, v -> opts.cleartext = v);
        choiceRow(c, "Large memory heap", tri, () -> opts.largeHeap, v -> opts.largeHeap = v);

        // ---- this phone
        c = card(col, "Compatible with this phone");
        c.addView(note(compatText()));
        if (an.scan.abis.size() > 1 && fitAbi != null) {
            final String fit = fitAbi;
            switchRow(c, "Fit my phone: keep only " + fit, "Removes the other CPU types, smaller APK, same app",
                    () -> fit.equals(opts.keepAbi), v -> opts.keepAbi = v ? fit : null);
        }

        if (fitAbi == null && !an.scan.abis.isEmpty() && phoneIsArmv7()) {
            switchRow(c, "Make it run on my phone (best effort)",
                    "Replaces the app's native libraries with empty stand-ins so it installs and starts on this ARMv7 "
                            + "phone. Features that need those libraries stop working; some apps may still close.",
                    () -> opts.armCompat, v -> opts.armCompat = v);
        }

        // ---- normal structure
        c = card(col, "Normal APK (for MT Manager)");
        switchRow(c, "Convert to normal structure",
                "Opens every file and repairs zip tricks (fake \"encrypted\" flags, wrong sizes) that stop tools like "
                        + "MT Manager from opening the code files. The files themselves are not changed.",
                () -> opts.normalize, v -> opts.normalize = v);
        c.addView(note("Cannot undo code that is packed or encrypted by a protection tool: that only unpacks "
                + "while the app runs. Such files stay as they are."));

        // ---- size
        if (an.scan.abis.size() > 1) {
            c = card(col, "APK size");
            final List<String> abis = new ArrayList<String>(an.scan.abis);
            String[] names = new String[abis.size() + 1];
            names[0] = "Keep all CPU types";
            for (int i = 0; i < abis.size(); i++) {
                names[i + 1] = "Only " + abis.get(i) + (abis.get(i).equals(phoneAbi) ? " (this phone)" : "");
            }
            choiceRow(c, "CPU types", names,
                    () -> opts.keepAbi == null ? 0 : abis.indexOf(opts.keepAbi) + 1,
                    v -> opts.keepAbi = v == 0 ? null : abis.get(v - 1));
            c.addView(note("A CPU type your phone does not use makes the app crash. Pick the one marked \"this phone\"."));
        }

        TextView foot = note("The patched app is signed with the Live Editor key, so Android treats it as a "
                + "different app: uninstall the original first (its data is lost), then install.");
        foot.setPadding(dp(4), dp(18), dp(4), 0);
        col.addView(foot);

        page.addView(optScroll, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout bottom = Ui.hbox(this);
        bottom.setBackgroundColor(Ui.CARD);
        bottom.setPadding(dp(16), dp(10), dp(16), dp(10));
        barInfo = Ui.text(this, "", 13.5f, Ui.TEXT, false);
        bottom.addView(barInfo, new LinearLayout.LayoutParams(0, WRAP, 1f));
        Button go = Ui.button(this, "Patch", true);
        go.setOnClickListener(v -> startPatch());
        bottom.addView(go);
        page.addView(bottom, new LinearLayout.LayoutParams(MATCH, WRAP));

        show(page);
        final int y = scrollY;
        optScroll.post(() -> optScroll.scrollTo(0, y));
        updateBar();
    }

    private void rerender() {
        scrollY = optScroll != null ? optScroll.getScrollY() : 0;
        showOptions();
    }

    private View appCard() {
        LinearLayout card = Ui.card(this);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout row = Ui.hbox(this);
        if (an.icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(an.icon);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(52), dp(52));
            lp.rightMargin = dp(14);
            row.addView(iv, lp);
        }
        LinearLayout tx = Ui.vbox(this);
        tx.addView(Ui.text(this, an.label, 19, Ui.TEXT, true));
        tx.addView(Ui.text(this, an.info.pkg == null ? "" : an.info.pkg, 12, Ui.SUB, false));
        row.addView(tx, new LinearLayout.LayoutParams(0, WRAP, 1f));
        card.addView(row);

        StringBuilder d = new StringBuilder();
        if (an.info.versionName != null) d.append("v").append(an.info.versionName).append(" (").append(an.info.versionCode).append(")  •  ");
        d.append(String.format(Locale.US, "%.1f MB", an.size / 1048576.0));
        if (!an.scan.abis.isEmpty()) d.append("  •  ").append(join(an.scan.abis));
        d.append("  •  ").append(an.scan.dexCount).append(" code file").append(an.scan.dexCount == 1 ? "" : "s");
        TextView det = Ui.text(this, d.toString(), 12.5f, Ui.SUB, false);
        det.setPadding(0, dp(10), 0, 0);
        card.addView(det);

        if (an.split) {
            card.addView(warn("Split app: only the base APK was taken. It may not install or run without its other parts."));
        }
        if (an.zipFixed > 0) {
            card.addView(warn("This APK had zip tricks that block tools; a repaired copy is used."));
        }
        if (an.alreadyPatched) {
            card.addView(warn(an.oldEngine
                    ? "This APK was patched by an older Live Editor. Pick the original app."
                    : "This APK already has the Live Editor engine. Its settings were loaded; patching again updates them."));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        card.setLayoutParams(lp);
        return card;
    }

    private View presetRow() {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, dp(14), 0, 0);
        String[] names = {"Privacy", "Ads off", "Smaller", "Faster UI", "Reset all"};
        for (int i = 0; i < names.length; i++) {
            final int which = i;
            TextView chip = Ui.chip(this, names[i]);
            chip.setOnClickListener(v -> applyPreset(which));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.rightMargin = dp(8);
            row.addView(chip, lp);
        }
        hs.addView(row);
        return hs;
    }

    private void applyPreset(int which) {
        String msg = "";
        if (which == 0) {
            opts.removePerms.addAll(privPerms);
            opts.blockTrackers = true;
            msg = "Privacy: private permissions removed, trackers blocked";
        } else if (which == 1) {
            opts.blockAds = true;
            opts.hideAds = true;
            msg = "Ads off: ad servers blocked, banners hidden";
        } else if (which == 2) {
            if (an.scan.abis.size() > 1 && an.scan.abis.contains(phoneAbi)) {
                opts.keepAbi = phoneAbi;
                msg = "Smaller: only " + phoneAbi + " kept";
            } else {
                msg = "Nothing to shrink: no other CPU types in this APK";
            }
        } else if (which == 3) {
            opts.anim = 1;
            opts.mute = true;
            msg = "Faster UI: quicker animations, no click sounds";
        } else {
            opts.reset();
            msg = "All options cleared";
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        rerender();
    }

    // ---- pick dialogs -----------------------------------------------------------------------

    private void pickPerms() {
        List<String> sorted = new ArrayList<String>(an.info.perms);
        Collections.sort(sorted);
        List<Ui.Item> items = new ArrayList<Ui.Item>();
        for (String p : sorted) {
            boolean priv = privPerms.contains(p);
            items.add(new Ui.Item(p, Presets.niceName(p), (priv ? "private data  •  " : "") + p, null));
        }
        Ui.list(this, "Remove permissions", items, opts.removePerms, null, this::afterChange);
    }

    private static boolean risky(Axml.Comp c) {
        return c.launcher || "service".equals(c.type) || "provider".equals(c.type);
    }

    private void pickComps() {
        List<Ui.Item> items = new ArrayList<Ui.Item>();
        for (Axml.Comp c : an.info.comps) {
            String shortName = c.name.substring(c.name.lastIndexOf('.') + 1);
            String flags = c.type + (c.launcher ? "  •  app icon entry" : "") + (!c.enabled ? "  •  already off" : "");
            String warn = c.launcher ? "\n\u26A0 MAIN SCREEN: switched off, the app will not open"
                    : "service".equals(c.type) ? "\n\u26A0 the app may start this itself: switching it off can crash the app"
                    : "provider".equals(c.type) ? "\n\u26A0 the app may need this to start: switching it off can crash the app"
                    : "";
            items.add(new Ui.Item(c.name, shortName, flags + warn + "\n" + c.name, null));
        }
        Ui.list(this, "Switch off parts of the app", items, opts.disableComps, null, () -> {
            final List<Axml.Comp> bad = new ArrayList<Axml.Comp>();
            for (Axml.Comp c : an.info.comps) {
                if (risky(c) && opts.disableComps.contains(c.name)) bad.add(c);
            }
            if (bad.isEmpty()) {
                afterChange();
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (Axml.Comp c : bad) {
                sb.append("\u2022 ").append(c.name.substring(c.name.lastIndexOf('.') + 1)).append(" (")
                        .append(c.launcher ? "main screen" : c.type).append(")\n");
            }
            new android.app.AlertDialog.Builder(this).setTitle("This can crash the app")
                    .setMessage(sb + "\nSwitching these off removes them from the app for real. If the app's code "
                            + "still starts them, it crashes. To hide a menu, popup or button safely, use the "
                            + "pencil panel > Windows tab instead: it hides it and the app keeps running.")
                    .setPositiveButton("Undo these (safe)", (d, w) -> {
                        for (Axml.Comp c : bad) opts.disableComps.remove(c.name);
                        afterChange();
                    })
                    .setNegativeButton("Keep switched off", (d, w) -> afterChange())
                    .setCancelable(false).show();
        });
    }

    private void pickHosts() {
        List<Ui.Item> items = new ArrayList<Ui.Item>();
        for (String h : an.scan.hosts) {
            Integer n = an.scan.hostCount.get(h);
            items.add(new Ui.Item(h, h, "found " + (n == null ? 1 : n.intValue()) + "x in the app", null));
        }
        Ui.list(this, "Servers found in this app", items, opts.blockHosts, null, this::afterChange);
    }

    // ---- row builders -----------------------------------------------------------------------

    private LinearLayout card(LinearLayout col, String title) {
        col.addView(Ui.section(this, title));
        LinearLayout c = Ui.card(this);
        col.addView(c, new LinearLayout.LayoutParams(MATCH, WRAP));
        return c;
    }

    private void addRow(LinearLayout card, View row) {
        if (card.getChildCount() > 0) card.addView(Ui.divider(this));
        card.addView(row);
    }

    private TextView note(String s) {
        TextView t = Ui.text(this, s, 12, Ui.SUB, false);
        t.setPadding(0, dp(10), 0, dp(10));
        return t;
    }

    private TextView warn(String s) {
        TextView t = Ui.text(this, s, 12.5f, Ui.WARN, false);
        t.setPadding(0, dp(10), 0, 0);
        return t;
    }

    private static String join(java.util.Collection<String> c) {
        StringBuilder b = new StringBuilder();
        for (String s : c) {
            if (b.length() > 0) b.append(", ");
            b.append(s);
        }
        return b.toString();
    }

    private static void setIn(java.util.Set<String> set, String v, boolean on) {
        if (on) set.add(v);
        else set.remove(v);
    }

    private void switchRow(LinearLayout card, String title, String sub,
                           final Supplier<Boolean> g, final Consumer<Boolean> s) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, dp(10), 0, dp(10));
        LinearLayout tx = Ui.vbox(this);
        tx.addView(Ui.text(this, title, 15, Ui.TEXT, false));
        if (sub != null) {
            TextView st = Ui.text(this, sub, 12.5f, Ui.SUB, false);
            st.setPadding(0, dp(2), dp(8), 0);
            tx.addView(st);
        }
        row.addView(tx, new LinearLayout.LayoutParams(0, WRAP, 1f));
        final Switch sw = new Switch(this);
        sw.setChecked(g.get());
        sw.setOnCheckedChangeListener((b, checked) -> {
            if (syncing) return;
            s.accept(checked);
            afterChange();
        });
        row.addView(sw);
        row.setOnClickListener(v -> sw.toggle());
        syncers.add(() -> {
            boolean want = g.get();
            if (sw.isChecked() != want) sw.setChecked(want);
        });
        addRow(card, row);
    }

    private void actionRow(LinearLayout card, String title, final Supplier<String> sub, final Runnable click) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, dp(12), 0, dp(12));
        LinearLayout tx = Ui.vbox(this);
        tx.addView(Ui.text(this, title, 15, Ui.TEXT, false));
        final TextView st = Ui.text(this, sub.get(), 12.5f, Ui.SUB, false);
        st.setPadding(0, dp(2), 0, 0);
        tx.addView(st);
        row.addView(tx, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(Ui.text(this, "›", 24, Ui.SUB, false));
        row.setOnClickListener(v -> click.run());
        syncers.add(() -> st.setText(sub.get()));
        addRow(card, row);
    }

    private void choiceRow(LinearLayout card, String title, String[] items,
                           final Supplier<Integer> g, final Consumer<Integer> s) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, dp(6), 0, dp(6));
        row.addView(Ui.text(this, title, 15, Ui.TEXT, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        final Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items));
        sp.setSelection(g.get(), false);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (syncing || pos == g.get().intValue()) return;
                s.accept(pos);
                afterChange();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {}
        });
        row.addView(sp);
        syncers.add(() -> {
            int want = g.get();
            if (sp.getSelectedItemPosition() != want) sp.setSelection(want, false);
        });
        addRow(card, row);
    }

    private void inputRow(LinearLayout card, String title, String hint,
                          Supplier<String> g, final Consumer<String> s, int inputType) {
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, dp(10), 0, dp(12));
        row.addView(Ui.text(this, title, 15, Ui.TEXT, false));
        EditText e = Ui.edit(this, hint);
        e.setInputType(inputType);
        e.setText(g.get());
        Ui.onText(e, v -> {
            s.accept(v);
            updateBar();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(6);
        row.addView(e, lp);
        addRow(card, row);
    }

    /** Looks for "a delay of 1-3 s" and "a beep" in the code, shows them, and sets the ticked ones. */
    private void autoFind() {
        final TimerScan.Pick pick = TimerScan.autoPick(an.scan.hits);
        final List<TimerScan.Hit> all = new ArrayList<TimerScan.Hit>();
        all.addAll(pick.timers);
        all.addAll(pick.beeps);
        if (all.isEmpty()) {
            new android.app.AlertDialog.Builder(this).setTitle("Nothing found")
                    .setMessage("No plain delay of 1 to 3 seconds and no sound call was found in the code of this app "
                            + "(it may be calculated by the app, or the code may be packed). Open the full list of "
                            + "timers, or use the file editor's export and send it to Claude.")
                    .setPositiveButton("Full list", (d, w) -> pickTimers())
                    .setNegativeButton("Close", null).show();
            return;
        }
        String[] names = new String[all.size()];
        final boolean[] on = new boolean[all.size()];
        for (int i = 0; i < all.size(); i++) {
            TimerScan.Hit h = all.get(i);
            names[i] = (h.type == 2 ? "Beep: " : "Auto-off timer: ") + h.label.replaceFirst("^BEEP: ", "");
            on[i] = pick.ticked.contains(h);
        }
        new android.app.AlertDialog.Builder(this).setTitle("Found in the code (tick what to remove)")
                .setMultiChoiceItems(names, on, (d, i, checked) -> on[i] = checked)
                .setPositiveButton("Remove ticked", (d, w) -> {
                    int n = 0;
                    for (int i = 0; i < all.size(); i++) {
                        TimerScan.Hit h = all.get(i);
                        if (on[i]) {
                            opts.timerEdits.put(h.key(), Long.valueOf(h.type == 2 ? -2 : -1));
                            n++;
                        } else {
                            opts.timerEdits.remove(h.key());
                        }
                    }
                    Toast.makeText(this, n + " change(s) set. Tap Patch to write them.", Toast.LENGTH_LONG).show();
                    afterChange();
                })
                .setNeutralButton("Full list", (d, w) -> pickTimers())
                .setNegativeButton("Cancel", null).show();
    }

    private void pickTimers() {
        if (an.scan.hits.isEmpty()) {
            Toast.makeText(this, "No timers found in the code of this app.", Toast.LENGTH_LONG).show();
            return;
        }
        final LinearLayout list = Ui.vbox(this);
        list.setPadding(dp(8), dp(8), dp(8), dp(8));
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this).setTitle("Timers in this app")
                .setView(sv).setPositiveButton("Done", (d, w) -> afterChange())
                .setNeutralButton("Copy all", (d, w) -> {
                    StringBuilder sb = new StringBuilder();
                    for (String t : an.scan.timers) sb.append(t).append("\n");
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("timers", sb.toString()));
                    Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
                }).create();
        fillTimers(list);
        dlg.show();
    }

    private void fillTimers(final LinearLayout list) {
        list.removeAllViews();
        int shown = 0;
        for (final TimerScan.Hit h : an.scan.hits) {
            if (shown++ >= 150) break;
            Long e = opts.timerEdits.get(h.key());
            String state = e == null ? "" : (h.type == 2 ? "\n-> sound removed (edited)" : h.type == 1
                    ? "\n-> " + Float.intBitsToFloat((int) e.longValue()) + " (edited)"
                    : (e.longValue() < 0 ? "\n-> NEVER (edited)" : "\n-> " + e + " ms (edited)"));
            TextView t = Ui.text(this, h.label + state, 13, h.editable ? Ui.TEXT : Ui.SUB, false);
            t.setPadding(dp(10), dp(10), dp(10), dp(10));
            if (h.editable) {
                t.setBackground(Ui.ripple(this, e != null ? 0xFF2A2F55 : (h.origin ? 0xFF33264F : Ui.CARD), 10));
                t.setOnClickListener(v -> editTimer(h, () -> fillTimers(list)));
            }
            list.addView(t);
            View gap = new View(this);
            list.addView(gap, new LinearLayout.LayoutParams(MATCH, dp(6)));
        }
    }

    private void editTimer(final TimerScan.Hit h, final Runnable after) {
        if (h.type == 1) {
            editThickness(h, after);
            return;
        }
        if (h.type == 2) {
            new android.app.AlertDialog.Builder(this).setTitle("Remove this sound?")
                    .setMessage(h.label + "\n\nThe call that plays the sound is cut out of the code when you tap Patch.")
                    .setPositiveButton("Remove sound", (d, w) -> {
                        opts.timerEdits.put(h.key(), Long.valueOf(-2));
                        after.run();
                    })
                    .setNeutralButton("Original", (d, w) -> {
                        opts.timerEdits.remove(h.key());
                        after.run();
                    })
                    .setNegativeButton("Cancel", null).show();
            return;
        }
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_NUMBER);
        Long cur = opts.timerEdits.get(h.key());
        in.setText(String.valueOf(cur != null && cur.longValue() > 0 ? cur.longValue() : h.value));
        new android.app.AlertDialog.Builder(this).setTitle("Edit timer")
                .setMessage(h.label.replaceAll(" ~ .*", "") + "\nnow " + h.value + " ms\n\nNew delay in milliseconds "
                        + "(1000 = 1 second, highest here " + h.maxMs() + "), or Never.")
                .setView(in)
                .setPositiveButton("Set", (d, w) -> {
                    try {
                        long v = Long.parseLong(in.getText().toString().trim());
                        if (v < 0 || v > h.maxMs()) {
                            Toast.makeText(this, "Use 0 to " + h.maxMs() + " ms, or tap Never.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (v == h.value) opts.timerEdits.remove(h.key());
                        else opts.timerEdits.put(h.key(), Long.valueOf(v));
                    } catch (NumberFormatException ex) {
                        Toast.makeText(this, "Type a number of milliseconds.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    after.run();
                })
                .setNegativeButton("Never", (d, w) -> {
                    opts.timerEdits.put(h.key(), Long.valueOf(-1));
                    after.run();
                })
                .setNeutralButton("Original", (d, w) -> {
                    opts.timerEdits.remove(h.key());
                    after.run();
                }).show();
    }

    /** A number near Paint.setStrokeWidth: the thickness of a line the app draws itself. */
    private void editThickness(final TimerScan.Hit h, final Runnable after) {
        final List<TimerScan.Hit> same = TimerScan.sameLines(an.scan.hits, h);
        LinearLayout box = Ui.vbox(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        Long cur = opts.timerEdits.get(h.key());
        float now = cur != null ? Float.intBitsToFloat((int) cur.longValue()) : h.asFloat();
        in.setText(String.valueOf(now));
        box.addView(in);
        final android.widget.CheckBox all = new android.widget.CheckBox(this);
        all.setText("Same thickness for ALL lines of this kind (" + same.size() + " place" + (same.size() == 1 ? "" : "s")
                + ")");
        all.setChecked(true);
        all.setVisibility(same.size() > 1 ? View.VISIBLE : View.GONE);
        box.addView(all);
        new android.app.AlertDialog.Builder(this).setTitle(h.origin ? "Origin lines (top)" : "Edit line thickness")
                .setMessage(h.label.replaceAll(", nearby number.*", "").replaceAll(", number 1.5.*", "")
                        + "\nnow " + h.asFloat()
                        + "\n\nNew number (for example 1.5 -> 1 for a thinner line, 0.3 for a hairline, 3 for a "
                        + "thicker one). The app multiplies it by the screen density, so it is about dp. "
                        + "Down to 0.05 is allowed.")
                .setView(box)
                .setPositiveButton("Set", (d, w) -> {
                    try {
                        float v = Float.parseFloat(in.getText().toString().trim());
                        if (v < 0.05f || v > 100f) {
                            Toast.makeText(this, "Use 0.05 to 100.", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        List<TimerScan.Hit> targets = all.isChecked() ? same : java.util.Collections.singletonList(h);
                        for (TimerScan.Hit t : targets) {
                            int bits = Float.floatToIntBits(v);
                            if (t.op == 0x15) bits = (bits + 0x8000) & 0xFFFF0000; // only the top 16 bits fit here
                            if (bits == (int) t.value) opts.timerEdits.remove(t.key());
                            else opts.timerEdits.put(t.key(), Long.valueOf(bits));
                        }
                    } catch (NumberFormatException ex) {
                        Toast.makeText(this, "Type a number like 1 or 0.3", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    after.run();
                })
                .setNeutralButton("Original", (d, w) -> {
                    List<TimerScan.Hit> targets = all.isChecked() ? same : java.util.Collections.singletonList(h);
                    for (TimerScan.Hit t : targets) opts.timerEdits.remove(t.key());
                    after.run();
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void showTimers(final List<String> timers) {
        if (timers.isEmpty()) {
            Toast.makeText(this, "No timers found in the code of this app.", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < timers.size(); i++) sb.append(timers.get(i)).append("\n\n");
        TextView t = new TextView(this);
        t.setText(sb.toString());
        t.setTextSize(12);
        t.setTextIsSelectable(true);
        t.setPadding(dp(16), dp(12), dp(16), dp(12));
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(t);
        final String all = sb.toString();
        new android.app.AlertDialog.Builder(this).setTitle("Timers in this app").setView(sv)
                .setPositiveButton("Copy all", (d, w) -> {
                    android.content.ClipboardManager cm =
                            (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("timers", all));
                    Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Close", null).show();
    }

    private void sliderRow(LinearLayout card, String title, final int lo, final int hi,
                           Supplier<Integer> g, final Consumer<Integer> s, final String unit, final String zeroLabel) {
        sliderRow(card, title, lo, hi, g, s, unit, zeroLabel, lo);
    }

    /** defVal is the value that means "original" (shown with zeroLabel); the slider goes below and above it. */
    private void sliderRow(LinearLayout card, String title, final int lo, final int hi,
                           Supplier<Integer> g, final Consumer<Integer> s, final String unit, final String zeroLabel,
                           final int defVal) {
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, dp(10), 0, dp(8));
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, title, 15, Ui.TEXT, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        final TextView val = Ui.text(this, (zeroLabel != null && g.get() == defVal) ? zeroLabel : showVal(g.get(), unit),
                14, Ui.ACCENT, true);
        head.addView(val);
        row.addView(head);
        SeekBar sb = new SeekBar(this);
        sb.setMax(hi - lo);
        sb.setProgress(g.get() - lo);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                int v = lo + p;
                s.accept(v);
                val.setText((zeroLabel != null && v == defVal) ? zeroLabel : showVal(v, unit));
                updateBar();
            }

            @Override
            public void onStartTrackingTouch(SeekBar b) {}

            @Override
            public void onStopTrackingTouch(SeekBar b) {}
        });
        row.addView(sb, new LinearLayout.LayoutParams(MATCH, WRAP));
        addRow(card, row);
    }

    /** "5 dp"; a unit that starts with the plus-minus sign shows +5 / -5. */
    private static String showVal(int v, String unit) {
        if (unit.startsWith("\u00B1")) return (v > 0 ? "+" : "") + v + unit.substring(1);
        return v + unit;
    }

    private static String tenthsText(int v) {
        return (v % 10 == 0) ? String.valueOf(v / 10) : (v / 10 + "." + Math.abs(v % 10));
    }

    /** A slider in tenths (5 = 0.5 dp) with - 0.1 / + 0.1 buttons. 0 shows zeroLabel (the original). */
    private void sliderRowTenths(LinearLayout card, String title, final int hi, final Supplier<Integer> g,
                                 final Consumer<Integer> s, final String zeroLabel) {
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, dp(10), 0, dp(8));
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, title, 15, Ui.TEXT, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        final TextView val = Ui.text(this, g.get() == 0 ? zeroLabel : tenthsText(g.get()) + " dp", 14, Ui.ACCENT, true);
        head.addView(val);
        row.addView(head);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(hi);
        sb.setProgress(g.get());
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                s.accept(p);
                val.setText(p == 0 ? zeroLabel : tenthsText(p) + " dp");
                updateBar();
            }

            @Override
            public void onStartTrackingTouch(SeekBar b) {}

            @Override
            public void onStopTrackingTouch(SeekBar b) {}
        });
        LinearLayout bar = Ui.hbox(this);
        TextView minus = Ui.chip(this, "\u2212 0.1");
        minus.setOnClickListener(v -> sb.setProgress(Math.max(0, sb.getProgress() - 1)));
        TextView plus = Ui.chip(this, "+ 0.1");
        plus.setOnClickListener(v -> sb.setProgress(Math.min(hi, sb.getProgress() + 1)));
        bar.addView(minus);
        bar.addView(sb, new LinearLayout.LayoutParams(0, WRAP, 1f));
        bar.addView(plus);
        row.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));
        addRow(card, row);
    }

    private void afterChange() {
        syncing = true;
        try {
            for (Runnable r : syncers) r.run();
        } finally {
            syncing = false;
        }
        updateBar();
    }

    private void updateBar() {
        if (barInfo == null) return;
        int n = opts.changeCount();
        String s = n == 0 ? "Nothing selected yet" : n + " change" + (n == 1 ? "" : "s") + " selected";
        if (n > 0 && opts.needsEngine()) s += "\n+ silent engine inside the app";
        barInfo.setText(s);
    }

    // =======================================================================================
    // 3. working / error / done
    // =======================================================================================

    private void showWorking(String title) {
        screen = 2;
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(44), dp(18), dp(18));
        col.addView(Ui.text(this, title, 24, Ui.TEXT, true));
        workBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        workBar.setMax(100);
        workBar.setIndeterminate(true);
        Ui.add(col, workBar, 16);

        workLog = Ui.text(this, "", 12.5f, Ui.SUB, false);
        workLog.setTypeface(Typeface.MONOSPACE);
        workLog.setPadding(dp(14), dp(12), dp(14), dp(12));
        workLog.setBackground(Ui.round(this, Ui.CARD, 14));
        workScroll = new ScrollView(this);
        workScroll.addView(workLog);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
        lp.topMargin = dp(16);
        col.addView(workScroll, lp);
        show(col);
        synchronized (logText) {
            workLog.setText(logText.toString());
        }
    }

    private void showError(Throwable t) {
        screen = 3;
        ScrollView sv = new ScrollView(this);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(40), dp(18), dp(24));
        sv.addView(col);
        col.addView(Ui.text(this, "That did not work", 26, Ui.BAD, true));
        String m = t.getMessage() != null ? t.getMessage() : t.toString();
        TextView msg = Ui.text(this, m, 14.5f, Ui.TEXT, false);
        msg.setPadding(0, dp(10), 0, dp(6));
        col.addView(msg);
        TextView log = Ui.text(this, logSnapshot(), 12, Ui.SUB, false);
        log.setTypeface(Typeface.MONOSPACE);
        log.setPadding(dp(14), dp(12), dp(14), dp(12));
        log.setBackground(Ui.round(this, Ui.CARD, 14));
        Ui.add(col, log, 12);
        actionButton(col, "Copy log", false, v -> copyLog());
        if (an != null) actionButton(col, "Back to options", true, v -> showOptions());
        else actionButton(col, "Back", true, v -> showHome());
        show(sv);
    }

    private void showDone() {
        screen = 3;
        ScrollView sv = new ScrollView(this);
        LinearLayout col = Ui.vbox(this);
        col.setPadding(dp(18), dp(40), dp(18), dp(24));
        sv.addView(col);
        col.addView(Ui.text(this, "Patched", 30, Ui.GOOD, true));
        TextView sub = Ui.text(this, last.label + "  •  " + String.format(Locale.US, "%.1f MB", last.size / 1048576.0),
                14, Ui.SUB, false);
        sub.setPadding(0, dp(4), 0, dp(14));
        col.addView(sub);

        LinearLayout card = Ui.card(this);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.addView(Ui.text(this, "What changed", 13, Ui.SUB, true));
        if (last.applied.isEmpty()) {
            card.addView(Ui.text(this, "Nothing visible; the APK was only re-signed.", 14, Ui.TEXT, false));
        }
        for (String s : last.applied) {
            TextView t = Ui.text(this, "•  " + s, 14.5f, Ui.TEXT, false);
            t.setPadding(0, dp(6), 0, 0);
            card.addView(t);
        }
        col.addView(card, new LinearLayout.LayoutParams(MATCH, WRAP));
        if (last.live) {
            TextView hint = Ui.text(this, "Install it and open the app: the pencil handle appears at once, even before "
                    + "you allow anything (inside the app's own screens). A Live Editor popup then asks for "
                    + "\"Display over other apps\" so the pencil also shows above menus and floating windows. "
                    + "Tap the pencil to edit; More, Copy settings, to convert it to a normal APK later.",
                    12.5f, Ui.SUB, false);
            hint.setPadding(dp(4), dp(12), dp(4), 0);
            col.addView(hint);
        }

        actionButton(col, "Install", true, v -> install());
        if (last.live) {
            actionButton(col, "Allow overlay for the patched app", false, v -> openOverlayPermission());
        }
        actionButton(col, "Uninstall the original first", false, v -> uninstallOriginal());
        actionButton(col, "Save a copy...", false, v -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/vnd.android.package-archive");
            i.putExtra(Intent.EXTRA_TITLE, safeName(last.label) + "_patched.apk");
            startActivityForResult(i, REQ_SAVE);
        });
        actionButton(col, "Share", false, v -> share());
        actionButton(col, "Change options and patch again", false, v -> showOptions());
        actionButton(col, "Start with another app", false, v -> showHome());
        actionButton(col, "Copy log", false, v -> copyLog());
        show(sv);
    }

    private void actionButton(LinearLayout col, String text, boolean primary, View.OnClickListener l) {
        Button b = Ui.button(this, text, primary);
        b.setOnClickListener(l);
        Ui.add(col, b, 10);
    }

    // ---- actions on the finished APK ----------------------------------------------------------

    private Uri apkUri() {
        return FileProvider.getUriForFile(this, getPackageName() + ".files", last.apk);
    }

    private void install() {
        if (!getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Allow \"Install unknown apps\" for Live Editor, then tap Install again",
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(apkUri(), "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }

    /** Opens Android's "Display over other apps" page of the patched app (it must be installed first). */
    private void openOverlayPermission() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + last.packageName)));
        } catch (Throwable t) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            } catch (Throwable t2) {
                Toast.makeText(this, "Open Settings > Apps > Special access > Display over other apps",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void uninstallOriginal() {
        startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + last.packageName)));
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/vnd.android.package-archive");
        i.putExtra(Intent.EXTRA_STREAM, apkUri());
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share APK"));
    }

    private void saveCopy(final Uri to) {
        final File src = last.apk;
        new Thread(() -> {
            try {
                OutputStream os = getContentResolver().openOutputStream(to);
                if (os == null) throw new IOException("Cannot write there");
                InputStream is = new FileInputStream(src);
                try {
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
                } finally {
                    is.close();
                    os.close();
                }
                runOnUiThread(() -> Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show());
            } catch (final Throwable t) {
                runOnUiThread(() -> Toast.makeText(this, "Could not save: " + t.getMessage(),
                        Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private String logSnapshot() {
        synchronized (logText) {
            return logText.toString();
        }
    }

    private void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("Live Editor log", logSnapshot()));
            Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show();
        }
    }

    private static String safeName(String s) {
        String n = s == null ? "app" : s.replaceAll("[^A-Za-z0-9._-]+", "_");
        return n.length() == 0 ? "app" : n;
    }
}
