package com.liveedit.agent;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.KeyEvent;
import android.widget.HorizontalScrollView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.List;

/**
 * The live editor: a small pencil handle that opens a panel. The panel lists every visible menu, button, icon and
 * text (overlays and app screens) and lets you change size (dp), colour, name, opacity or hide each one, plus the
 * global button/menu sizes and the app theme. Changes show at once and are kept; "Copy settings" exports them so
 * the Live Editor app can build a normal APK (no handle) with these edits inside.
 * Only exists when the APK was patched with "Live Editor inside the app".
 */
final class Panel {
    static final String TAG = "liveedit-own";

    private static final int BG = 0xF2171A21;
    private static final int CARD = 0xFF262B36;
    private static final int TEXT = 0xFFECEFF4;
    private static final int SUB = 0xFF9AA3B2;
    private static final int ACC = 0xFF7C5CFF;

    private static final String[] PRESET_NAMES = {"Dark", "AMOLED", "Light", "Blue", "Green", "Purple", "Red"};
    private static final int[][] PRESETS = {
            {0xFF101418, 0xFFECEFF4, 0xFF7C5CFF},
            {0xFF000000, 0xFFFFFFFF, 0xFF00E5FF},
            {0xFFF4F5F7, 0xFF111418, 0xFF2563EB},
            {0xFF0B1B33, 0xFFE6F0FF, 0xFF3B82F6},
            {0xFF0B2016, 0xFFE6FFF1, 0xFF22C55E},
            {0xFF1A1030, 0xFFF1E9FF, 0xFFA855F7},
            {0xFF240C0C, 0xFFFFECEC, 0xFFEF4444}
    };

    private interface IntCb {
        void on(int v);
    }

    private static Panel inst;
    private static boolean asked;

    private final Application app;
    private final Context ctx;
    private final WindowManager wm;
    private final Handler h = new Handler(Looper.getMainLooper());

    private TextView handle;
    private WindowManager.LayoutParams hlp;
    private LinearLayout panel;
    private WindowManager.LayoutParams plp;
    private LinearLayout body;
    private ScrollView scroll;
    private boolean open;

    // No overlay permission: the pencil and the panel live in the app's own window (PopupWindow), which needs no permission.
    private PopupWindow popHandle;
    private WeakReference<Activity> popOwner;
    private PopupWindow panelPop;
    private WeakReference<Activity> panelOwner;
    private int hx;
    private int hy;
    private long lastTop;
    private boolean overlayFailed; // the overlay window could not be added even with the permission (some phones)

    // pinned preview of the item that is being edited (outside the scrolling part, so it stays in view)
    private LinearLayout previewRow;
    private android.widget.ImageView previewImg;
    private TextView previewText;
    private final Runnable previewTick = new Runnable() {
        @Override
        public void run() {
            try {
                refreshPreview();
            } catch (Throwable t) {
                U.err("preview", t);
            }
            if (previewRow != null && previewRow.getVisibility() == View.VISIBLE && panel != null) {
                h.postDelayed(this, 400);
            }
        }
    };

    private static final int[] PALETTE = {
            0xFF000000, 0xFF424242, 0xFF9E9E9E, 0xFFE0E0E0, 0xFFFFFFFF, 0xFF795548, 0xFF607D8B, 0xFF0B1B33,
            0xFFF44336, 0xFFE91E63, 0xFF9C27B0, 0xFF673AB7, 0xFF3F51B5, 0xFF2196F3, 0xFF03A9F4, 0xFF00BCD4,
            0xFF009688, 0xFF4CAF50, 0xFF8BC34A, 0xFFCDDC39, 0xFFFFEB3B, 0xFFFFC107, 0xFFFF9800, 0xFFFF5722
    };

    private int tab;      // 0 items, 1 windows, 2 global, 3 theme, 4 more
    private int filter;   // 0 all, 1 menu, 2 buttons, 3 icons, 4 app
    private Overlays.El editing;

    /** Runs shortly after the app starts and then every 0.7 s: keeps exactly one pencil on screen. */
    private final Runnable ensure = new Runnable() {
        @Override
        public void run() {
            try {
                tick();
            } catch (Throwable t) {
                U.err("handle", t);
            }
            h.postDelayed(this, 700);
        }
    };

    /** True for the pencil, the panel, and the window that holds them (a PopupWindow wraps its content). */
    static boolean isOwn(View v) {
        return ownWithin(v, 3);
    }

    private static boolean ownWithin(View v, int depth) {
        if (v == null) return false;
        if (TAG.equals(v.getTag())) return true;
        if (depth > 0 && v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount() && i < 3; i++) {
                if (ownWithin(g.getChildAt(i), depth - 1)) return true;
            }
        }
        return false;
    }

    /** Called when an app screen comes on screen, so the pencil moves over at once. */
    static void nudge() {
        final Panel p = inst;
        if (p == null) return;
        p.h.post(new Runnable() {
            @Override
            public void run() {
                try {
                    p.tick();
                } catch (Throwable t) {
                    U.err("nudge", t);
                }
            }
        });
    }

    /** An app screen goes away: whatever we showed inside its window goes with it. */
    static void onPause(Activity a) {
        Panel p = inst;
        if (p == null || a == null) return;
        Activity ho = p.popOwner == null ? null : p.popOwner.get();
        if (ho == a && p.popHandle != null) {
            p.dismissPop(p.popHandle);
            p.popHandle = null;
        }
        Activity po = p.panelOwner == null ? null : p.panelOwner.get();
        if (po == a && p.panelPop != null) p.closePanel();
    }

    static synchronized void start(Application app) {
        if (inst != null) return;
        try {
            inst = new Panel(app);
            inst.h.postDelayed(inst.ensure, 300);
        } catch (Throwable t) {
            U.err("panel", t);
        }
    }

    private Panel(Application app) {
        this.app = app;
        this.ctx = new ContextThemeWrapper(app, android.R.style.Theme_Material);
        this.wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
        this.hx = dp(4);
        this.hy = dp(120);
    }

    // ---- handle ----------------------------------------------------------------------------

    private static int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
    }

    private int dp(float v) {
        return U.dp(ctx, v);
    }

    private void toast(String s) {
        try {
            Toast.makeText(app, s, Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            // ignore
        }
    }

    private boolean canDraw() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(app);
    }

    /** One step of the loop: pick the right kind of pencil for the permission the app has right now. */
    private void tick() {
        boolean can = canDraw();
        if (can && !overlayFailed) {
            if (popHandle != null) { // the permission arrived: change over to the overlay pencil
                dismissPop(popHandle);
                popHandle = null;
            }
            if (handle == null) {
                try {
                    addOverlayHandle();
                } catch (Throwable t) {
                    overlayFailed = true;
                    U.err("overlay pencil failed, using the in-app pencil", t);
                    showPopHandle();
                }
            } else {
                keepOnTop();
            }
            return;
        }
        if (handle != null) { // the permission was taken away
            try {
                wm.removeView(handle);
            } catch (Throwable t) {
                // ignore
            }
            handle = null;
        }
        if (!can) askPermission(false);
        showPopHandle();
    }

    private void dismissPop(PopupWindow pw) {
        try {
            if (pw != null) pw.dismiss();
        } catch (Throwable t) {
            // ignore
        }
    }

    private boolean declaresOverlay() {
        try {
            PackageInfo pi = app.getPackageManager().getPackageInfo(app.getPackageName(),
                    PackageManager.GET_PERMISSIONS);
            if (pi.requestedPermissions != null) {
                for (int i = 0; i < pi.requestedPermissions.length; i++) {
                    if ("android.permission.SYSTEM_ALERT_WINDOW".equals(pi.requestedPermissions[i])) return true;
                }
            }
            return false;
        } catch (Throwable t) {
            U.err("permissions", t);
            return true; // cannot tell: try anyway
        }
    }

    /** A Live Editor popup that leads to Android's "Display over other apps" page. Once per start (long-press the pencil to ask again). */
    private void askPermission(boolean force) {
        if (asked && !force) return;
        final Activity a = Agent.topActivity();
        if (a == null) return;
        View decor = a.getWindow() == null ? null : a.getWindow().peekDecorView();
        if (decor == null || decor.getWindowToken() == null) return; // the screen is not shown yet: try again in a moment
        asked = true;
        if (!declaresOverlay()) {
            toast("Live Editor: this app was patched without the overlay permission. Patch it again with the newest "
                    + "Live Editor to allow it. The pencil still works inside the app's own screens.");
            return;
        }
        try {
            AlertDialog.Builder b = new AlertDialog.Builder(a, android.R.style.Theme_Material_Dialog_Alert);
            b.setTitle("Live Editor");
            b.setMessage("Allow \"Display over other apps\" for this app?\n\nThen the \u270E pencil also shows above "
                    + "menus and floating windows. Without it the pencil still works inside the app's own screens.");
            b.setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface di, int which) {
                    openOverlaySettings(a);
                }
            });
            b.setNegativeButton("Not now", null);
            b.show();
        } catch (Throwable t) {
            U.err("permission dialog", t);
        }
    }

    private void openOverlaySettings(Activity a) {
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + app.getPackageName()));
            a.startActivity(i);
        } catch (Throwable t) {
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            } catch (Throwable t2) {
                toast("Open Settings > Apps > Special access > Display over other apps and allow this app.");
            }
        }
    }

    /** The pencil with the permission: a window above everything. */
    private void addOverlayHandle() {
        TextView t = buildHandle(false);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(dp(44), dp(44), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = hx;
        lp.y = hy;
        hlp = lp;
        wm.addView(t, lp);
        handle = t;
        U.log("live editor handle shown");
    }

    /** The pencil without the permission: a sub-window of the app screen that is on top right now. */
    private void showPopHandle() {
        Activity a = Agent.topActivity();
        if (a == null) return;
        if (popHandle != null) {
            Activity owner = popOwner == null ? null : popOwner.get();
            if (owner == a && popHandle.isShowing()) return;
            dismissPop(popHandle); // another screen is on top: move the pencil there
            popHandle = null;
        }
        View decor = a.getWindow() == null ? null : a.getWindow().peekDecorView();
        if (decor == null || decor.getWindowToken() == null) return;
        try {
            PopupWindow pw = new PopupWindow(a);
            pw.setContentView(buildHandle(true));
            pw.setWidth(dp(44));
            pw.setHeight(dp(44));
            pw.setFocusable(false);
            pw.setBackgroundDrawable(null);
            pw.setElevation(0f);
            pw.showAtLocation(decor, Gravity.TOP | Gravity.LEFT, hx, hy);
            popHandle = pw;
            popOwner = new WeakReference<Activity>(a);
            U.log("live editor pencil shown inside the app window (no overlay permission)");
        } catch (Throwable t) {
            U.err("pencil popup", t);
        }
    }

    private TextView buildHandle(final boolean pop) {
        final TextView t = new TextView(ctx);
        t.setText("\u270E");
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(ACC);
        t.setBackground(g);
        t.setAlpha(0.85f);
        t.setTag(TAG);
        t.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY;
            private int startX, startY;
            private boolean moved, longFired;
            private final Runnable longPress = new Runnable() {
                @Override
                public void run() {
                    longFired = true;
                    askPermission(true);
                }
            };

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    startX = hx;
                    startY = hy;
                    downX = e.getRawX();
                    downY = e.getRawY();
                    moved = false;
                    longFired = false;
                    if (pop) h.postDelayed(longPress, 800);
                    return true;
                }
                if (a == MotionEvent.ACTION_MOVE) {
                    float dx = e.getRawX() - downX;
                    float dy = e.getRawY() - downY;
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                        moved = true;
                        h.removeCallbacks(longPress);
                    }
                    if (moved) {
                        hx = startX + Math.round(dx);
                        hy = startY + Math.round(dy);
                        moveHandle(t, pop);
                    }
                    return true;
                }
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    h.removeCallbacks(longPress);
                    if (a == MotionEvent.ACTION_UP && !moved && !longFired) toggle();
                    return true;
                }
                return false;
            }
        });
        return t;
    }

    private void moveHandle(View t, boolean pop) {
        try {
            if (pop) {
                if (popHandle != null) popHandle.update(hx, hy, -1, -1);
            } else if (hlp != null) {
                hlp.x = hx;
                hlp.y = hy;
                wm.updateViewLayout(t, hlp);
            }
        } catch (Throwable ex) {
            // ignore
        }
    }

    /** A floating window the app added after the pencil would cover it: add the pencil again, on top. */
    private void keepOnTop() {
        long now = SystemClock.uptimeMillis();
        if (now - lastTop < 3000L || handle == null || open) return;
        lastTop = now;
        List<View> r = Overlays.roots();
        int idx = r.indexOf(handle);
        if (idx < 0) { // the window is gone (the app or the system removed it): add it again
            handle = null;
            addOverlayHandle();
            return;
        }
        boolean covered = false;
        for (int i = idx + 1; i < r.size(); i++) {
            View v = r.get(i);
            if (!isOwn(v) && Overlays.isOverlay(v)) {
                covered = true;
                break;
            }
        }
        if (covered) {
            try {
                wm.removeView(handle);
                wm.addView(handle, hlp);
            } catch (Throwable t) {
                U.err("pencil to front", t);
                handle = null;
            }
        }
    }

    private void toggle() {
        if (open) closePanel();
        else openPanel();
    }

    private void closePanel() {
        open = false;
        editing = null;
        Config.saveLive(app);
        PopupWindow pp = panelPop;
        panelPop = null;
        try {
            if (pp != null) pp.dismiss();
            else if (panel != null) wm.removeView(panel);
        } catch (Throwable t) {
            // ignore
        }
        panel = null;
    }

    private void openPanel() {
        try {
            int sw = app.getResources().getDisplayMetrics().widthPixels;
            int sh = app.getResources().getDisplayMetrics().heightPixels;
            // a touch outside the panel closes it (the touch still goes to the app under it)
            panel = new LinearLayout(ctx) {
                @Override
                public boolean dispatchTouchEvent(MotionEvent ev) {
                    if (ev.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                        closePanel();
                        return true;
                    }
                    return super.dispatchTouchEvent(ev);
                }

                @Override
                public boolean dispatchKeyEvent(KeyEvent ev) {
                    if (ev.getKeyCode() == KeyEvent.KEYCODE_BACK && ev.getAction() == KeyEvent.ACTION_UP) {
                        closePanel();
                        return true;
                    }
                    return super.dispatchKeyEvent(ev);
                }
            };
            panel.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(BG);
            bg.setCornerRadius(dp(16));
            panel.setBackground(bg);
            panel.setPadding(dp(10), dp(8), dp(10), dp(8));
            panel.setTag(TAG);

            LinearLayout top = new LinearLayout(ctx);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView x = chip("\u2715 Close  " + Agent.ENGINE, true);
            x.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closePanel();
                }
            });
            top.addView(x, chipLp());
            HorizontalScrollView tabScroll = new HorizontalScrollView(ctx);
            tabScroll.setHorizontalScrollBarEnabled(false);
            LinearLayout tabRow = new LinearLayout(ctx);
            tabRow.setOrientation(LinearLayout.HORIZONTAL);
            tabRow.setGravity(Gravity.CENTER_VERTICAL);
            tabRow.setTag("top");
            String[] tabs = {"Items", "Windows", "Global", "Theme", "More"};
            for (int i = 0; i < tabs.length; i++) {
                final int which = i;
                TextView c = chip(tabs[i], tab == i);
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tab = which;
                        editing = null;
                        rebuildTop();
                        render();
                    }
                });
                tabRow.addView(c, chipLp());
            }
            tabScroll.addView(tabRow);
            top.addView(tabScroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            panel.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            previewRow = new LinearLayout(ctx);
            previewRow.setOrientation(LinearLayout.HORIZONTAL);
            previewRow.setGravity(Gravity.CENTER_VERTICAL);
            previewRow.setPadding(dp(8), dp(6), dp(8), dp(6));
            GradientDrawable pbg = new GradientDrawable();
            pbg.setColor(CARD);
            pbg.setCornerRadius(dp(10));
            previewRow.setBackground(pbg);
            previewImg = new android.widget.ImageView(ctx);
            previewImg.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
            previewRow.addView(previewImg, new LinearLayout.LayoutParams(dp(96), dp(72)));
            previewText = label("", 12, SUB, false);
            LinearLayout.LayoutParams ptl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            ptl.leftMargin = dp(10);
            previewRow.addView(previewText, ptl);
            previewRow.setVisibility(View.GONE);
            LinearLayout.LayoutParams prl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            prl.topMargin = dp(6);
            panel.addView(previewRow, prl);

            scroll = new ScrollView(ctx);
            body = new LinearLayout(ctx);
            body.setOrientation(LinearLayout.VERTICAL);
            body.setPadding(0, dp(6), 0, dp(6));
            scroll.addView(body);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            slp.topMargin = dp(6);
            panel.addView(scroll, slp);

            int w = Math.min(dp(400), sw - dp(16));
            int hh = Math.min(dp(560), Math.round(sh * 0.78f));
            boolean placed = false;
            if (canDraw() && !overlayFailed) {
                try {
                    plp = new WindowManager.LayoutParams(w, hh, overlayType(),
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                                    | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT);
                    plp.gravity = Gravity.CENTER;
                    plp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
                    wm.addView(panel, plp);
                    placed = true;
                } catch (Throwable t) {
                    overlayFailed = true;
                    U.err("overlay panel failed, using a popup", t);
                }
            }
            if (!placed) showPanelPopup(w, hh);
            open = true;
            render();
        } catch (Throwable t) {
            U.err("open panel", t);
            toast("Live Editor could not open its panel.");
            panel = null;
            open = false;
        }
    }

    /** The panel without the overlay permission: a popup window of the app screen that is on top. */
    private void showPanelPopup(int w, int hh) {
        Activity a = Agent.topActivity();
        View decor = a == null || a.getWindow() == null ? null : a.getWindow().peekDecorView();
        if (decor == null || decor.getWindowToken() == null) throw new IllegalStateException("no app screen to attach to");
        final PopupWindow pw = new PopupWindow(a);
        pw.setContentView(panel);
        pw.setWidth(w);
        pw.setHeight(hh);
        pw.setFocusable(true);
        pw.setOutsideTouchable(true);
        pw.setBackgroundDrawable(new ColorDrawable(0));
        pw.setElevation(0f);
        pw.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        pw.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);
        pw.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                if (panelPop == pw) { // closed by a touch outside or the Back key
                    panelPop = null;
                    open = false;
                    editing = null;
                    panel = null;
                    Config.saveLive(app);
                }
            }
        });
        pw.showAtLocation(decor, Gravity.CENTER, 0, 0);
        panelPop = pw;
        panelOwner = new WeakReference<Activity>(a);
    }

    private void rebuildTop() {
        if (panel == null) return;
        View top = panel.findViewWithTag("top");
        if (!(top instanceof LinearLayout)) return;
        LinearLayout t = (LinearLayout) top;
        String[] tabs = {"Items", "Windows", "Global", "Theme", "More"};
        for (int i = 0; i < tabs.length && i < t.getChildCount(); i++) {
            View c = t.getChildAt(i);
            if (c instanceof TextView) styleChip((TextView) c, tab == i);
        }
    }

    // ---- small view kit --------------------------------------------------------------------

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(6);
        return lp;
    }

    private TextView chip(String s, boolean on) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(13);
        t.setPadding(dp(11), dp(7), dp(11), dp(7));
        t.setClickable(true);
        styleChip(t, on);
        return t;
    }

    private void styleChip(TextView t, boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(on ? ACC : CARD);
        g.setCornerRadius(dp(14));
        t.setBackground(g);
        t.setTextColor(TEXT);
    }

    private TextView label(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void add(LinearLayout parent, View v, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topDp);
        parent.addView(v, lp);
    }

    private String fmt(String label, int v, int min, String unit, String zeroLabel) {
        boolean signed = unit.startsWith("\u00B1");
        String u = signed ? unit.substring(1) : unit;
        String val = (zeroLabel != null && v == min) ? zeroLabel : ((signed && v > 0 ? "+" : "") + v + u);
        return label + ":  " + val;
    }

    /** Tenths as text: 5 -> "0.5", 15 -> "1.5", 30 -> "3". */
    private static String tenths(int v) {
        return (v % 10 == 0) ? String.valueOf(v / 10) : (v / 10 + "." + Math.abs(v % 10));
    }

    private String fmtT(String label, int v, String unit, String zeroLabel, boolean showPx) {
        if (zeroLabel != null && v == 0) return label + ":  " + zeroLabel;
        String t = label + ":  " + tenths(v) + unit;
        if (showPx) {
            float px = v / 10f * U.density(ctx);
            t += "   (" + (Math.round(px * 10f) / 10f) + " px on this phone)";
        }
        return t;
    }

    /**
     * A slider in tenths (5 = 0.5) with - and + buttons for exact 0.1 steps. Values below the original and above it
     * are both possible. zeroLabel is shown for 0 (meaning: keep the original).
     */
    private void tenthSlider(LinearLayout parent, final String label, final int min, final int max, int cur,
                             final String unit, final String zeroLabel, final boolean showPx, final IntCb cb) {
        final TextView head = label(fmtT(label, cur, unit, zeroLabel, showPx), 13, TEXT, false);
        add(parent, head, 10);
        final SeekBar sb = new SeekBar(ctx);
        sb.setMax(max - min);
        sb.setProgress(U.clamp(cur - min, 0, max - min));
        final IntCb set = new IntCb() {
            @Override
            public void on(int v) {
                int nv = U.clamp(v, min, max);
                sb.setProgress(nv - min);
                head.setText(fmtT(label, nv, unit, zeroLabel, showPx));
                cb.on(nv);
                Overlays.tick(app);
                Config.saveLive(app);
            }
        };
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s2, int p, boolean fromUser) {
                if (!fromUser) return;
                int v = min + p;
                head.setText(fmtT(label, v, unit, zeroLabel, showPx));
                cb.on(v);
                Overlays.tick(app);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s2) {}

            @Override
            public void onStopTrackingTouch(SeekBar s2) {
                Config.saveLive(app);
            }
        });
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final int[] now = {cur};
        TextView minus = chip("\u2212 0.1", false);
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                now[0] = Math.max(min, sb.getProgress() + min - 1);
                set.on(now[0]);
            }
        });
        TextView plus = chip("+ 0.1", false);
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                now[0] = Math.min(max, sb.getProgress() + min + 1);
                set.on(now[0]);
            }
        });
        row.addView(minus, chipLp());
        row.addView(sb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(plus);
        add(parent, row, 0);
    }

    private void slider(LinearLayout parent, final String label, final int min, int max, int cur,
                        final String unit, final String zeroLabel, final IntCb cb) {
        slider(parent, label, min, max, cur, unit, zeroLabel, min, cb);
    }

    /** defVal is the value that means "original" (shown with zeroLabel); the slider may go below and above it. */
    private void slider(LinearLayout parent, final String label, final int min, int max, int cur,
                        final String unit, final String zeroLabel, final int defVal, final IntCb cb) {
        final TextView head = label(fmt(label, cur, defVal, unit, zeroLabel), 13, TEXT, false);
        add(parent, head, 10);
        SeekBar sb = new SeekBar(ctx);
        sb.setMax(max - min);
        sb.setProgress(U.clamp(cur - min, 0, max - min));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                int v = min + p;
                head.setText(fmt(label, v, defVal, unit, zeroLabel));
                cb.on(v);
                Overlays.tick(app);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {}

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                Config.saveLive(app);
            }
        });
        add(parent, sb, 0);
    }

    private void showPreview(boolean on) {
        if (previewRow == null) return;
        previewRow.setVisibility(on ? View.VISIBLE : View.GONE);
        h.removeCallbacks(previewTick);
        if (on) {
            Overlays.El e = editing;
            previewText.setText(e == null ? "" : e.name + "\n" + e.sub);
            refreshPreview();
            h.postDelayed(previewTick, 400);
        }
    }

    /** The picture of the item being edited, as it looks now (it follows every change). */
    private void refreshPreview() {
        if (previewRow == null || previewRow.getVisibility() != View.VISIBLE || editing == null) return;
        android.graphics.Bitmap bm = Overlays.preview(editing, app, 96f);
        if (bm != null) previewImg.setImageBitmap(bm);
        else previewImg.setImageDrawable(null);
    }

    private void paintCell(View cell, int color, boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(7));
        g.setStroke(selected ? dp(3) : dp(1), selected ? 0xFFFFFFFF : 0x55FFFFFF);
        cell.setBackground(g);
    }

    /** Pick a colour: one tap on a swatch. cur == NONE means "not set". */
    private void colorRow(LinearLayout parent, final String name, int cur, final boolean canClear, final IntCb cb) {
        LinearLayout head = new LinearLayout(ctx);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        final View sw = new View(ctx);
        sw.setBackgroundColor(cur == Rules.NONE ? 0xFF808080 : (cur | 0xFF000000));
        head.addView(sw, new LinearLayout.LayoutParams(dp(26), dp(26)));
        final TextView t = label("  " + name + (cur == Rules.NONE ? ":  keep" : ":  " + hex(cur)), 13, TEXT, false);
        head.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final java.util.ArrayList<View> cells = new java.util.ArrayList<View>();
        final int[] sel = {cur == Rules.NONE ? 0 : (cur | 0xFF000000)};
        if (canClear) {
            TextView clr = chip("Clear", false);
            clr.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cb.on(Rules.NONE);
                    Config.saveLive(app);
                    Overlays.tick(app);
                    render();
                }
            });
            head.addView(clr);
        }
        add(parent, head, 12);
        for (int row = 0; row < PALETTE.length / 8; row++) {
            LinearLayout lr = new LinearLayout(ctx);
            lr.setOrientation(LinearLayout.HORIZONTAL);
            for (int k = 0; k < 8; k++) {
                final int c = PALETTE[row * 8 + k];
                View cell = new View(ctx);
                cell.setTag(Integer.valueOf(c));
                paintCell(cell, c, sel[0] == c);
                cell.setClickable(true);
                cell.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sel[0] = c;
                        sw.setBackgroundColor(c);
                        t.setText("  " + name + ":  " + hex(c));
                        for (int i = 0; i < cells.size(); i++) {
                            paintCell(cells.get(i), ((Integer) cells.get(i).getTag()).intValue(),
                                    ((Integer) cells.get(i).getTag()).intValue() == c);
                        }
                        cb.on(c);
                        Overlays.tick(app);
                        Config.saveLive(app);
                    }
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(32), 1f);
                lp.setMargins(dp(2), dp(2), dp(2), dp(2));
                lr.addView(cell, lp);
                cells.add(cell);
            }
            add(parent, lr, row == 0 ? 6 : 0);
        }
    }

    /** Quick values for a line thickness (tenths of a dp). Below 0.5 dp is a hairline. */
    private void lineChips(LinearLayout parent) {
        LinearLayout r = new LinearLayout(ctx);
        r.setOrientation(LinearLayout.HORIZONTAL);
        int[] vals = {1, 2, 3, 5, 10, 15};
        for (int i = 0; i < vals.length; i++) {
            final int v = vals[i];
            TextView c = chip(tenths(v) + " dp", Config.lineT == v);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    Config.lineT = v;
                    Rules.clearThick();
                    Config.saveLive(app);
                    Overlays.tick(app);
                    render();
                }
            });
            r.addView(c, chipLp());
        }
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(ctx);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(r);
        add(parent, hs, 4);
    }

    /** A slider with exact steps and - / + buttons (marker size in dp, red range in m). */
    private void stepSlider(LinearLayout parent, final String label, final int min, final int max, int cur,
                            final int step, final String unit, final IntCb cb) {
        final int steps = (max - min) / step;
        final TextView head = label(label + ":  " + cur + unit, 13, TEXT, false);
        add(parent, head, 10);
        final SeekBar sb = new SeekBar(ctx);
        sb.setMax(steps);
        sb.setProgress(U.clamp((cur - min) / step, 0, steps));
        final IntCb set = new IntCb() {
            @Override
            public void on(int v) {
                int nv = U.clamp(v, min, max);
                sb.setProgress((nv - min) / step);
                head.setText(label + ":  " + nv + unit);
                cb.on(nv);
                Overlays.tick(app);
                Config.saveLive(app);
            }
        };
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s2, int p, boolean fromUser) {
                if (!fromUser) return;
                int v = min + p * step;
                head.setText(label + ":  " + v + unit);
                cb.on(v);
                Overlays.tick(app);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s2) {}

            @Override
            public void onStopTrackingTouch(SeekBar s2) {
                Config.saveLive(app);
            }
        });
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView minus = chip("\u2212 " + step, false);
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set.on(min + sb.getProgress() * step - step);
            }
        });
        TextView plus = chip("+ " + step, false);
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set.on(min + sb.getProgress() * step + step);
            }
        });
        row.addView(minus, chipLp());
        row.addView(sb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(plus);
        add(parent, row, 0);
    }

    /** Records 8 seconds of line data, copies it, then opens the panel again. */
    private void recordLockData() {
        if (!Config.lockOn) {
            toast("Switch Lock ON first, then record.");
            return;
        }
        final int tabNow = tab;
        final Overlays.El ed = editing;
        closePanel();
        LineTips.recordStart();
        toast("Recording 8 seconds: swipe left and right in the app now.");
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    String rep = LineTips.recordStop(app);
                    ClipboardManager cm = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("Live Editor lock data", rep));
                    toast("Line data copied. Paste it to Claude.");
                } catch (Throwable t) {
                    toast("Could not copy: " + t);
                }
                tab = tabNow;
                openPanel();
                editing = ed;
                render();
            }
        }, 8000L);
    }

    /** A marker / lock setting changed: save it and draw the lines again at once. */
    private void tipChanged() {
        Config.saveLive(app);
        LineTips.refresh();
        Overlays.tick(app);
    }

    private android.widget.HorizontalScrollView chipRow(TextView[] chips) {
        LinearLayout r = new LinearLayout(ctx);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < chips.length; i++) r.addView(chips[i], chipLp());
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(ctx);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(r);
        return hs;
    }

    /**
     * Everything extra for the lines that start at the origin: a PNG marker on the end of every line (always upright,
     * tip down), its size (1 - 20 dp), where it sits, and the Lock switch (lines locked to their targets).
     */
    private void lineExtras(LinearLayout parent) {

        add(parent, label("Marker on the end of the lines (PNG)", 14, ACC, true), 6);
        TextView on = chip(Config.tipOn ? "Marker: ON" : "Marker: OFF", Config.tipOn);
        on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Config.tipOn = !Config.tipOn;
                tipChanged();
                render();
            }
        });
        TextView pick = chip("Choose PNG", false);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickTip();
            }
        });
        TextView built = chip("Built-in marker", Config.tipPng == null);
        built.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Config.tipPng = null;
                Config.tipOn = true;
                tipChanged();
                render();
            }
        });
        add(parent, chipRow(new TextView[] {on, pick, built}), 6);
        note(parent, "The picture is put on the end of EVERY line that starts at the origin. It never turns: the tip "
                + "stays pointing down wherever the line goes (up, down, left, right). "
                + (Config.tipPng == null ? "Now: the built-in marker." : "Now: your own PNG."));
        stepSlider(parent, "Marker size (width)", 1, 20, U.clamp(Config.tipDp, 1, 20), 1, " dp", new IntCb() {
            @Override
            public void on(int v) {
                Config.tipDp = v;
                LineTips.refresh();
            }
        });
        TextView a0 = chip("Tip on the line end", Config.tipAnchor == 0);
        a0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Config.tipAnchor = 0;
                tipChanged();
                render();
            }
        });
        TextView a1 = chip("Centered on the end", Config.tipAnchor == 1);
        a1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Config.tipAnchor = 1;
                tipChanged();
                render();
            }
        });
        add(parent, chipRow(new TextView[] {a0, a1}), 8);

        add(parent, label("Lock lines to targets (VR style)", 14, ACC, true), 18);
        android.widget.Switch lockSw = new android.widget.Switch(ctx);
        lockSw.setText("Lock: ON / OFF");
        lockSw.setTextColor(TEXT);
        lockSw.setChecked(Config.lockOn);
        lockSw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Config.lockOn = on;
                if (on) LineTips.retryLock();
                tipChanged();
                render();
            }
        });
        add(parent, lockSw, 8);
        add(parent, label(LineTips.lockStatus(), 12, TEXT, false), 4);
        TextView pRf = chip("Refresh status", false);
        pRf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                render();
            }
        });
        TextView pRec = chip("Record 8 s of line data", true);
        pRec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recordLockData();
            }
        });
        add(parent, chipRow(new TextView[] {pRec, pRf}), 6);
        note(parent, "To make the lock exact for your app: switch Lock ON, press Record. The panel closes: swipe left and "
                + "right in the app for 8 seconds. The numbers are copied by themselves, paste them to Claude.");
        note(parent, "No settings: the app reports where the targets are only now and then (on the app we measured about "
                + "10 times a second, unevenly), so its lines jump. Lock hides the app's own line drawing and draws the "
                + "lines again at every screen refresh: each line glides to its new position instead of jumping, never "
                + "overshoots (guessing ahead made it worse on this app), ignores the app's own shake of a pixel or two, "
                + "and snaps at once when the picture jumps (a target that goes behind you). If the lines vanish or show "
                + "twice on some app, switch Lock off.");
    }

    /** Opens the file picker for the marker PNG. The panel is closed meanwhile (it would float over the picker). */
    private void pickTip() {
        final int tabNow = tab;
        final Overlays.El ed = editing;
        closePanel();
        boolean started = Picker.pick(new Picker.Result() {
            @Override
            public void done(String base64, String error) {
                try {
                    if (base64 != null) {
                        Config.tipPng = base64;
                        Config.tipOn = true;
                        tipChanged();
                        toast("Marker picture set");
                    } else if (error != null) {
                        toast("Marker not changed: " + error);
                    }
                } catch (Throwable t) {
                    U.err("marker result", t);
                }
                tab = tabNow;
                openPanel();
                editing = ed;
                render();
            }
        });
        if (!started) {
            toast("The file picker could not be opened here.");
            tab = tabNow;
            openPanel();
            editing = ed;
            render();
        }
    }

    /** Opens the file picker for a PNG. The panel is closed meanwhile (it would float over the picker). */
    private void pickIcon(final String key) {
        final Overlays.El ed = editing;
        closePanel();
        boolean started = Picker.pick(new Picker.Result() {
            @Override
            public void done(String base64, String error) {
                try {
                    if (base64 != null) {
                        Rules.edit(key).icon = base64;
                        Config.saveLive(app);
                        Overlays.tick(app);
                        toast("Icon replaced");
                    } else if (error != null) {
                        toast("Icon not changed: " + error);
                    }
                } catch (Throwable t) {
                    U.err("icon result", t);
                }
                tab = 0;
                openPanel();
                editing = ed;
                render();
            }
        });
        if (!started) {
            toast("The file picker could not be opened here.");
            tab = 0;
            openPanel();
            editing = ed;
            render();
        }
    }

    private static String hex(int c) {
        return String.format(java.util.Locale.US, "#%06X", c & 0xFFFFFF);
    }

    private void note(LinearLayout parent, String s) {
        TextView t = label(s, 11.5f, SUB, false);
        add(parent, t, 8);
    }

    // ---- screens ---------------------------------------------------------------------------

    private void render() {
        if (body == null) return;
        body.removeAllViews();
        showPreview(tab == 0 && editing != null);
        try {
            if (tab == 0) {
                if (editing != null) renderEdit();
                else renderList();
            } else if (tab == 1) {
                renderWindows();
            } else if (tab == 2) {
                renderGlobal();
            } else if (tab == 3) {
                renderTheme();
            } else {
                renderMore();
            }
        } catch (Throwable t) {
            U.err("render", t);
            note(body, "Could not draw this screen: " + t);
        }
        if (scroll != null) scroll.scrollTo(0, 0);
    }

    private boolean matches(Overlays.El e) {
        if (filter == 0) return true;
        if (filter == 1) return "menu".equals(e.group);
        if (filter == 2) return "button".equals(e.group);
        if (filter == 3) return "icon".equals(e.group);
        if (filter == 4) return e.line;
        return "app".equals(e.group);
    }

    private void renderList() {
        LinearLayout fr = new LinearLayout(ctx);
        fr.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"All", "Menu", "Buttons", "Icons", "Lines", "App"};
        for (int i = 0; i < names.length; i++) {
            final int which = i;
            TextView c = chip(names[i], filter == i);
            c.setTextSize(12);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    filter = which;
                    render();
                }
            });
            fr.addView(c, chipLp());
        }
        TextView rf = chip("\u21BB", false);
        rf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                render();
            }
        });
        fr.addView(rf, chipLp());
        body.addView(fr);

        List<Overlays.El> all = Overlays.collect(app);
        int shown = 0;
        for (int i = 0; i < all.size(); i++) {
            final Overlays.El e = all.get(i);
            if (!matches(e)) continue;
            shown++;
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            GradientDrawable g = new GradientDrawable();
            g.setColor(CARD);
            g.setCornerRadius(dp(10));
            row.setBackground(g);
            boolean edited = Rules.get(e.o.key) != null;
            row.addView(label((edited ? "\u270E " : "") + e.name, 14, TEXT, true));
            row.addView(label(e.sub, 11, SUB, false));
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editing = e;
                    render();
                }
            });
            add(body, row, 6);
        }
        if (shown == 0) {
            note(body, "Nothing found here. Open the menu or screen you want to edit in the app, then tap \u21BB. "
                    + "Only things that are visible right now are listed.");
        } else {
            note(body, shown + " items. \u270E = already edited. Tap one to change it.");
        }
    }

    private void renderEdit() {
        final Overlays.El e = editing;
        final Rules.Rule r = Rules.edit(e.o.key);
        TextView back = chip("\u2039 Back to list", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editing = null;
                render();
            }
        });
        body.addView(back);
        add(body, label(e.name, 15, TEXT, true), 8);
        add(body, label(e.sub, 11, SUB, false), 0);
        final String frozenKey = e.o.key;
        String fz = EditGuard.blockedNames(frozenKey);
        String iconKey0 = Overlays.iconKeyFor(e);
        String fz2 = iconKey0 == null || iconKey0.equals(frozenKey) ? "" : EditGuard.blockedNames(iconKey0);
        if (fz.length() > 0 || fz2.length() > 0) {
            final String k2 = iconKey0;
            add(body, label("Switched off for this item: " + (fz.length() > 0 ? fz : fz2)
                    + ". The app closed right after that kind of change before, so only that one is off; "
                    + "everything else you set still works.", 12, SUB, false), 8);
            TextView again = chip("Try these changes again", true);
            again.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditGuard.unblockKey(frozenKey);
                    if (k2 != null) EditGuard.unblockKey(k2);
                    toast("Switched on again. If the app closes again, it is switched off again by itself.");
                    Overlays.tick(app);
                    render();
                }
            });
            add(body, again, 6);
        }

        if (e.isText && !(e.view instanceof EditText)) {
            add(body, label("Name (text shown)", 13, TEXT, false), 12);
            final EditText box = new EditText(ctx);
            box.setSingleLine(true);
            box.setTextColor(TEXT);
            box.setTextSize(14);
            box.setText(r.name != null ? r.name : ((TextView) e.view).getText());
            add(body, box, 4);
            LinearLayout br = new LinearLayout(ctx);
            br.setOrientation(LinearLayout.HORIZONTAL);
            TextView set = chip("Set name", true);
            set.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String s = box.getText().toString();
                    r.name = s.length() == 0 ? null : s;
                    Config.saveLive(app);
                    Overlays.tick(app);
                    toast("Name set");
                }
            });
            TextView orig = chip("Original name", false);
            orig.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    r.name = null;
                    Config.saveLive(app);
                    Overlays.tick(app);
                    render();
                }
            });
            br.addView(set, chipLp());
            br.addView(orig, chipLp());
            add(body, br, 6);
        }

        final String iconKey = Overlays.iconKeyFor(e);
        if (iconKey != null) {
            add(body, label("Icon", 13, TEXT, false), 12);
            LinearLayout ir = new LinearLayout(ctx);
            ir.setOrientation(LinearLayout.HORIZONTAL);
            final Rules.Rule iRule = Rules.edit(iconKey);
            TextView rep = chip(iRule.icon == null ? "Replace icon (PNG)" : "Change icon (PNG)", true);
            rep.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pickIcon(iconKey);
                }
            });
            TextView orig = chip("Original icon", false);
            orig.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Rules.edit(iconKey).icon = null;
                    Config.saveLive(app);
                    Overlays.tick(app);
                    render();
                }
            });
            ir.addView(rep, chipLp());
            ir.addView(orig, chipLp());
            add(body, ir, 4);
            note(body, "Any PNG, any size: it is fitted into the place of the old icon and keeps its shape. "
                    + (iRule.icon != null ? "A picture is set now." : "The app's own icon is shown now."));
        }

        if (e.line) {
            final float dens = U.density(app);
            final float origPx = Overlays.originalStrokePx();
            int startT;
            if (Config.lineT > 0) startT = Config.lineT;
            else if (r.thick != Rules.NONE) startT = r.thick;
            else if (origPx > 0f) startT = Math.round(origPx / dens * 10f);
            else if ("canvas".equals(e.group)) startT = 15;
            else startT = Math.max(1, Math.round(Math.min(e.wDp, e.hDp) * 10f));
            // the lines that start at the origin must all be the same width: this one number is used by EVERY line
            tenthSlider(body, "Thickness (all lines from the origin)", 1, 200, U.clamp(startT, 1, 200), " dp", null,
                    true, new IntCb() {
                        @Override
                        public void on(int v) {
                            Config.lineT = v;
                            Rules.clearThick();
                        }
                    });
            lineChips(body);
            if (origPx > 0f) {
                note(body, "Original: the app draws this line " + (Math.round(origPx * 10f) / 10f) + " px wide = "
                        + (Math.round(origPx / dens * 100f) / 100f) + " dp on this phone. Go lower than that to make "
                        + "it thinner. 0.1 dp is the thinnest step; thinner than 1 pixel is drawn fainter, like a hairline.");
            } else {
                note(body, "Use the - 0.1 and + 0.1 buttons for exact steps. 0.5 dp is a hairline, 0.1 to 0.4 dp "
                        + "are even finer.");
            }
            note(body, "This number is shared: every line from the origin gets the same width, never just one of them.");
            TextView orT = chip("Original thickness", false);
            orT.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Config.lineT = 0;
                    Rules.clearThick();
                    Config.saveLive(app);
                    Overlays.tick(app);
                    render();
                }
            });
            add(body, orT, 6);
            lineExtras(body);
        } else if (e.root) {
            final int orW = Math.max(1, e.owDp);
            slider(body, "Size (width, original " + orW + " dp)", 4, Math.max(600, orW * 3),
                    r.w == Rules.NONE ? orW : r.w, " dp", "original", orW, new IntCb() {
                        @Override
                        public void on(int v) {
                            r.w = v == orW ? Rules.NONE : v;
                        }
                    });
        } else {
            final int orW = Math.max(1, e.owDp);
            final int orH = Math.max(1, e.ohDp);
            slider(body, "Width (original " + orW + " dp)", 2, Math.max(500, orW * 3),
                    r.w == Rules.NONE ? orW : r.w, " dp", "original", orW, new IntCb() {
                        @Override
                        public void on(int v) {
                            r.w = v == orW ? Rules.NONE : v;
                        }
                    });
            slider(body, "Height (original " + orH + " dp)", 2, Math.max(500, orH * 3),
                    r.h == Rules.NONE ? orH : r.h, " dp", "original", orH, new IntCb() {
                        @Override
                        public void on(int v) {
                            r.h = v == orH ? Rules.NONE : v;
                        }
                    });
        }
        if (e.isText && e.otDp > 0) {
            final int orT = e.otDp;
            slider(body, "Text size (original " + orT + " dp)", 4, Math.max(60, orT * 3),
                    r.text == Rules.NONE ? orT : r.text, " dp", "original", orT, new IntCb() {
                        @Override
                        public void on(int v) {
                            r.text = v == orT ? Rules.NONE : v;
                        }
                    });
        }
        slider(body, "Opacity", 10, 100, r.alpha == Rules.NONE ? 100 : r.alpha, "%", "original", new IntCb() {
            @Override
            public void on(int v) {
                r.alpha = v >= 100 ? Rules.NONE : Math.max(10, v);
            }
        });
        if (e.isText) {
            colorRow(body, "Text colour", r.textColor, true, new IntCb() {
                @Override
                public void on(int v) {
                    r.textColor = v == Rules.NONE ? Rules.NONE : (v | 0xFF000000);
                }
            });
        }
        colorRow(body, e.isImage ? "Icon colour" : "Background colour", r.bgColor, true, new IntCb() {
            @Override
            public void on(int v) {
                r.bgColor = v == Rules.NONE ? Rules.NONE : (v | 0xFF000000);
            }
        });

        CheckBox quiet = new CheckBox(ctx);
        quiet.setText("Sound of this button: volume 0");
        quiet.setTextColor(TEXT);
        quiet.setChecked(r.quiet);
        quiet.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                r.quiet = on;
                Config.saveLive(app);
                Overlays.tick(app);
            }
        });
        add(body, quiet, 10);
        note(body, "Finds the code that plays this button's sound (MediaPlayer, ToneGenerator) and sets its volume to "
                + "zero. A sound it cannot reach that way (a SoundPool kept elsewhere) is muted only while you touch "
                + "the button.");

        CheckBox manual = new CheckBox(ctx);
        manual.setText("Auto-off timer: never (button stays manual)");
        manual.setTextColor(TEXT);
        manual.setChecked(r.manual);
        manual.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                r.manual = on;
                Config.saveLive(app);
                Overlays.tick(app);
            }
        });
        add(body, manual, 10);
        note(body, "For a button that switches itself off a few seconds after you tap it (and shows a 3 2 1 count): "
                + "after each tap, every delayed job the app starts for that is taken out again, so the button only "
                + "changes when YOU press it. The count text on it is hidden. Only the app's own delayed jobs of 0.3 "
                + "to 6 seconds that start after your tap are touched. A timer kept in another thread "
                + "(java.util.Timer, Thread.sleep) cannot be reached from here: then use the patch card "
                + "\"Button that turns itself off, and its beep\" in the Live Editor app.");

        CheckBox hide = new CheckBox(ctx);
        hide.setText("Remove this item (hidden, app keeps working)");
        hide.setTextColor(TEXT);
        hide.setChecked(r.hide);
        hide.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                r.hide = on;
                Config.saveLive(app);
                Overlays.tick(app);
            }
        });
        add(body, hide, 10);

        if (e.root) {
            add(body, label("Treat this window as", 13, TEXT, false), 8);
            LinearLayout kr = new LinearLayout(ctx);
            kr.setOrientation(LinearLayout.HORIZONTAL);
            final String[] kinds = {null, "menu", "button", "icon", "line"};
            String[] kn = {"Auto", "Menu", "Button", "Icon", "Line"};
            for (int i = 0; i < kinds.length; i++) {
                final String k = kinds[i];
                TextView c = chip(kn[i], (r.kind == null && k == null) || (k != null && k.equals(r.kind)));
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        r.kind = k;
                        Config.saveLive(app);
                        Overlays.tick(app);
                        render();
                    }
                });
                kr.addView(c, chipLp());
            }
            add(body, kr, 4);
        }

        saveButton(body, "this item");
        TextView reset = chip("Reset this item", false);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Rules.Rule x = Rules.edit(e.o.key);
                x.kind = null;
                x.w = Rules.NONE;
                x.h = Rules.NONE;
                x.alpha = Rules.NONE;
                x.text = Rules.NONE;
                x.textColor = Rules.NONE;
                x.bgColor = Rules.NONE;
                x.thick = Rules.NONE;
                x.name = null;
                x.hide = false;
                x.quiet = false;
                x.manual = false;
                x.icon = null;
                String ik2 = Overlays.iconKeyFor(e);
                if (ik2 != null) Rules.edit(ik2).icon = null;
                Config.saveLive(app);
                Overlays.tick(app);
                render();
            }
        });
        add(body, reset, 14);
    }

    /** A clear, explicit "Save" for whatever is being edited on this screen: changes already apply at once; this just confirms them and gives a visible "Saved" message. */
    private void saveButton(LinearLayout parent, final String what) {
        TextView save = chip("\uD83D\uDCBE Save " + what, true);
        save.setTextSize(14);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Config.saveLive(app);
                Overlays.tick(app);
                toast("Saved");
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(16);
        save.setGravity(Gravity.CENTER);
        parent.addView(save, lp);
    }

    private void group(String title, final String kind, int dpNow, int alpha, int textDp, final int which) {
        add(body, label(title, 14, ACC, true), which == 0 ? 4 : 18);
        final int orig = Overlays.originalWidthDp(app, kind);
        final int def = which == 0 ? 48 : (which == 1 ? 56 : 300);
        int start = dpNow > 0 ? dpNow : (orig > 0 ? orig : def);
        int max = which == 2 ? 900 : (which == 1 ? 400 : 300);
        String head = orig > 0 ? "Size, width in dp (original " + orig + " dp)" : "Size, width in dp";
        slider(body, head, 8, max, U.clamp(start, 8, max), " dp", "original", orig > 0 ? orig : -1,
                new IntCb() {
                    @Override
                    public void on(int v) {
                        int dpv = (orig > 0 && v == orig) ? 0 : v;
                        if (which == 0) {
                            Config.iconDp = dpv;
                            Config.iconPct = 100;
                        } else if (which == 1) {
                            Config.btnDp = dpv;
                            Config.btnPct = 100;
                        } else {
                            Config.menuDp = dpv;
                            Config.menuPct = 100;
                        }
                    }
                });
        if (orig <= 0) {
            note(body, "The original size shows here once this window has been on screen (open it, then tap the "
                    + "refresh in the Items tab).");
        }
        slider(body, "Opacity", 10, 100, alpha, "%", null, new IntCb() {
            @Override
            public void on(int v) {
                if (which == 0) Config.iconAlpha = v;
                else if (which == 1) Config.btnAlpha = v;
                else Config.menuAlpha = v;
            }
        });
        slider(body, "Text size change", -10, 30, textDp, "\u00B1 dp", "original", 0, new IntCb() {
            @Override
            public void on(int v) {
                if (which == 0) {
                    Config.iconTextDp = v;
                    Config.iconTextPct = 100;
                } else if (which == 1) {
                    Config.btnTextDp = v;
                    Config.btnTextPct = 100;
                } else {
                    Config.menuTextDp = v;
                    Config.menuTextPct = 100;
                }
            }
        });
    }

    private void renderGlobal() {
        group("Menu icon (the button that opens the menu)", "icon", Config.iconDp, Config.iconAlpha,
                Config.iconTextDp, 0);
        group("Floating buttons (the on / off buttons that appear)", "button", Config.btnDp, Config.btnAlpha,
                Config.btnTextDp, 1);
        group("Menu panels", "menu", Config.menuDp, Config.menuAlpha, Config.menuTextDp, 2);
        add(body, label("Lines", 14, ACC, true), 18);
        tenthSlider(body, "Thickness (all line overlays)", 0, 200, Config.lineT, " dp", "original", true,
                new IntCb() {
                    @Override
                    public void on(int v) {
                        Config.lineT = v;
                        Rules.clearThick();
                    }
                });
        lineChips(body);
        float op = Overlays.originalStrokePx();
        if (op > 0f) {
            note(body, "Original line: " + (Math.round(op * 10f) / 10f) + " px = "
                    + (Math.round(op / U.density(app) * 100f) / 100f) + " dp on this phone.");
        }
        lineExtras(body);
        saveButton(body, "these sizes");
        note(body, "Sizes are in dp: the number is the width every window of that group gets (the height follows). "
                + "Text size change adds or removes dp on every text of the group. Line thickness goes down to 0.1 dp "
                + "with the - 0.1 / + 0.1 buttons. For one single item use the Items tab. "
                + "The first small floating window of the app is taken as the menu icon; change it in Items > Treat as.");
    }

    /** Every window of the app, with a switch to keep or remove it. Removed = hidden and untouchable, never deleted. */
    private void renderWindows() {
        TextView rf = chip("\u21BB Refresh", false);
        rf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                render();
            }
        });
        body.addView(rf);
        List<Overlays.Win> all = Overlays.windows(app);
        for (int i = 0; i < all.size(); i++) {
            final Overlays.Win w = all.get(i);
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            GradientDrawable g = new GradientDrawable();
            g.setColor(CARD);
            g.setCornerRadius(dp(10));
            row.setBackground(g);
            // a small picture of the window, so it is clear which one it is
            android.widget.ImageView pic = new android.widget.ImageView(ctx);
            pic.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
            GradientDrawable pg = new GradientDrawable();
            pg.setColor(0xFF22253F);
            pg.setCornerRadius(dp(8));
            pic.setBackground(pg);
            pic.setPadding(dp(3), dp(3), dp(3), dp(3));
            if (w.thumb != null) pic.setImageBitmap(w.thumb);
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(78), dp(78));
            pl.rightMargin = dp(10);
            row.addView(pic, pl);
            LinearLayout col = new LinearLayout(ctx);
            col.setOrientation(LinearLayout.VERTICAL);
            row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            col.addView(label(w.name, 14, TEXT, true));
            col.addView(label(w.sub, 11, SUB, false));
            if (!w.locked && w.unsafe) {
                col.addView(label("Kept visible: removing it closed the app before.", 11.5f, SUB, false));
            } else if (!w.locked && w.unsafeShow) {
                col.addView(label("Kept removed: bringing it back closed the app before.", 11.5f, SUB, false));
            } else if (!w.locked) {
                CheckBox keep = new CheckBox(ctx);
                keep.setText("Keep this interface");
                keep.setTextColor(TEXT);
                keep.setChecked(!w.gone);
                keep.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton b, boolean on) {
                        try {
                            Rules.edit(w.o.key).hide = !on;
                            Config.saveLive(app);
                            Overlays.tick(app);
                        } catch (Throwable t) {
                            U.err("keep switch", t);
                            Rules.edit(w.o.key).hide = false;
                            toast("That interface could not be bypassed, it stays visible.");
                        }
                    }
                });
                col.addView(keep);
            }
            add(body, row, 6);
        }
        if (all.isEmpty()) {
            note(body, "No window found yet. Open the menus and popups of the app once, then tap Refresh.");
        } else {
            note(body, "Every menu, floating button, popup, dialog and screen the app has shown is listed here, "
                    + "visible or not, so you can remove any of them. Untick one to bypass it: it is not closed or "
                    + "detached, it just becomes fully transparent and untouchable with every touch passing straight "
                    + "to the app under it, so the app itself never notices this happened and cannot crash from it. "
                    + "The main screen cannot be removed. Popups that are closed right now stay in this list; tick "
                    + "Keep to bring one back. As an extra safety net: if the app ever closes right after a window "
                    + "was removed OR right after one was brought back, that exact change is undone and never tried "
                    + "again by itself. To remove a whole part of the app's own code (service, screen, permission) "
                    + "use the Live Editor patch options, not this list.");
        }
        if (HideGuard.unsafeCount() + EditGuard.count() > 0) {
            TextView fg = chip("Allow changing the frozen windows and edits again", false);
            fg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    HideGuard.forgetAll();
                    EditGuard.forgetAll();
                    toast("Done. Those windows can be changed again.");
                    render();
                }
            });
            add(body, fg, 12);
        }
    }

    private void renderTheme() {
        CheckBox on = new CheckBox(ctx);
        on.setText("Apply theme to the whole app");
        on.setTextColor(TEXT);
        on.setChecked(Config.themeOn);
        on.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Config.themeOn = v;
                Config.saveLive(app);
                Overlays.tick(app);
            }
        });
        body.addView(on);
        add(body, label("Ready-made", 13, SUB, false), 8);
        LinearLayout pr = new LinearLayout(ctx);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(ctx);
        for (int i = 0; i < PRESET_NAMES.length; i++) {
            final int[] pv = PRESETS[i];
            TextView c = chip(PRESET_NAMES[i], false);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Config.themeOn = true;
                    Config.themeBg = pv[0];
                    Config.themeText = pv[1];
                    Config.themeAccent = pv[2];
                    Config.saveLive(app);
                    Overlays.tick(app);
                    render();
                }
            });
            pr.addView(c, chipLp());
        }
        hs.addView(pr);
        add(body, hs, 4);
        colorRow(body, "Background", Config.themeBg, false, new IntCb() {
            @Override
            public void on(int v) {
                Config.themeBg = v | 0xFF000000;
                Config.themeOn = true;
            }
        });
        colorRow(body, "Text", Config.themeText, false, new IntCb() {
            @Override
            public void on(int v) {
                Config.themeText = v | 0xFF000000;
                Config.themeOn = true;
            }
        });
        colorRow(body, "Buttons (accent)", Config.themeAccent, false, new IntCb() {
            @Override
            public void on(int v) {
                Config.themeAccent = v | 0xFF000000;
                Config.themeOn = true;
            }
        });
        saveButton(body, "theme");
        note(body, "The theme repaints backgrounds, texts and buttons of the app screens and overlays. "
                + "Pictures stay as they are. A colour set on a single item (Items tab) wins over the theme.");
    }

    private void renderMore() {
        TextView copy = chip("Copy settings (to make a normal APK)", true);
        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ClipboardManager cm = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("Live Editor settings", Config.exportJson()));
                    toast("Settings copied. Open the Live Editor app, choose \"Convert live APK to normal\", "
                            + "pick this app, then tap \"Paste settings\".");
                } catch (Throwable t) {
                    toast("Could not copy: " + t);
                }
            }
        });
        add(body, copy, 6);
        note(body, "All sizes, colours, names, hidden items and the theme you set here are copied as text. "
                + "In the Live Editor app they are baked into a normal APK without this pencil.");
        TextView rep = chip("Copy report for Claude", false);
        rep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    StringBuilder b = new StringBuilder("LIVE EDITOR REPORT\napp: " + app.getPackageName()
                            + "\n\nWINDOWS:\n");
                    List<Overlays.Win> ws = Overlays.windows(app);
                    for (int i = 0; i < ws.size(); i++) {
                        b.append(ws.get(i).kind).append(" | ").append(ws.get(i).name).append(ws.get(i).gone
                                ? " | removed" : "").append("\n");
                    }
                    b.append("\nITEMS:\n");
                    List<Overlays.El> els = Overlays.collect(app);
                    for (int i = 0; i < els.size() && i < 80; i++) {
                        b.append(els.get(i).group).append(" | ").append(els.get(i).name).append(" | ")
                                .append(els.get(i).sub).append("\n");
                    }
                    b.append("\nSETTINGS JSON:\n").append(Config.exportJson()).append("\n");
                    ClipboardManager cm = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("Live Editor report", b.toString()));
                    toast("Report copied. Paste it to Claude and say what to change.");
                } catch (Throwable t) {
                    toast("Could not copy: " + t);
                }
            }
        });
        add(body, rep, 14);
        TextView paste = chip("Paste changes here (from Claude)", true);
        paste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ClipboardManager cm = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
                    CharSequence cs = (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0)
                            ? cm.getPrimaryClip().getItemAt(0).coerceToText(app) : null;
                    if (cs == null) {
                        toast("Nothing to paste.");
                        return;
                    }
                    String why = Config.importPasted(app, cs.toString());
                    if (why.length() == 0) {
                        Overlays.tick(app);
                        toast("Changes applied");
                        render();
                    } else {
                        toast("Could not apply: " + why);
                    }
                } catch (Throwable t) {
                    toast("Could not paste: " + t);
                }
            }
        });
        add(body, paste, 8);
        note(body, "Copy report, send it to Claude, say what to change, copy the answer and paste it here. "
                + "The edits apply at once and are kept.");
        TextView reset = chip("Reset all edits", false);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Rules.resetAll();
                Config.resetLook();
                Config.themeOn = false;
                Config.saveLive(app);
                Overlays.tick(app);
                toast("All edits reset");
                render();
            }
        });
        add(body, reset, 16);
        note(body, "Drag the \u270E handle to move it. Tap it to open or close this panel.");
    }
}
