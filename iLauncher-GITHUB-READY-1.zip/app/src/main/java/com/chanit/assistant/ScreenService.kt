package com.chanit.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Screen control by voice: home/back/recents/screenshot/lock, scroll, tap buttons by name. */
class ScreenService : AccessibilityService() {

    companion object {
        @Volatile var instance: ScreenService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(action: Int): Boolean = performGlobalAction(action)

    /** Taps the first clickable node whose text / description / view id contains one of the keys. */
    fun clickText(vararg keys: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return findClick(root, keys.map { it.lowercase() })
    }

    private fun findClick(n: AccessibilityNodeInfo?, keys: List<String>): Boolean {
        if (n == null) return false
        val low = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "") + " " +
            (n.viewIdResourceName ?: "")).lowercase()
        if (keys.any { low.contains(it) }) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                x = x.parent
            }
        }
        for (i in 0 until n.childCount) {
            if (findClick(n.getChild(i), keys)) return true
        }
        return false
    }

    /** down = see content further down the page (finger swipes up) */
    fun scroll(down: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val y1 = dm.heightPixels * (if (down) 0.7f else 0.3f)
        val y2 = dm.heightPixels * (if (down) 0.3f else 0.7f)
        val path = Path()
        path.moveTo(x, y1)
        path.lineTo(x, y2)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        dispatchGesture(g, null, null)
    }
}
