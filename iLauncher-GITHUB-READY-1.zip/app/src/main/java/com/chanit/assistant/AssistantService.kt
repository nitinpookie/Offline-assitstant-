package com.chanit.assistant

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.util.Locale
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.Executors

private const val S_WAKE = 0
private const val S_CMD = 1
private const val S_THINK = 2
private const val S_SPEAK = 3

private class Cand(val text: String, val score: Double, val hindi: Boolean)

/**
 * Always-listening foreground service.
 * wake phrase -> command (Hindi + English heard together, best one wins) -> action -> spoken reply (offline TTS).
 * While it speaks, "stop" or the wake phrase interrupts it.
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "com.chanit.assistant.STOP"
        const val ACTION_LISTEN_NOW = "com.chanit.assistant.LISTEN_NOW"
        @Volatile var running = false
        @Volatile var instance: AssistantService? = null
        val panels = CopyOnWriteArraySet<OrbPanel>()

        private val STOP_EN = listOf("stop", "quiet", "silence", "enough", "shut up", "cancel")
        private val STOP_HI = listOf("रुको", "रुक", "बस", "चुप", "बंद", "स्टॉप", "रुकिए")

        fun listenNow(c: Context) {
            val s = instance
            if (s != null) {
                s.listenRequested = true
                return
            }
            try {
                c.startForegroundService(Intent(c, AssistantService::class.java).setAction(ACTION_LISTEN_NOW))
            } catch (_: Throwable) {}
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val tone by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 80) }
    private lateinit var llm: LlmEngine
    private lateinit var commands: Commands

    @Volatile private var alive = false
    @Volatile private var state = S_WAKE
    @Volatile private var resetAsr = false
    @Volatile var listenRequested = false
    @Volatile private var follow = false
    @Volatile private var pendingFollow = false
    @Volatile private var ttsReady = false
    @Volatile private var uiState = 0
    @Volatile private var lastHindi = false
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var overlayPanel: OrbPanel? = null
    private var wakes: List<String> = emptyList()
    private var wakeLabel = "hey"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        llm = LlmEngine(applicationContext)
        commands = Commands(applicationContext, llm)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("assistant", "Assistant", NotificationManager.IMPORTANCE_LOW))
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { if (utteranceId == "reply") afterSpeech() }
                override fun onError(utteranceId: String?) {
                    if (utteranceId != "filler") {
                        try { tts?.stop() } catch (_: Throwable) {}
                        afterSpeech()
                    }
                }
            })
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val n = buildNotification("Starting…")
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Throwable) {
            Alerts.promptStart(this)
            stopSelf()
            return START_NOT_STICKY
        }
        instance = this
        running = true
        if (intent?.action == ACTION_LISTEN_NOW) listenRequested = true
        if (!alive) {
            alive = true
            try {
                val pm = getSystemService(PowerManager::class.java)
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "chanit:listen")
                wakeLock?.acquire()
            } catch (_: Throwable) {}
            Thread { loop() }.start()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        running = false
        instance = null
        main.post { removeOverlay() }
        try { tts?.shutdown() } catch (_: Throwable) {}
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Throwable) {}
        llm.close()
        exec.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ audio loop
    private fun parse(json: String, hindi: Boolean): Cand {
        val o = JSONObject(json)
        val text = o.optString("text").trim()
        var score = 0.0
        val arr = o.optJSONArray("result")
        if (arr != null) {
            for (i in 0 until arr.length()) score += arr.getJSONObject(i).optDouble("conf", 0.5)
        }
        return Cand(text, score, hindi)
    }

    private fun loop() {
        val closers = ArrayList<AutoCloseable>()
        var recHolder: AudioRecord? = null
        try {
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            val prefs = Store.prefs(this)
            val mode = Store.mode(this)
            wakes = Store.wakeList(this)
            wakeLabel = wakes.firstOrNull() ?: "hey"
            lastHindi = mode == "hi"

            val en = Model(ModelStore.dir(this, "en").absolutePath)
            closers.add(en)
            val hi: Model? = if (mode != "en" && ModelStore.ready(this, "hi")) {
                val m = Model(ModelStore.dir(this, "hi").absolutePath)
                closers.add(m)
                m
            } else null
            val useHi = hi != null
            val useEn = mode != "hi" || !useHi

            val wakeRec = Recognizer(en, 16000.0f, JSONArray(wakes + "[unk]").toString())
            closers.add(wakeRec)
            val enRec: Recognizer? = if (useEn) {
                val r = Recognizer(en, 16000.0f); r.setWords(true); closers.add(r); r
            } else null
            val hiRec: Recognizer? = if (useHi) {
                val r = Recognizer(hi!!, 16000.0f); r.setWords(true); closers.add(r); r
            } else null
            val stopEn = Recognizer(en, 16000.0f, JSONArray(STOP_EN + wakes + "[unk]").toString())
            closers.add(stopEn)
            val stopHi: Recognizer? = if (hi != null) {
                val r = Recognizer(hi, 16000.0f, JSONArray(STOP_HI + "[unk]").toString()); closers.add(r); r
            } else null

            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val ar = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16000) * 2
            )
            recHolder = ar
            if (ar.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Microphone not available")
            try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(ar.audioSessionId)?.setEnabled(true) } catch (_: Throwable) {}
            try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(ar.audioSessionId)?.setEnabled(true) } catch (_: Throwable) {}
            ar.startRecording()
            setStatus("Say \"$wakeLabel\"")

            val buf = ShortArray(1600)
            var t0 = 0L
            var heard = false
            var firstLimit = 7000L
            var checked = false
            val startT = System.currentTimeMillis()

            fun toWake() {
                state = S_WAKE
                resetAsr = true
                ui(0, null)
                setStatus("Say \"$wakeLabel\"")
            }

            fun enterCmd(fu: Boolean) {
                wakeRec.reset(); enRec?.reset(); hiRec?.reset()
                t0 = System.currentTimeMillis()
                heard = false
                firstLimit = if (fu) 8000L else 7000L
                state = S_CMD
                if (!fu) {
                    try { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120) } catch (_: Throwable) {}
                }
                ui(1, null)
                setStatus("Listening…")
            }

            while (alive) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) continue

                if (!checked && System.currentTimeMillis() - startT > 1500) {
                    checked = true
                    if (Build.VERSION.SDK_INT >= 29 && ar.activeRecordingConfiguration?.isClientSilenced == true) {
                        Alerts.promptStart(this)
                        throw IllegalStateException("Android blocked the mic in background. Tap the notification to start.")
                    }
                }

                if (resetAsr) {
                    resetAsr = false
                    wakeRec.reset(); enRec?.reset(); hiRec?.reset(); stopEn.reset(); stopHi?.reset()
                }
                val locked = isLocked()
                val lockOff = prefs.getString("lock_mode", "calls") == "off"

                if (state == S_WAKE) {
                    if (pendingFollow) {
                        pendingFollow = false
                        enterCmd(true)
                        continue
                    }
                    if (listenRequested) {
                        listenRequested = false
                        if (locked && lockOff) continue
                        enterCmd(false)
                        continue
                    }
                }

                when (state) {
                    S_WAKE -> {
                        val done = wakeRec.acceptWaveForm(buf, n)
                        val txt = if (done) JSONObject(wakeRec.result).optString("text")
                        else JSONObject(wakeRec.partialResult).optString("partial")
                        if (txt.isNotEmpty() && wakes.any { txt.contains(it) }) {
                            if (locked && lockOff) {
                                wakeRec.reset()
                            } else {
                                enterCmd(false)
                            }
                        }
                    }
                    S_CMD -> {
                        levelOf(buf, n)
                        val dEn = enRec?.acceptWaveForm(buf, n) ?: false
                        val dHi = hiRec?.acceptWaveForm(buf, n) ?: false
                        val age = System.currentTimeMillis() - t0
                        val finish = dEn || dHi || age > 15000
                        if (!finish) {
                            val pe = enRec?.let { JSONObject(it.partialResult).optString("partial") } ?: ""
                            val ph = hiRec?.let { JSONObject(it.partialResult).optString("partial") } ?: ""
                            val part = if (pe.length >= ph.length) pe else ph
                            if (part.isNotEmpty()) {
                                heard = true
                                ui(1, part)
                            } else if (!heard && age > firstLimit) {
                                toWake()
                            }
                        } else {
                            val cands = ArrayList<Cand>()
                            enRec?.let { cands.add(parse(if (dEn) it.result else it.finalResult, false)) }
                            hiRec?.let { cands.add(parse(if (dHi) it.result else it.finalResult, true)) }
                            enRec?.reset(); hiRec?.reset()
                            val best = cands.filter { it.text.isNotEmpty() }.maxByOrNull { it.score }
                            if (best != null) {
                                process(best.text, best.hindi, locked)
                            } else if (age > firstLimit) {
                                toWake()
                            }
                        }
                    }
                    S_SPEAK -> {
                        val de = stopEn.acceptWaveForm(buf, n)
                        val pe = if (de) JSONObject(stopEn.result).optString("text")
                        else JSONObject(stopEn.partialResult).optString("partial")
                        var ph = ""
                        if (stopHi != null) {
                            val dh = stopHi.acceptWaveForm(buf, n)
                            ph = if (dh) JSONObject(stopHi.result).optString("text")
                            else JSONObject(stopHi.partialResult).optString("partial")
                        }
                        val wakeHit = pe.isNotEmpty() && wakes.any { pe.contains(it) }
                        val stopHit = (pe.isNotEmpty() && STOP_EN.any { pe.contains(it) }) ||
                            (ph.isNotEmpty() && STOP_HI.any { ph.contains(it) })
                        if (wakeHit || stopHit) {
                            try { tts?.stop() } catch (_: Throwable) {}
                            follow = false
                            pendingFollow = false
                            resetAsr = true
                            if (wakeHit) enterCmd(false) else toWake()
                        }
                    }
                    else -> {}   // thinking: ignore audio
                }
            }
        } catch (e: Throwable) {
            val msg = e.message ?: e.toString()
            main.post { Toast.makeText(this, "Assistant error: $msg", Toast.LENGTH_LONG).show() }
        } finally {
            try { recHolder?.stop() } catch (_: Throwable) {}
            try { recHolder?.release() } catch (_: Throwable) {}
            for (cl in closers) { try { cl.close() } catch (_: Throwable) {} }
            alive = false
            main.post { stopSelf() }
        }
    }

    // ------------------------------------------------------------------ commands + speech
    private fun isLocked(): Boolean =
        try { getSystemService(KeyguardManager::class.java).isKeyguardLocked } catch (_: Throwable) { false }

    private fun process(text: String, hindi: Boolean, locked: Boolean) {
        state = S_THINK
        lastHindi = hindi
        ui(2, "“$text”")
        setStatus("Heard: $text")
        // natural "hmm…" if the answer takes a moment (AI questions)
        val filler = Runnable {
            val t = tts
            if (state == S_THINK && ttsReady && t != null) {
                Speech.apply(t, this, hindi)
                Speech.say(t, this, if (hindi) "हम्म…" else "Hmm…", "filler")
            }
        }
        if (Store.prefs(this).getBoolean("tts_hmm", true) && !locked) main.postDelayed(filler, 900)
        exec.execute {
            val reply = try {
                commands.handle(text, hindi, locked)
            } catch (e: Throwable) {
                Reply(if (hindi) "कुछ गड़बड़ हो गई।" else "Something went wrong.")
            }
            main.removeCallbacks(filler)
            speak(reply, hindi)
        }
    }

    private fun speak(reply: Reply, hindi: Boolean) {
        follow = reply.follow
        ui(3, reply.text)
        val t = tts
        if (!ttsReady || t == null) {
            afterSpeech()
            return
        }
        val res = Speech.apply(t, this, hindi)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            main.post {
                Toast.makeText(this, "Install the offline voice for this language in phone Text-to-speech settings", Toast.LENGTH_LONG).show()
            }
        }
        state = S_SPEAK
        Speech.say(t, this, reply.text, "reply")
    }

    private fun afterSpeech() {
        resetAsr = true
        pendingFollow = follow
        follow = false
        state = S_WAKE
        ui(if (pendingFollow) 1 else 0, null)
        if (!pendingFollow) setStatus("Say \"$wakeLabel\"")
    }

    /** reminders that fire while the service is idle */
    fun sayReminder(text: String) {
        if (state != S_WAKE) return
        exec.execute { speak(Reply((if (lastHindi) "याद दिलाना: " else "Reminder: ") + text), lastHindi) }
    }

    private fun levelOf(buf: ShortArray, n: Int) {
        var s = 0.0
        for (i in 0 until n) {
            val v = buf[i] / 32768.0
            s += v * v
        }
        val l = (Math.sqrt(s / n).toFloat() * 7f).coerceAtMost(1f)
        main.post { for (p in panels) p.level(l) }
    }

    // ------------------------------------------------------------------ UI
    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, AssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "assistant")
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Chanit Assistant")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    private fun setStatus(text: String) {
        try { getSystemService(NotificationManager::class.java).notify(1, buildNotification(text)) } catch (_: Throwable) {}
    }

    /** state: 0 idle, 1 listening, 2 thinking, 3 speaking */
    private fun ui(state: Int, text: String?) {
        uiState = state
        main.post {
            if (state != 0 && overlayPanel == null && panels.isEmpty()) addOverlay()
            for (p in panels) p.update(state, text)
            if (state == 0) main.postDelayed({ if (uiState == 0) removeOverlay() }, 1200)
        }
    }

    private fun addOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val p = OrbPanel(this)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.y = 140
            getSystemService(WindowManager::class.java).addView(p, lp)
            overlayPanel = p
            panels.add(p)
        } catch (_: Throwable) {}
    }

    private fun removeOverlay() {
        val p = overlayPanel ?: return
        panels.remove(p)
        try { getSystemService(WindowManager::class.java).removeView(p) } catch (_: Throwable) {}
        overlayPanel = null
    }
}
