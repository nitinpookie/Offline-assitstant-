package com.chanit.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.sin

/** Siri-like orb. state: 0 idle, 1 listening, 2 thinking, 3 speaking */
class OrbView(ctx: Context) : View(ctx) {
    var state = 0
    var level = 0f
    private var phase = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = (120 * resources.displayMetrics.density).toInt()
        setMeasuredDimension(s, s)
    }

    private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val col = when (state) {
            1 -> 0xFF22D3EE.toInt()
            2 -> 0xFFA855F7.toInt()
            3 -> 0xFFFF6BA8.toInt()
            else -> 0xFF5B7CFF.toInt()
        }
        val t = (phase * 2 * PI).toFloat()
        val pulse = when (state) {
            1 -> 1f + level.coerceIn(0f, 1f) * 1.3f
            3 -> 1f + 0.14f * sin(t * 2)
            2 -> 1f
            else -> 1f + 0.05f * sin(t)
        }
        val r = width * 0.2f * pulse

        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, r * 2.3f, intArrayOf(alpha(col, 130), alpha(col, 0)), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * 2.3f, paint)

        paint.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.3f, intArrayOf(Color.WHITE, col), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r, paint)
        paint.shader = null

        if (state == 2) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = width * 0.035f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.WHITE
            rect.set(cx - r * 1.5f, cy - r * 1.5f, cx + r * 1.5f, cy + r * 1.5f)
            for (i in 0 until 3) canvas.drawArc(rect, phase * 360f + i * 120f, 60f, false, paint)
        }
    }
}

class OrbPanel(ctx: Context) : LinearLayout(ctx) {
    val orb = OrbView(ctx)
    private val label = TextView(ctx)
    var onIdle: (() -> Unit)? = null

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        addView(orb)
        label.setTextColor(Color.WHITE)
        label.textSize = 16f
        label.gravity = Gravity.CENTER
        label.setPadding(44, 22, 44, 22)
        label.maxWidth = (resources.displayMetrics.widthPixels * 0.88).toInt()
        val bg = GradientDrawable()
        bg.setColor(0xCC141428.toInt())
        bg.cornerRadius = 60f
        label.background = bg
        label.visibility = View.GONE
        addView(label)
    }

    fun update(state: Int, text: String?) {
        orb.state = state
        if (text.isNullOrEmpty()) {
            label.visibility = View.GONE
        } else {
            label.text = text
            label.visibility = View.VISIBLE
        }
        if (state == 0) onIdle?.invoke()
    }

    fun level(l: Float) {
        orb.level = orb.level * 0.6f + l * 0.4f
    }
}
