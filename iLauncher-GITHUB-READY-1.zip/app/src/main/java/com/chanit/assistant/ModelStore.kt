package com.chanit.assistant

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the Vosk speech models once. After that everything is offline. */
object ModelStore {
    private const val EN = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val HI = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"

    fun dir(c: Context, lang: String) = File(c.filesDir, "vosk-$lang")
    fun ready(c: Context, lang: String) = File(dir(c, lang), "am").isDirectory

    fun download(c: Context, lang: String, onProgress: (Int) -> Unit) {
        val tmp = File(c.filesDir, "vosk-$lang.tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()

        val conn = URL(if (lang == "hi") HI else EN).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        val total = conn.contentLengthLong.coerceAtLeast(1L)
        var got = 0L
        var last = -1

        val counting = object : FilterInputStream(conn.inputStream) {
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                val n = super.read(b, off, len)
                if (n > 0) {
                    got += n
                    val p = (got * 100 / total).toInt().coerceAtMost(100)
                    if (p != last) {
                        last = p
                        onProgress(p)
                    }
                }
                return n
            }
        }

        ZipInputStream(BufferedInputStream(counting)).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                // strip the top-level folder name inside the zip
                val rel = e.name.substringAfter('/', "")
                if (rel.isNotEmpty()) {
                    val f = File(tmp, rel)
                    if (!f.canonicalPath.startsWith(tmp.canonicalPath)) throw IOException("bad zip")
                    if (e.isDirectory) {
                        f.mkdirs()
                    } else {
                        f.parentFile?.mkdirs()
                        FileOutputStream(f).use { out -> zip.copyTo(out) }
                    }
                }
                e = zip.nextEntry
            }
        }

        val dst = dir(c, lang)
        dst.deleteRecursively()
        if (!tmp.renameTo(dst)) throw IOException("could not save model")
    }
}
