package com.chanit.assistant

import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import org.json.JSONArray
import org.json.JSONObject

object Alerts {
    /** "Tap to start" notification, used when Android blocks starting the mic service from the background */
    fun promptStart(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alerts", "Alerts", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(
            c, 7, Intent(c, StartActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "alerts")
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Assistant is off")
            .setContentText("Tap here to start listening")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(77, n)
    }
}

object Reminders {
    private fun arr(c: Context): JSONArray =
        try { JSONArray(Store.prefs(c).getString("reminders", "[]")) } catch (_: Exception) { JSONArray() }

    private fun save(c: Context, a: JSONArray) {
        Store.prefs(c).edit().putString("reminders", a.toString()).apply()
    }

    fun add(c: Context, whenMs: Long, text: String) {
        val id = (System.currentTimeMillis() % 1_000_000_000L).toInt()
        val a = arr(c)
        a.put(JSONObject().put("id", id).put("t", whenMs).put("x", text))
        save(c, a)
        schedule(c, id, whenMs, text)
    }

    fun remove(c: Context, id: Int) {
        val a = arr(c)
        val n = JSONArray()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getInt("id") != id) n.put(o)
        }
        save(c, n)
    }

    fun schedule(c: Context, id: Int, whenMs: Long, text: String) {
        val am = c.getSystemService(AlarmManager::class.java)
        val fire = PendingIntent.getBroadcast(
            c, id, Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        // setAlarmClock needs no special exact-alarm permission
        am.setAlarmClock(AlarmManager.AlarmClockInfo(whenMs, show), fire)
    }

    fun rescheduleAll(c: Context) {
        val a = arr(c)
        val now = System.currentTimeMillis()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getLong("t") > now) schedule(c, o.getInt("id"), o.getLong("t"), o.getString("x"))
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", 0)
        val text = i.getStringExtra("text") ?: return
        Reminders.remove(c, id)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("reminders", "Reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(
            1000 + (id % 1000),
            Notification.Builder(c, "reminders").setSmallIcon(R.drawable.ic_mic)
                .setContentTitle("Reminder").setContentText(text).setAutoCancel(true).build()
        )
        AssistantService.instance?.sayReminder(text)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Reminders.rescheduleAll(c)
        if (!Store.prefs(c).getBoolean("autostart", true)) return
        try {
            c.startForegroundService(Intent(c, AssistantService::class.java))
        } catch (e: Throwable) {
            Alerts.promptStart(c)
        }
    }
}

class SecretCodeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Invisible activity: lets Android start the mic service from a visible context (tile / notification) */
class StartActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { startForegroundService(Intent(this, AssistantService::class.java)) } catch (_: Throwable) {}
        finish()
    }
}

/** Quick Settings tile: 1 tap start/stop, also the way to start after a reboot */
class AssistTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.state = if (AssistantService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Assistant"
        t.updateTile()
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        if (AssistantService.running) {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
            refresh()
        } else {
            val i = Intent(this, StartActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
            } else {
                startActivityAndCollapse(i)
            }
        }
    }
}
