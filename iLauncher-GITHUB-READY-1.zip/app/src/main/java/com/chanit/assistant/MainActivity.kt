package com.chanit.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var trainedView: TextView
    private lateinit var startBtn: Button
    private lateinit var iconBtn: Button
    private lateinit var wakeEdit: EditText
    private val pickCode = 42
    private val prefs by lazy { Store.prefs(this) }
    private val modes = listOf("auto", "en", "hi")
    private var testTts: TextToSpeech? = null
    private var testReady = false
    private var testInit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        fun label(t: String, size: Float = 15f): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = size
            v.setPadding(0, pad / 2, 0, pad / 4)
            col.addView(v)
            return v
        }

        fun button(t: String, f: () -> Unit): Button {
            val b = Button(this)
            b.text = t
            b.isAllCaps = false
            b.setOnClickListener { f() }
            col.addView(b)
            return b
        }

        label("Chanit Assistant", 22f)
        status = label("")

        label("Language")
        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Auto (Hindi + English + Hinglish)", "English only", "हिन्दी only")
        )
        spin.setSelection(modes.indexOf(Store.mode(this)).coerceAtLeast(0))
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("lang", modes[pos]).apply()
                refresh()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        col.addView(spin)

        label("Wake phrases (comma separated, normal English words)")
        wakeEdit = EditText(this)
        wakeEdit.setSingleLine()
        wakeEdit.setText(prefs.getString("wake", Store.DEFAULT_WAKE))
        col.addView(wakeEdit)
        trainedView = label("")
        button("Train wake word (say it 3 times)") { train() }
        button("Clear trained phrases") {
            prefs.edit().remove("wake_trained").apply()
            refresh()
        }

        val auto = CheckBox(this)
        auto.text = "Try to start automatically after phone restart"
        auto.isChecked = prefs.getBoolean("autostart", true)
        auto.setOnCheckedChangeListener { _, b -> prefs.edit().putBoolean("autostart", b).apply() }
        col.addView(auto)

        val lock = CheckBox(this)
        lock.text = "Lock screen: allow calls only (untick = ignore everything while locked)"
        lock.isChecked = prefs.getString("lock_mode", "calls") != "off"
        lock.setOnCheckedChangeListener { _, b -> prefs.edit().putString("lock_mode", if (b) "calls" else "off").apply() }
        col.addView(lock)

        label("Setup", 18f)
        button("1. Allow permissions (mic, contacts, calls, SMS, notifications)") {
            val p = mutableListOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS
            )
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        button("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("3. Download voice models (one time, needs internet)") {
            val need = needed()
            if (need.isEmpty()) {
                status.text = "Voice models already downloaded."
                return@button
            }
            thread {
                try {
                    for (l in need) {
                        ModelStore.download(this@MainActivity, l) { p ->
                            runOnUiThread { status.text = "Downloading $l voice model… $p%" }
                        }
                    }
                    runOnUiThread { refresh() }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Download failed: ${e.message}\nCheck internet and try again." }
                }
            }
        }
        button("4. Add AI model file (.task / .bin) for questions") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            @Suppress("DEPRECATION")
            startActivityForResult(i, pickCode)
        }
        button("5. Keep running in background (battery)") {
            val pm = getSystemService(PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }
        button("6. Screen control: turn on Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("7. Brightness control: allow modify system settings") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        button("8. Set as Default digital assistant (power button)") {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                try { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) } catch (_: Exception) {}
            }
        }
        label("Voice (how I sound)", 18f)
        button("Choose English (India) voice") { pickVoice(false) }
        button("Choose Hindi voice") { pickVoice(true) }
        fun slider(name: String, key: String, min: Float, max: Float, def: Float, unit: String) {
            val tv = label("")
            val sb = SeekBar(this)
            sb.max = 100
            fun show(v: Float) { tv.text = name + ": " + "%.2f".format(v) + unit }
            val cur = prefs.getFloat(key, def)
            sb.progress = ((cur - min) / (max - min) * 100).toInt()
            show(cur)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = min + (max - min) * p / 100f
                    show(v)
                    if (fromUser) prefs.edit().putFloat(key, v).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(sb)
        }
        slider("Speed", "tts_rate", 0.5f, 1.5f, 1.0f, "x")
        slider("Pitch", "tts_pitch", 0.5f, 1.5f, 1.0f, "x")
        slider("Pause between sentences", "tts_pause", 0f, 800f, 250f, " ms")
        val hmm = CheckBox(this)
        hmm.text = "Say \"hmm…\" while thinking"
        hmm.isChecked = prefs.getBoolean("tts_hmm", true)
        hmm.setOnCheckedChangeListener { _, b -> prefs.edit().putBoolean("tts_hmm", b).apply() }
        col.addView(hmm)
        button("▶ Test English voice") { speakTest(false) }
        button("▶ Test Hindi voice") { speakTest(true) }

        button("My custom commands") { customDialog() }
        iconBtn = button("") { toggleIcon() }

        startBtn = button("Start assistant") {
            if (AssistantService.running) {
                startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_STOP))
            } else {
                prefs.edit().putString("wake", wakeEdit.text.toString().trim().ifEmpty { Store.DEFAULT_WAKE }).apply()
                if (needed().isNotEmpty()) {
                    status.text = "First download the voice models (step 3)."
                    return@button
                }
                if (!granted(Manifest.permission.RECORD_AUDIO)) {
                    status.text = "First allow permissions (step 1)."
                    return@button
                }
                startForegroundService(Intent(this, AssistantService::class.java))
            }
            col.postDelayed({ refresh() }, 700)
        }

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun mark(b: Boolean) = if (b) "✓" else "✗"

    private fun needed(): List<String> {
        val l = mutableListOf<String>()
        if (!ModelStore.ready(this, "en")) l.add("en")
        if (Store.mode(this) != "en" && !ModelStore.ready(this, "hi")) l.add("hi")
        return l
    }

    private fun iconCn() = ComponentName(this, "com.chanit.assistant.LauncherAlias")

    private fun iconVisible() =
        packageManager.getComponentEnabledSetting(iconCn()) != PackageManager.COMPONENT_ENABLED_STATE_DISABLED

    private fun toggleIcon() {
        val show = !iconVisible()
        packageManager.setComponentEnabledSetting(
            iconCn(),
            if (show) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        status.text = if (show) "Home screen icon is back." else
            "Icon hidden. To open this screen again: Settings > Apps > Chanit Assistant > App settings, " +
                "the Assistant tile in Quick Settings, or dial *#*#2580#*#*"
        refresh(keepStatus = true)
    }

    private fun refresh(keepStatus: Boolean = false) {
        if (!::status.isInitialized || !::startBtn.isInitialized) return
        val mode = Store.mode(this)
        val sb = StringBuilder()
        sb.append("Voice EN ").append(mark(ModelStore.ready(this, "en")))
        if (mode != "en") sb.append("   HI ").append(mark(ModelStore.ready(this, "hi")))
        sb.append("\nAI model (optional) ").append(mark(LlmEngine.modelFile(this) != null))
        sb.append("\nMic ").append(mark(granted(Manifest.permission.RECORD_AUDIO)))
        sb.append("  Contacts ").append(mark(granted(Manifest.permission.READ_CONTACTS)))
        sb.append("  Calls ").append(mark(granted(Manifest.permission.CALL_PHONE)))
        sb.append("  SMS ").append(mark(granted(Manifest.permission.SEND_SMS)))
        sb.append("\nOverlay ").append(mark(Settings.canDrawOverlays(this)))
        sb.append("  Accessibility ").append(mark(ScreenService.instance != null))
        sb.append("  Brightness ").append(mark(Settings.System.canWrite(this)))
        sb.append("\nAssistant: ").append(if (AssistantService.running) "RUNNING" else "stopped")
        if (!keepStatus) status.text = sb.toString()
        val tr = (prefs.getString("wake_trained", "") ?: "").split("|").filter { it.isNotEmpty() }
        trainedView.text = if (tr.isEmpty()) "Trained phrases: none yet" else "Trained phrases: " + tr.joinToString(" | ")
        startBtn.text = if (AssistantService.running) "Stop assistant" else "Start assistant"
        iconBtn.text = if (iconVisible()) "Hide from home screen (keep as system-style app)" else "Show on home screen again"
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ------------------------------------------------------------- voice helpers
    private fun withTts(f: (TextToSpeech) -> Unit) {
        val t = testTts
        if (t != null && testReady) { f(t); return }
        if (testInit) return
        testInit = true
        testTts = TextToSpeech(this) { st ->
            testReady = st == TextToSpeech.SUCCESS
            testInit = false
            runOnUiThread {
                if (testReady) testTts?.let(f) else status.text = "Text-to-speech engine not available."
            }
        }
    }

    private fun speakTest(hi: Boolean) {
        withTts { t ->
            Speech.apply(t, this, hi)
            Speech.say(
                t, this,
                if (hi) "हम्म… नमस्ते! मैं आपकी असिस्टेंट हूँ। बताइए, क्या करूँ?"
                else "Hmm… Hello! I'm your assistant. Tell me, what should I do?",
                "test"
            )
        }
    }

    private fun pickVoice(hi: Boolean) {
        withTts { t ->
            val lang = if (hi) "hi" else "en"
            val list = (t.voices ?: emptySet<Voice>())
                .filter { it.locale.language == lang && !it.isNetworkConnectionRequired }
                .sortedWith(compareBy<Voice>({ it.locale.country != "IN" }, { -it.quality }, { it.name }))
            if (list.isEmpty()) {
                status.text = "No offline $lang voices found. Install one in Settings > Text-to-speech > Google > Install voice data."
                return@withTts
            }
            val names = list.map { it.name + "  (" + it.locale.displayName + ")" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle(if (hi) "Hindi voice" else "English voice")
                .setItems(names) { _, i ->
                    prefs.edit().putString(if (hi) "voice_hi" else "voice_en", list[i].name).apply()
                    speakTest(hi)
                }
                .setNegativeButton("Close", null)
                .show()
        }
    }

    override fun onDestroy() {
        try { testTts?.shutdown() } catch (_: Throwable) {}
        super.onDestroy()
    }

    // ------------------------------------------------------------- wake word trainer
    private fun train() {
        if (AssistantService.running) {
            status.text = "Stop the assistant first, then train."
            return
        }
        if (!granted(Manifest.permission.RECORD_AUDIO) || !ModelStore.ready(this, "en")) {
            status.text = "Allow mic permission and download voice models first."
            return
        }
        thread {
            val heard = ArrayList<String>()
            var ar: AudioRecord? = null
            var model: Model? = null
            try {
                model = Model(ModelStore.dir(this, "en").absolutePath)
                val a = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, 32000
                )
                ar = a
                a.startRecording()
                for (i in 1..3) {
                    runOnUiThread { status.text = "Get ready…  ($i/3)" }
                    Thread.sleep(1200)
                    runOnUiThread { status.text = "SAY your wake word now!  ($i/3)" }
                    val r = Recognizer(model!!, 16000.0f)
                    val buf = ShortArray(1600)
                    val end = System.currentTimeMillis() + 3200
                    while (System.currentTimeMillis() < end) {
                        val n = a.read(buf, 0, buf.size)
                        if (n > 0) r.acceptWaveForm(buf, n)
                    }
                    val text = JSONObject(r.finalResult).optString("text").trim()
                    r.close()
                    if (text.isNotEmpty()) heard.add(text)
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Training failed: ${e.message}" }
            } finally {
                try { ar?.stop() } catch (_: Throwable) {}
                try { ar?.release() } catch (_: Throwable) {}
                try { model?.close() } catch (_: Throwable) {}
            }
            val boring = setOf("the", "a", "i", "you", "it", "and", "yeah", "oh", "uh", "hey", "he", "she", "is", "to")
            val good = heard.filter { it.replace(" ", "").length >= 4 && it !in boring }
            val old = (prefs.getString("wake_trained", "") ?: "").split("|").filter { it.isNotEmpty() }
            val merged = (old + good).distinct().takeLast(8)
            prefs.edit().putString("wake_trained", merged.joinToString("|")).apply()
            runOnUiThread {
                refresh(keepStatus = true)
                status.text = if (good.isEmpty()) "Couldn't hear a clear phrase. Try again closer to the mic."
                else "Learned: " + good.joinToString(" | ")
            }
        }
    }

    // ------------------------------------------------------------- custom commands
    private fun customDialog() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val list = Store.customs(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, 0)
        val tv = TextView(this)
        tv.text = if (list.isEmpty()) "(no custom commands yet)" else list.joinToString("\n") { "• ${it.first}  →  ${it.second}" }
        col.addView(tv)
        val e1 = EditText(this)
        e1.hint = "When I say…"
        val e2 = EditText(this)
        e2.hint = "Do… (e.g. open youtube / call mom / say good morning)"
        col.addView(e1)
        col.addView(e2)
        AlertDialog.Builder(this)
            .setTitle("Custom commands")
            .setView(col)
            .setPositiveButton("Add") { _, _ ->
                val a = e1.text.toString().trim()
                val b = e2.text.toString().trim()
                if (a.isNotEmpty() && b.isNotEmpty()) {
                    list.add(a.lowercase() to b)
                    Store.saveCustoms(this, list)
                }
            }
            .setNeutralButton("Delete last") { _, _ ->
                if (list.isNotEmpty()) {
                    list.removeAt(list.size - 1)
                    Store.saveCustoms(this, list)
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ------------------------------------------------------------- AI model picker
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != pickCode || resultCode != RESULT_OK || uri == null) return

        var name = "model.task"
        contentResolver.query(uri, null, null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = cur.getString(i) ?: name
            }
        }
        val fname = name
        status.text = "Copying AI model… this can take a minute, keep the app open."
        thread {
            try {
                val dir = File(filesDir, "llm")
                dir.deleteRecursively()
                dir.mkdirs()
                val part = File(dir, "$fname.part")
                contentResolver.openInputStream(uri)!!.use { input ->
                    part.outputStream().use { out -> input.copyTo(out, 1 shl 16) }
                }
                part.renameTo(File(dir, fname))
                runOnUiThread { refresh() }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Copy failed: ${e.message}" }
            }
        }
    }
}
