package com.chanit.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** One place for how the assistant sounds: voice, speed, pitch, pauses between sentences. */
object Speech {

    fun split(text: String): List<String> =
        text.split(Regex("(?<=[.!?।…])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }

    /** English uses English (India); falls back to US English if the engine has no en-IN. */
    fun apply(t: TextToSpeech, c: Context, hindi: Boolean): Int {
        val p = Store.prefs(c)
        var res = t.setLanguage(if (hindi) Locale("hi", "IN") else Locale("en", "IN"))
        if (!hindi && (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED)) {
            res = t.setLanguage(Locale.US)
        }
        val name = p.getString(if (hindi) "voice_hi" else "voice_en", null)
        if (name != null) {
            try {
                val v = t.voices?.firstOrNull { it.name == name }
                if (v != null) t.setVoice(v)
            } catch (_: Throwable) {}
        }
        t.setSpeechRate(p.getFloat("tts_rate", 1.0f))
        t.setPitch(p.getFloat("tts_pitch", 1.0f))
        return res
    }

    /** Speaks sentence by sentence with a pause in between. Only the last part carries [lastId]. */
    fun say(t: TextToSpeech, c: Context, text: String, lastId: String) {
        val pause = Store.prefs(c).getFloat("tts_pause", 250f).toLong()
        val parts = split(text).ifEmpty { listOf(text) }
        for ((i, s) in parts.withIndex()) {
            val last = i == parts.size - 1
            t.speak(s, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, if (last) lastId else "part$i")
            if (!last && pause > 0) t.playSilentUtterance(pause, TextToSpeech.QUEUE_ADD, "gap$i")
        }
    }
}
