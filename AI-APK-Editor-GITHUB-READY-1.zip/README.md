# AI Assistant (free) - APK / project editor

Phone ke andar chalne wala AI assistant. Free Gemini API key se chalta hai (aistudio.google.com/apikey).

## App kaise kholein
Home screen / app drawer mein ab "AI Assistant" ka icon aata hai.
Backup: Settings > Apps > AI Assistant > **Open**, ya dialer mein `*#*#2424#*#*`.

## Kya kar sakta hai
- **Source project zip**: Import karo, bolo kya badalna hai, ye files edit karta hai, phir `Save` se naya zip milta hai (GitHub par upload karke APK build karo).
- **APK**: Import karo, ye dex ko smali mein decompile karta hai, code edit karta hai, APK dobara banata hai aur sign karta hai (sab phone par).
- **Screenshot** bhej sakte ho (📷), ye samajh leta hai.

## Abhi nahi ho sakta
- APK ka AndroidManifest.xml / resources.arsc / layout XML edit (binary hain). Code-level changes ho jate hain.
- Original app ke upar update nahi hota (signature alag) - pehle original uninstall karo.

## Build (GitHub) - purani repo mein
Is zip ko purani repo ke root mein upload karo (zip file ki tarah, ya extract karke files). Jo sabse naya upload hoga wahi build hoga.
`.github/workflows/build.yml` isi zip mein hai (purani ko replace karti hai).
APK: Actions > run > Artifacts > `AI-APK-Editor-APK-runN` > `AI-APK-Editor-debug.apk`.
Package: `com.aiapk.assistant` (phone mein naam: AI Assistant). Purani workflow ho to naam `iLauncher-...` aayega, par andar yahi AI app hota hai.
