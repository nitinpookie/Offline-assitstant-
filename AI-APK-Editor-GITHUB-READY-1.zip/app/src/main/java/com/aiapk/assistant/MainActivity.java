package com.aiapk.assistant;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.TypefaceSpan;
import android.text.util.Linkify;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    static final int RQ_IMPORT = 1, RQ_IMAGE = 2, RQ_SAVE = 3;
    static final String DEFAULT_MODEL = "gemini-3.8-flash";

    final Handler h = new Handler(Looper.getMainLooper());
    LinearLayout chat;
    ScrollView scroll;
    EditText input;
    TextView sendBtn;
    ObjectAnimator pulse;
    TextView statusTv, wsTv, pendingTv;
    SharedPreferences prefs;
    Tools tools;
    Agent agent;

    /** Saved model name; old retired families (1.5 / 2.0 / 2.5) are replaced by the current default. */
    String savedModel() {
        String m = prefs.getString("model", DEFAULT_MODEL);
        if (m == null || m.isEmpty() || m.startsWith("gemini-2.5-") || m.startsWith("gemini-2.0-") || m.startsWith("gemini-1.5-")) {
            prefs.edit().putString("model", DEFAULT_MODEL).apply();
            return DEFAULT_MODEL;
        }
        return m;
    }
    String pendingB64;
    volatile boolean busy;
    File saveFile, lastOut;
    String saveMime, lastOutName, lastOutMime;

    final Agent.Ui uiCb = new Agent.Ui() {
        @Override public void say(String t) { h.post(() -> addBubble(clean(t), 1)); }
        @Override public void log(String t) { h.post(() -> addBubble(t, 2)); }
        @Override public void status(String t) { h.post(() -> statusTv.setText(t)); }
        @Override public void error(String t) { h.post(() -> addBubble("⚠️ " + t, 3)); }
    };

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ---------- look: black, rounded, one gradient accent ----------
    static final int BG = 0xFF000000, CARD = 0xFF121216, EDGE = 0xFF24242B, TXT = 0xFFEDEDF0,
            MUTED = 0xFF8E8E98, BLUE = 0xFF5B7CFF, PURPLE = 0xFFA855F7, RED = 0xFFFF453A, ACCENT = 0xFF8AA4FF;

    GradientDrawable box(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    GradientDrawable grad(int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{BLUE, PURPLE});
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    /** tap ripple clipped to the same rounded shape */
    Drawable ripple(Drawable bg, int radiusDp) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, box(Color.WHITE, radiusDp, 0));
    }

    LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    TextView iconBtn(String glyph, String desc, boolean flat, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(glyph);
        t.setTextSize(17);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setContentDescription(desc);
        t.setBackground(ripple(box(flat ? 0 : 0xFF17171C, 20, 0), 20));
        t.setOnClickListener(l);
        return t;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);

        // header: title + 4 round buttons
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(18), dp(10), dp(12), dp(6));
        TextView title = new TextView(this);
        title.setText("AI Assistant");
        title.setTextColor(TXT);
        title.setTextSize(21);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        bar.addView(title, lp(0, WRAP));
        ((LinearLayout.LayoutParams) title.getLayoutParams()).weight = 1f;
        String[][] btns = {{"📥", "Import"}, {"💾", "Save"}, {"＋", "New chat"}, {"⚙", "Settings"}};
        for (int i = 0; i < btns.length; i++) {
            final int id = i;
            LinearLayout.LayoutParams ilp = lp(dp(40), dp(40));
            ilp.leftMargin = dp(8);
            bar.addView(iconBtn(btns[i][0], btns[i][1], false, v -> {
                if (id == 0) pickFile();
                else if (id == 1) saveLast();
                else if (id == 2) newChat();
                else settings();
            }), ilp);
        }
        root.addView(bar, lp(MATCH, WRAP));

        // workspace chip
        wsTv = new TextView(this);
        wsTv.setTextSize(12);
        wsTv.setTextColor(MUTED);
        wsTv.setSingleLine(true);
        wsTv.setEllipsize(TextUtils.TruncateAt.END);
        wsTv.setPadding(dp(12), dp(6), dp(12), dp(6));
        wsTv.setBackground(box(0xFF0F0F13, 14, EDGE));
        LinearLayout.LayoutParams wlp = lp(WRAP, WRAP);
        wlp.setMargins(dp(16), dp(2), dp(16), dp(6));
        wlp.gravity = Gravity.START;
        root.addView(wsTv, wlp);

        // chat
        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(dp(14), dp(6), dp(14), dp(10));
        scroll.addView(chat);
        root.addView(scroll, lp(MATCH, 0));
        ((LinearLayout.LayoutParams) scroll.getLayoutParams()).weight = 1f;

        // "working..." line with a pulsing dot
        statusTv = new TextView(this);
        statusTv.setTextSize(12);
        statusTv.setTextColor(ACCENT);
        statusTv.setPadding(dp(20), dp(2), dp(20), dp(6));
        statusTv.setVisibility(View.GONE);
        root.addView(statusTv);
        pulse = ObjectAnimator.ofFloat(statusTv, "alpha", 1f, 0.35f);
        pulse.setDuration(700);
        pulse.setRepeatCount(ObjectAnimator.INFINITE);
        pulse.setRepeatMode(ObjectAnimator.REVERSE);

        // screenshot chip
        pendingTv = new TextView(this);
        pendingTv.setText("📷 Screenshot laga hai  ·  hatane ke liye dabao");
        pendingTv.setTextSize(12);
        pendingTv.setTextColor(ACCENT);
        pendingTv.setPadding(dp(12), dp(7), dp(12), dp(7));
        pendingTv.setBackground(box(0xFF0F1220, 14, 0xFF26304F));
        pendingTv.setVisibility(View.GONE);
        pendingTv.setOnClickListener(v -> {
            pendingB64 = null;
            pendingTv.setVisibility(View.GONE);
            updateSend();
        });
        LinearLayout.LayoutParams plp = lp(WRAP, WRAP);
        plp.setMargins(dp(16), dp(2), dp(16), dp(6));
        plp.gravity = Gravity.START;
        root.addView(pendingTv, plp);

        // input dock: one rounded pill [📷  message...  ↑]
        LinearLayout dock = new LinearLayout(this);
        dock.setPadding(dp(12), dp(4), dp(12), dp(10));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(box(CARD, 26, EDGE));
        row.setPadding(dp(6), dp(5), dp(6), dp(5));
        row.addView(iconBtn("📷", "Screenshot bhejo", true, v -> pickImage()), lp(dp(40), dp(40)));
        input = new EditText(this);
        input.setHint("Message likho...");
        input.setHintTextColor(MUTED);
        input.setTextColor(TXT);
        input.setTextSize(15);
        input.setBackground(null);
        input.setPadding(dp(6), dp(8), dp(6), dp(8));
        input.setMaxLines(5);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int n, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int n, int d) { updateSend(); }
            @Override public void afterTextChanged(Editable e) { }
        });
        row.addView(input, lp(0, WRAP));
        ((LinearLayout.LayoutParams) input.getLayoutParams()).weight = 1f;
        sendBtn = new TextView(this);
        sendBtn.setText("↑");
        sendBtn.setTextSize(21);
        sendBtn.setTypeface(Typeface.DEFAULT_BOLD);
        sendBtn.setTextColor(Color.WHITE);
        sendBtn.setGravity(Gravity.CENTER);
        sendBtn.setContentDescription("Send");
        sendBtn.setBackground(ripple(grad(21), 21));
        sendBtn.setOnClickListener(v -> onSend());
        row.addView(sendBtn, lp(dp(42), dp(42)));
        dock.addView(row, lp(MATCH, WRAP));
        root.addView(dock, lp(MATCH, WRAP));

        setContentView(root);
        updateSend();

        tools = new Tools(this, (f, n, m) -> h.post(() -> showOutput(f, n, m)));
        wsTv.setText("📂 " + tools.shortStatus());
        addBubble("Namaste! 👋\n\n1️⃣  ⚙ mein free Gemini API key daalo\n2️⃣  📥 se APK ya project zip chuno\n3️⃣  Batao kya badalna hai\n\n📷 se screenshot bhi bhej sakte ho.", 1);
        if (prefs.getString("key", "").isEmpty()) h.postDelayed(this::settings, 400);
    }

    /** send button looks dim when there is nothing to send */
    void updateSend() {
        boolean can = busy || input.getText().length() > 0 || pendingB64 != null;
        sendBtn.setAlpha(can ? 1f : 0.45f);
    }

    TextView addBubble(String text, int kind) {
        TextView tv = new TextView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tv.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * (kind == 0 ? 0.82f : 0.92f)));
        if (kind == 2) {
            // tool log line: small, grey, monospace
            tv.setText(text);
            tv.setTextSize(12);
            tv.setTypeface(Typeface.MONOSPACE);
            tv.setTextColor(MUTED);
            tv.setPadding(dp(10), dp(3), dp(10), dp(3));
            lp.setMargins(dp(2), dp(2), 0, dp(2));
            lp.gravity = Gravity.START;
        } else {
            tv.setText(kind == 1 ? fmt(text) : text);
            tv.setTextSize(15);
            tv.setLineSpacing(0f, 1.12f);
            tv.setLinkTextColor(ACCENT);
            float r = dp(20), t = dp(6);
            GradientDrawable bg;
            if (kind == 0) {
                bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{BLUE, PURPLE});
                bg.setCornerRadii(new float[]{r, r, r, r, t, t, r, r});
                tv.setTextColor(Color.WHITE);
            } else {
                bg = new GradientDrawable();
                bg.setColor(kind == 3 ? 0xFF2A1214 : CARD);
                bg.setStroke(dp(1), kind == 3 ? 0xFF5A1F24 : EDGE);
                bg.setCornerRadii(new float[]{r, r, r, r, r, r, t, t});
                tv.setTextColor(kind == 3 ? 0xFFFF8A84 : TXT);
                tv.setTextIsSelectable(true);
            }
            tv.setBackground(bg);
            tv.setPadding(dp(14), dp(10), dp(14), dp(10));
            lp.setMargins(0, dp(5), 0, dp(5));
            lp.gravity = kind == 0 ? Gravity.END : Gravity.START;
        }
        if (chat.getChildCount() > 150) chat.removeViewAt(0);   // keep long chats light
        chat.addView(tv, lp);
        tv.setAlpha(0f);
        tv.setTranslationY(dp(10));
        tv.animate().alpha(1f).translationY(0f).setDuration(180).start();
        scrollDown();
        return tv;
    }

    /** `code` and ``` blocks get a monospace look; everything else stays plain */
    CharSequence fmt(String t) {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        boolean fence = false;
        String[] lines = t.split("\n", -1);
        for (int li = 0; li < lines.length; li++) {
            String line = lines[li];
            if (line.trim().startsWith("```")) {
                fence = !fence;
                continue;
            }
            if (fence) {
                int st = sb.length();
                sb.append(line);
                codeSpan(sb, st);
            } else {
                int i = 0;
                while (i < line.length()) {
                    int a = line.indexOf('`', i);
                    int e = a < 0 ? -1 : line.indexOf('`', a + 1);
                    if (a < 0 || e < 0) {
                        sb.append(line, i, line.length());
                        break;
                    }
                    sb.append(line, i, a);
                    int st = sb.length();
                    sb.append(line, a + 1, e);
                    codeSpan(sb, st);
                    i = e + 1;
                }
            }
            if (li < lines.length - 1) sb.append('\n');
        }
        while (sb.length() > 0 && sb.charAt(sb.length() - 1) == '\n') sb.delete(sb.length() - 1, sb.length());
        return sb;
    }

    void codeSpan(SpannableStringBuilder sb, int start) {
        int end = sb.length();
        if (end <= start) return;
        sb.setSpan(new TypefaceSpan("monospace"), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new BackgroundColorSpan(0xFF1E1E26), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new ForegroundColorSpan(0xFFB4C0FF), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    void scrollDown() {
        // smoothScrollTo (not fullScroll) so the keyboard / focus never jump
        scroll.post(() -> scroll.smoothScrollTo(0, chat.getBottom()));
    }

    static String clean(String t) {
        StringBuilder sb = new StringBuilder();
        for (String line : t.replace("**", "").split("\n", -1)) {
            if (line.startsWith("* ")) line = "• " + line.substring(2);
            else if (line.startsWith("  * ")) line = "   • " + line.substring(4);
            sb.append(line).append('\n');
        }
        return sb.toString().trim();
    }

    void setBusy(boolean b) {
        busy = b;
        sendBtn.setText(b ? "■" : "↑");
        sendBtn.setContentDescription(b ? "Stop" : "Send");
        sendBtn.setBackground(b ? ripple(box(RED, 21, 0), 21) : ripple(grad(21), 21));
        statusTv.setVisibility(b ? View.VISIBLE : View.GONE);
        if (b) {
            statusTv.setText("●  Soch raha hoon...");
            if (!pulse.isStarted()) pulse.start();
        } else {
            pulse.cancel();
            statusTv.setAlpha(1f);
            wsTv.setText("📂 " + tools.shortStatus());
        }
        updateSend();
    }

    // ---------- send ----------
    void onSend() {
        if (busy) {
            if (agent != null) agent.cancel = true;
            return;
        }
        final String t = input.getText().toString().trim();
        if (t.isEmpty() && pendingB64 == null) return;
        String key = prefs.getString("key", "");
        if (key.isEmpty()) {
            settings();
            return;
        }
        addBubble(t.isEmpty() ? "(screenshot)" : (pendingB64 != null ? "📷 " + t : t), 0);
        final String img = pendingB64;
        pendingB64 = null;
        pendingTv.setVisibility(View.GONE);
        input.setText("");
        if (agent == null) {
            agent = new Agent(tools, uiCb);
            agent.onModel = nm -> prefs.edit().putString("model", nm).apply();
        }
        agent.apiKey = key;
        agent.model = savedModel();
        agent.cancel = false;
        setBusy(true);
        final Agent ag = agent;
        new Thread(() -> {
            try {
                ag.run(t, img);
            } catch (Throwable e) {
                uiCb.error(String.valueOf(e.getMessage()));
            } finally {
                h.post(() -> setBusy(false));
            }
        }).start();
    }

    void newChat() {
        if (busy) {
            Toast.makeText(this, "Pehle Stop dabao", Toast.LENGTH_SHORT).show();
            return;
        }
        chat.removeAllViews();
        if (agent != null) agent.reset();
        addBubble("Nayi chat. Workspace wahi hai (" + tools.shortStatus() + ").", 1);
    }

    // ---------- file pickers ----------
    void pickFile() {
        if (busy) {
            Toast.makeText(this, "Pehle kaam khatam hone do ya Stop dabao", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, RQ_IMPORT);
    }

    void pickImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        startActivityForResult(i, RQ_IMAGE);
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (rs != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (rq == RQ_IMPORT) importUri(uri);
        else if (rq == RQ_IMAGE) {
            try {
                pendingB64 = loadImageB64(uri);
                pendingTv.setVisibility(View.VISIBLE);
                updateSend();
            } catch (Exception e) {
                Toast.makeText(this, "Image load nahi hui", Toast.LENGTH_SHORT).show();
            }
        } else if (rq == RQ_SAVE) saveTo(uri);
    }

    String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {
        }
        return "file";
    }

    void importUri(Uri uri) {
        final String name = displayName(uri);
        setBusy(true);
        statusTv.setText("⏳ Import ho raha hai...");
        new Thread(() -> {
            try {
                File tmp = new File(getCacheDir(), "import.tmp");
                try (InputStream in = getContentResolver().openInputStream(uri); OutputStream o = new FileOutputStream(tmp)) {
                    Tools.copy(in, o);
                }
                String res = tools.importFile(tmp, name);
                tmp.delete();
                if (agent != null) agent.reset();
                h.post(() -> addBubble("📂 " + name + ": " + res + "\nAb batao kya karna hai.", 1));
            } catch (Throwable e) {
                uiCb.error("Import fail: " + e.getMessage());
            } finally {
                h.post(() -> setBusy(false));
            }
        }).start();
    }

    String loadImageB64(Uri uri) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            Tools.copy(in, bo);
        }
        byte[] bytes = bo.toByteArray();
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / s > 2400) s *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = s;
        Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o2);
        if (bmp == null) throw new IOException("decode fail");
        float sc = 1568f / Math.max(bmp.getWidth(), bmp.getHeight());
        if (sc < 1f) bmp = Bitmap.createScaledBitmap(bmp, (int) (bmp.getWidth() * sc), (int) (bmp.getHeight() * sc), true);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out);
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    // ---------- outputs ----------
    void showOutput(File f, String name, String mime) {
        lastOut = f;
        lastOutName = name;
        lastOutMime = mime;
        TextView b = new TextView(this);
        b.setText("💾  Save: " + name + "  (" + (f.length() / 1024) + " KB)");
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(18), dp(12), dp(18), dp(12));
        b.setBackground(ripple(grad(22), 22));
        b.setOnClickListener(v -> startSave(f, name, mime));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.START;
        lp.setMargins(0, dp(6), 0, dp(6));
        chat.addView(b, lp);
        scrollDown();
    }

    void saveLast() {
        if (lastOut == null || !lastOut.exists()) {
            Toast.makeText(this, "Abhi koi output nahi bana", Toast.LENGTH_SHORT).show();
            return;
        }
        startSave(lastOut, lastOutName, lastOutMime);
    }

    void startSave(File f, String name, String mime) {
        saveFile = f;
        saveMime = mime;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, RQ_SAVE);
    }

    void saveTo(Uri uri) {
        final File f = saveFile;
        if (f == null) return;
        new Thread(() -> {
            try (InputStream in = new FileInputStream(f); OutputStream o = getContentResolver().openOutputStream(uri)) {
                Tools.copy(in, o);
                h.post(() -> Toast.makeText(this, "Save ho gaya ✅", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                uiCb.error("Save fail: " + e.getMessage());
            }
        }).start();
    }

    // ---------- settings ----------
    void settings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        TextView hint = new TextView(this);
        hint.setTextSize(13);
        hint.setTextColor(MUTED);
        hint.setAutoLinkMask(Linkify.WEB_URLS);
        hint.setText("Free key: https://aistudio.google.com/apikey (Google account se, card nahi chahiye).\nModel: gemini-3.8-flash (default). Limit khatam ho to gemini-3.1-flash-lite.");
        EditText k = new EditText(this);
        k.setTextColor(TXT);
        k.setHintTextColor(MUTED);
        k.setHint("Gemini API key");
        k.setSingleLine(true);
        k.setText(prefs.getString("key", ""));
        k.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText m = new EditText(this);
        m.setTextColor(TXT);
        m.setHintTextColor(MUTED);
        m.setHint("Model");
        m.setSingleLine(true);
        m.setText(savedModel());
        box.addView(hint);
        box.addView(k);
        box.addView(m);
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Settings")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    String mm = m.getText().toString().trim();
                    prefs.edit().putString("key", k.getText().toString().trim())
                            .putString("model", mm.isEmpty() ? DEFAULT_MODEL : mm).apply();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
