package com.aiapk.assistant;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Tool-calling agent loop on the free Gemini API. */
public class Agent {

    public interface Ui {
        void say(String t);
        void log(String t);
        void status(String t);
        void error(String t);
    }

    static final int MAX_STEPS = 30;
    static final String BASE = "https://generativelanguage.googleapis.com/v1beta/models/";

    static final String SYSTEM =
            "You are an expert Android developer and APK-modding assistant running inside a phone app. "
            + "The user (Hinglish speaker, beginner) imports an APK or a source-project ZIP into a workspace and you change it with tools. "
            + "Always reply in the user's language (Hinglish/Hindi/English), short and clear. The user may send screenshots - read them carefully.\n"
            + "WORKFLOW: first call workspace_info (and list_files) to see what was imported.\n"
            + "SOURCE mode: project files are in the workspace root. Find code with search, read only the needed line ranges, edit with replace_in_file / write_file, "
            + "then call export_zip (name it like the original zip) so the user can save it and upload it to GitHub, which builds the APK.\n"
            + "APK mode: apk_files/ holds assets, res, lib and other raw files. Binary XML (AndroidManifest.xml, res/*.xml) and resources.arsc are binary and cannot be edited as text yet - say so honestly if a request needs that. "
            + "Code is decompiled on demand: call apk_disassemble (dex='classes.dex' or 'all'); smali goes to smali/<dexname>/. Edit smali with search + replace_in_file. "
            + "When done call apk_build, which assembles smali, repacks and signs modified.apk. The signature differs from the original so the user must uninstall the original app first.\n"
            + "RULES: the free API allows very few requests per minute, so be economical: use search instead of reading many files, read line ranges, make several edits per step. "
            + "Never paste whole big files in chat. smali tips: keep .locals/.registers valid, p0 is 'this' in instance methods, labels must stay unique, "
            + "to disable a method insert 'return-void' (or 'const/4 v0, 0x0' + 'return v0') right after the .locals/.registers line. "
            + "After editing, re-read the edited range to verify. If apk_build reports smali errors, fix them and rebuild. "
            + "Finish with a summary of what changed in 3-5 short lines.";

    final Tools tools;
    final Ui ui;
    public String apiKey = "";
    public String model = "gemini-3.8-flash";
    /** called when Google tells us to use a different model, so the app can remember it */
    public java.util.function.Consumer<String> onModel;
    public volatile boolean cancel;
    JSONArray contents = new JSONArray();
    final JSONArray toolDecls;

    public Agent(Tools tools, Ui ui) {
        this.tools = tools;
        this.ui = ui;
        try {
            toolDecls = buildTools();
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    public void reset() {
        contents = new JSONArray();
    }

    // ---------- tool declarations ----------
    static JSONObject decl(String name, String desc, String[][] props, String[] required) throws JSONException {
        JSONObject d = new JSONObject().put("name", name).put("description", desc);
        if (props.length > 0) {
            JSONObject p = new JSONObject();
            for (String[] pr : props) {
                p.put(pr[0], new JSONObject().put("type", pr[1]).put("description", pr[2]));
            }
            JSONObject schema = new JSONObject().put("type", "OBJECT").put("properties", p);
            if (required.length > 0) schema.put("required", new JSONArray(Arrays.asList(required)));
            d.put("parameters", schema);
        }
        return d;
    }

    static JSONArray buildTools() throws JSONException {
        String S = "STRING", I = "INTEGER", B = "BOOLEAN";
        String[] none = new String[0];
        JSONArray a = new JSONArray();
        a.put(decl("workspace_info", "Show import mode (APK or source), dex files and saved outputs.", new String[0][], none));
        a.put(decl("list_files", "List files and folders (hidden dot-folders skipped).",
                new String[][]{{"path", S, "folder relative to workspace root; empty = root"}, {"depth", I, "levels 1-6, default 2"}}, none));
        a.put(decl("read_file", "Read a text file, optionally only a line range.",
                new String[][]{{"path", S, "file path"}, {"start_line", I, "first line, 1-based (optional)"}, {"end_line", I, "last line (optional)"}},
                new String[]{"path"}));
        a.put(decl("write_file", "Create or overwrite a UTF-8 text file. Parent folders are created.",
                new String[][]{{"path", S, "file path"}, {"content", S, "full file content"}}, new String[]{"path", "content"}));
        a.put(decl("replace_in_file", "Replace exact text in a file. old_text must match exactly (whitespace too) and be unique unless replace_all is true.",
                new String[][]{{"path", S, "file path"}, {"old_text", S, "exact text to find"}, {"new_text", S, "replacement text"},
                        {"replace_all", B, "replace every occurrence"}}, new String[]{"path", "old_text", "new_text"}));
        a.put(decl("search", "Case-insensitive text search in all text files under a folder. Returns path:line: text.",
                new String[][]{{"query", S, "text to find"}, {"path", S, "folder to search; empty = whole workspace"},
                        {"max_results", I, "default 40, max 100"}}, new String[]{"query"}));
        a.put(decl("delete_path", "Delete a file or folder.", new String[][]{{"path", S, "path"}}, new String[]{"path"}));
        a.put(decl("move_path", "Move or rename a file or folder.",
                new String[][]{{"from_path", S, "source"}, {"to_path", S, "target"}}, new String[]{"from_path", "to_path"}));
        a.put(decl("apk_disassemble", "APK mode: decompile dex to smali into smali/<dexname>/. Needed before editing code. May take a minute.",
                new String[][]{{"dex", S, "classes.dex, classes2.dex ... or all"}}, none));
        a.put(decl("apk_build", "APK mode: assemble edited smali to dex, repack apk_files, sign -> modified.apk the user can save.", new String[0][], none));
        a.put(decl("export_zip", "Zip the whole workspace so the user can save it (for source projects).",
                new String[][]{{"name", S, "zip file name, e.g. iLauncher-GITHUB-READY.zip"}}, none));
        return a;
    }

    // ---------- main loop (blocking; call from a background thread) ----------
    public void run(String text, String imgB64) throws Exception {
        JSONArray parts = new JSONArray();
        if (imgB64 != null) {
            stripImages();
            parts.put(new JSONObject().put("inlineData", new JSONObject().put("mimeType", "image/jpeg").put("data", imgB64)));
        }
        parts.put(new JSONObject().put("text", (text == null || text.isEmpty()) ? "Ye screenshot dekho aur batao kya dikh raha hai." : text));
        addUserParts(parts);

        for (int step = 0; step < MAX_STEPS; step++) {
            if (cancel) {
                ui.error("Roka gaya.");
                return;
            }
            ui.status("🤔 Soch raha hoon...");
            compact();
            JSONObject body = new JSONObject();
            body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", SYSTEM))));
            body.put("contents", contents);
            body.put("tools", new JSONArray().put(new JSONObject().put("functionDeclarations", toolDecls)));
            body.put("generationConfig", new JSONObject().put("maxOutputTokens", 8192));
            JSONObject resp = post(body);

            JSONArray cands = resp.optJSONArray("candidates");
            if (cands == null || cands.length() == 0) {
                JSONObject pf = resp.optJSONObject("promptFeedback");
                ui.error("Gemini ne jawab nahi diya" + (pf != null ? " (" + pf.optString("blockReason", "blocked") + ")" : "") + ". Message badal ke try karo.");
                return;
            }
            JSONObject cand = cands.getJSONObject(0);
            JSONObject content = cand.optJSONObject("content");
            JSONArray rp = content == null ? null : content.optJSONArray("parts");
            if (rp == null || rp.length() == 0) {
                ui.error("Khali jawab aaya (reason: " + cand.optString("finishReason", "?") + "). Dobara bhejo.");
                return;
            }
            content.put("role", "model");
            contents.put(content);

            StringBuilder txt = new StringBuilder();
            List<JSONObject> calls = new ArrayList<>();
            for (int i = 0; i < rp.length(); i++) {
                JSONObject p = rp.getJSONObject(i);
                if (p.has("functionCall")) calls.add(p.getJSONObject("functionCall"));
                else if (p.has("text") && !p.optBoolean("thought", false)) txt.append(p.getString("text"));
            }
            if (txt.length() > 0) ui.say(txt.toString().trim());
            if (calls.isEmpty()) return;

            JSONArray results = new JSONArray();
            for (JSONObject fc : calls) {
                String name = fc.optString("name");
                JSONObject args = fc.optJSONObject("args");
                if (args == null) args = new JSONObject();
                String res;
                if (cancel) {
                    res = "ERROR: user ne roka";
                } else {
                    ui.log("🔧 " + name + " " + shortArg(args));
                    ui.status("⚙️ " + name + "...");
                    res = tools.call(name, args);
                }
                if (res.length() > 24000) res = res.substring(0, 24000) + "\n...[output truncated]";
                results.put(new JSONObject().put("functionResponse",
                        new JSONObject().put("name", name).put("response", new JSONObject().put("result", res))));
            }
            contents.put(new JSONObject().put("role", "user").put("parts", results));
        }
        ui.say("(Bahut saare steps ho gaye - aage badhne ke liye 'continue' likho.)");
    }

    static String shortArg(JSONObject a) {
        String[] keys = {"path", "query", "dex", "from_path", "name"};
        for (String k : keys) {
            String v = a.optString(k, "");
            if (!v.isEmpty()) return v.length() > 70 ? v.substring(0, 70) : v;
        }
        return "";
    }

    void addUserParts(JSONArray parts) throws JSONException {
        if (contents.length() > 0) {
            JSONObject last = contents.getJSONObject(contents.length() - 1);
            if ("user".equals(last.optString("role"))) {
                JSONArray lp = last.getJSONArray("parts");
                for (int i = 0; i < parts.length(); i++) lp.put(parts.get(i));
                return;
            }
        }
        contents.put(new JSONObject().put("role", "user").put("parts", parts));
    }

    void stripImages() throws JSONException {
        for (int i = 0; i < contents.length(); i++) {
            JSONArray ps = contents.getJSONObject(i).optJSONArray("parts");
            if (ps == null) continue;
            for (int j = 0; j < ps.length(); j++) {
                if (ps.getJSONObject(j).has("inlineData")) {
                    ps.put(j, new JSONObject().put("text", "[purana screenshot hata diya]"));
                }
            }
        }
    }

    void compact() throws JSONException {
        if (contents.toString().length() < 350000) return;
        int keep = contents.length() - 8;
        for (int i = 0; i < keep; i++) {
            JSONArray ps = contents.getJSONObject(i).optJSONArray("parts");
            if (ps == null) continue;
            for (int j = 0; j < ps.length(); j++) {
                JSONObject p = ps.getJSONObject(j);
                if (p.has("functionResponse")) {
                    p.getJSONObject("functionResponse").put("response", new JSONObject().put("result", "[purana output hata diya]"));
                } else if (p.has("inlineData")) {
                    ps.put(j, new JSONObject().put("text", "[purana screenshot hata diya]"));
                }
            }
        }
    }

    // ---------- HTTP with free-tier retry ----------
    JSONObject post(JSONObject body) throws Exception {
        byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
        for (int attempt = 0; attempt < 6; attempt++) {
            if (cancel) throw new IOException("Roka gaya.");
            HttpURLConnection c = (HttpURLConnection) new URL(BASE + model + ":generateContent").openConnection();
            try {
                c.setRequestMethod("POST");
                c.setConnectTimeout(30000);
                c.setReadTimeout(240000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("x-goog-api-key", apiKey);
                try (OutputStream o = c.getOutputStream()) {
                    o.write(data);
                }
                int code = c.getResponseCode();
                InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
                String s = readAll(is);
                if (code == 200) return new JSONObject(s);
                String msg = errMsg(s);
                boolean daily = s.contains("PerDay") || msg.toLowerCase().contains("per day");
                if ((code == 429 || code == 503 || code == 500) && attempt < 5 && !daily) {
                    int wait = retrySeconds(s, 15 + attempt * 10);
                    for (int i = wait; i > 0 && !cancel; i--) {
                        ui.status("⏳ Free limit / server busy - " + i + "s baad dobara...");
                        Thread.sleep(1000);
                    }
                    continue;
                }
                if (code == 404 || code == 400) {
                    // "...no longer available... please use models/gemini-3.8-flash": switch to what Google suggests
                    java.util.regex.Matcher mm = java.util.regex.Pattern.compile("use models/([A-Za-z0-9._-]+)").matcher(msg);
                    if (mm.find() && !mm.group(1).equals(model) && attempt < 5) {
                        model = mm.group(1);
                        if (onModel != null) onModel.accept(model);
                        ui.status("\u21AA Naya model: " + model);
                        continue;
                    }
                }
                if (daily) {
                    throw new IOException("Aaj ki free limit khatam ho gayi. Kal tak ruko ya Settings mein model gemini-3.1-flash-lite karo.");
                }
                if (code == 400 && msg.toLowerCase().contains("api key")) {
                    throw new IOException("API key galat hai. Settings mein sahi key daalo.");
                }
                throw new IOException("Gemini error " + code + ": " + msg);
            } finally {
                c.disconnect();
            }
        }
        throw new IOException("Gemini abhi busy hai, thodi der baad try karo.");
    }

    static String readAll(InputStream is) throws IOException {
        if (is == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int r;
        while ((r = is.read(b)) > 0) bo.write(b, 0, r);
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }

    static String errMsg(String s) {
        try {
            return new JSONObject(s).getJSONObject("error").getString("message");
        } catch (Exception e) {
            return s.length() > 300 ? s.substring(0, 300) : s;
        }
    }

    static int retrySeconds(String s, int dflt) {
        Matcher m = Pattern.compile("retryDelay\"\\s*:\\s*\"(\\d+)").matcher(s);
        int w = dflt;
        if (m.find()) {
            w = Integer.parseInt(m.group(1)) + 2;
        } else {
            Matcher m2 = Pattern.compile("retry in ([0-9.]+)s").matcher(s);
            if (m2.find()) w = (int) Math.ceil(Double.parseDouble(m2.group(1))) + 2;
        }
        return Math.max(5, Math.min(w, 100));
    }
}
