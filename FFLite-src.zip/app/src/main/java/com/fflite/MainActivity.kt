package com.fflite

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

var resumeTick by mutableIntStateOf(0)

private val LEVELS = listOf("Original", "Lite (1/2)", "Extra Lite (1/4)", "Ultra Lite (1/8)", "Ultra Pro Max (1/16)", "Extreme (1/32)", "No Limit (1/64)")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val cs = darkColorScheme(primary = Color(0xFFFFB74D), onPrimary = Color(0xFF3E2200), primaryContainer = Color(0xFF5D3A00), onPrimaryContainer = Color(0xFFFFDDB3))
            MaterialTheme(colorScheme = cs) { Surface(Modifier.fillMaxSize()) { Gate() } }
        }
    }
    override fun onResume() { super.onResume(); resumeTick++ }
}

@Composable
fun Gate() {
    val ctx = LocalContext.current
    @Suppress("UNUSED_VARIABLE") val tick = resumeTick
    val ok = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
        ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    if (ok) Manager() else PermissionScreen()
}

@Composable
fun PermissionScreen() {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { resumeTick++ }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("\uD83E\uDD54", fontSize = 64.sp)
        Text("Potato \uD83E\uDD54 Manager", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("A file manager for game files. Like other file managers it needs the \"All files access\" permission.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 30) ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            else launcher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }) { Text("Allow all files access") }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Manager() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var cwd by remember { mutableStateOf(Fs.root) }
    var entries by remember { mutableStateOf<List<Item>?>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }
    val sel = remember { mutableStateListOf<String>() }
    var clip by remember { mutableStateOf<Pair<List<String>, Boolean>?>(null) }
    var logs by remember { mutableStateOf(listOf("Potato Manager ready.")) }
    var showPotato by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    var potatoPaths by remember { mutableStateOf(listOf<String>()) }
    @Suppress("UNUSED_VARIABLE") val rt = resumeTick

    fun log(s: String) { logs = (logs + s).takeLast(600) }
    fun toggle(p: String) { if (p in sel) sel.remove(p) else sel.add(p) }
    fun go(p: String) { sel.clear(); cwd = p }

    LaunchedEffect(cwd, tick, rt) { entries = withContext(Dispatchers.IO) { Fs.list(ctx, cwd) } }
    BackHandler(enabled = sel.isNotEmpty() || cwd != Fs.root) { if (sel.isNotEmpty()) sel.clear() else go(File(cwd).parent ?: Fs.root) }

    fun work(label: String, block: () -> Unit) {
        scope.launch(Dispatchers.IO) {
            try { block(); log("$label: done") } catch (t: Throwable) { log("$label failed: ${t.message}") }
            tick++
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp)) {
            Text("Potato \uD83E\uDD54 Manager", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(cwd.removePrefix(Fs.root).ifEmpty { "/" }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (cwd != Fs.root) FilledTonalButton(onClick = { go(File(cwd).parent ?: Fs.root) }) { Text("\u2191 Up") }
            if (sel.isNotEmpty()) {
                val list = entries ?: emptyList()
                FilledTonalButton(onClick = { sel.clear(); sel.addAll(list.map { it.path }) }) { Text("All") }
                FilledTonalButton(onClick = { clip = sel.toList() to false; log("Copied ${sel.size} item(s)"); sel.clear() }) { Text("Copy") }
                FilledTonalButton(onClick = { clip = sel.toList() to true; log("Cut ${sel.size} item(s)"); sel.clear() }) { Text("Cut") }
                FilledTonalButton(onClick = { confirmDel = true }) { Text("Delete") }
                FilledTonalButton(onClick = {
                    val paths = sel.toList(); val dir = File(cwd)
                    val out = Fs.uniq(dir, (if (paths.size == 1) File(paths[0]).name else "archive") + ".zip")
                    sel.clear(); work("Zip") { Fs.zipTo(paths, out) }
                }) { Text("Zip") }
                if (sel.size == 1 && sel[0].endsWith(".zip", true)) FilledTonalButton(onClick = {
                    val z = File(sel[0]); val dest = Fs.uniq(File(cwd), z.nameWithoutExtension)
                    sel.clear(); work("Extract") { Fs.unzipTo(z, dest) }
                }) { Text("Extract") }
                Button(onClick = { potatoPaths = sel.toList(); showPotato = true }) { Text("Potato \uD83E\uDD54") }
            }
        }
        clip?.let { c ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${c.first.size} item(s) to ${if (c.second) "move" else "copy"}", Modifier.weight(1f), fontSize = 13.sp)
                Button(onClick = {
                    val dir = File(cwd); clip = null
                    work("Paste") {
                        for (p in c.first) {
                            val src = File(p)
                            val dst = if (c.second) File(dir, src.name).let { if (it.exists()) Fs.uniq(dir, src.name) else it } else Fs.uniq(dir, src.name)
                            if (c.second) { if (!src.renameTo(dst)) { src.copyRecursively(dst, true); src.deleteRecursively() } }
                            else src.copyRecursively(dst, true)
                        }
                    }
                }) { Text("Paste here") }
                TextButton(onClick = { clip = null }) { Text("Cancel") }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            val list = entries
            if (list == null) {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("This folder is protected by Android 11+.", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("To open Android/data, install and start Shizuku, then allow it here.", textAlign = TextAlign.Center, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { try { Shizuku.requestPermission(100) } catch (t: Throwable) { log("Shizuku is not running") } }) { Text("Allow Shizuku") }
                        FilledTonalButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))) }) { Text("Get Shizuku") }
                        TextButton(onClick = { tick++ }) { Text("Retry") }
                    }
                }
            } else if (list.isEmpty()) {
                Text("Empty folder", Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.path }) { e ->
                    val on = e.path in sel
                    Row(
                        Modifier.fillMaxWidth()
                            .background(if (on) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .combinedClickable(
                                onClick = { if (sel.isNotEmpty()) toggle(e.path) else if (e.dir) go(e.path) else Toast.makeText(ctx, e.name, Toast.LENGTH_SHORT).show() },
                                onLongClick = { toggle(e.path) })
                            .padding(horizontal = 16.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (sel.isNotEmpty()) Checkbox(checked = on, onCheckedChange = null)
                        Text(if (e.dir) "\uD83D\uDCC1" else if (e.name.endsWith(".zip", true)) "\uD83D\uDCE6" else "\uD83D\uDCC4", fontSize = 22.sp)
                        Column(Modifier.weight(1f)) {
                            Text(e.name, maxLines = 1)
                            if (!e.dir && e.size > 0) Text(Fs.human(e.size), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        // log + copy button, always at the very bottom
        Surface(tonalElevation = 3.dp) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Text(logs.takeLast(3).joinToString("\n"), fontSize = 11.sp, maxLines = 3, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { clipboard.setText(AnnotatedString(logs.joinToString("\n"))); Toast.makeText(ctx, "Log copied", Toast.LENGTH_SHORT).show() }) { Text("Copy log") }
                    TextButton(onClick = { logs = emptyList() }) { Text("Clear") }
                }
            }
        }
    }

    if (confirmDel) AlertDialog(
        onDismissRequest = { confirmDel = false },
        title = { Text("Delete ${sel.size} item(s)?") },
        text = { Text("This cannot be undone.") },
        confirmButton = { TextButton(onClick = { val ps = sel.toList(); sel.clear(); confirmDel = false; work("Delete") { ps.forEach { File(it).deleteRecursively() } } }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("Cancel") } })

    if (showPotato) PotatoDialog(potatoPaths, ::log, onClose = { showPotato = false; sel.clear() }, onOpen = { p -> showPotato = false; go(p) })
}

@Composable
fun PotatoDialog(paths: List<String>, log: (String) -> Unit, onClose: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var level by remember { mutableIntStateOf(2) }
    var all by remember { mutableStateOf(true) }
    var sample by remember { mutableStateOf<UnityFs.Sample?>(null) }
    var status by remember { mutableStateOf("Looking for a real texture in your selection...") }
    val bmps = remember { mutableStateMapOf<Int, Bitmap?>() }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    LaunchedEffect(paths) {
        val found = withContext(Dispatchers.Default) {
            var best: UnityFs.Sample? = null
            var tried = 0
            loop@ for (p in paths) {
                val files = ArrayList<String>()
                Fs.walk(ctx, p) { f, size -> if (size in 64L..(300L shl 20)) files.add(f) }
                for (f in files) {
                    if (tried >= 60) break@loop
                    if (!Fs.isBundle(ctx, f)) continue
                    tried++
                    val bytes = try { Fs.read(ctx, f) } catch (t: Throwable) { continue }
                    for (c in UnityFs.samples(bytes, 4)) { if (Preview.decode(c, 0) != null) { best = c; break@loop } }
                }
            }
            best
        }
        sample = found
        status = if (found == null) "No previewable texture found (none with mip levels, or this phone cannot decode their format)." else "Real texture from your selection: ${found.name}"
    }
    val kEff = sample?.let { UnityFs.effKOf(it, level) } ?: 0
    LaunchedEffect(sample, kEff) {
        val s = sample ?: return@LaunchedEffect
        for (k in listOf(0, kEff)) if (!bmps.containsKey(k)) bmps[k] = withContext(Dispatchers.Default) { Preview.decode(s, k) }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text("Potato \uD83E\uDD54  (${paths.size} selected)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(status, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                val s = sample
                if (s != null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((k, label) in listOf(0 to "Original", kEff to LEVELS[level])) {
                            Column(Modifier.weight(1f)) {
                                val b = bmps[k]
                                if (b != null) Image(b.asImageBitmap(), label, Modifier.fillMaxWidth().aspectRatio(s.w.toFloat() / s.h).clip(RoundedCornerShape(10.dp)),
                                    contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low)
                                else Box(Modifier.fillMaxWidth().aspectRatio(s.w.toFloat() / s.h))
                                Text("$label\n${maxOf(1, s.w shr k)}x${maxOf(1, s.h shr k)}", fontSize = 11.sp)
                            }
                        }
                    }
                    Text("${Preview.fmtName(s.tf)}  \u2022  texture memory -${(100 - 100 / (1 shl (2 * kEff)))}%", fontSize = 12.sp)
                }
                Text("Level: ${LEVELS[level]}", fontWeight = FontWeight.SemiBold)
                Slider(value = level.toFloat(), onValueChange = { level = it.toInt() }, valueRange = 0f..6f, steps = 5, enabled = !busy)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = all, onCheckedChange = { all = it }, enabled = !busy)
                    Spacer(Modifier.width(10.dp))
                    Text("Include UI / sprite bundles (UI may look broken)", fontSize = 12.sp)
                }
                if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(progress, fontSize = 11.sp, maxLines = 2) }
                if (result.isNotEmpty()) Text(result, fontSize = 12.sp)
            }
        },
        confirmButton = {
            if (result.contains("Output: ")) TextButton(onClick = { onOpen(result.substringAfter("Output: ").trim()) }) { Text("Open output") }
            else TextButton(enabled = !busy && level > 0, onClick = {
                busy = true; result = ""
                scope.launch {
                    result = try { runPotato(ctx, paths, level, all) { m -> progress = m; log(m) } } catch (t: Throwable) { "Error: ${t.message}" }
                    busy = false
                }
            }) { Text(if (busy) "Working..." else "Start") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onClose) { Text("Close") } })
}
