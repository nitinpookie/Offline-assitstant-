package com.fflite

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.documentfile.provider.DocumentFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val cs = if (Build.VERSION.SDK_INT >= 31) dynamicDarkColorScheme(this) else darkColorScheme()
            MaterialTheme(colorScheme = cs) { Surface(Modifier.fillMaxSize()) { App() } }
        }
    }
}

private val NAMES = listOf("Original", "Lite", "Extra Lite", "Ultra Lite", "Ultra Pro Max", "Extreme", "Koi Limit Nahi")
private const val PKG_FFI = "com.garena.game.ffi"
private const val PKG_MAX = "com.dts.freefiremax"
private val FF_PKGS = setOf("com.dts.freefireth", "com.dts.freefiremax")

private fun steps(pkg: String) = listOf(
    "Free Fire poora band karo (recent apps se bhi hata do).",
    "Backup lo: Android/data/$pkg/files folder kahin copy kar lo.",
    "Zip ZArchiver se extract karo. Andar 'files' naam ka folder milega.",
    "'files' folder ko copy karo.",
    "Android/data/$pkg/ mein jao aur paste karo. Replace / Merge chuno.",
    "Android 13+ par Android/data normal file manager se nahi khulta: Shizuku wala file manager ya ADB chahiye.",
    "Game kholo, pehle training mein check karo. Dikkat ho to backup wapas daal do."
)

private fun stepsFolder(pkg: String) = listOf(
    "Free Fire poora band karo (recent apps se bhi hata do).",
    "Backup lo: Android/data/$pkg/files folder kahin copy kar lo.",
    "Ready folder (FF_LITE_READY) ke andar 'files' folder hai. Use copy karo.",
    "Android/data/$pkg/ mein jao aur paste karo. Replace / Merge chuno.",
    "Android 13+ par Android/data normal file manager se nahi khulta: Shizuku wala file manager ya ADB / aShell (cp -rf) chahiye.",
    "Game kholo, pehle training mein check karo. Dikkat ho to backup wapas daal do."
)

private fun sample(): Bitmap {
    val w = 320; val h = 200
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(b); val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.shader = LinearGradient(0f, 0f, 0f, h * 0.7f, 0xFF3FA9F5.toInt(), 0xFFFFE0B2.toInt(), Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
    p.color = 0xFFFFD54F.toInt(); c.drawCircle(262f, 48f, 26f, p)
    p.color = 0xFF2E7D32.toInt()
    val m = Path(); m.moveTo(0f, h.toFloat()); m.lineTo(75f, 85f); m.lineTo(150f, h.toFloat()); m.close(); c.drawPath(m, p)
    p.color = 0xFF8D6E63.toInt(); c.drawRect(150f, 120f, 310f, 200f, p)
    p.color = 0xFF3E2723.toInt(); p.strokeWidth = 1f
    var y = 120f; while (y < 200f) { c.drawLine(150f, y, 310f, y, p); y += 8f }
    var x = 150f; while (x < 310f) { c.drawLine(x, 120f, x, 200f, p); x += 12f }
    p.color = Color.WHITE; p.textSize = 22f; c.drawText("TEXTURE DETAIL", 12f, 36f, p)
    return b
}

private fun displayName(ctx: Context, u: Uri): String =
    ctx.contentResolver.query(u, null, null, null, null)?.use { if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "game.zip"

private fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

/** Kaam poora hone par toast + halka vibration, taaki pata chal jaye. */
private fun finish(ctx: Context) {
    Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, "FF Lite: kaam poora ho gaya", Toast.LENGTH_LONG).show() }
    try {
        val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
    } catch (e: Throwable) { }
}

private class AppEntry(val pkg: String, val label: String, val icon: ImageBitmap, val game: Boolean)

private fun Drawable.toBmp(sz: Int = 96): Bitmap {
    val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val c = Canvas(b); setBounds(0, 0, sz, sz); draw(c)
    return b
}

/** Phone ke saare launchable apps; jo game hai wo 'game' mark hota hai. */
private fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val seen = HashSet<String>()
    val out = ArrayList<AppEntry>()
    for (ri in pm.queryIntentActivities(q, 0)) {
        val ai = ri.activityInfo.applicationInfo
        val pkg = ai.packageName
        if (pkg == ctx.packageName || !seen.add(pkg)) continue
        val game = pkg in FF_PKGS ||
            (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) ||
            (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        val icon = try { pm.getApplicationIcon(ai).toBmp().asImageBitmap() }
        catch (t: Throwable) { Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888).asImageBitmap() }
        out.add(AppEntry(pkg, pm.getApplicationLabel(ai).toString(), icon, game))
    }
    return out.sortedWith(compareByDescending<AppEntry> { it.pkg in FF_PKGS }.thenBy { it.label.lowercase() })
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppEntry>?>(null) }
    var picked by remember { mutableStateOf<AppEntry?>(null) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    LaunchedEffect(Unit) {
        // Purane Android (10 ya kam) par seedha file access ke liye storage permission
        if (Build.VERSION.SDK_INT in 23..29 &&
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            perm.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        apps = withContext(Dispatchers.IO) { loadApps(ctx) }
    }
    BackHandler(enabled = picked != null) { picked = null }
    val p = picked
    if (p == null) Picker(apps) { picked = it } else Work(p) { picked = null }
}

@Composable
private fun Picker(apps: List<AppEntry>?, onPick: (AppEntry) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("FF Lite", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Game chuno. Baaki sab (files, access, apply) app khud karegi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("Search") }, singleLine = true)
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Games") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Apps") })
        }
        if (apps == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            val list = apps.filter { it.game == (tab == 0) && it.label.contains(q, ignoreCase = true) }
            if (list.isEmpty()) Text(
                if (tab == 0) "Is list mein game nahi mila. 'Apps' tab mein dekho." else "Koi app nahi mila.",
                Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(a) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Image(a.icon, a.label, Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)))
                        Column {
                            Text(a.label, fontWeight = FontWeight.Medium)
                            Text(a.pkg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Check(label: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = null, enabled = enabled)
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 14.sp)
    }
}

@Composable
private fun Work(game: AppEntry, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val pkg = game.pkg
    val base = remember { sample() }
    val ctl = remember { Ctl() }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var tree by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var level by remember { mutableIntStateOf(2) }
    var doApply by remember { mutableStateOf(true) }
    var doZip by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var logs by remember { mutableStateOf(listOf<String>()) }
    var prog by remember { mutableStateOf(Progress()) }
    var now by remember { mutableLongStateOf(0L) }
    var shz by remember { mutableIntStateOf(0) }   // 0 = chalu nahi, 1 = permission chahiye, 2 = tayyar
    var lastApply by remember { mutableStateOf(false) }
    var lastZip by remember { mutableStateOf(false) }
    var backups by remember { mutableIntStateOf(0) }
    var keepOn by remember { mutableStateOf(true) }
    var kw by remember { mutableStateOf("character, avatar, hero, player, fashion, outfit, role") }
    var outTree by remember { mutableStateOf<Uri?>(null) }
    var outName by remember { mutableStateOf("") }
    var mpkg by remember { mutableStateOf(if (pkg == PKG_MAX) PKG_MAX else PKG_FFI) }   // manual folder kis game ka hai
    var noLimit by remember { mutableStateOf(false) }
    var lastFolder by remember { mutableStateOf(false) }

    val manual = uri != null || tree != null
    val applyOn = doApply && !manual
    val zipOn = doZip || manual

    fun refreshShz() { shz = if (!Shz.running()) 0 else if (!Shz.granted()) 1 else 2 }
    DisposableEffect(Unit) {
        val a = Shizuku.OnBinderReceivedListener { refreshShz() }
        val b = Shizuku.OnBinderDeadListener { refreshShz() }
        val c = Shizuku.OnRequestPermissionResultListener { _, _ -> refreshShz() }
        Shizuku.addBinderReceivedListenerSticky(a)
        Shizuku.addBinderDeadListener(b)
        Shizuku.addRequestPermissionResultListener(c)
        refreshShz()
        onDispose {
            Shizuku.removeBinderReceivedListener(a)
            Shizuku.removeBinderDeadListener(b)
            Shizuku.removeRequestPermissionResultListener(c)
        }
    }
    // Kaam chalte waqt screen on rakho, aur timer chalao
    DisposableEffect(busy) { view.keepScreenOn = busy; onDispose { view.keepScreenOn = false } }
    LaunchedEffect(busy) { while (busy) { now = System.currentTimeMillis(); delay(500) } }
    LaunchedEffect(prog.phase) { backups = withContext(Dispatchers.IO) { Backup.of(ctx, pkg).entries().size } }
    BackHandler(enabled = busy) { Toast.makeText(ctx, "Kaam chal raha hai. Pehle 'Rok do' dabao.", Toast.LENGTH_SHORT).show() }

    fun go(restore: Boolean, zipUri: Uri?, outUri: Uri? = null) {
        ctl.stop = false
        val t = tree
        val u = uri
        val gp = if (t != null || u != null) mpkg else pkg
        val ms = if (noLimit) 1 else 32
        val lv = level
        val ap = doApply && t == null && u == null
        val keep = if (keepOn) kw.split(',', ' ', '\n').map { it.trim().lowercase() }.filter { it.isNotEmpty() } else emptyList()
        lastApply = ap && !restore
        lastZip = zipUri != null && !restore
        lastFolder = outUri != null && !restore
        scope.launch(Dispatchers.Default) {
            busy = true
            logs = emptyList()
            prog = Progress(phase = 1, startedAt = System.currentTimeMillis(), note = "Access le raha hu...")
            val lg: (String) -> Unit = { logs = (logs + it).takeLast(200) }
            try {
                val acc: FileAccess? = when {
                    t != null -> TreeAccess(ctx, t)
                    u != null -> ZipAccess(ctx, u)
                    else -> Access.resolve(ctx, pkg, lg)
                }
                if (acc == null) {
                    prog = prog.copy(phase = 4, note = "Game ki files tak access nahi mila. Upar Shizuku card dekho.")
                    return@launch
                }
                if (restore) Runner.restore(ctx, acc, pkg, ctl, lg) { prog = it }
                else Runner.lite(ctx, acc, Options(gp, lv, ap, zipUri, keep, outUri, ms), ctl, lg) { prog = it }
            } catch (e: Throwable) {
                prog = prog.copy(phase = 4, note = "Error: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                busy = false
                if (prog.phase == 3) finish(ctx)
            }
        }
    }

    fun goScan(reportUri: Uri) {
        ctl.stop = false
        val t = tree
        val u = uri
        val keep = if (keepOn) kw.split(',', ' ', '\n').map { it.trim().lowercase() }.filter { it.isNotEmpty() } else emptyList()
        lastApply = false
        lastZip = false
        scope.launch(Dispatchers.Default) {
            busy = true
            logs = emptyList()
            prog = Progress(phase = 1, startedAt = System.currentTimeMillis(), note = "Access le raha hu...")
            val lg: (String) -> Unit = { logs = (logs + it).takeLast(200) }
            try {
                val acc: FileAccess? = when {
                    t != null -> TreeAccess(ctx, t)
                    u != null -> ZipAccess(ctx, u)
                    else -> Access.resolve(ctx, pkg, lg)
                }
                if (acc == null) {
                    prog = prog.copy(phase = 4, note = "Game ki files tak access nahi mila. Upar Shizuku card dekho.")
                    return@launch
                }
                Runner.scan(ctx, acc, keep, reportUri, ctl, lg) { prog = it }
            } catch (e: Throwable) {
                prog = prog.copy(phase = 4, note = "Error: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                busy = false
                if (prog.phase == 3) finish(ctx)
            }
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { uri = u; tree = null; name = displayName(ctx, u); prog = Progress(); logs = emptyList() }
    }
    val pickDir = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) { tree = u; uri = null; name = DocumentFile.fromTreeUri(ctx, u)?.name ?: "?"; prog = Progress(); logs = emptyList() }
    }
    // Zip seedha usi jagah likhi jati hai jo tum chunte ho (cache mein double copy nahi banti)
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { u ->
        if (u != null) go(false, u)
    }

    val pickOut = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) { outTree = u; outName = DocumentFile.fromTreeUri(ctx, u)?.name ?: "?" }
    }

    val scanSave = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { u ->
        if (u != null) goScan(u)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("FF Lite", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Game chuna hai. Level set karo, phir shuru karo.", color = MaterialTheme.colorScheme.onSurfaceVariant)

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("1. Game", fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Image(game.icon, game.label, Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
                    Column(Modifier.weight(1f)) {
                        Text(game.label, fontWeight = FontWeight.Medium)
                        Text(pkg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    FilledTonalButton(onClick = onBack, enabled = !busy) { Text("Badlo") }
                }
                Text(
                    if (!manual) "Files: auto (app khud Android/data se leti hai)" else "Files: manual, $name (${if (mpkg == PKG_MAX) "FF MAX" else "FFI"}), seedha apply nahi hoga",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("2. File access (Shizuku)", fontWeight = FontWeight.SemiBold)
                Text(
                    when (shz) {
                        2 -> "Shizuku tayyar hai. App khud game ki files padhegi aur likhegi, tumhe kuch nahi karna."
                        1 -> "Shizuku chal raha hai, bas ek baar permission do."
                        else -> "Shizuku chalu nahi mila. Android 11+ par game ka data padhne/likhne ke liye Shizuku chahiye: Shizuku app kholo, Start karo. (Android 10 ya kam par bina Shizuku ke bhi chal sakta hai.)"
                    },
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (shz == 1) Button(onClick = { try { Shizuku.requestPermission(100) } catch (e: Throwable) { } }) { Text("Permission do") }
                    if (shz != 2) FilledTonalButton(onClick = {
                        val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                        if (i != null) ctx.startActivity(i) else Toast.makeText(ctx, "Shizuku install nahi hai", Toast.LENGTH_LONG).show()
                    }) { Text("Shizuku kholo") }
                    TextButton(onClick = { refreshShz() }) { Text("Dobara check") }
                }
                Text("Ya zip chuno (manual, seedha apply nahi hota):", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pick.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Zip / file") }
                    if (manual) TextButton(onClick = { uri = null; tree = null; name = ""; outTree = null; outName = "" }, enabled = !busy) { Text("Auto par wapas") }
                }
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Copy kiya hua folder (Shizuku ke bina)", fontWeight = FontWeight.SemiBold)
                Text(
                    "Game ka 'files' folder (Android/data/<game>/files) kisi file manager se apne storage mein copy kar lo, phir yahan chuno. App use badal ke ek naya 'ready' folder banayegi. Wo 'files' folder wapas Android/data/<game>/ mein paste karna hai.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text("Ye folder kis game ka hai?", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Row(Modifier.fillMaxWidth().clickable(enabled = !busy) { mpkg = PKG_FFI }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = mpkg == PKG_FFI, onClick = null, enabled = !busy)
                    Spacer(Modifier.width(8.dp)); Text("Free Fire India (FFI)  $PKG_FFI", fontSize = 13.sp)
                }
                Row(Modifier.fillMaxWidth().clickable(enabled = !busy) { mpkg = PKG_MAX }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = mpkg == PKG_MAX, onClick = null, enabled = !busy)
                    Spacer(Modifier.width(8.dp)); Text("Free Fire MAX  $PKG_MAX", fontSize = 13.sp)
                }
                OutlinedButton(onClick = { pickDir.launch(null) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (tree != null) "Copy kiya folder: $name" else "1. Copy kiya hua folder chuno")
                }
                OutlinedButton(onClick = { pickOut.launch(null) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (outTree != null) "Ready folder yahan banega: $outName" else "2. Ready folder kahan banana hai")
                }
                if (tree != null && outTree == null) Text("Ready folder nahi chuna to zip banegi.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (manual) TextButton(onClick = { uri = null; tree = null; name = ""; outTree = null; outName = "" }, enabled = !busy) { Text("Auto par wapas") }
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("3. Level: ${NAMES[level]}", fontWeight = FontWeight.SemiBold)
                val sc = 1 shl level
                val small = remember(level) { Bitmap.createScaledBitmap(base, maxOf(8, base.width / sc), maxOf(5, base.height / sc), true) }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for ((label, bmp) in listOf("Original" to base, "Level $level" to small)) {
                        Column(Modifier.weight(1f)) {
                            Image(bmp.asImageBitmap(), label, Modifier.fillMaxWidth().aspectRatio(1.6f).clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low)
                            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Slider(level.toFloat(), { level = it.toInt() }, valueRange = 0f..6f, steps = 5, enabled = !busy)
                Text(if (level == 0) "Kuch nahi badlega." else "Texture size 1/$sc, texture RAM lagbhag 1/${sc * sc}. (Preview sirf sample hai, tumhari asli textures nahi.)",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Check("Koi limit nahi: chhoti textures bhi poori chhoti karo (warna 32 px se neeche nahi jaati)", noLimit, !busy) { noLimit = it }
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Character saaf, baaki sab potato", fontWeight = FontWeight.SemiBold)
                Check("Ye naam wali textures saaf rakho (baaki sab level ke hisaab se chhoti)", keepOn, !busy) { keepOn = it }
                OutlinedTextField(kw, { kw = it }, Modifier.fillMaxWidth(), label = { Text("Keywords (comma se alag)") }, enabled = keepOn && !busy)
                Text(
                    "Ye naam ke andaze hain. Asli naam game ke bundles mein hote hain. Pehle 'Scan report' banao (kuch badlega nahi), file mujhe bhej do, main keywords sahi kar dunga. Gun/weapon ke naam yahan mat likhna.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(onClick = { scanSave.launch("FFLite_scan_report.txt") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Scan report banao (kuch badlega nahi)") }
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("4. Kya karna hai", fontWeight = FontWeight.SemiBold)
                Check("Seedha game mein apply karo", applyOn, !manual && !busy) { doApply = it }
                Check("Zip bhi banao (jahan chaho wahan save)", zipOn, !manual && !busy) { doZip = it }
                Text(
                    "Seedha apply: app game band karegi, har file ka original backup rakhegi, nayi file atomic tarike se likhegi aur CRC se check karegi. Kuch galat hua to usi file ka original wapas rakh degi. Backup app ke folder mein rehta hai (app uninstall karne par chala jata hai).",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = {
                        val o = outTree
                        if (manual && o != null) go(false, null, o)
                        else if (zipOn) save.launch("FF_LITE_${NAMES[level].replace(' ', '_')}.zip")
                        else go(false, null)
                    },
                    enabled = level > 0 && !busy && (applyOn || zipOn),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text(if (busy) "Kaam chal raha hai..." else "Shuru karo") }
                if (busy) OutlinedButton(onClick = { ctl.stop = true }, modifier = Modifier.fillMaxWidth()) { Text("Rok do") }
            }
        }

        if (prog.phase != 0) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        when (prog.phase) { 1 -> "Tayyari / files dhundh raha hu"; 2 -> "Kaam chal raha hai"; 3 -> "Ho gaya"; else -> "Ruk gaya" },
                        fontWeight = FontWeight.SemiBold, fontSize = 18.sp
                    )
                    if (prog.phase == 3) LinearProgressIndicator(progress = 1f, modifier = Modifier.fillMaxWidth())
                    else if (prog.total > 0 && prog.phase == 2) LinearProgressIndicator(progress = prog.done.toFloat() / prog.total, modifier = Modifier.fillMaxWidth())
                    else if (prog.phase < 3) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    val el = (if (prog.endedAt > 0) prog.endedAt else now) - prog.startedAt
                    Text(
                        (if (prog.total > 0) "${prog.done} / ${prog.total}  (${prog.done * 100 / prog.total}%)" else "${prog.done} dekhi") + "  •  ${fmt(maxOf(0L, el))}",
                        fontWeight = FontWeight.Medium
                    )
                    if (prog.current.isNotEmpty() && prog.phase < 3) Text("Abhi: ${prog.current}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Ho gayi: ${prog.changed} (textures ${prog.textures})  •  Same: ${prog.unchanged}  •  Fail: ${prog.failed}  •  Skip: ${prog.skipped}", fontSize = 13.sp)
                    if (prog.note.isNotEmpty()) Text(prog.note, color = if (prog.phase == 4) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    if (logs.isNotEmpty()) Text(logs.takeLast(6).joinToString("\n"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (prog.phase == 3) Button(onClick = {
                        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
                        if (i != null) ctx.startActivity(i)
                    }) { Text("Game kholo") }
                }
            }
        }

        if (backups > 0 && !manual && !busy) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Original wapas lagao", fontWeight = FontWeight.SemiBold)
                    Text("$backups files ka original backup hai. Restore dabao to game ki files pehle jaisi ho jayengi.",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = { go(true, null) }) { Text("Restore karo") }
                }
            }
        }

        if (prog.phase == 3 && lastFolder) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Ready folder ko kahan paste karna hai", fontWeight = FontWeight.SemiBold)
                    stepsFolder(mpkg).forEachIndexed { i, s -> Text("${i + 1}. $s", fontSize = 14.sp) }
                    Text("Modified game files se ban ka risk hota hai. Apna risk samajh ke hi use karo.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                }
            }
        }

        if (prog.phase == 3 && lastZip && !lastApply) {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Zip ko kahan paste karna hai", fontWeight = FontWeight.SemiBold)
                    steps(if (manual) mpkg else pkg).forEachIndexed { i, s -> Text("${i + 1}. $s", fontSize = 14.sp) }
                    Text("Modified game files se ban ka risk hota hai. Apna risk samajh ke hi use karo.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
