package com.fflite

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.documentfile.provider.DocumentFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.io.File
import java.util.zip.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val cs = if (Build.VERSION.SDK_INT >= 31) dynamicDarkColorScheme(this) else darkColorScheme()
            MaterialTheme(colorScheme = cs) { Surface(Modifier.fillMaxSize()) { App() } }
        }
    }
}

private val NAMES = listOf("Original", "Lite", "Extra Lite", "Ultra Lite", "Ultra Pro Max")

private fun steps(pkg: String) = listOf(
    "Free Fire poora band karo (recent apps se bhi hata do).",
    "Backup lo: Android/data/$pkg/files folder kahin copy kar lo.",
    "Zip download karo aur ZArchiver se extract karo. Andar 'files' naam ka folder milega.",
    "'files' folder ko copy karo.",
    "Android/data/$pkg/ mein jao aur paste karo. Replace / Merge chuno.",
    "Android 13+ par Android/data normal file manager se nahi khulta: Shizuku wala file manager ya ADB chahiye.",
    "Game kholo, pehle training mein check karo. Dikkat ho to backup wapas daal do."
)

private fun pasteText(pkg: String) = "FF LITE\n\nIs zip ke andar 'files' folder hai.\nUse copy karke yahan paste karo (Merge/Replace):\n  Android/data/$pkg/\n\nPehle apna original 'files' folder backup kar lo.\n"

private fun sample(): Bitmap {
    val w = 320; val h = 200
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(b); val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.shader = LinearGradient(0f, 0f, 0f, h * 0.7f, 0xFF3FA9F5.toInt(), 0xFFFFE0B2.toInt(), Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
    p.color = 0xFFFFD54F.toInt(); c.drawCircle(262f, 48f, 26f, p)
    p.color = 0xFF2E7D32.toInt()
    val m = Path(); m.moveTo(0f, h.toFloat()); m.lineTo(75f, 85f); m.lineTo(150f, h.toFloat()); m.close(); c.drawPath(m, p)
    p.color = 0xFF8D6E63.toInt(); c.drawRect(150f, 120f, 310f, 200f, p)
    p.color = 0xFF3E2723.toInt(); p.strokeWidth = 1f
    var y = 120f; while (y < 200f) { c.drawLine(150f, y, 310f, y, p); y += 8f }
    var x = 150f; while (x < 310f) { c.drawLine(x, 120f, x, 200f, p); x += 12f }
    p.color = Color.WHITE; p.textSize = 22f; c.drawText("TEXTURE DETAIL", 12f, 36f, p)
    return b
}

private fun displayName(ctx: Context, u: Uri): String =
    ctx.contentResolver.query(u, null, null, null, null)?.use { if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "game.zip"

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val base = remember { sample() }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var tree by remember { mutableStateOf<Uri?>(null) }
    var pkg by remember { mutableStateOf("com.dts.freefireth") }
    var name by remember { mutableStateOf("") }
    var level by remember { mutableIntStateOf(2) }
    var busy by remember { mutableStateOf(false) }
    var logs by remember { mutableStateOf(listOf<String>()) }
    var result by remember { mutableStateOf<File?>(null) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { uri = u; tree = null; name = displayName(ctx, u); result = null; logs = emptyList() }
    }
    val pickDir = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) { tree = u; uri = null; name = "Folder: " + (DocumentFile.fromTreeUri(ctx, u)?.name ?: "?"); result = null; logs = emptyList() }
    }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { u ->
        if (u != null) scope.launch(Dispatchers.IO) {
            ctx.contentResolver.openOutputStream(u)?.use { o -> result!!.inputStream().use { it.copyTo(o) } }
            withContext(Dispatchers.Main) { Toast.makeText(ctx, "Zip save ho gayi", Toast.LENGTH_LONG).show() }
        }
    }

    fun run() = scope.launch(Dispatchers.Default) {
        busy = true; logs = emptyList(); result = null
        try {
            val out = File(ctx.cacheDir, "FF_LITE.zip")
            var total = 0; var files = 0
            val key = "contentcache/"
            ZipOutputStream(out.outputStream().buffered()).use { zout ->
                zout.setLevel(Deflater.NO_COMPRESSION)
                fun handle(path: String, read: () -> ByteArray) {
                    val i = path.indexOf(key)
                    val fn = path.substringAfterLast('/')
                    if (i < 0 || '.' !in fn || fn.endsWith(".html")) return
                    val bytes = read()
                    if (bytes.size < 64 || String(bytes, 0, 7) != "UnityFS") return
                    logs = logs + "Bundle: ${fn.substringBefore('.')}"
                    val (nb, n) = UnityFs.process(bytes, level) { logs = logs + it }
                    if (n > 0) {
                        zout.putNextEntry(ZipEntry("files/" + path.substring(i))); zout.write(nb); zout.closeEntry()
                        total += n; files++; logs = logs + "  $n textures chhoti hui"
                    }
                }
                fun walk(d: DocumentFile, path: String) {
                    for (f in d.listFiles()) {
                        val p = path + "/" + (f.name ?: "")
                        if (f.isDirectory) walk(f, p)
                        else if (key in p && f.length() in 64L..(250L shl 20))
                            handle(p) { ctx.contentResolver.openInputStream(f.uri)!!.use { it.readBytes() } }
                    }
                }
                if (tree != null) {
                    val root = DocumentFile.fromTreeUri(ctx, tree!!)!!
                    walk(root, root.name ?: "")
                } else ZipInputStream(ctx.contentResolver.openInputStream(uri!!)!!.buffered()).use { zin ->
                    while (true) {
                        val e = zin.nextEntry ?: break
                        if (!e.isDirectory && key in e.name) handle(e.name) { zin.readBytes() }
                    }
                }
                if (files > 0) { zout.putNextEntry(ZipEntry("PASTE_KAHAN.txt")); zout.write(pasteText(pkg).toByteArray()); zout.closeEntry() }
            }
            if (total == 0) logs = logs + "Koi texture nahi badli. 'contentcache' wale bundles nahi mile, ya unme mip levels wali textures nahi hain."
            else { logs = logs + "Ho gaya: $files bundles, $total textures."; result = out }
        } catch (t: Throwable) { logs = logs + "Error: ${t.message}" }
        busy = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("FF Lite", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Zip chuno, smoothness level set karo, nayi lite zip pao.", color = MaterialTheme.colorScheme.onSurfaceVariant)

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("1. Game upload", fontWeight = FontWeight.SemiBold)
                Text(if (uri == null && tree == null) "Game ka data abhi nahi chuna" else name, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { pick.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Zip / file") }
                    FilledTonalButton(onClick = { pickDir.launch(null) }, enabled = !busy) { Text("Folder") }
                }
                OutlinedTextField(pkg, { pkg = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Game package name") }, singleLine = true, enabled = !busy)
                Text("Game ka 'contentcache' folder (ya uski zip) chuno. Android 11+ par Android/data seedha nahi khulta, to pehle use Download mein copy kar lo.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("2. Level: ${NAMES[level]}", fontWeight = FontWeight.SemiBold)
                val sc = 1 shl level
                val small = remember(level) { Bitmap.createScaledBitmap(base, maxOf(8, base.width / sc), maxOf(5, base.height / sc), true) }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for ((label, bmp) in listOf("Original" to base, "Level $level" to small)) {
                        Column(Modifier.weight(1f)) {
                            Image(bmp.asImageBitmap(), label, Modifier.fillMaxWidth().aspectRatio(1.6f).clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low)
                            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Slider(level.toFloat(), { level = it.toInt() }, valueRange = 0f..4f, steps = 3, enabled = !busy)
                Text(if (level == 0) "Kuch nahi badlega." else "Texture size 1/$sc, texture RAM lagbhag 1/${sc * sc}. (Preview sirf sample hai, tumhari asli textures nahi.)",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Button(onClick = { run() }, enabled = (uri != null || tree != null) && level > 0 && !busy, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text(if (busy) "Ban raha hai..." else "3. Lite zip banao")
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (logs.isNotEmpty()) Text(logs.takeLast(8).joinToString("\n"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (result != null) {
            Button(onClick = { save.launch("FF_LITE_${NAMES[level].replace(' ', '_')}.zip") }, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Zip download karo") }
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Ab kahan paste karna hai", fontWeight = FontWeight.SemiBold)
                    steps(pkg).forEachIndexed { i, s -> Text("${i + 1}. $s", fontSize = 14.sp) }
                    Text("Modified game files se ban ka risk hota hai. Apna risk samajh ke hi use karo.", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
