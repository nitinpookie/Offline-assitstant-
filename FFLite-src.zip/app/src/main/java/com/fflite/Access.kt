package com.fflite

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.CRC32
import java.util.zip.ZipInputStream

/** rel = "contentcache/...." wala path, size = bytes (-1 = pata nahi), read = poori file padh ke do. */
typealias Visit = (rel: String, size: Long, read: () -> ByteArray) -> Unit

fun crcOf(f: File): Long {
    val c = CRC32()
    val buf = ByteArray(1 shl 16)
    FileInputStream(f).use { i ->
        while (true) {
            val n = i.read(buf)
            if (n < 0) break
            c.update(buf, 0, n)
        }
    }
    return c.value
}

/** Game ki files tak pahunchne ka ek tareeka: padhna, (agar ho sake to) likhna, verify karna. */
abstract class FileAccess {
    abstract val label: String
    open val countable: Boolean get() = true      // false = pehle se list nahi ban sakti (stream zip)
    open val canWrite: Boolean get() = false
    abstract fun walk(visit: Visit)
    open fun write(rel: String, data: ByteArray) { throw UnsupportedOperationException() }
    open fun crc(rel: String): Long { throw UnsupportedOperationException() }
    open fun stop(pkg: String) { throw UnsupportedOperationException() }
}

/** Seedha File API (Android 10 ya kam, root, ya jab system de de). */
class DirectAccess(private val base: File, private val writable: Boolean) : FileAccess() {
    override val label = "seedha"
    override val canWrite: Boolean get() = writable

    override fun walk(visit: Visit) {
        val root = File(base, "contentcache")
        root.walkTopDown().filter { it.isFile }.forEach { x ->
            visit("contentcache/" + x.relativeTo(root).path, x.length()) { x.readBytes() }
        }
    }

    override fun write(rel: String, data: ByteArray) {
        val dest = File(base, rel)
        val tmp = File(dest.path + ".fflite_tmp")
        try {
            FileOutputStream(tmp).use { it.write(data); it.fd.sync() }
            if (tmp.length() != data.size.toLong()) throw IOException("size match nahi hui")
            if (!tmp.renameTo(dest)) throw IOException("rename nahi hua")
        } finally {
            if (tmp.exists()) tmp.delete()
        }
        if (crcOf(dest) != crc32(data)) throw IOException("verify fail (CRC)")
    }

    override fun crc(rel: String): Long = crcOf(File(base, rel))
}

/** Shizuku ke shell process se: Android 11+ par bhi Android/data padh/likh sakta hai. */
class ShizukuAccess(private val svc: IFileService, private val base: String) : FileAccess() {
    override val label = "Shizuku"
    override val canWrite: Boolean get() = true

    override fun walk(visit: Visit) = walkShz(svc, "$base/contentcache", "contentcache/", visit)

    override fun write(rel: String, data: ByteArray) {
        val dest = "$base/$rel"
        val tmp = "$dest.fflite_tmp"
        try {
            ParcelFileDescriptor.AutoCloseOutputStream(svc.openWrite(tmp)).use { it.write(data) }
            if (!svc.commit(tmp, dest, data.size.toLong())) throw IOException("commit nahi hua (size/rename)")
        } catch (e: Throwable) {
            try { svc.delete(tmp) } catch (e2: Throwable) { }
            throw e
        }
        if (svc.crc32(dest) != crc32(data)) throw IOException("verify fail (CRC)")
    }

    override fun crc(rel: String): Long = svc.crc32("$base/$rel")

    override fun stop(pkg: String) { svc.forceStop(pkg) }

    private fun walkShz(svc: IFileService, dir: String, rel: String, visit: Visit) {
        var off = 0
        while (true) {
            val page = svc.list(dir, off, 400) ?: break
            for (e in page) {
                val p = e.split('\t')
                if (p[0] == "d") walkShz(svc, "$dir/${p[1]}", "$rel${p[1]}/", visit)
                else visit(rel + p[2], p[1].toLongOrNull() ?: 0L) {
                    ParcelFileDescriptor.AutoCloseInputStream(svc.open("$dir/${p[2]}")).use { it.readBytes() }
                }
            }
            if (page.size < 400) break
            off += 400
        }
    }
}

/** Manual: user ne SAF se folder chuna (sirf padhna). */
class TreeAccess(private val ctx: Context, private val tree: Uri) : FileAccess() {
    override val label = "manual folder"

    override fun walk(visit: Visit) {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: throw IOException("folder khul nahi raha")
        fun rec(d: DocumentFile, path: String) {
            for (f in d.listFiles()) {
                val p = path + "/" + (f.name ?: "")
                if (f.isDirectory) rec(f, p)
                else {
                    val i = p.indexOf("contentcache/")
                    if (i >= 0) visit(p.substring(i), f.length()) {
                        ctx.contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }
                    }
                }
            }
        }
        rec(root, root.name ?: "")
    }
}

/** Manual: user ne contentcache wali zip chuni (stream hoti hai, isliye total pehle se nahi pata). */
class ZipAccess(private val ctx: Context, private val uri: Uri) : FileAccess() {
    override val label = "manual zip"
    override val countable: Boolean get() = false

    override fun walk(visit: Visit) {
        ZipInputStream(ctx.contentResolver.openInputStream(uri)!!.buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val i = e.name.indexOf("contentcache/")
                if (!e.isDirectory && i >= 0) visit(e.name.substring(i), e.size) { zin.readBytes() }
            }
        }
    }
}

object Shz {
    @Volatile var svc: IFileService? = null
    @Volatile private var args: Shizuku.UserServiceArgs? = null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            svc = if (binder != null && binder.pingBinder()) IFileService.Stub.asInterface(binder) else null
        }
        override fun onServiceDisconnected(name: ComponentName?) { svc = null }
    }

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun unbind() {
        val a = args ?: return
        try { Shizuku.unbindUserService(a, conn, true) } catch (e: Throwable) { }
        args = null
    }

    /**
     * Har baar saaf bind: purana (shayad mara hua) bind hata ke naya lagata hai. Pehle 'bound' flag atak jata tha
     * (Shizuku restart ke baad) aur service kabhi connect nahi hoti thi. Teen koshish, har ek ~12 sec.
     */
    suspend fun service(ctx: Context, log: (String) -> Unit = {}): IFileService? {
        svc?.let { if (it.asBinder().pingBinder()) return it }
        svc = null
        try {
            if (Shizuku.isPreV11()) { log("Shizuku bahut purana hai, Play Store / GitHub se update karo."); return null }
        } catch (e: Throwable) { }
        for (attempt in 1..3) {
            unbind()
            try {
                val a = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, FileService::class.java.name))
                    .daemon(false).processNameSuffix("fs").debuggable(false).version(3 + attempt)
                args = a
                Shizuku.bindUserService(a, conn)
            } catch (e: Throwable) {
                log("Shizuku bind error (koshish $attempt): ${e.message ?: e.javaClass.simpleName}")
                delay(800)
                continue
            }
            val got = withTimeoutOrNull(12000) { while (svc == null) delay(150); svc }
            if (got != null) return got
            log("Service abhi tak connect nahi hui (koshish $attempt/3)...")
        }
        unbind()
        return null
    }
}

object Access {
    private const val ROOT = "/storage/emulated/0/Android/data/"
    private fun cands(pkg: String) = listOf("$ROOT$pkg/files/contentcache", "$ROOT$pkg/contentcache")

    /** Game ki 'contentcache' tak pahunchne ka sabse achha raasta khud chunta hai (Shizuku / seedha). */
    suspend fun resolve(ctx: Context, pkg: String, log: (String) -> Unit): FileAccess? {
        // seedha access mil raha ho to (Android 10 ya kam, root)
        var directBase: File? = null
        for (c in cands(pkg)) {
            val f = File(c)
            if (f.isDirectory && f.list()?.isNotEmpty() == true) { directBase = f.parentFile; break }
        }
        if (directBase != null && directBase.canWrite()) {
            log("Access: seedha (padhna + likhna)")
            return DirectAccess(directBase, true)
        }
        // Shizuku: padhna + likhna dono
        if (Shz.running() && Shz.granted()) {
            val info = try { "v${Shizuku.getVersion()}, " + (if (Shizuku.getUid() == 0) "root" else "adb") } catch (e: Throwable) { "?" }
            log("Shizuku se connect ho raha hai ($info)...")
            val svc = Shz.service(ctx, log)
            if (svc == null) {
                log("Shizuku service connect nahi hui. FF Lite ko recents se hata do (force stop), Shizuku chalu rakho, FF Lite dobara kholo aur phir Shuru karo.")
            } else {
                val root = cands(pkg).firstOrNull { try { svc.isDir(it) } catch (e: Throwable) { false } }
                if (root == null) {
                    log("Android/data/$pkg mein 'contentcache' folder nahi mila. Game ek baar kholo aur data download hone do, ya ye game supported nahi hai.")
                    return null
                }
                log("Access: Shizuku (padhna + likhna)")
                return ShizukuAccess(svc, root.substringBeforeLast("/contentcache"))
            }
        }
        if (directBase != null) {
            log("Access: seedha, par sirf padh sakta hu. Seedha apply ke liye Shizuku chahiye.")
            return DirectAccess(directBase, false)
        }
        if (!Shz.running()) log("Shizuku chalu nahi hai. Shizuku app kholo, Start karo, phir dobara try karo.")
        else if (!Shz.granted()) log("Shizuku ki permission nahi mili. 'Permission do' dabao.")
        return null
    }
}
