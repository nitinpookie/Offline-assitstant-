package com.fflite

import android.content.Context
import android.os.Environment
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.IOException
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Used by Access.kt (it lived in the old Runner.kt). */
fun crc32(b: ByteArray): Long {
    val c = CRC32()
    c.update(b, 0, b.size)
    return c.value
}

class Item(val path: String, val name: String, val dir: Boolean, val size: Long)

/** File access for the manager: normal File API first, Shizuku (Android/data on Android 11+) when Android blocks it. */
object Fs {
    val root: String = Environment.getExternalStorageDirectory().path

    private fun restricted(p: String) = p.contains("/Android/data") || p.contains("/Android/obb")

    suspend fun list(ctx: Context, path: String): List<Item>? {
        val arr = File(path).listFiles()
        val raw: List<Item> = if (arr != null && !(arr.isEmpty() && restricted(path))) {
            arr.map { Item(it.path, it.name, it.isDirectory, if (it.isFile) it.length() else 0L) }
        } else if (restricted(path) && Shz.granted()) {
            val svc = Shz.service(ctx) ?: return null
            val out = ArrayList<Item>()
            var off = 0
            while (true) {
                val page = svc.list(path, off, 400) ?: break
                for (e in page) {
                    val p = e.split('\t')
                    if (p[0] == "d") out.add(Item("$path/${p[1]}", p[1], true, 0L))
                    else out.add(Item("$path/${p[2]}", p[2], false, p[1].toLongOrNull() ?: 0L))
                }
                if (page.size < 400) break
                off += 400
            }
            out
        } else return if (arr != null) emptyList() else null
        return raw.sortedWith(compareByDescending<Item> { it.dir }.thenBy { it.name.lowercase() })
    }

    /** Calls visit(path, size) for every file under root (root itself if it is a file). */
    suspend fun walk(ctx: Context, root: String, visit: (String, Long) -> Unit) {
        val f = File(root)
        if (f.isFile) { visit(root, f.length()); return }
        val top = f.listFiles()
        if (top != null && !(top.isEmpty() && restricted(root))) {
            f.walkTopDown().filter { it.isFile }.forEach { visit(it.path, it.length()) }
            return
        }
        if (!Shz.granted()) return
        val svc = Shz.service(ctx) ?: return
        fun rec(dir: String) {
            var off = 0
            while (true) {
                val page = svc.list(dir, off, 400) ?: break
                for (e in page) {
                    val p = e.split('\t')
                    if (p[0] == "d") rec("$dir/${p[1]}") else visit("$dir/${p[2]}", p[1].toLongOrNull() ?: 0L)
                }
                if (page.size < 400) break
                off += 400
            }
        }
        rec(root)
    }

    suspend fun isBundle(ctx: Context, path: String): Boolean {
        val b = ByteArray(7)
        try {
            val f = File(path)
            if (f.isFile && f.canRead()) return f.inputStream().use { it.read(b) == 7 } && String(b) == "UnityFS"
        } catch (t: Throwable) { }
        return try {
            val svc = Shz.service(ctx) ?: return false
            ParcelFileDescriptor.AutoCloseInputStream(svc.open(path)).use { it.read(b) == 7 } && String(b) == "UnityFS"
        } catch (t: Throwable) { false }
    }

    suspend fun read(ctx: Context, path: String): ByteArray {
        val f = File(path)
        if (f.isFile && f.canRead()) try { return f.readBytes() } catch (t: Throwable) { }
        val svc = Shz.service(ctx) ?: throw IOException("No access to $path")
        return ParcelFileDescriptor.AutoCloseInputStream(svc.open(path)).use { it.readBytes() }
    }

    fun human(n: Long): String = when {
        n >= 1L shl 30 -> String.format("%.1f GB", n / 1073741824.0)
        n >= 1L shl 20 -> String.format("%.1f MB", n / 1048576.0)
        n >= 1L shl 10 -> String.format("%.0f KB", n / 1024.0)
        else -> "$n B"
    }

    fun uniq(dir: File, name: String): File {
        var f = File(dir, name)
        val base = name.substringBeforeLast('.', name)
        val ext = if ('.' in name) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (f.exists()) { f = File(dir, "$base ($i)$ext"); i++ }
        return f
    }

    fun zipTo(paths: List<String>, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            for (p in paths) {
                val base = File(p).parentFile ?: continue
                File(p).walkTopDown().forEach { f ->
                    val rel = f.relativeTo(base).path
                    z.putNextEntry(ZipEntry(if (f.isDirectory) "$rel/" else rel))
                    if (f.isFile) f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
        }
    }

    fun unzipTo(zip: File, dest: File) {
        dest.mkdirs()
        val base = dest.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val t = File(dest, e.name)
                if (!t.canonicalPath.startsWith(base)) continue
                if (e.isDirectory) t.mkdirs() else { t.parentFile?.mkdirs(); t.outputStream().use { z.copyTo(it) } }
            }
        }
    }
}
