package com.fflite

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Used by Access.kt (it lived in the old Runner.kt). */
fun crc32(b: ByteArray): Long {
    val c = CRC32()
    c.update(b, 0, b.size)
    return c.value
}

class Item(val path: String, val name: String, val dir: Boolean, val size: Long)

/**
 * File access for the manager. Normal folders: plain File API.
 * Android/data and Android/obb (blocked for normal apps on Android 11+): first the File API (works on Android 10 and below),
 * then the folder access the user granted through the system picker (the ZArchiver way, no Shizuku), then Shizuku.
 */
object Fs {
    val root: String = Environment.getExternalStorageDirectory().path

    /** One short line about how the last list() got in (or why it could not). The screen puts it in the log. */
    @Volatile var note: String = ""

    private val RESTRICTED = Regex("/Android/(data|obb)(/|$)")

    fun restricted(p: String): Boolean = RESTRICTED.containsMatchIn(p)

    /** True when this path must NOT be touched with the plain File API on this phone. */
    private fun blocked(p: String): Boolean = Build.VERSION.SDK_INT >= 30 && restricted(p)

    private suspend fun shz(ctx: Context): IFileService? = if (Shz.granted()) Shz.service(ctx) else null

    private fun sorted(l: List<Item>): List<Item> = l.sortedWith(compareByDescending<Item> { it.dir }.thenBy { it.name.lowercase() })

    private fun shzPages(svc: IFileService, path: String): List<Item> {
        val out = ArrayList<Item>()
        var off = 0
        while (true) {
            val page = svc.list(path, off, 400) ?: break
            for (e in page) {
                val p = e.split('\t')
                if (p[0] == "d") out.add(Item("$path/${p[1]}", p[1], true, 0L))
                else out.add(Item("$path/${p[2]}", p[2], false, p[1].toLongOrNull() ?: 0L))
            }
            if (page.size < 400) break
            off += 400
        }
        return out
    }

    /** null = no access to this folder (the screen then shows the "Allow access" buttons). */
    suspend fun list(ctx: Context, path: String): List<Item>? {
        note = ""
        val arr = File(path).listFiles()
        if (arr != null && (arr.isNotEmpty() || !restricted(path))) {
            return sorted(arr.map { Item(it.path, it.name, it.isDirectory, if (it.isFile) it.length() else 0L) })
        }
        if (!restricted(path)) return null

        // Android/data or Android/obb: first the folder the user granted (fast, needs no Shizuku)
        val viaSaf = Saf.list(ctx, path)
        if (viaSaf != null) {
            note = "Folder access OK: ${viaSaf.size} item(s)"
            return sorted(viaSaf)
        }
        // then Shizuku, only if it is really running and allowed
        if (Shz.granted()) {
            val svc = Shz.service(ctx)
            if (svc != null) {
                note = "Shizuku OK"
                return sorted(shzPages(svc, path))
            }
            note = "Shizuku is running but its service did not connect. Use \"Allow access\" instead."
        } else {
            note = "Not allowed yet (granted: ${Saf.describe(ctx)}). Tap \"Allow access\"."
        }
        return if (Build.VERSION.SDK_INT < 30 && arr != null) emptyList() else null
    }

    suspend fun isDirectory(ctx: Context, path: String): Boolean {
        if (File(path).isDirectory) return true
        if (!restricted(path)) return false
        val st = Saf.stat(ctx, path)
        if (st != null) return st.first
        val svc = shz(ctx)
        if (svc != null) {
            try { return svc.isDir(path) } catch (t: Throwable) { }
        }
        return false
    }

    suspend fun openIn(ctx: Context, path: String): InputStream {
        val f = File(path)
        if (f.isFile && f.canRead()) {
            try { return f.inputStream() } catch (t: Throwable) { }
        }
        val s = Saf.openIn(ctx, path)
        if (s != null) return s
        val svc = shz(ctx)
        if (svc != null) return ParcelFileDescriptor.AutoCloseInputStream(svc.open(path))
        throw IOException("No access to $path")
    }

    suspend fun openOut(ctx: Context, path: String): OutputStream {
        if (!blocked(path)) {
            File(path).parentFile?.mkdirs()
            return FileOutputStream(path)
        }
        val s = Saf.openOut(ctx, path)
        if (s != null) return s
        val svc = shz(ctx)
        if (svc != null) return ParcelFileDescriptor.AutoCloseOutputStream(svc.openWrite(path))
        throw IOException("No write access to $path. Tap \"Allow access\" for Android/data first.")
    }

    suspend fun mkdirs(ctx: Context, path: String) {
        if (!blocked(path)) { File(path).mkdirs(); return }
        if (Saf.mkdirs(ctx, path)) return
        val svc = shz(ctx)
        if (svc != null) { svc.mkdirs(path); return }
        throw IOException("No write access to $path. Tap \"Allow access\" for Android/data first.")
    }

    suspend fun deleteTree(ctx: Context, path: String) {
        val p = path.trimEnd('/')
        if (p == root || p == "$root/Android" || p == "$root/Android/data" || p == "$root/Android/obb") {
            throw IOException("Refusing to delete a system folder: $p")
        }
        if (!blocked(p)) {
            val f = File(p)
            if (!f.deleteRecursively() && f.exists()) throw IOException("Could not delete $p")
            return
        }
        if (Saf.delete(ctx, p)) return
        val svc = shz(ctx)
        if (svc != null) { svc.deleteTree(p); return }
        throw IOException("No access to delete $p. Tap \"Allow access\" for Android/data first.")
    }

    /** Calls visit(path, size) for every file under root (root itself if it is a file). size -1 = unknown. */
    suspend fun walk(ctx: Context, root: String, visit: (String, Long) -> Unit) {
        val f = File(root)
        if (f.isFile) { visit(root, f.length()); return }
        val top = f.listFiles()
        if (top != null && (top.isNotEmpty() || !restricted(root))) {
            f.walkTopDown().filter { it.isFile }.forEach { visit(it.path, it.length()) }
            return
        }
        if (!isDirectory(ctx, root)) {
            // a single file inside Android/data: find its size in the parent folder
            val e = list(ctx, root.substringBeforeLast('/'))?.firstOrNull { it.path == root }
            if (e != null) visit(root, e.size)
            return
        }
        suspend fun rec(dir: String) {
            val ks = list(ctx, dir) ?: return
            for (k in ks) {
                if (k.dir) rec(k.path) else visit(k.path, k.size)
            }
        }
        rec(root)
    }

    suspend fun isBundle(ctx: Context, path: String): Boolean {
        return try {
            openIn(ctx, path).use { i ->
                val b = ByteArray(7)
                var n = 0
                while (n < 7) {
                    val r = i.read(b, n, 7 - n)
                    if (r < 0) break
                    n += r
                }
                n == 7 && String(b) == "UnityFS"
            }
        } catch (t: Throwable) {
            false
        }
    }

    suspend fun read(ctx: Context, path: String): ByteArray = openIn(ctx, path).use { it.readBytes() }

    fun human(n: Long): String = when {
        n >= 1L shl 30 -> String.format("%.1f GB", n / 1073741824.0)
        n >= 1L shl 20 -> String.format("%.1f MB", n / 1048576.0)
        n >= 1L shl 10 -> String.format("%.0f KB", n / 1024.0)
        else -> "$n B"
    }

    fun uniq(dir: File, name: String): File {
        var f = File(dir, name)
        val base = name.substringBeforeLast('.', name)
        val ext = if ('.' in name) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (f.exists()) { f = File(dir, "$base ($i)$ext"); i++ }
        return f
    }

    /** A name that does not exist yet in dir (works for every kind of folder). */
    suspend fun uniqName(ctx: Context, dir: String, name: String): String {
        val taken = HashSet<String>()
        list(ctx, dir)?.forEach { taken.add(it.name) }
        if (name !in taken) return name
        val base = name.substringBeforeLast('.', name)
        val ext = if ('.' in name) "." + name.substringAfterLast('.') else ""
        var i = 1
        var n = "$base ($i)$ext"
        while (n in taken) { i++; n = "$base ($i)$ext" }
        return n
    }

    /** Copy a file or folder (folders are merged, same-name files are overwritten). Works from and to Android/data. */
    suspend fun copyTree(ctx: Context, src: String, dst: String) {
        if (src == dst) return
        if (dst.startsWith("$src/")) throw IOException("Cannot copy a folder into itself")
        if (!blocked(src) && !blocked(dst)) {
            File(src).copyRecursively(File(dst), true)
            return
        }
        copyRec(ctx, src, dst)
    }

    private suspend fun copyRec(ctx: Context, src: String, dst: String) {
        if (isDirectory(ctx, src)) {
            mkdirs(ctx, dst)
            val ks = list(ctx, src) ?: throw IOException("Cannot open $src")
            for (k in ks) copyRec(ctx, k.path, "$dst/${k.name}")
        } else {
            openIn(ctx, src).use { i -> openOut(ctx, dst).use { o -> i.copyTo(o) } }
        }
    }

    suspend fun move(ctx: Context, src: String, dst: String) {
        if (src == dst) return
        if (!blocked(src) && !blocked(dst) && File(src).renameTo(File(dst))) return
        copyTree(ctx, src, dst)
        deleteTree(ctx, src)
    }

    suspend fun zipTo(ctx: Context, paths: List<String>, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            suspend fun rec(p: String, rel: String) {
                if (isDirectory(ctx, p)) {
                    z.putNextEntry(ZipEntry("$rel/"))
                    z.closeEntry()
                    val ks = list(ctx, p) ?: return
                    for (k in ks) rec(k.path, "$rel/${k.name}")
                } else {
                    z.putNextEntry(ZipEntry(rel))
                    openIn(ctx, p).use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
            for (p in paths) rec(p, p.substringAfterLast('/'))
        }
    }

    suspend fun unzipTo(ctx: Context, zip: String, dest: String) {
        mkdirs(ctx, dest)
        ZipInputStream(openIn(ctx, zip).buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val rel = e.name.replace('\\', '/').trim('/')
                if (rel.isEmpty() || rel.split('/').any { it == ".." }) continue
                val target = "$dest/$rel"
                if (e.isDirectory) mkdirs(ctx, target)
                else openOut(ctx, target).use { o -> z.copyTo(o) }
            }
        }
    }
}
