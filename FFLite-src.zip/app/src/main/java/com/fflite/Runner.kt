package com.fflite

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class Stop : RuntimeException()
class Ctl { @Volatile var stop = false }
class Options(val pkg: String, val level: Int, val apply: Boolean, val zipUri: Uri?, val keep: List<String> = emptyList())

/** phase: 0 = kuch nahi, 1 = tayyari/scan, 2 = kaam chal raha hai, 3 = ho gaya, 4 = ruka/error */
data class Progress(
    val phase: Int = 0, val done: Int = 0, val total: Int = 0, val current: String = "",
    val changed: Int = 0, val textures: Int = 0, val unchanged: Int = 0, val failed: Int = 0, val skipped: Int = 0,
    val note: String = "", val startedAt: Long = 0L, val endedAt: Long = 0L
)

fun crc32(b: ByteArray): Long {
    val c = CRC32()
    c.update(b, 0, b.size)
    return c.value
}

fun pasteText(pkg: String) = "FF LITE\n\nIs zip ke andar 'files' folder hai.\nUse copy karke yahan paste karo (Merge/Replace):\n  Android/data/$pkg/\n\nPehle apna original 'files' folder backup kar lo.\n"

class St(val crc: Long, val level: Int)

/**
 * Original files ka backup (app ke apne folder mein) + record ki kya lagaya gaya.
 * Isse: (1) level badalne par hamesha ORIGINAL se shuru hota hai (lite par lite nahi chadhta),
 * (2) Restore ho sakta hai, (3) game update aaye to purana backup galti se wapas nahi lagta.
 */
class Backup private constructor(private val dir: File) {
    private val files = File(dir, "files")
    private val man = File(dir, "manifest.tsv")
    private val map = LinkedHashMap<String, St>()

    class Res(val kind: Int, val orig: ByteArray?)

    init {
        dir.mkdirs()
        if (man.isFile) man.forEachLine { ln ->
            val p = ln.split('\t')
            if (p.size >= 2) {
                val c = p[1].toLongOrNull()
                if (c == null) map.remove(p[0]) else map[p[0]] = St(c, p.getOrNull(2)?.toIntOrNull() ?: 0)
            }
        }
    }

    companion object {
        const val FRESH = 0     // abhi ki file hi original hai
        const val FROM_BK = 1   // abhi ki file hamari lagayi hui hai, original backup se lo
        const val SAME = 2      // isi level par pehle se lagi hui hai

        fun of(ctx: Context, pkg: String): Backup =
            Backup(File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "backup/$pkg"))
    }

    fun entries(): List<Pair<String, St>> = map.entries.map { Pair(it.key, it.value) }
    fun file(rel: String) = File(files, rel)

    fun resolve(rel: String, cur: ByteArray, level: Int): Res {
        val st = map[rel] ?: return Res(FRESH, cur)
        if (crc32(cur) != st.crc) return Res(FRESH, cur)          // game ne file badal di: ye naya original hai
        if (st.level == level) return Res(SAME, null)
        val f = file(rel)
        if (!f.isFile) throw IllegalStateException("original ka backup nahi mila (game data dobara download karo)")
        return Res(FROM_BK, f.readBytes())
    }

    fun save(rel: String, orig: ByteArray) {
        val f = file(rel)
        f.parentFile?.mkdirs()
        val tmp = File(f.path + ".tmp")
        FileOutputStream(tmp).use { it.write(orig); it.fd.sync() }
        if (!tmp.renameTo(f)) { tmp.delete(); throw IOException("backup rename nahi hua") }
    }

    /** Game file badalne SE PEHLE likha jata hai, taaki beech mein kuch ho to bhi record sahi rahe. */
    fun mark(rel: String, crc: Long, level: Int) {
        man.appendText("$rel\t$crc\t$level\n")
        map[rel] = St(crc, level)
    }

    fun drop(rel: String) {
        man.appendText("$rel\t-\n")
        map.remove(rel)
        file(rel).delete()
    }
}

private class Item(val rel: String, val size: Long, val read: () -> ByteArray)

object Runner {
    private const val KEY = "contentcache/"
    private const val MAX_FILE = 250L * 1024 * 1024
    private const val ZIP_LIMIT = 3_900_000_000L

    /** 0 = chhodo, 1 = theek, 2 = bahut bada (RAM kam padegi) */
    private fun cand(rel: String, size: Long, limit: Long): Int {
        val fn = rel.substringAfterLast('/')
        if (!rel.contains(KEY) || '.' !in fn || fn.endsWith(".html") || fn.endsWith(".fflite_tmp")) return 0
        if (size in 0L..63L) return 0
        if (size > limit) return 2
        return 1
    }

    fun lite(ctx: Context, acc: FileAccess, o: Options, ctl: Ctl, log: (String) -> Unit, out: (Progress) -> Unit) {
        val t0 = System.currentTimeMillis()
        var done = 0; var total = 0; var changed = 0; var textures = 0
        var unchanged = 0; var failed = 0; var skipped = 0
        var applied = 0; var zipped = 0
        var current = ""
        fun push(phase: Int = 2, note: String = "") {
            out(Progress(phase, done, total, current, changed, textures, unchanged, failed, skipped, note, t0,
                if (phase >= 3) System.currentTimeMillis() else 0L))
        }

        val bk: Backup? = if (acc.canWrite) Backup.of(ctx, o.pkg) else null
        val applyOn = o.apply && bk != null
        if (o.apply && !applyOn) log("Seedha apply nahi ho sakta (write access nahi hai).")
        if (!applyOn && o.zipUri == null) {
            push(4, "Apply ke liye Shizuku (write access) chahiye. Upar Shizuku card dekho ya zip option chuno.")
            return
        }
        val limit = minOf(MAX_FILE, Runtime.getRuntime().maxMemory() / 5)
        val tag = o.level * 100000 + (o.keep.sorted().joinToString(",").hashCode() and 0xFFFF)   // level + keywords

        val zout: ZipOutputStream? = o.zipUri?.let { u ->
            ZipOutputStream(BufferedOutputStream(ctx.contentResolver.openOutputStream(u, "wt")!!, 1 shl 16)).also {
                it.setLevel(Deflater.NO_COMPRESSION)   // bundles pehle se compressed hain
            }
        }
        var zipOn = zout != null
        var zipBad = false
        var zipBytes = 0L

        fun addZip(rel: String, data: ByteArray): Boolean {
            val z = zout ?: return false
            if (!zipOn) return false
            if (zipBytes + data.size > ZIP_LIMIT) {
                zipOn = false
                log("Zip 4 GB limit par pahunchi, baaki files zip mein nahi jayengi.")
                return false
            }
            return try {
                z.putNextEntry(ZipEntry("files/$rel")); z.write(data); z.closeEntry()
                zipBytes += data.size; zipped++
                true
            } catch (e: IOException) {
                zipOn = false; zipBad = true
                log("Zip likhne mein error: ${e.message}")
                false
            }
        }

        fun one(rel: String, read: () -> ByteArray) {
            if (ctl.stop) throw Stop()
            val fn = rel.substringAfterLast('/')
            current = fn.substringBefore('.')
            push()
            try {
                val cur = read()
                if (cur.size < 64 || String(cur, 0, 7) != "UnityFS") { unchanged++; return }
                val rs = if (bk != null) bk.resolve(rel, cur, tag) else null
                if (rs != null && rs.kind == Backup.SAME) {      // pehle se isi level par
                    unchanged++
                    addZip(rel, cur)
                    return
                }
                val orig = rs?.orig ?: cur
                val res = UnityFs.process(orig, o.level, o.keep, null) { log(it) }
                val nb = res.first
                val n = res.second
                if (n == 0) { unchanged++; return }
                if (nb.size != orig.size) { failed++; log("  skip $fn: size badal gayi"); return }
                var did = false
                if (applyOn && bk != null) {
                    if (rs == null || rs.kind == Backup.FRESH) bk.save(rel, orig)   // original ka backup
                    bk.mark(rel, crc32(nb), tag)
                    try {
                        acc.write(rel, nb)                                          // atomic write + CRC verify
                    } catch (e: Throwable) {
                        try { acc.write(rel, orig) } catch (e2: Throwable) { log("  DIKKAT: $fn original wapas nahi rakhi ja saki, Restore dabao.") }
                        throw e
                    }
                    applied++; did = true
                }
                if (addZip(rel, nb)) did = true
                if (did) { changed++; textures += n } else { failed++; log("  $fn kahin save nahi hui") }
            } catch (s: Stop) {
                throw s
            } catch (e: Throwable) {
                failed++
                log("  skip $fn: ${e.message ?: e.javaClass.simpleName}")
            }
        }

        var stopped = false
        var fatal: Throwable? = null
        try {
            if (applyOn) {
                push(1, "Game band kar raha hu...")
                try { acc.stop(o.pkg); log("Game band kiya (force-stop).") }
                catch (e: Throwable) { log("Game khud band kar do (auto band nahi hua).") }
            }
            push(1, "Bundles dhundh raha hu...")
            if (acc.countable) {
                val items = ArrayList<Item>()
                acc.walk { rel, size, read ->
                    if (ctl.stop) throw Stop()
                    when (cand(rel, size, limit)) {
                        1 -> {
                            items.add(Item(rel, size, read))
                            if (items.size % 40 == 0) { done = items.size; current = "${items.size} files mile"; push(1, "Bundles dhundh raha hu...") }
                        }
                        2 -> { skipped++; log("Bada bundle skip (RAM kam): ${rel.substringAfterLast('/')} ${size shr 20} MB") }
                    }
                }
                done = 0; total = items.size; current = ""
                log("${items.size} files mili.")
                push()
                for (x in items) {
                    one(x.rel, x.read)
                    done++
                    push()
                }
            } else {
                acc.walk { rel, size, read ->
                    when (cand(rel, size, limit)) {
                        1 -> { one(rel, read); done++; push() }
                        2 -> { skipped++; log("Bada bundle skip (RAM kam): ${rel.substringAfterLast('/')}") }
                    }
                }
            }
            if (zout != null && zipped > 0 && !zipBad) {
                zout.putNextEntry(ZipEntry("PASTE_KAHAN.txt")); zout.write(pasteText(o.pkg).toByteArray()); zout.closeEntry()
            }
        } catch (s: Stop) {
            stopped = true
        } catch (e: Throwable) {
            fatal = e
        }

        try { zout?.close() } catch (e: Throwable) { zipBad = true }
        if (o.zipUri != null && (zipped == 0 || zipBad)) {
            try { DocumentsContract.deleteDocument(ctx.contentResolver, o.zipUri) } catch (e: Throwable) { }
        }
        current = ""

        val sum = StringBuilder()
        if (changed == 0) sum.append("Kuch nahi badla (koi texture mip-levels wali nahi mili, ya sab pehle se isi level par hain). ")
        if (applied > 0) sum.append("$applied files seedha game mein apply hui (backup + verify OK). ")
        if (zipped > 0 && !zipBad) sum.append("$zipped files zip mein save hui. ")
        if (zipBad) sum.append("Zip kharab ho gayi, hata di. ")
        if (skipped > 0) sum.append("$skipped bade bundles RAM kam hone se skip hue. ")
        if (failed > 0) sum.append("$failed files fail hui (log dekho). ")
        when {
            fatal != null -> push(4, "Error: ${fatal.message ?: fatal.javaClass.simpleName}")
            stopped -> push(4, "Rok diya gaya. Jo files ho chuki thi wo theek hain (Restore se wapas la sakte ho). $sum")
            else -> push(3, sum.toString().trim())
        }
    }

    fun restore(ctx: Context, acc: FileAccess, pkg: String, ctl: Ctl, log: (String) -> Unit, out: (Progress) -> Unit) {
        val t0 = System.currentTimeMillis()
        val bk = Backup.of(ctx, pkg)
        val list = bk.entries()
        val total = list.size
        var done = 0; var restored = 0; var skipped = 0; var failed = 0
        var current = ""
        fun push(phase: Int = 2, note: String = "") {
            out(Progress(phase, done, total, current, restored, 0, 0, failed, skipped, note, t0,
                if (phase >= 3) System.currentTimeMillis() else 0L))
        }
        if (!acc.canWrite) { push(4, "Restore ke liye write access chahiye (Shizuku)."); return }
        push(1, "Game band kar raha hu...")
        try { acc.stop(pkg); log("Game band kiya (force-stop).") } catch (e: Throwable) { log("Game khud band kar do.") }

        var stopped = false
        var fatal: Throwable? = null
        try {
            for ((rel, st) in list) {
                if (ctl.stop) throw Stop()
                current = rel.substringAfterLast('/').substringBefore('.')
                push()
                try {
                    val f = bk.file(rel)
                    if (!f.isFile) {
                        skipped++; log("  skip $current: backup nahi mila"); bk.drop(rel)
                    } else if (acc.crc(rel) != st.crc) {
                        skipped++; log("  skip $current: game ne file badal di (update?), purana backup hata diya"); bk.drop(rel)
                    } else {
                        acc.write(rel, f.readBytes())
                        bk.drop(rel)
                        restored++
                    }
                } catch (e: Throwable) {
                    failed++; log("  fail $current: ${e.message ?: e.javaClass.simpleName}")
                }
                done++
            }
        } catch (s: Stop) {
            stopped = true
        } catch (e: Throwable) {
            fatal = e
        }
        current = ""
        val sum = "$restored files original ho gayi. " + (if (skipped > 0) "$skipped skip. " else "") + (if (failed > 0) "$failed fail. " else "")
        when {
            fatal != null -> push(4, "Error: ${fatal.message ?: fatal.javaClass.simpleName}")
            stopped -> push(4, "Rok diya gaya. $sum")
            else -> push(3, "Restore ho gaya: " + sum.trim())
        }
    }

    /** Kuch badle bina: har bundle ke asset paths aur texture names ek text file mein likhta hai (keywords tune karne ke liye). */
    fun scan(ctx: Context, acc: FileAccess, keep: List<String>, uri: Uri, ctl: Ctl, log: (String) -> Unit, out: (Progress) -> Unit) {
        val t0 = System.currentTimeMillis()
        var done = 0; var total = 0; var matched = 0; var unchanged = 0; var failed = 0; var skipped = 0
        var current = ""
        fun push(phase: Int = 2, note: String = "") {
            out(Progress(phase, done, total, current, matched, 0, unchanged, failed, skipped, note, t0,
                if (phase >= 3) System.currentTimeMillis() else 0L))
        }
        val limit = minOf(MAX_FILE, Runtime.getRuntime().maxMemory() / 5)
        var stopped = false
        var fatal: Throwable? = null
        val w = ctx.contentResolver.openOutputStream(uri, "wt")!!.bufferedWriter()
        try {
            w.write("FF LITE SCAN REPORT\nkeywords: ${keep.joinToString(",")}\n(* = keyword se saaf rakhi jayegi)\n\n")
            push(1, "Bundles dhundh raha hu...")
            val items = ArrayList<Item>()
            acc.walk { rel, size, read ->
                if (ctl.stop) throw Stop()
                when (cand(rel, size, limit)) {
                    1 -> items.add(Item(rel, size, read))
                    2 -> skipped++
                }
            }
            total = items.size
            log("${items.size} files mili.")
            push()
            for (x in items) {
                if (ctl.stop) throw Stop()
                current = x.rel.substringAfterLast('/').substringBefore('.')
                push()
                try {
                    val cur = x.read()
                    if (cur.size < 64 || String(cur, 0, 7) != "UnityFS") { unchanged++ }
                    else {
                        val sb = StringBuilder()
                        UnityFs.process(cur, 1, keep, sb) { }
                        w.write("=== ${x.rel} (${cur.size shr 20} MB)\n")
                        w.write(sb.toString())
                        if (sb.contains("KEYWORD MATCH") || sb.contains("*")) matched++
                    }
                } catch (e: Throwable) {
                    failed++
                    w.write("=== ${x.rel}: error ${e.message}\n")
                }
                done++
                push()
            }
        } catch (s: Stop) {
            stopped = true
        } catch (e: Throwable) {
            fatal = e
        }
        try { w.close() } catch (e: Throwable) { }
        current = ""
        val sum = "Report ban gayi: $done bundles dekhe, $matched mein keyword match mila, $unchanged bundle nahi hain, $failed fail."
        when {
            fatal != null -> push(4, "Error: ${fatal.message ?: fatal.javaClass.simpleName}")
            stopped -> push(4, "Rok diya gaya. $sum")
            else -> push(3, "$sum Ye file mujhe bhej do, keywords sahi kar dunga.")
        }
    }
}
