package com.fflite

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Android/data and Android/obb through the Storage Access Framework. This is how ZArchiver gets in without Shizuku:
 * the user grants the folder once ("Use this folder"), Android remembers it, and we talk to the system
 * document provider. Every function returns null / false when the folder was not granted.
 */
object Saf {
    const val AUTH = "com.android.externalstorage.documents"

    private val COLS = arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE, Document.COLUMN_SIZE)

    private class Kid(val id: String, val name: String, val dir: Boolean, val size: Long)

    /** "/storage/emulated/0/Android/data/x" -> "primary:Android/data/x" */
    fun docId(path: String): String? {
        val r = Fs.root
        if (path != r && !path.startsWith("$r/")) return null
        return "primary:" + path.removePrefix(r).trim('/')
    }

    /** Folders the user granted and Android still remembers: (tree uri, its document id). */
    fun granted(ctx: Context): List<Pair<Uri, String>> {
        return try {
            ctx.contentResolver.persistedUriPermissions
                .filter { it.isReadPermission && it.uri.authority == AUTH && DocumentsContract.isTreeUri(it.uri) }
                .map { Pair(it.uri, DocumentsContract.getTreeDocumentId(it.uri)) }
        } catch (t: Throwable) {
            emptyList()
        }
    }

    /** (tree uri, document id of this path) when a granted folder covers the path. */
    private fun locate(ctx: Context, path: String): Pair<Uri, String>? {
        val id = docId(path) ?: return null
        for (g in granted(ctx)) {
            val tid = g.second
            if (id == tid || id.startsWith("$tid/")) return Pair(g.first, id)
        }
        return null
    }

    private fun docUri(tree: Uri, id: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)

    private fun kids(ctx: Context, tree: Uri, id: String): List<Kid>? {
        return try {
            val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
            ctx.contentResolver.query(uri, COLS, null, null, null)?.use { c ->
                val out = ArrayList<Kid>()
                while (c.moveToNext()) {
                    val name = c.getString(1) ?: continue
                    val dir = c.getString(2) == Document.MIME_TYPE_DIR
                    val size = if (c.isNull(3)) 0L else c.getLong(3)
                    out.add(Kid(c.getString(0), name, dir, size))
                }
                out
            }
        } catch (t: Throwable) {
            null
        }
    }

    /** Short human text for the log: what is granted. */
    fun describe(ctx: Context): String {
        val g = granted(ctx)
        return if (g.isEmpty()) "no folder granted yet" else g.joinToString(", ") { it.second }
    }

    /** Items of a folder, or null when this path is not covered by a granted folder. */
    fun list(ctx: Context, path: String): List<Item>? {
        val id = docId(path) ?: return null
        val loc = locate(ctx, path)
        if (loc == null) {
            // Not granted itself, but the user may have granted single folders below it (for example one game).
            val names = LinkedHashSet<String>()
            for (g in granted(ctx)) {
                val tid = g.second
                if (tid.startsWith("$id/")) names.add(tid.removePrefix("$id/").substringBefore('/'))
            }
            return if (names.isEmpty()) null else names.map { Item("$path/$it", it, true, 0L) }
        }
        val ks = kids(ctx, loc.first, loc.second) ?: return null
        return ks.map { Item("$path/${it.name}", it.name, it.dir, if (it.dir) 0L else it.size) }
    }

    /** (isDirectory, size) or null. */
    fun stat(ctx: Context, path: String): Pair<Boolean, Long>? {
        val loc = locate(ctx, path) ?: return null
        return try {
            val cols = arrayOf(Document.COLUMN_MIME_TYPE, Document.COLUMN_SIZE)
            ctx.contentResolver.query(docUri(loc.first, loc.second), cols, null, null, null)?.use { c ->
                if (c.moveToFirst()) Pair(c.getString(0) == Document.MIME_TYPE_DIR, if (c.isNull(1)) 0L else c.getLong(1)) else null
            }
        } catch (t: Throwable) {
            null
        }
    }

    fun openIn(ctx: Context, path: String): InputStream? {
        val loc = locate(ctx, path) ?: return null
        return try {
            ctx.contentResolver.openInputStream(docUri(loc.first, loc.second))
        } catch (t: Throwable) {
            null
        }
    }

    /** Creates the folder and every missing parent. False when the path is not covered by a granted folder. */
    fun mkdirs(ctx: Context, path: String): Boolean {
        val loc = locate(ctx, path) ?: return false
        val tree = loc.first
        val treeId = DocumentsContract.getTreeDocumentId(tree)
        val rest = loc.second.removePrefix(treeId).trim('/')
        if (rest.isEmpty()) return true
        var cur = treeId
        for (part in rest.split('/')) {
            val have = kids(ctx, tree, cur)?.firstOrNull { it.name == part && it.dir }
            if (have != null) {
                cur = have.id
                continue
            }
            val made: Uri? = try {
                DocumentsContract.createDocument(ctx.contentResolver, docUri(tree, cur), Document.MIME_TYPE_DIR, part)
            } catch (t: Throwable) {
                null
            }
            if (made == null) return false
            cur = DocumentsContract.getDocumentId(made)
        }
        return true
    }

    /** Output stream for a file (created, or overwritten in place). null = path not covered by a granted folder. */
    fun openOut(ctx: Context, path: String): OutputStream? {
        val parent = path.substringBeforeLast('/')
        val name = path.substringAfterLast('/')
        val ploc = locate(ctx, parent) ?: return null
        if (!mkdirs(ctx, parent)) throw IOException("Cannot create folder: $parent")
        val tree = ploc.first
        val cr = ctx.contentResolver
        val have = kids(ctx, tree, ploc.second)?.firstOrNull { it.name == name && !it.dir }
        var target: Uri
        if (have != null) {
            target = docUri(tree, have.id)
        } else {
            val made = DocumentsContract.createDocument(cr, docUri(tree, ploc.second), "application/octet-stream", name)
                ?: throw IOException("Cannot create file: $name")
            target = made
            if (DocumentsContract.getDocumentId(made).substringAfterLast('/') != name) {
                target = DocumentsContract.renameDocument(cr, made, name) ?: made
            }
        }
        return cr.openOutputStream(target, "wt") ?: throw IOException("Cannot open for writing: $name")
    }

    /** Deletes a file or a whole folder. */
    fun delete(ctx: Context, path: String): Boolean {
        val loc = locate(ctx, path) ?: return false
        return try {
            DocumentsContract.deleteDocument(ctx.contentResolver, docUri(loc.first, loc.second))
        } catch (t: Throwable) {
            false
        }
    }
}
