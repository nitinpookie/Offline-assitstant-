package com.fflite

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private val PKG = Regex("^(.*/Android/(?:data|obb)/([^/]+))")

/**
 * Processes every Unity bundle under the selected paths and writes the changed ones to
 * <storage>/Potato Manager/Potato 🥔 by Nixu/<package>/<same relative path as in the game>.
 */
suspend fun runPotato(ctx: Context, paths: List<String>, level: Int, all: Boolean, say: (String) -> Unit): String = withContext(Dispatchers.Default) {
    val m = paths.firstNotNullOfOrNull { PKG.find(it) }
    val pkg = m?.groupValues?.get(2) ?: "selected"
    val pkgDir = m?.groupValues?.get(1) ?: (File(paths.first()).parent ?: Fs.root)
    val out = File(Fs.root, "Potato Manager/Potato \uD83E\uDD54 by Nixu/$pkg")
    val ty = Tally()
    var written = 0; var seen = 0
    val limit = Runtime.getRuntime().maxMemory() / 5
    for (p in paths) {
        val files = ArrayList<Pair<String, Long>>()
        Fs.walk(ctx, p) { f, s -> files.add(f to s) }
        files.sortBy { it.second }                       // small files first, big ones last
        for ((f, size) in files) {
            if (size in 0L..63L) continue
            if (!Fs.isBundle(ctx, f)) continue
            seen++
            val name = f.substringAfterLast('/')
            if (size > limit) { ty.tooBig++; say("Too big for the available memory: $name (${Fs.human(size)})"); continue }
            say("[$seen] $name")
            val bytes = try { Fs.read(ctx, f) } catch (t: Throwable) { ty.readFail++; say("Read failed: $name"); continue }
            val res = try {
                UnityFs.process(bytes, level, emptyList(), null, 4, all, ty) { say(it) }
            } catch (t: Throwable) { ty.bad++; say("Failed: $name (${t.message})"); bytes to 0 }
            if (res.second > 0) {
                val rel = f.removePrefix(pkgDir).trimStart('/')
                val dest = File(out, rel)
                dest.parentFile?.mkdirs()
                dest.writeBytes(res.first)
                if (dest.length() != res.first.size.toLong()) say("Write size mismatch: $rel") else { written++; say("  saved: $rel (${res.second} textures)") }
            }
        }
    }
    val lines = ArrayList<String>()
    lines.add("Bundles found: $seen, changed and saved: $written")
    lines.add("Textures reduced: ${ty.reduced}")
    if (ty.noMip > 0) lines.add("Not reducible: ${ty.noMip} compressed textures with no mip levels (shrinking them needs a texture encoder)")
    if (ty.small > 0) lines.add("Already at the minimum size: ${ty.small}")
    if (ty.unsupported > 0) lines.add("Unsupported texture format: ${ty.unsupported}")
    if (ty.bad > 0) lines.add("Unreadable texture layout: ${ty.bad}")
    if (ty.badVersion > 0) lines.add("Unsupported Unity version: ${ty.badVersion}")
    if (ty.tooBig > 0) lines.add("Too big for memory: ${ty.tooBig}")
    if (ty.readFail > 0) lines.add("Read failures: ${ty.readFail}")
    lines.forEach(say)
    if (written > 0) lines.add("Output: ${out.path}")
    lines.joinToString("\n")
}
