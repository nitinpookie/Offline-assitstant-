package com.fflite

import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileInputStream
import java.util.zip.CRC32
import kotlin.system.exitProcess

/** Ye Shizuku ke shell process mein chalta hai, isliye Android/data ki files padh aur likh sakta hai. */
class FileService : IFileService.Stub() {
    override fun destroy() { exitProcess(0) }

    override fun isDir(path: String): Boolean = File(path).isDirectory

    /** Ek folder ka ek page: "d\tnaam" (folder) ya "f\tsize\tnaam" (file). Binder limit ke liye page-by-page. */
    override fun list(dir: String, offset: Int, limit: Int): Array<String> {
        val all = File(dir).listFiles() ?: return emptyArray()
        all.sortBy { it.name }
        return all.drop(offset).take(limit)
            .map { if (it.isDirectory) "d\t${it.name}" else "f\t${it.length()}\t${it.name}" }
            .toTypedArray()
    }

    override fun open(path: String): ParcelFileDescriptor = guard {
        ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
    }

    /** Temp file likhne ke liye kholta hai (folder bana deta hai, purana content hata deta hai). */
    override fun openWrite(path: String): ParcelFileDescriptor = guard {
        val f = File(path)
        f.parentFile?.mkdirs()
        ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_WRITE_ONLY or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE)
    }

    /** Temp file ka size check karke use asli naam par rename karta hai (ek hi folder mein, atomic). */
    override fun commit(tmp: String, dest: String, size: Long): Boolean {
        val t = File(tmp)
        if (!t.isFile || t.length() != size) return false
        return t.renameTo(File(dest))
    }

    override fun crc32(path: String): Long = guard {
        val c = CRC32()
        val buf = ByteArray(1 shl 16)
        FileInputStream(path).use { i ->
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                c.update(buf, 0, n)
            }
        }
        c.value
    }

    override fun delete(path: String) { File(path).delete() }

    override fun forceStop(pkg: String) {
        if (!Regex("[A-Za-z0-9_.]+").matches(pkg)) throw IllegalArgumentException("bad package")
        guard { Runtime.getRuntime().exec(arrayOf("/system/bin/am", "force-stop", pkg)).waitFor() }
    }

    private inline fun <T> guard(block: () -> T): T =
        try { block() } catch (e: Exception) { throw IllegalStateException(e.message ?: e.javaClass.simpleName) }
}
