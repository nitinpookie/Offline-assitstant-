package com.spudlab.tater

import android.content.Context
import android.content.pm.ApplicationInfo
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** One entry of the list: an installed app, or an APK file chosen in the Files tab. */
class AppRow(val label: String, val pkg: String, val ver: String, val files: List<File>, val size: Long, val fromFile: Boolean)

private fun loadApps(ctx: Context): List<AppRow> {
    val pm = ctx.packageManager
    val out = ArrayList<AppRow>()
    for (ai in pm.getInstalledApplications(0)) {
        if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
        try {
            val fl = ArrayList<File>()
            fl.add(File(ai.sourceDir))
            val sp = ai.splitSourceDirs
            if (sp != null) for (s in sp) fl.add(File(s))
            val ver = try { pm.getPackageInfo(ai.packageName, 0).versionName ?: "" } catch (t: Throwable) { "" }
            out.add(AppRow(pm.getApplicationLabel(ai).toString(), ai.packageName, ver, fl, fl.sumOf { it.length() }, false))
        } catch (t: Throwable) { }
    }
    val game = Regex("free ?fire|freefire|garena|dts\\.")
    return out.sortedWith(compareBy({ if (game.containsMatchIn((it.label + " " + it.pkg).lowercase())) 0 else 1 }, { it.label.lowercase() }))
}

private fun apkRow(ctx: Context, path: String): AppRow {
    val f = File(path)
    val info = try { ctx.packageManager.getPackageArchiveInfo(path, 0) } catch (t: Throwable) { null }
    return AppRow(f.name, info?.packageName ?: ("apk_" + f.nameWithoutExtension), info?.versionName ?: "", listOf(f), f.length(), true)
}

@Composable
fun AppItem(a: AppRow, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick).padding(10.dp)
    ) {
        Text((if (a.fromFile) "APK file: " else "") + a.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
        Text(a.pkg + (if (a.ver.isNotEmpty()) "  \u2022  " + a.ver else "") + "  \u2022  " + Fs.human(a.size) + "  \u2022  " + a.files.size + " APK file(s)",
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
    }
}

/** The "Game / APK" tab: pick an installed game or an APK, then Potato edits the game files inside the APK. */
@Composable
fun GameTab() {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppRow>?>(null) }
    var queued by remember { mutableStateOf<List<AppRow>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf<AppRow?>(null) }
    var apkDlg by remember { mutableStateOf<ApkJob?>(null) }
    var dataDlg by remember { mutableStateOf<List<String>?>(null) }
    val q = apkQueue

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { try { loadApps(ctx) } catch (t: Throwable) { emptyList() } } }
    LaunchedEffect(q) {
        queued = withContext(Dispatchers.IO) { q.map { apkRow(ctx, it) } }
        if (queued.isNotEmpty()) sel = queued.first()
    }
    val list = remember(apps, queued, query) {
        val k = query.trim().lowercase()
        (queued + (apps ?: emptyList())).filter { k.isEmpty() || it.label.lowercase().contains(k) || it.pkg.lowercase().contains(k) }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Game / APK", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            "Pick the installed game (or an APK chosen in the Files tab). Potato changes the game files inside the APK, signs it again, and you install it. This is for games whose data is inside the APK (no OBB).",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        val s = sel
        if (s != null) {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Selected: ${s.label}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                for (f in s.files.take(6)) Text(f.name + "  " + Fs.human(f.length()), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (s.files.size > 6) Text("... and ${s.files.size - 6} more APK files", fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { apkDlg = ApkJob(s.pkg, s.label, s.files) }) { Text("Potato the APK") }
                    if (!s.fromFile) FilledTonalButton(onClick = { dataDlg = listOf(Fs.root + "/Android/data/" + s.pkg) }) { Text("Potato its data folder") }
                }
            }
        }
        OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true, label = { Text("Search installed apps") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        if (apps == null) Text("Loading installed apps ...", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        LazyColumn(Modifier.fillMaxWidth().weight(1f).padding(top = 6.dp)) {
            items(list, key = { it.pkg + "|" + it.files.first().path }) { a -> AppItem(a, a === sel) { sel = a } }
        }
    }

    apkDlg?.let { j ->
        PotatoDialog(emptyList(), { }, onClose = { apkDlg = null }, onOpen = { p -> apkDlg = null; savedCwd = p; mainTab = 0 }, apk = j)
    }
    dataDlg?.let { ps ->
        PotatoDialog(ps, { }, onClose = { dataDlg = null }, onOpen = { p -> dataDlg = null; savedCwd = p; mainTab = 0 })
    }
}
