package com.spudlab.tater

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.CRC32

private val PKG_RE = Regex("^(.*/Android/(?:data|obb)/([^/]+))")

class ScanBase(val pkgDir: String, val pkg: String, val bundles: Int, val skipped: Int)

/**
 * Read-only: opens every Unity bundle under the selected paths and collects every texture (name, size, format,
 * mip levels, a small picture). Nothing is written. Results go into `sink` as they come, so a stopped scan keeps
 * what it already found.
 */
suspend fun scanAll(ctx: Context, paths: List<String>, thumbs: Boolean, sink: MutableList<UnityFs.TexInfo>, say: (String) -> Unit): ScanBase =
    withContext(Dispatchers.Default) {
        val m = paths.firstNotNullOfOrNull { PKG_RE.find(it) }
        val pkg = m?.groupValues?.get(2) ?: "selected"
        val pkgDir = m?.groupValues?.get(1) ?: (File(paths.first()).parent ?: Fs.root)
        val limit = Runtime.getRuntime().maxMemory() / 5
        val budget = intArrayOf(2500)
        var seen = 0; var skipped = 0
        for (p in paths) {
            ensureActive()
            val files = ArrayList<Pair<String, Long>>()
            Fs.walk(ctx, p) { f, s -> files.add(f to s) }
            files.sortBy { it.second }
            for ((f, size) in files) {
                ensureActive()
                if (size in 0L..63L) continue
                if (!Fs.isBundle(ctx, f)) continue
                seen++
                val name = f.substringAfterLast('/')
                if (size > limit) { skipped++; say("Too big for the available memory: $name (${Fs.human(size)})"); continue }
                val rel = f.removePrefix(pkgDir).trimStart('/')
                val bytes = try { Fs.read(ctx, f) } catch (t: Throwable) { skipped++; say("Read failed: $name"); continue }
                try {
                    sink.addAll(UnityFs.scan(bytes, rel, thumbs, budget))
                } catch (t: Throwable) {
                    skipped++
                }
                say("Scanning bundle $seen: $name\n${sink.size} textures found so far")
            }
        }
        ScanBase(pkgDir, pkg, seen, skipped)
    }

class RunResult(val text: String, val results: List<TexResult>, val outDir: String, val written: Int, val seen: Int)

/**
 * The real Potato run, driven by a Policy (a level for every category). Changed bundles are written to
 * <storage>/Tater Manager/Potato Output/<package>/<same relative path as in the game>. With backup = true the original
 * of every changed bundle is copied (once) to <storage>/Tater Manager/Backup/<package>/. With resume = true bundles
 * that are already in the output folder are skipped.
 */
suspend fun runPotatoP(ctx: Context, paths: List<String>, policy: Policy, backup: Boolean, resume: Boolean, say: (String) -> Unit): RunResult =
    withContext(Dispatchers.Default) {
        val m = paths.firstNotNullOfOrNull { PKG_RE.find(it) }
        val pkg = m?.groupValues?.get(2) ?: "selected"
        val pkgDir = m?.groupValues?.get(1) ?: (File(paths.first()).parent ?: Fs.root)
        val out = File(Fs.root, "Tater Manager/Potato Output/$pkg")
        val bk = File(Fs.root, "Tater Manager/Backup/$pkg")
        val ty = Tally()
        var written = 0; var seen = 0; var resumed = 0
        val limit = Runtime.getRuntime().maxMemory() / 5
        for (p in paths) {
            ensureActive()
            val files = ArrayList<Pair<String, Long>>()
            Fs.walk(ctx, p) { f, s -> files.add(f to s) }
            files.sortBy { it.second }
            for ((f, size) in files) {
                ensureActive()
                if (size in 0L..63L) continue
                val rel = f.removePrefix(pkgDir).trimStart('/')
                if (resume && File(out, rel).exists()) { resumed++; continue }
                if (!Fs.isBundle(ctx, f)) continue
                seen++
                val name = f.substringAfterLast('/')
                ty.cur = name
                if (size > limit) { ty.tooBig++; say("Too big for the available memory: $name (${Fs.human(size)})"); continue }
                say("[$seen] $name")
                val bytes = try { Fs.read(ctx, f) } catch (t: Throwable) { ty.readFail++; say("Read failed: $name"); continue }
                val res = try {
                    UnityFs.process(bytes, 0, emptyList(), null, 4, true, ty, policy = policy, hint = rel) { say(it) }
                } catch (t: Throwable) { ty.bad++; say("Failed: $name (${t.message})"); bytes to 0 }
                if (res.second > 0) {
                    try {
                        if (backup) {
                            val bf = File(bk, rel)
                            if (!bf.exists()) { bf.parentFile?.mkdirs(); bf.writeBytes(bytes) }
                        }
                        val dest = File(out, rel)
                        dest.parentFile?.mkdirs()
                        dest.writeBytes(res.first)
                        if (dest.length() != res.first.size.toLong()) say("Write size mismatch: $rel") else { written++; say("  saved: $rel (${res.second} textures)") }
                    } catch (t: Throwable) {
                        say("Write failed: $rel (${t.message})")
                    }
                }
            }
        }
        if (written > 0) {
            try { File(out, ".tater_base").writeText("base=$pkgDir\n") } catch (t: Throwable) { }
        }
        val rs = ty.results
        val lines = ArrayList<String>()
        lines.add("Bundles checked: $seen, changed and saved: $written" + (if (resumed > 0) " (skipped $resumed already in output)" else ""))
        lines.add("Textures: ${rs.size} checked")
        lines.add("  reduced: ${rs.count { it.code == Dec.REDUCE }}")
        lines.add("  kept (level Original): ${rs.count { it.code == Dec.KEEP }}")
        lines.add("  cannot be reduced: ${rs.count { it.code == Dec.CANT }}")
        lines.add("  already tiny: ${rs.count { it.code == Dec.TINY }}")
        lines.add("  unreadable / unsupported: ${rs.count { it.code == Dec.BAD }}")
        if (ty.converted > 0) lines.add("Re-encoded (compressed without mips): ${ty.converted}")
        if (ty.tooBig > 0) lines.add("Bundles too big for memory: ${ty.tooBig}")
        if (ty.readFail > 0) lines.add("Bundles that could not be read: ${ty.readFail}")
        if (written > 0) {
            lines.add("Output: ${out.path}")
            if (backup) lines.add("Originals saved in: ${bk.path}")
        } else lines.add("Nothing was changed, so no output folder was made.")
        RunResult(lines.joinToString("\n"), rs, out.path, written, seen)
    }

private suspend fun gameCrc(ctx: Context, path: String): Long? {
    val i = try { Fs.openIn(ctx, path) } catch (t: Throwable) { return null }
    return try {
        val c = CRC32()
        val buf = ByteArray(1 shl 16)
        i.use { s ->
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                c.update(buf, 0, n)
            }
        }
        c.value
    } catch (t: Throwable) {
        null
    }
}

/**
 * Compares every file in "Tater Manager/Potato Output/<package>" with the file at the same place in the game folder.
 * Tells you whether the paste really happened and whether the game put the original files back.
 */
suspend fun verifyOutputs(ctx: Context): String = withContext(Dispatchers.IO) {
    val root = File(Fs.root, "Tater Manager/Potato Output")
    val dirs = root.listFiles()?.filter { it.isDirectory } ?: emptyList()
    if (dirs.isEmpty()) return@withContext "No Potato output found yet. Run Potato first."
    val sb = StringBuilder()
    for (dir in dirs) {
        val mf = File(dir, ".tater_base")
        val base = if (mf.exists()) {
            mf.readText().lineSequence().firstOrNull { it.startsWith("base=") }?.removePrefix("base=")?.trim()
        } else null
        if (base.isNullOrEmpty()) {
            sb.append(dir.name).append(": game folder unknown (run Potato again on a folder inside Android/data).\n\n")
            continue
        }
        var same = 0; var diff = 0; var noRead = 0; var total = 0
        val diffNames = ArrayList<String>()
        for (f in dir.walkTopDown()) {
            if (!f.isFile || f.name == ".tater_base") continue
            total++
            val rel = f.relativeTo(dir).path
            val g = gameCrc(ctx, "$base/$rel")
            if (g == null) noRead++
            else if (g == crcOf(f)) same++
            else { diff++; if (diffNames.size < 3) diffNames.add(rel) }
        }
        sb.append(dir.name).append(":\n")
        sb.append("  $same of $total files in the game folder are the NEW (potato) version\n")
        if (diff > 0) sb.append("  $diff are different (still the original, or restored by the game), e.g. ${diffNames.joinToString(", ")}\n")
        if (noRead > 0) sb.append("  $noRead could not be read (missing, or this app has no access to Android/data)\n")
        if (same == total && total > 0) sb.append("  Applied. If graphics did not change, the game is not using these textures.\n")
        else if (diff > 0) sb.append("  If you checked right after pasting: the paste went to the wrong place. If you checked after opening the game: the game restores its files.\n")
        sb.append('\n')
    }
    sb.toString().trim()
}

/** Writes the complete texture list as a text file (one line per texture) and returns its path. */
fun exportList(lines: List<String>): String {
    val dir = File(Fs.root, "Tater Manager/Reports")
    dir.mkdirs()
    val f = File(dir, "textures-" + System.currentTimeMillis() + ".txt")
    f.writeText(lines.joinToString("\n"))
    return f.path
}
