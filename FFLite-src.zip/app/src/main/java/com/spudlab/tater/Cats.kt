package com.spudlab.tater

/** Texture categories. Every texture belongs to exactly one, and every category has its own Potato level. */
object Cat {
    const val CHAR = 0
    const val GUN = 1
    const val LOBBY = 2
    const val VFX = 3
    const val UI = 4
    const val ENV = 5
    const val N = 6
    val NAMES = listOf("Character", "Gun", "Lobby", "Effects (VFX)", "UI / sprites", "Environment / other")
    val SHORT = listOf("Char", "Gun", "Lobby", "VFX", "UI", "Env")
    /** 0 = Original (not touched) ... 6 = No Limit (1/64) */
    val DEFAULT_LEVELS = intArrayOf(0, 0, 1, 6, 0, 6)
    val DEFAULT_WORDS = listOf(
        "character, avatar, hero, npc, player, role, costume, outfit",
        "weapon, gun, rifle, pistol, smg, sniper, shotgun, grenade",
        "lobby, mainmenu, homepage, login",
        "vfx, fx_, _fx, effect, particle, smoke, explosion",
        "ui_, _ui, icon, atlas, font, hud",
        ""
    )
}

/** What happens to a texture. */
object Dec {
    const val REDUCE = 0   // will be / was made smaller
    const val KEEP = 1     // level Original for its category
    const val CANT = 2     // cannot be reduced (compressed, no mips, cannot re-encode)
    const val TINY = 3     // already at the minimum size
    const val BAD = 4      // unreadable / unsupported
}

fun parseWords(t: String): List<String> = t.split(',', ';', '\n').map { it.trim().lowercase() }.filter { it.isNotEmpty() }

/**
 * levels[cat] = how far textures of that category are shrunk (0 = untouched, 6 = No Limit).
 * words[cat] = keywords. A texture NAME that contains a word decides first; if no name matches, the bundle's asset paths
 * and file path decide. Sprite / UI bundles are always UI. catOverride = categories the user changed by hand.
 */
class Policy(val levels: IntArray, val words: List<List<String>>, val catOverride: Map<String, Int>) {
    private val bundleCache = HashMap<String, Int>()
    private val orderName = intArrayOf(Cat.VFX, Cat.GUN, Cat.CHAR, Cat.LOBBY, Cat.UI)
    private val orderBundle = intArrayOf(Cat.GUN, Cat.CHAR, Cat.LOBBY, Cat.VFX, Cat.UI)

    fun copy(): Policy = Policy(levels.copyOf(), words, catOverride.toMap())

    fun category(key: String, bundle: String, bundleLow: String, nameLow: String, ui: Boolean): Int {
        val o = catOverride[key]
        if (o != null) return o
        if (ui) return Cat.UI
        for (c in orderName) {
            for (w in words[c]) if (nameLow.contains(w)) return c
        }
        val b = bundleCache.getOrPut(bundle) { bundleCat(bundleLow) }
        return if (b >= 0) b else Cat.ENV
    }

    private fun bundleCat(low: String): Int {
        for (c in orderBundle) {
            for (w in words[c]) if (low.contains(w)) return c
        }
        return -1
    }
}

class Decision(val cat: Int, val code: Int, val k: Int, val w2: Int, val h2: Int, val before: Long, val after: Long, val note: String)

/** Bytes the texture needs after dropping k levels (an estimate for re-encoded ones). */
private fun estimateAfter(t: UnityFs.TexInfo, k: Int): Long {
    val b = t.csz.toLong()
    val w2 = maxOf(1, t.w shr k); val h2 = maxOf(1, t.h shr k)
    val ch = UnityFs.channels(t.tf)
    if (t.mips > 1) {
        var drop = 0L
        for (i in 0 until k) drop += UnityFs.lvlSize(t.tf, t.w, t.h, i)
        return b - drop
    }
    return if (ch > 0) w2.toLong() * h2 * ch else w2.toLong() * h2
}

/** Same rule as the real processing step, but without touching any data. */
fun decide(t: UnityFs.TexInfo, p: Policy, minSide: Int = 4): Decision {
    val cat = p.category(t.key, t.bundle, t.bundleLow, t.nameLow, t.ui)
    val lv = p.levels[cat]
    val b = t.csz.toLong()
    val prob = t.problem
    if (prob != null) return Decision(cat, Dec.BAD, 0, t.w, t.h, b, b, prob)
    if (lv <= 0) return Decision(cat, Dec.KEEP, 0, t.w, t.h, b, b, "level Original for " + Cat.NAMES[cat])
    val ch = UnityFs.channels(t.tf)
    val canConv = t.mips == 1 && ch == 0 && Reencode.canConvert(t.tf)
    val maxK = if (t.mips > 1) t.mips - 1 else if (ch > 0 || canConv) 8 else 0
    var k = minOf(lv, maxK)
    while (k > 0 && (maxOf(t.w, t.h) shr k) < minSide) k--
    if (k == 0) {
        return if (maxK == 0) Decision(cat, Dec.CANT, 0, t.w, t.h, b, b, "compressed, no mip levels, and this format cannot be re-encoded")
        else Decision(cat, Dec.TINY, 0, t.w, t.h, b, b, "already at the minimum size")
    }
    val note = if (t.mips > 1) "drops the top $k mip level(s)" else if (ch > 0) "resampled smaller" else "re-encoded smaller (ETC2)"
    return Decision(cat, Dec.REDUCE, k, maxOf(1, t.w shr k), maxOf(1, t.h shr k), b, estimateAfter(t, k), note)
}

/** After a run: what really happened to this texture (falls back to the prediction when it was not part of the run). */
fun fromResult(t: UnityFs.TexInfo, r: TexResult?, p: Policy): Decision {
    if (r == null) return decide(t, p)
    val b = t.csz.toLong()
    var k = 0
    while (k < 16 && (t.w shr k) > r.w2) k++
    if (r.code != Dec.REDUCE) return Decision(r.cat, r.code, 0, t.w, t.h, b, b, r.note)
    return Decision(r.cat, Dec.REDUCE, k, r.w2, r.h2, b, estimateAfter(t, k), "was made smaller")
}
