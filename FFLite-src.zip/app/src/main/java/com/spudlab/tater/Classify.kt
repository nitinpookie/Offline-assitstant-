package com.spudlab.tater

/**
 * Texture categories. The names/paths below come from real game files (Free Fire cache bundles):
 *  - character textures:  Male_* / Female_* / *_Cos_* / avatar bundles (assets/arts/avatarassets/...)
 *  - effects:             VFX_* / FF_VFX_* / Emote_* / particles / flares
 *  - lightmaps:           Lightmap_*
 *  - map / environment:   T_* / WS_* / Terrain / building / sky (...nastc) / decals / props ...
 *  - lobby:               SA_SYS_* / GROUPPHOTO* / lobby paths
 *  - ui:                  UIFX_* / icons / minimap / sprite atlases
 *  - pets, weapons.
 * The first matching rule wins. Texture NAME rules run first, then the bundle's asset paths (hint).
 */
object Cat {
    const val CHARACTER = 0
    const val WEAPON = 1
    const val LOBBY = 2
    const val UI = 3
    const val PET = 4
    const val VFX = 5
    const val LIGHTMAP = 6
    const val MAP = 7
    const val OTHER = 8
    const val COUNT = 9

    val names = listOf("Character", "Weapon", "Lobby", "UI", "Pet", "Effects (VFX)", "Lightmap", "Map / environment", "Other")

    /** 0 = keep original, 1 = light (at most 1/2), 2 = use the slider level. */
    val defaultMode = intArrayOf(0, 0, 1, 0, 2, 2, 2, 2, 2)

    val modeNames = listOf("Keep", "Light", "Potato")
}

object Classify {
    private val byName: List<Pair<Int, Regex>> = listOf(
        Cat.UI to Regex("^uifx|^ff_icon|^icon|(^|_)icon(_|$)|minimap|^banner|^preview_|^sactx|^ui_"),
        Cat.VFX to Regex("^(ff_)?vfx|particle|^emote|groupanim|flare|foam|(^|_)(smoke|trail|glow|noise|nosie|shine|lightning)(_|[0-9])"),
        Cat.WEAPON to Regex("weapon|^3p_|(^|_)gun(_|$)|grenade|(^|_)(sw|wp)_"),
        Cat.CHARACTER to Regex("^(fe)?male[_ ]|avatar|wardrobe|(^|_)cos_|^matcap|mischiefgirl|facecloth"),
        Cat.PET to Regex("^cat_|^catfood|(^|_)pet(_|$)"),
        Cat.LOBBY to Regex("^sa_sys|groupphoto|lobby"),
        Cat.LIGHTMAP to Regex("^lightmap"),
        Cat.MAP to Regex("^t_|^ws_|bermuda|kalahari|purgatory|nexterra|solara|alpine|terrain|hippo|azores|alphaisland|building|concrete|metal|^zone_|mounts|moonbase|cyberfarm|sgmuseum|construction|^eic_|geminipark|^common|plant|tree|grass|wall|ground|sky|nastc|water|rock|portal|^fur_|decal|daylight|shrub|^props|(^|_)lod[0-9]*(_|$)|^oil_|^all_lod|firedepartment|billboard|^wace_|^highfactory|fishingvillage|^ob[0-9]+_")
    )

    private val byHint: List<Pair<Int, Regex>> = listOf(
        Cat.CHARACTER to Regex("avatarassets|wardrobe|newmale|newfemale|optionalab_avatar|clothres"),
        Cat.LOBBY to Regex("lobby"),
        Cat.PET to Regex("petres|/pet|optionalab_pet"),
        Cat.UI to Regex("/ui/|/img/|sprite"),
        Cat.VFX to Regex("effects/|/effects"),
        Cat.MAP to Regex("scenes/game|arts_pvp|ff_common|optionalmap|training|battlesplit|environment|bermuda|kalahari|purgatory|nexterra|solara|alpine|/maps?/|map_")
    )

    /** name = texture name, hint = bundle file path + some asset paths of the bundle (any case). */
    fun of(name: String, hint: String): Int {
        val n = name.lowercase()
        for ((c, r) in byName) if (r.containsMatchIn(n)) return c
        val h = hint.lowercase()
        for ((c, r) in byHint) if (r.containsMatchIn(h)) return c
        return Cat.OTHER
    }
}
