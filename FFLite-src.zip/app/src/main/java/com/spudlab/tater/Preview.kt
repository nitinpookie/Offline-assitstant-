package com.spudlab.tater

import android.graphics.Bitmap
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLExt
import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Real texture preview. The pixels come from the real texture bytes of the selected game, at exactly the mip level
 * the processing step would keep. Plain formats are decoded on the CPU, compressed ones (ASTC / ETC2 / DXT) by the
 * phone's own GPU. If the phone cannot decode a format, null is returned (nothing is faked).
 */
object Preview {
    private const val VS = "#version 300 es\nout vec2 uv;\nvoid main() { vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2)); uv = p; gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }"
    private const val FS = "#version 300 es\nprecision mediump float;\nuniform sampler2D t;\nin vec2 uv;\nout vec4 o;\nvoid main() { o = texture(t, uv); }"

    private fun glFormat(tf: Int): Int = when (tf) {
        34, 45 -> 0x9274
        46 -> 0x9276
        47 -> 0x9278
        48, 54 -> 0x93B0
        49, 55 -> 0x93B2
        50, 56 -> 0x93B4
        51, 57 -> 0x93B7
        52, 58 -> 0x93BB
        53, 59 -> 0x93BD
        10 -> 0x83F1
        12 -> 0x83F3
        else -> 0
    }

    fun fmtName(tf: Int): String {
        val a = listOf("4x4", "5x5", "6x6", "8x8", "10x10", "12x12")
        return when (tf) {
            1 -> "Alpha8"
            3 -> "RGB24"
            4 -> "RGBA32"
            5 -> "ARGB32"
            14 -> "BGRA32"
            10 -> "DXT1"
            12 -> "DXT5"
            34, 45 -> "ETC2 RGB"
            46 -> "ETC2 RGBA1"
            47 -> "ETC2 RGBA8"
            in 48..53 -> "ASTC " + a[tf - 48]
            in 54..59 -> "ASTC " + a[tf - 54]
            2, 13 -> "RGBA4444"
            7 -> "RGB565"
            9 -> "R16"
            24 -> "BC6H"
            25 -> "BC7"
            28 -> "DXT1 crunch"
            29 -> "DXT5 crunch"
            30, 31, 32, 33 -> "PVRTC"
            41 -> "EAC R"
            43 -> "EAC RG"
            64 -> "ETC crunch"
            65 -> "ETC2 crunch"
            else -> "format $tf"
        }
    }

    fun decode(s: UnityFs.Sample, k: Int): Bitmap? = try { decode0(s, k) } catch (t: Throwable) { null }

    private fun argb(a: Int, r: Int, g: Int, b: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b

    private fun decode0(s: UnityFs.Sample, k: Int): Bitmap? {
        val w = maxOf(1, s.w shr k); val h = maxOf(1, s.h shr k)
        var off = 0
        for (i in 0 until k) off += UnityFs.lvlSize(s.tf, s.w, s.h, i)
        val n = UnityFs.lvlSize(s.tf, s.w, s.h, k)
        if (off + n > s.chain.size) return null
        val d = s.chain.copyOfRange(off, off + n)
        val ch = UnityFs.channels(s.tf)
        if (ch > 0) {
            val px = IntArray(w * h)
            for (row in 0 until h) for (x in 0 until w) {
                val i = (row * w + x) * ch
                val c0 = d[i].toInt() and 0xFF
                val c = when (s.tf) {
                    1 -> argb(255, c0, c0, c0)
                    3 -> argb(255, c0, d[i + 1].toInt() and 0xFF, d[i + 2].toInt() and 0xFF)
                    4 -> argb(d[i + 3].toInt() and 0xFF, c0, d[i + 1].toInt() and 0xFF, d[i + 2].toInt() and 0xFF)
                    5 -> argb(c0, d[i + 1].toInt() and 0xFF, d[i + 2].toInt() and 0xFF, d[i + 3].toInt() and 0xFF)
                    else -> argb(d[i + 3].toInt() and 0xFF, d[i + 2].toInt() and 0xFF, d[i + 1].toInt() and 0xFF, c0)
                }
                px[(h - 1 - row) * w + x] = c      // Unity stores the bottom row first
            }
            return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        }
        return gpu(w, h, s.tf, d)
    }

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }

    /** True when the phone's GPU path knows this format at all. */
    fun gpuKnows(tf: Int): Boolean = glFormat(tf) != 0

    private fun gpu(w: Int, h: Int, tf: Int, data: ByteArray): Bitmap? {
        val raw = gpuRaw(w, h, tf, data) ?: return null
        val px = IntArray(w * h)
        for (row in 0 until h) for (x in 0 until w) {
            val i = (row * w + x) * 4
            px[(h - 1 - row) * w + x] = argb(raw[i + 3].toInt() and 255, raw[i].toInt() and 255, raw[i + 1].toInt() and 255, raw[i + 2].toInt() and 255)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /**
     * Decodes one compressed level on the phone's GPU. Returns RGBA bytes, rows in the SAME order as in the file
     * (row 0 = first row stored by Unity), or null when the phone cannot decode this format / size.
     */
    @Synchronized
    fun gpuRaw(w: Int, h: Int, tf: Int, data: ByteArray): ByteArray? {
        val fmt = glFormat(tf)
        if (fmt == 0 || w < 1 || h < 1 || w * h > 4194304) return null
        val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) return null
        val cfg = arrayOfNulls<EGLConfig>(1); val num = IntArray(1)
        val attr = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_NONE)
        if (!EGL14.eglChooseConfig(dpy, attr, 0, cfg, 0, 1, num, 0) || num[0] == 0) return null
        val surf = EGL14.eglCreatePbufferSurface(dpy, cfg[0], intArrayOf(EGL14.EGL_WIDTH, w, EGL14.EGL_HEIGHT, h, EGL14.EGL_NONE), 0)
        val ctx = EGL14.eglCreateContext(dpy, cfg[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        try {
            if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) return null
            val prog = GLES20.glCreateProgram()
            GLES20.glAttachShader(prog, shader(GLES20.GL_VERTEX_SHADER, VS))
            GLES20.glAttachShader(prog, shader(GLES20.GL_FRAGMENT_SHADER, FS))
            GLES20.glLinkProgram(prog)
            GLES20.glUseProgram(prog)
            val tex = IntArray(1)
            GLES20.glGenTextures(1, tex, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
            val db = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
            db.put(data); db.position(0)
            GLES20.glCompressedTexImage2D(GLES20.GL_TEXTURE_2D, 0, fmt, w, h, 0, data.size, db)
            if (GLES20.glGetError() != GLES20.GL_NO_ERROR) return null
            GLES20.glViewport(0, 0, w, h)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 3)
            val rb = ByteBuffer.allocateDirect(w * h * 4)
            GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, rb)
            val out = ByteArray(w * h * 4)
            rb.position(0)
            rb.get(out)
            return out
        } finally {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf)
            EGL14.eglDestroyContext(dpy, ctx)
        }
    }
}
