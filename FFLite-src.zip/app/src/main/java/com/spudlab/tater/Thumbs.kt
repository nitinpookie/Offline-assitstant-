package com.spudlab.tater

import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream

/**
 * Small pictures for the report. They are written as little files in the app's cache folder and loaded one by one
 * when the list is scrolled, so the phone never holds thousands of pictures in memory.
 */
object Thumbs {
    private const val MAX = 96

    /** Saves a picture (scaled down to 96 px at most). Returns the file path, or "" when nothing could be saved. */
    fun save(dir: File?, key: String, b: Bitmap?): String {
        if (dir == null || b == null) return ""
        return try {
            var bm: Bitmap = b
            val m = maxOf(b.width, b.height)
            if (m > MAX) {
                val s = MAX.toFloat() / m
                bm = Bitmap.createScaledBitmap(b, maxOf(1, (b.width * s).toInt()), maxOf(1, (b.height * s).toInt()), true)
            }
            dir.mkdirs()
            val png = bm.width * bm.height <= 1024
            val f = File(dir, key + (if (png) ".png" else ".jpg"))
            FileOutputStream(f).use { bm.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 80, it) }
            f.path
        } catch (t: Throwable) {
            ""
        }
    }

    /** Picture of one mip level of a texture chain (the phone decodes it). */
    fun level(dir: File?, key: String, name: String, tf: Int, w: Int, h: Int, mips: Int, chain: ByteArray, lv: Int): String {
        if (dir == null) return ""
        return save(dir, key, Preview.decode(UnityFs.Sample(name, w, h, tf, mips, chain), lv))
    }

    /** Picture of the original texture (a small mip level when there is one, else the whole texture). */
    fun before(dir: File?, key: String, name: String, tf: Int, w: Int, h: Int, mips: Int, d: ByteArray, pos: Int, csz: Int): String {
        if (dir == null) return ""
        var kb = 0
        while (kb < mips - 1 && (maxOf(w, h) shr kb) > 128) kb++
        return level(dir, key + "b", name, tf, w, h, mips, d.copyOfRange(pos, pos + csz), kb)
    }
}
