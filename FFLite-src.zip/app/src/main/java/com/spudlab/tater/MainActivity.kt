package com.spudlab.tater

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku
import java.io.File

var resumeTick by mutableIntStateOf(0)

private val LEVELS = listOf("Original", "Lite (1/2)", "Extra Lite (1/4)", "Ultra Lite (1/8)", "Ultra Pro Max (1/16)", "Extreme (1/32)", "No Limit (1/64)")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val cs = darkColorScheme(primary = Color(0xFFFFB74D), onPrimary = Color(0xFF3E2200), primaryContainer = Color(0xFF5D3A00), onPrimaryContainer = Color(0xFFFFDDB3))
            MaterialTheme(colorScheme = cs) { Surface(Modifier.fillMaxSize()) { Gate() } }
        }
    }
    override fun onResume() { super.onResume(); resumeTick++ }
}

@Composable
fun Gate() {
    val ctx = LocalContext.current
    @Suppress("UNUSED_VARIABLE") val tick = resumeTick
    val ok = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
        ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    if (ok) Manager() else PermissionScreen()
}

@Composable
fun PermissionScreen() {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { resumeTick++ }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("\uD83E\uDD54", fontSize = 64.sp)
        Text("Tater Manager", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("A file manager for game files. Like other file managers it needs the \"All files access\" permission.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 30) ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            else launcher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }) { Text("Allow all files access") }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Manager() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var cwd by remember { mutableStateOf(Fs.root) }
    var entries by remember { mutableStateOf<List<Item>?>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    val sel = remember { mutableStateListOf<String>() }
    var clip by remember { mutableStateOf<Pair<List<String>, Boolean>?>(null) }
    var logs by remember { mutableStateOf(listOf("Tater Manager ready.")) }
    var showPotato by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    var potatoPaths by remember { mutableStateOf(listOf<String>()) }
    var noticeTitle by remember { mutableStateOf<String?>(null) }
    var noticeBody by remember { mutableStateOf("") }
    @Suppress("UNUSED_VARIABLE") val rt = resumeTick

    fun log(s: String) { logs = (logs + s).takeLast(600) }
    fun toggle(p: String) { if (p in sel) sel.remove(p) else sel.add(p) }
    fun go(p: String) { sel.clear(); cwd = p }

    // "Allow access" for Android/data / Android/obb: the system folder picker, same way ZArchiver does it (no Shizuku).
    val safLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val u = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && u != null) {
            try {
                var fl = (res.data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                if (fl == 0) fl = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                ctx.contentResolver.takePersistableUriPermission(u, fl)
                val id = try { DocumentsContract.getTreeDocumentId(u) } catch (t: Throwable) { u.toString() }
                log("Access granted: $id")
                if (id != "primary:Android/data" && id != "primary:Android/obb") {
                    log("You selected \"$id\". For everything, go up and select the folder named \"data\" itself, then Use this folder.")
                }
            } catch (t: Throwable) {
                log("Could not keep the access: ${t.message ?: t.javaClass.simpleName}")
            }
        } else {
            log("Nothing granted. If the picker says it cannot use this folder, this phone blocks it; only Shizuku can open Android/data then.")
        }
        tick++
    }

    fun askSaf(path: String, own: Boolean) {
        val kind = if (path.contains("/Android/obb")) "obb" else "data"
        if (own) {
            // Method 2: open the picker inside this app's own folder (always allowed), then the user goes up one level.
            try { if (kind == "obb") ctx.obbDir.mkdirs() else ctx.getExternalFilesDir(null) } catch (t: Throwable) { }
        }
        val docId = if (own) "primary:Android/$kind/${ctx.packageName}" else "primary:Android/$kind"
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            .putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildDocumentUri(Saf.AUTH, docId))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        try { safLauncher.launch(i) } catch (t: Throwable) { log("Cannot open the folder picker: ${t.message ?: t.javaClass.simpleName}") }
    }

    // Tap on a folder: show "Loading" at once (never leave the old list on screen), list in the background, 25 sec limit.
    LaunchedEffect(cwd, tick, rt) {
        loading = true
        val job = async(Dispatchers.IO) { try { Fs.list(ctx, cwd) } catch (t: Throwable) { Fs.note = "Error: ${t.message ?: t.javaClass.simpleName}"; null } }
        var timedOut = true
        val r = withTimeoutOrNull(25000L) { val x = job.await(); timedOut = false; x }
        if (timedOut) log("Opening this folder took too long (25 sec). Tap Retry.")
        else if (Fs.note.isNotEmpty()) log(Fs.note)
        entries = r
        loading = false
    }
    BackHandler(enabled = sel.isNotEmpty() || cwd != Fs.root) { if (sel.isNotEmpty()) sel.clear() else go(File(cwd).parent ?: Fs.root) }

    fun work(label: String, block: suspend () -> Unit) {
        scope.launch(Dispatchers.IO) {
            try { block(); log("$label: done") } catch (t: Throwable) { log("$label failed: ${t.message}") }
            tick++
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp)) {
            Text("Tater Manager", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(cwd.removePrefix(Fs.root).ifEmpty { "/" }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (cwd != Fs.root) FilledTonalButton(onClick = { go(File(cwd).parent ?: Fs.root) }) { Text("Up") }
            if (sel.isNotEmpty()) {
                val list = entries ?: emptyList()
                FilledTonalButton(onClick = { sel.clear(); sel.addAll(list.map { it.path }) }) { Text("All") }
                FilledTonalButton(onClick = { clip = sel.toList() to false; log("Copied ${sel.size} item(s)"); sel.clear() }) { Text("Copy") }
                FilledTonalButton(onClick = { clip = sel.toList() to true; log("Cut ${sel.size} item(s)"); sel.clear() }) { Text("Cut") }
                FilledTonalButton(onClick = { confirmDel = true }) { Text("Delete") }
                FilledTonalButton(onClick = {
                    val paths = sel.toList()
                    // a zip cannot be written inside Android/data, so it goes to "Tater Manager" instead
                    val dir = if (Fs.restricted(cwd)) File(Fs.root, "Tater Manager").also { it.mkdirs() } else File(cwd)
                    val out = Fs.uniq(dir, (if (paths.size == 1) File(paths[0]).name else "archive") + ".zip")
                    sel.clear(); work("Zip") { Fs.zipTo(ctx, paths, out) }
                }) { Text("Zip") }
                if (sel.size == 1 && sel[0].endsWith(".zip", true)) FilledTonalButton(onClick = {
                    val z = sel[0]; val where = cwd
                    sel.clear()
                    work("Extract") { Fs.unzipTo(ctx, z, "$where/" + Fs.uniqName(ctx, where, File(z).nameWithoutExtension)) }
                }) { Text("Extract") }
                Button(onClick = { potatoPaths = sel.toList(); showPotato = true }) { Text("Potato \uD83E\uDD54") }
            }
        }
        clip?.let { c ->
            fun paste(replace: Boolean) {
                val dir = cwd; clip = null
                val items = c.first; val moving = c.second
                scope.launch(Dispatchers.IO) {
                    try {
                        var files = 0
                        for (p in items) {
                            val name = p.substringAfterLast('/')
                            val dst = "$dir/" + (if (replace) name else Fs.uniqName(ctx, dir, name))
                            if (moving) { Fs.move(ctx, p, dst); files++ } else files += Fs.copyTree(ctx, p, dst)
                        }
                        log("Paste: done")
                        noticeBody = (if (moving) "$files item(s) moved to " else "$files file(s) written to ") +
                            dir.removePrefix(Fs.root).ifEmpty { "/" } + (if (replace) "\nFiles with the same name were replaced." else "")
                        noticeTitle = "Applied successfully \u2705"
                    } catch (t: Throwable) {
                        log("Paste failed: ${t.message}")
                        noticeBody = t.message ?: t.javaClass.simpleName
                        noticeTitle = "Not applied"
                    }
                    tick++
                }
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Text("${c.first.size} item(s) to ${if (c.second) "move" else "copy"}", fontSize = 13.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { paste(false) }) { Text("Paste here") }
                    FilledTonalButton(onClick = { paste(true) }) { Text("Paste & replace") }
                    TextButton(onClick = { clip = null }) { Text("Cancel") }
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            val list = entries
            if (loading) {
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(10.dp))
                    Text("Loading...", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else if (list == null) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("This folder is protected by Android.", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Tap \"Allow access\", then on the next screen tap \"Use this folder\" and \"Allow\". This is the same way ZArchiver does it, no Shizuku needed.", textAlign = TextAlign.Center, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { askSaf(cwd, false) }) { Text("Allow access") }
                        FilledTonalButton(onClick = { askSaf(cwd, true) }) { Text("Method 2") }
                        TextButton(onClick = { Shz.reset(); tick++ }) { Text("Retry") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Method 2: the picker opens inside this app's own folder. Go back one level to \"data\", then tap \"Use this folder\".", textAlign = TextAlign.Center, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    Text("Or with Shizuku:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { Shz.reset(); try { Shizuku.requestPermission(100) } catch (t: Throwable) { log("Shizuku is not running") } }) { Text("Allow Shizuku") }
                        TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))) }) { Text("Get Shizuku") }
                    }
                }
            } else if (list.isEmpty()) {
                Text("Empty folder", Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.path }) { e ->
                    val on = e.path in sel
                    Row(
                        Modifier.fillMaxWidth()
                            .background(if (on) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .combinedClickable(
                                onClick = { if (sel.isNotEmpty()) toggle(e.path) else if (e.dir) go(e.path) else Toast.makeText(ctx, e.name, Toast.LENGTH_SHORT).show() },
                                onLongClick = { toggle(e.path) })
                            .padding(horizontal = 16.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (sel.isNotEmpty()) Checkbox(checked = on, onCheckedChange = null)
                        Text(if (e.dir) "\uD83D\uDCC1" else if (e.name.endsWith(".zip", true)) "\uD83D\uDCE6" else "\uD83D\uDCC4", fontSize = 22.sp)
                        Column(Modifier.weight(1f)) {
                            Text(e.name, maxLines = 1)
                            if (!e.dir && e.size > 0) Text(Fs.human(e.size), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        // log + copy button, always at the very bottom
        Surface(tonalElevation = 3.dp) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Text(logs.takeLast(3).joinToString("\n"), fontSize = 11.sp, maxLines = 3, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = { clipboard.setText(AnnotatedString(logs.joinToString("\n"))); Toast.makeText(ctx, "Log copied", Toast.LENGTH_SHORT).show() }) { Text("Copy log") }
                    TextButton(onClick = { logs = emptyList() }) { Text("Clear") }
                }
            }
        }
    }

    if (confirmDel) AlertDialog(
        onDismissRequest = { confirmDel = false },
        title = { Text("Delete ${sel.size} item(s)?") },
        text = { Text("This cannot be undone.") },
        confirmButton = { TextButton(onClick = { val ps = sel.toList(); sel.clear(); confirmDel = false; work("Delete") { for (p in ps) Fs.deleteTree(ctx, p) } }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("Cancel") } })

    noticeTitle?.let { t ->
        AlertDialog(
            onDismissRequest = { noticeTitle = null },
            title = { Text(t) },
            text = { Text(noticeBody) },
            confirmButton = { TextButton(onClick = { noticeTitle = null }) { Text("OK") } })
    }

    if (showPotato) PotatoDialog(potatoPaths, ::log, onClose = { showPotato = false; sel.clear() }, onOpen = { p -> showPotato = false; go(p) })
}

@Composable
fun Chip(text: String, on: Boolean, onClick: () -> Unit) {
    Text(
        text,
        Modifier.clip(RoundedCornerShape(16.dp))
            .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        fontSize = 12.sp,
        color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
    )
}

/** One small picture of the report, loaded from its file only when the row is on screen. */
@Composable
fun Pic(path: String, crisp: Boolean) {
    val bm by produceState<ImageBitmap?>(null, path) {
        value = if (path.isEmpty()) null else withContext(Dispatchers.IO) {
            try { BitmapFactory.decodeFile(path)?.asImageBitmap() } catch (t: Throwable) { null }
        }
    }
    val b = bm
    Box(Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit, filterQuality = if (crisp) FilterQuality.None else FilterQuality.Low)
        else Text("-", fontSize = 11.sp)
    }
}

@Composable
fun RecRow(r: Rec) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Pic(r.thumbB, false)
        if (r.status == 0) {
            Text("\u2192", fontSize = 18.sp)
            Pic(r.thumbA, true)
        }
        Column(Modifier.weight(1f)) {
            Text(if (r.name.isEmpty()) "(no name)" else r.name, maxLines = 1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(Cat.names[r.cat] + "  \u2022  " + r.fmt, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(if (r.status == 0) "${r.w}x${r.h}  \u2192  ${r.nw}x${r.nh} ${r.nfmt}" else "${r.w}x${r.h}", fontSize = 11.sp)
            if (r.reason.isNotEmpty()) Text(r.reason, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun BundleRow(b: BRec) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(b.name, maxLines = 1, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(Fs.human(b.size) + "  \u2022  " + b.info + "  \u2022  textures " + b.tex + ", changed " + b.changed + (if (b.saved) "  \u2022  saved" else ""),
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (b.note.isNotEmpty()) Text(b.note, fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
    }
}

/** Full-screen report: every texture with a picture, what happened to it and why. */
@Composable
fun ReportScreen(res: PotatoResult, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var tab by remember { mutableIntStateOf(0) }
    var catF by remember { mutableIntStateOf(-1) }
    var query by remember { mutableStateOf("") }
    var showSummary by remember { mutableStateOf(false) }
    val nChanged = remember(res) { res.recs.count { it.status == 0 } }
    val nKept = remember(res) { res.recs.count { it.status == 1 } }
    val nCant = remember(res) { res.recs.count { it.status >= 2 } }
    val inTab = remember(tab, res) { res.recs.filter { r -> if (tab == 0) r.status == 0 else if (tab == 1) r.status == 1 else r.status >= 2 } }
    val shown = remember(inTab, catF, query) {
        val q = query.trim().lowercase()
        inTab.filter { r -> (catF < 0 || r.cat == catF) && (q.isEmpty() || r.name.lowercase().contains(q) || r.bundle.lowercase().contains(q)) }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (res.dry) "Scan report" else "Potato report", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${res.recs.size} textures in ${res.bundles.size} bundle files", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = { showSummary = !showSummary }) { Text("Summary") }
                    TextButton(onClick = onClose) { Text("Close") }
                }
                if (showSummary) {
                    Column(Modifier.fillMaxWidth().heightIn(max = 240.dp).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                        Text(res.text, fontSize = 11.sp)
                        TextButton(onClick = { clipboard.setText(AnnotatedString(res.text)); Toast.makeText(ctx, "Summary copied", Toast.LENGTH_SHORT).show() }) { Text("Copy summary") }
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val labels = listOf(
                        (if (res.dry) "Would change " else "Changed ") + nChanged,
                        "Kept $nKept", "Not changeable $nCant", "Bundles ${res.bundles.size}"
                    )
                    for (i in labels.indices) Chip(labels[i], tab == i) { tab = i; catF = -1 }
                }
                if (tab < 3) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Chip("All ${inTab.size}", catF < 0) { catF = -1 }
                        for (c in 0 until Cat.COUNT) {
                            val n = inTab.count { it.cat == c }
                            if (n > 0) Chip(Cat.names[c] + " " + n, catF == c) { catF = c }
                        }
                    }
                    OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true,
                        label = { Text("Search texture or bundle name") }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp))
                }
                if (tab < 3 && shown.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("Nothing here", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                } else LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    if (tab < 3) items(shown, key = { it.bundle + "#" + it.idx }) { r -> RecRow(r) }
                    else items(res.bundles) { b -> BundleRow(b) }
                }
            }
        }
    }
}

@Composable
fun PotatoDialog(paths: List<String>, log: (String) -> Unit, onClose: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var level by remember { mutableIntStateOf(2) }
    val modes = remember { mutableStateListOf<Int>().apply { for (m in Cat.defaultMode) add(m) } }
    var sample by remember { mutableStateOf<UnityFs.Sample?>(null) }
    var status by remember { mutableStateOf("Looking for a real texture in your selection...") }
    val bmps = remember { mutableStateMapOf<Int, Bitmap?>() }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<PotatoResult?>(null) }
    var showReport by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var keepTxt by remember { mutableStateOf("") }
    var fullTxt by remember { mutableStateOf("training, tutorial") }
    fun words(t: String): List<String> = t.split(',', ';', '\n').map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    fun launchRun(dry: Boolean) {
        busy = true; result = null; note = ""
        scope.launch {
            try {
                val plan = Plan(modes.toIntArray(), level, dry, words(keepTxt), words(fullTxt), File(ctx.cacheDir, "thumbs"))
                val r = runPotato(ctx, paths, plan) { m -> progress = m; log(m) }
                result = r
                showReport = true
            } catch (t: Throwable) { note = "Error: ${t.message}" }
            busy = false
        }
    }

    LaunchedEffect(paths) {
        val found = withContext(Dispatchers.Default) {
            var best: UnityFs.Sample? = null
            var tried = 0
            loop@ for (p in paths) {
                val files = ArrayList<String>()
                Fs.walk(ctx, p) { f, size -> if (size in 64L..(300L shl 20) && !f.substringAfterLast('/').startsWith(".trashed-")) files.add(f) }
                for (f in files) {
                    if (tried >= 60) break@loop
                    if (!Fs.isBundle(ctx, f)) continue
                    tried++
                    val bytes = try { Fs.read(ctx, f) } catch (t: Throwable) { continue }
                    for (c in UnityFs.samples(bytes, 4)) { if (Preview.decode(c, 0) != null) { best = c; break@loop } }
                }
            }
            best
        }
        sample = found
        status = if (found == null) "No previewable texture found (none with mip levels, or this phone cannot decode their format)." else "Real texture from your selection: ${found.name}"
    }
    val kEff = sample?.let { UnityFs.effKOf(it, level) } ?: 0
    LaunchedEffect(sample, kEff) {
        val s = sample ?: return@LaunchedEffect
        for (k in listOf(0, kEff)) if (!bmps.containsKey(k)) bmps[k] = withContext(Dispatchers.Default) { Preview.decode(s, k) }
    }

    result?.let { r -> if (showReport) ReportScreen(r, onClose = { showReport = false }) }

    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text("Potato \uD83E\uDD54  (${paths.size} selected)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(status, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                val s = sample
                if (s != null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((k, label) in listOf(0 to "Original", kEff to LEVELS[level])) {
                            Column(Modifier.weight(1f)) {
                                val b = bmps[k]
                                if (b != null) Image(b.asImageBitmap(), label, Modifier.fillMaxWidth().aspectRatio(s.w.toFloat() / s.h).clip(RoundedCornerShape(10.dp)),
                                    contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low)
                                else Box(Modifier.fillMaxWidth().aspectRatio(s.w.toFloat() / s.h))
                                Text("$label\n${maxOf(1, s.w shr k)}x${maxOf(1, s.h shr k)}", fontSize = 11.sp)
                            }
                        }
                    }
                    Text("${Preview.fmtName(s.tf)}  \u2022  texture memory -${(100 - 100 / (1 shl (2 * kEff)))}%", fontSize = 12.sp)
                }
                Text("Level: ${LEVELS[level]}", fontWeight = FontWeight.SemiBold)
                Slider(value = level.toFloat(), onValueChange = { level = it.toInt() }, valueRange = 0f..6f, steps = 5, enabled = !busy)

                Text("What gets reduced (found automatically from texture names and asset paths):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                for (c in 0 until Cat.COUNT) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(Cat.names[c], Modifier.weight(1f), fontSize = 13.sp)
                        for (mm in 0..2) {
                            val on = modes[c] == mm
                            Text(
                                Cat.modeNames[mm],
                                Modifier.padding(start = 6.dp).clip(RoundedCornerShape(8.dp))
                                    .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable(enabled = !busy) { modes[c] = mm }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                fontSize = 12.sp,
                                color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Text("Keep = untouched, Light = at most 1/2, Potato = the level above.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value = fullTxt, onValueChange = { fullTxt = it }, enabled = !busy, singleLine = true,
                    label = { Text("Full potato bundles (words)") }, modifier = Modifier.fillMaxWidth())
                Text("Everything inside bundles whose path contains one of these words gets the level, whatever the categories say (training ground).",
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value = keepTxt, onValueChange = { keepTxt = it }, enabled = !busy, singleLine = true,
                    label = { Text("Extra: always keep sharp (words)") }, modifier = Modifier.fillMaxWidth())

                FilledTonalButton(enabled = !busy && level > 0, onClick = { launchRun(true) }) { Text("Scan only (nothing is written)") }
                if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(progress, fontSize = 11.sp, maxLines = 2) }
                if (note.isNotEmpty()) Text(note, fontSize = 12.sp)
                val r = result
                if (r != null) {
                    Text(r.text, fontSize = 12.sp)
                    FilledTonalButton(onClick = { showReport = true }) { Text("Open report with pictures (${r.recs.size})") }
                    if (!r.dry && r.written > 0 && r.pkgDir.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(enabled = !busy, onClick = {
                                busy = true
                                scope.launch { note = try { applyPotato(ctx, r) } catch (t: Throwable) { "Not applied: ${t.message}" }; busy = false }
                            }) { Text("Apply to game") }
                            FilledTonalButton(enabled = !busy, onClick = {
                                busy = true
                                scope.launch { note = try { restorePotato(ctx, r.pkg, r.pkgDir) } catch (t: Throwable) { "Not restored: ${t.message}" }; busy = false }
                            }) { Text("Restore originals") }
                        }
                        Text("Apply copies the new files into the game folder and first saves the original of each file in Tater Manager/Backup.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        confirmButton = {
            val r = result
            if (r != null && !r.dry && r.written > 0) TextButton(onClick = { onOpen(r.outDir) }) { Text("Open output") }
            else TextButton(enabled = !busy && level > 0, onClick = { launchRun(false) }) { Text(if (busy) "Working..." else "Start") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onClose) { Text("Close") } })
}
