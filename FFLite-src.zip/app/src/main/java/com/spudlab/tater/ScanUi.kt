package com.spudlab.tater

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val LEVEL_LABELS = listOf("Original (not touched)", "Lite (1/2)", "Extra Lite (1/4)", "Ultra Lite (1/8)", "Ultra Pro Max (1/16)", "Extreme (1/32)", "No Limit (1/64)")

private class Stats(val n: Int, val reduce: Int, val keep: Int, val cant: Int, val before: Long, val after: Long, val perCat: IntArray)

private fun computeStats(ds: List<Decision>): Stats {
    var reduce = 0; var keep = 0; var cant = 0
    var before = 0L; var after = 0L
    val perCat = IntArray(Cat.N)
    for (d in ds) {
        when (d.code) {
            Dec.REDUCE -> reduce++
            Dec.KEEP -> keep++
            else -> cant++
        }
        before += d.before; after += d.after
        perCat[d.cat]++
    }
    return Stats(ds.size, reduce, keep, cant, before, after, perCat)
}

private fun statusColor(code: Int): Color = when (code) {
    Dec.REDUCE -> Color(0xFF81C784)
    Dec.KEEP -> Color(0xFF64B5F6)
    else -> Color(0xFFFFB74D)
}

private fun statusWord(code: Int): String = when (code) {
    Dec.REDUCE -> "REDUCE"
    Dec.KEEP -> "KEPT"
    Dec.CANT -> "CANNOT"
    Dec.TINY -> "TINY"
    else -> "UNREADABLE"
}

@Composable
private fun Thumb(b: Bitmap?, dd: Int, pixel: Boolean, mark: String) {
    Box(Modifier.size(52.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF202020)), contentAlignment = Alignment.Center) {
        if (b == null) {
            Text(mark, fontSize = 12.sp, color = Color.Gray)
        } else {
            val shown = remember(b, dd) {
                if (dd <= 0) b else Bitmap.createScaledBitmap(b, maxOf(1, b.width shr dd), maxOf(1, b.height shr dd), true)
            }
            Image(remember(shown) { shown.asImageBitmap() }, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit,
                filterQuality = if (pixel) FilterQuality.None else FilterQuality.Low)
        }
    }
}

@Composable
private fun TexRow(t: UnityFs.TexInfo, d: Decision, manual: Boolean, onCat: (Int) -> Unit, onOpen: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable { onOpen() }.padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(t.thumb, 0, false, "no pic")
        if (d.code == Dec.REDUCE) Thumb(t.thumb, d.k - t.thumbK, true, "?") else Thumb(null, 0, false, "=")
        Column(Modifier.weight(1f)) {
            Text(t.name.ifEmpty { "(no name)" }, maxLines = 1, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            val size = if (t.w > 0) "${t.w}x${t.h}  ${Preview.fmtName(t.tf)}" + (if (t.mips > 1) "  ${t.mips} mips" else "") else "unknown"
            Text(if (d.code == Dec.REDUCE) "$size  \u2192  ${d.w2}x${d.h2}" else size, fontSize = 11.sp, maxLines = 1,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(statusWord(d.code) + ": " + d.note, fontSize = 11.sp, maxLines = 2, color = statusColor(d.code))
        }
        Box {
            TextButton(onClick = { menu = true }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) {
                Text(Cat.SHORT[d.cat] + (if (manual) " *" else ""), fontSize = 12.sp)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                for (c in 0 until Cat.N) {
                    DropdownMenuItem(text = { Text(Cat.NAMES[c]) }, onClick = { onCat(c); menu = false })
                }
            }
        }
    }
}

@Composable
private fun DetailDialog(t: UnityFs.TexInfo, d: Decision, pkgDir: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var pic by remember { mutableStateOf<Pair<Bitmap, Int>?>(null) }
    var msg by remember { mutableStateOf("Loading picture...") }
    LaunchedEffect(t.key) {
        val r = withContext(Dispatchers.Default) {
            try {
                val bytes = Fs.read(ctx, pkgDir + "/" + t.bundle)
                UnityFs.pictureOf(bytes, t.name, 1024)
            } catch (e: Throwable) {
                null
            }
        }
        pic = r
        msg = if (r == null) "No picture: this phone cannot decode this format, or the bundle cannot be read." else ""
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(t.name.ifEmpty { "(no name)" }, maxLines = 2, fontSize = 16.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val p = pic
                if (p != null) {
                    val b = p.first
                    val dd = d.k - p.second
                    val after = remember(b, dd) {
                        if (dd <= 0) b else Bitmap.createScaledBitmap(b, maxOf(1, b.width shr dd), maxOf(1, b.height shr dd), true)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f)) {
                            Image(remember(b) { b.asImageBitmap() }, "original",
                                Modifier.fillMaxWidth().aspectRatio(b.width.toFloat() / b.height).clip(RoundedCornerShape(8.dp)).background(Color(0xFF202020)),
                                contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low)
                            Text("Original\n${t.w}x${t.h}", fontSize = 11.sp)
                        }
                        Column(Modifier.weight(1f)) {
                            Image(remember(after) { after.asImageBitmap() }, "after",
                                Modifier.fillMaxWidth().aspectRatio(after.width.toFloat() / after.height).clip(RoundedCornerShape(8.dp)).background(Color(0xFF202020)),
                                contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.None)
                            Text("After\n${d.w2}x${d.h2}", fontSize = 11.sp)
                        }
                    }
                } else Text(msg, fontSize = 12.sp)
                Text(statusWord(d.code) + ": " + d.note, fontSize = 12.sp, color = statusColor(d.code))
                Text("Category: ${Cat.NAMES[d.cat]}\nFormat: ${Preview.fmtName(t.tf)}, ${t.mips} mip level(s)\n" +
                    "Texture memory: ${Fs.human(d.before)} \u2192 ${Fs.human(d.after)}\nBundle: ${t.bundle}", fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } })
}

/**
 * Full-screen Potato: 1) scan (nothing is changed), 2) a list of EVERY texture with a picture, its category and what
 * Potato will do (or why it cannot), 3) set a level per category, 4) run, 5) the same list again showing what really happened.
 */
@Composable
fun ScanScreen(paths: List<String>, log: (String) -> Unit, onClose: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var phase by remember { mutableIntStateOf(0) }   // 0 start, 1 scanning, 2 ready, 3 running, 4 done
    var thumbsOn by remember { mutableStateOf(true) }
    var backupOn by remember { mutableStateOf(true) }
    var resumeOn by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var scanned by remember { mutableStateOf<List<UnityFs.TexInfo>>(emptyList()) }
    var base by remember { mutableStateOf<ScanBase?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    var decisions by remember { mutableStateOf<List<Decision>>(emptyList()) }
    var finals by remember { mutableStateOf<Map<String, TexResult>?>(null) }
    var runInfo by remember { mutableStateOf<RunResult?>(null) }
    var verifyText by remember { mutableStateOf<String?>(null) }
    var fStatus by remember { mutableIntStateOf(0) }  // 0 all, 1 reduce, 2 kept, 3 cannot
    var fCat by remember { mutableIntStateOf(-1) }
    var query by remember { mutableStateOf("") }
    var showSet by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Int?>(null) }
    val levels = remember { Cat.DEFAULT_LEVELS.toList().toMutableStateList() }
    val wordTxt = remember { Cat.DEFAULT_WORDS.toMutableStateList() }
    val catOv = remember { mutableStateMapOf<String, Int>() }

    fun buildPolicy(): Policy = Policy(levels.toIntArray(), wordTxt.map { parseWords(it) }, catOv.toMap())

    LaunchedEffect(scanned, levels.toList(), wordTxt.toList(), catOv.toMap(), finals) {
        if (scanned.isEmpty()) return@LaunchedEffect
        delay(200)
        val pol = buildPolicy()
        val fin = finals
        val list = scanned
        decisions = withContext(Dispatchers.Default) {
            list.map { t -> if (fin != null) fromResult(t, fin[t.key], pol) else decide(t, pol) }
        }
    }

    val stats = remember(decisions) { computeStats(decisions) }
    val shown = remember(decisions, scanned, fStatus, fCat, query) {
        val q = query.trim().lowercase()
        val out = ArrayList<Int>()
        val n = minOf(decisions.size, scanned.size)
        for (i in 0 until n) {
            val d = decisions[i]
            val ok = when (fStatus) {
                1 -> d.code == Dec.REDUCE
                2 -> d.code == Dec.KEEP
                3 -> d.code == Dec.CANT || d.code == Dec.TINY || d.code == Dec.BAD
                else -> true
            }
            if (!ok) continue
            if (fCat >= 0 && d.cat != fCat) continue
            if (q.isNotEmpty() && !scanned[i].nameLow.contains(q) && !scanned[i].bundle.lowercase().contains(q)) continue
            out.add(i)
        }
        out
    }

    fun startScan() {
        phase = 1; progress = "Starting..."
        val sink = ArrayList<UnityFs.TexInfo>()
        job = scope.launch {
            try {
                base = scanAll(ctx, paths, thumbsOn, sink) { m -> progress = m }
            } catch (t: CancellationException) {
                progress = "Scan stopped. Showing what was found so far."
            } catch (t: Throwable) {
                progress = "Scan error: " + (t.message ?: t.javaClass.simpleName)
            } finally {
                scanned = sink.toList()
                phase = 2
            }
        }
    }

    fun startRun() {
        phase = 3; progress = "Starting..."
        val pol = buildPolicy()
        job = scope.launch {
            try {
                val r = runPotatoP(ctx, paths, pol, backupOn, resumeOn) { m -> progress = m; log(m) }
                runInfo = r
                finals = r.results.associateBy { it.bundle + "|" + it.name }
                progress = r.text
            } catch (t: CancellationException) {
                progress = "Stopped. Files already written stay in the output folder (turn on Resume to continue later)."
                log("Potato stopped")
            } catch (t: Throwable) {
                progress = "Error: " + (t.message ?: t.javaClass.simpleName)
            } finally {
                phase = if (runInfo != null) 4 else 2
            }
        }
    }

    fun listLines(): List<String> {
        val out = ArrayList<String>()
        out.add("category\tstatus\tname\tsize\tformat\tafter\tnote\tbundle")
        val n = minOf(decisions.size, scanned.size)
        for (i in 0 until n) {
            val t = scanned[i]; val d = decisions[i]
            out.add(Cat.NAMES[d.cat] + "\t" + statusWord(d.code) + "\t" + t.name + "\t" + t.w + "x" + t.h + "\t" + Preview.fmtName(t.tf) + "\t" +
                (if (d.code == Dec.REDUCE) "${d.w2}x${d.h2}" else "-") + "\t" + d.note + "\t" + t.bundle)
        }
        return out
    }

    Dialog(
        onDismissRequest = { if (phase != 1 && phase != 3) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(top = 8.dp)) {
                Text("Potato \uD83E\uDD54  (${paths.size} selected)", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))

                if (phase == 0) {
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Step 1: Scan. Nothing is changed. The app opens every bundle and makes a list of every texture: a picture of it, what kind it is " +
                            "(character, gun, lobby, effect, UI, environment), and what Potato will do to it, or why it cannot.", fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = thumbsOn, onCheckedChange = { thumbsOn = it })
                            Spacer(Modifier.width(10.dp))
                            Text("Make a picture of every texture (slower, but you can see them)", fontSize = 12.sp)
                        }
                    }
                } else if (phase == 1) {
                    Column(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text(progress, fontSize = 12.sp)
                    }
                } else {
                    // ---- summary ----
                    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        val saved = if (stats.before > 0) 100 - (100 * stats.after / stats.before) else 0L
                        Text("${stats.n} textures  \u2022  reduce ${stats.reduce}  \u2022  kept ${stats.keep}  \u2022  cannot ${stats.cant}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Texture memory: ${Fs.human(stats.before)} \u2192 about ${Fs.human(stats.after)}  (-$saved%)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (phase == 4) Text("This is what really happened in the run.", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for ((i, label) in listOf("All", "Reduce", "Kept", "Cannot").withIndex()) {
                            if (fStatus == i) Button(onClick = { fStatus = i }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(label, fontSize = 12.sp) }
                            else FilledTonalButton(onClick = { fStatus = i }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(label, fontSize = 12.sp) }
                        }
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val allLabel = "Any type"
                        if (fCat == -1) Button(onClick = { fCat = -1 }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(allLabel, fontSize = 12.sp) }
                        else FilledTonalButton(onClick = { fCat = -1 }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(allLabel, fontSize = 12.sp) }
                        for (c in 0 until Cat.N) {
                            val label = Cat.SHORT[c] + " " + stats.perCat[c]
                            if (fCat == c) Button(onClick = { fCat = c }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(label, fontSize = 12.sp) }
                            else FilledTonalButton(onClick = { fCat = c }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(label, fontSize = 12.sp) }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true, label = { Text("Search name or file", fontSize = 12.sp) }, modifier = Modifier.weight(1f))
                        TextButton(onClick = { showSet = !showSet }) { Text(if (showSet) "Hide settings" else "Settings") }
                    }

                    if (showSet) {
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Level for each type of texture. Tap \"Hide settings\" to see the list again, it updates live.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            for (c in 0 until Cat.N) {
                                Text("${Cat.NAMES[c]}: ${LEVEL_LABELS[levels[c]]}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Slider(value = levels[c].toFloat(), onValueChange = { levels[c] = it.toInt() }, valueRange = 0f..6f, steps = 5, enabled = phase != 3)
                                if (c != Cat.ENV) {
                                    OutlinedTextField(value = wordTxt[c], onValueChange = { wordTxt[c] = it }, singleLine = true, enabled = phase != 3,
                                        label = { Text("${Cat.SHORT[c]} words (a texture name or file path that contains one)", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth())
                                } else Text("Everything that matches none of the words above.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = backupOn, onCheckedChange = { backupOn = it }, enabled = phase != 3)
                                Spacer(Modifier.width(10.dp))
                                Text("Save a copy of every original that gets changed (Tater Manager/Backup)", fontSize = 12.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = resumeOn, onCheckedChange = { resumeOn = it }, enabled = phase != 3)
                                Spacer(Modifier.width(10.dp))
                                Text("Resume: skip bundles that are already in the output folder", fontSize = 12.sp)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(enabled = phase != 3, onClick = {
                                    for (c in 0 until Cat.N) { levels[c] = Cat.DEFAULT_LEVELS[c]; wordTxt[c] = Cat.DEFAULT_WORDS[c] }
                                }) { Text("Reset") }
                                FilledTonalButton(enabled = phase != 3 && catOv.isNotEmpty(), onClick = { catOv.clear() }) { Text("Clear my type changes (${catOv.size})") }
                            }
                        }
                    } else if (shown.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text(if (scanned.isEmpty()) "No textures found. Select the game's files folder (or contentcache) and try again." else "Nothing matches this filter.",
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                            items(shown, key = { it }) { i ->
                                val t = scanned[i]
                                val d = decisions[i]
                                TexRow(t, d, catOv.containsKey(t.key), onCat = { c -> catOv[t.key] = c }, onOpen = { detail = i })
                            }
                        }
                    }
                }

                // ---- bottom bar ----
                Surface(tonalElevation = 3.dp) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        when (phase) {
                            0 -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { startScan() }) { Text("Scan") }
                                TextButton(onClick = onClose) { Text("Close") }
                            }
                            1 -> Button(onClick = { job?.cancel() }) { Text("Stop and show what was found") }
                            2 -> {
                                if (progress.isNotEmpty()) Text(progress, fontSize = 11.sp, maxLines = 2, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Button(enabled = stats.reduce > 0, onClick = { startRun() }) { Text("Start Potato (${stats.reduce})") }
                                    FilledTonalButton(onClick = {
                                        val p = exportList(listLines())
                                        log("List saved: $p")
                                        Toast.makeText(ctx, "Saved: $p", Toast.LENGTH_LONG).show()
                                    }) { Text("Save list") }
                                    TextButton(onClick = onClose) { Text("Close") }
                                }
                            }
                            3 -> {
                                LinearProgressIndicator(Modifier.fillMaxWidth())
                                Text(progress, fontSize = 11.sp, maxLines = 2)
                                Button(onClick = { job?.cancel() }) { Text("Stop") }
                            }
                            else -> {
                                Text(runInfo?.text ?: progress, fontSize = 12.sp, modifier = Modifier.heightIn(max = 150.dp).verticalScroll(rememberScrollState()))
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    val ri = runInfo
                                    if (ri != null && ri.written > 0) Button(onClick = { onOpen(ri.outDir) }) { Text("Open output") }
                                    FilledTonalButton(onClick = { scope.launch { verifyText = "Checking..."; verifyText = verifyOutputs(ctx) } }) { Text("Verify in game") }
                                    FilledTonalButton(onClick = {
                                        val p = exportList(listLines())
                                        log("List saved: $p")
                                        Toast.makeText(ctx, "Saved: $p", Toast.LENGTH_LONG).show()
                                    }) { Text("Save list") }
                                    FilledTonalButton(onClick = {
                                        clipboard.setText(AnnotatedString(runInfo?.text ?: progress))
                                        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                                    }) { Text("Copy summary") }
                                    TextButton(onClick = { finals = null; runInfo = null; phase = 2 }) { Text("Run again") }
                                    TextButton(onClick = onClose) { Text("Close") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    detail?.let { di ->
        val t = scanned.getOrNull(di)
        val d = decisions.getOrNull(di)
        if (t != null && d != null) DetailDialog(t, d, base?.pkgDir ?: "", onClose = { detail = null })
    }

    verifyText?.let { v ->
        AlertDialog(
            onDismissRequest = { verifyText = null },
            title = { Text("Verify") },
            text = { Text(v, fontSize = 12.sp, modifier = Modifier.verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton(onClick = { verifyText = null }) { Text("OK") } })
    }
}
