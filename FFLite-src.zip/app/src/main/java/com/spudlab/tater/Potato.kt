package com.spudlab.tater

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private val PKG = Regex("^(.*/Android/(?:data|obb)/([^/]+))")

class PotatoResult(val text: String, val skips: List<Skip>)

/**
 * Processes every Unity bundle under the selected paths and writes the changed ones to
 * <storage>/Tater Manager/Potato Output/<package>/<same relative path as in the game>.
 *
 * keep  = words for things that must stay sharp (characters, guns): matching textures / bundles are not touched.
 * lobby = words for the lobby: matching textures get a light blur only (at most Lite 1/2), whatever the slider says.
 * Everything else gets the level from the slider.
 */
suspend fun runPotato(
    ctx: Context, paths: List<String>, level: Int, all: Boolean, keep: List<String>, lobby: List<String>, say: (String) -> Unit
): PotatoResult = withContext(Dispatchers.Default) {
    val m = paths.firstNotNullOfOrNull { PKG.find(it) }
    val pkg = m?.groupValues?.get(2) ?: "selected"
    val pkgDir = m?.groupValues?.get(1) ?: (File(paths.first()).parent ?: Fs.root)
    val out = File(Fs.root, "Tater Manager/Potato Output/$pkg")
    val ty = Tally()
    var written = 0; var seen = 0
    val limit = Runtime.getRuntime().maxMemory() / 5
    for (p in paths) {
        val files = ArrayList<Pair<String, Long>>()
        Fs.walk(ctx, p) { f, s -> files.add(f to s) }
        files.sortBy { it.second }                       // small files first, big ones last
        for ((f, size) in files) {
            if (size in 0L..63L) continue
            if (!Fs.isBundle(ctx, f)) continue
            seen++
            val name = f.substringAfterLast('/')
            ty.cur = name
            if (size > limit) { ty.tooBig++; say("Too big for the available memory: $name (${Fs.human(size)})"); continue }
            say("[$seen] $name")
            val bytes = try { Fs.read(ctx, f) } catch (t: Throwable) { ty.readFail++; say("Read failed: $name"); continue }
            val rel = f.removePrefix(pkgDir).trimStart('/')
            val res = try {
                UnityFs.process(bytes, level, keep, null, 4, all, ty, lobby = lobby, lobbyDrop = minOf(level, 1), hint = rel) { say(it) }
            } catch (t: Throwable) { ty.bad++; say("Failed: $name (${t.message})"); bytes to 0 }
            if (res.second > 0) {
                val dest = File(out, rel)
                dest.parentFile?.mkdirs()
                dest.writeBytes(res.first)
                if (dest.length() != res.first.size.toLong()) say("Write size mismatch: $rel") else { written++; say("  saved: $rel (${res.second} textures)") }
            }
        }
    }
    val lines = ArrayList<String>()
    lines.add("Bundles found: $seen, changed and saved: $written")
    lines.add("Textures reduced: ${ty.reduced}")
    if (ty.converted > 0) lines.add("  of them compressed textures without mips, re-encoded smaller (ETC2): ${ty.converted}")
    if (keep.isNotEmpty()) {
        if (ty.kept > 0) lines.add("Kept sharp (characters / guns): ${ty.kept}  e.g. ${ty.keptNames.joinToString(", ")}")
        else lines.add("Kept sharp: 0 (no texture matched: ${keep.joinToString(", ")})")
    }
    if (lobby.isNotEmpty()) {
        if (ty.lobby > 0) lines.add("Lobby, light blur only: ${ty.lobby}  e.g. ${ty.lobbyNames.joinToString(", ")}")
        else lines.add("Lobby: 0 (no texture matched: ${lobby.joinToString(", ")})")
    }
    if (ty.convFail > 0) lines.add("Could not convert, original kept: ${ty.convFail}")
    if (ty.noMip > 0) lines.add("No mip levels and this format cannot be re-encoded: ${ty.noMip}")
    if (ty.small > 0) lines.add("Already at the minimum size: ${ty.small}")
    if (ty.unsupported > 0) lines.add("Unsupported texture format: ${ty.unsupported}")
    if (ty.bad > 0) lines.add("Unreadable texture layout: ${ty.bad}")
    if (ty.badVersion > 0) lines.add("Unsupported Unity version: ${ty.badVersion}")
    if (ty.tooBig > 0) lines.add("Too big for memory: ${ty.tooBig}")
    if (ty.readFail > 0) lines.add("Read failures: ${ty.readFail}")
    if (ty.skips.isNotEmpty()) lines.add("Not changed: ${ty.skips.size} (pictures below)")
    lines.forEach(say)
    if (written > 0) lines.add("Output: ${out.path}")
    PotatoResult(lines.joinToString("\n"), ty.skips)
}
