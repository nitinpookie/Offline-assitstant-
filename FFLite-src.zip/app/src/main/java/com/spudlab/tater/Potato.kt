package com.spudlab.tater

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private val PKG = Regex("^(.*/Android/(?:data|obb)/([^/]+))")

class PotatoResult(
    val text: String, val recs: List<Rec>, val bundles: List<BRec>,
    val outDir: String, val pkg: String, val pkgDir: String, val reportPath: String, val dry: Boolean, val written: Int
)

private fun csv(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""

/**
 * Looks at every Unity bundle under the selected paths.
 *  - plan.dry = true : SCAN ONLY. Nothing is written; the report shows what would change and what would not.
 *  - plan.dry = false: changed bundles are written to <storage>/Tater Manager/Potato Output/<package>/<same relative path as in the game>.
 *    Every bundle is opened again and every texture is checked BEFORE it is saved; a bundle that fails the check is not saved.
 * A text report and a CSV (every texture, its category, before / after, reason) go to <storage>/Tater Manager/Potato Reports/<package>/.
 */
suspend fun runPotato(ctx: Context, paths: List<String>, plan: Plan, say: (String) -> Unit): PotatoResult = withContext(Dispatchers.Default) {
    val m = paths.firstNotNullOfOrNull { PKG.find(it) }
    val pkg = m?.groupValues?.get(2) ?: "selected"
    val pkgDirReal = m?.groupValues?.get(1) ?: ""
    val relBase = if (pkgDirReal.isNotEmpty()) pkgDirReal else (File(paths.first()).parent ?: Fs.root)
    val out = File(Fs.root, "Tater Manager/Potato Output/$pkg")
    plan.thumbDir?.let { it.deleteRecursively(); it.mkdirs() }
    val ty = Tally()
    var written = 0; var seen = 0; var trashed = 0; var failedCheck = 0
    val limit = Runtime.getRuntime().maxMemory() / 5
    for (p in paths) {
        val files = ArrayList<Pair<String, Long>>()
        Fs.walk(ctx, p) { f, s -> files.add(f to s) }
        files.sortBy { it.second }                       // small files first, big ones last
        for ((f, size) in files) {
            if (size in 0L..63L) continue
            val name = f.substringAfterLast('/')
            if (name.startsWith(".trashed-")) { trashed++; continue }   // copies Android already deleted
            if (!Fs.isBundle(ctx, f)) continue
            seen++
            ty.cur = name
            if (size > limit) {
                ty.tooBig++
                val b = BRec(name, size); b.note = "too big for the free memory of this phone (${Fs.human(size)})"
                ty.bundleRecs.add(b)
                say("Too big for the available memory: $name (${Fs.human(size)})"); continue
            }
            say("[$seen] $name")
            val bytes = try { Fs.read(ctx, f) } catch (t: Throwable) {
                ty.readFail++
                val b = BRec(name, size); b.note = "could not be read"
                ty.bundleRecs.add(b)
                say("Read failed: $name"); continue
            }
            val rel = f.removePrefix(relBase).trimStart('/')
            val startRec = ty.recs.size
            val startB = ty.bundleRecs.size
            fun failBundle(why: String) = failRecs(ty, startRec, startB, why)
            val res = try {
                UnityFs.process(bytes, plan, ty, rel) { say(it) }
            } catch (t: Throwable) {
                ty.bad++; failBundle("failed (${t.message})"); say("Failed: $name (${t.message})"); bytes to 0
            }
            if (res.second == 0 && !plan.dry && (startRec until ty.recs.size).any { ty.recs[it].status == 0 }) {
                failBundle(if (startB < ty.bundleRecs.size && ty.bundleRecs[startB].note.isNotEmpty()) ty.bundleRecs[startB].note else "not saved")
            }
            if (res.second > 0 && !plan.dry) {
                // check: open the NEW bundle again, every texture must read back as planned
                val good = verifyBundle(ty, startRec, res.first)
                if (!good) {
                    failedCheck++
                    failBundle("the check after writing failed, this bundle was NOT saved")
                    say("  check failed, not saved: $rel")
                } else {
                    try {
                        val dest = File(out, rel)
                        dest.parentFile?.mkdirs()
                        dest.writeBytes(res.first)
                        if (dest.length() != res.first.size.toLong()) { failBundle("write size mismatch"); say("Write size mismatch: $rel") }
                        else {
                            written++
                            if (startB < ty.bundleRecs.size) ty.bundleRecs[startB].saved = true
                            say("  saved: $rel (${res.second} textures, checked)")
                        }
                    } catch (t: Throwable) {
                        failBundle("could not write (${t.message})"); say("Could not write: $rel")
                    }
                }
            }
        }
    }

    buildResult(plan, ty, seen, written, trashed, failedCheck, pkg, pkgDirReal, out.path, emptyList(), say)
}

/** Marks every texture of a bundle that was going to be changed as not saved. */
internal fun failRecs(ty: Tally, startRec: Int, startB: Int, why: String) {
    for (i in startRec until ty.recs.size) {
        val r = ty.recs[i]
        if (r.status == 0) { r.status = 2; r.reason = "not saved: $why"; r.nw = r.w; r.nh = r.h; r.nfmt = r.fmt }
    }
    if (startB < ty.bundleRecs.size) { ty.bundleRecs[startB].note = why; ty.bundleRecs[startB].changed = 0 }
}

/** Opens the NEW bundle again: every texture must read back with the planned size. */
internal fun verifyBundle(ty: Tally, startRec: Int, data: ByteArray): Boolean {
    val inv = UnityFs.inventory(data) ?: return false
    for (i in startRec until ty.recs.size) {
        val r = ty.recs[i]
        if (r.status == 3) continue
        val x = inv.getOrNull(r.idx)
        val wantW = if (r.status == 0) r.nw else r.w
        val wantH = if (r.status == 0) r.nh else r.h
        if (x == null || !x.ok || x.w != wantW || x.h != wantH) return false
    }
    return true
}

internal fun buildResult(plan: Plan, ty: Tally, seen: Int, written: Int, trashed: Int, failedCheck: Int,
                         pkg: String, pkgDirReal: String, outPath: String, extra: List<String>, say: (String) -> Unit): PotatoResult {
    // ---------------- summary
    val recs = ty.recs
    val tot = IntArray(Cat.COUNT); val chg = IntArray(Cat.COUNT); val kpt = IntArray(Cat.COUNT); val cnt = IntArray(Cat.COUNT)
    var pix0 = 0.0; var pix1 = 0.0
    var nChanged = 0; var nKept = 0; var nCant = 0
    for (r in recs) {
        tot[r.cat]++
        when (r.status) {
            0 -> { chg[r.cat]++; nChanged++ }
            1 -> { kpt[r.cat]++; nKept++ }
            else -> { cnt[r.cat]++; nCant++ }
        }
        if (r.status != 3) { pix0 += r.w.toDouble() * r.h; pix1 += r.nw.toDouble() * r.nh }
    }
    val lines = ArrayList<String>()
    lines.add(if (plan.dry) "SCAN ONLY - nothing was written. This is what would happen:" else "Potato finished.")
    lines.addAll(extra)
    lines.add("Bundle files: $seen  (opened: ${ty.bundles}, could not open: ${seen - ty.bundles})")
    if (!plan.dry) lines.add("Saved bundles: $written  (each one was opened again and every texture checked)")
    lines.add("Textures found: ${recs.size}")
    lines.add((if (plan.dry) "Would change: " else "Changed: ") + nChanged + "   Kept on purpose: " + nKept + "   Not changeable: " + nCant)
    if (pix0 > 0) lines.add("Texture pixels in these files: 100% -> " + String.format("%.1f", 100.0 * pix1 / pix0) + "%")
    for (c in 0 until Cat.COUNT) {
        if (tot[c] > 0) lines.add("  ${Cat.names[c]}: ${tot[c]} textures - ${chg[c]} changed, ${kpt[c]} kept, ${cnt[c]} not changeable")
    }
    if (ty.converted > 0) lines.add("Re-encoded (no mip levels): ${ty.converted}")
    if (ty.placeholder > 0) lines.add("Placeholder pictures (8 px or less): ${ty.placeholder} - the real textures of these are NOT in your files (they are somewhere else, e.g. OBB)")
    if (ty.convFail > 0) lines.add("Could not re-encode, original kept: ${ty.convFail}")
    if (ty.noMip > 0) lines.add("No mip levels and this phone cannot re-encode the format: ${ty.noMip}")
    if (ty.small > 0) lines.add("Already as small as allowed: ${ty.small}")
    if (ty.unsupported > 0) lines.add("Format not supported (crunch / PVRTC / BC7): ${ty.unsupported}")
    if (ty.bad > 0) lines.add("Texture layout could not be read: ${ty.bad}")
    if (ty.badVersion > 0) lines.add("Bundles with an unsupported serialized-file version: ${ty.badVersion}")
    if (ty.badBundle > 0) lines.add("Broken or incomplete bundle files: ${ty.badBundle}")
    if (ty.tooBig > 0) lines.add("Too big for memory: ${ty.tooBig}")
    if (ty.readFail > 0) lines.add("Read failures: ${ty.readFail}")
    if (failedCheck > 0) lines.add("Failed the check after writing (NOT saved): $failedCheck")
    if (trashed > 0) lines.add("Skipped .trashed- files (old copies deleted by Android): $trashed")
    val noted = ty.bundleRecs.filter { it.note.isNotEmpty() }
    if (noted.isNotEmpty()) {
        lines.add("Bundles with a problem:")
        for (b in noted.take(8)) lines.add("  ${b.name.take(40)}: ${b.note}")
        if (noted.size > 8) lines.add("  ... and ${noted.size - 8} more (see the Bundles tab)")
    }

    // ---------------- report files
    var reportPath = ""
    try {
        val rdir = File(Fs.root, "Tater Manager/Potato Reports/$pkg")
        rdir.mkdirs()
        val txt = File(rdir, "Potato Report.txt")
        val sb = StringBuilder()
        for (l in lines) sb.append(l).append('\n')
        sb.append("\nBUNDLES\n")
        for (b in ty.bundleRecs) {
            sb.append(b.name).append(" | ").append(Fs.human(b.size)).append(" | ").append(b.info).append(" | textures ").append(b.tex)
                .append(" | changed ").append(b.changed).append(if (b.saved) " | saved" else "").append(if (b.note.isNotEmpty()) " | " + b.note else "").append('\n')
        }
        txt.writeText(sb.toString())
        val cf = File(rdir, "Potato Report.csv")
        val cs = StringBuilder("bundle,texture,category,status,before,after,reason\n")
        val stat = listOf("changed", "kept", "not changeable", "unreadable")
        for (r in recs) {
            cs.append(csv(r.bundle)).append(',').append(csv(r.name)).append(',').append(csv(Cat.names[r.cat])).append(',').append(stat[r.status]).append(',')
                .append(csv("${r.w}x${r.h} ${r.fmt}")).append(',').append(csv("${r.nw}x${r.nh} ${r.nfmt}")).append(',').append(csv(r.reason)).append('\n')
        }
        cf.writeText(cs.toString())
        reportPath = rdir.path
    } catch (t: Throwable) { }
    if (reportPath.isNotEmpty()) lines.add("Report files: $reportPath")
    if (written > 0) lines.add("Output: $outPath")
    lines.forEach(say)
    return PotatoResult(lines.joinToString("\n"), recs, ty.bundleRecs, outPath, pkg, pkgDirReal, reportPath, plan.dry, written)
}

/** Copies the saved bundles into the game folder. The original of every file is first copied to Tater Manager/Backup (only the first time). */
suspend fun applyPotato(ctx: Context, res: PotatoResult): String = withContext(Dispatchers.IO) {
    if (res.pkgDir.isEmpty()) return@withContext "The selected folder is not inside Android/data or Android/obb, so there is no game folder to apply to."
    val outDir = File(res.outDir)
    val backup = File(Fs.root, "Tater Manager/Backup/${res.pkg}")
    var n = 0; var b = 0
    val files = outDir.walkTopDown().filter { it.isFile }.toList()
    for (f in files) {
        val rel = f.path.removePrefix(res.outDir).trimStart('/')
        val dest = res.pkgDir + "/" + rel
        val bk = File(backup, rel)
        if (!bk.exists()) { Fs.copyTree(ctx, dest, bk.path); b++ }
        Fs.copyTree(ctx, f.path, dest); n++
    }
    "$n file(s) applied to the game folder. Originals saved in Tater Manager/Backup: $b new."
}

/** Puts the backed up original files back into the game folder. */
suspend fun restorePotato(ctx: Context, pkg: String, pkgDir: String): String = withContext(Dispatchers.IO) {
    if (pkgDir.isEmpty()) return@withContext "No game folder known."
    val backup = File(Fs.root, "Tater Manager/Backup/$pkg")
    if (!backup.exists()) return@withContext "No backup found yet (nothing was applied with Tater Manager)."
    var n = 0
    for (f in backup.walkTopDown().filter { it.isFile }) {
        val rel = f.path.removePrefix(backup.path).trimStart('/')
        Fs.copyTree(ctx, f.path, pkgDir + "/" + rel); n++
    }
    "$n original file(s) restored."
}
