package com.spudlab.tater

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Colour filter for the map textures. preset: 0 = Off, 1 = Vivid, 2 = Warm, 3 = Fresh. strength: 0..100.
 * The SAME maths is used for the preview picture and for the real textures (applyRgba), so the preview shows what you get.
 */
class ColorFx(val preset: Int, val strength: Int) {
    private val sat: Float
    private val con: Float
    private val bri: Float
    private val tr: Float
    private val tg: Float
    private val tb: Float

    init {
        val t = strength.coerceIn(0, 100) / 100f
        val p = PRESETS[preset.coerceIn(0, PRESETS.size - 1)]
        sat = 1f + (p[0] - 1f) * t
        con = 1f + (p[1] - 1f) * t
        bri = p[2] * t
        tr = 1f + (p[3] - 1f) * t
        tg = 1f + (p[4] - 1f) * t
        tb = 1f + (p[5] - 1f) * t
    }

    val active: Boolean get() = preset > 0 && strength > 0

    private fun cl(v: Float): Int = if (v < 0f) 0 else if (v > 255f) 255 else (v + 0.5f).toInt()

    /** r, g, b 0..255 in, packed 0xRRGGBB out. */
    private fun mix(r: Int, g: Int, bl: Int): Int {
        val l = 0.299f * r + 0.587f * g + 0.114f * bl
        val nr = l + (r - l) * sat
        val ng = l + (g - l) * sat
        val nb = l + (bl - l) * sat
        val off = 128f + bri * 255f
        val rr = cl(((nr - 128f) * con + off) * tr)
        val gg = cl(((ng - 128f) * con + off) * tg)
        val bb = cl(((nb - 128f) * con + off) * tb)
        return (rr shl 16) or (gg shl 8) or bb
    }

    /** RGBA bytes (R, G, B, A order), changed in place. Alpha is not touched. */
    fun applyRgba(b: ByteArray) {
        var i = 0
        while (i + 3 < b.size) {
            val m = mix(b[i].toInt() and 255, b[i + 1].toInt() and 255, b[i + 2].toInt() and 255)
            b[i] = (m shr 16).toByte()
            b[i + 1] = (m shr 8).toByte()
            b[i + 2] = m.toByte()
            i += 4
        }
    }

    /** Android ARGB pixels, changed in place, except inside the protect boxes (fractions 0..1 of the picture). */
    fun applyArgb(px: IntArray, w: Int, h: Int, protect: List<RectF>) {
        val boxes = protect.map { intArrayOf((it.left * w).toInt(), (it.top * h).toInt(), (it.right * w).toInt(), (it.bottom * h).toInt()) }
        for (y in 0 until h) {
            for (x in 0 until w) {
                var skip = false
                for (bx in boxes) {
                    if (x >= bx[0] && x < bx[2] && y >= bx[1] && y < bx[3]) { skip = true; break }
                }
                if (skip) continue
                val c = px[y * w + x]
                val m = mix((c shr 16) and 255, (c shr 8) and 255, c and 255)
                px[y * w + x] = (c and (0xFF shl 24)) or m
            }
        }
    }

    companion object {
        val NAMES = listOf("Off", "Vivid", "Warm", "Fresh")
        val HINTS = listOf("No colour change.", "Deeper, stronger colours.", "Warmer, a bit like a sunset.", "Cooler, clean and fresh.")
        // saturation, contrast, brightness, tint R, tint G, tint B  (at 100% strength)
        private val PRESETS = arrayOf(
            floatArrayOf(1f, 1f, 0f, 1f, 1f, 1f),
            floatArrayOf(1.45f, 1.12f, 0.02f, 1f, 1f, 1f),
            floatArrayOf(1.20f, 1.08f, 0.03f, 1.08f, 1.02f, 0.90f),
            floatArrayOf(1.30f, 1.10f, 0.03f, 0.93f, 1.03f, 1.08f)
        )
    }
}

/** The chosen filter is remembered between runs. */
object FxPrefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("tater_fx", Context.MODE_PRIVATE)
    fun load(ctx: Context): ColorFx {
        val s = sp(ctx)
        return ColorFx(s.getInt("preset", 0), s.getInt("strength", 60))
    }
    fun save(ctx: Context, fx: ColorFx) {
        sp(ctx).edit().putInt("preset", fx.preset).putInt("strength", fx.strength).apply()
    }
}

private val NONCOLOUR = Regex("normal|nrm|bump|mask|(^|_)ao(_|\$)|spec|smooth|metal|rough|height|disp|noise|lut|ramp|lookup|gradation|flow|sdf|(_n|_m|_s|_h|_r)\$")

/** Only map colour textures get the filter: not characters, weapons, UI, lobby, effects, lightmaps, and not normal / mask / lookup textures. */
fun fxWanted(cat: Int, nameLow: String): Boolean = (cat == Cat.MAP || cat == Cat.OTHER) && !NONCOLOUR.containsMatchIn(nameLow)

// boxes (fractions of the picture) that stay unchanged in the preview: the character and the buttons / HUD
private val PROTECT_STANDING = listOf(
    RectF(0.39f, 0.43f, 0.49f, 0.945f), RectF(0f, 0f, 0.14f, 0.26f), RectF(0.14f, 0f, 0.62f, 0.08f), RectF(0.72f, 0f, 1f, 0.45f),
    RectF(0f, 0.12f, 0.30f, 0.72f), RectF(0.30f, 0.10f, 0.40f, 0.45f), RectF(0.57f, 0.56f, 1f, 1f), RectF(0.03f, 0.90f, 0.57f, 1f)
)
private val PROTECT_MATCH = listOf(
    RectF(0.32f, 0.63f, 0.57f, 1f), RectF(0.23f, 0.36f, 0.29f, 0.51f), RectF(0f, 0f, 0.13f, 0.25f), RectF(0.18f, 0f, 0.97f, 0.10f),
    RectF(0.03f, 0.83f, 0.27f, 1f), RectF(0.59f, 0.62f, 0.72f, 0.88f), RectF(0.17f, 0.20f, 0.21f, 0.27f)
)

private fun renderAfter(s: Bitmap, fx: ColorFx, protect: List<RectF>): Bitmap {
    val w = s.width; val h = s.height
    val px = IntArray(w * h)
    s.getPixels(px, 0, w, 0, 0, w, h)
    if (fx.active) fx.applyArgb(px, w, h, protect)
    return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
}

private fun loadScaled(ctx: Context, uri: Uri, maxSide: Int): Bitmap? = try {
    val opt = BitmapFactory.Options()
    opt.inJustDecodeBounds = true
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt) }
    var sample = 1
    while (maxOf(opt.outWidth, opt.outHeight) / sample > maxSide * 2) sample *= 2
    val o2 = BitmapFactory.Options()
    o2.inSampleSize = sample
    val b = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    if (b != null && maxOf(b.width, b.height) > maxSide) {
        val f = maxSide.toFloat() / maxOf(b.width, b.height)
        Bitmap.createScaledBitmap(b, maxOf(1, (b.width * f).toInt()), maxOf(1, (b.height * f).toInt()), true)
    } else b
} catch (t: Throwable) {
    null
}

/** Colour filter window: 3 filters + a strength slider + a before / after picture of a game screenshot. */
@Composable
fun ColourLabDialog(initial: ColorFx, onApply: (ColorFx) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var preset by remember { mutableIntStateOf(initial.preset) }
    var strength by remember { mutableIntStateOf(initial.strength) }
    var sampleNo by remember { mutableIntStateOf(0) }          // 0, 1 = built-in screenshots, 2 = your own screenshot
    var own by remember { mutableStateOf<Bitmap?>(null) }
    var cx by remember { mutableFloatStateOf(0.5f) }
    var cy by remember { mutableFloatStateOf(0.65f) }
    var bw by remember { mutableFloatStateOf(0.14f) }
    var bh by remember { mutableFloatStateOf(0.55f) }
    var after by remember { mutableStateOf<Bitmap?>(null) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val b = loadScaled(ctx, uri, 1000)
            if (b != null) { own = b; sampleNo = 2 }
        }
    }
    val src: Bitmap? = remember(sampleNo, own) {
        when (sampleNo) {
            0 -> BitmapFactory.decodeResource(ctx.resources, R.drawable.sample_standing)
            1 -> BitmapFactory.decodeResource(ctx.resources, R.drawable.sample_match)
            else -> own
        }
    }
    val protect: List<RectF> = when (sampleNo) {
        0 -> PROTECT_STANDING
        1 -> PROTECT_MATCH
        else -> listOf(RectF(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2))
    }
    LaunchedEffect(src, preset, strength, sampleNo, cx, cy, bw, bh) {
        val s = src
        if (s == null) { after = null; return@LaunchedEffect }
        delay(60)
        after = withContext(Dispatchers.Default) { renderAfter(s, ColorFx(preset, strength), protect) }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Colour filter + preview", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Only the map colours change (ground, walls, trees, rocks, cars). Characters, weapons, buttons and the lobby stay as they are. " +
                    "In the preview the white boxes show what stays unchanged.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((i, label) in listOf("Sample 1", "Sample 2").withIndex()) {
                        if (sampleNo == i) Button(onClick = { sampleNo = i }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(label, fontSize = 12.sp) }
                        else FilledTonalButton(onClick = { sampleNo = i }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text(label, fontSize = 12.sp) }
                    }
                    if (sampleNo == 2) Button(onClick = { pick.launch("image/*") }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("My screenshot", fontSize = 12.sp) }
                    else FilledTonalButton(onClick = { pick.launch("image/*") }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("My screenshot", fontSize = 12.sp) }
                }
                val s = src
                val a = after
                if (s != null) {
                    Text("Before", fontSize = 12.sp)
                    Image(remember(s) { s.asImageBitmap() }, "before",
                        Modifier.fillMaxWidth().aspectRatio(s.width.toFloat() / s.height).clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low)
                    Text("After:  ${ColorFx.NAMES[preset]}, $strength%", fontSize = 12.sp)
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(s.width.toFloat() / s.height).clip(RoundedCornerShape(8.dp))
                            .pointerInput(sampleNo) {
                                detectTapGestures { p ->
                                    if (sampleNo == 2) { cx = (p.x / size.width).coerceIn(0f, 1f); cy = (p.y / size.height).coerceIn(0f, 1f) }
                                }
                            }
                            .pointerInput(sampleNo) {
                                detectDragGestures { change, _ ->
                                    if (sampleNo == 2) { cx = (change.position.x / size.width).coerceIn(0f, 1f); cy = (change.position.y / size.height).coerceIn(0f, 1f) }
                                }
                            }
                    ) {
                        val shown = a ?: s
                        Image(remember(shown) { shown.asImageBitmap() }, "after", Modifier.fillMaxSize(),
                            contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low)
                        Canvas(Modifier.matchParentSize()) {
                            for (r in protect) {
                                drawRect(Color.White, Offset(r.left * size.width, r.top * size.height),
                                    Size((r.right - r.left) * size.width, (r.bottom - r.top) * size.height), style = Stroke(width = 2f))
                            }
                        }
                    }
                    if (sampleNo == 2) {
                        Text("Tap or drag on the After picture to put the box over your character. Everything outside the box gets the filter.", fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Box width", fontSize = 11.sp)
                        Slider(value = bw, onValueChange = { bw = it }, valueRange = 0.05f..0.6f)
                        Text("Box height", fontSize = 11.sp)
                        Slider(value = bh, onValueChange = { bh = it }, valueRange = 0.1f..0.95f)
                    }
                } else {
                    Text("Pick a screenshot of the game with \"My screenshot\".", fontSize = 12.sp)
                }

                Text("Filter", fontWeight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in ColorFx.NAMES.indices) {
                        if (preset == i) Button(onClick = { preset = i }, contentPadding = PaddingValues(horizontal = 16.dp)) { Text(ColorFx.NAMES[i]) }
                        else FilledTonalButton(onClick = { preset = i }, contentPadding = PaddingValues(horizontal = 16.dp)) { Text(ColorFx.NAMES[i]) }
                    }
                }
                Text(ColorFx.HINTS[preset], fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Strength: $strength%", fontWeight = FontWeight.SemiBold)
                Slider(value = strength.toFloat(), onValueChange = { strength = it.toInt() }, valueRange = 0f..100f)
                Text("The colour is written into the map textures when you press Start (they are re-encoded, so patching takes longer). Off = no colour change.",
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val fx = ColorFx(preset, strength)
                        FxPrefs.save(ctx, fx)
                        onApply(fx)
                        onClose()
                    }) { Text("Use this filter") }
                    TextButton(onClick = onClose) { Text("Close") }
                }
            }
        }
    }
}
