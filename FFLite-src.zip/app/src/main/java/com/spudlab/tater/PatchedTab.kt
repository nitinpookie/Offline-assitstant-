package com.spudlab.tater

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One patched game: the folder <storage>/Tater Manager/Patched APK/<package> with its APK files (base + splits). */
private class PatchedSet(val pkg: String, val dir: File, val files: List<File>, val bytes: Long, val time: Long)

private fun loadPatched(): List<PatchedSet> {
    val root = File(Fs.root, "Tater Manager/Patched APK")
    val dirs = root.listFiles { f -> f.isDirectory } ?: return emptyList()
    val out = ArrayList<PatchedSet>()
    for (d in dirs) {
        val files = (d.listFiles { f -> f.isFile && f.name.endsWith(".apk") } ?: emptyArray()).sortedBy { it.name }
        if (files.isEmpty()) continue
        out.add(PatchedSet(d.name, d, files, files.sumOf { it.length() }, files.maxOf { it.lastModified() }))
    }
    return out.sortedByDescending { it.time }
}

/** Third tab: every patched APK set with an Install button (Android package installer), so a patched game can be installed again later. */
@Composable
fun PatchedTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sets by remember { mutableStateOf<List<PatchedSet>>(emptyList()) }
    var delAsk by remember { mutableStateOf<PatchedSet?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) { sets = withContext(Dispatchers.IO) { loadPatched() } }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Patched APKs", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { tick++ }) { Text("Refresh") }
        }
        Text(
            "Every game you patched is listed here. Tap Install to install it with the Android package installer. " +
                "The original game must be uninstalled first (different signature).",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (installMsg.isNotEmpty()) Text(installMsg, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 6.dp))
        if (sets.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No patched APK yet.\nPatch a game in the Game / APK tab first.", textAlign = TextAlign.Center, fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sets, key = { it.dir.path }) { s ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(s.pkg, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        "${s.files.size} APK file(s), ${Fs.human(s.bytes)}  \u2022  " +
                                            SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(s.time)),
                                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Button(onClick = { scope.launch(Dispatchers.IO) { Installer.install(ctx, s.dir.path) } }) { Text("\uD83D\uDCF2 Install") }
                            }
                            Text(s.files.joinToString(", ") { it.name }, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row {
                                TextButton(onClick = { Installer.uninstall(ctx, s.pkg) }) { Text("Uninstall original", fontSize = 12.sp) }
                                TextButton(onClick = { delAsk = s }) { Text("Delete", fontSize = 12.sp) }
                            }
                        }
                    }
                }
            }
        }
    }

    delAsk?.let { s ->
        AlertDialog(
            onDismissRequest = { delAsk = null },
            title = { Text("Delete patched APKs?") },
            text = { Text("${s.pkg}: ${s.files.size} file(s), ${Fs.human(s.bytes)}. They are removed from this phone's storage. You can patch again later.") },
            confirmButton = {
                TextButton(onClick = {
                    val d = s.dir
                    delAsk = null
                    scope.launch(Dispatchers.IO) { try { d.deleteRecursively() } catch (t: Throwable) { }; tick++ }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { delAsk = null }) { Text("Cancel") } }
        )
    }
}
