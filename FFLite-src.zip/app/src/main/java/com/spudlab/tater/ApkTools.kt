package com.spudlab.tater

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.android.apksig.ApkSigner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.zip.CRC32
import java.util.zip.ZipFile

/** 0 = Files tab, 1 = Game / APK tab. */
var mainTab by mutableIntStateOf(0)

/** APK files chosen in the Files tab, waiting in the Game / APK tab. */
var apkQueue by mutableStateOf<List<String>>(emptyList())

/** Last message of the install / uninstall steps (written by InstallReceiver and Installer). */
var installMsg by mutableStateOf("")

/** One APK (or the base + split APKs of an installed game). */
class ApkJob(val pkg: String, val label: String, val files: List<File>)

/** One entry of a zip / APK file. dataOff = where the stored bytes of the entry start inside the file. */
class ZEnt(
    val name: String, val method: Int, val csize: Long, val usize: Long, val flags: Int,
    val lhOff: Long, val cdCrcOff: Long, val dataOff: Long
)

object Zip {
    private fun le16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun le32(b: ByteArray, o: Int): Long = le16(b, o).toLong() or (le16(b, o + 2).toLong() shl 16)

    /** Reads the central directory of a zip / APK file (zip64 is not supported). */
    fun entries(f: File): List<ZEnt> {
        val out = ArrayList<ZEnt>()
        RandomAccessFile(f, "r").use { raf ->
            val len = raf.length()
            val tailLen = minOf(len, 65557L).toInt()
            val tail = ByteArray(tailLen)
            raf.seek(len - tailLen)
            raf.readFully(tail)
            var p = tailLen - 22
            while (p >= 0 && le32(tail, p) != 0x06054b50L) p--
            if (p < 0) throw IOException("not a zip / APK file")
            val total = le16(tail, p + 10)
            val cdSize = le32(tail, p + 12)
            val cdOff = le32(tail, p + 16)
            if (total == 0xFFFF || cdOff == 0xFFFFFFFFL) throw IOException("zip64 files are not supported")
            val cd = ByteArray(cdSize.toInt())
            raf.seek(cdOff)
            raf.readFully(cd)
            val lh = ByteArray(30)
            var q = 0
            for (i in 0 until total) {
                if (q + 46 > cd.size || le32(cd, q) != 0x02014b50L) break
                val flags = le16(cd, q + 8)
                val method = le16(cd, q + 10)
                val cs = le32(cd, q + 20)
                val us = le32(cd, q + 24)
                val nl = le16(cd, q + 28)
                val el = le16(cd, q + 30)
                val cl = le16(cd, q + 32)
                val lhOff = le32(cd, q + 42)
                val name = String(cd, q + 46, nl, Charsets.UTF_8)
                raf.seek(lhOff)
                raf.readFully(lh)
                val dataOff = lhOff + 30 + le16(lh, 26) + le16(lh, 28)
                out.add(ZEnt(name, method, cs, us, flags, lhOff, cdOff + q + 16, dataOff))
                q += 46 + nl + el + cl
            }
        }
        return out
    }

    fun readAt(raf: RandomAccessFile, off: Long, n: Int): ByteArray {
        val b = ByteArray(n)
        raf.seek(off)
        raf.readFully(b)
        return b
    }

    /** Writes a new CRC-32 for an entry (central directory + local header or data descriptor). */
    fun setCrc(raf: RandomAccessFile, e: ZEnt, crc: Long) {
        val b = ByteArray(4)
        b[0] = crc.toByte(); b[1] = (crc shr 8).toByte(); b[2] = (crc shr 16).toByte(); b[3] = (crc shr 24).toByte()
        raf.seek(e.cdCrcOff); raf.write(b)
        if ((e.flags and 8) == 0) {
            raf.seek(e.lhOff + 14); raf.write(b)
        } else {
            val d = readAt(raf, e.dataOff + e.csize, 4)
            val sig = le32(d, 0) == 0x08074b50L
            raf.seek(e.dataOff + e.csize + (if (sig) 4 else 0)); raf.write(b)
        }
    }
}

private val SKIP_EXT = setOf(
    "dex", "so", "arsc", "xml", "png", "jpg", "jpeg", "ogg", "mp3", "wav", "ttf", "otf", "mp4", "webm", "webp", "json", "txt",
    "properties", "kotlin_module", "version", "rsa", "sf", "mf", "dsa", "ec", "html", "css", "js", "pro", "proto", "tflite"
)

private fun extOf(name: String): String = name.substringAfterLast('/').substringAfterLast('.', "").lowercase()

/** Signs an APK with Tater's own key (APK signature scheme v2, the zip layout and alignment stay as they are). */
fun signApk(ctx: Context, inApk: File, outApk: File) {
    val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(ctx.assets.open("tater_sign_key.der").use { it.readBytes() }))
    val cert = ctx.assets.open("tater_sign_cert.der").use { CertificateFactory.getInstance("X.509").generateCertificate(it) } as X509Certificate
    val cfg = ApkSigner.SignerConfig.Builder("tater", key, listOf(cert)).build()
    outApk.parentFile?.mkdirs()
    if (outApk.exists()) outApk.delete()
    val builder = ApkSigner.Builder(listOf(cfg))
        .setInputApk(inApk)
        .setOutputApk(outApk)
        .setMinSdkVersion(26)
        .setV1SigningEnabled(false)
        .setV2SigningEnabled(true)
        .setV3SigningEnabled(false)
        .setV4SigningEnabled(false)
    // Keep the zip alignment when this apksig version has the option (apksig 8.2.2 does not, so it is called by name).
    try {
        builder.javaClass.getMethod("setAlignmentPreserved", java.lang.Boolean.TYPE).invoke(builder, true)
    } catch (t: Throwable) { }
    builder.build().sign()
}

/**
 * Potato for a game APK (or the base + split APKs of an installed game).
 * Unity bundles that are STORED (not compressed) inside the APK are changed in place: same size, same position, so nothing
 * else in the APK moves. Then every APK is signed again with Tater's key. Patched files go to
 * <storage>/Tater Manager/Patched APK/<package>/.
 * plan.dry = true: only reads and reports (what is inside the APK, which bundles can be changed, what would change).
 */
suspend fun runApkPotato(ctx: Context, job: ApkJob, plan: Plan, say: (String) -> Unit): PotatoResult = withContext(Dispatchers.Default) {
    val pkg = job.pkg
    val outDir = File(Fs.root, "Tater Manager/Patched APK/$pkg")
    val work = File(outDir, "work")
    val ty = Tally()
    val extra = ArrayList<String>()
    extra.add("Game: ${job.label} ($pkg), APK files: ${job.files.size}")
    var written = 0; var seen = 0; var failedCheck = 0
    val limit = Runtime.getRuntime().maxMemory() / 5

    if (!plan.dry) {
        val sizes = job.files.map { it.length() }
        val need = sizes.sum() + (sizes.maxOrNull() ?: 0L) + (100L shl 20)
        val free = File(Fs.root).usableSpace
        if (free < need) {
            extra.add("Not enough free storage: about ${Fs.human(need)} needed, ${Fs.human(free)} free. Nothing was done.")
            return@withContext buildResult(plan, ty, 0, 0, 0, 0, pkg, "", outDir.path, extra, say)
        }
        outDir.deleteRecursively()
        work.mkdirs()
    }
    plan.thumbDir?.let { it.deleteRecursively(); it.mkdirs() }

    val patched = HashSet<String>()
    for (apk in job.files) {
        say("Reading ${apk.name} ...")
        val ents = try { Zip.entries(apk) } catch (t: Throwable) {
            extra.add("${apk.name}: cannot be read (${t.message})"); continue
        }
        // ---- what is inside
        var stored = 0; var deflated = 0
        val ext = HashMap<String, LongArray>()
        for (e in ents) {
            if (e.method == 0) stored++ else deflated++
            val a = ext.getOrPut(extOf(e.name)) { LongArray(2) }
            a[0]++; a[1] += e.usize
        }
        val top = ext.entries.sortedByDescending { it.value[1] }.take(6).joinToString(", ") { "." + it.key + " " + it.value[0] + "x " + Fs.human(it.value[1]) }
        extra.add("${apk.name}: ${Fs.human(apk.length())}, ${ents.size} files (stored $stored, compressed $deflated)")
        extra.add("  biggest types: $top")
        val rawAssets = ents.count { extOf(it.name) == "assets" }
        val resS = ents.count { extOf(it.name) == "ress" }
        if (rawAssets + resS > 0) extra.add("  plain Unity data files: .assets $rawAssets, .resS $resS (not handled yet)")

        // ---- Unity bundles
        val cands = ents.filter { !it.name.endsWith("/") && it.usize >= 1024 && extOf(it.name) !in SKIP_EXT }
        val bundles = ArrayList<ZEnt>()
        val deflBundles = ArrayList<String>()
        val raf = RandomAccessFile(apk, "r")
        var outRaf: RandomAccessFile? = null
        try {
            var zf: ZipFile? = null
            for (e in cands) {
                if (e.method == 0) {
                    val mg = try { Zip.readAt(raf, e.dataOff, 7) } catch (t: Throwable) { continue }
                    if (String(mg, Charsets.ISO_8859_1) == "UnityFS") bundles.add(e)
                } else if (e.usize >= 65536) {
                    try {
                        val z: ZipFile = zf ?: ZipFile(apk).also { zf = it }
                        val ze = z.getEntry(e.name)
                        if (ze != null) {
                            val buf = ByteArray(7)
                            val n = z.getInputStream(ze).use { it.read(buf, 0, 7) }
                            if (n == 7 && String(buf, Charsets.ISO_8859_1) == "UnityFS") deflBundles.add(e.name)
                        }
                    } catch (t: Throwable) { }
                }
            }
            try { zf?.close() } catch (t: Throwable) { }
            extra.add("  Unity bundles: ${bundles.size} stored (can be changed), ${deflBundles.size} compressed inside the APK (cannot be changed in place)")
            for (n in deflBundles.take(3)) extra.add("    compressed: $n")

            // what the biggest files and folders are (tells what kind of data the game keeps in this APK)
            val dirs = HashMap<String, Long>()
            for (e in ents) {
                if (e.name.endsWith("/")) continue
                val parts = e.name.split('/')
                val key = if (parts.size > 2) parts[0] + "/" + parts[1] else parts[0]
                dirs[key] = (dirs[key] ?: 0L) + e.usize
            }
            extra.add("  biggest folders: " + dirs.entries.sortedByDescending { it.value }.take(6).joinToString(", ") { it.key + " " + Fs.human(it.value) })
            extra.add("  biggest files (name, size, stored/compressed, first 4 bytes):")
            for (b in ents.filter { !it.name.endsWith("/") }.sortedByDescending { it.usize }.take(8)) {
                var mg = ""
                if (b.method == 0 && b.usize >= 4) mg = try { Zip.readAt(raf, b.dataOff, 4).joinToString("") { x -> "%02x".format(x) } } catch (t: Throwable) { "" }
                extra.add("    " + b.name.takeLast(60) + "  " + Fs.human(b.usize) + "  " + (if (b.method == 0) "stored" else "compressed") + "  " + mg)
            }

            for (e in bundles) {
                seen++
                val shortName = e.name.substringAfterLast('/')
                ty.cur = shortName
                if (e.usize > limit) {
                    ty.tooBig++
                    val b = BRec(shortName, e.usize); b.note = "too big for the free memory of this phone (${Fs.human(e.usize)})"
                    ty.bundleRecs.add(b)
                    say("Too big for the available memory: ${e.name}")
                    continue
                }
                say("[$seen] ${e.name}")
                val bytes = try { Zip.readAt(raf, e.dataOff, e.usize.toInt()) } catch (t: Throwable) {
                    ty.readFail++
                    val b = BRec(shortName, e.usize); b.note = "could not be read"
                    ty.bundleRecs.add(b)
                    continue
                }
                val startRec = ty.recs.size
                val startB = ty.bundleRecs.size
                val res = try {
                    UnityFs.process(bytes, plan, ty, apk.name + "/" + e.name) { say(it) }
                } catch (t: Throwable) {
                    ty.bad++; failRecs(ty, startRec, startB, "failed (${t.message})"); bytes to 0
                }
                if (res.second == 0 && !plan.dry && (startRec until ty.recs.size).any { ty.recs[it].status == 0 }) {
                    failRecs(ty, startRec, startB, if (startB < ty.bundleRecs.size && ty.bundleRecs[startB].note.isNotEmpty()) ty.bundleRecs[startB].note else "not saved")
                }
                if (res.second > 0 && !plan.dry) {
                    if (!verifyBundle(ty, startRec, res.first) || res.first.size.toLong() != e.usize) {
                        failedCheck++
                        failRecs(ty, startRec, startB, "the check after changing failed, this bundle was NOT changed")
                        say("  check failed, not changed: ${e.name}")
                    } else {
                        try {
                            if (outRaf == null) {
                                val copy = File(work, apk.name)
                                say("  copying ${apk.name} ...")
                                apk.copyTo(copy, overwrite = true)
                                outRaf = RandomAccessFile(copy, "rw")
                            }
                            val o = outRaf!!
                            o.seek(e.dataOff)
                            o.write(res.first)
                            val crc = CRC32()
                            crc.update(res.first)
                            Zip.setCrc(o, e, crc.value)
                            written++
                            patched.add(apk.name)
                            if (startB < ty.bundleRecs.size) ty.bundleRecs[startB].saved = true
                            say("  changed in the APK: ${e.name} (${res.second} textures, checked)")
                        } catch (t: Throwable) {
                            failRecs(ty, startRec, startB, "could not write (${t.message})")
                            say("Could not write: ${e.name}")
                        }
                    }
                }
            }
        } finally {
            try { raf.close() } catch (t: Throwable) { }
            try { outRaf?.close() } catch (t: Throwable) { }
        }
    }

    // ---- sign every APK of the set (they all need the same signature)
    var signedOk = true
    if (!plan.dry && written > 0) {
        for (apk in job.files) {
            val src = if (apk.name in patched) File(work, apk.name) else apk
            val dst = File(outDir, apk.name)
            say("Signing ${apk.name} ...")
            try {
                signApk(ctx, src, dst)
            } catch (t: Throwable) {
                signedOk = false
                extra.add("SIGNING FAILED for ${apk.name}: ${t.message}")
                say("Signing failed: ${apk.name} (${t.message})")
                break
            }
            if (apk.name in patched) File(work, apk.name).delete()
        }
        work.deleteRecursively()
        if (signedOk) extra.add("Signed ${job.files.size} APK file(s) with Tater's key. The original game must be uninstalled before this one can be installed (different signature).")
    }
    buildResult(plan, ty, seen, if (signedOk) written else 0, 0, failedCheck, pkg, "", outDir.path, extra, say)
}

/** Install / uninstall helpers. */
object Installer {
    fun uninstall(ctx: Context, pkg: String) {
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    /** Installs every .apk in outDir as one install session (base + splits). Run on a background thread. */
    fun install(ctx: Context, outDir: String) {
        val files = (File(outDir).listFiles { f -> f.isFile && f.name.endsWith(".apk") } ?: emptyArray()).sortedBy { it.name }
        if (files.isEmpty()) { installMsg = "No patched APK found in $outDir"; return }
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            installMsg = "Allow \"Install unknown apps\" for Tater Manager in the window that opens, then press Install again."
            val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return
        }
        try {
            installMsg = "Preparing the install ..."
            val pi = ctx.packageManager.packageInstaller
            val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
            val session = pi.openSession(id)
            for (f in files) {
                f.inputStream().use { input ->
                    session.openWrite(f.name, 0, f.length()).use { o ->
                        input.copyTo(o)
                        session.fsync(o)
                    }
                }
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(ctx, id, Intent(ctx, InstallReceiver::class.java), flags)
            session.commit(pending.intentSender)
            session.close()
            installMsg = "Install started. Confirm in the Android window ..."
        } catch (t: Throwable) {
            installMsg = "Install failed: ${t.message}"
        }
    }
}

/** Receives the answer of the Android installer. */
class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val st = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)
        val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
        if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            val i = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            }
            installMsg = "Waiting for your confirmation in the Android window ..."
        } else if (st == PackageInstaller.STATUS_SUCCESS) {
            installMsg = "Installed. You can open the game now."
        } else {
            installMsg = "Install failed ($st): $msg"
        }
    }
}
