package com.spudlab.tater

import android.graphics.Bitmap
import net.jpountz.lz4.LZ4Factory
import org.tukaani.xz.LZMAInputStream
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Arrays

class Node(val off: Long, val size: Long, val flags: Int, val name: String)

/** Counters for the final report. */
class Skip(val name: String, val w: Int, val h: Int, val fmt: String, val reason: String, val thumb: Bitmap?, val bundle: String)

class Tally {
    var bundles = 0; var reduced = 0; var noMip = 0; var small = 0; var unsupported = 0; var bad = 0; var badVersion = 0
    var tooBig = 0; var readFail = 0
    var kept = 0; var lobby = 0; var converted = 0; var convFail = 0
    var cur = ""
    val skips = ArrayList<Skip>()
    val keptNames = ArrayList<String>()
    val lobbyNames = ArrayList<String>()
    /** Remember a texture that stayed unchanged (with a small picture of it when it could be decoded). Max 80 are kept. */
    fun skip(name: String, w: Int, h: Int, fmt: String, reason: String, thumb: Bitmap?) {
        if (skips.size < 80) skips.add(Skip(name, w, h, fmt, reason, thumb, cur))
    }
}

/**
 * Unity 2018 (UnityFS v6, serialized v17) bundles: texture ke sabse bade mip levels hata deta hai.
 * Sab kuch in-place hota hai (offsets/sizes same, bacha hua hissa zero), bundle ka size original jitna rehta hai.
 * Har texture ka size check hota hai; kuch bhi match na kare to wo texture chhod di jati hai.
 */
object UnityFs {
    private val lz4 = LZ4Factory.fastestInstance()
    private val astc = intArrayOf(4, 5, 6, 8, 10, 12)

    private fun cstr(b: ByteBuffer): String {
        val s = StringBuilder()
        while (true) { val c = b.get().toInt(); if (c == 0) break; s.append(c.toChar()) }
        return s.toString()
    }

    private fun dec(src: ByteArray, type: Int, usize: Int): ByteArray = when (type) {
        0 -> src
        1 -> {
            val out = ByteArray(usize)
            val dict = ByteBuffer.wrap(src, 1, 4).order(ByteOrder.LITTLE_ENDIAN).int
            DataInputStream(LZMAInputStream(ByteArrayInputStream(src, 5, src.size - 5), usize.toLong(), src[0], dict)).readFully(out)
            out
        }
        else -> ByteArray(usize).also { lz4.fastDecompressor().decompress(src, 0, it, 0, usize) }
    }

    /** (blockW, blockH, bytesPerBlock) */
    fun fmt(f: Int): IntArray? = when (f) {
        1 -> intArrayOf(1, 1, 1)
        2, 7, 9, 13 -> intArrayOf(1, 1, 2)
        3 -> intArrayOf(1, 1, 3)
        4, 5, 14 -> intArrayOf(1, 1, 4)
        10, 34, 41, 45, 46 -> intArrayOf(4, 4, 8)
        12, 43, 47 -> intArrayOf(4, 4, 16)
        in 48..53 -> intArrayOf(astc[f - 48], astc[f - 48], 16)
        in 54..59 -> intArrayOf(astc[f - 54], astc[f - 54], 16)
        else -> null
    }

    /** Channels per pixel for plain 8-bit formats (these can be resampled without an encoder), else 0. */
    fun channels(tf: Int): Int = when (tf) {
        1 -> 1
        3 -> 3
        4, 5, 14 -> 4
        else -> 0
    }

    fun lvlSize(tf: Int, w: Int, h: Int, i: Int): Int {
        val f = fmt(tf)!!
        return ((maxOf(1, w shr i) + f[0] - 1) / f[0]) * ((maxOf(1, h shr i) + f[1] - 1) / f[1]) * f[2]
    }

    private fun boxDown(src: ByteArray, w: Int, h: Int, ch: Int, k: Int): ByteArray {
        val nw = maxOf(1, w shr k); val nh = maxOf(1, h shr k); val s = 1 shl k
        val out = ByteArray(nw * nh * ch)
        for (y in 0 until nh) for (x in 0 until nw) for (c in 0 until ch) {
            var sum = 0; var n = 0
            for (dy in 0 until s) {
                val sy = minOf(h - 1, y * s + dy)
                for (dx in 0 until s) { val sx = minOf(w - 1, x * s + dx); sum += src[(sy * w + sx) * ch + c].toInt() and 0xFF; n++ }
            }
            out[(y * nw + x) * ch + c] = (sum / n).toByte()
        }
        return out
    }

    /** returns (new bundle bytes, shrunk texture count). Kuch na badla to original wapas. */
    fun process(file: ByteArray, drop: Int, keep: List<String>, report: StringBuilder?, minSide: Int = 32, all: Boolean = false, tally: Tally? = null,
                lobby: List<String> = emptyList(), lobbyDrop: Int = 1, hint: String = "", log: (String) -> Unit): Pair<ByteArray, Int> {
        val bb = ByteBuffer.wrap(file)
        if (file.size < 64 || cstr(bb) != "UnityFS") return file to 0
        val ver = bb.int; val uv = cstr(bb); val rev = cstr(bb)
        report?.append("  unity $rev\n")
        tally?.let { it.bundles++ }
        if (!(rev.startsWith("2017.") || rev.startsWith("2018.") || rev.startsWith("2019."))) {
            report?.append("  unsupported Unity version $rev\n"); log("  unsupported Unity version $rev"); tally?.let { it.badVersion++ }; return file to 0
        }
        val size = bb.long; val cbi = bb.int; val ubi = bb.int; val flags = bb.int
        val infoRaw = ByteArray(cbi)
        if ((flags and 0x80) != 0) System.arraycopy(file, (size - cbi).toInt(), infoRaw, 0, cbi) else bb.get(infoRaw)
        val info = ByteBuffer.wrap(dec(infoRaw, flags and 3, ubi))
        info.position(16)
        val blocks = List(info.int) { Triple(info.int, info.int, info.short.toInt() and 0xFFFF) }
        val nodes = List(info.int) { Node(info.long, info.long, info.int, cstr(info)) }
        val data = ByteArray(blocks.sumOf { it.first.toLong() }.toInt())
        var dp = 0
        for ((u, c, f) in blocks) {
            val chunk = ByteArray(c); bb.get(chunk)
            System.arraycopy(dec(chunk, f and 3, u), 0, data, dp, u); dp += u
        }
        var count = 0
        val st = IntArray(2)   // st[0] = saaf rakhi textures, st[1] = kul textures
        for (n in nodes) if ((n.flags and 4) != 0) count += shrinkSf(data, n.off.toInt(), nodes, drop, keep, lobby, lobbyDrop, hint.lowercase(), report, st, minSide, all, tally)
        if (report != null) { report.append("  => textures ${st[1]}, keyword se saaf rakhi ${st[0]}\n"); return file to 0 }
        if (st[0] > 0) log("  ${st[0]} textures saaf rakhi (keyword match)")
        if (count == 0) return file to 0

        // dobara pack: 128 KB LZ4HC blocks
        val comp = ByteArrayOutputStream(); val nb = ArrayList<Triple<Int, Int, Int>>()
        var i = 0
        while (i < data.size) {
            val n = minOf(131072, data.size - i)
            val buf = ByteArray(lz4.highCompressor().maxCompressedLength(n))
            val c = lz4.highCompressor().compress(data, i, n, buf, 0, buf.size)
            if (c >= n) { comp.write(data, i, n); nb.add(Triple(n, n, 0)) } else { comp.write(buf, 0, c); nb.add(Triple(n, c, 3)) }
            i += n
        }
        val bi = ByteArrayOutputStream(); val d = DataOutputStream(bi)
        d.write(ByteArray(16)); d.writeInt(nb.size)
        for ((u, c, f) in nb) { d.writeInt(u); d.writeInt(c); d.writeShort(f) }
        d.writeInt(nodes.size)
        for (n in nodes) { d.writeLong(n.off); d.writeLong(n.size); d.writeInt(n.flags); d.write(n.name.toByteArray()); d.write(0) }
        val iu = bi.toByteArray()
        val ic = ByteArray(lz4.highCompressor().maxCompressedLength(iu.size))
        val icl = lz4.highCompressor().compress(iu, 0, iu.size, ic, 0, ic.size)
        val headLen = 8 + 4 + uv.length + 1 + rev.length + 1 + 8 + 12
        val total = headLen + icl + comp.size()
        val out = ByteArrayOutputStream(maxOf(total, file.size)); val h = DataOutputStream(out)
        h.write("UnityFS".toByteArray()); h.write(0); h.writeInt(ver)
        h.write(uv.toByteArray()); h.write(0); h.write(rev.toByteArray()); h.write(0)
        h.writeLong(total.toLong()); h.writeInt(icl); h.writeInt(iu.size); h.writeInt(0x43)
        h.write(ic, 0, icl); comp.writeTo(h)
        if (total < file.size) h.write(ByteArray(file.size - total))   // original size tak pad (game size check karta hai)
        else log("  warning: bundle original se bada hai")
        return out.toByteArray() to count
    }

    private fun shrinkSf(d: ByteArray, base: Int, nodes: List<Node>, drop: Int, keep: List<String>, lobby: List<String>, lobbyDrop: Int, hint: String,
                         report: StringBuilder?, st: IntArray, minSide: Int, all: Boolean, ty: Tally?): Int {
        val h = ByteBuffer.wrap(d).order(ByteOrder.BIG_ENDIAN)
        h.position(base + 8)
        val version = h.int; val dataOff = h.int
        if (version < 17 || version > 19) { ty?.let { it.badVersion++ }; return 0 }
        val endian = h.get().toInt()
        if (endian != 0) { ty?.let { it.badVersion++ }; return 0 }
        h.position(base + 20)
        h.order(ByteOrder.LITTLE_ENDIAN)
        cstr(h); h.int
        val tt = h.get().toInt()
        val cids = IntArray(h.int)
        for (i in cids.indices) {
            val cid = h.int; cids[i] = cid
            h.position(h.position() + 3 + (if (cid == 114) 16 else 0) + 16)
            if (tt != 0) { val nn = h.int; val sb = h.int; h.position(h.position() + nn * (if (version >= 19) 32 else 24) + sb) }
        }
        if (!all && cids.any { it == 213 || it == 687078895 }) {   // Sprite/SpriteAtlas: UI na tute isliye skip
            report?.append("  (UI/Sprite bundle: chhoda jata hai)\n")
            return 0
        }
        val objs = ArrayList<IntArray>()   // {byteStart, byteSize, typeIndex}
        repeat(h.int) {
            h.position(base + ((h.position() - base + 3) and -4))
            h.long
            objs.add(intArrayOf(h.int, h.int, h.int))
        }
        // AssetBundle (class 142) ke container se asset ke path: character bundle pehchanne ke liye
        val paths = ArrayList<String>()
        for (ob in objs) if (cids[ob[2]] == 142) paths.addAll(containerPaths(d, base + dataOff + ob[0], ob[1]))
        val low = paths.map { it.lowercase() } + hint
        val bundleKeep = keep.isNotEmpty() && low.any { p -> keep.any { k -> p.contains(k) } }
        val bundleLobby = lobby.isNotEmpty() && low.any { p -> lobby.any { k -> p.contains(k) } }
        if (report != null) {
            report.append("  paths ${paths.size}${if (bundleKeep) " [KEYWORD MATCH]" else ""}: ")
                .append(paths.take(5).joinToString(" | ")).append('\n')
        }
        var n = 0
        val names = ArrayList<String>()
        for (ob in objs) {
            if (cids[ob[2]] != 28) continue
            val o = base + dataOff + ob[0]
            val nm = texName(d, o)
            st[1]++
            val lname = nm.lowercase()
            val kept = keep.isNotEmpty() && (bundleKeep || keep.any { k -> lname.contains(k) })
            if (kept) st[0]++
            if (report != null) { if (names.size < 6) names.add(if (kept) "$nm*" else nm); continue }
            if (kept) {
                ty?.let { it.kept++; if (it.keptNames.size < 6) it.keptNames.add(nm) }
                continue
            }
            val lob = lobby.isNotEmpty() && (bundleLobby || lobby.any { k -> lname.contains(k) })
            if (lob) ty?.let { it.lobby++; if (it.lobbyNames.size < 6) it.lobbyNames.add(nm) }
            if (shrinkTex(d, o, ob[1], nodes, if (lob) minOf(drop, lobbyDrop) else drop, minSide, ty, nm)) n++
        }
        if (report != null) report.append("  texture names: ").append(names.joinToString(", ")).append('\n')
        return n
    }

    private fun texName(d: ByteArray, o: Int): String = try {
        val nl = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN).getInt(o)
        if (nl < 0 || nl > 512 || o + 4 + nl > d.size) "" else String(d, o + 4, nl)
    } catch (t: Throwable) { "" }

    private fun containerPaths(d: ByteArray, o: Int, sz: Int): List<String> {
        val out = ArrayList<String>()
        try {
            val e = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
            var p = o
            fun str(): String {
                val n = e.getInt(p)
                if (n < 0 || n > 4096) throw IllegalStateException("bad string")
                val s = String(d, p + 4, n)
                p += 4 + n
                p = o + ((p - o + 3) and -4)
                return s
            }
            str()                                   // m_Name
            val pre = e.getInt(p); p += 4           // m_PreloadTable
            if (pre < 0 || pre > 5000000) return out
            p += pre * 12
            val cn = e.getInt(p); p += 4            // m_Container
            if (cn < 0 || cn > 1000000) return out
            for (i in 0 until cn) {
                if (p > o + sz) break
                out.add(str())
                p += 4 + 4 + 12                     // preloadIndex, preloadSize, PPtr
            }
        } catch (t: Throwable) { }
        return out
    }

    private fun shrinkTex(d: ByteArray, o: Int, sz: Int, nodes: List<Node>, drop: Int, minSide: Int, ty: Tally?, texName: String): Boolean {
        fun bad(why: String = "unreadable texture layout"): Boolean { ty?.let { it.bad++; it.skip(texName, 0, 0, "?", why, null) }; return false }
        val e = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        fun al(p: Int) = o + ((p - o + 3) and -4)
        val nl = e.getInt(o); if (nl < 0 || nl > 512) return bad()
        val wP = al(o + 4 + nl) + 8
        val w = e.getInt(wP); val hh = e.getInt(wP + 4); val csz = e.getInt(wP + 8); val tf = e.getInt(wP + 12); val mips = e.getInt(wP + 16)
        val f = fmt(tf) ?: run { ty?.let { it.unsupported++; it.skip(texName, w, hh, Preview.fmtName(tf), "format not supported by Potato (maybe crunch/PVRTC/BC7)", null) }; return false }
        if (w < 1 || hh < 1 || mips < 1 || mips > 16) return bad()
        val dlP = wP + 20 + 4 + 12 + 24 + 8
        val dl = e.getInt(dlP); val dataStart = dlP + 4
        val after = al(dataStart + maxOf(dl, 0))
        if (after + 12 > o + sz) return bad()
        fun lvl(i: Int) = ((maxOf(1, w shr i) + f[0] - 1) / f[0]) * ((maxOf(1, hh shr i) + f[1] - 1) / f[1]) * f[2]
        if ((0 until mips).sumOf { lvl(it) } != csz) return bad()
        val ch = channels(tf)
        val canConv = mips == 1 && ch == 0 && Reencode.canConvert(tf)
        val maxK = if (mips > 1) mips - 1 else if (ch > 0 || canConv) 8 else 0
        var k = minOf(drop, maxK)
        while (k > 0 && (maxOf(w, hh) shr k) < minSide) k--
        if (k == 0) {
            ty?.let {
                if (maxK == 0) { it.noMip++; it.skip(texName, w, hh, Preview.fmtName(tf), "compressed, no mip levels, and this format cannot be re-encoded", null) } else it.small++
            }
            return false
        }
        val pos: Int
        if (dl > 0) {                                   // texture is inside the bundle
            if (dl != csz) return bad()
            pos = dataStart
        } else {                                        // texture is in a .resS file
            if (e.getInt(after + 4) != csz) return bad()
            val pl = e.getInt(after + 8); if (pl < 0 || pl > 512) return bad()
            val path = String(d, after + 12, pl)
            val nd = nodes.firstOrNull { path.endsWith(it.name) } ?: return bad()
            pos = nd.off.toInt() + e.getInt(after)
        }
        if (pos < 0 || pos + csz > d.size) return bad()
        val nb: ByteArray
        val nm: Int
        var newTf = tf
        if (mips > 1) {
            var skip = 0; for (i in 0 until k) skip += lvl(i)
            nb = d.copyOfRange(pos + skip, pos + csz); nm = mips - k
        } else if (ch > 0) {
            nb = boxDown(d.copyOfRange(pos, pos + csz), w, hh, ch, k); nm = 1
        } else {
            // compressed, no mips: decode on the GPU, shrink, write ETC2, check it on the GPU again
            val r = Reencode.convert(tf, w, hh, d.copyOfRange(pos, pos + csz), k, csz, minSide)
            val rd = r.data
            if (rd == null) {
                ty?.let { it.convFail++; it.skip(texName, w, hh, Preview.fmtName(tf), r.why, r.thumb) }
                return false
            }
            nb = rd; nm = 1; k = r.k; newTf = r.tf
            ty?.let { it.converted++ }
        }
        if (dl > 0) {
            val tail = d.copyOfRange(after, o + sz)
            e.putInt(dlP, nb.size)
            System.arraycopy(nb, 0, d, dataStart, nb.size)
            val q = dataStart + nb.size; val qa = al(q)
            Arrays.fill(d, q, qa, 0)
            System.arraycopy(tail, 0, d, qa, tail.size)
            Arrays.fill(d, qa + tail.size, o + sz, 0)
        } else {
            System.arraycopy(nb, 0, d, pos, nb.size)
            Arrays.fill(d, pos + nb.size, pos + csz, 0)
            e.putInt(after + 4, nb.size)
        }
        e.putInt(wP, maxOf(1, w shr k)); e.putInt(wP + 4, maxOf(1, hh shr k))
        e.putInt(wP + 8, nb.size); e.putInt(wP + 12, newTf); e.putInt(wP + 16, nm)
        ty?.let { it.reduced++ }
        return true
    }

    // ---------------- real texture samples (for the preview) ----------------

    class Sample(val name: String, val w: Int, val h: Int, val tf: Int, val mips: Int, val chain: ByteArray)

    /** The mip level the engine would really keep for this sample at the given level (same rule as shrinkTex, minSide 4). */
    fun effKOf(s: Sample, drop: Int): Int {
        var k = minOf(drop, s.mips - 1)
        while (k > 0 && (maxOf(s.w, s.h) shr k) < 4) k--
        return k
    }

    fun samples(file: ByteArray, max: Int): List<Sample> {
        val out = ArrayList<Sample>()
        try {
            val bb = ByteBuffer.wrap(file)
            if (file.size < 64 || cstr(bb) != "UnityFS") return out
            bb.int; cstr(bb); val rev = cstr(bb)
            if (!(rev.startsWith("2017.") || rev.startsWith("2018.") || rev.startsWith("2019."))) return out
            val size = bb.long; val cbi = bb.int; val ubi = bb.int; val flags = bb.int
            val infoRaw = ByteArray(cbi)
            if ((flags and 0x80) != 0) System.arraycopy(file, (size - cbi).toInt(), infoRaw, 0, cbi) else bb.get(infoRaw)
            val info = ByteBuffer.wrap(dec(infoRaw, flags and 3, ubi))
            info.position(16)
            val blocks = List(info.int) { Triple(info.int, info.int, info.short.toInt() and 0xFFFF) }
            val nodes = List(info.int) { Node(info.long, info.long, info.int, cstr(info)) }
            val data = ByteArray(blocks.sumOf { it.first.toLong() }.toInt())
            var dp = 0
            for ((u, c, f) in blocks) {
                val chunk = ByteArray(c); bb.get(chunk)
                System.arraycopy(dec(chunk, f and 3, u), 0, data, dp, u); dp += u
            }
            for (n in nodes) if ((n.flags and 4) != 0) sampleSf(data, n.off.toInt(), nodes, out)
        } catch (t: Throwable) { }
        return out.sortedByDescending { it.w * it.h }.take(max)
    }

    private fun sampleSf(d: ByteArray, base: Int, nodes: List<Node>, out: MutableList<Sample>) {
        val h = ByteBuffer.wrap(d).order(ByteOrder.BIG_ENDIAN)
        h.position(base + 8)
        val version = h.int; val dataOff = h.int
        if (version < 17 || version > 19) return
        if (h.get().toInt() != 0) return
        h.position(base + 20)
        h.order(ByteOrder.LITTLE_ENDIAN)
        cstr(h); h.int
        val tt = h.get().toInt()
        val cids = IntArray(h.int)
        for (i in cids.indices) {
            val cid = h.int; cids[i] = cid
            h.position(h.position() + 3 + (if (cid == 114) 16 else 0) + 16)
            if (tt != 0) { val nn = h.int; val sb = h.int; h.position(h.position() + nn * (if (version >= 19) 32 else 24) + sb) }
        }
        repeat(h.int) {
            h.position(base + ((h.position() - base + 3) and -4))
            h.long
            val bs = h.int; val bz = h.int; val ti = h.int
            if (cids[ti] == 28) readSample(d, base + dataOff + bs, bz, nodes)?.let { out.add(it) }
        }
    }

    private fun readSample(d: ByteArray, o: Int, sz: Int, nodes: List<Node>): Sample? {
        val e = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        fun al(p: Int) = o + ((p - o + 3) and -4)
        val nl = e.getInt(o); if (nl < 0 || nl > 512) return null
        val wP = al(o + 4 + nl) + 8
        val w = e.getInt(wP); val hh = e.getInt(wP + 4); val csz = e.getInt(wP + 8); val tf = e.getInt(wP + 12); val mips = e.getInt(wP + 16)
        if (fmt(tf) == null || mips < 4 || mips > 16 || minOf(w, hh) < 64 || w > 4096 || hh > 4096) return null
        val dlP = wP + 20 + 4 + 12 + 24 + 8
        val dl = e.getInt(dlP); val dataStart = dlP + 4
        val after = al(dataStart + maxOf(dl, 0))
        if (after + 12 > o + sz) return null
        var sum = 0L; for (i in 0 until mips) sum += lvlSize(tf, w, hh, i)
        if (sum != csz.toLong()) return null
        val pos: Int
        if (dl > 0) {
            if (dl != csz) return null
            pos = dataStart
        } else {
            if (e.getInt(after + 4) != csz) return null
            val pl = e.getInt(after + 8); if (pl < 0 || pl > 512) return null
            val path = String(d, after + 12, pl)
            val nd = nodes.firstOrNull { path.endsWith(it.name) } ?: return null
            pos = nd.off.toInt() + e.getInt(after)
        }
        if (pos < 0 || pos + csz > d.size) return null
        return Sample(String(d, o + 4, nl), w, hh, tf, mips, d.copyOfRange(pos, pos + csz))
    }
}
