package com.spudlab.tater

import android.graphics.Bitmap
import net.jpountz.lz4.LZ4Factory
import org.tukaani.xz.LZMAInputStream
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Arrays

class Node(val off: Long, val size: Long, val flags: Int, val name: String)

/**
 * One line of the report = one texture.
 * status: 0 = changed (or would be changed in a scan), 1 = kept on purpose, 2 = could not be changed, 3 = unreadable.
 */
class Rec(
    val bundle: String, val idx: Int, val name: String, val cat: Int,
    val w: Int, val h: Int, val fmt: String,
    var nw: Int, var nh: Int, var nfmt: String,
    var status: Int, var reason: String,
    var thumbB: String = "", var thumbA: String = ""
)

/** One line per bundle file (the "Bundles" tab). */
class BRec(val name: String, val size: Long) {
    var info = ""
    var note = ""
    var tex = 0
    var changed = 0
    var saved = false
}

/** What the user chose. mode[category]: 0 = keep, 1 = light (at most 1/2), 2 = use level. full = words of bundles that get the level for EVERYTHING (training ground). */
class Plan(val mode: IntArray, val level: Int, val dry: Boolean, val words: List<String>, val full: List<String>, val thumbDir: File?, val fx: ColorFx? = null)

class BundleProblem(msg: String) : Exception(msg)

/** Counters for the final report + every texture / bundle line. */
class Tally {
    var bundles = 0; var reduced = 0; var noMip = 0; var small = 0; var unsupported = 0; var bad = 0; var badVersion = 0
    var tooBig = 0; var readFail = 0; var kept = 0; var converted = 0; var convFail = 0; var badBundle = 0; var placeholder = 0
    var cur = ""
    var ti = 0
    val recs = ArrayList<Rec>()
    val bundleRecs = ArrayList<BRec>()
}

/** Positions of the interesting fields of one Texture2D object (all absolute offsets inside the decoded bundle data). */
class Lay(
    val wP: Int, val tfP: Int, val mipP: Int, val dlP: Int, val dataStart: Int, val after: Int,
    val sOffP: Int, val sSizeP: Int, val pathP: Int, val pathLen: Int
)

class Tex(
    val name: String, val lay: Lay?, val w: Int, val h: Int, val csz: Int, val tf: Int, val mips: Int,
    val dl: Int, val pos: Int, val err: String
)

class SfInfo(val version: Int, val uvn: Int, val dataOff: Int, val cids: IntArray, val objs: List<IntArray>, val pids: LongArray = LongArray(0))

class Opened(val ver: Int, val uv: String, val rev: String, val flags: Int, val nodes: List<Node>, val data: ByteArray)

class Inv(val name: String, val w: Int, val h: Int, val tf: Int, val mips: Int, val ok: Boolean)

/**
 * Unity bundles (UnityFS v6 and v8) with serialized files v17-19 (Unity 2017-2019) and v22 (Unity 2022).
 * Textures lose their biggest mip levels (textures without mips are re-encoded smaller, see Reencode).
 * Everything is in place (same offsets and sizes), the rest is zero, and the bundle keeps the size of the original.
 */
object UnityFs {
    private val lz4 = LZ4Factory.fastestInstance()
    private val astc = intArrayOf(4, 5, 6, 8, 10, 12)
    private const val MIN_SIDE = 4
    private val LOOKUP = Regex("(^|[_ ])lut|lut[0-9]*$|ramp|gradation|lookup")
    const val ERR_FMT = "unsupported format"
    const val ERR_BAD = "unreadable texture layout"

    private fun cstr(b: ByteBuffer): String {
        val s = StringBuilder()
        while (true) { val c = b.get().toInt(); if (c == 0) break; s.append(c.toChar()) }
        return s.toString()
    }

    private fun dec(src: ByteArray, type: Int, usize: Int): ByteArray = when (type) {
        0 -> src
        1 -> {
            val out = ByteArray(usize)
            val dict = ByteBuffer.wrap(src, 1, 4).order(ByteOrder.LITTLE_ENDIAN).int
            DataInputStream(LZMAInputStream(ByteArrayInputStream(src, 5, src.size - 5), usize.toLong(), src[0], dict)).readFully(out)
            out
        }
        else -> ByteArray(usize).also { lz4.fastDecompressor().decompress(src, 0, it, 0, usize) }
    }

    /** (blockW, blockH, bytesPerBlock) */
    fun fmt(f: Int): IntArray? = when (f) {
        1 -> intArrayOf(1, 1, 1)
        2, 7, 9, 13 -> intArrayOf(1, 1, 2)
        3 -> intArrayOf(1, 1, 3)
        4, 5, 14 -> intArrayOf(1, 1, 4)
        10, 34, 41, 45, 46 -> intArrayOf(4, 4, 8)
        12, 43, 47 -> intArrayOf(4, 4, 16)
        in 48..53 -> intArrayOf(astc[f - 48], astc[f - 48], 16)
        in 54..59 -> intArrayOf(astc[f - 54], astc[f - 54], 16)
        else -> null
    }

    /** Channels per pixel for plain 8-bit formats (these can be resampled without an encoder), else 0. */
    fun channels(tf: Int): Int = when (tf) {
        1 -> 1
        3 -> 3
        4, 5, 14 -> 4
        else -> 0
    }

    fun lvlSize(tf: Int, w: Int, h: Int, i: Int): Int {
        val f = fmt(tf)!!
        return ((maxOf(1, w shr i) + f[0] - 1) / f[0]) * ((maxOf(1, h shr i) + f[1] - 1) / f[1]) * f[2]
    }

    private fun boxDown(src: ByteArray, w: Int, h: Int, ch: Int, k: Int): ByteArray {
        val nw = maxOf(1, w shr k); val nh = maxOf(1, h shr k); val s = 1 shl k
        val out = ByteArray(nw * nh * ch)
        for (y in 0 until nh) for (x in 0 until nw) for (c in 0 until ch) {
            var sum = 0; var n = 0
            for (dy in 0 until s) {
                val sy = minOf(h - 1, y * s + dy)
                for (dx in 0 until s) { val sx = minOf(w - 1, x * s + dx); sum += src[(sy * w + sx) * ch + c].toInt() and 0xFF; n++ }
            }
            out[(y * nw + x) * ch + c] = (sum / n).toByte()
        }
        return out
    }

    // ---------------------------------------------------------------- bundle container

    /** Reads the bundle container: header, block info, all data blocks decoded. Throws BundleProblem for a broken / partial file. */
    private fun open(file: ByteArray): Opened? {
        val bb = ByteBuffer.wrap(file)
        if (file.size < 64 || cstr(bb) != "UnityFS") return null
        val ver = bb.int; val uv = cstr(bb); val rev = cstr(bb)
        val size = bb.long; val cbi = bb.int; val ubi = bb.int; val flags = bb.int
        if (size > file.size.toLong()) throw BundleProblem("incomplete file: ${file.size} of $size bytes (download not finished?)")
        if (ver >= 7) bb.position((bb.position() + 15) and -16)
        val infoRaw = ByteArray(cbi)
        if ((flags and 0x80) != 0) System.arraycopy(file, (size - cbi).toInt(), infoRaw, 0, cbi)
        else {
            bb.get(infoRaw)
            if (ver >= 7 && (flags and 0x200) != 0) bb.position((bb.position() + 15) and -16)
        }
        val info = ByteBuffer.wrap(dec(infoRaw, flags and 3, ubi))
        info.position(16)
        val blocks = List(info.int) { Triple(info.int, info.int, info.short.toInt() and 0xFFFF) }
        val nodes = List(info.int) { Node(info.long, info.long, info.int, cstr(info)) }
        val data = ByteArray(blocks.sumOf { it.first.toLong() }.toInt())
        var dp = 0
        for ((u, c, f) in blocks) {
            val chunk = ByteArray(c); bb.get(chunk)
            System.arraycopy(dec(chunk, f and 3, u), 0, data, dp, u); dp += u
        }
        return Opened(ver, uv, rev, flags, nodes, data)
    }

    /** Serialized file header + type list + object table. null = version / endianness not supported. */
    private fun parseSf(d: ByteArray, base: Int): SfInfo? {
        val h = ByteBuffer.wrap(d).order(ByteOrder.BIG_ENDIAN)
        h.position(base + 8)
        val version = h.int
        var dataOff = h.int
        if (version == 22) {
            if (d[base + 0x28].toInt() != 0) return null
            dataOff = h.getLong(base + 0x20).toInt()
            h.position(base + 0x30)
        } else if (version in 17..19) {
            if (h.get().toInt() != 0) return null
            h.position(base + 20)
        } else return null
        h.order(ByteOrder.LITTLE_ENDIAN)
        val uvn = uvNum(cstr(h)); h.int
        val tt = h.get().toInt()
        val cids = IntArray(h.int)
        for (i in cids.indices) {
            val cid = h.int; cids[i] = cid
            h.position(h.position() + 3 + (if (cid == 114) 16 else 0) + 16)
            if (tt != 0) {
                val nn = h.int; val sb = h.int
                h.position(h.position() + nn * (if (version >= 19) 32 else 24) + sb)
                if (version >= 21) { val dn = h.int; h.position(h.position() + dn * 4) }
            }
        }
        val objs = ArrayList<IntArray>()   // {byteStart, byteSize, typeIndex}
        val pidl = ArrayList<Long>()       // path id of every object (same order)
        repeat(h.int) {
            h.position(base + ((h.position() - base + 3) and -4))
            pidl.add(h.long)
            if (version >= 22) {
                val bs = h.long.toInt()
                val bz = h.int; val ti = h.int
                objs.add(intArrayOf(bs, bz, ti))
            } else {
                val bs = h.int; val bz = h.int; val ti = h.int
                objs.add(intArrayOf(bs, bz, ti))
            }
        }
        return SfInfo(version, uvn, dataOff, cids, objs, pidl.toLongArray())
    }

    /** "5.6.3f1" -> 506, "2018.4.11f1" -> 201804, "2022.3.47f1" -> 202203 (so versions compare as numbers). */
    private fun uvNum(uv: String): Int {
        val p = uv.split('.')
        val major = p[0].toIntOrNull() ?: 2018
        val minor = if (p.size > 1) (p[1].toIntOrNull() ?: 0) else 0
        return major * 100 + minor
    }

    private fun texName(d: ByteArray, o: Int): String = try {
        val nl = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN).getInt(o)
        if (nl < 0 || nl > 512 || o + 4 + nl > d.size) "" else String(d, o + 4, nl)
    } catch (t: Throwable) { "" }

    private fun containerPaths(d: ByteArray, o: Int, sz: Int): List<String> {
        val out = ArrayList<String>()
        try {
            val e = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
            var p = o
            fun str(): String {
                val n = e.getInt(p)
                if (n < 0 || n > 4096) throw IllegalStateException("bad string")
                val s = String(d, p + 4, n)
                p += 4 + n
                p = o + ((p - o + 3) and -4)
                return s
            }
            str()                                   // m_Name
            val pre = e.getInt(p); p += 4           // m_PreloadTable
            if (pre < 0 || pre > 5000000) return out
            p += pre * 12
            val cn = e.getInt(p); p += 4            // m_Container
            if (cn < 0 || cn > 1000000) return out
            for (i in 0 until cn) {
                if (p > o + sz) break
                out.add(str())
                p += 4 + 4 + 12                     // preloadIndex, preloadSize, PPtr
            }
        } catch (t: Throwable) { }
        return out
    }

    // ---------------------------------------------------------------- one Texture2D object

    private fun layout(d: ByteArray, o: Int, sz: Int, sfv: Int, uvn: Int): Lay? {
        try {
            val e = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
            fun al(p: Int) = o + ((p - o + 3) and -4)
            val nl = e.getInt(o); if (nl < 0 || nl > 512) return null
            // Unity before 2017.3 (e.g. 5.6.3) has no fallback-format fields in front of the width
            val wP = al(o + 4 + nl) + (if (uvn >= 201703) 8 else 0)
            val big = sfv >= 22
            val tfP = wP + (if (big) 16 else 12)
            val mipP = tfP + 4
            val dlP: Int
            if (big) {
                // Unity 2022: bools, streaming priority, 2 more ints, image count, dimension, settings (24), lightmap + colour space (8)
                val pbP = mipP + 4 + 4 + 4 + 8 + 4 + 4 + 24 + 8
                val pb = e.getInt(pbP)
                if (pb < 0 || pb > 1048576) return null
                dlP = al(pbP + 4 + pb)
            } else {
                // bools (4), [streaming priority (4) since 2018.2], image count + dimension (8), texture settings (24, or 16 before 2017.1), lightmap + colour space (8)
                dlP = wP + 20 + 4 + (if (uvn >= 201802) 4 else 0) + 8 + (if (uvn >= 201701) 24 else 16) + 8
            }
            val dl = e.getInt(dlP)
            val dataStart = dlP + 4
            val after = al(dataStart + maxOf(dl, 0))
            val sSizeP = after + (if (big) 8 else 4)
            val plenP = sSizeP + 4
            val pathP = plenP + 4
            if (pathP > o + sz) return null
            val pl = e.getInt(plenP)
            if (pl < 0 || pl > 512 || al(pathP + pl) > o + sz) return null
            return Lay(wP, tfP, mipP, dlP, dataStart, after, after, sSizeP, pathP, pl)
        } catch (t: Throwable) {
            return null
        }
    }

    /** Reads and checks one texture. err is empty when everything is consistent. */
    private fun readTex(d: ByteArray, o: Int, sz: Int, nodes: List<Node>, sfv: Int, uvn: Int): Tex {
        val name = texName(d, o)
        val lay = layout(d, o, sz, sfv, uvn) ?: return Tex(name, null, 0, 0, 0, 0, 0, 0, 0, ERR_BAD)
        val e = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        val w = e.getInt(lay.wP); val h = e.getInt(lay.wP + 4); val csz = e.getInt(lay.wP + 8)
        val tf = e.getInt(lay.tfP); val mips = e.getInt(lay.mipP)
        val dl = e.getInt(lay.dlP)
        if (fmt(tf) == null) return Tex(name, lay, w, h, csz, tf, mips, dl, 0, ERR_FMT)
        if (w < 1 || h < 1 || mips < 1 || mips > 16) return Tex(name, lay, w, h, csz, tf, mips, dl, 0, ERR_BAD)
        var sum = 0L
        for (i in 0 until mips) sum += lvlSize(tf, w, h, i)
        if (sum != csz.toLong()) return Tex(name, lay, w, h, csz, tf, mips, dl, 0, ERR_BAD)
        val pos: Int
        if (dl > 0) {
            if (dl != csz) return Tex(name, lay, w, h, csz, tf, mips, dl, 0, ERR_BAD)
            pos = lay.dataStart
        } else {
            if (e.getInt(lay.sSizeP) != csz) return Tex(name, lay, w, h, csz, tf, mips, dl, 0, ERR_BAD)
            val path = String(d, lay.pathP, lay.pathLen)
            val nd = nodes.firstOrNull { path.endsWith(it.name) } ?: return Tex(name, lay, w, h, csz, tf, mips, dl, 0, ERR_BAD)
            val so = if (sfv >= 22) e.getLong(lay.sOffP).toInt() else e.getInt(lay.sOffP)
            pos = nd.off.toInt() + so
        }
        if (pos < 0 || pos + csz > d.size) return Tex(name, lay, w, h, csz, tf, mips, dl, 0, ERR_BAD)
        return Tex(name, lay, w, h, csz, tf, mips, dl, pos, "")
    }

    // ---------------------------------------------------------------- processing

    /** returns (new bundle bytes, changed texture count). Nothing changed / scan only / problem: the original comes back with 0 or the count. */
    fun process(file: ByteArray, plan: Plan, ty: Tally, hint: String, log: (String) -> Unit): Pair<ByteArray, Int> {
        val br = BRec(ty.cur, file.size.toLong())
        ty.bundleRecs.add(br)
        ty.ti = 0
        val op: Opened = try {
            open(file) ?: run { br.note = "not a Unity bundle"; return file to 0 }
        } catch (t: BundleProblem) {
            br.note = t.message ?: "unreadable bundle"; ty.badBundle++; log("  ${br.note}"); return file to 0
        }
        ty.bundles++
        br.info = "Unity ${op.rev}, bundle v${op.ver}"
        var count = 0
        for (n in op.nodes) if ((n.flags and 4) != 0) count += shrinkSf(op.data, n.off.toInt(), op.nodes, plan, ty, br, hint)
        br.tex = ty.ti
        br.changed = count
        if (count == 0) return file to 0
        if (plan.dry) return file to count

        // pack again: 128 KB LZ4HC blocks
        val data = op.data; val nodes = op.nodes; val ver = op.ver
        val comp = ByteArrayOutputStream(); val nb = ArrayList<Triple<Int, Int, Int>>()
        var i = 0
        while (i < data.size) {
            val n = minOf(131072, data.size - i)
            val buf = ByteArray(lz4.highCompressor().maxCompressedLength(n))
            val c = lz4.highCompressor().compress(data, i, n, buf, 0, buf.size)
            if (c >= n) { comp.write(data, i, n); nb.add(Triple(n, n, 0)) } else { comp.write(buf, 0, c); nb.add(Triple(n, c, 3)) }
            i += n
        }
        val bi = ByteArrayOutputStream(); val d = DataOutputStream(bi)
        d.write(ByteArray(16)); d.writeInt(nb.size)
        for ((u, c, f) in nb) { d.writeInt(u); d.writeInt(c); d.writeShort(f) }
        d.writeInt(nodes.size)
        for (n in nodes) { d.writeLong(n.off); d.writeLong(n.size); d.writeInt(n.flags); d.write(n.name.toByteArray()); d.write(0) }
        val iu = bi.toByteArray()
        val ic = ByteArray(lz4.highCompressor().maxCompressedLength(iu.size))
        val icl = lz4.highCompressor().compress(iu, 0, iu.size, ic, 0, ic.size)
        val headLen = 8 + 4 + op.uv.length + 1 + op.rev.length + 1 + 8 + 12
        val big = ver >= 7
        val pad1 = if (big) ((headLen + 15) and -16) - headLen else 0
        val endInfo = headLen + pad1 + icl
        val pad2 = if (big) ((endInfo + 15) and -16) - endInfo else 0
        val total = endInfo + pad2 + comp.size()
        if (total > file.size) {
            br.note = "result would be bigger than the original, not saved"
            log("  ${br.note}")
            return file to 0
        }
        val out = ByteArrayOutputStream(file.size); val h = DataOutputStream(out)
        h.write("UnityFS".toByteArray()); h.write(0); h.writeInt(ver)
        h.write(op.uv.toByteArray()); h.write(0); h.write(op.rev.toByteArray()); h.write(0)
        h.writeLong(total.toLong()); h.writeInt(icl); h.writeInt(iu.size); h.writeInt(if (big) 0x243 else 0x43)
        if (pad1 > 0) h.write(ByteArray(pad1))
        h.write(ic, 0, icl)
        if (pad2 > 0) h.write(ByteArray(pad2))
        comp.writeTo(h)
        if (total < file.size) h.write(ByteArray(file.size - total))   // pad to the original size (the game checks it)
        return out.toByteArray() to count
    }

    /**
     * Path ids of the textures that Sprites of this file use. A sprite stores its picture as pixel rectangles of ONE texture (an atlas), so such a
     * texture must keep its size, otherwise the buttons / banners turn into grey squares. Layout (Unity 2017-2022): name, rect (16), offset (8),
     * border (16), pixelsToUnits (4), pivot (8), extrude (4), isPolygon (4), render data key (24), atlas tags (array of strings), sprite atlas PPtr (12),
     * then m_RD.texture PPtr (fileID int32 + pathID int64). A value only counts when it is a texture of THIS file, so a layout that does not fit gives nothing.
     */
    private fun spriteTextures(d: ByteArray, base: Int, sf: SfInfo, texIds: Set<Long>): Set<Long> {
        val out = HashSet<Long>()
        val e = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        for ((i, ob) in sf.objs.withIndex()) {
            if (sf.cids[ob[2]] != 213) continue
            try {
                val o = base + sf.dataOff + ob[0]
                val end = o + ob[1]
                var p = o
                val nl = e.getInt(p); if (nl < 0 || nl > 512) continue
                p += 4 + ((nl + 3) and -4)
                p += 16 + 8 + 16 + 4 + 8 + 4 + 4 + 24
                val nTags = e.getInt(p); if (nTags < 0 || nTags > 64) continue
                p += 4
                var bad = false
                for (t in 0 until nTags) {
                    val l = e.getInt(p)
                    if (l < 0 || l > 512) { bad = true; break }
                    p += 4 + ((l + 3) and -4)
                }
                if (bad || p + 24 > end) continue
                p += 12
                val fileId = e.getInt(p)
                val pid = e.getLong(p + 4)
                if (fileId == 0 && pid in texIds) out.add(pid)
            } catch (t: Throwable) { }
        }
        return out
    }

    /** A texture without mip levels and with clamped edges is almost always a UI picture / atlas (world textures repeat and have mips). */
    private fun spriteLike(d: ByteArray, o: Int, sz: Int, sfv: Int, uvn: Int): Boolean {
        if (uvn < 201701) return false
        val lay = layout(d, o, sz, sfv, uvn) ?: return false
        val e = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        val mips = e.getInt(lay.mipP)
        val wu = if (sfv >= 22) e.getInt(lay.mipP + 40) else e.getInt(lay.dlP - 20)
        val wv = if (sfv >= 22) e.getInt(lay.mipP + 44) else e.getInt(lay.dlP - 16)
        return mips == 1 && wu == 1 && wv == 1
    }

    private fun shrinkSf(d: ByteArray, base: Int, nodes: List<Node>, plan: Plan, ty: Tally, br: BRec, bhint: String): Int {
        val sf = try { parseSf(d, base) } catch (t: Throwable) { null }
        if (sf == null) {
            ty.badVersion++
            br.note = "serialized file version not supported"
            return 0
        }
        val paths = ArrayList<String>()
        for (ob in sf.objs) if (sf.cids[ob[2]] == 142) paths.addAll(containerPaths(d, base + sf.dataOff + ob[0], ob[1]))
        val hintAll = (bhint + " " + paths.take(16).joinToString(" ")).lowercase()
        val hasSprite = sf.cids.any { it == 213 || it == 687078895 }
        val fullPotato = plan.full.isNotEmpty() && plan.full.any { hintAll.contains(it) }
        val texIds = HashSet<Long>()
        for ((i, ob) in sf.objs.withIndex()) if (sf.cids[ob[2]] == 28 && i < sf.pids.size) texIds.add(sf.pids[i])
        val spriteTex: Set<Long> = if (sf.cids.any { it == 213 }) spriteTextures(d, base, sf, texIds) else emptySet()
        var n = 0
        for ((oi, ob) in sf.objs.withIndex()) {
            if (sf.cids[ob[2]] != 28) continue
            val o = base + sf.dataOff + ob[0]
            val nm = texName(d, o)
            val lname = nm.lowercase()
            var cat = Classify.of(nm, hintAll)
            if (hasSprite && cat == Cat.OTHER) cat = Cat.UI
            var uiWhy = ""
            if (oi < sf.pids.size && sf.pids[oi] in spriteTex) { cat = Cat.UI; uiWhy = "used by Sprites of this file (a UI picture / atlas)" }
            else if (cat == Cat.OTHER && spriteLike(d, o, ob[1], sf.version, sf.uvn)) { cat = Cat.UI; uiWhy = "looks like a UI picture (no mip levels, clamped edges)" }
            val word = plan.words.isNotEmpty() && plan.words.any { lname.contains(it) || hintAll.contains(it) }
            val m = if (fullPotato && uiWhy.isEmpty()) 2 else plan.mode[cat]
            var drop = when (m) { 0 -> 0; 1 -> minOf(plan.level, 1); else -> plan.level }
            var why = "kept: ${Cat.names[cat]} is set to Keep" + (if (uiWhy.isNotEmpty()) " ($uiWhy)" else "")
            if (word) { drop = 0; why = "kept: matches your extra keep word" }
            if (LOOKUP.containsMatchIn(lname)) { drop = 0; why = "kept: colour lookup / ramp texture (shrinking it would break the colours)" }
            val idx = ty.ti
            ty.ti = ty.ti + 1
            if (shrinkTex(d, o, ob[1], nodes, sf.version, sf.uvn, drop, why, cat, idx, plan, ty, nm)) n++
        }
        return n
    }

    private fun shrinkTex(d: ByteArray, o: Int, sz: Int, nodes: List<Node>, sfv: Int, uvn: Int, drop: Int, keptWhy: String, cat: Int, idx: Int,
                          plan: Plan, ty: Tally, texName: String): Boolean {
        fun newRec(w: Int, h: Int, fmtName: String, status: Int, reason: String): Rec {
            val r = Rec(ty.cur, idx, texName, cat, w, h, fmtName, w, h, fmtName, status, reason)
            ty.recs.add(r)
            return r
        }
        fun key() = "r" + (ty.recs.size - 1)
        val tx = readTex(d, o, sz, nodes, sfv, uvn)
        val lay = tx.lay
        if (tx.err.isNotEmpty() || lay == null) {
            if (tx.err == ERR_FMT) { ty.unsupported++; newRec(tx.w, tx.h, Preview.fmtName(tx.tf), 2, "format not supported by Potato (crunch / PVRTC / BC7...)") }
            else { ty.bad++; newRec(tx.w, tx.h, if (tx.tf != 0 || tx.w != 0) Preview.fmtName(tx.tf) else "?", 3, "texture layout could not be read") }
            return false
        }
        val e = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        val w = tx.w; val hh = tx.h; val csz = tx.csz; val tf = tx.tf; val mips = tx.mips; val pos = tx.pos; val dl = tx.dl
        val fname = Preview.fmtName(tf)
        val dir = plan.thumbDir
        fun al(p: Int) = o + ((p - o + 3) and -4)

        if (drop == 0) {
            ty.kept++
            val r = newRec(w, hh, fname, 1, keptWhy)
            if (dir != null) r.thumbB = Thumbs.before(dir, key(), texName, tf, w, hh, mips, d, pos, csz)
            return false
        }
        val ch = channels(tf)
        val canConv = mips == 1 && ch == 0 && Reencode.canConvert(tf)
        val maxK = if (mips > 1) mips - 1 else if (ch > 0 || canConv) 8 else 0
        var k = minOf(drop, maxK)
        while (k > 0 && (maxOf(w, hh) shr k) < MIN_SIDE) k--
        if (k == 0) {
            val r: Rec
            if (maxK == 0) { ty.noMip++; r = newRec(w, hh, fname, 2, "compressed without mip levels, this phone cannot re-encode ${fname}") }
            else if (maxOf(w, hh) <= 8) { ty.placeholder++; r = newRec(w, hh, fname, 2, "placeholder picture (${w}x$hh): the real texture is NOT in this file") }
            else { ty.small++; r = newRec(w, hh, fname, 2, "already as small as allowed") }
            if (dir != null) r.thumbB = Thumbs.before(dir, key(), texName, tf, w, hh, mips, d, pos, csz)
            return false
        }

        // scan only: compressed without mips would need the (slow) re-encode, so it is only announced
        if (plan.dry && mips == 1 && ch == 0) {
            ty.reduced++
            val r = newRec(w, hh, fname, 0, "will be re-encoded smaller (no mip levels), 1/${1 shl k}")
            r.nw = maxOf(1, w shr k); r.nh = maxOf(1, hh shr k); r.nfmt = "ETC2"
            if (dir != null) r.thumbB = Thumbs.before(dir, key(), texName, tf, w, hh, mips, d, pos, csz)
            return true
        }

        var nb: ByteArray
        var nm: Int
        var newTf = tf
        var thB: Bitmap? = null
        var thA: Bitmap? = null
        var fxDone = false
        // colour filter: only map colour textures that are compressed and can be decoded on this phone
        val fxUse: ColorFx? = if (plan.fx != null && !plan.dry && ch == 0 && Reencode.canConvert(tf) && fxWanted(cat, texName.lowercase())) plan.fx else null
        if (mips > 1) {
            var skip = 0
            for (i in 0 until k) skip += lvlSize(tf, w, hh, i)
            nb = d.copyOfRange(pos + skip, pos + csz); nm = mips - k
            if (fxUse != null) {
                val lv = d.copyOfRange(pos + skip, pos + skip + lvlSize(tf, w, hh, k))
                val fo = try { Reencode.recolour(tf, maxOf(1, w shr k), maxOf(1, hh shr k), lv, fxUse, csz) } catch (t: Throwable) { null }
                if (fo != null) { nb = fo.data; nm = fo.mips; newTf = fo.tf; fxDone = true }
            }
        } else if (ch > 0) {
            nb = boxDown(d.copyOfRange(pos, pos + csz), w, hh, ch, k); nm = 1
        } else {
            // compressed, no mips: decode on the GPU, shrink, write ETC2, check it on the GPU again
            val r = Reencode.convert(tf, w, hh, d.copyOfRange(pos, pos + csz), k, csz, MIN_SIDE, fxUse)
            val rd = r.data
            if (rd == null) {
                ty.convFail++
                val rc = newRec(w, hh, fname, 2, r.why)
                if (dir != null) rc.thumbB = Thumbs.save(dir, key() + "b", r.thumb)
                return false
            }
            nb = rd; nm = 1; k = r.k; newTf = r.tf
            fxDone = fxUse != null
            thB = r.thumb; thA = r.after
            ty.converted++
        }
        val nw = maxOf(1, w shr k); val nh = maxOf(1, hh shr k)
        val rc = newRec(w, hh, fname, 0, "")
        rc.nw = nw; rc.nh = nh; rc.nfmt = Preview.fmtName(newTf)
        rc.reason = if (mips > 1) "top $k mip level(s) removed" else if (ch > 0) "resized to 1/${1 shl k}" else "re-encoded as ${rc.nfmt}, 1/${1 shl k}"
        if (fxDone) rc.reason += " + colour filter"
        ty.reduced++

        // pictures first (they need the ORIGINAL bytes, the data is changed below)
        if (dir != null) {
            val id = key()
            if (mips > 1) {
                val chain = d.copyOfRange(pos, pos + csz)
                var kb = 0
                while (kb < mips - 1 && (maxOf(w, hh) shr kb) > 128) kb++
                rc.thumbB = Thumbs.level(dir, id + "b", texName, tf, w, hh, mips, chain, kb)
                rc.thumbA = if (k <= kb) rc.thumbB else Thumbs.level(dir, id + "a", texName, tf, w, hh, mips, chain, k)
            } else if (ch > 0) {
                rc.thumbB = Thumbs.level(dir, id + "b", texName, tf, w, hh, 1, d.copyOfRange(pos, pos + csz), 0)
                rc.thumbA = Thumbs.level(dir, id + "a", texName, tf, nw, nh, 1, nb, 0)
            } else {
                rc.thumbB = Thumbs.save(dir, id + "b", thB)
                rc.thumbA = Thumbs.save(dir, id + "a", thA)
            }
        }
        if (plan.dry) return true

        if (dl > 0) {                                   // texture is inside the bundle
            val tail = d.copyOfRange(lay.after, o + sz)
            e.putInt(lay.dlP, nb.size)
            System.arraycopy(nb, 0, d, lay.dataStart, nb.size)
            val q = lay.dataStart + nb.size; val qa = al(q)
            Arrays.fill(d, q, qa, 0)
            System.arraycopy(tail, 0, d, qa, tail.size)
            Arrays.fill(d, qa + tail.size, o + sz, 0)
        } else {                                        // texture is in a .resS file
            System.arraycopy(nb, 0, d, pos, nb.size)
            Arrays.fill(d, pos + nb.size, pos + csz, 0)
            e.putInt(lay.sSizeP, nb.size)
        }
        e.putInt(lay.wP, nw); e.putInt(lay.wP + 4, nh)
        e.putInt(lay.wP + 8, nb.size); e.putInt(lay.tfP, newTf); e.putInt(lay.mipP, nm)
        return true
    }

    // ---------------------------------------------------------------- Gloo Vault

    class GlooOut(val data: ByteArray?, val why: String)

    /**
     * Puts a new picture (already ETC2, see Reencode.encodeChain) into the texture [target] of a bundle. The picture is appended to the .resS part
     * (which must be the last part of the bundle), the old picture is zeroed. The textures in [flat] (ASTC) become one flat colour block each
     * (normal map = flat, specular = dark grey), which frees their space. The bundle is packed again with LZ4HC level 12 and padded with zeros to the
     * ORIGINAL file size. When it does not fit, nothing is returned (why says by how much).
     */
    fun glooPatch(file: ByteArray, target: String, ch: Reencode.Chain, nw: Int, nh: Int, flat: List<String>): GlooOut {
        val op: Opened = try {
            open(file) ?: return GlooOut(null, "not a Unity bundle")
        } catch (t: BundleProblem) {
            return GlooOut(null, t.message ?: "unreadable bundle")
        }
        val nodes = op.nodes
        val sfNode = nodes.firstOrNull { (it.flags and 4) != 0 } ?: return GlooOut(null, "no serialized file inside")
        val last = nodes.last()
        if ((last.flags and 4) != 0 || !last.name.endsWith(".resS") || last.off + last.size != op.data.size.toLong())
            return GlooOut(null, "unexpected bundle layout (the .resS part is not the last part)")
        val old = op.data
        val base = sfNode.off.toInt()
        val sf = parseSf(old, base) ?: return GlooOut(null, "serialized file version not supported")
        val data = old.copyOf(old.size + ch.data.size)
        val e = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        var found = false
        for (ob in sf.objs) {
            if (sf.cids[ob[2]] != 28) continue
            val o = base + sf.dataOff + ob[0]
            val nm = texName(old, o)
            val isT = nm == target
            val isF = !isT && flat.contains(nm)
            if (!isT && !isF) continue
            val t = readTex(old, o, ob[1], nodes, sf.version, sf.uvn)
            val lay = t.lay
            if (lay == null || t.err.isNotEmpty()) return GlooOut(null, "texture $nm cannot be read (${t.err})")
            if (t.dl != 0) return GlooOut(null, "texture $nm is stored inside the file, not in .resS")
            if (isT) {
                Arrays.fill(data, t.pos, t.pos + t.csz, 0)
                System.arraycopy(ch.data, 0, data, old.size, ch.data.size)
                val offInRes = last.size
                if (sf.version >= 22) e.putLong(lay.sOffP, offInRes) else e.putInt(lay.sOffP, offInRes.toInt())
                e.putInt(lay.sSizeP, ch.data.size)
                e.putInt(lay.wP, nw); e.putInt(lay.wP + 4, nh); e.putInt(lay.wP + 8, ch.data.size)
                e.putInt(lay.tfP, ch.tf); e.putInt(lay.mipP, ch.mips)
                found = true
            } else {
                val f = fmt(t.tf)
                if (f == null || t.tf < 48 || t.tf > 59) continue      // only ASTC textures are turned into a flat colour
                Arrays.fill(data, t.pos, t.pos + t.csz, 0)
                val normal = nm.endsWith("_N")
                val blk = ByteArray(16)                                // ASTC "void extent" block = one colour for the whole block
                blk[0] = 0xFC.toByte(); blk[1] = 0xFD.toByte()
                for (k in 2..7) blk[k] = 0xFF.toByte()
                val r = if (normal) 0x8000 else 0x4000
                val b = if (normal) 0xFFFF else 0x4000
                blk[8] = r.toByte(); blk[9] = (r shr 8).toByte(); blk[10] = r.toByte(); blk[11] = (r shr 8).toByte()
                blk[12] = b.toByte(); blk[13] = (b shr 8).toByte(); blk[14] = 0xFF.toByte(); blk[15] = 0xFF.toByte()
                System.arraycopy(blk, 0, data, t.pos, 16)
                e.putInt(lay.wP, f[0]); e.putInt(lay.wP + 4, f[1]); e.putInt(lay.wP + 8, 16)
                e.putInt(lay.mipP, 1); e.putInt(lay.sSizeP, 16)
            }
        }
        if (!found) return GlooOut(null, "texture $target was not found in this bundle")

        val newNodes = ArrayList<Node>()
        for (n in nodes) newNodes.add(if (n === last) Node(n.off, n.size + ch.data.size, n.flags, n.name) else n)
        val comp = ByteArrayOutputStream(); val nb = ArrayList<Triple<Int, Int, Int>>()
        val hc = lz4.highCompressor(12)
        var i = 0
        while (i < data.size) {
            val n = minOf(131072, data.size - i)
            val buf = ByteArray(hc.maxCompressedLength(n))
            val c = hc.compress(data, i, n, buf, 0, buf.size)
            if (c >= n) { comp.write(data, i, n); nb.add(Triple(n, n, 0)) } else { comp.write(buf, 0, c); nb.add(Triple(n, c, 3)) }
            i += n
        }
        val bi = ByteArrayOutputStream(); val d = DataOutputStream(bi)
        d.write(ByteArray(16)); d.writeInt(nb.size)
        for ((u, c, f) in nb) { d.writeInt(u); d.writeInt(c); d.writeShort(f) }
        d.writeInt(newNodes.size)
        for (n in newNodes) { d.writeLong(n.off); d.writeLong(n.size); d.writeInt(n.flags); d.write(n.name.toByteArray()); d.write(0) }
        val iu = bi.toByteArray()
        val ic = ByteArray(hc.maxCompressedLength(iu.size))
        val icl = hc.compress(iu, 0, iu.size, ic, 0, ic.size)
        val ver = op.ver
        val headLen = 8 + 4 + op.uv.length + 1 + op.rev.length + 1 + 8 + 12
        val big = ver >= 7
        val pad1 = if (big) ((headLen + 15) and -16) - headLen else 0
        val endInfo = headLen + pad1 + icl
        val pad2 = if (big) ((endInfo + 15) and -16) - endInfo else 0
        val total = endInfo + pad2 + comp.size()
        if (total > file.size) return GlooOut(null, "bigger than the original by ${total - file.size} bytes")
        val out = ByteArrayOutputStream(file.size); val h = DataOutputStream(out)
        h.write("UnityFS".toByteArray()); h.write(0); h.writeInt(ver)
        h.write(op.uv.toByteArray()); h.write(0); h.write(op.rev.toByteArray()); h.write(0)
        h.writeLong(total.toLong()); h.writeInt(icl); h.writeInt(iu.size); h.writeInt(if (big) 0x243 else 0x43)
        if (pad1 > 0) h.write(ByteArray(pad1))
        h.write(ic, 0, icl)
        if (pad2 > 0) h.write(ByteArray(pad2))
        comp.writeTo(h)
        if (total < file.size) h.write(ByteArray(file.size - total))
        return GlooOut(out.toByteArray(), "${file.size - total} bytes to spare")
    }

    // ---------------------------------------------------------------- plain Unity data files (level*, sharedassets*, hash-named files inside an APK)

    /** First 16 bytes of a plain serialized file (version 17-19 with the file size at byte 4, or version 22). */
    fun looksLikeSf(head: ByteArray, size: Long): Boolean {
        if (head.size < 16) return false
        fun be(o: Int): Long = ((head[o].toLong() and 255L) shl 24) or ((head[o + 1].toLong() and 255L) shl 16) or ((head[o + 2].toLong() and 255L) shl 8) or (head[o + 3].toLong() and 255L)
        val v = be(8)
        if (v in 17L..19L) return be(4) == size
        return v == 22L && be(0) == 0L && be(4) == 0L
    }

    /** The serialized file and its .resS files in ONE array, so the bundle code (which finds .resS by name) can be used unchanged. */
    fun plainData(sf: ByteArray, extras: List<Pair<String, ByteArray>>): Pair<ByteArray, List<Node>> {
        var total = sf.size.toLong()
        for (e in extras) total += e.second.size
        val data = ByteArray(total.toInt())
        System.arraycopy(sf, 0, data, 0, sf.size)
        val nodes = ArrayList<Node>()
        nodes.add(Node(0L, sf.size.toLong(), 4, "sf"))
        var p = sf.size
        for ((n, b) in extras) {
            System.arraycopy(b, 0, data, p, b.size)
            nodes.add(Node(p.toLong(), b.size.toLong(), 0, n))
            p += b.size
        }
        return data to nodes
    }

    /** Same as process() for a bundle, but for plain data made by plainData(). Changes `data` in place, returns the number of textures changed. */
    fun processPlain(data: ByteArray, nodes: List<Node>, plan: Plan, ty: Tally, hint: String): Int {
        val br = BRec(ty.cur, data.size.toLong())
        ty.bundleRecs.add(br)
        ty.ti = 0
        ty.bundles++
        br.info = "plain Unity data file"
        val n = shrinkSf(data, 0, nodes, plan, ty, br, hint)
        br.tex = ty.ti
        br.changed = n
        return n
    }

    /** Every texture of plain data (in file order), like inventory() does for a bundle. null = cannot be read. */
    fun inventoryData(data: ByteArray, nodes: List<Node>): List<Inv>? {
        val out = ArrayList<Inv>()
        try {
            val sf = parseSf(data, 0) ?: return null
            for (ob in sf.objs) {
                if (sf.cids[ob[2]] != 28) continue
                val t = readTex(data, sf.dataOff + ob[0], ob[1], nodes, sf.version, sf.uvn)
                out.add(Inv(t.name, t.w, t.h, t.tf, t.mips, t.err.isEmpty()))
            }
        } catch (t: Throwable) {
            return null
        }
        return out
    }

    // ---------------------------------------------------------------- check of a written bundle

    /** Every texture of a bundle (in file order). null = the bundle cannot be opened at all. */
    fun inventory(file: ByteArray): List<Inv>? {
        val out = ArrayList<Inv>()
        try {
            val op = open(file) ?: return null
            for (n in op.nodes) if ((n.flags and 4) != 0) {
                val base = n.off.toInt()
                val sf = parseSf(op.data, base) ?: continue
                for (ob in sf.objs) {
                    if (sf.cids[ob[2]] != 28) continue
                    val t = readTex(op.data, base + sf.dataOff + ob[0], ob[1], op.nodes, sf.version, sf.uvn)
                    out.add(Inv(t.name, t.w, t.h, t.tf, t.mips, t.err.isEmpty()))
                }
            }
        } catch (t: Throwable) {
            return null
        }
        return out
    }

    // ---------------------------------------------------------------- real texture samples (for the preview)

    class Sample(val name: String, val w: Int, val h: Int, val tf: Int, val mips: Int, val chain: ByteArray)

    /** The mip level the engine would really keep for this sample at the given level (same rule as shrinkTex). */
    fun effKOf(s: Sample, drop: Int): Int {
        var k = minOf(drop, s.mips - 1)
        while (k > 0 && (maxOf(s.w, s.h) shr k) < MIN_SIDE) k--
        return k
    }

    fun samples(file: ByteArray, max: Int): List<Sample> {
        val out = ArrayList<Sample>()
        try {
            val op = open(file) ?: return out
            for (n in op.nodes) if ((n.flags and 4) != 0) {
                val base = n.off.toInt()
                val sf = parseSf(op.data, base) ?: continue
                for (ob in sf.objs) {
                    if (sf.cids[ob[2]] != 28) continue
                    val t = readTex(op.data, base + sf.dataOff + ob[0], ob[1], op.nodes, sf.version, sf.uvn)
                    if (t.err.isNotEmpty() || t.mips < 4 || minOf(t.w, t.h) < 64 || t.w > 4096 || t.h > 4096) continue
                    out.add(Sample(t.name, t.w, t.h, t.tf, t.mips, op.data.copyOfRange(t.pos, t.pos + t.csz)))
                }
            }
        } catch (t: Throwable) { }
        return out.sortedByDescending { it.w * it.h }.take(max)
    }
}
