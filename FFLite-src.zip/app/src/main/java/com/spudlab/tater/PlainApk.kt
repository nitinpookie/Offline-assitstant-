package com.spudlab.tater

import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.io.RandomAccessFile
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipFile

/** A file of the APK that gets new content. method 0 = stored (same size, in place), 8 = deflate. The new bytes are in the spool file. */
class NewEntry(val method: Int, val crc: Long, val usize: Long, val csize: Long, val spoolOff: Long)

private fun plainCrc(b: ByteArray): Long { val c = CRC32(); c.update(b, 0, b.size); return c.value }

private fun plainDeflate(b: ByteArray): ByteArray {
    val d = Deflater(9, true)
    d.setInput(b); d.finish()
    val out = ByteArrayOutputStream(b.size / 4 + 64)
    val buf = ByteArray(65536)
    while (!d.finished()) { val k = d.deflate(buf); out.write(buf, 0, k) }
    d.end()
    return out.toByteArray()
}

/** The new bundle / file is opened again: every texture must read back with the planned size. */
private fun verifyPlain(ty: Tally, startRec: Int, data: ByteArray, nodes: List<Node>): Boolean {
    val inv = UnityFs.inventoryData(data, nodes) ?: return false
    for (i in startRec until ty.recs.size) {
        val r = ty.recs[i]
        if (r.status == 3) continue
        val x = inv.getOrNull(r.idx)
        val wantW = if (r.status == 0) r.nw else r.w
        val wantH = if (r.status == 0) r.nh else r.h
        if (x == null || !x.ok || x.w != wantW || x.h != wantH) return false
    }
    return true
}

/**
 * Plain Unity data files inside an APK (level*, sharedassets*.assets, hash-named serialized files, with their .resS files)
 * and Unity bundles that are COMPRESSED inside the APK. They are read, the textures are changed in place (same size, rest zero),
 * compressed again, and the APK is written again by ApkRewrite (everything else is copied byte for byte).
 * Returns [seen, written, failedCheck, rewritten (0/1)]. plan.dry: only reads and reports.
 */
fun plainPass(apk: File, ents: List<ZEnt>, plan: Plan, ty: Tally, work: File, limit: Long, say: (String) -> Unit, extra: MutableList<String>): IntArray {
    val res = IntArray(4)
    val byName = HashMap<String, ZEnt>()
    for (e in ents) byName[e.name] = e
    val cands = ents.filter {
        !it.name.endsWith("/") && it.usize >= 1024 && (it.method == 0 || it.method == 8) &&
            extOf(it.name) !in SKIP_EXT && extOf(it.name) != "ress" && extOf(it.name) != "resource"
    }
    if (cands.isEmpty()) return res
    val zf = ZipFile(apk)
    val spool = File(work, apk.name + ".spool")
    var spoolOut: OutputStream? = null
    try {
        val sfs = ArrayList<ZEnt>()
        val ubs = ArrayList<ZEnt>()
        val head = ByteArray(16)
        say("Looking for Unity data files in ${apk.name} (${cands.size} candidates) ...")
        for (e in cands) {
            val ze = zf.getEntry(e.name) ?: continue
            val n = try {
                zf.getInputStream(ze).use { s -> var r = 0; while (r < 16) { val k = s.read(head, r, 16 - r); if (k < 0) break; r += k }; r }
            } catch (t: Throwable) { 0 }
            if (n < 16) continue
            if (String(head, 0, 7, Charsets.ISO_8859_1) == "UnityFS") { if (e.method == 8) ubs.add(e) }
            else if (UnityFs.looksLikeSf(head, e.usize)) sfs.add(e)
        }
        extra.add("  plain Unity data files (serialized files): ${sfs.size}, compressed Unity bundles: ${ubs.size}")
        if (sfs.isEmpty() && ubs.isEmpty()) return res

        val changes = HashMap<String, NewEntry>()
        var spoolPos = 0L
        val used = HashSet<String>()

        fun put(name: String, orig: ZEnt, bytes: ByteArray) {
            val o = spoolOut ?: BufferedOutputStream(FileOutputStream(spool)).also { spoolOut = it }
            val cdata = if (orig.method == 0) bytes else plainDeflate(bytes)
            o.write(cdata)
            changes[name] = NewEntry(orig.method, plainCrc(bytes), bytes.size.toLong(), cdata.size.toLong(), spoolPos)
            spoolPos += cdata.size
        }
        fun read(z: ZEnt): ByteArray = zf.getInputStream(zf.getEntry(z.name)).use { it.readBytes() }

        // ---- plain serialized files (with their .resS)
        for (e in sfs) {
            res[0]++
            val sn = e.name.substringAfterLast('/')
            ty.cur = sn
            val dir = e.name.substringBeforeLast('/', "")
            val pre = if (dir.isEmpty()) "" else "$dir/"
            val stem = sn.removeSuffix(".assets")
            val comp = listOf("$sn.resS", "$stem.resS").distinct().mapNotNull { byName[pre + it] }.filter { (it.method == 0 || it.method == 8) && it.usize > 0 }
            val total = e.usize + comp.sumOf { it.usize }
            if (total > limit / 2) {
                ty.tooBig++
                val b = BRec(sn, e.usize); b.note = "too big for the free memory of this phone (${Fs.human(total)})"
                ty.bundleRecs.add(b)
                say("Too big for the available memory: ${e.name}")
                continue
            }
            if (comp.any { it.name in used }) {
                val b = BRec(sn, e.usize); b.note = "shares a .resS file with an earlier file, left as it is"
                ty.bundleRecs.add(b)
                continue
            }
            if (res[0] % 50 == 1) say("[data ${res[0]}/${sfs.size}] ${e.name}")
            val sf = try { read(e) } catch (t: Throwable) {
                ty.readFail++
                val b = BRec(sn, e.usize); b.note = "could not be read"; ty.bundleRecs.add(b)
                continue
            }
            val extras = ArrayList<Pair<String, ByteArray>>()
            var ok = true
            for (c in comp) { try { extras.add(c.name.substringAfterLast('/') to read(c)) } catch (t: Throwable) { ok = false } }
            if (!ok) {
                ty.readFail++
                val b = BRec(sn, e.usize); b.note = "its .resS file could not be read"; ty.bundleRecs.add(b)
                continue
            }
            val pd = UnityFs.plainData(sf, extras)
            val data = pd.first; val nodes = pd.second
            val startRec = ty.recs.size; val startB = ty.bundleRecs.size
            val n = try {
                UnityFs.processPlain(data, nodes, plan, ty, apk.name + "/" + e.name)
            } catch (t: Throwable) {
                ty.bad++; failRecs(ty, startRec, startB, "failed (${t.message})"); 0
            }
            if (n == 0 || plan.dry) continue
            if (!verifyPlain(ty, startRec, data, nodes)) {
                res[2]++
                failRecs(ty, startRec, startB, "the check after changing failed, this file was NOT changed")
                say("  check failed, not changed: ${e.name}")
                continue
            }
            try {
                put(e.name, e, data.copyOfRange(0, sf.size))
                for ((i, c) in comp.withIndex()) {
                    val nd = nodes[i + 1]
                    val part = data.copyOfRange(nd.off.toInt(), (nd.off + nd.size).toInt())
                    if (!part.contentEquals(extras[i].second)) put(c.name, c, part)
                    used.add(c.name)
                }
                res[1]++
                if (startB < ty.bundleRecs.size) ty.bundleRecs[startB].saved = true
            } catch (t: Throwable) {
                failRecs(ty, startRec, startB, "could not be stored (${t.message})")
                say("Could not store: ${e.name}")
            }
        }

        // ---- Unity bundles that are compressed inside the APK
        for (e in ubs) {
            res[0]++
            val sn = e.name.substringAfterLast('/')
            ty.cur = sn
            if (e.usize > limit) {
                ty.tooBig++
                val b = BRec(sn, e.usize); b.note = "too big for the free memory of this phone (${Fs.human(e.usize)})"
                ty.bundleRecs.add(b)
                continue
            }
            say("[bundle] ${e.name}")
            val bytes = try { read(e) } catch (t: Throwable) {
                ty.readFail++
                val b = BRec(sn, e.usize); b.note = "could not be read"; ty.bundleRecs.add(b)
                continue
            }
            val startRec = ty.recs.size; val startB = ty.bundleRecs.size
            val r = try {
                UnityFs.process(bytes, plan, ty, apk.name + "/" + e.name) { say(it) }
            } catch (t: Throwable) {
                ty.bad++; failRecs(ty, startRec, startB, "failed (${t.message})"); bytes to 0
            }
            if (r.second == 0 || plan.dry) continue
            if (!verifyBundle(ty, startRec, r.first) || r.first.size.toLong() != e.usize) {
                res[2]++
                failRecs(ty, startRec, startB, "the check after changing failed, this bundle was NOT changed")
                say("  check failed, not changed: ${e.name}")
                continue
            }
            try {
                put(e.name, e, r.first)
                res[1]++
                if (startB < ty.bundleRecs.size) ty.bundleRecs[startB].saved = true
            } catch (t: Throwable) {
                failRecs(ty, startRec, startB, "could not be stored (${t.message})")
            }
        }
        try { spoolOut?.close() } catch (t: Throwable) { }
        spoolOut = null

        // ---- write the APK again
        if (!plan.dry && changes.isNotEmpty()) {
            val inp = File(work, apk.name).let { if (it.exists()) it else apk }
            val outF = File(work, apk.name + ".rw")
            say("Writing ${apk.name} again (${changes.size} changed files) ...")
            try {
                ApkRewrite.rewrite(inp, outF, changes, spool)
                val bad = checkRewritten(outF, ents.size, changes)
                if (bad != null) {
                    outF.delete()
                    extra.add("${apk.name}: the new APK did not pass the check ($bad). Nothing was changed in it.")
                    say("Check of the new ${apk.name} failed: $bad")
                    res[1] = 0; res[2]++
                } else {
                    if (inp != apk) inp.delete()
                    val dst = File(work, apk.name)
                    if (dst.exists()) dst.delete()
                    if (!outF.renameTo(dst)) throw IOException("rename failed")
                    res[3] = 1
                    extra.add("${apk.name}: ${changes.size} files changed inside the APK (data files / compressed bundles), rewritten and checked.")
                }
            } catch (t: Throwable) {
                outF.delete()
                extra.add("${apk.name}: writing the APK again failed (${t.message}). Nothing was changed in it.")
                say("Writing the APK failed: ${t.message}")
                res[1] = 0
            }
        }
    } finally {
        try { spoolOut?.close() } catch (t: Throwable) { }
        try { zf.close() } catch (t: Throwable) { }
        spool.delete()
    }
    return res
}

/** Opens the new APK like Android does: same number of files, every changed file (and about 1 in 97 of the others) reads back with the right CRC. */
private fun checkRewritten(f: File, expectEntries: Int, changes: Map<String, NewEntry>): String? {
    ZipFile(f).use { z ->
        if (z.size() != expectEntries) return "${z.size()} files instead of $expectEntries"
        var i = 0
        val en = z.entries()
        val buf = ByteArray(1 shl 16)
        while (en.hasMoreElements()) {
            val ze = en.nextElement(); i++
            val ch = changes[ze.name]
            if (ch == null && i % 97 != 0) continue
            val c = CRC32(); var n = 0L
            z.getInputStream(ze).use { s -> while (true) { val k = s.read(buf); if (k < 0) break; c.update(buf, 0, k); n += k } }
            val want = ch?.crc ?: ze.crc
            if (c.value != want || (ch != null && n != ch.usize)) return "${ze.name} does not read back correctly"
        }
    }
    return null
}

/**
 * Writes an APK again with new content for some files. Every other file is copied byte for byte. A changed (deflated) file gets a new
 * local header, and the length difference is rounded to a multiple of 16 KB with padding inside its "extra" field, so every later file moves by a
 * multiple of 16 KB and keeps its alignment (resources.arsc, native libraries). The old APK signing block is dropped (the APK is signed again afterwards).
 */
object ApkRewrite {
    private const val G = 16384L
    private fun u16(b: ByteArray, o: Int): Int = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
    private fun u32(b: ByteArray, o: Int): Long = u16(b, o).toLong() or (u16(b, o + 2).toLong() shl 16)
    private fun w16(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte() }
    private fun w32(b: ByteArray, o: Int, v: Long) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte(); b[o + 2] = (v shr 16).toByte(); b[o + 3] = (v shr 24).toByte() }

    private class R(val name: String, val cdPos: Int, val lhOff: Long, val flags: Int) { var newOff = 0L }

    fun rewrite(input: File, output: File, changes: Map<String, NewEntry>, spool: File) {
        RandomAccessFile(input, "r").use { rin ->
            RandomAccessFile(spool, "r").use { rsp ->
                RandomAccessFile(output, "rw").use { out ->
                    out.setLength(0)
                    val len = rin.length()
                    val tailLen = minOf(len, 65557L).toInt()
                    val tail = ByteArray(tailLen)
                    rin.seek(len - tailLen); rin.readFully(tail)
                    var p = tailLen - 22
                    while (p >= 0 && u32(tail, p) != 0x06054b50L) p--
                    if (p < 0) throw IOException("not a zip / APK file")
                    val total = u16(tail, p + 10); val cdSize = u32(tail, p + 12); val cdOff = u32(tail, p + 16)
                    if (total == 0xFFFF || cdOff == 0xFFFFFFFFL) throw IOException("zip64 is not supported")
                    val cd = ByteArray(cdSize.toInt())
                    rin.seek(cdOff); rin.readFully(cd)
                    val recs = ArrayList<R>()
                    var q = 0
                    for (i in 0 until total) {
                        if (u32(cd, q) != 0x02014b50L) throw IOException("bad central directory")
                        val nl = u16(cd, q + 28); val el = u16(cd, q + 30); val cl = u16(cd, q + 32)
                        recs.add(R(String(cd, q + 46, nl, Charsets.UTF_8), q, u32(cd, q + 42), u16(cd, q + 8)))
                        q += 46 + nl + el + cl
                    }
                    var lfhEnd = cdOff
                    if (cdOff >= 32) {
                        val mg = ByteArray(16); rin.seek(cdOff - 16); rin.readFully(mg)
                        if (String(mg, Charsets.ISO_8859_1) == "APK Sig Block 42") {
                            val sz = ByteArray(8); rin.seek(cdOff - 24); rin.readFully(sz)
                            lfhEnd = cdOff - 8 - (u32(sz, 0) or (u32(sz, 4) shl 32))
                        }
                    }
                    val order = recs.sortedBy { it.lhOff }
                    val buf = ByteArray(1 shl 20)
                    fun copy(src: RandomAccessFile, from: Long, n: Long) {
                        src.seek(from)
                        var left = n
                        while (left > 0) {
                            val k = src.read(buf, 0, minOf(left, buf.size.toLong()).toInt())
                            if (k < 0) throw EOFException()
                            out.write(buf, 0, k); left -= k
                        }
                    }
                    var shift = 0L
                    for ((i, r) in order.withIndex()) {
                        val oldEnd = if (i + 1 < order.size) order[i + 1].lhOff else lfhEnd
                        val oldLen = oldEnd - r.lhOff
                        r.newOff = r.lhOff + shift
                        val ch = changes[r.name]
                        if (ch == null) { copy(rin, r.lhOff, oldLen); continue }
                        val lh = ByteArray(30)
                        rin.seek(r.lhOff); rin.readFully(lh)
                        val nl = u16(lh, 26); val el = u16(lh, 28)
                        val nameExtra = ByteArray(nl + el)
                        rin.readFully(nameExtra)
                        if (ch.method == 0) {                      // stored: same size, same place
                            if (ch.csize != ch.usize) throw IOException("stored size mismatch: ${r.name}")
                            val base = out.filePointer
                            copy(rin, r.lhOff, oldLen)
                            val dataRel = 30L + nl + el
                            out.seek(base + dataRel)
                            copy(rsp, ch.spoolOff, ch.csize)
                            if ((r.flags and 8) == 0) {
                                val b = ByteArray(4); w32(b, 0, ch.crc); out.seek(base + 14); out.write(b)
                            } else {
                                val pos = base + dataRel + ch.csize
                                val d = ByteArray(4); out.seek(pos); out.readFully(d)
                                val b = ByteArray(4); w32(b, 0, ch.crc)
                                out.seek(pos + (if (u32(d, 0) == 0x08074b50L) 4 else 0)); out.write(b)
                            }
                            out.seek(base + oldLen)
                            continue
                        }
                        val needed = 30L + nl + el + ch.csize
                        val delta = oldLen - needed
                        var newLen = if (delta >= 0) oldLen - (delta / G) * G else oldLen + ((-delta + G - 1) / G) * G
                        var pad = newLen - needed
                        if (pad in 1L..3L) { newLen += G; pad += G }
                        val nlh = lh.copyOf()
                        w16(nlh, 6, u16(lh, 6) and 8.inv())
                        w16(nlh, 8, 8)
                        w32(nlh, 14, ch.crc); w32(nlh, 18, ch.csize); w32(nlh, 22, ch.usize)
                        w16(nlh, 28, el + pad.toInt())
                        out.write(nlh); out.write(nameExtra)
                        if (pad > 0) {
                            val pb = ByteArray(pad.toInt())
                            w16(pb, 0, 0xD935); w16(pb, 2, pad.toInt() - 4)
                            out.write(pb)
                        }
                        copy(rsp, ch.spoolOff, ch.csize)
                        shift += newLen - oldLen
                    }
                    val cdStart = out.filePointer
                    val ncd = cd.copyOf()
                    for (r in recs) {
                        w32(ncd, r.cdPos + 42, r.newOff)
                        val ch = changes[r.name] ?: continue
                        if (ch.method == 8) { w16(ncd, r.cdPos + 8, u16(cd, r.cdPos + 8) and 8.inv()); w16(ncd, r.cdPos + 10, 8) }
                        w32(ncd, r.cdPos + 16, ch.crc); w32(ncd, r.cdPos + 20, ch.csize); w32(ncd, r.cdPos + 24, ch.usize)
                    }
                    out.write(ncd)
                    val eocd = tail.copyOfRange(p, p + 22)
                    w16(eocd, 20, 0)
                    w32(eocd, 16, cdStart)
                    out.write(eocd)
                }
            }
        }
    }
}
