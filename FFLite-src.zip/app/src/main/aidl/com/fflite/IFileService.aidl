package com.fflite;

import android.os.ParcelFileDescriptor;

interface IFileService {
    void destroy() = 16777114;
    boolean isDir(String path) = 1;
    String[] list(String dir, int offset, int limit) = 2;
    ParcelFileDescriptor open(String path) = 3;
    ParcelFileDescriptor openWrite(String path) = 4;
    boolean commit(String tmp, String dest, long size) = 5;
    long crc32(String path) = 6;
    void delete(String path) = 7;
    void forceStop(String pkg) = 8;
}
