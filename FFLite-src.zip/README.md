# Tater Manager (v3.1.0) - separate app, package com.spudlab.tater

Build: same as before. Upload this zip to the repo root (name stays FFLite-src.zip), the existing workflow unzips and builds.
Untested build (no compiler here). If GitHub shows an error, send the error line.
New file: Classify.kt, Thumbs.kt. Changed: UnityFs.kt, Potato.kt, Reencode.kt (tiny), Preview.kt (format names), MainActivity.kt (Potato window + report).

## What was wrong before (found in a real 283 MB contentcache)
- 18 of 48 bundles use the newer bundle header (v8, 16-byte padding, flag 0x200) and a newer serialized file (v22, Unity 2022 style).
  The old reader skipped them without saying so. These are clothes, emotes, avatars, pets, training ground, hippo effects. Now supported.
- The two big "map" bundles (Unity 5.6.3, 76 MB and 31 MB) were read with the wrong field layout. Read correctly they only hold
  5x5 placeholder pictures (all 757 textures): the real map textures are NOT in those files. They are listed as "placeholder".
- 1963 of 3601 textures have no mip levels (ASTC without mips: characters, clothes). Dropping mips does nothing for them, they must be re-encoded.
  That path exists (GPU decode, shrink, ETC2, check) and now also works for the new bundles.

## Potato window
- Scan only: reads everything, writes NOTHING, and shows what would change and what would not.
- Categories are found automatically (Character, Weapon, Lobby, UI, Pet, Effects, Lightmap, Map, Other) from texture names and asset paths.
  Each has Keep / Light (at most 1/2) / Potato (slider level). Defaults: characters, weapons, UI = Keep, lobby = Light, the rest = Potato.
- Full potato bundles (words): everything inside bundles whose path contains these words gets the level, whatever the categories say.
  Default "training, tutorial" = training ground completely potato.
- Colour lookup / ramp textures (names with lut, ramp, gradation, lookup) are never shrunk (it would break the colours).
- Every written bundle is opened again and every texture is checked BEFORE it is saved. A bundle that fails is not saved.
- Report screen: tabs Changed / Kept / Not changeable / Bundles. Every texture has a picture (before and after), size, format, category and reason.
  Filter by category, search by name. Also written to "Tater Manager/Potato Reports/<package>/Potato Report.txt and .csv".
- Apply to game: copies the new files into the game folder and first backs up the original of each file (Tater Manager/Backup). Restore originals puts them back.
- .trashed- files and partly downloaded bundles are skipped and named in the report.

## Limits (honest)
- Only what is inside the files you select can change. Textures that live in OBB / APK / other files are not touched.
- Crunch-compressed, PVRTC, BC7 and similar formats cannot be decoded here: listed, unchanged.
- Textures bigger than 2048x2048 without mips cannot be decoded on the GPU in one go: listed, unchanged.
- Android/data access: open the folder, "Allow access" > "Use this folder" > "Allow" (or Shizuku), as before.
