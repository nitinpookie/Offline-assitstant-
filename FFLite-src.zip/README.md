# FF Lite (Android app)

## Build (GitHub Actions)
Same as the other projects: upload this zip to the repo root, the existing workflow unzips it and builds.
The project module is called `app` (Groovy Gradle, AGP 8.2.2, same as LiveEditor). There is no workflow file
inside this zip on purpose: the one already in your repo is used. APK: app-debug.apk / app-release.apk
(release is signed with the debug key, so it installs too).

## Use (v1.2)
1. Open the app, pick the game from the Games / Apps list.
2. Shizuku: start it, press "Permission do" once (Android 10 or lower can work without it).
3. Pick the level, tick what you want: "Seedha game mein apply" and / or "Zip bhi banao", press "Shuru karo".
4. Progress bar shows phase, x / total, current file, counters and time. Toast + vibration when done.

## What it does
- Direct apply: stops the game, backs up each original (app's own folder), writes the new file to a temp name,
  renames it atomically, checks CRC. If anything fails for a file the original of that file is put back.
- Backup is kept, so changing the level always starts from the ORIGINAL (no double shrink), and "Restore karo"
  puts the originals back (a file is skipped if the game replaced it meanwhile, e.g. an update).
- Zip is streamed straight to the place you choose (no second copy in cache). 4 GB zip limit is guarded.
- Big bundles are skipped when RAM is too small (heap / 5), reported in the summary.
- Manual Zip / Folder source still works (zip only, no direct apply).
- Untested build (no compiler here). If GitHub shows an error, send the error line.

## Character saaf, baaki potato (v1.3)
- Card "Character saaf, baaki sab potato": keywords (default guess) jo textures / asset paths se match karein, unhe level se chhota nahi kiya jata.
- Match texture ke naam (m_Name) aur bundle ke AssetBundle container paths par hota hai.
- Keywords sirf andaze hain. "Scan report banao" kuch badle bina FFLite_scan_report.txt likhta hai (bundle, asset paths, texture names,
  * = keyword match). Us file se keywords tune karo.
- Keywords badalne par files dobara process hoti hain (backup record mein level + keywords ka tag hai).

## v1.3.2
- Shizuku service connect fix: har baar purana bind hata ke naya bind (3 koshish), pehle Shizuku restart ke baad atak jata tha.
- RAM ke andaze se bundle skip karna band. Chhoti files pehle, badi aakhir mein. Sirf asli "RAM kam padi" aane par wahi ek file chhodi jati hai.
- Abhi bhi sirf Unity 2018 bundles process hote hain (Free Fire 2018 hai). Dusre version par log mein "skip (Unity ...)" aata hai.

## v1.4.0
- Naya card "Copy kiya hua folder": game ka `files` folder (Android/data/<game>/files) kahin copy karo, "1. Copy kiya hua folder chuno",
  "2. Ready folder kahan banana hai" chuno, Shuru karo. Output: <chuna folder>/FF_LITE_READY/files/... (sirf badli hui files). Us `files` ko
  wapas Android/data/<game>/ mein paste (Replace / Merge) karo. Original copy ko haath nahi lagta (double shrink nahi hota).
- Game chunav: FFI (com.garena.game.ffi) ya FF MAX (com.dts.freefiremax). Normal FF (com.dts.freefireth) ke liye alag option nahi.
- Level 5 "Extreme" (1/32) aur 6 "Koi Limit Nahi" (1/64). "Koi limit nahi" tick: 32 px ka neeche ka floor hat jata hai.
- Unity 2017 / 2018 / 2019 bundles (serialized v17-19) chalte hain. Har texture ka size-math check hota hai, mismatch wali texture chhod di jati hai.
  Scan report mein ab har bundle ka Unity version likha aata hai.
- Folder ka naam kuch bhi ho (files / contentcache / koi aur): andar `contentcache` nahi mila to poora folder contentcache maana jata hai.
