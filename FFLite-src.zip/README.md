# Tater Manager (v3.2.2) - separate app, package com.spudlab.tater

Build: same as before. Upload this zip to the repo root (name stays FFLite-src.zip), the existing workflow unzips and builds.
Untested build (no compiler here). If GitHub shows an error, send the error line.
New file: Classify.kt, Thumbs.kt. Changed: UnityFs.kt, Potato.kt, Reencode.kt (tiny), Preview.kt (format names), MainActivity.kt (Potato window + report).

## What was wrong before (found in a real 283 MB contentcache)
- 18 of 48 bundles use the newer bundle header (v8, 16-byte padding, flag 0x200) and a newer serialized file (v22, Unity 2022 style).
  The old reader skipped them without saying so. These are clothes, emotes, avatars, pets, training ground, hippo effects. Now supported.
- The two big "map" bundles (Unity 5.6.3, 76 MB and 31 MB) were read with the wrong field layout. Read correctly they only hold
  5x5 placeholder pictures (all 757 textures): the real map textures are NOT in those files. They are listed as "placeholder".
- 1963 of 3601 textures have no mip levels (ASTC without mips: characters, clothes). Dropping mips does nothing for them, they must be re-encoded.
  That path exists (GPU decode, shrink, ETC2, check) and now also works for the new bundles.

## Potato window
- Scan only: reads everything, writes NOTHING, and shows what would change and what would not.
- Categories are found automatically (Character, Weapon, Lobby, UI, Pet, Effects, Lightmap, Map, Other) from texture names and asset paths.
  Each has Keep / Light (at most 1/2) / Potato (slider level). Defaults: characters, weapons, UI = Keep, lobby = Light, the rest = Potato.
- Full potato bundles (words): everything inside bundles whose path contains these words gets the level, whatever the categories say.
  Default "training, tutorial" = training ground completely potato.
- Colour lookup / ramp textures (names with lut, ramp, gradation, lookup) are never shrunk (it would break the colours).
- Every written bundle is opened again and every texture is checked BEFORE it is saved. A bundle that fails is not saved.
- Report screen: tabs Changed / Kept / Not changeable / Bundles. Every texture has a picture (before and after), size, format, category and reason.
  Filter by category, search by name. Also written to "Tater Manager/Potato Reports/<package>/Potato Report.txt and .csv".
- Apply to game: copies the new files into the game folder and first backs up the original of each file (Tater Manager/Backup). Restore originals puts them back.
- .trashed- files and partly downloaded bundles are skipped and named in the report.

## Limits (honest)
- Only what is inside the files you select can change. Textures that live in OBB / APK / other files are not touched.
- Crunch-compressed, PVRTC, BC7 and similar formats cannot be decoded here: listed, unchanged.
- Textures bigger than 2048x2048 without mips cannot be decoded on the GPU in one go: listed, unchanged.
- Android/data access: open the folder, "Allow access" > "Use this folder" > "Allow" (or Shizuku), as before.

## v3.2.0: Game / APK tab (for Bermuda and everything else that is not in Android/data)
Why: Bermuda's textures are NOT in Android/data/<pkg>/files (only its language text is). Free Fire India has no OBB, so the map data is inside
the APK / split APKs of the installed game. The Files tab can never reach it.
- Bottom bar: Files (as before) | Game / APK.
- Game / APK: the list of installed apps (games first). Pick the game, press "Potato the APK". Or select .apk files in the Files tab and press "APK".
- Same Potato window (levels, categories, Scan only, report with pictures). Scan first: it also prints what is inside the APK
  (files, stored / compressed, biggest types, how many Unity bundles can be changed).
- Only Unity bundles that are STORED (not compressed) inside the APK are changed, in place, same size and position, CRC fixed. Nothing else in the APK moves.
- Every APK of the game (base + splits) is signed again with Tater's own key (APK signature v2, library apksig) and written to
  Tater Manager/Patched APK/<package>/.
- Install: "1. Uninstall original", then "2. Install patched" (Android's own installer window asks you to confirm).
  Android never updates an app with a different signature, so the original MUST be uninstalled first. Account data is online, Android/data of the game is deleted.
- New permissions: see all apps, install apps, uninstall apps. New files: ApkTools.kt, GameTab.kt, assets/tater_sign_*.der (the signing key).

Limits: bundles that are compressed inside the APK are listed but not changed (next step if the scan shows that). Plain Unity .assets / .resS files
inside the APK are counted but not handled yet. Games can refuse to run when their signature or files changed, and an account can be banned for it.
Use an extra account first. Untested on a real Free Fire India APK (no compiler / no APK here): send the Scan summary if something does not match.

v3.2.1: the APK scan summary now also lists the biggest folders and the 8 biggest files of every APK (size, stored / compressed, first 4 bytes),
so it is clear in one look where the game keeps its maps (Unity bundles, plain .assets, or something else).

v3.2.2: build fix. ApkTools.kt called ApkSigner.Builder.setAlignmentPreserved, which apksig 8.2.2 does not have ("Unresolved reference"). It is now called by name only if the library has it.

## v3.3.0: plain Unity data files inside the APK (this is where Free Fire India keeps Bermuda)
Found in a real Free Fire India 1.134.1 APK set (split_asset_pack_install_time.apk, 306 MB): about 39,000 plain Unity data files
(hash-named files, level*, sharedassets*), COMPRESSED inside the APK, about 5,900 textures (172 MB, mostly ASTC), half of them without mip levels.
There are no UnityFS bundles there, so 3.2.x found "0 textures".
- New: those files are read (also compressed bundles inside the APK), the textures are changed with the same engine as for bundles
  (categories, levels, re-encode of textures without mips, check before saving), and each file is compressed again.
- New: the APK is written again (ApkRewrite). Every other file is copied byte for byte. A changed file moves the later files by a multiple of 16 KB,
  so resources.arsc and native libraries stay aligned. The old signing block is dropped, then Tater signs all APK files as before.
- Safety: a changed file is read back and checked before it is accepted. The new APK is opened again and every changed file (plus a sample of the
  others) must read back with the right CRC, otherwise that APK is NOT used and the report says so.
- Scan only works for these files too (nothing is written): the report lists every texture of Bermuda with its category.
- The rewrite logic was run on a synthetic signed APK (deflated + stored + data descriptors + signing block): all files read back with the right CRC,
  stored files kept their alignment. The Kotlin code itself and the texture parsing of these data files have NOT run on the real APK (no compiler / no APK here).
- Defaults keep characters, weapons and UI untouched; map, terrain, trees, walls, vehicles and effects get the level.
- Still true: the original game must be uninstalled first (different signature), its Android/data is deleted, the game may refuse modified files,
  and the account may be banned. Use an extra account first.
