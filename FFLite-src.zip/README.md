# FF Lite (Android app)
Build: GitHub repo mein FFLite-src.zip + .github/workflows/build-apk.yml daalo, Actions -> Build APK -> Run workflow,
artifact FFLite-APK se app-debug.apk install karo.
Use: game ka 'contentcache' folder/zip chuno, package name likho, level chuno -> output zip mein 'files' folder aata hai,
use Android/data/<package>/ mein paste karo. Untested build.
