# Potato 🥔 Manager (v2.0.0)

Build: same as before. Upload this zip to the repo root (name stays FFLite-src.zip), the existing workflow unzips and builds.
Untested build (no compiler here). If GitHub shows an error, send the error line.

## What it is
A ZArchiver-style file manager. First start: allow "All files access".
- Browse folders, long-press to select (tick), then Copy / Cut / Paste / Delete / Zip / Extract, or Potato 🥔.
- Potato 🥔: processes every Unity bundle in the selected folders/files (for example Android/data/<game>/files).
  Output: /Potato Manager/Potato 🥔 by Nixu/<package>/<same path as in the game>. Only changed files are written.
- Preview: a real texture from your selection, decoded from its real bytes at the exact mip level the processing keeps
  (plain formats on the CPU, ASTC/ETC2/DXT on the phone GPU). If the phone cannot decode, it says so; nothing is faked.
- Android/data on Android 11+ is blocked by the system for normal apps. In that case the app uses Shizuku (already in the project).
- "Copy log" is at the bottom.

## Limits (honest)
- Textures with mip levels: the biggest mip levels are removed (exact, no re-encoding).
- Plain 8-bit textures (RGB24 / RGBA32 / ...) without mips: resampled.
- Compressed textures (ASTC/ETC2/DXT) without mip levels cannot be shrunk without a texture encoder. They are counted in the report.
- "Include UI / sprite bundles" is ON by default; UI may look broken at high levels.
