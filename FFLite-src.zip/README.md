# FF Lite (Android app)

## Build (GitHub Actions)
Same as the other projects: upload this zip to the repo root, the existing workflow unzips it and builds.
The project module is called `app` (Groovy Gradle, AGP 8.2.2, same as LiveEditor). There is no workflow file
inside this zip on purpose: the one already in your repo is used. APK: app-debug.apk / app-release.apk
(release is signed with the debug key, so it installs too).

## Use (v1.2)
1. Open the app, pick the game from the Games / Apps list.
2. Shizuku: start it, press "Permission do" once (Android 10 or lower can work without it).
3. Pick the level, tick what you want: "Seedha game mein apply" and / or "Zip bhi banao", press "Shuru karo".
4. Progress bar shows phase, x / total, current file, counters and time. Toast + vibration when done.

## What it does
- Direct apply: stops the game, backs up each original (app's own folder), writes the new file to a temp name,
  renames it atomically, checks CRC. If anything fails for a file the original of that file is put back.
- Backup is kept, so changing the level always starts from the ORIGINAL (no double shrink), and "Restore karo"
  puts the originals back (a file is skipped if the game replaced it meanwhile, e.g. an update).
- Zip is streamed straight to the place you choose (no second copy in cache). 4 GB zip limit is guarded.
- Big bundles are skipped when RAM is too small (heap / 5), reported in the summary.
- Manual Zip / Folder source still works (zip only, no direct apply).
- Untested build (no compiler here). If GitHub shows an error, send the error line.

## Character saaf, baaki potato (v1.3)
- Card "Character saaf, baaki sab potato": keywords (default guess) jo textures / asset paths se match karein, unhe level se chhota nahi kiya jata.
- Match texture ke naam (m_Name) aur bundle ke AssetBundle container paths par hota hai.
- Keywords sirf andaze hain. "Scan report banao" kuch badle bina FFLite_scan_report.txt likhta hai (bundle, asset paths, texture names,
  * = keyword match). Us file se keywords tune karo.
- Keywords badalne par files dobara process hoti hain (backup record mein level + keywords ka tag hai).
