# Tater Manager (v3.0.0) - separate app, package com.spudlab.tater

Build: same as before. Upload this zip to the repo root (name stays FFLite-src.zip), the existing workflow unzips and builds.
If the repo still has the OLD folder app/src/main/java/com/fflite (and app/src/main/aidl/com/fflite), delete both folders first.
Untested build (no compiler here). If GitHub shows an error, send the error line.

## New identity
- Own package (com.spudlab.tater), own name (Tater Manager), own icon (green), own folders ("Tater Manager/Potato Output/..").
  It installs NEXT TO the old app, it never replaces or touches it.
- A fixed signing key (app/tater.keystore) is inside, so every new build can be installed over the previous Tater build
  and the permissions stay.
- No phone trusts an app because of its name. If "All files access" is greyed out (Android 13+): Settings > Apps > Tater Manager >
  three dots (top right) > "Allow restricted settings", then allow "All files access".

## Potato
- Keep sharp (characters, guns): words, default "character, avatar, weapon, gun, hero, npc, player". Textures / bundles whose asset path,
  file path or name contain one of these words are not touched. Edit the words in the Potato window if your game names them differently.
- Lobby: words, default "lobby". Those textures only get a light blur (at most Lite 1/2), whatever the slider says.
- Everything else gets the slider level.
- Compressed textures WITHOUT mip levels (ASTC / ETC2 / DXT) used to be skipped ("Not reducible"). Now: decoded on the phone GPU, shrunk,
  written as ETC2 (RGB, or RGBA8 when the texture has transparency) and checked by decoding the new texture on the GPU again.
  If the check fails, the original stays and the texture is listed.
- After a run, every texture that stayed unchanged is listed with a small picture (when the phone can decode it), its format and the reason.
- The result says how many textures matched "keep sharp" and "lobby" (with example names) so you can fix the words.

## Paste
- Paste / Paste & replace ends with a window "Applied successfully" (files written, where), or "Not applied" with the error.

## Limits (honest)
- Crunch-compressed, PVRTC, BC7 and similar formats cannot be decoded here: they are listed (no picture) and stay unchanged.
- Textures bigger than 2048x2048 without mips cannot be decoded on the GPU in one go: listed, unchanged.
- Android/data access: open the folder, "Allow access" > "Use this folder" > "Allow" (or Shizuku), as before.
