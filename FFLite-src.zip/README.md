# Tater Manager (v3.8.0) - separate app, package com.spudlab.tater

Build: same as before. Upload this zip to the repo root (name stays FFLite-src.zip), the existing workflow unzips and builds.
Untested build (no compiler here). If GitHub shows an error, send the error line.
New file: Classify.kt, Thumbs.kt. Changed: UnityFs.kt, Potato.kt, Reencode.kt (tiny), Preview.kt (format names), MainActivity.kt (Potato window + report).

## v3.7.0
- Potato run now has a full-screen loading window with a percent counter and a bar from 0 to 100% (percent = bytes looked at / bytes of the whole selection).
- "Extra: always keep sharp" starts with "icon, pickup" so the gun pictures in the pick-up window stay sharp.

## v3.6.0: Gloo Vault tab (new)
Make your own gloo wall skin from two photos and put it in the game as a glitch file.
- Target: the "Crisp" apple gloo wall (CS-Ranked) = texture IceWall_Bunker_Apple_GR_D in bundle optionalab_weapon_096.* (found automatically in the game folders, or pick the file).
- Front photo (your side) and Back photo (enemy side). The preview is the REAL 3D model of the wall (decoded from the bundle, shipped as assets/gloo_apple_gr.bin)
  with your photo projected onto it, exactly as it is baked into the texture. Drag / pinch / turn, sliders for size, turn, move, mirror. No automatic crop.
- "Generate gloo wall": the photos are baked into the texture atlas (512 px), written as ETC2, the normal / specular maps of the apple are turned into flat colours
  (flat finish, frees space and removes the apple relief), the bundle is packed again (LZ4HC 12) and padded to the ORIGINAL file size.
  If 512 px does not fit it falls back to 256 px with mip levels. Every result is read back and checked before it is saved.
- Game choice: Free Fire India / Free Fire MAX (found automatically, the bundle is searched in both).
- Output: Tater Manager/Gloo Vault/<package>/<same folders and file name as in Android/data/<package>/> (for example Gloo Vault/com.dts.freefiremax/files/contentcache/.../optionalab_weapon_096.xxxx). "Copy into the game now" backs up the original to Gloo Vault/Original backup first.
- Copy log button at the bottom.
Untested build (no compiler here). If GitHub shows an error, send the error line.

## v3.4.1: HUD buttons turned into grey squares - found and fixed
Cause (found by reading all 5,982 texture names of the Free Fire India 1.134.1 APK): every HUD / menu picture sheet is named FF_UI_* , FF_ingame_* ,
FF_fakeloading* , dts_* , UI* ... The category rules only knew UIFX_ / icon_ / ui_, so about 1,380 UI sheets (88 MB) landed in "Other",
and "Other" was set to Potato. The joystick, fire button and HUD panels were shrunk to a few pixels = grey squares.
Fixed: all those names are now "UI" (default Keep). 1P_* (the gun in your hands) is now "Weapon" (it was "Other"). Vehicles, props, airdrops, indoor
scenes are "Map / environment". "Other" now defaults to Light (half size) so anything unknown stays safe.
Every category row in the Potato window now has one line that says what it is. Colour filter no longer touches UI (it also used to hit "Other").

### What is inside the 1.134.1 APK (measured, uncompressed texture size, new rules)
| Category | textures | size | what you see | advice |
|---|---|---|---|---|
| UI | 2,287 | 76.7 MB | HUD, joystick, fire / jump / crouch buttons, weapon bar, minimap, shop, lobby menus, icons, loading screens | Keep |
| Map / environment | 512 | 35.8 MB | ground, buildings, walls, trees, rocks, sky, vehicles, indoor | Potato |
| Effects (VFX) | 1,427 | 22.1 MB | smoke, fire, explosions, lightning, emote and skin effects, UI effects | Potato |
| Other | 498 | 17.2 MB | props, airdrops, items, bosses, post-processing colour tables (never shrunk) | Light |
| Weapon | 441 | 13.5 MB | 1P_ = gun in your hands, 3P_ = gun on players / ground, grenades, melee | Keep or Light |
| Character | 438 | 9.4 MB | outfits, faces, hair, shoes, backpacks (Male_ / Female_) | Keep |
| Lightmap | 361 | 7.0 MB | baked shadows of the map | Potato |
| Pet, Lobby | 18 | 0.7 MB | pets, lobby room | any |

Name prefixes: 1P_ first person, 3P_ third person; PW primary weapon, SW secondary (pistol), MW melee, EW equipment (grenade); D / N / S at the end = colour /
normal / specular map; NB_GP, JS_GP, SA_GP = map object sets; Lightmap_150 / _300 = baked shadow tiles of the map.
Formats: 4,702 textures are ASTC 8x8 and 1,062 are ASTC 10x10 (already 2 and 1.3 bits per pixel), 50% have no mip levels. They are already small,
so expect a lower texture memory and fewer stutters on a weak phone, not a big FPS jump. Maps: the 1,257 PVP_Paradise tile scenes only point to
textures, many map textures are not in the APK at all (they come in the game's downloaded data: scan Android/data/<package>/files too).

## What was wrong before (found in a real 283 MB contentcache)
- 18 of 48 bundles use the newer bundle header (v8, 16-byte padding, flag 0x200) and a newer serialized file (v22, Unity 2022 style).
  The old reader skipped them without saying so. These are clothes, emotes, avatars, pets, training ground, hippo effects. Now supported.
- The two big "map" bundles (Unity 5.6.3, 76 MB and 31 MB) were read with the wrong field layout. Read correctly they only hold
  5x5 placeholder pictures (all 757 textures): the real map textures are NOT in those files. They are listed as "placeholder".
- 1963 of 3601 textures have no mip levels (ASTC without mips: characters, clothes). Dropping mips does nothing for them, they must be re-encoded.
  That path exists (GPU decode, shrink, ETC2, check) and now also works for the new bundles.

## Potato window
- Scan only: reads everything, writes NOTHING, and shows what would change and what would not.
- Categories are found automatically (Character, Weapon, Lobby, UI, Pet, Effects, Lightmap, Map, Other) from texture names and asset paths.
  Each has Keep / Light (at most 1/2) / Potato (slider level). Defaults: characters, weapons, UI = Keep, lobby = Light, the rest = Potato.
- Full potato bundles (words): everything inside bundles whose path contains these words gets the level, whatever the categories say.
  Default "training, tutorial" = training ground completely potato.
- Colour lookup / ramp textures (names with lut, ramp, gradation, lookup) are never shrunk (it would break the colours).
- Every written bundle is opened again and every texture is checked BEFORE it is saved. A bundle that fails is not saved.
- Report screen: tabs Changed / Kept / Not changeable / Bundles. Every texture has a picture (before and after), size, format, category and reason.
  Filter by category, search by name. Also written to "Tater Manager/Potato Reports/<package>/Potato Report.txt and .csv".
- Apply to game: copies the new files into the game folder and first backs up the original of each file (Tater Manager/Backup). Restore originals puts them back.
- .trashed- files and partly downloaded bundles are skipped and named in the report.

## Limits (honest)
- Only what is inside the files you select can change. Textures that live in OBB / APK / other files are not touched.
- Crunch-compressed, PVRTC, BC7 and similar formats cannot be decoded here: listed, unchanged.
- Textures bigger than 2048x2048 without mips cannot be decoded on the GPU in one go: listed, unchanged.
- Android/data access: open the folder, "Allow access" > "Use this folder" > "Allow" (or Shizuku), as before.

## v3.2.0: Game / APK tab (for Bermuda and everything else that is not in Android/data)
Why: Bermuda's textures are NOT in Android/data/<pkg>/files (only its language text is). Free Fire India has no OBB, so the map data is inside
the APK / split APKs of the installed game. The Files tab can never reach it.
- Bottom bar: Files (as before) | Game / APK.
- Game / APK: the list of installed apps (games first). Pick the game, press "Potato the APK". Or select .apk files in the Files tab and press "APK".
- Same Potato window (levels, categories, Scan only, report with pictures). Scan first: it also prints what is inside the APK
  (files, stored / compressed, biggest types, how many Unity bundles can be changed).
- Only Unity bundles that are STORED (not compressed) inside the APK are changed, in place, same size and position, CRC fixed. Nothing else in the APK moves.
- Every APK of the game (base + splits) is signed again with Tater's own key (APK signature v2, library apksig) and written to
  Tater Manager/Patched APK/<package>/.
- Install: "1. Uninstall original", then "2. Install patched" (Android's own installer window asks you to confirm).
  Android never updates an app with a different signature, so the original MUST be uninstalled first. Account data is online, Android/data of the game is deleted.
- New permissions: see all apps, install apps, uninstall apps. New files: ApkTools.kt, GameTab.kt, assets/tater_sign_*.der (the signing key).

Limits: bundles that are compressed inside the APK are listed but not changed (next step if the scan shows that). Plain Unity .assets / .resS files
inside the APK are counted but not handled yet. Games can refuse to run when their signature or files changed, and an account can be banned for it.
Use an extra account first. Untested on a real Free Fire India APK (no compiler / no APK here): send the Scan summary if something does not match.

v3.2.1: the APK scan summary now also lists the biggest folders and the 8 biggest files of every APK (size, stored / compressed, first 4 bytes),
so it is clear in one look where the game keeps its maps (Unity bundles, plain .assets, or something else).

v3.2.2: build fix. ApkTools.kt called ApkSigner.Builder.setAlignmentPreserved, which apksig 8.2.2 does not have ("Unresolved reference"). It is now called by name only if the library has it.

## v3.3.0: plain Unity data files inside the APK (this is where Free Fire India keeps Bermuda)
Found in a real Free Fire India 1.134.1 APK set (split_asset_pack_install_time.apk, 306 MB): about 39,000 plain Unity data files
(hash-named files, level*, sharedassets*), COMPRESSED inside the APK, about 5,900 textures (172 MB, mostly ASTC), half of them without mip levels.
There are no UnityFS bundles there, so 3.2.x found "0 textures".
- New: those files are read (also compressed bundles inside the APK), the textures are changed with the same engine as for bundles
  (categories, levels, re-encode of textures without mips, check before saving), and each file is compressed again.
- New: the APK is written again (ApkRewrite). Every other file is copied byte for byte. A changed file moves the later files by a multiple of 16 KB,
  so resources.arsc and native libraries stay aligned. The old signing block is dropped, then Tater signs all APK files as before.
- Safety: a changed file is read back and checked before it is accepted. The new APK is opened again and every changed file (plus a sample of the
  others) must read back with the right CRC, otherwise that APK is NOT used and the report says so.
- Scan only works for these files too (nothing is written): the report lists every texture of Bermuda with its category.
- The rewrite logic was run on a synthetic signed APK (deflated + stored + data descriptors + signing block): all files read back with the right CRC,
  stored files kept their alignment. The Kotlin code itself and the texture parsing of these data files have NOT run on the real APK (no compiler / no APK here).
- Defaults keep characters, weapons and UI untouched; map, terrain, trees, walls, vehicles and effects get the level.
- Still true: the original game must be uninstalled first (different signature), its Android/data is deleted, the game may refuse modified files,
  and the account may be banned. Use an extra account first.


## v3.4.0: colour filter + preview, Patched APK list
- Potato window: new "Colour filter + preview" button. 3 filters (Vivid, Warm, Fresh) + a strength slider (0-100%). The window shows a game screenshot
  Before / After. The white boxes (character, buttons, HUD) stay unchanged, like in the game: only MAP colour textures get the filter
  (ground, walls, trees, rocks, cars). Characters, weapons, pets, UI, lobby, effects, lightmaps and normal / mask / lookup textures are never recoloured.
  "My screenshot" lets you load your own picture; tap or drag on the After picture to put the box over your character.
  The chosen filter is remembered. Patching with a filter takes longer (the textures are decoded, recoloured and re-encoded as ETC2 and checked).
- New third tab "Patched" (bottom bar): every game in Tater Manager/Patched APK/<package> with an Install button (Android package installer,
  base + splits as one session), "Uninstall original" and Delete.
- New files: Colour.kt (filter, preview window), PatchedTab.kt. Changed: UnityFs.kt (Plan.fx, shrinkTex), Reencode.kt (recolour, convert + fx), MainActivity.kt.
  Two sample screenshots in res/drawable-nodpi.

## v3.5.0: UI no longer disappears + 9 more colour filters
Why buttons, banners and popup backgrounds went missing (lobby / login page showed only text and grey squares): a Sprite stores its picture as a pixel
rectangle of ONE big texture (an atlas). If that atlas is made smaller, every rectangle points to the wrong place. Text still shows because fonts are separate textures.
Even "Light" (half size) breaks an atlas, so unknown textures must not be shrunk at all.
- Unknown textures (category Other) now default to KEEP (was Light).
- NEW: textures that Sprites of the same file use are found by reading the Sprite objects (their m_RD.texture reference) and counted as UI, whatever their name is.
  The value is only used when it is the id of a texture of the same file, so a layout that does not fit simply finds nothing.
- NEW: an unknown texture with no mip levels and clamped edges is counted as UI (world textures repeat and have mip levels).
- More UI name words: mapbg, atlas, sprite, btn, button, panel, frame, window, dialog, logo, login, splash, loading, joystick, crosshair, compass, reticle, badge,
  medal, notice, cursor, tutorial, reward, banner, slot, toast, title, tab. The report shows the reason ("used by Sprites of this file", "looks like a UI picture").
- Colour filters: 12 instead of 3 (Vivid, Warm, Fresh + Pro Max, Cinematic, Golden hour, Neon, Cool night, Noir, Pastel, HDR pop) and Custom with 6 sliders
  (Saturation, Vibrance, Contrast, Brightness, Warmth, Tint). New maths: vibrance, gamma, s-curve, split toning (own colour for shadows and highlights).
  The old three give exactly the same pixels as before (checked). The preview uses the same maths as the real textures.
- A colour filter only changes colours. It cannot add detail, shadows or sharpness that a smaller texture has lost.
- A game that was already patched with older rules has the small atlases inside: patch again from the ORIGINAL APK (uninstall the patched game, install the original, Scan only, then Potato).
- Not run: no compiler here, and the Sprite layout was not tested on a real APK.


## v3.8.0: "Reference HD" colour filter
New filter at the end of the list: Reference HD. Its 15 parameters were fitted (least squares in Lab colour space) between a real potato screenshot and 7 HD reference
screenshots, so it moves the potato colours to the HD colours: richer green, warmer lights, more saturation and a little more contrast. The preview shows the target
picture above Before / After when this filter is chosen. The filter changes only the COLOUR of map textures (Potato removes the texture detail, a colour filter can
not bring it back, and sky / light / fog are not textures), so it gives the colour mood of the reference, not a pixel copy.
