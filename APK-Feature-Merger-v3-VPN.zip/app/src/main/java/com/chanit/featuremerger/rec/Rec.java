package com.chanit.featuremerger.rec;

import android.app.Activity;
import android.app.Application;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Checkable;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Recorder that Feature Merger injects into the SOURCE app. It
 *  - shows a small floating panel,
 *  - notices every tap on every button / switch of the app (also on the app's own floating menu),
 *  - after each tap looks at what changed inside the app (services, threads, native libs, files, prefs,
 *    classes, windows, VPN) and keeps the result per control,
 *  - calls a control "confirmed" after 3 taps (ON, OFF, ON ...) and saves a preview screenshot,
 *  - sends the whole recording back to Feature Merger.
 */
public final class Rec {
    static final String TAG = "FmRec";
    static final String FM_PKG = "com.chanit.featuremerger";
    static final int CONFIRM_AT = 3;

    private static Context app;
    private static Handler ui, bg;
    private static File dir;
    private static String[] names = new String[0];
    private static volatile RecSnap last;
    private static boolean inited, asked;
    private static Activity current;
    private static RecPanel panel;
    private static int observing;

    private static final Map<String, Ctl> ctls = new LinkedHashMap<String, Ctl>();
    private static final WeakHashMap<View, Boolean> hooked = new WeakHashMap<View, Boolean>();

    private static final class Cycle {
        int state;
        RecSnap.Diff diff;
    }

    private static final class Ctl {
        int index;
        String key, label, idName, cls;
        int clicks, state = -1;
        boolean confirmed;
        final List<Cycle> cycles = new ArrayList<Cycle>();
        String prevOn, prevOff;
    }

    // ------------------------------------------------------------------ start
    public static synchronized void init(Context ctx) {
        if (inited || ctx == null) return;
        inited = true;
        app = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
        ui = new Handler(Looper.getMainLooper());
        HandlerThread t = new HandlerThread("fm-rec", Thread.MIN_PRIORITY);
        t.start();
        bg = new Handler(t.getLooper());
        dir = new File(app.getFilesDir(), "fm_rec");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        loadNames();
        if (app instanceof Application) {
            ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override public void onActivityResumed(Activity a) { current = a; }
                @Override public void onActivityPaused(Activity a) { if (current == a) current = null; }
                @Override public void onActivityCreated(Activity a, Bundle b) { }
                @Override public void onActivityStarted(Activity a) { }
                @Override public void onActivityStopped(Activity a) { }
                @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                @Override public void onActivityDestroyed(Activity a) { }
            });
        }
        ui.postDelayed(SHOW, 1500);
        ui.postDelayed(SCAN, 1500);
        bg.postDelayed(ROLL, 2500);
    }

    static File dir() { return dir; }

    static boolean isOwnWindow(Object root) { return panel != null && panel.view() == root; }

    private static void loadNames() {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(app.getAssets().open("fm/rec_classes.txt"), "UTF-8"))) {
            List<String> l = new ArrayList<String>();
            String s;
            while ((s = r.readLine()) != null) if (s.length() > 0) l.add(s);
            names = l.toArray(new String[0]);
        } catch (Throwable t) {
            Log.w(TAG, "no class list: " + t);
        }
    }

    // ------------------------------------------------------------------ panel (needs "display over other apps")
    private static final Runnable SHOW = new Runnable() {
        @Override public void run() {
            try {
                if (panel != null) return;
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(app)) {
                    if (!asked) {
                        asked = true;
                        Toast.makeText(app, "FM Recorder: allow \"Display over other apps\", then come back", Toast.LENGTH_LONG).show();
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + app.getPackageName()));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        app.startActivity(i);
                    }
                    ui.postDelayed(this, 2000);
                    return;
                }
                panel = new RecPanel(app);
                panel.show();
                refreshPanel();
            } catch (Throwable t) {
                Log.e(TAG, "panel", t);
                panel = null;
                ui.postDelayed(this, 4000);
            }
        }
    };

    // ------------------------------------------------------------------ finding and hooking the app's controls
    private static final Runnable SCAN = new Runnable() {
        @Override public void run() {
            try {
                List<View> roots = new ArrayList<View>();
                collectRoots(roots);
                for (View r : roots) {
                    if (panel != null && panel.view() == r) continue;
                    hookTree(r, 0);
                }
            } catch (Throwable t) {
                Log.w(TAG, "scan: " + t);
            }
            ui.postDelayed(this, 600);
        }
    };

    @SuppressWarnings("unchecked")
    private static void collectRoots(List<View> out) {
        try {
            Class<?> c = Class.forName("android.view.WindowManagerGlobal");
            Object g = c.getMethod("getInstance").invoke(null);
            Field f = c.getDeclaredField("mViews");
            f.setAccessible(true);
            Object v = f.get(g);
            if (v instanceof List) out.addAll((List<View>) v);
        } catch (Throwable ignored) { }
        Activity a = current;
        if (a != null && a.getWindow() != null) {
            View d = a.getWindow().getDecorView();
            if (!out.contains(d)) out.add(d);
        }
    }

    private static void hookTree(View v, int depth) {
        if (v == null || depth > 40) return;
        if ((v.isClickable() || v instanceof Checkable) && !hooked.containsKey(v)) {
            hooked.put(v, Boolean.TRUE);
            try {
                View.AccessibilityDelegate prev = null;
                if (Build.VERSION.SDK_INT >= 29) prev = v.getAccessibilityDelegate();
                v.setAccessibilityDelegate(new Spy(prev));
            } catch (Throwable ignored) { }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) hookTree(g.getChildAt(i), depth + 1);
        }
    }

    /** performClick() always reports TYPE_VIEW_CLICKED to the view's delegate, with or without accessibility. */
    private static final class Spy extends View.AccessibilityDelegate {
        private final View.AccessibilityDelegate prev;

        Spy(View.AccessibilityDelegate prev) { this.prev = prev; }

        @Override public void sendAccessibilityEvent(View host, int type) {
            if (type == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                try {
                    onTap(host);
                } catch (Throwable t) {
                    Log.w(TAG, "tap: " + t);
                }
            }
            if (prev != null) prev.sendAccessibilityEvent(host, type);
            else super.sendAccessibilityEvent(host, type);
        }
    }

    // ------------------------------------------------------------------ a tap
    private static void onTap(View v) {
        if (panel != null && panel.owns(v)) return;
        tap(v, labelOf(v), idName(v), v.getClass().getName(),
                v instanceof Checkable ? (((Checkable) v).isChecked() ? 1 : 0) : -1, v);
    }

    /** Fallback for menus that are drawn without views (the user presses "mark" in the panel instead). */
    static void manualTap() {
        tap(null, "Manual feature", "manual", "manual", -1, null);
    }

    private static void tap(View v, String label, String id, String cls, int checked, final View shotView) {
        String key = id + "|" + cls + "|" + label;
        Ctl c = ctls.get(key);
        if (c == null) {
            c = new Ctl();
            c.index = ctls.size();
            c.key = key;
            c.label = label;
            c.idName = id;
            c.cls = cls;
            ctls.put(key, c);
        }
        c.clicks++;
        c.state = checked >= 0 ? checked : (c.clicks % 2 == 1 ? 1 : 0);
        final Cycle cy = new Cycle();
        cy.state = c.state;
        c.cycles.add(cy);
        final Ctl fc = c;
        final RecSnap before = last;
        observing++;
        refreshPanel();

        // preview, a moment later so a moving switch has settled
        if (shotView != null) {
            ui.postDelayed(new Runnable() {
                @Override public void run() {
                    String f = "prev_" + fc.index + (cy.state == 1 ? "_on.png" : "_off.png");
                    if (shot(shotView, f)) {
                        if (cy.state == 1) fc.prevOn = f; else fc.prevOff = f;
                    }
                }
            }, 450);
        }

        // two looks after the tap: early (service starts) and late (slow engines)
        bg.postDelayed(new Runnable() {
            @Override public void run() {
                final RecSnap mid = RecSnap.take(app, names, true);
                bg.postDelayed(new Runnable() {
                    @Override public void run() {
                        RecSnap fin = RecSnap.take(app, names, true);
                        last = fin;
                        RecSnap.Diff d = RecSnap.diff(before, fin);
                        d.addAppeared(RecSnap.diff(before, mid));
                        cy.diff = d;
                        ui.post(new Runnable() {
                            @Override public void run() {
                                observing = Math.max(0, observing - 1);
                                if (fc.clicks >= CONFIRM_AT) fc.confirmed = true;
                                save();
                                refreshPanel();
                            }
                        });
                    }
                }, 3500);
            }
        }, 1500);
    }

    // ------------------------------------------------------------------ rolling snapshot ("before" for the next tap)
    private static int lastLoaded = -1;
    private static final Runnable ROLL = new Runnable() {
        @Override public void run() {
            try {
                int n = Debug.getLoadedClassCount();
                if (n <= 0 || n != lastLoaded || last == null) {
                    lastLoaded = n;
                    last = RecSnap.take(app, names, true);
                } else {
                    // classes did not change: refresh only the cheap parts and keep the class set
                    RecSnap s = RecSnap.take(app, names, false);
                    s.classes.or(last.classes);
                    last = s;
                }
            } catch (Throwable t) {
                Log.w(TAG, "roll: " + t);
            }
            bg.postDelayed(this, 3000);
        }
    };

    // ------------------------------------------------------------------ labels
    private static String idName(View v) {
        try {
            if (v.getId() != View.NO_ID) return v.getResources().getResourceEntryName(v.getId());
        } catch (Throwable ignored) { }
        return "noid";
    }

    private static String clip(String s) {
        s = s.replace('\n', ' ').trim();
        return s.length() > 40 ? s.substring(0, 40) : s;
    }

    private static String labelOf(View v) {
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null && t.toString().trim().length() > 0) return clip(t.toString());
        }
        CharSequence d = v.getContentDescription();
        if (d != null && d.toString().trim().length() > 0) return clip(d.toString());
        ViewParent p = v.getParent();
        for (int i = 0; i < 3 && p instanceof ViewGroup; i++) {
            String t = firstText((ViewGroup) p, v, 0);
            if (t != null) return clip(t);
            p = p.getParent();
        }
        String id = idName(v);
        return "noid".equals(id) ? v.getClass().getSimpleName() : id;
    }

    private static String firstText(ViewGroup g, View skip, int depth) {
        if (depth > 4) return null;
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c == skip) continue;
            if (c instanceof TextView) {
                CharSequence t = ((TextView) c).getText();
                if (t != null && t.toString().trim().length() > 0) return t.toString();
            } else if (c instanceof ViewGroup) {
                String t = firstText((ViewGroup) c, skip, depth + 1);
                if (t != null) return t;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ preview
    private static boolean shot(View v, String name) {
        try {
            View root = v.getRootView();
            int w = root.getWidth(), h = root.getHeight();
            if (w <= 0 || h <= 0) return false;
            float sc = Math.min(1f, 960f / Math.max(w, h));
            Bitmap b = Bitmap.createBitmap(Math.max(1, (int) (w * sc)), Math.max(1, (int) (h * sc)), Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            cv.scale(sc, sc);
            root.draw(cv);
            try (FileOutputStream o = new FileOutputStream(new File(dir, name))) {
                b.compress(Bitmap.CompressFormat.PNG, 100, o);
            }
            b.recycle();
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "shot: " + t);
            return false;
        }
    }

    // ------------------------------------------------------------------ panel text
    private static void refreshPanel() {
        if (panel == null) return;
        StringBuilder sb = new StringBuilder();
        if (ctls.isEmpty()) {
            sb.append("Tap the app's switches / buttons now.\nEach one needs ").append(CONFIRM_AT).append(" taps (ON, OFF, ON).\nWait ~5 s between taps.");
        } else {
            for (Ctl c : ctls.values()) {
                sb.append(c.confirmed ? "\u2714 " : "\u25CB ").append(c.label)
                        .append("  ").append(Math.min(c.clicks, CONFIRM_AT)).append('/').append(CONFIRM_AT);
                if (c.state == 1) sb.append("  ON"); else if (c.state == 0) sb.append("  OFF");
                sb.append('\n');
            }
            if (observing > 0) sb.append("\n\u23F3 watching what changed, don't tap for 5 s");
            else sb.append("\nDone? Press \"Send to FM\".");
        }
        panel.setText(sb.toString());
    }

    // ------------------------------------------------------------------ result
    private static Set<String> inter(List<Cycle> l, String cat, boolean added) {
        Set<String> r = null;
        for (Cycle y : l) {
            Set<String> s = added ? y.diff.added(cat) : y.diff.removed(cat);
            if (r == null) r = new HashSet<String>(s); else r.retainAll(s);
        }
        return r == null ? new HashSet<String>() : r;
    }

    private static Set<String> union(List<Cycle> l, String cat) {
        Set<String> r = new HashSet<String>();
        for (Cycle y : l) r.addAll(y.diff.added(cat));
        return r;
    }

    /** strong = appears on every ON and goes away on every OFF; weak = appears on ON only. */
    private static JSONArray strongWeak(List<Cycle> on, List<Cycle> off, String cat, boolean vpnCheck) throws Exception {
        JSONArray out = new JSONArray();
        Set<String> a = inter(on, cat, true);
        Set<String> gone = off.isEmpty() ? null : inter(off, cat, false);
        for (String s : a) {
            JSONObject o = new JSONObject();
            o.put("n", s);
            o.put("strong", gone != null && gone.contains(s));
            if (vpnCheck) o.put("vpn", isVpn(s));
            out.put(o);
        }
        return out;
    }

    private static boolean isVpn(String cls) {
        try {
            return android.net.VpnService.class.isAssignableFrom(Class.forName(cls, false, app.getClassLoader()));
        } catch (Throwable t) {
            return false;
        }
    }

    private static JSONObject derive(Ctl c) throws Exception {
        List<Cycle> on = new ArrayList<Cycle>(), off = new ArrayList<Cycle>();
        for (Cycle y : c.cycles) {
            if (y.diff == null) continue;
            if (y.state == 1) on.add(y); else off.add(y);
        }
        JSONObject o = new JSONObject();
        o.put("name", c.label);
        o.put("idName", c.idName);
        o.put("cls", c.cls);
        o.put("clicks", c.clicks);
        o.put("confirmed", c.confirmed);
        o.put("on", on.size());
        o.put("off", off.size());
        if (c.prevOn != null) o.put("prevOn", c.prevOn);
        if (c.prevOff != null) o.put("prevOff", c.prevOff);
        if (on.isEmpty()) return o;

        o.put("services", strongWeak(on, off, RecSnap.SVC, true));
        o.put("threads", strongWeak(on, off, RecSnap.THR, false));
        o.put("windows", strongWeak(on, off, RecSnap.WIN, false));
        o.put("files", strongWeak(on, off, RecSnap.FD, false));
        o.put("net", strongWeak(on, off, RecSnap.NET, false));
        JSONArray libs = new JSONArray();
        for (String s : union(on, RecSnap.LIB)) libs.put(s);
        o.put("libs", libs);

        // classes that were loaded because of the tap
        BitSet cls = new BitSet();
        for (Cycle y : on) cls.or(y.diff.newClasses);
        o.put("classCount", cls.cardinality());
        Map<String, Integer> pk = new HashMap<String, Integer>();
        for (int i = cls.nextSetBit(0); i >= 0; i = cls.nextSetBit(i + 1)) {
            if (i >= names.length) break;
            String n = names[i];
            String[] p = n.split("\\.");
            StringBuilder b = new StringBuilder();
            for (int k = 0; k < Math.min(3, p.length - 1); k++) b.append(k > 0 ? "." : "").append(p[k]);
            String key = b.length() == 0 ? "(default)" : b.toString();
            Integer cur = pk.get(key);
            pk.put(key, cur == null ? 1 : cur + 1);
        }
        JSONArray pa = new JSONArray();
        List<Map.Entry<String, Integer>> es = new ArrayList<Map.Entry<String, Integer>>(pk.entrySet());
        java.util.Collections.sort(es, new java.util.Comparator<Map.Entry<String, Integer>>() {
            @Override public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) { return b.getValue() - a.getValue(); }
        });
        for (int i = 0; i < Math.min(10, es.size()); i++) pa.put(es.get(i).getKey() + ":" + es.get(i).getValue());
        o.put("classPkgs", pa);

        // settings the app saved: keys that flipped on every tap are the real ON/OFF state
        Map<String, Integer> seen = new HashMap<String, Integer>();
        for (Cycle y : c.cycles) if (y.diff != null) for (String k : y.diff.prefChanged.keySet()) {
            Integer n = seen.get(k);
            seen.put(k, n == null ? 1 : n + 1);
        }
        int total = on.size() + off.size();
        JSONArray pf = new JSONArray();
        int cap = 0;
        for (Map.Entry<String, Integer> e : seen.entrySet()) {
            if (cap++ >= 30) break;
            String onVal = "", offVal = "";
            for (Cycle y : c.cycles) {
                String[] ch = y.diff == null ? null : y.diff.prefChanged.get(e.getKey());
                if (ch == null) continue;
                if (y.state == 1) onVal = ch[1]; else offVal = ch[1];
            }
            JSONObject p = new JSONObject();
            p.put("k", e.getKey());
            p.put("on", onVal);
            p.put("off", offVal);
            p.put("strong", total > 1 && e.getValue() == total);
            pf.put(p);
        }
        o.put("prefs", pf);
        return o;
    }

    private static void save() {
        try {
            JSONObject r = new JSONObject();
            r.put("v", 1);
            r.put("pkg", app.getPackageName());
            r.put("app", String.valueOf(app.getPackageManager().getApplicationLabel(app.getApplicationInfo())));
            r.put("time", System.currentTimeMillis());
            r.put("sdk", Build.VERSION.SDK_INT);
            JSONArray fs = new JSONArray();
            for (Ctl c : ctls.values()) fs.put(derive(c));
            r.put("features", fs);
            try (FileOutputStream o = new FileOutputStream(new File(dir, "recording.json"))) {
                o.write(r.toString().getBytes("UTF-8"));
            }
        } catch (Throwable t) {
            Log.w(TAG, "save: " + t);
        }
    }

    // ------------------------------------------------------------------ send to Feature Merger
    static void send() {
        try {
            save();
            File zip = new File(dir, "fm_rec.zip");
            try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(zip))) {
                File[] fs = dir.listFiles();
                if (fs != null) for (File f : fs) {
                    String n = f.getName();
                    if (!(n.equals("recording.json") || (n.startsWith("prev_") && n.endsWith(".png")))) continue;
                    z.putNextEntry(new ZipEntry(n));
                    try (FileInputStream in = new FileInputStream(f)) {
                        byte[] buf = new byte[1 << 14];
                        int r;
                        while ((r = in.read(buf)) > 0) z.write(buf, 0, r);
                    }
                    z.closeEntry();
                }
            }
            Uri uri = Uri.parse("content://" + app.getPackageName() + ".fmrec/fm_rec.zip");
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/zip");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.setClipData(ClipData.newRawUri("fm", uri));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                Intent direct = new Intent(i);
                direct.setPackage(FM_PKG);
                app.startActivity(direct);
            } catch (Throwable notFound) {
                Intent ch = Intent.createChooser(i, "Send recording to Feature Merger");
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                app.startActivity(ch);
            }
        } catch (Throwable t) {
            Log.e(TAG, "send", t);
            Toast.makeText(app, "Could not send: " + t, Toast.LENGTH_LONG).show();
        }
    }
}
