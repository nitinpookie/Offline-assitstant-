package com.chanit.featuremerger.vpnshim;

import android.net.VpnService;

/**
 * Runtime helper that Feature Merger injects into a patched VPN app. Every call of
 * VpnService.Builder.addAllowedApplication(pkg) inside the VPN app is redirected to add(): it still does the
 * original call, and when pkg is one of the reference games it also allows the extra (target) packages.
 * The CFG text below is rewritten inside the patched copy of this class ("refs;targets"). Keep it as is.
 */
public final class FmVpn {
    private FmVpn() {}

    private static final String CFG = "@FMV{################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################}@";
    private static String[] refs = new String[0];
    private static String[] targets = new String[0];
    private static boolean parsed;

    public static VpnService.Builder add(VpnService.Builder b, String pkg) throws Exception {
        VpnService.Builder r = b.addAllowedApplication(pkg);
        try {
            parse();
            if (targets.length > 0 && matches(pkg)) {
                for (String t : targets) {
                    try {
                        b.addAllowedApplication(t);
                    } catch (Throwable ignored) {
                        // target app not installed: the original behaviour must not break
                    }
                }
            }
        } catch (Throwable ignored) {
            // never break the VPN because of the helper
        }
        return r;
    }

    private static boolean matches(String pkg) {
        if (refs.length == 0) return true;
        if (pkg == null) return false;
        for (String s : refs) if (s.equals(pkg)) return true;
        return false;
    }

    private static synchronized void parse() {
        if (parsed) return;
        parsed = true;
        String c = CFG;
        int s = c.indexOf('{');
        int e = c.lastIndexOf('}');
        String body = (s >= 0 && e > s) ? c.substring(s + 1, e) : "";
        body = body.replace("#", "").trim();
        String[] part = body.split(";", -1);
        refs = split(part.length > 0 ? part[0] : "");
        targets = split(part.length > 1 ? part[1] : "");
    }

    private static String[] split(String v) {
        String[] raw = v.split(",");
        int n = 0;
        String[] tmp = new String[raw.length];
        for (String x : raw) {
            String t = x.trim();
            if (t.length() > 0) tmp[n++] = t;
        }
        String[] out = new String[n];
        System.arraycopy(tmp, 0, out, 0, n);
        return out;
    }
}
