package com.chanit.featuremerger.core;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Makes a "recorder build" of a source app: the same app plus a floating recorder panel. The user runs that
 * build, taps the app's switches, and sends the recording back to Feature Merger.
 */
public final class RecorderBuilder {
    private RecorderBuilder() {}

    public static final String FM_PKG = "com.chanit.featuremerger";
    private static final String REC_PREFIX = "Lcom/chanit/featuremerger/rec/";
    private static final int A_NAME = 0x01010003, A_ENABLED = 0x0101000e, A_EXPORTED = 0x01010010,
            A_AUTH = 0x01010018, A_GRANT = 0x0101001b;
    private static final String[] SKIP = {
            "android.", "androidx.", "kotlin.", "kotlinx.", "j$.", "javax.", "dagger.", "okhttp3.", "okio.", "retrofit2.",
            "org.jetbrains.", "org.intellij.", "com.google.android.", "com.google.firebase.", "com.google.protobuf.",
            "com.google.common.", "com.bumptech.", "com.squareup.", "com.chanit.featuremerger.rec."
    };

    public static File build(Context ctx, Model.Apk apk, Merger.Sink s) throws Exception {
        File work = new File(ctx.getCacheDir(), "recorder");
        deleteTree(work);
        //noinspection ResultOfMethodCallIgnored
        work.mkdirs();
        File src = new File(apk.path);

        s.step(5, "Reading " + apk.label);
        Axml mf;
        int dexCount = 0;
        try (ZipFile zf = new ZipFile(src)) {
            ZipEntry me = zf.getEntry("AndroidManifest.xml");
            if (me == null) throw new IOException("App has no AndroidManifest.xml");
            mf = Axml.parse(ApkZip.readAll(zf, me));
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); )
                if (en.nextElement().getName().matches("classes\\d*\\.dex")) dexCount++;
        }
        if (dexCount == 0) throw new IOException("App has no code (classes.dex)");
        String pkg = mf.root.plain("package").text();
        Axml.Elem app = mf.root.child("application");
        if (app == null) throw new IOException("Manifest has no <application>");

        // ---------- list of the app's own classes (the recorder checks which of them get loaded after a tap)
        s.step(15, "Listing classes");
        StringBuilder names = new StringBuilder();
        int total = 0;
        try (ZipFile zf = new ZipFile(src)) {
            int i = 0;
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                if (!e.getName().matches("classes\\d*\\.dex")) continue;
                File tmp = new File(work, "src_" + (i++) + ".dex");
                try (InputStream in = zf.getInputStream(e); FileOutputStream o = new FileOutputStream(tmp)) {
                    byte[] buf = new byte[1 << 16];
                    int r;
                    while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                }
                try {
                    DexFile df = DexFileFactory.loadDexFile(tmp, Opcodes.getDefault());
                    for (ClassDef cd : df.getClasses()) {
                        String t = cd.getType();
                        String n = t.substring(1, t.length() - 1).replace('/', '.');
                        if (skip(n)) continue;
                        names.append(n).append('\n');
                        total++;
                    }
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                }
            }
        }
        s.log("Tracking " + total + " classes of the app");

        // ---------- manifest
        s.step(40, "Editing manifest");
        Set<String> have = new HashSet<>();
        for (Axml.Elem k : mf.root.kids) if ("uses-permission".equals(k.name) && k.text("name") != null) have.add(k.text("name"));
        int at = mf.root.kids.indexOf(app);
        for (String perm : new String[]{"android.permission.SYSTEM_ALERT_WINDOW", "android.permission.ACCESS_NETWORK_STATE"}) {
            if (have.contains(perm)) continue;
            Axml.Elem pe = new Axml.Elem("uses-permission");
            pe.put(Axml.str("name", A_NAME, perm));
            mf.root.kids.add(at++, pe);
        }
        // Android 11+ hides other apps unless asked for; the recorder must be able to open Feature Merger
        Axml.Elem q = mf.root.child("queries");
        if (q == null) {
            q = new Axml.Elem("queries");
            mf.root.kids.add(at++, q);
        }
        Axml.Elem qp = new Axml.Elem("package");
        qp.put(Axml.str("name", A_NAME, FM_PKG));
        q.kids.add(qp);

        Axml.Elem prov = new Axml.Elem("provider");
        prov.put(Axml.str("name", A_NAME, "com.chanit.featuremerger.rec.RecProvider"));
        prov.put(Axml.bool("enabled", A_ENABLED, true));
        prov.put(Axml.bool("exported", A_EXPORTED, false));
        prov.put(Axml.bool("grantUriPermissions", A_GRANT, true));
        prov.put(Axml.str("authorities", A_AUTH, pkg + ".fmrec"));
        app.kids.add(prov);

        // ---------- recorder code
        s.step(55, "Building recorder code");
        File recDex = new File(work, "rec.dex");
        int n = BridgeDex.extract(ctx, recDex, REC_PREFIX);
        s.log("Recorder: " + n + " classes");

        // ---------- write unsigned apk
        s.step(70, "Writing new APK");
        File unsigned = new File(work, "unsigned.apk");
        Map<String, byte[]> rep = new LinkedHashMap<>();
        rep.put("AndroidManifest.xml", mf.build());
        try (ApkZip.Writer w = new ApkZip.Writer(unsigned)) {
            w.copy(src, rep, true);
            w.put("classes" + (dexCount + 1) + ".dex", readAll(recDex), false);
            w.put("assets/fm/rec_classes.txt", names.toString().getBytes("UTF-8"), false);
        }

        // ---------- sign
        s.step(85, "Signing");
        File outDir = ctx.getExternalFilesDir("Output");
        if (outDir == null) outDir = new File(ctx.getFilesDir(), "Output");
        //noinspection ResultOfMethodCallIgnored
        outDir.mkdirs();
        File out = new File(outDir, apk.label.replaceAll("[^A-Za-z0-9._-]", "_") + "_recorder.apk");
        Signer.sign(new File(ctx.getFilesDir(), "keys"), unsigned, out);

        // ---------- verify
        s.step(95, "Checking the result");
        PackageInfo pi = ctx.getPackageManager().getPackageArchiveInfo(out.getAbsolutePath(), PackageManager.GET_PROVIDERS);
        if (pi == null) throw new IOException("Android cannot read the new APK (manifest problem). Nothing was installed.");
        boolean ok = false;
        if (pi.providers != null)
            for (android.content.pm.ProviderInfo p : pi.providers) if (p.name.endsWith("RecProvider")) ok = true;
        if (!ok) throw new IOException("Recorder provider missing in the new APK.");
        deleteTree(work);
        s.step(100, "Done");
        s.log("Saved: " + out.getAbsolutePath());
        return out;
    }

    private static boolean skip(String n) {
        for (String p : SKIP) if (n.startsWith(p)) return true;
        return n.endsWith(".R") || n.contains(".R$") || n.endsWith(".BuildConfig");
    }

    private static byte[] readAll(File f) throws IOException {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[1 << 16];
            int r;
            while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
        }
        return bo.toByteArray();
    }

    private static void deleteTree(File f) {
        File[] k = f.listFiles();
        if (k != null) for (File c : k) deleteTree(c);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
