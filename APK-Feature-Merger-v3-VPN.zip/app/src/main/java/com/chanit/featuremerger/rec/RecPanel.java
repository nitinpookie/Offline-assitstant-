package com.chanit.featuremerger.rec;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** The small floating panel of the recorder. Plain views, no theme or library needed. */
final class RecPanel {
    private final Context c;
    private final WindowManager wm;
    private final WindowManager.LayoutParams lp;
    private final LinearLayout root, body;
    private final TextView head, text;
    private boolean open = true;

    RecPanel(Context ctx) {
        c = ctx;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(8);
        lp.y = dp(110);

        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(235, 24, 24, 28));
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.rgb(229, 57, 53));
        root.setBackground(bg);
        root.setPadding(dp(10), dp(8), dp(10), dp(10));

        head = new TextView(c);
        head.setText("\u25CF FM Recorder  \u25BE");
        head.setTextColor(Color.rgb(255, 110, 100));
        head.setTextSize(13);
        head.setPadding(0, 0, 0, dp(4));
        head.setOnTouchListener(new View.OnTouchListener() {
            private float dx, dy;
            private int sx, sy;
            private boolean moved;

            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX();
                        dy = e.getRawY();
                        sx = lp.x;
                        sy = lp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - dx) > dp(6) || Math.abs(e.getRawY() - dy) > dp(6)) moved = true;
                        if (moved) {
                            lp.x = sx + (int) (e.getRawX() - dx);
                            lp.y = sy + (int) (e.getRawY() - dy);
                            try { wm.updateViewLayout(root, lp); } catch (Throwable ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) toggle();
                        return true;
                    default:
                        return false;
                }
            }
        });
        root.addView(head);

        body = new LinearLayout(c);
        body.setOrientation(LinearLayout.VERTICAL);
        text = new TextView(c);
        text.setTextColor(Color.WHITE);
        text.setTextSize(12);
        text.setMaxWidth(dp(250));
        body.addView(text);

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(8), 0, 0);
        row.addView(button("Mark", new View.OnClickListener() {
            @Override public void onClick(View v) { Rec.manualTap(); }
        }));
        row.addView(button("Send to FM", new View.OnClickListener() {
            @Override public void onClick(View v) { Rec.send(); }
        }));
        body.addView(row);
        root.addView(body);
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(10), dp(4), dp(10), dp(4));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36));
        p.rightMargin = dp(6);
        b.setLayoutParams(p);
        return b;
    }

    private void toggle() {
        open = !open;
        body.setVisibility(open ? View.VISIBLE : View.GONE);
        head.setText(open ? "\u25CF FM Recorder  \u25BE" : "\u25CF REC");
    }

    void show() { wm.addView(root, lp); }

    View view() { return root; }

    boolean owns(View v) { return v != null && v.getRootView() == root; }

    void setText(String s) { text.setText(s); }

    private int dp(int v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }
}
