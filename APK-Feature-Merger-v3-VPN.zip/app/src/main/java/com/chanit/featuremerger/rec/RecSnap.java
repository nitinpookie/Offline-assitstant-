package com.chanit.featuremerger.rec;

import android.app.ActivityManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.system.Os;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** One look at what the app is doing right now. Two looks are compared to see what a tap changed. */
final class RecSnap {
    static final String SVC = "svc", THR = "thr", LIB = "lib", FD = "fd", WIN = "win", NET = "net";
    static final String[] CATS = {SVC, THR, LIB, FD, WIN, NET};

    final BitSet classes = new BitSet();
    final Map<String, Set<String>> sets = new HashMap<String, Set<String>>();
    final Map<String, String> prefs = new HashMap<String, String>();

    Set<String> set(String cat) {
        Set<String> s = sets.get(cat);
        if (s == null) {
            s = new HashSet<String>();
            sets.put(cat, s);
        }
        return s;
    }

    // ------------------------------------------------------------------ taking a snapshot
    static RecSnap take(Context c, String[] names, boolean withClasses) {
        RecSnap s = new RecSnap();
        if (withClasses && names != null) {
            try { scanClasses(c, names, s.classes); } catch (Throwable ignored) { }
        }
        try { services(c, s.set(SVC)); } catch (Throwable ignored) { }
        try { threads(s.set(THR)); } catch (Throwable ignored) { }
        try { libs(c, s.set(LIB)); } catch (Throwable ignored) { }
        try { fds(c, s.set(FD)); } catch (Throwable ignored) { }
        try { windows(s.set(WIN)); } catch (Throwable ignored) { }
        try { vpn(c, s.set(NET)); } catch (Throwable ignored) { }
        try { prefs(c, s.prefs); } catch (Throwable ignored) { }
        return s;
    }

    private static Method findLoaded;

    /** Which of the app's own classes are loaded right now (no class is loaded by this check). */
    private static void scanClasses(Context c, String[] names, BitSet out) throws Exception {
        if (findLoaded == null) {
            findLoaded = ClassLoader.class.getDeclaredMethod("findLoadedClass", String.class);
            findLoaded.setAccessible(true);
        }
        ClassLoader cl = c.getClassLoader();
        for (int i = 0; i < names.length; i++) {
            try {
                if (findLoaded.invoke(cl, names[i]) != null) out.set(i);
            } catch (Throwable ignored) { }
        }
    }

    @SuppressWarnings("deprecation")
    private static void services(Context c, Set<String> out) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> l = am.getRunningServices(200);
        if (l == null) return;
        for (ActivityManager.RunningServiceInfo i : l) {
            if (i.service != null && c.getPackageName().equals(i.service.getPackageName())) out.add(i.service.getClassName());
        }
    }

    private static void threads(Set<String> out) throws Exception {
        File[] t = new File("/proc/self/task").listFiles();
        if (t == null) return;
        for (File d : t) {
            try (BufferedReader r = new BufferedReader(new FileReader(new File(d, "comm")))) {
                String n = r.readLine();
                if (n != null && n.length() > 0) out.add(n.replaceAll("\\d+$", "#"));
            } catch (Exception ignored) { }
        }
    }

    private static void libs(Context c, Set<String> out) throws Exception {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream("/proc/self/maps")))) {
            String line;
            while ((line = r.readLine()) != null) {
                int p = line.lastIndexOf(' ');
                if (p < 0) continue;
                String path = line.substring(p + 1).trim();
                if (!path.endsWith(".so")) continue;
                if (path.startsWith("/system") || path.startsWith("/apex") || path.startsWith("/vendor") || path.startsWith("/product")) continue;
                out.add(path.substring(path.lastIndexOf('/') + 1));
            }
        }
    }

    private static void fds(Context c, Set<String> out) {
        File[] f = new File("/proc/self/fd").listFiles();
        if (f == null) return;
        String data = c.getApplicationInfo().dataDir;
        for (File x : f) {
            try {
                String t = Os.readlink(x.getAbsolutePath());
                if (t == null || !t.startsWith("/")) continue;
                if (t.endsWith(".apk") || t.endsWith(".dex") || t.endsWith(".vdex") || t.endsWith(".odex") || t.endsWith(".oat") || t.endsWith(".art") || t.endsWith(".jar")) continue;
                if (t.startsWith(data) || t.contains("/Android/data/" + c.getPackageName()) || t.startsWith("/data/user/") || t.startsWith("/storage/") || t.startsWith("/sdcard/")) {
                    if (t.endsWith("/recording.json") || t.contains("/fm_rec")) continue;
                    out.add(t.startsWith(data) ? t.substring(data.length()) : t);
                }
            } catch (Throwable ignored) { }
        }
    }

    @SuppressWarnings("unchecked")
    private static void windows(Set<String> out) throws Exception {
        Class<?> g = Class.forName("android.view.WindowManagerGlobal");
        Object inst = g.getMethod("getInstance").invoke(null);
        Field f = g.getDeclaredField("mViews");
        f.setAccessible(true);
        Object v = f.get(inst);
        if (!(v instanceof List)) return;
        for (Object o : new ArrayList<Object>((List<Object>) v)) {
            if (o == null || Rec.isOwnWindow(o)) continue;
            String extra = "";
            if (o instanceof android.view.ViewGroup) extra = ":" + ((android.view.ViewGroup) o).getChildCount();
            out.add(o.getClass().getName() + extra);
        }
    }

    private static void vpn(Context c, Set<String> out) {
        ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        Network[] all = cm.getAllNetworks();
        if (all == null) return;
        for (Network n : all) {
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            if (nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) out.add("vpn:active");
        }
    }

    private static final Pattern ENTRY = Pattern.compile("<(string|int|long|float|boolean)\\s+name=\"([^\"]+)\"(?:\\s+value=\"([^\"]*)\")?\\s*/?>([^<]*)");

    private static void prefs(Context c, Map<String, String> out) throws Exception {
        File dir = new File(c.getApplicationInfo().dataDir, "shared_prefs");
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (!f.getName().endsWith(".xml") || f.length() > 400 * 1024) continue;
            byte[] b = new byte[(int) f.length()];
            try (FileInputStream in = new FileInputStream(f)) {
                int off = 0, r;
                while (off < b.length && (r = in.read(b, off, b.length - off)) > 0) off += r;
            }
            Matcher m = ENTRY.matcher(new String(b, "UTF-8"));
            int n = 0;
            while (m.find() && n++ < 400) {
                String v = m.group(3) != null ? m.group(3) : m.group(4);
                if (v != null && v.length() > 80) v = v.substring(0, 80);
                out.put(f.getName().replace(".xml", "") + "/" + m.group(2), v == null ? "" : v);
            }
        }
    }

    // ------------------------------------------------------------------ comparing two snapshots
    static final class Diff {
        final Map<String, Set<String>> added = new HashMap<String, Set<String>>();
        final Map<String, Set<String>> removed = new HashMap<String, Set<String>>();
        final BitSet newClasses = new BitSet();
        final Map<String, String[]> prefChanged = new HashMap<String, String[]>();

        Set<String> added(String cat) { return get(added, cat); }
        Set<String> removed(String cat) { return get(removed, cat); }

        private static Set<String> get(Map<String, Set<String>> m, String cat) {
            Set<String> s = m.get(cat);
            if (s == null) {
                s = new HashSet<String>();
                m.put(cat, s);
            }
            return s;
        }

        /** Adds what another diff saw appear (used to merge an early and a late look). */
        void addAppeared(Diff o) {
            for (String cat : CATS) added(cat).addAll(o.added(cat));
            newClasses.or(o.newClasses);
            for (Map.Entry<String, String[]> e : o.prefChanged.entrySet()) if (!prefChanged.containsKey(e.getKey())) prefChanged.put(e.getKey(), e.getValue());
        }
    }

    static Diff diff(RecSnap a, RecSnap b) {
        Diff d = new Diff();
        if (a == null) a = new RecSnap();
        BitSet nc = (BitSet) b.classes.clone();
        nc.andNot(a.classes);
        d.newClasses.or(nc);
        for (String cat : CATS) {
            Set<String> x = a.set(cat), y = b.set(cat);
            for (String s : y) if (!x.contains(s)) d.added(cat).add(s);
            for (String s : x) if (!y.contains(s)) d.removed(cat).add(s);
        }
        for (Map.Entry<String, String> e : b.prefs.entrySet()) {
            String old = a.prefs.get(e.getKey());
            if (old == null || !old.equals(e.getValue())) d.prefChanged.put(e.getKey(), new String[]{old == null ? "" : old, e.getValue()});
        }
        for (Map.Entry<String, String> e : a.prefs.entrySet()) {
            if (!b.prefs.containsKey(e.getKey())) d.prefChanged.put(e.getKey(), new String[]{e.getValue(), ""});
        }
        return d;
    }
}
