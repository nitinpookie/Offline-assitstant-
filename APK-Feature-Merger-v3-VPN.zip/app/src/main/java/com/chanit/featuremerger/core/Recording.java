package com.chanit.featuremerger.core;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** A recording sent back by the recorder build of a source app. */
public final class Recording {
    public File dir;
    public String id, pkg, app;
    public long time;
    public final List<Feat> feats = new ArrayList<>();

    public static final class Item {
        public String n;
        public boolean strong, vpn;
    }

    public static final class Pref {
        public String k, on, off;
        public boolean strong;
    }

    public static final class Feat {
        public String name, idName, prevOn, prevOff;
        public int clicks, onCount, offCount, classCount;
        public boolean confirmed;
        public final List<Item> services = new ArrayList<>(), threads = new ArrayList<>(),
                windows = new ArrayList<>(), files = new ArrayList<>(), net = new ArrayList<>();
        public final List<String> libs = new ArrayList<>(), classPkgs = new ArrayList<>();
        public final List<Pref> prefs = new ArrayList<>();

        /** Best service to start for this feature: a strong, non-VPN one first. */
        public Item bestService() {
            Item pick = null;
            for (Item i : services) {
                if (i.vpn) continue;
                if (pick == null || (i.strong && !pick.strong)) pick = i;
            }
            return pick;
        }

        public Item vpnService() {
            for (Item i : services) if (i.vpn) return i;
            return null;
        }
    }

    public static File root(Context c) {
        File r = new File(c.getFilesDir(), "recordings");
        //noinspection ResultOfMethodCallIgnored
        r.mkdirs();
        return r;
    }

    public static List<Recording> list(Context c) {
        List<Recording> out = new ArrayList<>();
        File[] ds = root(c).listFiles();
        if (ds == null) return out;
        Arrays.sort(ds);
        for (File d : ds) {
            try {
                out.add(load(d));
            } catch (Throwable ignored) { }
        }
        Collections.reverse(out);
        return out;
    }

    public File file(String name) { return name == null ? null : new File(dir, name); }

    public void delete() {
        File[] k = dir.listFiles();
        if (k != null) for (File f : k) //noinspection ResultOfMethodCallIgnored
            f.delete();
        //noinspection ResultOfMethodCallIgnored
        dir.delete();
    }

    public static Recording importZip(Context c, InputStream in) throws Exception {
        File d = new File(root(c), String.valueOf(System.currentTimeMillis()));
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        boolean json = false;
        try (ZipInputStream z = new ZipInputStream(in)) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String n = e.getName();
                boolean ok = n.equals("recording.json") || (n.startsWith("prev_") && n.endsWith(".png") && n.indexOf('/') < 0 && !n.contains(".."));
                if (!ok) continue;
                try (FileOutputStream o = new FileOutputStream(new File(d, n))) {
                    byte[] buf = new byte[1 << 14];
                    int r;
                    while ((r = z.read(buf)) > 0) o.write(buf, 0, r);
                }
                if (n.equals("recording.json")) json = true;
            }
        }
        if (!json) {
            Recording tmp = new Recording();
            tmp.dir = d;
            tmp.delete();
            throw new IOException("This file is not a Feature Merger recording");
        }
        return load(d);
    }

    static Recording load(File d) throws Exception {
        byte[] b = new byte[(int) new File(d, "recording.json").length()];
        try (FileInputStream in = new FileInputStream(new File(d, "recording.json"))) {
            int off = 0, r;
            while (off < b.length && (r = in.read(b, off, b.length - off)) > 0) off += r;
        }
        JSONObject o = new JSONObject(new String(b, "UTF-8"));
        Recording rec = new Recording();
        rec.dir = d;
        rec.id = d.getName();
        rec.pkg = o.optString("pkg");
        rec.app = o.optString("app");
        rec.time = o.optLong("time");
        JSONArray fs = o.optJSONArray("features");
        if (fs != null) for (int i = 0; i < fs.length(); i++) {
            JSONObject f = fs.getJSONObject(i);
            Feat x = new Feat();
            x.name = f.optString("name");
            x.idName = f.optString("idName");
            x.clicks = f.optInt("clicks");
            x.onCount = f.optInt("on");
            x.offCount = f.optInt("off");
            x.confirmed = f.optBoolean("confirmed");
            x.classCount = f.optInt("classCount");
            x.prevOn = f.has("prevOn") ? f.optString("prevOn") : null;
            x.prevOff = f.has("prevOff") ? f.optString("prevOff") : null;
            items(f.optJSONArray("services"), x.services);
            items(f.optJSONArray("threads"), x.threads);
            items(f.optJSONArray("windows"), x.windows);
            items(f.optJSONArray("files"), x.files);
            items(f.optJSONArray("net"), x.net);
            strings(f.optJSONArray("libs"), x.libs);
            strings(f.optJSONArray("classPkgs"), x.classPkgs);
            JSONArray pf = f.optJSONArray("prefs");
            if (pf != null) for (int k = 0; k < pf.length(); k++) {
                JSONObject p = pf.getJSONObject(k);
                Pref q = new Pref();
                q.k = p.optString("k");
                q.on = p.optString("on");
                q.off = p.optString("off");
                q.strong = p.optBoolean("strong");
                x.prefs.add(q);
            }
            rec.feats.add(x);
        }
        return rec;
    }

    private static void items(JSONArray a, List<Item> out) throws Exception {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            Item it = new Item();
            it.n = o.optString("n");
            it.strong = o.optBoolean("strong");
            it.vpn = o.optBoolean("vpn");
            out.add(it);
        }
    }

    private static void strings(JSONArray a, List<String> out) throws Exception {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) out.add(a.getString(i));
    }
}
