package com.chanit.featuremerger.core;

import android.content.Context;
import android.os.Build;

import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.MethodImplementation;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction35c;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction3rc;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.android.tools.smali.dexlib2.iface.reference.Reference;
import com.android.tools.smali.dexlib2.iface.reference.StringReference;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction35c;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction3rc;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableMethodReference;
import com.android.tools.smali.dexlib2.rewriter.DexRewriter;
import com.android.tools.smali.dexlib2.rewriter.Rewriter;
import com.android.tools.smali.dexlib2.rewriter.RewriterModule;
import com.android.tools.smali.dexlib2.rewriter.Rewriters;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.Adler32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * "Server transplant": makes a VPN app also work for another game / app (for example Free Fire India when the VPN
 * already supports Free Fire and Free Fire MAX).
 *
 * How: every VpnService.Builder.addAllowedApplication(pkg) call inside the VPN app is redirected to a tiny helper
 * (FmVpn.add). The helper does the original call and, when pkg is one of the reference games, also allows the new
 * package. Package lists stored in plain config files (json arrays, one-per-line lists) get the new package too.
 * If the VPN has no addAllowedApplication call at all, a per-app list is injected instead: every Builder.establish()
 * call goes through the helper, which adds addAllowedApplication(pkg) for the reference games and the new game(s)
 * just before the tunnel starts.
 * Everything else in the VPN app (servers, engine, UI) stays byte for byte the same.
 * The result is written UNSIGNED, on purpose: sign it afterwards (MT Manager).
 */
public final class VpnTransplant {
    private VpnTransplant() {}

    static final String SHIM_PREFIX = "Lcom/chanit/featuremerger/vpnshim/";
    static final String SHIM_TYPE = "Lcom/chanit/featuremerger/vpnshim/FmVpn;";
    static final String BUILDER = "Landroid/net/VpnService$Builder;";
    static final String PFD = "Landroid/os/ParcelFileDescriptor;";
    static final String OPEN = "@FMV{", CLOSE = "}@";
    static final int CFG_LEN = 480;

    private static final Pattern PKG = Pattern.compile("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*){2,}$");
    private static final Pattern TOKEN = Pattern.compile("[a-z][a-z0-9_]*(?:\\.[a-z][a-z0-9_]*){2,}");
    private static final Pattern GAMEISH = Pattern.compile("(?i)freefire|garena|\\.dts\\.|pubg|tencent|activision|codm|supercell|moonton|battlegrounds|krafton");
    private static final String[] NOT_GAME = {"android.", "androidx.", "java.", "javax.", "kotlin.", "org.", "com.google.", "com.android.", "dalvik.", "sun.", "libcore."};
    private static final Set<String> TEXT_EXT = new LinkedHashSet<>(Arrays.asList(
            "json", "txt", "xml", "conf", "cfg", "ini", "list", "properties", "yml", "yaml", "csv", "js"));

    // ------------------------------------------------------------------ data
    public static final class Scan {
        public int dexFiles, allowCalls, disallowCalls, establishCalls, shimCalls, shimEstCalls, shimDisCalls;
        public boolean shimClass;
        public String cfg;
        public String vpnService;
        public final Map<String, Integer> allowByDex = new LinkedHashMap<>();
        public final Map<String, Integer> estByDex = new LinkedHashMap<>();
        public final Map<String, Integer> disByDex = new LinkedHashMap<>();
        public final Set<String> packages = new LinkedHashSet<>();
        public final Map<String, Set<String>> textHits = new LinkedHashMap<>();
        public final List<String> notes = new ArrayList<>();

        public String summary() {
            StringBuilder sb = new StringBuilder();
            sb.append("VPN service: ").append(vpnService == null ? "not declared in manifest" : vpnService).append('\n');
            sb.append("Code files (dex): ").append(dexFiles).append('\n');
            sb.append("Per-app allow calls (addAllowedApplication): ").append(allowCalls).append('\n');
            sb.append("Per-app exclude calls (addDisallowedApplication): ").append(disallowCalls).append('\n');
            sb.append("VPN start calls (establish): ").append(establishCalls).append('\n');
            sb.append("Game packages seen in code/config: ").append(packages.isEmpty() ? "none" : String.valueOf(packages.size())).append('\n');
            sb.append("Config files naming those packages: ").append(textHits.size());
            for (String n : notes) sb.append("\n- ").append(n);
            return sb.toString();
        }
    }

    public static final class Plan {
        public Model.Apk vpn;
        public List<String> targets = new ArrayList<>();
        public Set<String> refs = new LinkedHashSet<>();
        public boolean patchText = true;
        /** VPN without any addAllowedApplication call: add a per-app list (reference games + new games). */
        public boolean injectIfMissing = true;
    }

    public static final class Result {
        public File out;
        public boolean ok;
        public String report = "";
    }

    // ------------------------------------------------------------------ scan
    public static Scan scan(Context ctx, File apk, Merger.Sink s) throws IOException {
        Scan sc = new Scan();
        try (ZipFile zf = new ZipFile(apk)) {
            ZipEntry me = zf.getEntry("AndroidManifest.xml");
            if (me != null) {
                try {
                    Axml mf = Axml.parse(ApkZip.readAll(zf, me));
                    Axml.Elem app = mf.root.child("application");
                    String pkg = mf.root.plain("package") == null ? "" : mf.root.plain("package").text();
                    if (app != null) {
                        for (Axml.Elem k : app.kids) {
                            if (!"service".equals(k.name)) continue;
                            if ("android.permission.BIND_VPN_SERVICE".equals(k.text("permission"))) {
                                String n = k.text("name");
                                if (n != null && n.startsWith(".")) n = pkg + n;
                                sc.vpnService = n;
                            }
                        }
                    }
                } catch (Exception e) {
                    sc.notes.add("Manifest not readable: " + e.getMessage());
                }
            }
            List<String> dexNames = dexNames(zf);
            sc.dexFiles = dexNames.size();
            int i = 0;
            for (String dn : dexNames) {
                s.log("Scanning " + dn);
                File tmp = new File(ctx.getCacheDir(), "vt_scan_" + (i++) + ".dex");
                try {
                    extract(zf, dn, tmp);
                    DexFile df = DexFileFactory.loadDexFile(tmp, Opcodes.getDefault());
                    scanDex(df, sc, dn, true);
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                }
            }
            // config / asset files that name game packages
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory() || !isTextCandidate(e)) continue;
                String txt = readText(zf, e);
                if (txt == null) continue;
                Matcher m = TOKEN.matcher(txt);
                Set<String> hit = new LinkedHashSet<>();
                while (m.find()) {
                    String t = m.group();
                    if (isGameish(t) || sc.packages.contains(t)) hit.add(t);
                }
                if (!hit.isEmpty()) {
                    sc.textHits.put(e.getName(), hit);
                    for (String h : hit) if (isGameish(h) && sc.packages.size() < 80) sc.packages.add(h);
                }
            }
        }
        if (sc.vpnService == null) sc.notes.add("No VPN service found in the manifest: this may not be a VPN app.");
        boolean patched = sc.shimCalls > 0 || sc.shimEstCalls > 0 || sc.shimDisCalls > 0;
        if (patched)
            sc.notes.add("This APK was already patched by Feature Merger. Patch the ORIGINAL VPN APK again instead, so the lists do not get mixed.");
        if (!patched && sc.allowCalls == 0 && sc.disallowCalls > 0)
            sc.notes.add("This VPN only EXCLUDES apps, so every other app (also the new game) is already routed through it."
                    + (sc.establishCalls > 0 ? " Switch \"Add a per-app list if missing\" ON to make it route only the chosen games (the exclude calls are then switched off, Android does not allow both lists)." : ""));
        if (!patched && sc.allowCalls == 0 && sc.disallowCalls == 0 && sc.establishCalls > 0)
            sc.notes.add("This VPN has no addAllowedApplication call, so it routes all apps. Switch \"Add a per-app list if missing\" ON to inject one: "
                    + "the VPN then routes only the ticked games + the new game. Games that are not listed below can be typed in \"Extra package names\".");
        if (!patched && sc.allowCalls == 0 && sc.establishCalls == 0)
            sc.notes.add("No VPN code found in the dex (it may be packed or loaded later).");
        return sc;
    }

    private static boolean isGameish(String t) {
        for (String p : NOT_GAME) if (t.startsWith(p)) return false;
        return GAMEISH.matcher(t).find();
    }

    private static void scanDex(DexFile df, Scan sc, String dexName, boolean collect) {
        int allow = 0, est = 0, dis = 0;
        for (ClassDef cd : df.getClasses()) {
            boolean shim = SHIM_TYPE.equals(cd.getType());
            if (shim) sc.shimClass = true;
            for (Method m : cd.getMethods()) {
                MethodImplementation mi = m.getImplementation();
                if (mi == null) continue;
                boolean uses = false;
                List<String> strs = null;
                for (Instruction ins : mi.getInstructions()) {
                    if (!(ins instanceof ReferenceInstruction)) continue;
                    Reference r = ((ReferenceInstruction) ins).getReference();
                    if (r instanceof MethodReference) {
                        // the helper's own calls into the VPN API are not calls of the VPN app
                        if (shim) continue;
                        MethodReference mr = (MethodReference) r;
                        String dc = mr.getDefiningClass();
                        String nm = mr.getName();
                        if (BUILDER.equals(dc)) {
                            if ("addAllowedApplication".equals(nm)) {
                                sc.allowCalls++;
                                allow++;
                                uses = true;
                            } else if ("addDisallowedApplication".equals(nm)) {
                                sc.disallowCalls++;
                                dis++;
                                uses = true;
                            } else if ("establish".equals(nm)) {
                                sc.establishCalls++;
                                est++;
                            }
                        } else if (SHIM_TYPE.equals(dc)) {
                            if ("add".equals(nm)) sc.shimCalls++;
                            else if ("establish".equals(nm)) sc.shimEstCalls++;
                            else if ("dis".equals(nm)) sc.shimDisCalls++;
                        }
                    } else if (r instanceof StringReference) {
                        String str = ((StringReference) r).getString();
                        if (shim && str.startsWith(OPEN)) {
                            sc.cfg = str;
                        } else if (collect && str.length() <= 80 && PKG.matcher(str).matches()) {
                            boolean skip = false;
                            for (String p : NOT_GAME) if (str.startsWith(p)) { skip = true; break; }
                            if (!skip) {
                                if (strs == null) strs = new ArrayList<>();
                                strs.add(str);
                            }
                        }
                    }
                }
                if (strs != null) {
                    for (String x : strs) {
                        if ((uses || GAMEISH.matcher(x).find()) && sc.packages.size() < 80) sc.packages.add(x);
                    }
                }
            }
        }
        if (allow > 0) sc.allowByDex.put(dexName, allow);
        if (est > 0) sc.estByDex.put(dexName, est);
        if (dis > 0) sc.disByDex.put(dexName, dis);
    }

    // ------------------------------------------------------------------ run
    public static Result run(Context ctx, Plan plan, Merger.Sink s) throws Exception {
        Result res = new Result();
        StringBuilder rp = new StringBuilder();
        header(rp, ctx, plan);
        File work = new File(ctx.getCacheDir(), "vpnt");
        deleteTree(work);
        //noinspection ResultOfMethodCallIgnored
        work.mkdirs();
        File src = new File(plan.vpn.path);
        if (plan.targets.isEmpty()) throw new IOException("No target package given.");

        s.step(5, "Scanning VPN app");
        Scan sc = scan(ctx, src, s);
        rp.append("\n[SCAN]\n").append(sc.summary()).append('\n');
        if (!sc.allowByDex.isEmpty()) rp.append("Allow calls per dex: ").append(sc.allowByDex).append('\n');

        // ---------- text / config edits
        Map<String, byte[]> repBytes = new LinkedHashMap<>();
        List<String> textDone = new ArrayList<>(), textManual = new ArrayList<>();
        if (plan.patchText && !sc.textHits.isEmpty()) {
            s.step(20, "Patching package lists in config files");
            Set<String> refSet = new LinkedHashSet<>(plan.refs);
            if (refSet.isEmpty()) for (Set<String> v : sc.textHits.values()) refSet.addAll(v);
            try (ZipFile zf = new ZipFile(src)) {
                for (Map.Entry<String, Set<String>> e : sc.textHits.entrySet()) {
                    ZipEntry ze = zf.getEntry(e.getKey());
                    String txt = ze == null ? null : readText(zf, ze);
                    if (txt == null) continue;
                    Set<String> use = new LinkedHashSet<>();
                    for (String h : e.getValue()) if (refSet.contains(h)) use.add(h);
                    if (use.isEmpty()) continue;
                    int[] cnt = {0};
                    String nt = patchText(txt, use, plan.targets, cnt);
                    if (cnt[0] > 0 && !nt.equals(txt)) {
                        repBytes.put(e.getKey(), nt.getBytes(StandardCharsets.UTF_8));
                        textDone.add(e.getKey() + " (" + cnt[0] + " place" + (cnt[0] == 1 ? "" : "s") + ")");
                        s.log("Config patched: " + e.getKey());
                    } else {
                        boolean already = true;
                        for (String t : plan.targets) if (!txt.contains(t)) already = false;
                        if (!already) textManual.add(e.getKey() + " names " + use + " in a format that is not a plain list");
                    }
                }
            }
        }

        // no per-app list at all: add one (only when the VPN is not already patched and really starts a tunnel)
        final boolean inject = plan.injectIfMissing && sc.allowCalls == 0
                && sc.shimCalls == 0 && sc.shimEstCalls == 0 && sc.shimDisCalls == 0 && sc.establishCalls > 0;
        if (inject) rp.append("Mode: the VPN has no addAllowedApplication call, so a per-app list is added.\n");

        if (sc.allowCalls == 0 && repBytes.isEmpty() && !inject) {
            rp.append("\n[RESULT] NOTHING TO PATCH\n");
            for (String n : sc.notes) rp.append("- ").append(n).append('\n');
            if (!textManual.isEmpty()) {
                rp.append("Needs manual edit:\n");
                for (String t : textManual) rp.append("- ").append(t).append('\n');
            }
            res.report = rp.toString();
            res.ok = false;
            return res;
        }

        // ---------- dex rewrite
        Map<String, File> repFiles = new LinkedHashMap<>();
        Map<String, Integer> todo = new LinkedHashMap<>();
        if (inject) {
            for (Map.Entry<String, Integer> e : sc.estByDex.entrySet()) todo.put(e.getKey(), e.getValue());
            for (Map.Entry<String, Integer> e : sc.disByDex.entrySet()) {
                Integer have = todo.get(e.getKey());
                todo.put(e.getKey(), (have == null ? 0 : have) + e.getValue());
            }
        } else {
            todo.putAll(sc.allowByDex);
        }
        List<String> dexNames;
        try (ZipFile zf = new ZipFile(src)) {
            dexNames = dexNames(zf);
            int idx = 0;
            int total = Math.max(1, todo.size());
            for (String dn : dexNames) {
                Integer c = todo.get(dn);
                if (c == null || c == 0) continue;
                s.step(30 + 30 * idx / total, "Rewriting " + dn + " (" + c + " call" + (c == 1 ? "" : "s") + ")");
                File in = new File(work, "in_" + idx + ".dex");
                File out = new File(work, "out_" + idx + ".dex");
                extract(zf, dn, in);
                rewriteDex(in, out, inject);
                //noinspection ResultOfMethodCallIgnored
                in.delete();
                repFiles.put(dn, out);
                idx++;
            }
        }

        // ---------- helper dex
        File shim = null;
        if (!repFiles.isEmpty()) {
            s.step(62, "Building helper code");
            String payload = join(plan.refs) + ";" + join(plan.targets) + (inject ? ";I" : "");
            if (payload.length() > CFG_LEN) throw new IOException("Package list too long (" + payload.length() + " > " + CFG_LEN + ").");
            File raw = new File(work, "shim_raw.dex");
            int n = BridgeDex.extract(ctx, raw, SHIM_PREFIX);
            s.log("Helper: " + n + " class(es)");
            byte[] bytes = ApkZip.readFile(raw);
            patchCfg(bytes, payload);
            File patched = new File(work, "shim_patched.dex");
            try (FileOutputStream o = new FileOutputStream(patched)) { o.write(bytes); }
            DexFile hf = DexFileFactory.loadDexFile(patched, Opcodes.getDefault());
            DexPool pool = new DexPool(Opcodes.forApi(23));
            for (ClassDef cd : hf.getClasses()) pool.internClass(cd);
            shim = new File(work, "shim.dex");
            pool.writeTo(new FileDataStore(shim));
        }

        // ---------- write the (unsigned) apk
        s.step(72, "Writing patched APK (unsigned)");
        File outDir = ctx.getExternalFilesDir("Output");
        if (outDir == null) outDir = new File(ctx.getFilesDir(), "Output");
        //noinspection ResultOfMethodCallIgnored
        outDir.mkdirs();
        String tag = plan.targets.get(0).replaceAll("[^A-Za-z0-9._-]", "_");
        String safe = plan.vpn.label.replaceAll("[^A-Za-z0-9._-]", "_");
        File out = new File(outDir, safe + "_+" + tag + "_UNSIGNED.apk");
        try (ApkZip.Writer w = new ApkZip.Writer(out)) {
            w.copy(src, repBytes, repFiles, true);
            if (shim != null) w.put("classes" + (dexNames.size() + 1) + ".dex", ApkZip.readFile(shim), false);
        }
        rp.append("\n[PATCH]\n");
        rp.append("Targets added: ").append(plan.targets).append('\n');
        if (inject) {
            rp.append("Games the VPN will route (added per-app list): ").append(plan.refs).append(" + ").append(plan.targets).append('\n');
            if (plan.refs.isEmpty())
                rp.append("WARN  No existing game was ticked: ONLY the new game(s) will go through the VPN. Type the old games in \"Extra package names\" if they must stay.\n");
            rp.append("Dex files rewritten: ").append(repFiles.keySet()).append('\n');
            rp.append("VPN start calls (establish) redirected: ").append(sc.establishCalls).append('\n');
            if (sc.disallowCalls > 0)
                rp.append("Exclude calls (addDisallowedApplication) switched off: ").append(sc.disallowCalls).append(" (Android cannot mix them with an allow list)\n");
        } else {
            rp.append("Reference games: ").append(plan.refs.isEmpty() ? "(all allow calls)" : plan.refs.toString()).append('\n');
            rp.append("Dex files rewritten: ").append(repFiles.keySet()).append('\n');
            rp.append("Allow calls redirected: ").append(sc.allowCalls).append('\n');
        }
        rp.append("Config files patched: ").append(textDone.isEmpty() ? "none" : textDone.toString()).append('\n');
        for (String t : textManual) rp.append("Manual: ").append(t).append('\n');

        // ---------- verify
        s.step(88, "Scanning the new APK");
        List<String> fails = new ArrayList<>();
        rp.append("\n[VERIFY]\n");
        verify(ctx, out, plan, sc, repFiles.keySet(), textDone, rp, fails, inject);

        deleteTree(work);
        res.ok = fails.isEmpty();
        res.out = out;
        rp.append('\n').append(res.ok ? (inject ? "[RESULT] OK - the VPN now routes only " + plan.refs + " + " + plan.targets
                : "[RESULT] OK - the VPN now also allows " + plan.targets)
                : "[RESULT] FAILED (" + fails.size() + " check(s)). Copy this report and send it to Claude.").append('\n');
        if (res.ok) rp.append("Next: sign this APK with MT Manager, uninstall the old VPN app, install the signed one.\n");
        res.report = rp.toString();
        s.step(100, res.ok ? "Done" : "Done, with problems");
        return res;
    }

    // ------------------------------------------------------------------ verify
    private static void verify(Context ctx, File out, Plan plan, Scan before, Set<String> rewritten,
                               List<String> textDone, StringBuilder rp, List<String> fails, boolean inject) {
        try (ZipFile zf = new ZipFile(out)) {
            boolean signed = false;
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); )
                if (ApkZip.isSignature(en.nextElement().getName())) signed = true;
            check(rp, fails, !signed, "APK is unsigned (sign it with MT Manager)", "APK still carries old signature files");

            ZipEntry me = zf.getEntry("AndroidManifest.xml");
            boolean mfOk = false;
            try {
                Axml mf = Axml.parse(ApkZip.readAll(zf, me));
                mfOk = plan.vpn.pkg == null || plan.vpn.pkg.equals(mf.root.plain("package").text());
            } catch (Exception ignored) { }
            check(rp, fails, mfOk, "Manifest readable, package unchanged (" + plan.vpn.pkg + ")", "Manifest unreadable or package changed");

            Scan after = new Scan();
            int idx = 0;
            for (String dn : dexNames(zf)) {
                File tmp = new File(ctx.getCacheDir(), "vt_chk_" + (idx++) + ".dex");
                try {
                    extract(zf, dn, tmp);
                    boolean sumOk = checksumOk(tmp);
                    if (!sumOk) check(rp, fails, false, "", dn + ": dex checksum wrong");
                    DexFile df = DexFileFactory.loadDexFile(tmp, Opcodes.getDefault());
                    scanDex(df, after, dn, false);
                } catch (Throwable t) {
                    check(rp, fails, false, "", dn + ": cannot be read back (" + t + ")");
                } finally {
                    //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
                }
            }
            if (!inject && before.allowCalls > 0) {
                check(rp, fails, after.allowCalls == 0,
                        "No direct addAllowedApplication call is left (all " + before.allowCalls + " go through the helper)",
                        after.allowCalls + " direct addAllowedApplication call(s) are still left");
                check(rp, fails, after.shimCalls == before.allowCalls,
                        "Helper is called from " + after.shimCalls + " place(s)",
                        "Helper is called from " + after.shimCalls + " place(s), expected " + before.allowCalls);
            }
            if (inject) {
                check(rp, fails, after.establishCalls == 0,
                        "No direct establish() call is left (all " + before.establishCalls + " go through the helper)",
                        after.establishCalls + " direct establish() call(s) are still left");
                check(rp, fails, after.shimEstCalls == before.establishCalls,
                        "Helper starts the tunnel from " + after.shimEstCalls + " place(s)",
                        "Helper starts the tunnel from " + after.shimEstCalls + " place(s), expected " + before.establishCalls);
                if (before.disallowCalls > 0) {
                    check(rp, fails, after.disallowCalls == 0,
                            "Exclude calls are switched off (" + before.disallowCalls + ")",
                            after.disallowCalls + " exclude call(s) are still left (the VPN would crash on start)");
                    check(rp, fails, after.shimDisCalls == before.disallowCalls,
                            "Exclude calls go to the helper from " + after.shimDisCalls + " place(s)",
                            "Exclude calls go to the helper from " + after.shimDisCalls + " place(s), expected " + before.disallowCalls);
                }
            }
            if (!rewritten.isEmpty()) {
                check(rp, fails, after.shimClass, "Helper class is inside the APK", "Helper class FmVpn is missing");
                if (after.cfg != null) {
                    String body = after.cfg.substring(OPEN.length(), Math.max(OPEN.length(), after.cfg.lastIndexOf('}'))).replace("#", "").trim();
                    String[] part = body.split(";", -1);
                    List<String> gotT = part.length > 1 ? Arrays.asList(part[1].split(",")) : Collections.<String>emptyList();
                    List<String> gotR = part.length > 0 && part[0].length() > 0 ? Arrays.asList(part[0].split(",")) : Collections.<String>emptyList();
                    check(rp, fails, gotT.containsAll(plan.targets),
                            "Helper allows: " + plan.targets, "Helper list is " + gotT + ", expected " + plan.targets);
                    check(rp, fails, new LinkedHashSet<>(gotR).equals(new LinkedHashSet<>(plan.refs)),
                            "Helper reference games: " + (gotR.isEmpty() ? "(all)" : gotR.toString()),
                            "Helper reference list is " + gotR + ", expected " + plan.refs);
                    if (inject)
                        check(rp, fails, part.length > 2 && "I".equals(part[2].trim()),
                                "Helper is in add-a-list mode", "Helper add-a-list flag is missing");
                } else {
                    check(rp, fails, false, "", "Helper settings text not found");
                }
            }
            for (String t : textDone) {
                String name = t.substring(0, t.indexOf(" ("));
                ZipEntry ze = zf.getEntry(name);
                String txt = ze == null ? null : readText(zf, ze);
                boolean ok = txt != null;
                if (ok) for (String tg : plan.targets) if (!txt.contains(tg)) ok = false;
                check(rp, fails, ok, "Config " + name + " now lists " + plan.targets, "Config " + name + " does not contain the new package");
            }
            try {
                android.content.pm.PackageInfo pi = ctx.getPackageManager().getPackageArchiveInfo(out.getAbsolutePath(), 0);
                rp.append(pi != null ? "PASS  Android can read the manifest\n" : "WARN  Android could not read the unsigned APK here (normal on some phones)\n");
            } catch (Throwable ignored) { }
        } catch (Throwable t) {
            fails.add("verify crashed");
            rp.append("FAIL  verification crashed: ").append(t).append('\n');
        }
    }

    private static void check(StringBuilder rp, List<String> fails, boolean ok, String pass, String fail) {
        if (ok) {
            if (pass.length() > 0) rp.append("PASS  ").append(pass).append('\n');
        } else {
            fails.add(fail);
            rp.append("FAIL  ").append(fail).append('\n');
        }
    }

    private static boolean checksumOk(File f) throws IOException {
        byte[] b = ApkZip.readFile(f);
        if (b.length < 40) return false;
        Adler32 ad = new Adler32();
        ad.update(b, 12, b.length - 12);
        long v = ad.getValue();
        long have = (b[8] & 0xffL) | ((b[9] & 0xffL) << 8) | ((b[10] & 0xffL) << 16) | ((b[11] & 0xffL) << 24);
        return v == have;
    }

    // ------------------------------------------------------------------ dex rewrite
    private static void rewriteDex(File in, File out, final boolean inject) throws IOException {
        DexFile df = DexFileFactory.loadDexFile(in, Opcodes.getDefault());
        DexRewriter rw = new DexRewriter(new RewriterModule() {
            @Override public Rewriter<Instruction> getInstructionRewriter(Rewriters rewriters) {
                return ins -> {
                    Instruction x = swap(ins, inject);
                    return x != null ? x : ins;
                };
            }
        });
        DexFile done = rw.getDexFileRewriter().rewrite(df);
        DexPool pool = new DexPool(df.getOpcodes());
        for (ClassDef cd : done.getClasses()) pool.internClass(cd);
        pool.writeTo(new FileDataStore(out));
    }

    /**
     * Mode 1: Builder.addAllowedApplication(pkg) -> FmVpn.add(builder, pkg).
     * Mode 2 (inject): Builder.establish() -> FmVpn.establish(builder), Builder.addDisallowedApplication(pkg) -> FmVpn.dis(builder, pkg).
     * The register layout stays the same, only invoke-virtual becomes invoke-static.
     */
    private static Instruction swap(Instruction i, boolean inject) {
        if (!(i instanceof ReferenceInstruction)) return null;
        Reference r = ((ReferenceInstruction) i).getReference();
        if (!(r instanceof MethodReference)) return null;
        MethodReference mr = (MethodReference) r;
        if (!BUILDER.equals(mr.getDefiningClass())) return null;
        String name = mr.getName();
        MethodReference nr;
        if (!inject && "addAllowedApplication".equals(name)) {
            nr = new ImmutableMethodReference(SHIM_TYPE, "add",
                    Arrays.asList(BUILDER, "Ljava/lang/String;"), BUILDER);
        } else if (inject && "establish".equals(name)) {
            nr = new ImmutableMethodReference(SHIM_TYPE, "establish",
                    Arrays.asList(BUILDER), PFD);
        } else if (inject && "addDisallowedApplication".equals(name)) {
            nr = new ImmutableMethodReference(SHIM_TYPE, "dis",
                    Arrays.asList(BUILDER, "Ljava/lang/String;"), BUILDER);
        } else {
            return null;
        }
        Opcode op = i.getOpcode();
        if (op == Opcode.INVOKE_VIRTUAL && i instanceof Instruction35c) {
            Instruction35c c = (Instruction35c) i;
            return new ImmutableInstruction35c(Opcode.INVOKE_STATIC, c.getRegisterCount(), c.getRegisterC(),
                    c.getRegisterD(), c.getRegisterE(), c.getRegisterF(), c.getRegisterG(), nr);
        }
        if (op == Opcode.INVOKE_VIRTUAL_RANGE && i instanceof Instruction3rc) {
            Instruction3rc c = (Instruction3rc) i;
            return new ImmutableInstruction3rc(Opcode.INVOKE_STATIC_RANGE, c.getStartRegister(), c.getRegisterCount(), nr);
        }
        return null;
    }

    /** Writes "refs;targets" (or "refs;targets;I") into the placeholder text of the helper dex (same length) and fixes the dex header. */
    private static void patchCfg(byte[] dex, String payload) throws Exception {
        StringBuilder mk = new StringBuilder(OPEN);
        for (int i = 0; i < CFG_LEN; i++) mk.append('#');
        mk.append(CLOSE);
        byte[] mark = mk.toString().getBytes(StandardCharsets.US_ASCII);
        int at = -1, found = 0;
        for (int i = 0; i + mark.length <= dex.length; i++) {
            if (dex[i] != mark[0]) continue;
            boolean eq = true;
            for (int k = 1; k < mark.length; k++) if (dex[i + k] != mark[k]) { eq = false; break; }
            if (eq) {
                if (at < 0) at = i;
                found++;
            }
        }
        if (at < 0) throw new IOException("Helper settings text not found inside the helper dex");
        if (found != 1) throw new IOException("Helper settings text found " + found + " times");
        StringBuilder nw = new StringBuilder(OPEN).append(payload);
        while (nw.length() < OPEN.length() + CFG_LEN) nw.append('#');
        nw.append(CLOSE);
        byte[] nb = nw.toString().getBytes(StandardCharsets.US_ASCII);
        if (nb.length != mark.length) throw new IOException("Helper settings length mismatch");
        System.arraycopy(nb, 0, dex, at, nb.length);
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        md.update(dex, 32, dex.length - 32);
        System.arraycopy(md.digest(), 0, dex, 12, 20);
        Adler32 ad = new Adler32();
        ad.update(dex, 12, dex.length - 12);
        long v = ad.getValue();
        dex[8] = (byte) v;
        dex[9] = (byte) (v >> 8);
        dex[10] = (byte) (v >> 16);
        dex[11] = (byte) (v >> 24);
    }

    // ------------------------------------------------------------------ config patching
    static String patchText(String text, Set<String> refs, List<String> targets, int[] count) {
        String out = text;
        for (String ref : refs) {
            for (String q : new String[]{"\"", "'"}) {
                Matcher m = Pattern.compile(Pattern.quote(q + ref + q)).matcher(out);
                StringBuilder sb = new StringBuilder();
                int last = 0;
                boolean any = false;
                while (m.find()) {
                    if (!arrayElement(out, m.start(), m.end())) continue;
                    StringBuilder add = new StringBuilder();
                    for (String t : targets) if (!out.contains(q + t + q)) add.append(',').append(q).append(t).append(q);
                    if (add.length() == 0) continue;
                    sb.append(out, last, m.end()).append(add);
                    last = m.end();
                    count[0]++;
                    any = true;
                }
                if (any) {
                    sb.append(out, last, out.length());
                    out = sb.toString();
                }
            }
        }
        // plain list: one package per line
        String[] lines = out.split("\n", -1);
        boolean list = false;
        for (String l : lines) {
            String t = l.trim();
            if (t.length() > 0 && PKG.matcher(t).matches()) { list = true; break; }
        }
        if (list) {
            boolean allPlain = true;
            for (String l : lines) {
                String t = l.trim();
                if (t.length() > 0 && !PKG.matcher(t).matches() && !t.startsWith("#")) { allPlain = false; break; }
            }
            if (allPlain) {
                StringBuilder sb = new StringBuilder();
                boolean changed = false;
                Set<String> added = new LinkedHashSet<>();
                for (int i = 0; i < lines.length; i++) {
                    sb.append(lines[i]);
                    if (i < lines.length - 1) sb.append('\n');
                    String t = lines[i].trim();
                    if (refs.contains(t)) {
                        for (String tg : targets) {
                            if (out.contains(tg) || !added.add(tg)) continue;
                            sb.append(tg).append('\n');
                            count[0]++;
                            changed = true;
                        }
                    }
                }
                if (changed) out = sb.toString();
            }
        }
        return out;
    }

    private static boolean arrayElement(String s, int start, int end) {
        int p = start - 1;
        while (p >= 0 && Character.isWhitespace(s.charAt(p))) p--;
        int n = end;
        while (n < s.length() && Character.isWhitespace(s.charAt(n))) n++;
        if (p < 0 || n >= s.length()) return false;
        char a = s.charAt(p), b = s.charAt(n);
        return (a == '[' || a == ',') && (b == ',' || b == ']');
    }

    // ------------------------------------------------------------------ helpers
    private static boolean isTextCandidate(ZipEntry e) {
        String n = e.getName();
        if (!(n.startsWith("assets/") || n.startsWith("res/raw"))) return false;
        if (e.getSize() > 2 * 1024 * 1024) return false;
        int d = n.lastIndexOf('.');
        String ext = d < 0 ? "" : n.substring(d + 1).toLowerCase(Locale.US);
        if (!TEXT_EXT.contains(ext)) return false;
        return true;
    }

    private static String readText(ZipFile zf, ZipEntry e) {
        try {
            byte[] b = ApkZip.readAll(zf, e);
            int bin = 0;
            for (int i = 0; i < Math.min(b.length, 512); i++) if (b[i] == 0) bin++;
            if (bin > 0) return null;
            return new String(b, StandardCharsets.UTF_8);
        } catch (Exception ex) {
            return null;
        }
    }

    private static List<String> dexNames(ZipFile zf) {
        final List<String> names = new ArrayList<>();
        for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
            String n = en.nextElement().getName();
            if (n.matches("classes\\d*\\.dex")) names.add(n);
        }
        Collections.sort(names, (x, y) -> Integer.compare(dexNo(x), dexNo(y)));
        return names;
    }

    private static int dexNo(String n) {
        String d = n.substring("classes".length(), n.length() - ".dex".length());
        return d.isEmpty() ? 1 : Integer.parseInt(d);
    }

    private static void extract(ZipFile zf, String name, File to) throws IOException {
        try (InputStream in = zf.getInputStream(zf.getEntry(name)); FileOutputStream o = new FileOutputStream(to)) {
            byte[] buf = new byte[1 << 16];
            int r;
            while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
        }
    }

    private static String join(java.util.Collection<String> c) {
        StringBuilder sb = new StringBuilder();
        for (String s : c) {
            if (sb.length() > 0) sb.append(',');
            sb.append(s);
        }
        return sb.toString();
    }

    private static void header(StringBuilder rp, Context ctx, Plan plan) {
        rp.append("Feature Merger - VPN transplant report\n");
        rp.append("Phone: Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT)
                .append("), ").append(Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "?").append('\n');
        rp.append("VPN app: ").append(plan.vpn.label).append(" (").append(plan.vpn.pkg).append(", v").append(plan.vpn.versionName).append(")\n");
        rp.append("Add support for: ").append(plan.targets).append('\n');
        rp.append("Add a per-app list if missing: ").append(plan.injectIfMissing ? "on" : "off").append('\n');
    }

    /** Report for a run that crashed before it could write its own report. */
    public static String errorReport(Context ctx, Plan plan, Throwable t) {
        StringBuilder rp = new StringBuilder();
        header(rp, ctx, plan);
        rp.append("\n[RESULT] CRASHED\n").append(t).append('\n');
        int n = 0;
        for (StackTraceElement e : t.getStackTrace()) {
            rp.append("   at ").append(e).append('\n');
            if (++n >= 14) break;
        }
        Throwable c = t.getCause();
        if (c != null) rp.append("Caused by: ").append(c).append('\n');
        return rp.toString();
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] k = f.listFiles();
        if (k != null) for (File c : k) deleteTree(c);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
