package com.chanit.featuremerger.rec;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Added to the recorder build of the source app. Android creates it at process start, which boots the
 * recorder. It also hands the finished recording zip to Feature Merger (read-only, via a granted Uri).
 */
public class RecProvider extends ContentProvider {
    @Override public boolean onCreate() {
        try {
            Rec.init(getContext());
        } catch (Throwable t) {
            android.util.Log.e(Rec.TAG, "init failed", t);
        }
        return true;
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        try {
            File dir = Rec.dir();
            File f = new File(dir, uri.getLastPathSegment());
            if (!f.getCanonicalPath().startsWith(dir.getCanonicalPath() + File.separator)) throw new FileNotFoundException("bad path");
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (FileNotFoundException e) {
            throw e;
        } catch (Exception e) {
            throw new FileNotFoundException(String.valueOf(e));
        }
    }

    @Override public String getType(Uri u) { return "application/zip"; }
    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
