package com.chanit.featuremerger;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.chanit.featuremerger.core.Merger;
import com.chanit.featuremerger.core.Model;
import com.chanit.featuremerger.core.Recording;
import com.chanit.featuremerger.core.RecorderBuilder;
import com.chanit.featuremerger.core.Store;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Record mode. Step 1: build a recorder copy of a source app. Step 2: run it, tap the switches, send the
 * recording back (this activity receives it). Step 3: use a recorded feature in a merge.
 */
public class RecordActivity extends AppCompatActivity {
    public static final String EXTRA_APK = "apk";
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Store store;
    private LinearLayout page, appsBox, builtBox, recBox;
    private LinearLayout.LayoutParams lpFull;
    private LinearProgressIndicator bar;
    private TextView status;
    private File built;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(20), dp(16), dp(32));
        sv.addView(page);
        setContentView(sv);
        lpFull = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        page.addView(text("Record a feature", 22, true));
        page.addView(text("1. Pick the app you want to take a feature from and build its recorder copy.\n"
                + "2. Uninstall the original, install the recorder copy, open it and allow \"Display over other apps\".\n"
                + "3. Use the app's own switches / buttons. Tap each one 3 times (ON, OFF, ON), 5 seconds apart.\n"
                + "4. Press \"Send to FM\" in the floating panel. The recording shows up below.", 13, false));

        page.addView(text("Apps", 16, true));
        appsBox = box();
        page.addView(appsBox);

        bar = new LinearProgressIndicator(this);
        bar.setMax(100);
        bar.setVisibility(View.GONE);
        page.addView(bar, lpFull);
        status = text("", 12, false);
        page.addView(status);
        builtBox = box();
        page.addView(builtBox);

        page.addView(text("Recordings", 16, true));
        recBox = box();
        page.addView(recBox);

        renderApps();
        renderRecordings();
        handle(getIntent());
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handle(i);
    }

    // ------------------------------------------------------------------ incoming recording
    private void handle(Intent i) {
        if (i == null || !Intent.ACTION_SEND.equals(i.getAction())) return;
        final Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u == null) return;
        i.setAction(null);
        exec.execute(() -> {
            try (InputStream in = getContentResolver().openInputStream(u)) {
                Recording r = Recording.importZip(this, in);
                ui.post(() -> {
                    Toast.makeText(this, "Recording received: " + r.feats.size() + " feature(s)", Toast.LENGTH_LONG).show();
                    renderRecordings();
                });
            } catch (Throwable t) {
                ui.post(() -> Toast.makeText(this, "Import failed: " + t, Toast.LENGTH_LONG).show());
            }
        });
    }

    // ------------------------------------------------------------------ step 1: apps
    private void renderApps() {
        appsBox.removeAllViews();
        int n = 0;
        for (File f : store.listApks()) {
            final Model.Apk a = store.loadCached(f);
            if (a == null) continue;
            n++;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, dp(6), 0, dp(6));
            TextView t = text(a.label + "\n" + a.pkg, 13, false);
            row.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            MaterialButton bt = new MaterialButton(this);
            bt.setText("Build recorder");
            bt.setOnClickListener(v -> buildRecorder(a));
            row.addView(bt);
            appsBox.addView(row, lpFull);
        }
        if (n == 0) appsBox.addView(text("No apps yet. Add the source APK in the Apps tab first.", 13, false));
    }

    private void buildRecorder(Model.Apk a) {
        bar.setVisibility(View.VISIBLE);
        bar.setProgress(0);
        builtBox.removeAllViews();
        built = null;
        exec.execute(() -> {
            try {
                File out = RecorderBuilder.build(this, a, new Merger.Sink() {
                    @Override public void step(int pct, String msg) {
                        ui.post(() -> {
                            bar.setProgress(pct);
                            status.setText(msg);
                        });
                    }

                    @Override public void log(String line) { }
                });
                built = out;
                ui.post(() -> {
                    bar.setVisibility(View.GONE);
                    status.setText("Recorder ready: " + out.getName() + "\nUninstall the original " + a.pkg + " first, then install this one.");
                    builtBox.addView(buttons(
                            btn("Install", v -> install()),
                            btn("Share", v -> share())));
                });
            } catch (Throwable t) {
                ui.post(() -> {
                    bar.setVisibility(View.GONE);
                    status.setText("Could not build the recorder: " + t);
                });
            }
        });
    }

    private Uri uri() {
        return FileProvider.getUriForFile(this, getPackageName() + ".files", built);
    }

    private void install() {
        if (built == null) return;
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Allow installs from this app, then tap Install again", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            return;
        }
        startActivity(new Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri(), "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    private void share() {
        if (built == null) return;
        Intent i = new Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive")
                .putExtra(Intent.EXTRA_STREAM, uri()).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share recorder APK"));
    }

    // ------------------------------------------------------------------ step 3: recordings
    private void renderRecordings() {
        recBox.removeAllViews();
        List<Recording> all = Recording.list(this);
        if (all.isEmpty()) {
            recBox.addView(text("Nothing recorded yet.", 13, false));
            return;
        }
        String when;
        for (final Recording r : all) {
            when = new SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(new Date(r.time));
            recBox.addView(text(r.app + "  (" + r.pkg + ")  " + when, 14, true));
            for (final Recording.Feat f : r.feats) recBox.addView(featCard(r, f));
            recBox.addView(buttons(btn("Delete recording", v -> new MaterialAlertDialogBuilder(this)
                    .setTitle("Delete this recording?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete", (d, w) -> {
                        r.delete();
                        renderRecordings();
                    }).show())));
        }
    }

    private View featCard(Recording r, Recording.Feat f) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(10), dp(12), dp(10));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), 0x55888888);
        c.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        c.setLayoutParams(lp);

        c.addView(text((f.confirmed ? "\u2714 " : "\u25CB ") + f.name + "   (" + f.clicks + " taps: " + f.onCount + " on, " + f.offCount + " off)", 15, true));
        c.addView(text(f.confirmed ? "Confirmed: you tapped it 3 or more times." : "Not confirmed yet, tap it " + Math.max(0, 3 - f.clicks) + " more time(s).", 12, false));

        LinearLayout pv = new LinearLayout(this);
        pv.setOrientation(LinearLayout.HORIZONTAL);
        addPreview(pv, r, f.prevOn, "ON");
        addPreview(pv, r, f.prevOff, "OFF");
        if (pv.getChildCount() > 0) c.addView(pv);

        StringBuilder sb = new StringBuilder();
        line(sb, "Starts", f.services);
        if (!f.libs.isEmpty()) sb.append("Native code loaded: ").append(join(f.libs, 6)).append('\n');
        line(sb, "Overlay windows", f.windows);
        line(sb, "Threads", f.threads);
        line(sb, "Files in use", f.files);
        line(sb, "Network", f.net);
        int shown = 0;
        for (Recording.Pref p : f.prefs) {
            if (!p.strong || shown++ >= 4) continue;
            sb.append("Setting ").append(p.k).append(":  ON=").append(p.on).append("  OFF=").append(p.off).append('\n');
        }
        if (f.classCount > 0) sb.append("Code that ran because of it: ").append(f.classCount).append(" classes, mostly ").append(join(f.classPkgs, 3)).append('\n');
        if (sb.length() == 0) sb.append("Nothing changed inside the app after the taps. The option may be drawn without views, or it only changes a native engine.\n");
        c.addView(text(sb.toString().trim(), 12, false));

        Recording.Item svc = f.bestService();
        Recording.Item vpn = f.vpnService();
        String note;
        if (svc != null) note = "Can be added: it runs as a service (" + shortName(svc.n) + ").";
        else if (vpn != null) note = "This feature is a VPN service (" + shortName(vpn.n) + "). Adding it works only partly, see the warning on the next screen.";
        else note = "No service started, so there is nothing to add yet.";
        c.addView(text(note, 12, true));

        return c;
    }

    private void line(StringBuilder sb, String label, List<Recording.Item> l) {
        if (l.isEmpty()) return;
        List<String> n = new ArrayList<>();
        for (Recording.Item i : l) n.add(shortName(i.n) + (i.strong ? " \u2714" : "") + (i.vpn ? " (VPN)" : ""));
        sb.append(label).append(": ").append(join(n, 5)).append('\n');
    }

    private static String join(List<String> l, int max) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < l.size() && i < max; i++) b.append(i > 0 ? ", " : "").append(l.get(i));
        if (l.size() > max) b.append(" +").append(l.size() - max);
        return b.toString();
    }

    private static String shortName(String n) {
        int p = n.lastIndexOf('.');
        return p >= 0 ? n.substring(p + 1) : n;
    }

    private void addPreview(LinearLayout row, Recording r, String file, String label) {
        File f = r.file(file);
        if (f == null || !f.exists()) return;
        Bitmap bm = BitmapFactory.decodeFile(f.getAbsolutePath());
        if (bm == null) return;
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(8), dp(8), 0);
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(bm);
        iv.setAdjustViewBounds(true);
        iv.setMaxHeight(dp(220));
        iv.setMaxWidth(dp(150));
        col.addView(iv);
        col.addView(text(label, 11, false));
        row.addView(col);
    }

    private void useInMerge(Recording r, Recording.Feat f) {
        Model.Apk target = null;
        for (File x : store.listApks()) {
            Model.Apk a = store.loadCached(x);
            if (a != null && r.pkg.equals(a.pkg)) target = a;
        }
        if (target == null) {
            Toast.makeText(this, "Add the original " + r.pkg + " APK in the Apps tab first", Toast.LENGTH_LONG).show();
            return;
        }
        Recording.Item svc = f.bestService();
        boolean isVpn = false;
        if (svc == null) {
            svc = f.vpnService();
            isVpn = true;
        }
        if (svc == null) return;

        Model.Feature nf = new Model.Feature();
        nf.id = "L" + svc.n.replace('.', '/') + ";";
        nf.label = f.name;
        nf.kind = "SERVICE";
        nf.serviceName = svc.n;
        nf.movable = true;
        nf.classCount = f.classCount;
        nf.level = isVpn ? Model.RED : (svc.strong ? Model.GREEN : Model.AMBER);
        nf.reasons.add("Recorded: it started " + shortName(svc.n) + " after " + f.onCount + " ON tap(s)" + (svc.strong ? " and stopped it after OFF." : "."));
        if (!f.libs.isEmpty()) nf.reasons.add("Loads native code: " + join(f.libs, 4) + " (travels inside the source APK).");
        if (isVpn) nf.reasons.add("VPN service: the VPN engine and its server settings may not work after the move.");
        for (int i = target.features.size() - 1; i >= 0; i--) if (nf.id.equals(target.features.get(i).id)) target.features.remove(i);
        target.features.add(0, nf);
        store.save(target);
        startActivity(new Intent(this, MainActivity.class)
                .putExtra(EXTRA_APK, target.path)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        finish();
    }

    // ------------------------------------------------------------------ small view helpers
    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, dp(6), 0, dp(2));
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    private LinearLayout box() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private MaterialButton btn(String label, View.OnClickListener l) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout buttons(View... vs) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, 0);
        for (View v : vs) row.addView(v);
        return row;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
    }
}
