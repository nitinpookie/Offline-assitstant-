# Feature Merger

## VPN transplant (new, main feature)

Makes a VPN app that works for some games (for example Free Fire and Free Fire MAX) work for one more game
(for example Free Fire India), without touching the VPN's servers, engine or screens.

1. **Apps** tab: Add the VPN APK and the game APK (Free Fire India).
2. **VPN** tab: choose the VPN app, tap **Scan VPN** (shows how the VPN picks its games), tick the games it
   already supports (the new game copies those), choose the new game, tap **Transplant, scan and save**.
3. The app patches the VPN, then scans the new APK again and prints a PASS/FAIL report.
   * FAIL or crash: tap **Copy report** and paste it to Claude.
4. **Save as...** (or Share). The file is saved **unsigned** on purpose; sign it with MT Manager,
   uninstall the old VPN, install the signed one.

How it works: every `VpnService.Builder.addAllowedApplication(pkg)` call in the VPN is redirected to a small helper
(`FmVpn.add`). It does the original call and, when `pkg` is one of the ticked games, also allows the new package
(a missing/uninstalled target never breaks the VPN). Package lists in plain config files (JSON arrays, one-per-line
lists) get the new package too. If the VPN has no per-app list (routes all apps, or only excludes some), the scan says
so: the new game is then already covered and nothing is patched.

**VPN has no addAllowedApplication call (new):** switch **Add a per-app list if missing** (VPN tab, on by default).
Then every `Builder.establish()` call goes through `FmVpn.establish`, which injects `addAllowedApplication(pkg)` for the
ticked games and the new game(s) right before the tunnel starts. The VPN then routes ONLY those games. Games that are
not listed in the scan (because the VPN had no list) can be typed into **Extra package names**
(for example Free Fire + Free Fire MAX + Free Fire India = three games). If the VPN only excludes apps
(`addDisallowedApplication`), those calls are switched off, because Android does not allow an exclude list and an allow
list together. A package that is not installed is skipped; if none is installed the VPN simply routes all apps.
Switch it off to keep the old behaviour ("nothing to patch" for such VPNs).

Limits: VPNs that decide the game some other way (server side, usage-stats checks, encrypted lists) are reported,
not patched. Apps that check their own signature may refuse to start after patching.

The old "move features between apps" Merge tab was removed. The Record tab (recorder build) is still there.

---

Android app that reads APKs on the phone and

* lists every **overlay feature** inside them (floating menus, switches, sliders) with a traffic light:
  green = should work the same after the move, amber = check first, red = probably will not work
* lists everything the developer **switched off** (controls hidden with `visibility=gone/invisible`, disabled
  controls, disabled services/activities/receivers) and lets you **activate** it
* moves chosen features from one APK into another (the **base app**) and, if the base app has a switch menu,
  **adds a matching switch row** to that menu by cloning its last row, so it looks like every other option
* can turn off whole base-app features or hide single controls
* signs the result (v1 + v2) with a key generated on first use and offers Install / Share

Everything runs on the phone, pure Java (no native code, fine on armv7a), no internet needed.

## Build on GitHub

1. Use your existing repo. Upload this zip into the repo root (or the extracted files). The workflow
   `.github/workflows/build.yml` (same file as the TraceLock/iLauncher repo) unpacks the newest zip and builds it.
2. Open the **Actions** tab: it runs on every push (or run it by hand).
3. Download the `iLauncher-APK-run<N>` artifact: `iLauncher-debug.apk` (and `iLauncher-release.apk`).
   The artifact keeps the old iLauncher name on purpose, the workflow is unchanged. The Android Gradle plugin is 8.3.2
   because that workflow uses Gradle 8.4.

## Use

1. **Apps** tab: Add APK (one or more). Tap **Details** to see features, risk colours and switched-off items.
2. **Merge** tab: pick the base app, tick what to activate / turn off / bring in, press **Build merged APK**.
3. Uninstall the original base app, then Install the merged APK (it is signed with your own key).

## How a moved feature works

The source APK is embedded unchanged in the base APK. A small bridge (extracted from this app's own dex)
loads it with its own code and resources, so the feature behaves like in the original app. A manifest
provider boots the bridge, shim services host the feature's overlay Service, and the cloned menu switch
(found at runtime through its `android:tag`) starts/stops it.

## Record mode (new)

Instead of guessing from the code, you can let the source app show you what a feature really does.

1. **Record** tab -> pick the source app -> **Build recorder**. This makes a copy of the app with a small floating
   panel added (the original code and resources are untouched).
2. Uninstall the original, install the recorder copy, open it, allow *Display over other apps*.
3. Use the app's own switches / buttons. Tap each one **3 times** (ON, OFF, ON), about 5 seconds apart.
   After every tap the recorder compares the app before and after and remembers what changed:
   services started or stopped, native libraries loaded, threads, overlay windows, files in use, saved settings that
   flipped, classes that got loaded, VPN becoming active. A control is *confirmed* after 3 taps and gets a preview
   screenshot for ON and for OFF.
4. Press **Send to FM** in the panel. The recording opens in Feature Merger (Record tab) with the previews.
5. **Use in Merge** puts the recorded feature (its entry service) into the app's feature list, then the normal
   Merge flow adds it to your base app, together with the whole source APK it needs (code, resources, native libs).

Not covered yet / honest limits:

* Menus drawn without Android views (game-engine / canvas menus) are not noticed; use **Mark** in the panel
  after you tapped them yourself. The recording then still shows what changed.
* The recorder watches the app's main process only.
* Apps that check their own signature may crash in the recorder copy (it is signed with your key).
* A VPN feature is recorded and shown, but the VPN engine itself still cannot be moved (marked red).
* Not built or run by the author's tools: this code was written without an Android SDK, so the first GitHub build
  may report small compile errors. Send them back and they get fixed.

## Known limits

* Features that drive their own app's VPN engine are marked red; the engine cannot be moved.
* Overlays built inside an Activity (not a Service) are listed but cannot be moved yet.
* Only hidden/disabled items that exist in layouts or the manifest are found; flags inside code are not.
* Menus built entirely in code (no layout XML) cannot get a cloned switch; the feature then starts automatically.
