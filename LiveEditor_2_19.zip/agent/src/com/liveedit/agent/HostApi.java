package com.liveedit.agent;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * What the Live Editor app may ask this app to do from its pencil overlay: list the windows (with small pictures),
 * keep or remove one, or open the full pencil panel. Runs on the main thread of this app; only called through
 * AgentProvider, which answers nobody but the Live Editor app.
 */
final class HostApi {

    private HostApi() {}

    static Bundle handle(final Context ctx, final String method, final String arg, final Bundle extras) {
        final Object[] box = new Object[1];
        final CountDownLatch done = new CountDownLatch(1);
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    box[0] = work(ctx, method, arg, extras);
                } catch (Throwable t) {
                    U.err("host api " + method, t);
                } finally {
                    done.countDown();
                }
            }
        });
        try {
            done.await(4, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // answer what we have
        }
        Bundle out = new Bundle();
        out.putString("json", box[0] == null ? "" : String.valueOf(box[0]));
        return out;
    }

    private static String work(Context ctx, String method, String arg, Bundle extras) throws Exception {
        if ("windows".equals(method)) return windows(ctx);
        if ("keep".equals(method)) {
            if (arg == null || arg.length() == 0) return "no key";
            boolean keep = extras == null || extras.getBoolean("keep", true);
            Rules.edit(arg).hide = !keep;
            Config.saveLive(ctx);
            Overlays.tick(ctx);
            return "ok";
        }
        if ("panel".equals(method)) {
            Panel.showFromHost();
            return "ok";
        }
        return "unknown";
    }

    private static String windows(Context ctx) throws Exception {
        List<Overlays.Win> all = Overlays.windows(ctx);
        JSONArray arr = new JSONArray();
        int used = 0;
        for (int i = 0; i < all.size(); i++) {
            Overlays.Win w = all.get(i);
            JSONObject o = new JSONObject();
            o.put("k", w.o.key);
            o.put("kind", w.kind);
            o.put("name", w.name);
            o.put("sub", w.sub);
            o.put("gone", w.gone);
            o.put("locked", w.locked);
            o.put("unsafe", w.unsafe);
            o.put("unsafeShow", w.unsafeShow);
            Bitmap t = w.thumb;
            if (t != null && !t.isRecycled() && used < 450000) {
                try {
                    Bitmap sc = t;
                    int mx = Math.max(t.getWidth(), t.getHeight());
                    if (mx > 80) {
                        float f = 80f / mx;
                        sc = Bitmap.createScaledBitmap(t, Math.max(1, Math.round(t.getWidth() * f)),
                                Math.max(1, Math.round(t.getHeight() * f)), true);
                    }
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    sc.compress(Bitmap.CompressFormat.PNG, 90, bo);
                    byte[] pb = bo.toByteArray();
                    if (pb.length < 12000) {
                        String b64 = Base64.encodeToString(pb, Base64.NO_WRAP);
                        o.put("p", b64);
                        used += b64.length();
                    }
                } catch (Throwable e) {
                    // no picture for this one
                }
            }
            arr.put(o);
        }
        return arr.toString();
    }
}
