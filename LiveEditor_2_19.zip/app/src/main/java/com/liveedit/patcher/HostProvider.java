package com.liveedit.patcher;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

/**
 * The patched app tells Live Editor "I am on screen" ("fg") or "I left" ("bg"). Only the app that was patched most
 * recently (see MainActivity, key "recent") gets a pencil, and only that app itself can ask for it.
 */
public final class HostProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        Bundle out = new Bundle();
        out.putBoolean("shown", false);
        try {
            Context c = getContext();
            if (c == null || arg == null) return out;
            String caller = getCallingPackage();
            String recent = c.getSharedPreferences("liveeditor", Context.MODE_PRIVATE).getString("recent", "");
            if (!arg.equals(caller) || !arg.equals(recent)) return out;
            if ("fg".equals(method)) {
                out.putBoolean("shown", PencilHost.beat(c.getApplicationContext(), arg));
            } else if ("bg".equals(method)) {
                PencilHost.leave(arg);
            }
        } catch (Throwable t) {
            // never let a bad call hurt this app
        }
        return out;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] args) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] args) {
        return 0;
    }
}
