package com.liveedit.patcher;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Base64;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * The pencil of the most recently patched app, shown by Live Editor itself as an overlay above that app (so the patched app
 * needs no overlay permission of its own). The app reports every 1.5 s that it is on screen; when the reports stop, or it says
 * it left, the pencil goes away. The panel lists the app's windows with a small picture and a Keep switch (like the Windows
 * tab of the in-app pencil), opens the full in-app pencil, and starts "Save and patch" (normal APK, no pencil).
 * All view work runs on the main thread.
 */
final class PencilHost {

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static Context ctx;
    private static Context app;
    private static WindowManager wm;
    private static String pkg;
    private static String label = "";
    private static long lastBeat;
    private static boolean watching;

    private static TextView handle;
    private static WindowManager.LayoutParams hlp;
    private static LinearLayout panel;
    private static LinearLayout list;
    private static TextView status;
    private static int hx;
    private static int hy;

    private PencilHost() {}

    private static final Runnable WATCH = new Runnable() {
        @Override
        public void run() {
            watching = false;
            if (handle == null) return;
            if (SystemClock.uptimeMillis() - lastBeat > 6000L) {
                hideNow();
                return;
            }
            watching = true;
            H.postDelayed(this, 2000L);
        }
    };

    /** The app is on screen. Returns true when the pencil is showing (then the app hides its own). */
    static boolean beat(final Context application, final String p) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(application)) return false;
        final boolean[] ok = new boolean[1];
        final CountDownLatch done = new CountDownLatch(1);
        H.post(new Runnable() {
            @Override
            public void run() {
                try {
                    ok[0] = showNow(application, p);
                } catch (Throwable t) {
                    ok[0] = false;
                } finally {
                    done.countDown();
                }
            }
        });
        try {
            done.await(2, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // answer what we have
        }
        return ok[0];
    }

    /** The app left the screen. */
    static void leave(final String p) {
        H.post(new Runnable() {
            @Override
            public void run() {
                if (p != null && p.equals(pkg)) hideNow();
            }
        });
    }

    private static boolean showNow(Context application, String p) {
        lastBeat = SystemClock.uptimeMillis();
        if (handle != null && p.equals(pkg)) return true;
        hideNow();
        app = application;
        ctx = new ContextThemeWrapper(application, android.R.style.Theme_Material);
        wm = (WindowManager) application.getSystemService(Context.WINDOW_SERVICE);
        pkg = p;
        label = p;
        try {
            PackageManager pm = application.getPackageManager();
            label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(p, 0)));
        } catch (Throwable t) {
            // the package name is enough
        }
        if (hx == 0 && hy == 0) {
            hx = Ui.dp(ctx, 4);
            hy = Ui.dp(ctx, 140);
        }
        handle = buildHandle();
        hlp = new WindowManager.LayoutParams(Ui.dp(ctx, 46), Ui.dp(ctx, 46), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        hlp.gravity = Gravity.TOP | Gravity.LEFT;
        hlp.x = hx;
        hlp.y = hy;
        try {
            wm.addView(handle, hlp);
        } catch (Throwable t) {
            handle = null;
            return false;
        }
        if (!watching) {
            watching = true;
            H.postDelayed(WATCH, 2000L);
        }
        return true;
    }

    private static int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : 2002;
    }

    private static void hideNow() {
        closePanel();
        if (handle != null) {
            try {
                wm.removeView(handle);
            } catch (Throwable t) {
                // already gone
            }
            handle = null;
        }
        pkg = null;
    }

    // ---- the handle ----------------------------------------------------------------------------

    private static TextView buildHandle() {
        final TextView t = new TextView(ctx);
        t.setText("\u270E");
        t.setTextSize(20);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.round(ctx, Ui.ACCENT, 23));
        t.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;
            private int startX;
            private int startY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = hlp.x;
                        startY = hlp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > Ui.dp(ctx, 6) || Math.abs(dy) > Ui.dp(ctx, 6)) moved = true;
                        if (moved) {
                            hlp.x = Math.max(0, startX + Math.round(dx));
                            hlp.y = Math.max(0, startY + Math.round(dy));
                            hx = hlp.x;
                            hy = hlp.y;
                            try {
                                wm.updateViewLayout(t, hlp);
                            } catch (Throwable ex) {
                                // ignore
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel();
                        return true;
                    default:
                        return true;
                }
            }
        });
        return t;
    }

    // ---- the panel -----------------------------------------------------------------------------

    private static void togglePanel() {
        if (panel != null) closePanel();
        else openPanel();
    }

    private static void closePanel() {
        if (panel != null) {
            try {
                wm.removeView(panel);
            } catch (Throwable t) {
                // already gone
            }
        }
        panel = null;
        list = null;
        status = null;
    }

    private static void openPanel() {
        try {
            int sw = ctx.getResources().getDisplayMetrics().widthPixels;
            int sh = ctx.getResources().getDisplayMetrics().heightPixels;
            LinearLayout box = Ui.vbox(ctx);
            box.setBackground(Ui.round(ctx, Ui.CARD, 16));
            box.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 10), Ui.dp(ctx, 12), Ui.dp(ctx, 10));

            LinearLayout head = Ui.hbox(ctx);
            head.addView(Ui.text(ctx, "\u270E " + label, 15, Ui.TEXT, true), new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView close = Ui.chip(ctx, "Close");
            close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closePanel();
                }
            });
            head.addView(close);
            box.addView(head);
            box.addView(Ui.text(ctx, "Windows of this app: what is open, and what to remove", 12, Ui.SUB, false));

            LinearLayout row1 = Ui.hbox(ctx);
            TextView refresh = Ui.chip(ctx, "\u21BB Refresh");
            refresh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    refresh();
                }
            });
            TextView full = Ui.chip(ctx, "Full pencil (items, global, theme)");
            full.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    callAsync("panel", null, null);
                    closePanel();
                }
            });
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            cl.rightMargin = Ui.dp(ctx, 8);
            row1.addView(refresh, cl);
            row1.addView(full);
            Ui.add(box, row1, 8);

            android.widget.Button bake = Ui.button(ctx, "Save and patch (remove the pencil)", true);
            bake.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    saveAndPatch();
                }
            });
            Ui.add(box, bake, 8);

            status = Ui.text(ctx, "Reading the windows...", 12, Ui.SUB, false);
            Ui.add(box, status, 8);
            ScrollView sv = new ScrollView(ctx);
            list = Ui.vbox(ctx);
            sv.addView(list);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            slp.topMargin = Ui.dp(ctx, 6);
            box.addView(sv, slp);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(Math.min(sw - Ui.dp(ctx, 24), Ui.dp(ctx, 420)),
                    Math.round(sh * 0.74f), overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = Ui.dp(ctx, 50);
            wm.addView(box, lp);
            panel = box;
            refresh();
        } catch (Throwable t) {
            panel = null;
        }
    }

    private static Uri agentUri() {
        return Uri.parse("content://" + pkg + ".liveeditagent");
    }

    /** Asks the engine inside the patched app for its windows (on a worker thread) and shows them. */
    private static void refresh() {
        final String p = pkg;
        if (p == null) return;
        if (status != null) status.setText("Reading the windows...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                String json = null;
                try {
                    Bundle b = app.getContentResolver().call(Uri.parse("content://" + p + ".liveeditagent"), "windows",
                            null, null);
                    if (b != null) json = b.getString("json");
                } catch (Throwable t) {
                    json = null;
                }
                final String j = json;
                H.post(new Runnable() {
                    @Override
                    public void run() {
                        fill(j);
                    }
                });
            }
        }, "pencil-windows").start();
    }

    private static void fill(String json) {
        if (list == null) return;
        list.removeAllViews();
        JSONArray arr = null;
        try {
            if (json != null && json.length() > 0) arr = new JSONArray(json);
        } catch (Throwable t) {
            arr = null;
        }
        if (arr == null) {
            if (status != null) status.setText("Could not read the windows. This app must be patched with Live Editor 2.19 "
                    + "and be open. Tap Refresh.");
            return;
        }
        if (status != null) {
            status.setText(arr.length() == 0 ? "No window found yet. Open the menus and popups of the app once, then Refresh."
                    : arr.length() + " windows. Untick Keep to remove one (it is bypassed, never closed).");
        }
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            list.addView(row(o), rowLp());
        }
    }

    private static LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(ctx, 6);
        return lp;
    }

    private static View row(JSONObject o) {
        final String key = o.optString("k", "");
        LinearLayout row = Ui.hbox(ctx);
        row.setPadding(Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8), Ui.dp(ctx, 8));
        row.setBackground(Ui.round(ctx, Ui.CARD2, 10));
        ImageView pic = new ImageView(ctx);
        pic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pic.setBackground(Ui.round(ctx, 0xFF22253F, 8));
        pic.setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3));
        String p64 = o.optString("p", "");
        if (p64.length() > 0) {
            try {
                byte[] pb = Base64.decode(p64, Base64.DEFAULT);
                Bitmap bm = BitmapFactory.decodeByteArray(pb, 0, pb.length);
                if (bm != null) pic.setImageBitmap(bm);
            } catch (Throwable t) {
                // no picture
            }
        }
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(Ui.dp(ctx, 66), Ui.dp(ctx, 66));
        pl.rightMargin = Ui.dp(ctx, 10);
        row.addView(pic, pl);
        LinearLayout col = Ui.vbox(ctx);
        row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(Ui.text(ctx, o.optString("name", "Window"), 13.5f, Ui.TEXT, true));
        col.addView(Ui.text(ctx, o.optString("sub", ""), 11, Ui.SUB, false));
        boolean locked = o.optBoolean("locked", false);
        if (!locked && o.optBoolean("unsafe", false)) {
            col.addView(Ui.text(ctx, "Kept visible: removing it closed the app before.", 11.5f, Ui.SUB, false));
        } else if (!locked && o.optBoolean("unsafeShow", false)) {
            col.addView(Ui.text(ctx, "Kept removed: bringing it back closed the app before.", 11.5f, Ui.SUB, false));
        } else if (!locked) {
            CheckBox keep = new CheckBox(ctx);
            keep.setText("Keep this interface");
            keep.setTextColor(Ui.TEXT);
            keep.setChecked(!o.optBoolean("gone", false));
            keep.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton b, boolean on) {
                    Bundle ex = new Bundle();
                    ex.putBoolean("keep", on);
                    callAsync("keep", key, ex);
                }
            });
            col.addView(keep);
        }
        return row;
    }

    /** A command for the engine inside the patched app, sent from a worker thread. */
    private static void callAsync(final String method, final String arg, final Bundle extras) {
        final String p = pkg;
        if (p == null) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    app.getContentResolver().call(Uri.parse("content://" + p + ".liveeditagent"), method, arg, extras);
                } catch (Throwable t) {
                    // the app is gone or too old: nothing to do
                }
            }
        }, "pencil-call").start();
    }

    private static void saveAndPatch() {
        final String p = pkg;
        if (p == null) return;
        try {
            Intent i = new Intent("com.liveedit.patcher.BAKE");
            i.setClassName(app.getPackageName(), MainActivity.class.getName());
            i.putExtra("pkg", p);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            hideNow();
            app.startActivity(i);
        } catch (Throwable t) {
            // Live Editor can still be opened by hand: Pencil apps > this app
        }
    }
}
