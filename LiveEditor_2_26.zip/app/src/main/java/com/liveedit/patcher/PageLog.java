package com.liveedit.patcher;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

/**
 * What the pencil on apps that are not patched remembers (only on this phone, inside Live Editor):
 * the pages (screens) it saw in each app, the covers the user put on a page, the places where the pencil is not wanted,
 * and where the handle was left.
 */
final class PageLog {

    private static final String FILE = "liveeditor_pages";
    private static final int MAX_PAGES = 60;

    private PageLog() {}

    static final class Page {
        String cls;
        int n;
        long t;
    }

    /** A cover on a page. It follows the element by its view id when it has one, else it stays at the saved place. */
    static final class Cover {
        String id = "";
        int l;
        int t;
        int r;
        int b;
        int mode; // 0 = hide (solid), 1 = block taps only
        String label = "";
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    // ---- pages ----------------------------------------------------------------------------------

    static void seen(Context c, String pkg, String cls) {
        try {
            SharedPreferences sp = sp(c);
            ArrayList<Page> list = pages(c, pkg);
            Page hit = null;
            for (Page p : list) {
                if (p.cls.equals(cls)) {
                    hit = p;
                    break;
                }
            }
            if (hit == null) {
                hit = new Page();
                hit.cls = cls;
                list.add(hit);
            }
            hit.n++;
            hit.t = System.currentTimeMillis();
            Collections.sort(list, new Comparator<Page>() {
                @Override
                public int compare(Page a, Page b) {
                    return Long.compare(b.t, a.t);
                }
            });
            while (list.size() > MAX_PAGES) list.remove(list.size() - 1);
            JSONArray arr = new JSONArray();
            for (Page p : list) {
                JSONObject o = new JSONObject();
                o.put("c", p.cls);
                o.put("n", p.n);
                o.put("t", p.t);
                arr.put(o);
            }
            sp.edit().putString("pages:" + pkg, arr.toString()).apply();
        } catch (Throwable t) {
            // the log is a bonus
        }
    }

    /** The pages seen in this app, the newest first. */
    static ArrayList<Page> pages(Context c, String pkg) {
        ArrayList<Page> out = new ArrayList<Page>();
        try {
            String raw = sp(c).getString("pages:" + pkg, null);
            if (raw == null) return out;
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Page p = new Page();
                p.cls = o.getString("c");
                p.n = o.optInt("n", 1);
                p.t = o.optLong("t", 0L);
                out.add(p);
            }
        } catch (Throwable t) {
            // empty list
        }
        return out;
    }

    // ---- covers ---------------------------------------------------------------------------------

    private static String coverKey(String pkg, String cls) {
        return "covers:" + pkg + "|" + cls;
    }

    static ArrayList<Cover> covers(Context c, String pkg, String cls) {
        ArrayList<Cover> out = new ArrayList<Cover>();
        try {
            String raw = sp(c).getString(coverKey(pkg, cls), null);
            if (raw == null) return out;
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Cover v = new Cover();
                v.id = o.optString("id", "");
                v.l = o.optInt("l");
                v.t = o.optInt("t");
                v.r = o.optInt("r");
                v.b = o.optInt("b");
                v.mode = o.optInt("m");
                v.label = o.optString("x", "");
                out.add(v);
            }
        } catch (Throwable t) {
            // empty list
        }
        return out;
    }

    static void saveCovers(Context c, String pkg, String cls, ArrayList<Cover> list) {
        try {
            SharedPreferences.Editor ed = sp(c).edit();
            if (list == null || list.isEmpty()) {
                ed.remove(coverKey(pkg, cls));
            } else {
                JSONArray arr = new JSONArray();
                for (Cover v : list) {
                    JSONObject o = new JSONObject();
                    o.put("id", v.id);
                    o.put("l", v.l);
                    o.put("t", v.t);
                    o.put("r", v.r);
                    o.put("b", v.b);
                    o.put("m", v.mode);
                    o.put("x", v.label);
                    arr.put(o);
                }
                ed.putString(coverKey(pkg, cls), arr.toString());
            }
            ed.apply();
        } catch (Throwable t) {
            // keep the old list
        }
    }

    static int coverCount(Context c, String pkg, String cls) {
        return covers(c, pkg, cls).size();
    }

    // ---- apps where the pencil is not wanted ------------------------------------------------------

    private static Set<String> mutedSet(Context c) {
        try {
            return new HashSet<String>(sp(c).getStringSet("muted", new HashSet<String>()));
        } catch (Throwable t) {
            return new HashSet<String>();
        }
    }

    static boolean isMuted(Context c, String pkg) {
        return mutedSet(c).contains(pkg);
    }

    static void mute(Context c, String pkg) {
        try {
            Set<String> s = mutedSet(c);
            s.add(pkg);
            sp(c).edit().putStringSet("muted", s).apply();
        } catch (Throwable t) {
            // not saved
        }
    }

    static int mutedCount(Context c) {
        return mutedSet(c).size();
    }

    static void unmuteAll(Context c) {
        try {
            sp(c).edit().remove("muted").apply();
        } catch (Throwable t) {
            // not saved
        }
    }

    // ---- where the handle was left ----------------------------------------------------------------

    static int[] pos(Context c) {
        SharedPreferences sp = sp(c);
        return new int[] {sp.getInt("hx", Ui.dp(c, 4)), sp.getInt("hy", Ui.dp(c, 140))};
    }

    /** Place of the pencil on a patched app (the app's own pencil sits at the default place, this one lower). */
    static int[] posTwin(Context c) {
        SharedPreferences sp = sp(c);
        return new int[] {sp.getInt("tx", Ui.dp(c, 4)), sp.getInt("ty", Ui.dp(c, 210))};
    }

    static void savePosTwin(Context c, int x, int y) {
        try {
            sp(c).edit().putInt("tx", x).putInt("ty", y).apply();
        } catch (Throwable t) {
            // not saved
        }
    }

    static void savePos(Context c, int x, int y) {
        try {
            sp(c).edit().putInt("hx", x).putInt("hy", y).apply();
        } catch (Throwable t) {
            // not saved
        }
    }
}
