package com.chanit.featuremerger;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.chanit.featuremerger.core.Model;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

final class ApkAdapter extends RecyclerView.Adapter<ApkAdapter.VH> {
    interface Listener {
        void onRemove(Model.Apk a);
        void onActivate(Model.Apk a);
    }

    private final List<Model.Apk> items;
    private final Listener listener;
    private final Set<String> open = new HashSet<>();

    ApkAdapter(List<Model.Apk> items, Listener l) {
        this.items = items;
        this.listener = l;
    }

    static final class VH extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView name, meta, summary;
        final ChipGroup chips;
        final LinearLayout details;
        final MaterialButton remove, toggle;

        VH(View v) {
            super(v);
            icon = v.findViewById(R.id.ivIcon);
            name = v.findViewById(R.id.tvName);
            meta = v.findViewById(R.id.tvMeta);
            summary = v.findViewById(R.id.tvSummary);
            chips = v.findViewById(R.id.chips);
            details = v.findViewById(R.id.details);
            remove = v.findViewById(R.id.btnRemove);
            toggle = v.findViewById(R.id.btnDetails);
        }
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_apk, p, false));
    }

    private static void chip(ChipGroup g, String text) {
        Chip c = new Chip(g.getContext());
        c.setText(text);
        c.setClickable(false);
        c.setCheckable(false);
        g.addView(c);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        final Model.Apk a = items.get(pos);
        h.name.setText(a.label);
        h.meta.setText((a.pkg != null ? a.pkg : "package unknown") + "  |  " + String.format(Locale.US, "%.1f MB", a.size / 1048576.0)
                + (a.versionName != null ? "  |  v" + a.versionName : ""));
        h.icon.setImageResource(R.drawable.ic_launcher);
        if (a.iconPath != null) {
            Bitmap b = BitmapFactory.decodeFile(a.iconPath);
            if (b != null) h.icon.setImageBitmap(b);
        }
        int safe = 0, movable = 0;
        for (Model.Feature f : a.features) {
            if (f.movable) movable++;
            if (f.movable && f.level == Model.GREEN) safe++;
        }
        h.chips.removeAllViews();
        chip(h.chips, a.features.size() + " overlay feature" + (a.features.size() == 1 ? "" : "s"));
        if (!a.hidden.isEmpty()) chip(h.chips, a.hidden.size() + " switched off");
        if (a.vpn) chip(h.chips, "VPN engine");
        chip(h.chips, a.abiOk ? "Runs on this phone" : "CPU mismatch");
        if (a.obfuscation > 40) chip(h.chips, "Obfuscated " + a.obfuscation + "%");
        h.summary.setText(a.features.isEmpty()
                ? "No overlay features found."
                : movable + " can be moved, " + safe + " of them safe.");

        final boolean isOpen = open.contains(a.path);
        h.details.setVisibility(isOpen ? View.VISIBLE : View.GONE);
        h.toggle.setText(isOpen ? "Hide details" : "Details");
        h.details.removeAllViews();
        if (isOpen) fillDetails(h, a);
        h.toggle.setOnClickListener(v -> {
            if (!open.remove(a.path)) open.add(a.path);
            notifyItemChanged(h.getBindingAdapterPosition());
        });
        h.remove.setOnClickListener(v -> listener.onRemove(a));
    }

    private void fillDetails(VH h, Model.Apk a) {
        LinearLayout d = h.details;
        android.content.Context c = d.getContext();
        Rows.header(c, d, "Overlay features");
        if (a.features.isEmpty()) Rows.note(c, d, "None found. The overlay may be built from code that is hidden or obfuscated.");
        for (Model.Feature f : a.features) Rows.feature(c, d, a, f, null, false, false, false);
        Rows.header(c, d, "Switched off by the developer");
        if (a.hidden.isEmpty()) Rows.note(c, d, "Nothing hidden or disabled was found.");
        for (Model.Hidden x : a.hidden) Rows.hidden(c, d, x, false);
        if (!a.notes.isEmpty()) {
            Rows.header(c, d, "Notes");
            for (String n : a.notes) Rows.note(c, d, "- " + n);
        }
    }

    @Override public int getItemCount() { return items.size(); }
}
