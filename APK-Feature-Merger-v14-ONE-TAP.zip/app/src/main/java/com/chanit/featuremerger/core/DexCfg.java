package com.chanit.featuremerger.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.Adler32;

/**
 * Reads and rewrites the settings text of a Feature Merger helper inside a dex file, whether it still holds the empty
 * placeholder (all #) or settings written by an earlier run. This is what makes "select it again" a REWRITE: the old
 * settings are replaced in place, the rest of the app is untouched.
 */
final class DexCfg {
    private DexCfg() {}

    /** Offsets of every OPEN + len plain-text bytes + CLOSE in the dex. */
    static List<Integer> find(byte[] dex, String open, String close, int len) {
        byte[] o = open.getBytes(StandardCharsets.US_ASCII);
        byte[] c = close.getBytes(StandardCharsets.US_ASCII);
        List<Integer> hits = new ArrayList<>();
        int total = o.length + len + c.length;
        for (int i = 0; i + total <= dex.length; i++) {
            if (dex[i] != o[0]) continue;
            boolean ok = true;
            for (int k = 1; k < o.length && ok; k++) if (dex[i + k] != o[k]) ok = false;
            if (!ok) continue;
            for (int k = 0; k < len && ok; k++) {
                int b = dex[i + o.length + k] & 0xff;
                if (b < 0x20 || b > 0x7e || b == '}') ok = false;
            }
            for (int k = 0; k < c.length && ok; k++) if (dex[i + o.length + len + k] != c[k]) ok = false;
            if (ok) hits.add(i);
        }
        return hits;
    }

    /** The settings text without the # padding. */
    static String read(byte[] dex, int at, String open, int len) {
        String s = new String(dex, at + open.length(), len, StandardCharsets.US_ASCII);
        return s.replace("#", "").trim();
    }

    static void write(byte[] dex, int at, String open, String close, int len, String payload) throws IOException {
        if (payload.length() > len) throw new IOException("Settings too long (" + payload.length() + " > " + len + ").");
        StringBuilder nw = new StringBuilder(open).append(payload);
        while (nw.length() < open.length() + len) nw.append('#');
        nw.append(close);
        byte[] nb = nw.toString().getBytes(StandardCharsets.US_ASCII);
        if (nb.length != open.length() + len + close.length()) throw new IOException("Settings length mismatch");
        System.arraycopy(nb, 0, dex, at, nb.length);
        fixHeader(dex);
    }

    static void fixHeader(byte[] dex) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            md.update(dex, 32, dex.length - 32);
            System.arraycopy(md.digest(), 0, dex, 12, 20);
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
        Adler32 ad = new Adler32();
        ad.update(dex, 12, dex.length - 12);
        long v = ad.getValue();
        dex[8] = (byte) v;
        dex[9] = (byte) (v >> 8);
        dex[10] = (byte) (v >> 16);
        dex[11] = (byte) (v >> 24);
    }
}
