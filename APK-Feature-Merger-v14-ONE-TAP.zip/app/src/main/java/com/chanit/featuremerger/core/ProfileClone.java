package com.chanit.featuremerger.core;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Copies what a VPN keeps for a reference game to the new game, inside a JSON config file:
 *  - a list that names the reference package gets the new package too,
 *  - an entry keyed by the reference package ("com.game": {servers, ports, ...}) is copied under the new package,
 *  - an object in a list that mentions the reference package (for example {"package":"com.game","server":"..."}) is
 *    copied with the new package in its place.
 * Everything the VPN knows about the reference game (servers, ports, routes, per-game switches) so travels with the new
 * game, and the VPN features that read this config work for it like they do for the other games.
 * Returns null when the text is not JSON or nothing had to be copied.
 */
final class ProfileClone {
    private ProfileClone() {}

    static String clone(String text, Set<String> refs, List<String> targets, int[] count) {
        String t = text == null ? "" : text.trim();
        try {
            Object root = t.startsWith("[") ? new JSONArray(t) : t.startsWith("{") ? new JSONObject(t) : null;
            if (root == null) return null;
            int before = count[0];
            Object out = tx(root, refs, targets, count, 0);
            if (count[0] == before) return null;
            return out instanceof JSONArray ? ((JSONArray) out).toString(2) : ((JSONObject) out).toString(2);
        } catch (Throwable e) {
            return null;
        }
    }

    private static Object tx(Object node, Set<String> refs, List<String> targets, int[] count, int depth) throws Exception {
        if (depth > 12) return node;
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            List<Object> items = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) items.add(tx(a.get(i), refs, targets, count, depth + 1));
            List<Object> out = new ArrayList<>();
            for (Object e : items) {
                out.add(e);
                String ref = e instanceof String ? (refs.contains(e) ? (String) e : null) : (e instanceof JSONObject ? mentions(e, refs, 0) : null);
                if (ref == null) continue;
                for (String tg : targets) {
                    Object copy = e instanceof String ? tg : replaceDeep(e, ref, tg);
                    if (!containsEqual(items, copy) && !containsEqual(out, copy)) {
                        out.add(copy);
                        count[0]++;
                    }
                }
            }
            JSONArray res = new JSONArray();
            for (Object o : out) res.put(o);
            return res;
        }
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject res = new JSONObject();
            List<String> keys = new ArrayList<>();
            Iterator<String> it = o.keys();
            while (it.hasNext()) keys.add(it.next());
            for (String k : keys) {
                Object v = tx(o.get(k), refs, targets, count, depth + 1);
                res.put(k, v);
                if (refs.contains(k)) {
                    for (String tg : targets) {
                        if (o.has(tg) || res.has(tg)) continue;
                        res.put(tg, replaceDeep(v, k, tg));
                        count[0]++;
                    }
                }
            }
            return res;
        }
        return node;
    }

    /** the reference package named by this object (a string value, up to 3 levels down), or null */
    private static String mentions(Object node, Set<String> refs, int depth) throws Exception {
        if (depth > 3) return null;
        if (node instanceof String) return refs.contains(node) ? (String) node : null;
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String r = mentions(o.get(it.next()), refs, depth + 1);
                if (r != null) return r;
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String r = mentions(a.get(i), refs, depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static Object replaceDeep(Object node, String ref, String target) throws Exception {
        if (node instanceof String) return ((String) node).contains(ref) ? ((String) node).replace(ref, target) : node;
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node, res = new JSONObject();
            Iterator<String> it = o.keys();
            List<String> keys = new ArrayList<>();
            while (it.hasNext()) keys.add(it.next());
            for (String k : keys) res.put(k.equals(ref) ? target : k, replaceDeep(o.get(k), ref, target));
            return res;
        }
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node, res = new JSONArray();
            for (int i = 0; i < a.length(); i++) res.put(replaceDeep(a.get(i), ref, target));
            return res;
        }
        return node;
    }

    private static boolean containsEqual(List<Object> l, Object x) {
        String xs = String.valueOf(x);
        for (Object o : l) if (String.valueOf(o).equals(xs)) return true;
        return false;
    }
}
