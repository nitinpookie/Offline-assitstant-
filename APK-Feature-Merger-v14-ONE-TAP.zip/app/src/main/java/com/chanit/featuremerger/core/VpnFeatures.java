package com.chanit.featuremerger.core;

import android.content.Context;

import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.MethodImplementation;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.android.tools.smali.dexlib2.iface.reference.Reference;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * What a VPN app is made of, as a list the user can pick from.
 *
 * FEATURES = the components you see and tap in the VPN (a "Freeze" button, a "Ghost" switch, a menu item, a setting):
 * every clickable component of every window / dialog / menu, with its name as shown on screen, and, from the code, where it
 * is wired (the classes and methods that use it). The connection settings (DNS, MTU, routes ...) are kept apart at the end
 * as "advanced".
 */
public final class VpnFeatures {
    private VpnFeatures() {}

    public static final String BUILDER = "Landroid/net/VpnService$Builder;";
    public static final String E_DNS = "dns", E_MTU = "mtu", E_V6 = "v6", E_MET = "met", E_AON = "aon", E_START = "start", E_APPS = "apps", E_ROUTE = "route",
            C_CTL = "ctl", C_INFO = "info";

    public static final class Feat {
        public String group, title, detail, kind;
        public int count;
        // components
        public int viewId;
        public String layout, idName, tag;
        public boolean checkable, wired;
        public List<String> layoutPaths = new ArrayList<>();
        /** classes / methods of the VPN that use this component */
        public List<String> codeRefs = new ArrayList<>();
    }

    public static final class Result {
        public String vpnService;
        public int targetSdk;
        public boolean alwaysOnOptOut, alreadyEnhanced;
        public String shimDexName;
        public final Map<String, Integer> calls = new LinkedHashMap<>();
        public final Map<String, Integer> callsByDex = new LinkedHashMap<>();
        public final List<Feat> engine = new ArrayList<>();
        /** the features: components, menu items, settings */
        public final List<Feat> controls = new ArrayList<>();
        public final List<String> notes = new ArrayList<>();

        public int calls(String name) {
            Integer n = calls.get(name);
            return n == null ? 0 : n;
        }
    }

    private static final String[] LIB_LAYOUT = {"abc_", "mtrl_", "material_", "design_", "m3_", "notification_", "support_",
            "select_dialog", "custom_dialog", "browser_actions", "ime_", "preference", "expand_button", "image_frame",
            "test_", "language_", "oss_", "common_", "fb_", "ad_", "admob", "gms_", "googlesignin", "auth_", "play_"};
    private static final String[] SKIP_XML = {"backup", "data_extraction", "network_security", "file_paths", "provider_paths", "device_admin",
            "accessibility", "shortcuts", "searchable", "widget", "appwidget", "locales", "remote_config", "automotive", "standalone"};
    private static final String[] GENERIC = {"back", "close", "ok", "cancel", "dismiss", "exit", "rate", "share", "privacy", "terms", "ads", "banner", "navigation", "toolbar", "menu"};

    private static final class Cand {
        Feat f;
        boolean interactive;
    }

    /** Never throws: whatever cannot be read is skipped and mentioned in notes. */
    public static Result scan(Context ctx, File apk) {
        Result r = new Result();
        Arsc arsc = null;
        try (ZipFile zf = new ZipFile(apk)) {
            ZipEntry me = zf.getEntry("AndroidManifest.xml");
            if (me != null) readManifest(Axml.parse(ApkZip.readAll(zf, me)), r);
            ZipEntry ae = zf.getEntry("resources.arsc");
            if (ae != null) {
                try {
                    arsc = Arsc.parse(ApkZip.readAll(zf, ae));
                } catch (Throwable t) {
                    r.notes.add("Resources not readable: " + t.getMessage());
                }
            }
            List<Cand> cands = new ArrayList<>();
            if (arsc != null) collect(zf, arsc, cands, r);
            Set<Integer> ids = new HashSet<>();
            for (Cand c : cands) ids.add(c.f.viewId);
            Set<Integer> wired = new HashSet<>();
            Map<Integer, List<String>> refs = new HashMap<>();
            countCalls(ctx, zf, r, ids, wired, refs);
            finish(r, cands, wired, refs);
            if (arsc != null) extras(zf, arsc, r);
        } catch (Throwable t) {
            r.notes.add("Could not read the APK fully: " + t);
        }
        engine(r);
        return r;
    }

    // ------------------------------------------------------------------ manifest
    private static void readManifest(Axml mf, Result r) {
        String pkg = mf.root.plain("package") == null ? "" : mf.root.plain("package").text();
        Axml.Elem uses = mf.root.child("uses-sdk");
        if (uses != null && uses.text("targetSdkVersion") != null) {
            try {
                r.targetSdk = Integer.parseInt(uses.text("targetSdkVersion"));
            } catch (Exception ignored) { }
        }
        Axml.Elem app = mf.root.child("application");
        if (app == null) return;
        for (Axml.Elem k : app.kids) {
            if (!"service".equals(k.name)) continue;
            String perm = k.text("permission");
            if (perm == null || !perm.contains("BIND_VPN_SERVICE")) continue;
            String n = k.text("name");
            if (n == null) continue;
            r.vpnService = n.startsWith(".") ? pkg + n : (n.indexOf('.') < 0 ? pkg + "." + n : n);
            for (Axml.Elem m : k.kids) {
                if (!"meta-data".equals(m.name)) continue;
                if ("android.net.VpnService.SUPPORTS_ALWAYS_ON".equals(m.text("name")) && "false".equals(m.text("value"))) r.alwaysOnOptOut = true;
            }
        }
    }

    // ------------------------------------------------------------------ layouts: every component that has an id
    private static void collect(ZipFile zf, Arsc arsc, List<Cand> out, Result r) {
        Set<String> seen = new HashSet<>();
        for (Arsc.Entry le : arsc.byId.values()) {
            if (!"layout".equals(le.type) || le.name == null || !seen.add(le.name)) continue;
            if (isLibLayout(le.name)) continue;
            ArrayList<String> paths = new ArrayList<>();
            for (String s : le.strings) if (s.endsWith(".xml")) paths.add(s);
            if (paths.isEmpty() || out.size() > 1500) continue;
            try {
                ZipEntry ze = zf.getEntry(paths.get(0));
                if (ze == null) continue;
                Axml x = Axml.parse(ApkZip.readAll(zf, ze));
                final String lname = le.name;
                final ArrayList<String> lp = paths;
                final Set<Integer> got = new HashSet<>();
                x.root.walk(el -> {
                    Axml.Attr ida = el.attr("id");
                    if (ida == null || ida.type != Axml.T_REF || !got.add(ida.data)) return;
                    String tl = el.name.toLowerCase(Locale.ROOT);
                    if (tl.contains("edittext")) return;
                    Cand c = new Cand();
                    Feat f = new Feat();
                    f.kind = C_CTL;
                    f.group = kindOfLayout(lname) + ": " + lname.replace('_', ' ');
                    f.viewId = ida.data;
                    f.idName = arsc.nameOf(ida.data);
                    f.tag = ApkAnalyzer.simple(el.name);
                    f.layout = lname;
                    f.layoutPaths = lp;
                    f.checkable = ApkAnalyzer.isToggle(el.name);
                    f.title = labelFor(el, arsc, f.idName);
                    String st = el.text("checked");
                    f.detail = f.tag + (f.checkable ? (", " + ("true".equals(st) ? "ON" : "OFF") + " by default") : "");
                    c.f = f;
                    c.interactive = ApkAnalyzer.isInteractiveTag(el.name) || el.attr("onClick") != null || "true".equals(el.text("clickable"));
                    out.add(c);
                });
            } catch (Throwable ignored) { }
        }
    }

    /** The name the user sees on screen; if the component has no text, its id turned into words ("btn_freeze_ghost" -> "Freeze ghost"). */
    private static String labelFor(Axml.Elem el, Arsc arsc, String idName) {
        for (String an : new String[]{"text", "contentDescription", "title", "hint"}) {
            Axml.Attr a = el.attr(an);
            if (a == null) continue;
            String s = null;
            if (a.type == Axml.T_STRING) s = a.str;
            else if (a.type == Axml.T_REF && arsc != null) s = arsc.firstString(a.data);
            if (s != null && !s.trim().isEmpty()) return s.trim().replace('\n', ' ');
        }
        return clean(idName);
    }

    static String clean(String idName) {
        if (idName == null || idName.isEmpty()) return "(no name)";
        String s = idName.replaceAll("([a-z0-9])([A-Z])", "$1_$2").toLowerCase(Locale.ROOT);
        List<String> w = new ArrayList<>();
        for (String p : s.split("[_\\s]+")) if (!p.isEmpty()) w.add(p);
        String[] pre = {"btn", "button", "iv", "img", "image", "tv", "txt", "text", "sw", "switch", "cb", "check", "checkbox", "ll", "rl", "fl", "id", "lyt", "layout", "ib", "toggle", "cv", "card"};
        while (w.size() > 1 && java.util.Arrays.asList(pre).contains(w.get(0))) w.remove(0);
        String[] post = {"button", "btn", "switch", "toggle", "view", "layout", "image", "icon"};
        while (w.size() > 1 && java.util.Arrays.asList(post).contains(w.get(w.size() - 1))) w.remove(w.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (String p : w) sb.append(sb.length() > 0 ? " " : "").append(p);
        String out = sb.toString();
        return out.isEmpty() ? idName : Character.toUpperCase(out.charAt(0)) + out.substring(1);
    }

    // ------------------------------------------------------------------ the code: Builder calls, and where each component is wired
    private static void countCalls(Context ctx, ZipFile zf, Result r, Set<Integer> ids, Set<Integer> wired, Map<Integer, List<String>> refs) throws Exception {
        List<String> dexes = VpnTransplant.dexNames(zf);
        int i = 0;
        for (String dn : dexes) {
            File tmp = new File(ctx.getCacheDir(), "fmenh_scan_" + (i++) + ".dex");
            try {
                VpnTransplant.extract(zf, dn, tmp);
                DexFile df = DexFileFactory.loadDexFile(tmp, Opcodes.getDefault());
                int here = 0;
                for (ClassDef cd : df.getClasses()) {
                    if (cd.getType().startsWith("Lcom/chanit/featuremerger/vpnenh/")) {
                        r.alreadyEnhanced = true;
                        r.shimDexName = dn;
                        continue;
                    }
                    if (cd.getType().startsWith("Lcom/chanit/featuremerger/vpnshim/")) continue;
                    for (Method m : cd.getMethods()) {
                        MethodImplementation mi = m.getImplementation();
                        if (mi == null) continue;
                        Set<Integer> mine = null;
                        boolean sets = false;
                        for (Instruction ins : mi.getInstructions()) {
                            if (!ids.isEmpty() && ins instanceof NarrowLiteralInstruction) {
                                int lit = ((NarrowLiteralInstruction) ins).getNarrowLiteral();
                                if (ids.contains(lit)) {
                                    if (mine == null) mine = new HashSet<>();
                                    mine.add(lit);
                                }
                            }
                            if (!(ins instanceof ReferenceInstruction)) continue;
                            Reference ref = ((ReferenceInstruction) ins).getReference();
                            if (!(ref instanceof MethodReference)) continue;
                            MethodReference mr = (MethodReference) ref;
                            String nm = mr.getName();
                            if (nm.startsWith("setOn") && nm.endsWith("Listener")) sets = true;
                            if (!BUILDER.equals(mr.getDefiningClass())) continue;
                            Integer c = r.calls.get(nm);
                            r.calls.put(nm, c == null ? 1 : c + 1);
                            here++;
                        }
                        if (mine != null) {
                            String where = shortClass(cd.getType()) + "." + m.getName();
                            for (int id : mine) {
                                List<String> l = refs.get(id);
                                if (l == null) {
                                    l = new ArrayList<>();
                                    refs.put(id, l);
                                }
                                if (l.size() < 6 && !l.contains(where)) l.add(where);
                                if (sets) wired.add(id);
                            }
                        }
                    }
                }
                r.callsByDex.put(dn, here);
            } catch (Throwable t) {
                r.notes.add(dn + " skipped: " + VpnTransplant.shortErr(t));
            } finally {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }
    }

    private static String shortClass(String type) {
        String s = type.startsWith("L") && type.endsWith(";") ? type.substring(1, type.length() - 1) : type;
        return s.replace('/', '.');
    }

    // ------------------------------------------------------------------ keep the real features, put them in a sensible order
    private static void finish(Result r, List<Cand> cands, Set<Integer> wired, Map<Integer, List<String>> refs) {
        List<Feat> keep = new ArrayList<>();
        for (Cand c : cands) {
            Feat f = c.f;
            f.wired = wired.contains(f.viewId);
            if (!c.interactive && !f.wired) continue;
            List<String> rf = refs.get(f.viewId);
            if (rf != null) f.codeRefs.addAll(rf);
            f.detail = f.detail + (f.wired ? "  \u00B7 has click code" : "") + (rf != null && !rf.isEmpty() ? "  \u00B7 " + rf.get(0) : "");
            keep.add(f);
        }
        Collections.sort(keep, new Comparator<Feat>() {
            @Override public int compare(Feat a, Feat b) {
                int ra = rank(a.group), rb = rank(b.group);
                if (ra != rb) return ra - rb;
                int c = a.group.compareTo(b.group);
                if (c != 0) return c;
                int ga = isGeneric(a) ? 1 : 0, gb = isGeneric(b) ? 1 : 0;
                return ga - gb; // stable sort keeps the layout order otherwise
            }
        });
        r.controls.addAll(keep);
    }

    private static int rank(String group) {
        if (group.startsWith("Window")) return 0;
        if (group.startsWith("Dialog")) return 1;
        if (group.startsWith("Screen")) return 2;
        if (group.startsWith("Tab")) return 3;
        if (group.startsWith("Menu")) return 4;
        if (group.startsWith("Settings")) return 5;
        return 6;
    }

    private static boolean isGeneric(Feat f) {
        String t = (f.title == null ? "" : f.title).toLowerCase(Locale.ROOT);
        String id = (f.idName == null ? "" : f.idName).toLowerCase(Locale.ROOT);
        for (String g : GENERIC) if (t.equals(g) || id.equals(g) || id.endsWith("_" + g) || id.startsWith(g + "_")) return true;
        return false;
    }

    // ------------------------------------------------------------------ menu items and settings screens
    private static void extras(ZipFile zf, Arsc arsc, Result r) {
        Set<String> seen = new HashSet<>();
        int files = 0;
        for (Arsc.Entry le : arsc.byId.values()) {
            if (le.name == null || r.controls.size() > 400 || files > 60) break;
            boolean menu = "menu".equals(le.type), xml = "xml".equals(le.type);
            if (!menu && !xml) continue;
            if (!seen.add(le.type + "/" + le.name) || isLibLayout(le.name)) continue;
            if (xml) {
                boolean skip = false;
                for (String p : SKIP_XML) if (le.name.startsWith(p)) skip = true;
                if (skip) continue;
            }
            String path = null;
            for (String s : le.strings) if (s.endsWith(".xml")) {
                path = s;
                break;
            }
            if (path == null) continue;
            try {
                ZipEntry ze = zf.getEntry(path);
                if (ze == null) continue;
                Axml x = Axml.parse(ApkZip.readAll(zf, ze));
                files++;
                final String lname = le.name;
                final boolean isMenu = menu;
                final boolean prefs = xml && x.root.name != null && x.root.name.contains("Preference");
                if (xml && !prefs) continue;
                x.root.walk(el -> {
                    String tag = el.name == null ? "" : el.name;
                    boolean item = isMenu ? "item".equals(tag) : (tag.contains("Preference") && !tag.contains("Screen") && !tag.contains("Category"));
                    if (!item) return;
                    Axml.Attr ta = el.attr("title");
                    if (ta == null) return;
                    String title = labelFor(el, arsc, "");
                    if (title.isEmpty() || "(no name)".equals(title)) return;
                    Feat f = new Feat();
                    f.kind = C_INFO;
                    f.group = (isMenu ? "Menu: " : "Settings: ") + lname.replace('_', ' ');
                    f.title = title;
                    f.tag = ApkAnalyzer.simple(tag);
                    f.checkable = tag.contains("Switch") || tag.contains("CheckBox");
                    String key = el.text("key");
                    f.idName = key == null ? "" : key;
                    f.detail = (isMenu ? "menu item" : "setting (" + f.tag + ")") + (key == null ? "" : ", key " + key);
                    r.controls.add(f);
                });
            } catch (Throwable ignored) { }
        }
    }

    private static boolean isLibLayout(String n) {
        String l = n.toLowerCase(Locale.ROOT);
        for (String p : LIB_LAYOUT) if (l.startsWith(p)) return true;
        return false;
    }

    private static String kindOfLayout(String n) {
        String l = n.toLowerCase(Locale.ROOT);
        if (l.startsWith("activity")) return "Window";
        if (l.contains("dialog") || l.contains("sheet") || l.contains("popup")) return "Dialog";
        if (l.startsWith("item") || l.startsWith("row") || l.contains("_item")) return "List item";
        if (l.startsWith("fragment")) return "Tab / page";
        return "Screen";
    }

    // ------------------------------------------------------------------ connection settings (advanced)
    private static void engine(Result r) {
        add(r, E_DNS, "DNS servers", r.calls("addDnsServer"),
                "Which DNS the VPN uses. Without one, the phone's normal DNS is used and can leak to your provider.");
        add(r, E_MTU, "Packet size (MTU)", r.calls("setMtu"),
                "Too big = slow / dropped connections on mobile data, too small = lower speed.");
        add(r, E_V6, "IPv6 handling", r.calls("addRoute") + r.calls("addAddress"),
                "IPv6 traffic can go around a VPN that only handles IPv4.");
        add(r, E_MET, "Metered flag", r.calls("setMetered"),
                "Whether Android treats the VPN as metered data (some apps then refuse big downloads).");
        Feat a = new Feat();
        a.group = "Connection settings (advanced)";
        a.kind = E_AON;
        a.title = "Always-on / kill switch support";
        a.detail = r.vpnService == null ? "No VPN service declared in the manifest."
                : (r.alwaysOnOptOut ? "Switched OFF by the developer (meta-data false)." : "Declared as supported.")
                + " Kill switch = Android's \"Block connections without VPN\".";
        a.count = r.alwaysOnOptOut ? 0 : 1;
        r.engine.add(a);
        add(r, E_START, "Tunnel start (establish)", r.calls("establish"),
                "The moment the VPN interface is created. Has the fix for an OLDER game version that reaches the lobby but not the match.");
        add(r, E_APPS, "Games (which apps use the VPN)", r.calls("addAllowedApplication") + r.calls("addDisallowedApplication"),
                "Add your game (also another version / private-server client with a different package). Picking a game that is already there rewrites it.");
        add(r, E_ROUTE, "Game server routes (private server IP)", r.calls("addRoute"),
                "Send the traffic of an older game version (it uses other servers and ports than the current one) through the VPN: a server IP, or everything.");
    }

    private static void add(Result r, String kind, String title, int n, String why) {
        Feat f = new Feat();
        f.group = "Connection settings (advanced)";
        f.kind = kind;
        f.title = title;
        f.count = n;
        f.detail = (n > 0 ? n + " place" + (n == 1 ? "" : "s") + " in the code. " : "Not set by the VPN. ") + why;
        r.engine.add(f);
    }

    // ------------------------------------------------------------------ text for the brief / chat
    public static String text(Result r) {
        StringBuilder sb = new StringBuilder();
        sb.append("VPN service: ").append(r.vpnService == null ? "?" : r.vpnService).append('\n');
        sb.append("Features (components the user sees):\n");
        String g = "";
        int n = 0;
        for (Feat f : r.controls) {
            if (n++ > 80) {
                sb.append("   ... (").append(r.controls.size() - 80).append(" more)\n");
                break;
            }
            if (!f.group.equals(g)) {
                g = f.group;
                sb.append(g).append('\n');
            }
            sb.append("   * ").append(f.title).append(" (").append(f.tag).append(f.idName == null || f.idName.isEmpty() ? "" : ", " + f.idName).append(")");
            if (!f.codeRefs.isEmpty()) sb.append(" code: ").append(f.codeRefs.get(0));
            sb.append('\n');
        }
        sb.append("Connection settings:\n");
        for (Feat f : r.engine) sb.append("- ").append(f.title).append(": ").append(f.count).append(" call(s)\n");
        return sb.toString();
    }
}
