package com.chanit.featuremerger;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.InputType;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.chanit.featuremerger.core.AiHelper;
import com.chanit.featuremerger.core.Instruct;
import com.chanit.featuremerger.core.Merger;
import com.chanit.featuremerger.core.Model;
import com.chanit.featuremerger.core.Store;
import com.chanit.featuremerger.core.VpnEnhancer;
import com.chanit.featuremerger.core.VpnFeatures;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * VPN enhancer + feature rewriter. Pick a VPN, see its features as a list (engine items and every screen with its
 * clickable controls), tap one, choose a ready-made improvement or write a short instruction, then build. The improved
 * version replaces the original behaviour inside the VPN app.
 */
public class EnhanceActivity extends AppCompatActivity {
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Store store;
    private final List<Model.Apk> vpns = new ArrayList<>();
    private Model.Apk cur;
    private VpnFeatures.Result scan;
    private final VpnEnhancer.Plan plan = EnhanceState.plan;
    private final List<String> notes = EnhanceState.notes;
    private EditText searchBox;
    private LinearLayout featBox, planBox, outBox;
    private Spinner spin;
    private LinearProgressIndicator bar;
    private TextView status, report, aiLine, logView, summaryView;
    private final List<String> logLines = new ArrayList<>();
    private CheckBox signBox;
    private MaterialButton btnBuild;
    private File built;
    private String lastReport = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);
        ScrollView sv = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(20), dp(16), dp(40));
        sv.addView(page);
        setContentView(sv);

        page.addView(text("VPN enhancer", 22, true));
        page.addView(text("1. Pick the VPN and press Scan.\n2. Tap a feature in the list and choose how to improve it (or write a short instruction).\n"
                + "3. Press Build: the improved version replaces the original behaviour inside the VPN.", 13, false));

        aiLine = text("", 12, true);
        page.addView(aiLine);
        page.addView(btn("AI setup", v -> aiSetup()));
        page.addView(btn("Chat with AI", v -> startActivity(new Intent(this, AiChatActivity.class))));
        refreshAi();

        loadVpns();
        spin = new Spinner(this);
        List<String> names = new ArrayList<>();
        for (Model.Apk a : vpns) names.add(a.label + (a.vpn ? "  (VPN)" : ""));
        spin.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        page.addView(spin);
        MaterialButton scanBtn = btn("Scan features", v -> doScan());
        page.addView(scanBtn);
        page.addView(btn("Auto adapt everything (AI)", v -> autoAdapt(true)));
        page.addView(text("One tap: the app scans the VPN, the AI picks every setting by itself (your game, routes, packet size, IPv6 ...), "
                + "builds the APK, checks it, and if the check fails it shows the AI the report and tries again. Needs the AI key (AI setup).", 11, false));
        page.addView(btn("Fix: old game version (lobby works, no match)", v -> quickFix()));
        page.addView(text("One tap, no AI and no key needed: scans the VPN, adds the old-version fix (route everything of the game, MTU 1380), "
                + "builds the APK and checks it. Use it when an older game version reaches the lobby but the match never starts.", 11, false));
        if (vpns.isEmpty()) page.addView(text("No apps yet. Add the VPN APK in the Apps tab first.", 13, false));

        status = text("", 12, false);
        page.addView(status);
        bar = new LinearProgressIndicator(this);
        bar.setMax(100);
        bar.setVisibility(View.GONE);
        page.addView(bar);

        page.addView(text("What is happening", 14, true));
        logView = text("Nothing yet. Scan a VPN or ask the AI and every step shows up here.", 11, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        page.addView(logView);
        summaryView = text("", 13, true);
        page.addView(summaryView);

        searchBox = new EditText(this);
        searchBox.setHint("Search a feature (for example: freeze)");
        searchBox.setSingleLine(true);
        searchBox.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }

            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }

            @Override public void afterTextChanged(android.text.Editable e) { renderFeatures(); }
        });
        page.addView(searchBox);
        featBox = box();
        page.addView(featBox);

        page.addView(text("Your changes", 16, true));
        planBox = box();
        page.addView(planBox);
        signBox = new CheckBox(this);
        signBox.setText("Sign with the FM key (leave off if you sign with MT Manager)");
        page.addView(signBox);
        btnBuild = btn("Build enhanced APK", v -> build());
        page.addView(btnBuild);
        page.addView(btn("Copy brief for Claude", v -> copy("brief", brief(), "Brief copied. Paste it in the chat.")));

        outBox = box();
        page.addView(outBox);
        report = text("", 11, false);
        report.setTypeface(Typeface.MONOSPACE);
        report.setTextIsSelectable(true);
        page.addView(report);
        renderPlan();
    }

    private void loadVpns() {
        List<Model.Apk> all = new ArrayList<>();
        for (File f : store.listApks()) {
            Model.Apk a = store.loadCached(f);
            if (a != null) all.add(a);
        }
        for (Model.Apk a : all) if (a.vpn) vpns.add(a);
        for (Model.Apk a : all) if (!a.vpn) vpns.add(a);
    }

    // ------------------------------------------------------------------ scan + list
    private void doScan() {
        if (vpns.isEmpty()) return;
        cur = vpns.get(Math.max(0, spin.getSelectedItemPosition()));
        plan.vpn = cur;
        plan.ops.clear();
        notes.clear();
        renderPlan();
        outBox.removeAllViews();
        report.setText("");
        featBox.removeAllViews();
        logClear();
        logAdd("\u2192 Reading " + cur.label + " (code and screens)");
        bar.setVisibility(View.VISIBLE);
        bar.setIndeterminate(true);
        status.setText("Reading " + cur.label + " ...");
        final Model.Apk target = cur;
        exec.execute(() -> {
            VpnFeatures.Result r = VpnFeatures.scan(this, new File(target.path));
            ui.post(() -> {
                scan = r;
                EnhanceState.apk = target;
                EnhanceState.scan = r;
                EnhanceState.focus = null;
                bar.setVisibility(View.GONE);
                bar.setIndeterminate(false);
                status.setText(r.controls.size() + " features and " + r.engine.size() + " connection settings found."
                        + (r.alreadyEnhanced ? "\nThis VPN was enhanced before: building again rewrites the old settings." : "")
                        + (r.notes.isEmpty() ? "" : "\n" + join(r.notes)));
                renderFeatures();
                logStep("Listing features");
                logDone("Done: found " + r.engine.size() + " engine items and " + r.controls.size() + " clickable controls in " + target.label + "."
                        + "\nNext: tap a feature in the list and choose how to improve it.");
            });
        });
    }

    // ------------------------------------------------------------------ auto adapt (AI autopilot)
    private boolean autoBusy;

    /** Installed apps the AI may choose the game from: "label [package]", user apps only, at most 150. */
    private String installedAppsText(String skipPkg) {
        final PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        java.util.Collections.sort(apps, (x, y) -> String.valueOf(pm.getApplicationLabel(x)).compareToIgnoreCase(String.valueOf(pm.getApplicationLabel(y))));
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (ApplicationInfo a : apps) {
            if ((a.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (a.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0) continue;
            if (a.packageName.equals(getPackageName()) || a.packageName.equals(skipPkg)) continue;
            sb.append(pm.getApplicationLabel(a)).append(" [").append(a.packageName).append("]\n");
            if (++n >= 150 || sb.length() > 7000) break;
        }
        return sb.toString();
    }

    /** Runs r on the main thread and waits until it is done (so the worker thread never reads a half-changed plan). */
    private void onUiWait(final Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            r.run();
            return;
        }
        final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
        ui.post(() -> {
            try {
                r.run();
            } finally {
                latch.countDown();
            }
        });
        try {
            latch.await();
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    private static boolean hasKind(List<VpnEnhancer.Op> ops, String kind) {
        for (VpnEnhancer.Op o : ops) if (o.ctl == null && kind.equals(o.kind)) return true;
        return false;
    }

    private void autoAdapt(final boolean useAi) {
        if (autoBusy) return;
        if (vpns.isEmpty()) {
            Toast.makeText(this, "Add the VPN APK in the Apps tab first", Toast.LENGTH_LONG).show();
            return;
        }
        if (useAi && !AiHelper.load(this).ready()) {
            Toast.makeText(this, "Pehle AI key set karo (AI setup), phir Auto adapt dabao", Toast.LENGTH_LONG).show();
            aiSetup();
            return;
        }
        cur = vpns.get(Math.max(0, spin.getSelectedItemPosition()));
        final Model.Apk target = cur;
        final boolean sign = signBox.isChecked();
        final String apps = installedAppsText(target.pkg);
        autoBusy = true;
        plan.vpn = target;
        plan.ops.clear();
        notes.clear();
        renderPlan();
        outBox.removeAllViews();
        report.setText("");
        logClear();
        btnBuild.setEnabled(false);
        bar.setVisibility(View.VISIBLE);
        bar.setIndeterminate(true);
        status.setText(useAi ? "Auto adapt: working ..." : "Old-version fix: working ...");
        logAdd("\u2192 Reading " + target.label + " (code and screens)");
        exec.execute(() -> autoRun(target, apps, sign, useAi));
    }

    private void autoRun(final Model.Apk target, final String apps, final boolean sign, final boolean useAi) {
        final StringBuilder story = new StringBuilder();
        boolean ok = false;
        File out = null;
        String rep = "";
        try {
            final VpnFeatures.Result r = VpnFeatures.scan(this, new File(target.path));
            EnhanceState.apk = target;
            EnhanceState.scan = r;
            EnhanceState.focus = null;
            ui.post(() -> {
                scan = r;
                renderFeatures();
                logStep("Scan done: " + r.controls.size() + " features, " + r.engine.size() + " connection settings");
            });
            String lastReport = "";
            for (int round = 1; round <= (useAi ? 2 : 1); round++) {
                final int rd = round;
                ui.post(() -> logStep(useAi ? "Round " + rd + ": the AI decides the settings" : "Adding the old-version fix"));
                List<VpnEnhancer.Op> ops = new ArrayList<>();
                String aiLineText;
                if (!useAi) {
                    aiLineText = "";
                } else {
                    try {
                        AiHelper.Answer a = AiHelper.auto(this, EnhanceState.context(), apps, lastReport, line -> ui.post(() -> logAdd(line)));
                        ops.addAll(a.ops);
                        aiLineText = a.summary.isEmpty() ? "" : a.summary;
                    } catch (AiHelper.AiException e) {
                        if (round > 1) throw e;
                        aiLineText = "AI nahi chala (" + e.getMessage() + "). Standard old-version fix se build kiya.";
                        final String msg = e.getMessage();
                        ui.post(() -> logAdd("\u2718 " + msg + "  \u2192 using the standard old-version fix instead"));
                    }
                }
                if (round == 1) {
                    // the user's case is always "old version: lobby ok, match not": make sure the standard fix is in
                    final List<VpnEnhancer.Op> base = Instruct.matchFix().ops;
                    for (VpnEnhancer.Op o : base) {
                        if (!hasKind(ops, o.kind)) {
                            ops.add(o);
                            final String lbl = o.label;
                            ui.post(() -> logAdd("+ standard fix added: " + lbl));
                        }
                    }
                }
                if (aiLineText.length() > 0) story.append(aiLineText).append('\n');
                final List<VpnEnhancer.Op> use = ops;
                onUiWait(() -> {
                    plan.ops.clear();
                    EnhanceState.addOps(use);
                    plan.vpn = target;
                    plan.sign = sign;
                    renderPlan();
                });
                ui.post(() -> logStep("Round " + rd + ": building and checking (" + use.size() + " change(s))"));
                try {
                    VpnEnhancer.Result res = VpnEnhancer.run(this, plan, new Merger.Sink() {
                        @Override public void step(int pct, String msg) {
                            ui.post(() -> {
                                bar.setIndeterminate(false);
                                bar.setProgress(pct);
                                status.setText(msg);
                                logStep(msg);
                            });
                        }

                        @Override public void log(String line) { }
                    });
                    ok = res.ok;
                    out = res.out;
                    rep = res.report;
                } catch (Throwable t) {
                    ok = false;
                    out = null;
                    StringBuilder sb = new StringBuilder("[RESULT] FAILED\n").append(t).append('\n');
                    for (StackTraceElement e : t.getStackTrace()) {
                        sb.append("  at ").append(e).append('\n');
                        if (sb.length() > 1800) break;
                    }
                    rep = sb.toString();
                }
                if (ok) break;
                lastReport = rep;
                if (useAi && round == 1) ui.post(() -> logAdd("\u2718 Build or check failed. Showing the report to the AI for a second try."));
            }
        } catch (final Throwable t) {
            ok = false;
            out = null;
            rep = "[RESULT] FAILED\n" + t + "\n";
            story.append(t.getMessage() == null ? t.toString() : t.getMessage()).append('\n');
        }
        final boolean fOk = ok;
        final File fOut = out;
        final String fRep = rep;
        ui.post(() -> {
            autoBusy = false;
            done(fOk, fOut, fRep);
            if (story.length() > 0) summaryView.setText(summaryView.getText() + "\n\nAI: " + story.toString().trim());
        });
    }

    /** One tap: scan the VPN, add the old-version fix, build and check it. No AI and no key needed. */
    private void quickFix() {
        autoAdapt(false);
    }

    private void renderFeatures() {
        featBox.removeAllViews();
        if (scan == null) return;
        String q = searchBox == null ? "" : searchBox.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
        int shown = 0;
        StringBuilder head = new StringBuilder();
        featBox.addView(text("Features you see in the VPN (" + scan.controls.size() + ")", 16, true));
        String g = "";
        for (VpnFeatures.Feat f : scan.controls) {
            if (!q.isEmpty() && !(f.title + " " + f.idName + " " + f.group).toLowerCase(java.util.Locale.ROOT).contains(q)) continue;
            if (!f.group.equals(g)) {
                g = f.group;
                featBox.addView(text(g, 13, true));
            }
            featBox.addView(row(f));
            shown++;
        }
        if (scan.controls.isEmpty()) featBox.addView(text("No clickable components were found in the resources. A menu drawn in code (floating menu) is not listed here; ask the AI chat about it.", 12, false));
        else if (shown == 0) featBox.addView(text("No feature matches \"" + q + "\".", 12, false));
        featBox.addView(text("Connection settings (advanced)", 16, true));
        for (VpnFeatures.Feat f : scan.engine) featBox.addView(row(f));
    }

    private View row(final VpnFeatures.Feat f) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(8), dp(8), dp(8), dp(8));
        TypedValue tv = new TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) r.setBackgroundResource(tv.resourceId);
        r.addView(text(f.title, 14, true));
        TextView d = text(f.detail, 12, false);
        d.setAlpha(0.75f);
        r.addView(d);
        r.setOnClickListener(v -> openFeature(f));
        return r;
    }

    // ------------------------------------------------------------------ one feature: recipes + own words
    private void openFeature(final VpnFeatures.Feat f) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        EnhanceState.focus = f;
        box.addView(text(f.detail, 12, false));
        if (!f.codeRefs.isEmpty()) box.addView(text("Its code: " + join(f.codeRefs), 11, false));
        final AlertDialog[] dlg = new AlertDialog[1];
        List<Instruct.Recipe> rs = Instruct.recipes(f);
        if (rs.isEmpty()) box.addView(text("No ready-made improvement for this one. Write what you want below, it goes into the brief.", 12, true));
        for (final Instruct.Recipe r : rs) {
            box.addView(btn(r.label, v -> {
                addOps(r.ops);
                dlg[0].dismiss();
            }));
        }
        if (VpnFeatures.E_APPS.equals(f.kind)) {
            box.addView(btn("Pick installed game(s)", v -> {
                dlg[0].dismiss();
                pickGames();
            }));
        }
        if (VpnFeatures.E_ROUTE.equals(f.kind)) {
            box.addView(btn("Enter private server IP(s)", v -> {
                dlg[0].dismiss();
                askServerIps();
            }));
        }
        box.addView(btn("Chat with AI about this feature", v -> {
            dlg[0].dismiss();
            startActivity(new Intent(this, AiChatActivity.class));
        }));
        final EditText et = new EditText(this);
        et.setHint("Or write it, e.g. \"dns google, mtu 1350\"");
        et.setMinLines(2);
        box.addView(et);
        box.addView(btn("Ask AI (researches, picks best settings)", v -> {
            askAi(f, et.getText().toString());
            dlg[0].dismiss();
        }));
        dlg[0] = new MaterialAlertDialogBuilder(this)
                .setTitle(f.title)
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add my words", (d, w) -> {
                    Instruct.Out o = Instruct.parse(f, et.getText().toString());
                    if (!o.ops.isEmpty()) {
                        addOps(o.ops);
                        Toast.makeText(this, "Understood: " + join(o.understood), Toast.LENGTH_LONG).show();
                    } else if (!o.leftover.isEmpty()) {
                        if (AiHelper.load(this).ready()) {
                            askAi(f, o.leftover);
                        } else {
                            notes.add(f.title + ": " + o.leftover);
                            Toast.makeText(this, "Not a ready-made improvement. Saved in the brief. Set up the AI helper to let it handle this.", Toast.LENGTH_LONG).show();
                        }
                    }
                    renderPlan();
                }).create();
        dlg[0].show();
    }

    private void addOps(List<VpnEnhancer.Op> ops) {
        EnhanceState.addOps(ops);
        renderPlan();
    }

    private void renderPlan() {
        planBox.removeAllViews();
        if (plan.ops.isEmpty()) planBox.addView(text("Nothing chosen yet.", 12, false));
        for (final VpnEnhancer.Op o : new ArrayList<>(plan.ops)) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            TextView t = text(o.label, 13, false);
            r.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            r.addView(btn("\u2715", v -> {
                plan.ops.remove(o);
                renderPlan();
            }));
            planBox.addView(r);
        }
        for (String n : notes) planBox.addView(text("For Claude: " + n, 12, false));
        if (btnBuild != null) btnBuild.setEnabled(!plan.ops.isEmpty() && cur != null);
    }

    // ------------------------------------------------------------------ games and private server
    /** Lists the apps installed on this phone (also another version or a private-server client of the same game) to tick. */
    private void pickGames() {
        final PackageManager pm = getPackageManager();
        final List<String> pkgs = new ArrayList<>(), labels = new ArrayList<>();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);
        java.util.Collections.sort(apps, (x, y) -> String.valueOf(pm.getApplicationLabel(x)).compareToIgnoreCase(String.valueOf(pm.getApplicationLabel(y))));
        for (ApplicationInfo a : apps) {
            if ((a.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (a.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0) continue;
            if (a.packageName.equals(getPackageName())) continue;
            pkgs.add(a.packageName);
            labels.add(pm.getApplicationLabel(a) + "\n" + a.packageName);
        }
        final boolean[] on = new boolean[pkgs.size()];
        new MaterialAlertDialogBuilder(this)
                .setTitle("Tick your game(s)")
                .setMultiChoiceItems(labels.toArray(new String[0]), on, (d, i, c) -> on[i] = c)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Type package names", (d, w) -> typePackages())
                .setPositiveButton("Add", (d, w) -> {
                    StringBuilder sb = new StringBuilder();
                    int n = 0;
                    for (int i = 0; i < on.length && n < 6; i++) if (on[i]) {
                        sb.append(sb.length() > 0 ? "," : "").append(pkgs.get(i));
                        n++;
                    }
                    if (sb.length() == 0) {
                        Toast.makeText(this, "Nothing ticked", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    addOps(java.util.Collections.singletonList(Instruct.appsOp(sb.toString())));
                }).show();
    }

    private void typePackages() {
        final EditText et = new EditText(this);
        et.setHint("com.game.one, com.game.private");
        new MaterialAlertDialogBuilder(this).setTitle("Game package names").setView(et)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", (d, w) -> {
                    String ok = Instruct.cleanPackages(et.getText().toString());
                    if (ok.isEmpty()) Toast.makeText(this, "No valid package name found", Toast.LENGTH_LONG).show();
                    else addOps(java.util.Collections.singletonList(Instruct.appsOp(ok)));
                }).show();
    }

    private void askServerIps() {
        final EditText et = new EditText(this);
        et.setHint("203.0.113.10  or  203.0.113.0/24");
        new MaterialAlertDialogBuilder(this).setTitle("Private server IP(s)")
                .setMessage("IP addresses only (not a website name). They are sent through the VPN when it starts.")
                .setView(et)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", (d, w) -> {
                    String ok = Instruct.cleanCidrs(et.getText().toString());
                    if (ok.isEmpty()) Toast.makeText(this, "No valid IPv4 address found", Toast.LENGTH_LONG).show();
                    else addOps(java.util.Collections.singletonList(Instruct.routeOp(ok)));
                }).show();
    }

    // ------------------------------------------------------------------ AI helper
    private void refreshAi() {
        AiHelper.Config c = AiHelper.load(this);
        AiHelper.Prov pv = AiHelper.prov(c.provider);
        if (!c.ready()) {
            aiLine.setText("AI helper: not set up. Tap AI setup, pick a provider and press its \"Get key\" button (free ones take about a minute).");
        } else {
            aiLine.setText("AI helper: " + pv.label + (pv.free ? " (free)" : " (paid)") + "  \u00B7  " + AiHelper.usedToday(this) + "/" + c.cap + " asks today");
        }
    }

    private void aiSetup() {
        final AiHelper.Config cur = AiHelper.load(this);
        final String[] chosen = {cur.provider};
        final List<RadioButton> radios = new ArrayList<>();
        final List<String> ids = new ArrayList<>();
        final List<TextView> notes = new ArrayList<>();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(text("Pick a provider and press \"Get key\" next to it. It opens the page where the key is made. Copy the key, come back and paste it below. Free providers stop by themselves when their free limit is used up.", 12, false));

        final EditText key = new EditText(this);
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        final Runnable refresh = () -> {
            for (int i = 0; i < radios.size(); i++) radios.get(i).setChecked(ids.get(i).equals(chosen[0]));
            AiHelper.Prov pv = AiHelper.prov(chosen[0]);
            String saved = cur.keys.get(chosen[0]);
            key.setHint(saved != null && saved.length() > 0 ? pv.label + " key saved. Leave empty to keep it." : "Paste the " + pv.label + " key here");
        };
        for (final AiHelper.Prov pv : AiHelper.PROVIDERS) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            final RadioButton rb = new RadioButton(this);
            rb.setText(pv.label);
            rb.setOnClickListener(v -> {
                chosen[0] = pv.id;
                key.setText("");
                refresh.run();
            });
            radios.add(rb);
            ids.add(pv.id);
            left.addView(rb);
            TextView nt = text(pv.note, 11, false);
            nt.setPadding(dp(32), 0, 0, dp(2));
            nt.setAlpha(0.75f);
            left.addView(nt);
            row.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(btn(pv.free ? "Get free key" : "Get key", v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(pv.keyUrl)))));
            box.addView(row);
        }
        box.addView(key);
        final EditText model = new EditText(this);
        model.setHint("Model name (leave empty = automatic, newest working one)");
        model.setText(cur.model);
        box.addView(model);
        final EditText cap = new EditText(this);
        cap.setHint("Asks per day (default 20)");
        cap.setText(String.valueOf(cur.cap));
        cap.setInputType(InputType.TYPE_CLASS_NUMBER);
        box.addView(cap);
        refresh.run();
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        new MaterialAlertDialogBuilder(this)
                .setTitle("AI helper")
                .setView(sv)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    try {
                        AiHelper.Config n = new AiHelper.Config();
                        n.keys.putAll(cur.keys);
                        n.provider = chosen[0];
                        String k = key.getText().toString().trim();
                        if (!k.isEmpty()) n.keys.put(n.provider, k);
                        String have = n.keys.get(n.provider);
                        n.key = have == null ? "" : have;
                        n.model = model.getText().toString().trim();
                        try {
                            n.cap = Math.max(1, Math.min(500, Integer.parseInt(cap.getText().toString().trim())));
                        } catch (Exception e) {
                            n.cap = 20;
                        }
                        AiHelper.save(this, n);
                        Toast.makeText(this, n.ready() ? AiHelper.prov(n.provider).label + " saved" : "Key is missing for " + AiHelper.prov(n.provider).label, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Could not save: " + e, Toast.LENGTH_LONG).show();
                    }
                    refreshAi();
                }).show();
    }

    // ------------------------------------------------------------------ live log + summary ("what is done, what is next")
    private void logClear() {
        logLines.clear();
        summaryView.setText("");
        logView.setText("");
    }

    private void logAdd(String line) {
        logLines.add(line);
        while (logLines.size() > 40) logLines.remove(0);
        StringBuilder sb = new StringBuilder();
        for (String l : logLines) sb.append(l).append('\n');
        logView.setText(sb.toString().trim());
    }

    /** A new step: the previous "in progress" line gets its tick. */
    private void logStep(String msg) {
        if (!logLines.isEmpty()) {
            int i = logLines.size() - 1;
            if (logLines.get(i).startsWith("\u2192 ")) logLines.set(i, "\u2714 " + logLines.get(i).substring(2));
        }
        logAdd("\u2192 " + msg);
    }

    private void logDone(String summary) {
        if (!logLines.isEmpty()) {
            int i = logLines.size() - 1;
            if (logLines.get(i).startsWith("\u2192 ")) logLines.set(i, "\u2714 " + logLines.get(i).substring(2));
            logAdd("");
        }
        summaryView.setText(summary);
    }

    private void askAi(final VpnFeatures.Feat f, final String words) {
        if (!AiHelper.load(this).ready()) {
            aiSetup();
            return;
        }
        logClear();
        bar.setVisibility(View.VISIBLE);
        bar.setIndeterminate(true);
        status.setText("AI is working ...");
        final Model.Apk apk = cur;
        final VpnFeatures.Result sc = scan;
        exec.execute(() -> {
            try {
                AiHelper.Answer a = AiHelper.ask(this, apk, f, sc, words, line -> ui.post(() -> logAdd(line)));
                ui.post(() -> {
                    bar.setVisibility(View.GONE);
                    bar.setIndeterminate(false);
                    status.setText("AI answered.");
                    logDone("Done: " + a.model + " suggested " + a.ops.size() + " change(s) for \"" + f.title + "\"."
                            + (a.ops.isEmpty() ? "\nNext: rephrase your request, or pick a ready-made improvement." : "\nNext: check the suggestion and press Add to plan, then Build."));
                    refreshAi();
                    showAnswer(f, a);
                });
            } catch (AiHelper.AiException e) {
                ui.post(() -> {
                    bar.setVisibility(View.GONE);
                    bar.setIndeterminate(false);
                    status.setText(e.getMessage());
                    logAdd("\u2718 " + e.getMessage());
                    logDone("Stopped: " + e.getMessage() + "\nNext: fix this (AI setup) or pick a ready-made improvement.");
                    refreshAi();
                });
            } catch (Throwable t) {
                ui.post(() -> {
                    bar.setVisibility(View.GONE);
                    bar.setIndeterminate(false);
                    status.setText("AI error: " + t);
                    logAdd("\u2718 " + t);
                    logDone("Stopped with an error. Copy the log above and send it to Claude.");
                });
            }
        });
    }

    private void showAnswer(final VpnFeatures.Feat f, final AiHelper.Answer a) {
        StringBuilder sb = new StringBuilder();
        if (!a.summary.isEmpty()) sb.append(a.summary).append("\n\n");
        if (a.ops.isEmpty()) sb.append("No setting could be made from this.\n");
        else {
            sb.append("Changes:\n");
            for (VpnEnhancer.Op o : a.ops) sb.append("\u2022 ").append(o.label).append('\n');
        }
        sb.append("\nWeb research: ").append(a.searched ? "yes" : "no (the AI answered from its own knowledge)");
        for (String s : a.sources) sb.append("\n  ").append(s);
        if (!a.dropped.isEmpty()) sb.append("\nIgnored: ").append(join(a.dropped));
        sb.append("\n(model: ").append(a.model).append(")");
        MaterialAlertDialogBuilder d = new MaterialAlertDialogBuilder(this).setTitle("AI suggestion: " + f.title)
                .setMessage(sb.toString()).setNegativeButton("Cancel", null);
        if (!a.ops.isEmpty()) d.setPositiveButton("Add to plan", (x, w) -> addOps(a.ops));
        d.show();
    }

    // ------------------------------------------------------------------ build
    private void build() {
        if (cur == null || plan.ops.isEmpty()) return;
        plan.vpn = cur;
        plan.sign = signBox.isChecked();
        btnBuild.setEnabled(false);
        logClear();
        logAdd("\u2192 Building the enhanced APK (" + plan.ops.size() + " change(s))");
        bar.setVisibility(View.VISIBLE);
        bar.setProgress(0);
        outBox.removeAllViews();
        report.setText("");
        exec.execute(() -> {
            try {
                VpnEnhancer.Result r = VpnEnhancer.run(this, plan, new Merger.Sink() {
                    @Override public void step(int pct, String msg) {
                        ui.post(() -> {
                            bar.setProgress(pct);
                            status.setText(msg);
                            logStep(msg);
                        });
                    }

                    @Override public void log(String line) { }
                });
                ui.post(() -> done(r.ok, r.out, r.report));
            } catch (Throwable t) {
                StringBuilder sb = new StringBuilder("[RESULT] FAILED\n").append(t).append('\n');
                for (StackTraceElement e : t.getStackTrace()) {
                    sb.append("  at ").append(e).append('\n');
                    if (sb.length() > 1800) break;
                }
                ui.post(() -> done(false, null, sb.toString()));
            }
        });
    }

    private void done(boolean ok, File out, String rep) {
        bar.setVisibility(View.GONE);
        btnBuild.setEnabled(true);
        built = out;
        lastReport = rep;
        status.setText(ok ? "Done." : "Problem, see the report.");
        logDone(ok ? "Done: enhanced APK built, helper added, checks passed.\nNext: " + (plan.sign ? "uninstall the old VPN app and install the new one." : "sign it with MT Manager, uninstall the old VPN app, install the signed one.")
                : "Stopped: the build or its checks failed.\nNext: tap Copy report and send it to Claude.");
        report.setText(rep);
        outBox.removeAllViews();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(btn("Copy report", v -> copy("report", lastReport, "Report copied. Paste it in the chat.")));
        if (out != null) row.addView(btn("Share / save APK", v -> share()));
        outBox.addView(row);
        if (out != null) outBox.addView(text("File: " + out.getAbsolutePath(), 11, false));
    }

    private void share() {
        if (built == null) return;
        Uri u = FileProvider.getUriForFile(this, getPackageName() + ".files", built);
        Intent i = new Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive")
                .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share enhanced APK"));
    }

    // ------------------------------------------------------------------ brief for Claude
    private String brief() {
        StringBuilder sb = new StringBuilder();
        sb.append("VPN ENHANCER BRIEF\n");
        if (cur != null) sb.append("App: ").append(cur.label).append(" (").append(cur.pkg).append(")\n");
        if (scan != null) sb.append(VpnFeatures.text(scan));
        sb.append("\nChanges chosen:\n");
        if (plan.ops.isEmpty()) sb.append("(none)\n");
        for (VpnEnhancer.Op o : plan.ops) sb.append("- ").append(o.label).append('\n');
        sb.append("\nMy instructions (not covered by the ready-made improvements):\n");
        if (notes.isEmpty()) sb.append("(none)\n");
        for (String n : notes) sb.append("- ").append(n).append('\n');
        sb.append("\nTask: research the best way to do this, and add it to the enhancer as a new improvement for this feature.\n");
        return sb.toString();
    }

    private void copy(String label, String s, String msg) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, s));
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ view helpers
    private static String join(List<String> l) {
        StringBuilder b = new StringBuilder();
        for (String s : l) b.append(b.length() > 0 ? "; " : "").append(s);
        return b.toString();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, dp(6), 0, dp(2));
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    private LinearLayout box() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private MaterialButton btn(String label, View.OnClickListener l) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override protected void onResume() {
        super.onResume();
        renderPlan();
        refreshAi();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
    }
}
