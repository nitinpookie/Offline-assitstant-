package com.chanit.featuremerger.vpnshim;

import android.app.usage.UsageEvents;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.view.accessibility.AccessibilityEvent;

/**
 * Runtime helper that Feature Merger injects into a patched VPN app.
 *
 * Mode 1 (the VPN already has a per-app list): every call of VpnService.Builder.addAllowedApplication(pkg) inside
 * the VPN app is redirected to add(): it still does the original call, and when pkg is one of the reference games
 * it also allows the extra (target) packages.
 *
 * Mode 2 (the VPN has NO addAllowedApplication call at all, flag "I"): every Builder.establish() call is redirected
 * to establish(). Right before the tunnel is started it injects addAllowedApplication(pkg) for the reference games
 * and the target games. Builder.addDisallowedApplication() calls are switched off (dis()), because Android does not
 * allow an exclude list and an allow list on the same builder.
 *
 * The CFG text below is rewritten inside the patched copy of this class ("refs;targets" or "refs;targets;I").
 * Keep it as is.
 */
public final class FmVpn {
    private FmVpn() {}

    private static final String CFG = "@FMV{################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################}@";
    private static String[] refs = new String[0];
    private static String[] targets = new String[0];
    private static boolean inject, alias;
    private static boolean parsed;

    // ---- mode 1
    public static VpnService.Builder add(VpnService.Builder b, String pkg) throws Exception {
        VpnService.Builder r = b.addAllowedApplication(pkg);
        try {
            parse();
            if (targets.length > 0 && matches(pkg)) {
                for (String t : targets) {
                    try {
                        b.addAllowedApplication(t);
                    } catch (Throwable ignored) {
                        // target app not installed: the original behaviour must not break
                    }
                }
            }
        } catch (Throwable ignored) {
            // never break the VPN because of the helper
        }
        return r;
    }

    // ---- mode 2
    public static ParcelFileDescriptor establish(VpnService.Builder b) {
        try {
            parse();
            if (inject) {
                for (String p : refs) allow(b, p);
                for (String t : targets) allow(b, t);
            }
        } catch (Throwable ignored) {
            // never break the VPN because of the helper
        }
        return b.establish();
    }

    public static VpnService.Builder dis(VpnService.Builder b, String pkg) throws Exception {
        try {
            parse();
            if (inject) return b; // exclude list switched off: it cannot be combined with the allow list
        } catch (Throwable ignored) {
            // fall through to the original behaviour
        }
        return b.addDisallowedApplication(pkg);
    }

    private static void allow(VpnService.Builder b, String pkg) {
        try {
            b.addAllowedApplication(pkg);
        } catch (Throwable ignored) {
            // app not installed: skip it, the others still work
        }
    }

    private static boolean matches(String pkg) {
        if (refs.length == 0) return true;
        if (pkg == null) return false;
        for (String s : refs) if (s.equals(pkg)) return true;
        return false;
    }

    private static synchronized void parse() {
        if (parsed) return;
        parsed = true;
        String c = CFG;
        int s = c.indexOf('{');
        int e = c.lastIndexOf('}');
        String body = (s >= 0 && e > s) ? c.substring(s + 1, e) : "";
        body = body.replace("#", "").trim();
        String[] part = body.split(";", -1);
        refs = split(part.length > 0 ? part[0] : "");
        targets = split(part.length > 1 ? part[1] : "");
        String flags = part.length > 2 ? part[2].trim() : "";
        inject = flags.indexOf('I') >= 0;
        alias = flags.indexOf('A') >= 0;
    }

    // ---- game alias: the new game is treated by the VPN exactly like its reference game
    // (the VPN's own launch / "is it installed" / "which app is in front" checks of the reference game also work for the new one)

    /** getLaunchIntentForPackage(ref): when the reference game is not installed, the new game is started instead. */
    public static Intent launch(PackageManager pm, String pkg) {
        Intent i = pm.getLaunchIntentForPackage(pkg);
        try {
            parse();
            if (i == null && alias && isRef(pkg)) {
                for (String t : targets) {
                    i = pm.getLaunchIntentForPackage(t);
                    if (i != null) break;
                }
            }
        } catch (Throwable ignored) {
            // original behaviour
        }
        return i;
    }

    public static PackageInfo pkgInfo(PackageManager pm, String pkg, int flags) throws PackageManager.NameNotFoundException {
        try {
            return pm.getPackageInfo(pkg, flags);
        } catch (PackageManager.NameNotFoundException e) {
            try {
                parse();
                if (alias && isRef(pkg)) {
                    for (String t : targets) {
                        try {
                            return pm.getPackageInfo(t, flags);
                        } catch (PackageManager.NameNotFoundException ignored) {
                            // try the next one
                        }
                    }
                }
            } catch (Throwable ignored) {
                // original behaviour
            }
            throw e;
        }
    }

    public static ApplicationInfo appInfo(PackageManager pm, String pkg, int flags) throws PackageManager.NameNotFoundException {
        try {
            return pm.getApplicationInfo(pkg, flags);
        } catch (PackageManager.NameNotFoundException e) {
            try {
                parse();
                if (alias && isRef(pkg)) {
                    for (String t : targets) {
                        try {
                            return pm.getApplicationInfo(t, flags);
                        } catch (PackageManager.NameNotFoundException ignored) {
                            // try the next one
                        }
                    }
                }
            } catch (Throwable ignored) {
                // original behaviour
            }
            throw e;
        }
    }

    /** the app that is in front (usage events): the new game is reported as its reference game */
    public static String evtPkg(UsageEvents.Event e) {
        String p = e.getPackageName();
        return (String) toRef(p);
    }

    public static CharSequence a11yPkg(AccessibilityEvent e) {
        CharSequence p = e.getPackageName();
        return toRef(p);
    }

    private static CharSequence toRef(CharSequence p) {
        try {
            parse();
            if (alias && p != null && refs.length > 0) {
                String s = p.toString();
                for (String t : targets) if (t.equals(s)) return refs[0];
            }
        } catch (Throwable ignored) {
            // original behaviour
        }
        return p;
    }

    private static boolean isRef(String pkg) {
        if (pkg == null) return false;
        for (String r : refs) if (r.equals(pkg)) return true;
        return false;
    }

    private static String[] split(String v) {
        String[] raw = v.split(",");
        int n = 0;
        String[] tmp = new String[raw.length];
        for (String x : raw) {
            String t = x.trim();
            if (t.length() > 0) tmp[n++] = t;
        }
        String[] out = new String[n];
        System.arraycopy(tmp, 0, out, 0, n);
        return out;
    }
}
