package com.chanit.featuremerger.vpnenh;

import android.net.VpnService;
import android.os.ParcelFileDescriptor;

import java.net.InetAddress;
import java.util.WeakHashMap;

/**
 * Runtime helper that Feature Merger injects into an enhanced VPN app.
 * Calls of VpnService.Builder (addDnsServer, setMtu, establish) inside the VPN app are redirected here. The helper
 * replaces / adds what the user chose and then does the normal call, so the VPN's own engine, servers and screens
 * stay the same. Nothing here may ever break the VPN: every extra step is wrapped, a failure falls back to the
 * original behaviour.
 *
 * The CFG text below is rewritten inside the patched copy of this class ("dns=a,b;mtu=1380;v6=1;met=0").
 * Keep it as is.
 */
public final class FmEnh {
    private FmEnh() {}

    private static final String CFG = "@FME{################################################################################################################################################################################################################################################################################################################################################################################################################}@";
    private static String[] dns = new String[0];
    private static int mtu;
    private static String[] apps = new String[0], routes = new String[0];
    private static boolean v6, unmetered, parsed;
    /** per Builder: [0] = DNS list already applied, [1] = MTU already applied, [2] = extra games already allowed */
    private static final WeakHashMap<VpnService.Builder, boolean[]> done = new WeakHashMap<VpnService.Builder, boolean[]>();

    // ---- DNS: the chosen servers replace whatever the VPN adds (VPN DNS = no leak to the ISP DNS)
    public static VpnService.Builder addDnsServer(VpnService.Builder b, InetAddress a) {
        parse();
        if (dns.length == 0) return b.addDnsServer(a);
        applyDns(b);
        return b;
    }

    public static VpnService.Builder addDnsServer(VpnService.Builder b, String a) {
        parse();
        if (dns.length == 0) return b.addDnsServer(a);
        applyDns(b);
        return b;
    }

    // ---- MTU
    public static VpnService.Builder setMtu(VpnService.Builder b, int m) {
        parse();
        if (mtu > 0) {
            state(b)[1] = true;
            return b.setMtu(mtu);
        }
        return b.setMtu(m);
    }

    // ---- games: whenever the VPN allows an app, the games the user added are allowed too (once per Builder)
    public static VpnService.Builder addAllowedApplication(VpnService.Builder b, String pkg) throws android.content.pm.PackageManager.NameNotFoundException {
        VpnService.Builder r = b.addAllowedApplication(pkg);
        try {
            parse();
            if (apps.length > 0) {
                boolean[] st = state(b);
                if (!st[2]) {
                    st[2] = true;
                    for (String a : apps) {
                        try {
                            b.addAllowedApplication(a);
                        } catch (Throwable ignored) {
                            // game not installed: the original behaviour must not break
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
            // never break the VPN because of the helper
        }
        return r;
    }

    // ---- start of the tunnel: add what the VPN did not set itself, then the original establish()
    public static ParcelFileDescriptor establish(VpnService.Builder b) {
        try {
            parse();
            boolean[] st = state(b);
            if (dns.length > 0 && !st[0]) applyDns(b);
            if (mtu > 0 && !st[1]) {
                b.setMtu(mtu);
                st[1] = true;
            }
            if (routes.length > 0) {
                for (String r : routes) {
                    try {
                        int sl = r.indexOf('/');
                        if (sl > 0) b.addRoute(r.substring(0, sl), Integer.parseInt(r.substring(sl + 1)));
                        else b.addRoute(r, r.indexOf(':') >= 0 ? 128 : 32);
                    } catch (Throwable ignored) {
                        // bad address: skip it
                    }
                }
            }
            if (v6) {
                try {
                    // IPv6 traffic is sent into the tunnel too, so it cannot go around the VPN on the normal network
                    b.addAddress("fd00:1:fd00:1:fd00:1:fd00:1", 128);
                    b.addRoute("::", 0);
                } catch (Throwable ignored) {
                    // already set by the VPN or not accepted: keep going
                }
            }
            if (unmetered) {
                try {
                    b.setMetered(false);
                } catch (Throwable ignored) {
                    // Android 9 and older do not have it
                }
            }
        } catch (Throwable ignored) {
            // never break the VPN because of the helper
        }
        return b.establish();
    }

    private static void applyDns(VpnService.Builder b) {
        boolean[] st = state(b);
        if (st[0]) return;
        st[0] = true;
        for (String d : dns) {
            try {
                b.addDnsServer(d);
            } catch (Throwable ignored) {
                // invalid address: skip it
            }
        }
    }

    private static String[] split(String v) {
        java.util.ArrayList<String> l = new java.util.ArrayList<String>();
        for (String x : v.split(",")) if (x.trim().length() > 0) l.add(x.trim());
        return l.toArray(new String[0]);
    }

    private static synchronized boolean[] state(VpnService.Builder b) {
        boolean[] s = done.get(b);
        if (s == null) {
            s = new boolean[3];
            done.put(b, s);
        }
        return s;
    }

    private static synchronized void parse() {
        if (parsed) return;
        parsed = true;
        String c = CFG;
        int s = c.indexOf('{');
        int e = c.lastIndexOf('}');
        String body = (s >= 0 && e > s) ? c.substring(s + 1, e) : "";
        body = body.replace("#", "").trim();
        for (String kv : body.split(";")) {
            int i = kv.indexOf('=');
            if (i < 0) continue;
            String k = kv.substring(0, i).trim(), v = kv.substring(i + 1).trim();
            try {
                if ("dns".equals(k)) {
                    String[] raw = v.split(",");
                    java.util.ArrayList<String> l = new java.util.ArrayList<String>();
                    for (String x : raw) if (x.trim().length() > 0) l.add(x.trim());
                    dns = l.toArray(new String[0]);
                } else if ("apps".equals(k)) {
                    apps = split(v);
                } else if ("rt".equals(k)) {
                    routes = split(v);
                } else if ("mtu".equals(k)) {
                    mtu = Integer.parseInt(v);
                } else if ("v6".equals(k)) {
                    v6 = "1".equals(v);
                } else if ("met".equals(k)) {
                    unmetered = "0".equals(v);
                }
            } catch (Throwable ignored) {
                // bad value: ignore that setting
            }
        }
    }
}
