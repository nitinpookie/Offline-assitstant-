# Nixu Browse (FastLink Browser) v4.3

GitHub repo ke root mein zip upload karo (`.github/workflows/build.yml` wahi hai).
Actions > Build > Artifacts se APK milegi (file ka naam iLauncher-debug.apk hoga, andar ye browser hi hai).

## v4.3: pehle log se mile sabak
- Flow mein engine ab har agle step par turant lagta hai (pehle ek page par 37 sec kuch nahi hota tha, aakhri "click to verify" page par engine tha hi nahi).
- "Counting down...", "click to verify", "WAIT 10 SECONDS TO GET LINK" jaise lambe texts ab pehchane jaate hain; vplinks/earnlinks shortener list mein.
- Flow chalte waqt ad *scripts* block nahi hote (popup/redirect phir bhi block): site ka apna `sendAdData` jaisa code chale warna uski checking fail hoti hai.
- Log mein ab: X-Requested-With ki asli sthiti, har host ki request, timers kaun sa (setTimeout / rAF / Worker), iframes, focus/visibility.

## v4.2: Flow recorder
- Menu -> **Flow log copy**: link kholne ke baad har step ka page text, buttons, har tap, anomaly/popup/stuck/download sab record hota hai (sirf link kholne ke 3 min tak ya flow chalne tak). Copy karke developer ko bhejo.
- "Your link will be ready in..." / "You'll be redirected automatically" wale page ab "wait" maane jaate hain.

## v4.1: Key aur File/APK ki alag pehchaan
- **Khud pehchanta hai** ki link key ka hai ya file/APK ka (URL, page title/text, aur jis page se aaye uska poora URL dekh kar). Pakka na ho to purane tareeke se chalta hai. Menu -> **Link type** se Auto / Key / File/APK force kar sakte ho.
- **KEY mode:** speed max 5x (checkpoint ka dwell time), key flow mein cookies/session kabhi saaf nahi hote aur auto-reload nahi hota (checkpoint reset na ho), "Checkpoint 2/3" dikhata hai, key page par aate hi key nikal kar **copy + save** karta hai aur auto-click ruk jata hai. Menu -> **Saved keys** (tap = copy, 20 tak yaad).
- **FILE/APK mode:** Mediafire / Drive ka asli Download button khud dabata hai, link aate hi copy, download khatam hone par size ke saath **Install** (APK) / **Open** button; 200 KB se chhoti APK par warning.
- Link Radar mein .apk links sabse upar.

## v4.0 mein kya naya hai (practical upgrade)
- **Asli ungli jaisa swipe:** scroll ab JS se nahi, app ke asli (trusted) touch swipe se hota hai, easing ke saath; pehle thoda "padhne wala" scroll, phir tap.
- **Insaan jaisa tap:** press time / pressure / size random, beech mein halka move, reaction time 0.7-3.1 sec.
- **Step counter:** har tap par "Step N complete" dikhta hai.
- **Atakne par khud dobara try:** 30 sec tak kuch na ho to page ek baar khud reload hota hai.
- **Real-time par bhi anomaly:** us site ke cookies/storage/cache saaf karke (sirf usi site ke) ek baar fresh session se dobara try karta hai.
- **Menu mein naya:** Fresh session, Final link auto-copy (ON/OFF), Links complete ka counter.
- **Final link aate hi copy** ho jata hai (Drive, Mega, Telegram, Workupload, 1fichier ... ).
- JS alert/confirm ab flow ko rokte nahi. Zyada ad networks block, zyada button texts (Get link, Your link is ready, Next step ...) pehchane jaate hain.

## v3.1 mein kya naya hai
- **App ka naam: Nixu Browse** (package / zip ka naam wahi hai, to purani repo mein seedha update hoga).
- **Cute naya icon** (hasta hua chhota globe + bijli).
- **Neeche kala gol message (toast jaisa):** har kaam ke baad batata hai - "Ad block chalu ho gaya", "Button daba diya, ye ho gaya", "Link mil gaya, ye complete ho gaya", "Download complete ho gaya" wagera.

## Toolbar
- ⚡ / 🚀  Speed: OFF -> Smart -> Turbo (tap karte jao)
    - Smart: sirf shortener jaise pages par timer tez karta hai (default)
    - Turbo: har page par tez (YouTube chhod kar)
- 🤖  Auto-click: "Get Link / Continue" jaise buttons ko asli touch se dabata hai, fake/ad buttons chhod deta hai
- 🛡  Ad block + anti-adblock wall hatana + fake Google redirect block
- ⋮  Menu: Link Radar, Page unlock, Real-time mode (is site par), Desktop site, Reset, URL copy

## Kya naya hai
- Asli (trusted) native touch se click -> `isTrusted` check wali sites par kaam
- Timer + Date + performance.now ek saath tez hote hain (pehle sirf setTimeout hota tha)
- Anti-adblock: ad scripts ko block karne ke bajay harmless stub milta hai, wall dikhe to hata deta hai
- Popup (window.open) ab pakda jaata hai: real link khulta hai, ad popup nahi
- Fake "Continue" jo Google search par bhejta hai -> roka jaata hai (bar mein "Allow" ka option)
- ?r=<base64> / ?url= wale redirect khud decode hote hain
- Site "anomaly / too fast" bole to us site ko khud real-time mode mein daal kar dobara try karta hai
- Link Radar: page mein chhupe hue outbound links ki list
- Chrome jaisa UA, X-Requested-With header hata hua, bridge ka naam random

## v3 mein kya naya hai
- **Adaptive speed (per site):** site "anomaly / too fast" bole to app us site ki speed ek step ghatati hai (25x -> 10x -> 5x -> 3x -> 2x -> real-time), reload karti hai aur seekh leti hai. Pehle seedha real-time par girti thi.
- **Manual per-site speed:** ⋮ menu -> "Is site ki speed set karo" (Auto / 1x / 2x / 3x / 5x / 10x / 25x).
- **Saari clocks ek saath:** Date, performance.now, setTimeout/Interval ke saath ab requestAnimationFrame, event.timeStamp, document.timeline aur CSS/Web-Animations bhi virtual speed par chalte hain (inka mismatch hi sites ko pakadta tha).
- **Hamesha visible/focused:** page ko hidden / blur / visibilitychange nahi dikhta, to "tab chhodo to timer ruk jaye" wali sites ruk nahi paati.
- **Chrome jaisa identity:** Sec-CH-UA headers aur navigator.userAgentData me "Android WebView" ki jagah "Google Chrome" (androidx.webkit ki UserAgentMetadata se), window.chrome stub.
- **Insaan jaisa reaction:** button clickable hone ke 0.6-2 sec baad hi tap hota hai (pehle turant hota tha).

## Limits (v3 me bhi)
- Server-side timing check ko koi client script fool nahi kar sakti. Adaptive speed bas us site ki safe limit dhoondhti hai.
- Real-time par bhi anomaly aaye to site WebView / automation hi pakad rahi hai.

## Purani limits
- Server-side timing check ko koi client script fool nahi kar sakti. Aisi sites par real-time mode hi chalta hai.
- Captcha (reCAPTCHA / hCaptcha / Turnstile) khud solve karna padega.
- App background mein ho to auto-click ruk jaata hai.
