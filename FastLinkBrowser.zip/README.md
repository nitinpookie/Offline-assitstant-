# FastLinkBrowser

Is zip ko repo ke root mein upload karo (`.github/workflows/build.yml` wahi hai jo baaki projects mein hai).
Actions > Build > Artifacts se APK milegi (file ka naam iLauncher-debug.apk aayega, par andar ye browser hi hai).
