# FastLink Browser v2

GitHub repo ke root mein zip upload karo (`.github/workflows/build.yml` wahi hai).
Actions > Build > Artifacts se APK milegi (file ka naam iLauncher-debug.apk hoga, andar ye browser hi hai).

## Toolbar
- ⚡ / 🚀  Speed: OFF -> Smart -> Turbo (tap karte jao)
    - Smart: sirf shortener jaise pages par timer tez karta hai (default)
    - Turbo: har page par tez (YouTube chhod kar)
- 🤖  Auto-click: "Get Link / Continue" jaise buttons ko asli touch se dabata hai, fake/ad buttons chhod deta hai
- 🛡  Ad block + anti-adblock wall hatana + fake Google redirect block
- ⋮  Menu: Link Radar, Page unlock, Real-time mode (is site par), Desktop site, Reset, URL copy

## Kya naya hai
- Asli (trusted) native touch se click -> `isTrusted` check wali sites par kaam
- Timer + Date + performance.now ek saath tez hote hain (pehle sirf setTimeout hota tha)
- Anti-adblock: ad scripts ko block karne ke bajay harmless stub milta hai, wall dikhe to hata deta hai
- Popup (window.open) ab pakda jaata hai: real link khulta hai, ad popup nahi
- Fake "Continue" jo Google search par bhejta hai -> roka jaata hai (bar mein "Allow" ka option)
- ?r=<base64> / ?url= wale redirect khud decode hote hain
- Site "anomaly / too fast" bole to us site ko khud real-time mode mein daal kar dobara try karta hai
- Link Radar: page mein chhupe hue outbound links ki list
- Chrome jaisa UA, X-Requested-With header hata hua, bridge ka naam random

## Limits
- Server-side timing check ko koi client script fool nahi kar sakti. Aisi sites par real-time mode hi chalta hai.
- Captcha (reCAPTCHA / hCaptcha / Turnstile) khud solve karna padega.
- App background mein ho to auto-click ruk jaata hai.
