# Nixu Browse (FastLink Browser) v5.4

## v5.4: notification ka Pause / Stop button ab sach mein rokta hai
- **Pehle kya hota tha:** Pause dabane par video ek pal ruk kar khud chal padti thi aur awaaz band nahi hoti thi. Wajah: YouTube jaise players bahar se aaye pause ko "interruption" maan kar khud resume kar dete hain; aur agar video iframe ke andar thi to command us tak pahunchti hi nahi thi.
- **Ab:** Pause dabate hi pause "hold" ho jata hai. Page ka koi script play() nahi kar sakta, jab tak aap khud page par tap karke play na karo ya notification mein Play na dabao. YouTube par uske apne player se bhi pause hota hai.
- **Sab chalti media ek saath ruki:** pehle sirf ek element rukta tha, ab page ki har chalti video / audio rukti hai.
- **iframe wali videos:** Pause / Play ab iframe ke andar wali video tak bhi pahunchta hai.
- **Stop:** pause + notification hat jaati hai, aur page use dobara chala kar notification wapas nahi la sakta.
- Notification ka Pause / Play ab seedha "pause" ya "play" bhejta hai (pehle "toggle" bhejta tha jo galat state par ulta chal sakta tha).

## v5.3: adult / video sites ke liye pakka kiya (quality, Back, download strip)
- **Video quality (search bar ke saath wala badge) ab zyada sites par chalta hai:** pehle sirf HLS/DASH (m3u8 / mpd) aur wo MP4 sites chalti thi jinke URL mein 480 / 720 likha ho. Ab wo sites bhi jinke page mein quality alag se likhi hoti hai, jaise `{"quality":"480","videoUrl":"..."}`, `"720p":"..."`, `quality_480p='...'`. Chal rahi video ki apni doosri qualities dhoondh kar chuni hui limit wali file par swap ho jaati hai (time wahi rehta hai). Kisi site par sach mein ek hi file ho to limit nahi lag sakti, app batata hai.
- **Video par long press = download sheet:** sheet mein ab wo sab qualities bhi aati hain jo page mein JSON style mein likhi hon, sirf wo nahi jo URL se dikhti thi.
- **Clean back zyada pakka:** (1) jis page par aapne ek baar bhi screen touch nahi ki aur wo khud aage chala gaya, wo pakka redirect maana jata hai (pehle sirf "gesture nahi tha" dekha jata tha, jo kabhi kabhi galat nikalta tha). (2) Agar ad ne aapko video page se bahar bhej kar wapas usi video page par laa diya, to Back purani copy bhi skip karta hai. (3) Jis page par aap khud tap karke gaye the wo ab kabhi galti se skip nahi hota. Incognito mein hamesha ON, normal mode mein menu -> Clean back.
- **Download strip swipe:** pehle swipe tabhi chalta tha jab ungli strip ke khali hisse se shuru ho. Ab pause / cancel button par se shuru karke bhi left ya right swipe karne se strip hat jati hai (download chalta rehta hai).

## v5.2: stop button fix + bina refresh ke toggles + Incognito + Data saver + Video quality / focus
- **Option on/off karne par page refresh nahi hota:** Speed, Auto-click, Ad block, Background play, Real-time, Link type, Site speed ab khuli hui page par turant lagte hain. (Sirf Desktop site, Fresh session aur Reload chip jaan-boojh kar reload karte hain.)
- **X (stop) button ab sach mein rokta hai:** pehle page ruk kar bhi auto-click, auto-reload aur script-redirect aage badha dete the. Ab X dabate hi load, auto-click, redirect chain aur popup sab ruk jaate hain. Link flow chalte waqt (page load hone ke baad bhi) X dikhta hai.
- **Incognito (menu -> Data saver & privacy):** alag private profile (cookies, cache, storage alag), history save nahi hoti, upar ka bar kala ho jata hai. Band karte hi private data hat jata hai aur purana tab wapas aata hai. Agar phone ka WebView private profile nahi deta to "Incognito lite" chalta hai (sirf history/cache band).
- **Data saver:** web fonts, GIF aur auto-preview videos band, Save-Data signal on.
- **Images band:** photos load hi nahi hoti (band karte hi wapas aa jaati hain, refresh nahi chahiye).
- **Video quality:** Auto / 720p / 480p / 360p / 240p / 144p. m3u8 / mpd wali videos mein app manifest se bade quality hata deti hai, isliye player badi quality kabhi download hi nahi karta. Seedhi MP4 wali sites par player ka quality menu / source list use hota hai (best effort).
- **Video focus:** jab video chal rahi ho to page ki baaki saari requests (images, scripts, ads, trackers, doosre videos) band, aur app ke chalte downloads pause (video rukte hi resume). Video 9 sec atke to khud band ho jata hai.
- **Quality badge search bar ke saath:** "Auto" / "480p" wala chhota button, tap karo to YouTube jaisi list (Auto, 720p ... 144p) khulti hai. Chuni hui quality HLS downloads par bhi lagti hai. Seedhi MP4 sites par app page mein likhi doosri quality ki file (same video) dhoondh kar swap karti hai, play hone se pehle hi.
- **Video par long press = download sheet:** site ka apna download menu band, uski jagah app ka download button wali list khulti hai (usi video ki doosri qualities bhi). Download manager mein smooth download hota hai.
- **Download wali strip swipe karke hatao:** left ya right swipe karo, download chalta rahta hai, naya download shuru hone par strip wapas aati hai.
- **Clean back (Incognito mein hamesha ON, normal mode mein menu se):** video select karne ke baad jo redirect sites beech mein aati hain, Back dabane par wo skip hoti hain aur seedha us page par pahunchte ho jahan se video chuni thi.
- **Data used:** menu mein counter (lamba dabao = zero).
- **History mein Copy link:** har item ke saamne copy icon; Select mode mein chune hue sab links ek saath copy.
- Limit: ye sirf is browser ke andar ka data control karta hai, doosre apps ka nahi.

## v5.1: awaaz cut-cut fix + YouTube rotate fix + Instagram download
- **Sound boost ab cut-cut nahi karta:** pehle limiter har bass beat par awaaz daba deta tha aur 0.12 sec baad chhod deta tha, isliye loud / concert music mein awaaz flicker karti thi. Ab dheema compressor + ek fixed "soft clipper" hai (koi tez ups-and-downs nahi), slider hilane par awaaz smooth badalti hai, aur CPU kam lagta hai. Phone ke apne speaker par 200-250% tak rakho, us se upar bahar ke speaker par.
- **YouTube rotate fix:** video ko landscape karke wapas seedha (portrait) karne par page ka layout atak jata tha (khisak jana / video upar chipak jana). Ab fullscreen se nikalte hi pehle page ko fullscreen se bahar nikala jata hai, phir screen ghumti hai, aur uske baad page ko 2 baar resize karke dobara naap-tol karwai jati hai. Phir bhi galat dikhe to (sirf YouTube jaise sites par) page khud ek baar reload hota hai.
- **Instagram download (apne login se):** Instagram kholo, login karo. Koi post / reel / story khol kar (ya feed mein screen ke beech wali post par) rukte hi neela download button bounce karta hai. Tap karo: video (original quality), photo, aur carousel ki har slide alag list mein. Photos **Pictures/Nixu Browse** mein, videos Movies/Nixu Browse mein jaate hain.
    - Ye Instagram ka wahi web API call hai jo website khud karti hai, aapke apne login ke saath. Sirf wahi cheez milti hai jo aap apne account se dekh sakte ho.
    - Login nahi hai to app batata hai "Instagram mein login karo".
    - Instagram apna andar ka API badalta rehta hai; kabhi file na mile to batana.
    - Sirf apne personal use ke liye; kisi aur ka content dobara upload mat karna.

## v5.0: premium pill UI + download manager + sound boost
- **Naya UI:** upar pill search bar, neeche floating pill navigation (Home / Back / Downloads / Sound / Menu). Menu ab draggable bottom sheet mein chips ki list hai (neeche kheencho = band).
- **Home page:** favourites tiles. YouTube pehle se hai, "+" se apni favourite site jodo, lamba dabao = edit / hatao. Menu -> "Home mein jodo" se current page bhi jud jata hai.
- **Floating download button (neeche right):** page par audio / video file milte hi neela ho jata hai. Tap = file ki list (Video / Audio only / HLS .m3u8), ya link paste karke download. Button ko kheench kar kahin bhi rakh sakte ho.
- **Apna download manager:** upar strip mein naam, speed, progress, Pause / Cancel; Downloads screen mein poori list (Resume, Retry, Open, Delete). Gaane Music folder mein, video Movies/Nixu Browse mein, baaki Downloads mein.
- **Sound boost 100-350%:** neeche Sound icon. Limiter ON ho to awaaz phat'ti nahi. "System volume MAX" chip bhi hai.
- **Background play:** screen lock karne par bhi music chalta rehta hai (notification mein Pause / Stop, Bluetooth buttons bhi kaam karte hain).
- **YouTube / social sites fast:** in sites par bhari scripts band hain, isliye settings, buttons aur video load tez.
- **App links:** Play Store ke links block; Telegram / WhatsApp / Instagram etc. kholne se pehle popup poochta hai.
- Note: YouTube, Spotify, Netflix jaise protected streams ka download isme nahi hai.

## v4.5: manual rotate + History
- **Auto-rotate band:** phone ghumane se app ab kabhi apne aap rotate nahi hota (app portrait mein locked hai).
- **Landscape sirf 2 tareeke se:** (1) video ke **fullscreen button par tap** karo -> landscape; fullscreen band karte hi (ya back dabate hi) wapas portrait. (2) **⋮ menu -> Rotate screen** -> landscape; dobara tap = portrait. Menu se landscape karne par agar video chal raha ho to wo poori screen mein aa jata hai (back = portrait).
- **History save hoti hai** (500 tak, restart ke baad bhi rehti hai). **⋮ menu -> History**:
    - page par tap = kholo
    - **Select** (ya kisi item ko dabaye rakho) = chunne ka mode, har item par tick
    - **Select all / Unselect all** = sab ek saath chuno
    - **Delete (n)** = chune hue hatao
    - **Sab hatao** = poori history saaf (pehle confirm poochta hai)


GitHub repo ke root mein zip upload karo (`.github/workflows/build.yml` wahi hai).
Actions > Build > Artifacts se APK milegi (file ka naam iLauncher-debug.apk hoga, andar ye browser hi hai).

## v4.3: pehle log se mile sabak
- Flow mein engine ab har agle step par turant lagta hai (pehle ek page par 37 sec kuch nahi hota tha, aakhri "click to verify" page par engine tha hi nahi).
- "Counting down...", "click to verify", "WAIT 10 SECONDS TO GET LINK" jaise lambe texts ab pehchane jaate hain; vplinks/earnlinks shortener list mein.
- Flow chalte waqt ad *scripts* block nahi hote (popup/redirect phir bhi block): site ka apna `sendAdData` jaisa code chale warna uski checking fail hoti hai.
- Log mein ab: X-Requested-With ki asli sthiti, har host ki request, timers kaun sa (setTimeout / rAF / Worker), iframes, focus/visibility.

## v4.2: Flow recorder
- Menu -> **Flow log copy**: link kholne ke baad har step ka page text, buttons, har tap, anomaly/popup/stuck/download sab record hota hai (sirf link kholne ke 3 min tak ya flow chalne tak). Copy karke developer ko bhejo.
- "Your link will be ready in..." / "You'll be redirected automatically" wale page ab "wait" maane jaate hain.

## v4.1: Key aur File/APK ki alag pehchaan
- **Khud pehchanta hai** ki link key ka hai ya file/APK ka (URL, page title/text, aur jis page se aaye uska poora URL dekh kar). Pakka na ho to purane tareeke se chalta hai. Menu -> **Link type** se Auto / Key / File/APK force kar sakte ho.
- **KEY mode:** speed max 5x (checkpoint ka dwell time), key flow mein cookies/session kabhi saaf nahi hote aur auto-reload nahi hota (checkpoint reset na ho), "Checkpoint 2/3" dikhata hai, key page par aate hi key nikal kar **copy + save** karta hai aur auto-click ruk jata hai. Menu -> **Saved keys** (tap = copy, 20 tak yaad).
- **FILE/APK mode:** Mediafire / Drive ka asli Download button khud dabata hai, link aate hi copy, download khatam hone par size ke saath **Install** (APK) / **Open** button; 200 KB se chhoti APK par warning.
- Link Radar mein .apk links sabse upar.

## v4.0 mein kya naya hai (practical upgrade)
- **Asli ungli jaisa swipe:** scroll ab JS se nahi, app ke asli (trusted) touch swipe se hota hai, easing ke saath; pehle thoda "padhne wala" scroll, phir tap.
- **Insaan jaisa tap:** press time / pressure / size random, beech mein halka move, reaction time 0.7-3.1 sec.
- **Step counter:** har tap par "Step N complete" dikhta hai.
- **Atakne par khud dobara try:** 30 sec tak kuch na ho to page ek baar khud reload hota hai.
- **Real-time par bhi anomaly:** us site ke cookies/storage/cache saaf karke (sirf usi site ke) ek baar fresh session se dobara try karta hai.
- **Menu mein naya:** Fresh session, Final link auto-copy (ON/OFF), Links complete ka counter.
- **Final link aate hi copy** ho jata hai (Drive, Mega, Telegram, Workupload, 1fichier ... ).
- JS alert/confirm ab flow ko rokte nahi. Zyada ad networks block, zyada button texts (Get link, Your link is ready, Next step ...) pehchane jaate hain.

## v3.1 mein kya naya hai
- **App ka naam: Nixu Browse** (package / zip ka naam wahi hai, to purani repo mein seedha update hoga).
- **Cute naya icon** (hasta hua chhota globe + bijli).
- **Neeche kala gol message (toast jaisa):** har kaam ke baad batata hai - "Ad block chalu ho gaya", "Button daba diya, ye ho gaya", "Link mil gaya, ye complete ho gaya", "Download complete ho gaya" wagera.

## Toolbar
- ⚡ / 🚀  Speed: OFF -> Smart -> Turbo (tap karte jao)
    - Smart: sirf shortener jaise pages par timer tez karta hai (default)
    - Turbo: har page par tez (YouTube chhod kar)
- 🤖  Auto-click: "Get Link / Continue" jaise buttons ko asli touch se dabata hai, fake/ad buttons chhod deta hai
- 🛡  Ad block + anti-adblock wall hatana + fake Google redirect block
- ⋮  Menu: Link Radar, Page unlock, Real-time mode (is site par), Desktop site, Reset, URL copy

## Kya naya hai
- Asli (trusted) native touch se click -> `isTrusted` check wali sites par kaam
- Timer + Date + performance.now ek saath tez hote hain (pehle sirf setTimeout hota tha)
- Anti-adblock: ad scripts ko block karne ke bajay harmless stub milta hai, wall dikhe to hata deta hai
- Popup (window.open) ab pakda jaata hai: real link khulta hai, ad popup nahi
- Fake "Continue" jo Google search par bhejta hai -> roka jaata hai (bar mein "Allow" ka option)
- ?r=<base64> / ?url= wale redirect khud decode hote hain
- Site "anomaly / too fast" bole to us site ko khud real-time mode mein daal kar dobara try karta hai
- Link Radar: page mein chhupe hue outbound links ki list
- Chrome jaisa UA, X-Requested-With header hata hua, bridge ka naam random

## v3 mein kya naya hai
- **Adaptive speed (per site):** site "anomaly / too fast" bole to app us site ki speed ek step ghatati hai (25x -> 10x -> 5x -> 3x -> 2x -> real-time), reload karti hai aur seekh leti hai. Pehle seedha real-time par girti thi.
- **Manual per-site speed:** ⋮ menu -> "Is site ki speed set karo" (Auto / 1x / 2x / 3x / 5x / 10x / 25x).
- **Saari clocks ek saath:** Date, performance.now, setTimeout/Interval ke saath ab requestAnimationFrame, event.timeStamp, document.timeline aur CSS/Web-Animations bhi virtual speed par chalte hain (inka mismatch hi sites ko pakadta tha).
- **Hamesha visible/focused:** page ko hidden / blur / visibilitychange nahi dikhta, to "tab chhodo to timer ruk jaye" wali sites ruk nahi paati.
- **Chrome jaisa identity:** Sec-CH-UA headers aur navigator.userAgentData me "Android WebView" ki jagah "Google Chrome" (androidx.webkit ki UserAgentMetadata se), window.chrome stub.
- **Insaan jaisa reaction:** button clickable hone ke 0.6-2 sec baad hi tap hota hai (pehle turant hota tha).

## Limits (v3 me bhi)
- Server-side timing check ko koi client script fool nahi kar sakti. Adaptive speed bas us site ki safe limit dhoondhti hai.
- Real-time par bhi anomaly aaye to site WebView / automation hi pakad rahi hai.

## Purani limits
- Server-side timing check ko koi client script fool nahi kar sakti. Aisi sites par real-time mode hi chalta hai.
- Captcha (reCAPTCHA / hCaptcha / Turnstile) khud solve karna padega.
- App background mein ho to auto-click ruk jaata hai.
