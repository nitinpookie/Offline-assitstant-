package com.fastlink.browser;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * The browser's own download manager (replaces Android's DownloadManager so progress, pause, resume and cancel
 * are available inside the app). Plain files use HTTP Range for resume; .m3u8 (HLS, non-DRM) is downloaded segment
 * by segment. Finished files are saved through MediaStore (Music / Movies / Download).
 */
public class DownloadCenter {

    public static final int QUEUED = 0, RUNNING = 1, PAUSED = 2, DONE = 3, FAILED = 4, CANCELED = 5;

    /** Max height for HLS downloads (0 = best). Set from the browser's video quality option. */
    public static volatile int hlsCap;

    public static class Task {
        public int id;
        public String url, name, ua, ref, mime, err, outUri, hlsUrl, hlsExt;
        public boolean audioOnly, nameAuto;
        public volatile int state;
        public volatile long total, done, speed;
        public volatile String note;
        public long added;
        public int segDone, segTotal;
        volatile boolean stop;
        volatile HttpURLConnection conn;
        volatile String finalUrl;
        final Object lock = new Object();
        long spT, spB;
        final HashMap<String, byte[]> keys = new HashMap<>();
    }

    public interface Listener {
        void changed();

        void finished(Task t);

        void failed(Task t);
    }

    private static final class Seg {
        String url, keyUri, iv;
        long seq;
    }

    private static DownloadCenter inst;

    public static synchronized DownloadCenter get(Context c) {
        if (inst == null) inst = new DownloadCenter(c.getApplicationContext());
        return inst;
    }

    private final Context ctx;
    private final SharedPreferences prefs;
    private final CopyOnWriteArrayList<Task> tasks = new CopyOnWriteArrayList<>();
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile Listener listener;
    private int nextId = 1;
    private long lastNotify, lastSave, lastSvc;
    private int lastAct = -1;

    private DownloadCenter(Context c) {
        ctx = c;
        prefs = c.getSharedPreferences("fastlink", Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(prefs.getString("dl_tasks", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Task t = new Task();
                t.id = o.optInt("id");
                t.url = o.optString("u");
                t.name = o.optString("n");
                t.ua = o.optString("ua", null);
                t.ref = o.optString("r", null);
                t.mime = o.optString("m", null);
                t.err = o.optString("e", null);
                t.outUri = o.optString("o", null);
                t.hlsUrl = o.optString("hu", null);
                t.hlsExt = o.optString("he", null);
                t.audioOnly = o.optBoolean("ao");
                t.nameAuto = o.optBoolean("na");
                t.state = o.optInt("s");
                t.total = o.optLong("t");
                t.done = o.optLong("d");
                t.added = o.optLong("a");
                t.segDone = o.optInt("sd");
                t.segTotal = o.optInt("st");
                if (t.state == RUNNING || t.state == QUEUED) t.state = PAUSED;
                tasks.add(t);
                nextId = Math.max(nextId, t.id + 1);
            }
        } catch (Exception ignored) {
        }
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public List<Task> list() {
        return new ArrayList<>(tasks);
    }

    public int activeCount() {
        int n = 0;
        for (Task t : tasks) if (t.state == RUNNING || t.state == QUEUED) n++;
        return n;
    }

    /** 0..1 over all running downloads, or -1 if nothing is running / sizes unknown. */
    public float overall() {
        long tot = 0, dn = 0;
        boolean any = false;
        for (Task t : tasks) {
            if (t.state == RUNNING || t.state == QUEUED) {
                any = true;
                if (t.total > 0) {
                    tot += t.total;
                    dn += Math.min(t.done, t.total);
                }
            }
        }
        if (!any) return -1f;
        return tot > 0 ? (float) dn / (float) tot : 0f;
    }

    // ------------------------------------------------------------------ public actions

    public Task add(String url, String name, String ua, String ref, String mime, boolean audioOnly) {
        Task t = new Task();
        t.id = nextId++;
        t.url = url;
        t.ua = ua;
        t.ref = ref;
        t.mime = mime;
        t.audioOnly = audioOnly;
        t.added = System.currentTimeMillis();
        if (name == null || name.trim().isEmpty()) {
            t.nameAuto = true;
            name = URLUtil.guessFileName(url, null, mime);
        }
        t.name = name;
        t.state = QUEUED;
        tasks.add(0, t);
        trim();
        save();
        start(t);
        postChanged(true);
        return t;
    }

    public void pause(final Task t) {
        if (t.state != RUNNING && t.state != QUEUED) return;
        t.stop = true;
        t.state = PAUSED;
        t.speed = 0;
        killConn(t);
        save();
        postChanged(true);
    }

    public void resume(Task t) {
        if (t.state != PAUSED && t.state != FAILED) return;
        t.err = null;
        start(t);
        postChanged(true);
    }

    /** Stops the download and removes it (the half-downloaded file is deleted). */
    public void cancel(final Task t) {
        t.stop = true;
        t.state = CANCELED;
        tasks.remove(t);
        killConn(t);
        new Thread(() -> {
            synchronized (t.lock) {
                partFile(t).delete();
            }
        }).start();
        save();
        postChanged(true);
    }

    /** Removes a finished / failed entry from the list. deleteFile = also delete the saved file. */
    public void remove(final Task t, boolean deleteFile) {
        tasks.remove(t);
        final String uri = t.outUri;
        final boolean del = deleteFile;
        new Thread(() -> {
            partFile(t).delete();
            if (del && uri != null) {
                try {
                    ctx.getContentResolver().delete(Uri.parse(uri), null, null);
                } catch (Throwable ignored) {
                }
            }
        }).start();
        save();
        postChanged(true);
    }

    public void clearFinished() {
        for (Task t : tasks) {
            if (t.state == DONE || t.state == FAILED) {
                tasks.remove(t);
                new File(dir(), t.id + ".part").delete();
            }
        }
        save();
        postChanged(true);
    }

    // ------------------------------------------------------------------ internals

    private void trim() {
        while (tasks.size() > 60) {
            Task victim = null;
            for (int i = tasks.size() - 1; i >= 0; i--) {
                Task t = tasks.get(i);
                if (t.state == DONE || t.state == FAILED) {
                    victim = t;
                    break;
                }
            }
            if (victim == null) break;
            tasks.remove(victim);
        }
    }

    private void killConn(final Task t) {
        final HttpURLConnection c = t.conn;
        if (c == null) return;
        new Thread(() -> {
            try {
                c.disconnect();
            } catch (Throwable ignored) {
            }
        }).start();
    }

    private File dir() {
        File d = new File(ctx.getFilesDir(), "dl");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private File partFile(Task t) {
        return new File(dir(), t.id + ".part");
    }

    private void start(final Task t) {
        t.stop = false;
        t.err = null;
        t.state = QUEUED;
        pool.execute(() -> run(t));
    }

    private void save() {
        try {
            JSONArray a = new JSONArray();
            for (Task t : tasks) {
                JSONObject o = new JSONObject();
                o.put("id", t.id);
                o.put("u", t.url);
                o.put("n", t.name);
                o.put("ua", t.ua);
                o.put("r", t.ref);
                o.put("m", t.mime);
                o.put("e", t.err);
                o.put("o", t.outUri);
                o.put("hu", t.hlsUrl);
                o.put("he", t.hlsExt);
                o.put("ao", t.audioOnly);
                o.put("na", t.nameAuto);
                o.put("s", t.state);
                o.put("t", t.total);
                o.put("d", t.done);
                o.put("a", t.added);
                o.put("sd", t.segDone);
                o.put("st", t.segTotal);
                a.put(o);
            }
            prefs.edit().putString("dl_tasks", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void postChanged(boolean force) {
        long now = SystemClock.elapsedRealtime();
        if (!force && now - lastNotify < 350) return;
        lastNotify = now;
        if (now - lastSave > 3000) {
            lastSave = now;
            save();
        }
        main.post(() -> {
            syncService();
            Listener l = listener;
            if (l != null) l.changed();
        });
    }

    private void syncService() {
        int act = 0;
        long tot = 0, dn = 0;
        for (Task t : tasks) {
            if (t.state == RUNNING || t.state == QUEUED) {
                act++;
                if (t.total > 0) {
                    tot += t.total;
                    dn += Math.min(t.done, t.total);
                }
            }
        }
        MediaService.dlActive = act;
        MediaService.dlPercent = tot > 0 ? (int) (dn * 100 / tot) : -1;
        long now = SystemClock.elapsedRealtime();
        if (act != lastAct || now - lastSvc > 1500) {
            lastSvc = now;
            lastAct = act;
            MediaService.sync(ctx);
        }
    }

    private void tick(Task t) {
        long now = SystemClock.elapsedRealtime();
        if (now - t.spT >= 700) {
            long dt = now - t.spT;
            long db = t.done - t.spB;
            double inst = db * 1000.0 / Math.max(1, dt);
            t.speed = t.speed == 0 ? (long) inst : (long) (t.speed * 0.6 + inst * 0.4);
            t.spT = now;
            t.spB = t.done;
            postChanged(false);
        }
    }

    private void run(final Task t) {
        synchronized (t.lock) {
            if (t.stop || t.state == DONE || t.state == CANCELED) return;
            t.state = RUNNING;
            t.note = null;
            t.spT = SystemClock.elapsedRealtime();
            t.spB = t.done;
            postChanged(true);
            try {
                File part = partFile(t);
                if (isHls(t.url)) runHls(t, part);
                else runHttp(t, part);
                if (t.stop) return;
                finish(t, part);
            } catch (Throwable e) {
                if (t.stop) return;
                String m = e.getMessage();
                t.err = m == null || m.isEmpty() ? e.getClass().getSimpleName() : m;
                t.state = FAILED;
                t.speed = 0;
                t.note = null;
                save();
                postChanged(true);
                main.post(() -> {
                    Listener l = listener;
                    if (l != null) l.failed(t);
                });
            }
        }
    }

    // ------------------------------------------------------------------ plain files

    private HttpURLConnection open(Task t, String url, long from) throws IOException {
        String cur = url;
        for (int hop = 0; hop < 8; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            t.conn = c;
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            if (t.ua != null) c.setRequestProperty("User-Agent", t.ua);
            try {
                String ck = CookieManager.getInstance().getCookie(cur);
                if (ck != null) c.setRequestProperty("Cookie", ck);
            } catch (Throwable ignored) {
            }
            if (t.ref != null) c.setRequestProperty("Referer", t.ref);
            c.setRequestProperty("Accept-Encoding", "identity");
            if (from > 0) c.setRequestProperty("Range", "bytes=" + from + "-");
            int code = c.getResponseCode();
            if (code >= 300 && code < 400 && code != 304) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("Redirect adhoora tha");
                cur = new URL(new URL(cur), loc).toString();
                continue;
            }
            t.finalUrl = cur;
            return c;
        }
        throw new IOException("Bahut zyada redirects");
    }

    private void runHttp(Task t, File part) throws Exception {
        long have = part.exists() ? part.length() : 0;
        t.done = have;
        HttpURLConnection c = open(t, t.url, have);
        try {
            if (t.stop) return;
            int code = c.getResponseCode();
            if (code == 416 && have > 0) {      // file was already complete
                t.total = have;
                return;
            }
            if (code != 200 && code != 206) throw new IOException("Server ne HTTP " + code + " diya");
            boolean append = code == 206 && have > 0;
            if (!append) {
                have = 0;
                t.done = 0;
            }
            long len = c.getContentLengthLong();
            long total = len > 0 ? have + len : 0;
            if (code == 206) {
                String cr = c.getHeaderField("Content-Range");
                if (cr != null && cr.indexOf('/') > 0) {
                    try {
                        total = Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim());
                    } catch (Exception ignored) {
                    }
                }
            } else {
                total = len > 0 ? len : 0;
            }
            t.total = total;
            String ct = c.getContentType();
            if (ct != null) {
                int sc = ct.indexOf(';');
                if (sc > 0) ct = ct.substring(0, sc);
                t.mime = ct.trim().toLowerCase();
            }
            if (t.nameAuto) {
                String fu = t.finalUrl == null ? t.url : t.finalUrl;
                t.name = URLUtil.guessFileName(fu, c.getHeaderField("Content-Disposition"), t.mime);
                t.nameAuto = false;
            }
            postChanged(true);
            byte[] buf = new byte[64 * 1024];
            try (InputStream in = c.getInputStream(); FileOutputStream fo = new FileOutputStream(part, append)) {
                int n;
                while (!t.stop && (n = in.read(buf)) > 0) {
                    fo.write(buf, 0, n);
                    t.done += n;
                    tick(t);
                }
            }
            if (t.stop) return;
            if (t.total > 0 && t.done < t.total) {
                throw new IOException("Connection beech mein toot gaya (Resume dabao)");
            }
            if (t.total <= 0) t.total = t.done;
        } finally {
            c.disconnect();
            t.conn = null;
        }
    }

    // ------------------------------------------------------------------ HLS (.m3u8, not DRM)

    private static boolean isHls(String url) {
        if (url == null) return false;
        int q = url.indexOf('?');
        String p = (q >= 0 ? url.substring(0, q) : url).toLowerCase();
        return p.endsWith(".m3u8");
    }

    private byte[] httpBytes(String url, Task t) throws IOException {
        IOException last = null;
        for (int a = 0; a < 3; a++) {
            if (t.stop) throw new IOException("stopped");
            HttpURLConnection c = null;
            try {
                c = open(t, url, 0);
                int code = c.getResponseCode();
                if (code != 200) throw new IOException("HTTP " + code);
                try (InputStream in = c.getInputStream(); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
                    byte[] b = new byte[32 * 1024];
                    int n;
                    while ((n = in.read(b)) > 0) {
                        if (t.stop) throw new IOException("stopped");
                        bo.write(b, 0, n);
                    }
                    return bo.toByteArray();
                }
            } catch (IOException e) {
                if (t.stop) throw e;
                last = e;
                try {
                    Thread.sleep(600);
                } catch (InterruptedException ignored) {
                }
            } finally {
                if (c != null) c.disconnect();
            }
        }
        throw last != null ? last : new IOException("Segment nahi mila");
    }

    private static String attr(String line, String name) {
        int k = line.indexOf(name + "=");
        if (k < 0) return null;
        int s = k + name.length() + 1;
        if (s >= line.length()) return null;
        if (line.charAt(s) == '"') {
            int e = line.indexOf('"', s + 1);
            return e < 0 ? line.substring(s + 1) : line.substring(s + 1, e);
        }
        int e = line.indexOf(',', s);
        return (e < 0 ? line.substring(s) : line.substring(s, e)).trim();
    }

    private static String resolve(String base, String ref) throws IOException {
        return new URL(new URL(base), ref).toString();
    }

    private byte[] decrypt(byte[] data, byte[] key, String ivHex, long seq) throws Exception {
        byte[] iv = new byte[16];
        if (ivHex != null && ivHex.length() > 2) {
            String h = ivHex.startsWith("0x") || ivHex.startsWith("0X") ? ivHex.substring(2) : ivHex;
            while (h.length() < 32) h = "0" + h;
            for (int i = 0; i < 16; i++) iv[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
        } else {
            for (int i = 0; i < 8; i++) iv[15 - i] = (byte) ((seq >> (8 * i)) & 0xff);
        }
        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        return c.doFinal(data);
    }

    private void runHls(Task t, File part) throws Exception {
        String base = t.hlsUrl != null ? t.hlsUrl : t.url;
        String txt = new String(httpBytes(base, t), "UTF-8");
        if (txt.contains("#EXT-X-STREAM-INF")) {          // master list: take the best quality (inside the chosen limit)
            if (hlsCap > 0) txt = VideoCap.capHlsMaster(txt, hlsCap, null);
            String best = null;
            long bw = -1;
            String[] ls = txt.split("\\r?\\n");
            for (int i = 0; i < ls.length; i++) {
                String l = ls[i].trim();
                if (!l.startsWith("#EXT-X-STREAM-INF")) continue;
                long b = 0;
                try {
                    String bs = attr(l, "BANDWIDTH");
                    if (bs != null) b = Long.parseLong(bs.trim());
                } catch (Exception ignored) {
                }
                for (int j = i + 1; j < ls.length; j++) {
                    String u = ls[j].trim();
                    if (u.isEmpty() || u.startsWith("#")) continue;
                    if (b > bw) {
                        bw = b;
                        best = u;
                    }
                    break;
                }
            }
            if (best == null) throw new IOException("HLS list samajh nahi aayi");
            base = resolve(base, best);
            txt = new String(httpBytes(base, t), "UTF-8");
        }
        t.hlsUrl = base;

        ArrayList<Seg> segs = new ArrayList<>();
        String curKey = null, curIv = null, mapUri = null;
        long mediaSeq = 0;
        boolean ended = false;
        for (String raw : txt.split("\\r?\\n")) {
            String l = raw.trim();
            if (l.isEmpty()) continue;
            if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
                try {
                    mediaSeq = Long.parseLong(l.substring(22).trim());
                } catch (Exception ignored) {
                }
            } else if (l.startsWith("#EXT-X-KEY:")) {
                String m = attr(l, "METHOD");
                if ("AES-128".equals(m)) {
                    curKey = attr(l, "URI");
                    curIv = attr(l, "IV");
                    if (curKey != null) curKey = resolve(base, curKey);
                } else if ("NONE".equals(m)) {
                    curKey = null;
                    curIv = null;
                } else {
                    throw new IOException("Ye stream DRM / protected hai, download nahi ho sakta");
                }
            } else if (l.startsWith("#EXT-X-MAP:")) {
                mapUri = attr(l, "URI");
                if (mapUri != null) mapUri = resolve(base, mapUri);
            } else if (l.startsWith("#EXT-X-ENDLIST")) {
                ended = true;
            } else if (!l.startsWith("#")) {
                Seg s = new Seg();
                s.url = resolve(base, l);
                s.keyUri = curKey;
                s.iv = curIv;
                s.seq = mediaSeq + segs.size();
                segs.add(s);
            }
        }
        if (!ended) throw new IOException("Live stream download support nahi hai");
        if (segs.isEmpty()) throw new IOException("Stream mein kuch nahi mila");

        t.hlsExt = mapUri != null ? "mp4" : "ts";
        t.segTotal = segs.size();
        boolean append = t.segDone > 0 && part.exists() && t.done > 0 && part.length() >= t.done;
        if (append && part.length() > t.done) {
            try (RandomAccessFile raf = new RandomAccessFile(part, "rw")) {
                raf.setLength(t.done);
            }
        }
        if (!append) {
            t.segDone = 0;
            t.done = 0;
            if (part.exists()) part.delete();
        }
        postChanged(true);
        try (FileOutputStream fo = new FileOutputStream(part, append)) {
            if (mapUri != null && t.segDone == 0) {
                byte[] init = httpBytes(mapUri, t);
                fo.write(init);
                t.done += init.length;
            }
            for (int i = t.segDone; i < segs.size(); i++) {
                if (t.stop) return;
                Seg s = segs.get(i);
                byte[] data = httpBytes(s.url, t);
                if (t.stop) return;
                if (s.keyUri != null) {
                    byte[] key = t.keys.get(s.keyUri);
                    if (key == null) {
                        key = httpBytes(s.keyUri, t);
                        t.keys.put(s.keyUri, key);
                    }
                    data = decrypt(data, key, s.iv, s.seq);
                }
                fo.write(data);
                t.done += data.length;
                t.segDone = i + 1;
                t.total = (long) ((double) t.done / t.segDone * t.segTotal);
                tick(t);
            }
        }
    }

    // ------------------------------------------------------------------ finishing (mp4 / audio / save)

    private static String extOf(String name) {
        int i = name.lastIndexOf('.');
        return i >= 0 && i < name.length() - 1 ? name.substring(i + 1).toLowerCase() : "";
    }

    private static String swapExt(String name, String ext) {
        int i = name.lastIndexOf('.');
        String b = i > 0 ? name.substring(0, i) : name;
        return b + "." + ext;
    }

    private static String cleanName(String n) {
        String s = n.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "_").trim();
        if (s.length() > 120) {
            String e = extOf(s);
            s = s.substring(0, 110) + (e.isEmpty() ? "" : "." + e);
        }
        return s.isEmpty() ? "download" : s;
    }

    private static boolean isAudio(String name, String mime) {
        if (mime != null && mime.startsWith("audio/")) return true;
        return extOf(name).matches("mp3|m4a|aac|ogg|oga|opus|wav|flac|wma|amr");
    }

    private static String mimeFor(String name, String hint) {
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extOf(name));
        if (m != null) return m;
        if (hint != null && !hint.isEmpty() && !hint.equals("application/octet-stream")) return hint;
        return "application/octet-stream";
    }

    private void finish(Task t, File part) throws Exception {
        ArrayList<File> junk = new ArrayList<>();
        File src = part;
        String name = cleanName(t.name == null || t.name.isEmpty() ? "download_" + t.id : t.name);
        String mime;
        try {
            if (t.hlsExt != null) {
                name = swapExt(name, t.hlsExt);
                mime = "ts".equals(t.hlsExt) ? "video/mp2t" : "video/mp4";
                if ("ts".equals(t.hlsExt)) {
                    t.note = "MP4 ban rahi hai...";
                    postChanged(true);
                    File mp4 = new File(dir(), t.id + ".mp4");
                    junk.add(mp4);
                    if (remuxToMp4(part, mp4)) {
                        src = mp4;
                        name = swapExt(name, "mp4");
                        mime = "video/mp4";
                    }
                }
            } else {
                mime = mimeFor(name, t.mime);
            }
            if (t.audioOnly && !isAudio(name, mime)) {
                t.note = "Audio nikal rahi hai...";
                postChanged(true);
                File au = new File(dir(), t.id + ".aud");
                junk.add(au);
                try {
                    String[] r = extractAudio(src, au);
                    src = au;
                    name = swapExt(name, r[0]);
                    mime = r[1];
                } catch (Exception e) {
                    t.err = null;     // keep the video instead of failing
                }
            }
            t.note = "Save ho rahi hai...";
            postChanged(true);
            Uri u = publish(src, name, mime);
            t.name = name;
            t.mime = mime;
            t.outUri = u.toString();
            t.state = DONE;
            t.speed = 0;
            t.note = null;
            t.total = Math.max(t.total, t.done);
            part.delete();
            save();
            postChanged(true);
            final Task ft = t;
            main.post(() -> {
                Listener l = listener;
                if (l != null) l.finished(ft);
            });
        } finally {
            for (File f : junk) f.delete();
        }
    }

    private Uri publish(File f, String name, String mime) throws IOException {
        ContentResolver cr = ctx.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        Uri coll;
        String rel;
        if (mime.startsWith("audio/")) {
            coll = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            rel = Environment.DIRECTORY_MUSIC + "/Nixu Browse";
        } else if (mime.startsWith("video/")) {
            coll = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            rel = Environment.DIRECTORY_MOVIES + "/Nixu Browse";
        } else if (mime.startsWith("image/")) {
            coll = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            rel = Environment.DIRECTORY_PICTURES + "/Nixu Browse";
        } else {
            coll = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            rel = Environment.DIRECTORY_DOWNLOADS;
        }
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri u = cr.insert(coll, v);
        if (u == null) throw new IOException("File save nahi ho paayi");
        try (OutputStream o = cr.openOutputStream(u); InputStream in = new FileInputStream(f)) {
            if (o == null) throw new IOException("File khul nahi paayi");
            byte[] b = new byte[64 * 1024];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
        } catch (IOException e) {
            try {
                cr.delete(u, null, null);
            } catch (Throwable ignored) {
            }
            throw e;
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(u, done, null, null);
        return u;
    }

    /** Copies the audio track out of a video file without re-encoding. Returns {ext, mime}. */
    private String[] extractAudio(File in, File out) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        MediaMuxer mux = null;
        try {
            ex.setDataSource(in.getAbsolutePath());
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) {
                    track = i;
                    fmt = f;
                    break;
                }
            }
            if (track < 0) throw new IOException("Is video mein audio track nahi mila");
            String mime = fmt.getString(MediaFormat.KEY_MIME);
            int muxFmt;
            String ext, outMime;
            if ("audio/mp4a-latm".equals(mime)) {
                muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4;
                ext = "m4a";
                outMime = "audio/mp4";
            } else if ("audio/opus".equals(mime) || "audio/vorbis".equals(mime)) {
                muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM;
                ext = "webm";
                outMime = "audio/webm";
            } else {
                throw new IOException("Audio format (" + mime + ") support nahi hai");
            }
            mux = new MediaMuxer(out.getAbsolutePath(), muxFmt);
            ex.selectTrack(track);
            int outTrack = mux.addTrack(fmt);
            mux.start();
            ByteBuffer buf = ByteBuffer.allocate(1 << 20);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (true) {
                buf.clear();
                int n = ex.readSampleData(buf, 0);
                if (n < 0) break;
                info.set(0, n, ex.getSampleTime(), ex.getSampleFlags());
                mux.writeSampleData(outTrack, buf, info);
                ex.advance();
            }
            mux.stop();
            return new String[]{ext, outMime};
        } finally {
            try {
                ex.release();
            } catch (Throwable ignored) {
            }
            try {
                if (mux != null) mux.release();
            } catch (Throwable ignored) {
            }
        }
    }

    /** MPEG-TS -> MP4 (H.264 / AAC) without re-encoding. Returns false if the phone cannot do this file. */
    private boolean remuxToMp4(File in, File out) {
        MediaExtractor ex = new MediaExtractor();
        MediaMuxer mux = null;
        try {
            ex.setDataSource(in.getAbsolutePath());
            int n = ex.getTrackCount();
            int[] map = new int[n];
            mux = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int added = 0;
            for (int i = 0; i < n; i++) {
                map[i] = -1;
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && (m.startsWith("video/") || m.startsWith("audio/"))) {
                    map[i] = mux.addTrack(f);
                    ex.selectTrack(i);
                    added++;
                }
            }
            if (added == 0) return false;
            mux.start();
            ByteBuffer buf = ByteBuffer.allocate(4 << 20);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (true) {
                buf.clear();
                int sz = ex.readSampleData(buf, 0);
                if (sz < 0) break;
                int ti = ex.getSampleTrackIndex();
                if (ti >= 0 && ti < n && map[ti] >= 0) {
                    info.set(0, sz, ex.getSampleTime(), ex.getSampleFlags());
                    mux.writeSampleData(map[ti], buf, info);
                }
                ex.advance();
            }
            mux.stop();
            return true;
        } catch (Throwable e) {
            out.delete();
            return false;
        } finally {
            try {
                ex.release();
            } catch (Throwable ignored) {
            }
            try {
                if (mux != null) mux.release();
            } catch (Throwable ignored) {
            }
        }
    }
}
