package com.fastlink.browser;

import android.content.Context;
import android.view.View;
import android.webkit.WebView;

/**
 * WebView that keeps itself "visible" while a page is playing media and Background play is ON.
 * Without this, Chromium sees the window go to GONE when the screen locks (or the app is left), hides the page
 * and pauses the player. With it, the page never learns it was hidden, so audio keeps playing.
 */
public class BgWebView extends WebView {

    /** Mirrors the "Background play" switch (set by MainActivity). */
    public static volatile boolean allow = true;

    public BgWebView(Context c) {
        super(c);
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        if (allow && MediaService.hold && visibility != View.VISIBLE) {
            super.onWindowVisibilityChanged(View.VISIBLE);
            return;
        }
        super.onWindowVisibilityChanged(visibility);
    }
}
