package com.fastlink.browser;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pure Java (no Android classes) helpers that cap the video quality inside adaptive-streaming manifests.
 * <p>
 * HLS (.m3u8 master playlist) and DASH (.mpd) list several renditions (240p ... 1080p). The player picks one
 * by itself; if the manifest only offers renditions up to the chosen height, the player can never download
 * anything bigger. The app answers the manifest request itself with the filtered copy.
 */
final class VideoCap {

    private VideoCap() {
    }

    static final class Result {
        int code;
        byte[] body;
        String finalUrl;
        String contentType;
        final List<String> setCookies = new ArrayList<>();
    }

    private static final Pattern RES = Pattern.compile("RESOLUTION=(\\d+)x(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern BW = Pattern.compile("[:,]BANDWIDTH=(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern URI_ATTR = Pattern.compile("URI=\"([^\"]*)\"");
    private static final Pattern DASH_SET = Pattern.compile("<AdaptationSet\\b.*?</AdaptationSet>", Pattern.DOTALL);
    private static final Pattern DASH_REP = Pattern.compile(
            "<Representation\\b[^>]*?(?:/>|>.*?</Representation>)", Pattern.DOTALL);
    private static final Pattern HEIGHT = Pattern.compile("\\sheight=\"(\\d+)\"");

    static boolean looksHls(String t) {
        return t != null && t.contains("#EXT-X-STREAM-INF");
    }

    static boolean looksDash(String t) {
        return t != null && t.contains("<MPD") && t.contains("<Representation");
    }

    /** Rough bitrate ceiling for a height; only used when the playlist has no RESOLUTION= information. */
    static int bandwidthFor(int cap) {
        if (cap <= 144) return 300000;
        if (cap <= 240) return 700000;
        if (cap <= 360) return 1200000;
        if (cap <= 480) return 2200000;
        if (cap <= 720) return 4500000;
        return 8000000;
    }

    private static final class Var {
        int tag, uri, h, bw;
        boolean keep;
    }

    /**
     * Keeps only the variants up to {@code cap} pixels of height (if none fits, the smallest one stays).
     *
     * @param base when not null, relative URIs are turned into absolute ones against this URL
     *             (needed when the playlist was fetched after a redirect)
     */
    static String capHlsMaster(String text, int cap, String base) {
        String[] lines = text.split("\r?\n", -1);
        List<Var> vs = new ArrayList<>();
        for (int i = 0; i < lines.length; i++) {
            if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue;
            int j = i + 1;
            while (j < lines.length && (lines[j].trim().isEmpty() || lines[j].startsWith("#"))) j++;
            if (j >= lines.length) break;
            Var v = new Var();
            v.tag = i;
            v.uri = j;
            Matcher m = RES.matcher(lines[i]);
            if (m.find()) {
                try {
                    v.h = Integer.parseInt(m.group(2));
                } catch (NumberFormatException ignored) {
                }
            }
            Matcher b = BW.matcher(lines[i]);
            if (b.find()) {
                try {
                    v.bw = Integer.parseInt(b.group(1));
                } catch (NumberFormatException ignored) {
                }
            }
            vs.add(v);
            i = j;
        }

        boolean[] drop = new boolean[lines.length];
        if (vs.size() >= 2 && cap > 0) {
            boolean anyRes = false;
            for (Var v : vs) if (v.h > 0) anyRes = true;
            int capBw = bandwidthFor(cap);
            int kept = 0;
            for (Var v : vs) {
                v.keep = anyRes ? (v.h > 0 && v.h <= cap) : (v.bw > 0 && v.bw <= capBw);
                if (v.keep) kept++;
            }
            if (kept == 0) {
                Var low = null;
                for (Var v : vs) {
                    if (anyRes && v.h <= 0) continue;
                    if (low == null || (anyRes ? v.h < low.h : v.bw < low.bw)) low = v;
                }
                if (low == null) low = vs.get(0);
                low.keep = true;
            }
            for (Var v : vs) {
                if (!v.keep) {
                    drop[v.tag] = true;
                    drop[v.uri] = true;
                }
            }
            for (int i = 0; i < lines.length; i++) {
                if (lines[i].startsWith("#EXT-X-I-FRAME-STREAM-INF")) {
                    Matcher m = RES.matcher(lines[i]);
                    if (m.find()) {
                        try {
                            if (Integer.parseInt(m.group(2)) > cap) drop[i] = true;
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
            }
        }

        StringBuilder sb = new StringBuilder(text.length());
        for (int i = 0; i < lines.length; i++) {
            if (drop[i]) continue;
            String L = lines[i];
            if (base != null) L = absolutizeLine(L, base);
            sb.append(L);
            if (i < lines.length - 1) sb.append('\n');
        }
        return sb.toString();
    }

    private static String absolutizeLine(String line, String base) {
        String t = line.trim();
        if (t.isEmpty()) return line;
        try {
            if (t.startsWith("#")) {
                Matcher m = URI_ATTR.matcher(line);
                StringBuffer out = new StringBuffer();
                while (m.find()) {
                    String u = m.group(1);
                    String abs = u.isEmpty() ? u : URI.create(base).resolve(u).toString();
                    m.appendReplacement(out, Matcher.quoteReplacement("URI=\"" + abs + "\""));
                }
                m.appendTail(out);
                return out.toString();
            }
            return URI.create(base).resolve(t).toString();
        } catch (Exception e) {
            return line;
        }
    }

    /** DASH: inside every video AdaptationSet keep the renditions up to {@code cap} (or the smallest one). */
    static String capDash(String xml, int cap) {
        if (cap <= 0) return xml;
        Matcher sm = DASH_SET.matcher(xml);
        StringBuffer out = new StringBuffer();
        while (sm.find()) {
            String set = sm.group();
            Matcher rm = DASH_REP.matcher(set);
            List<int[]> reps = new ArrayList<>();      // {start, end, height}
            while (rm.find()) {
                int h = 0;
                Matcher hm = HEIGHT.matcher(rm.group());
                if (hm.find()) {
                    try {
                        h = Integer.parseInt(hm.group(1));
                    } catch (NumberFormatException ignored) {
                    }
                }
                reps.add(new int[]{rm.start(), rm.end(), h});
            }
            int withH = 0, fit = 0, lowH = Integer.MAX_VALUE;
            for (int[] r : reps) {
                if (r[2] > 0) {
                    withH++;
                    if (r[2] <= cap) fit++;
                    if (r[2] < lowH) lowH = r[2];
                }
            }
            String res = set;
            if (withH >= 2 && fit < withH) {
                StringBuilder sb = new StringBuilder();
                int pos = 0;
                for (int[] r : reps) {
                    boolean remove = r[2] > 0 && (fit > 0 ? r[2] > cap : r[2] != lowH);
                    if (remove) {
                        sb.append(set, pos, r[0]);
                        pos = r[1];
                    }
                }
                sb.append(set.substring(pos));
                res = sb.toString();
            }
            sm.appendReplacement(out, Matcher.quoteReplacement(res));
        }
        sm.appendTail(out);
        return out.toString();
    }

    /** Plain GET with the browser's own headers (so cookies / referer checks of the site still pass). */
    static Result fetch(String url, Map<String, String> hdr, String cookie, int timeoutMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(timeoutMs);
            c.setReadTimeout(timeoutMs);
            c.setInstanceFollowRedirects(true);
            if (hdr != null) {
                for (Map.Entry<String, String> e : hdr.entrySet()) {
                    String k = e.getKey();
                    if (k == null || e.getValue() == null) continue;
                    if (k.equalsIgnoreCase("Accept-Encoding") || k.equalsIgnoreCase("Cookie")
                            || k.equalsIgnoreCase("Range") || k.equalsIgnoreCase("Host")
                            || k.equalsIgnoreCase("Connection") || k.equalsIgnoreCase("Content-Length")) {
                        continue;
                    }
                    c.setRequestProperty(k, e.getValue());
                }
            }
            if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
            Result r = new Result();
            r.code = c.getResponseCode();
            r.finalUrl = c.getURL().toString();
            r.contentType = c.getContentType();
            List<String> sc = c.getHeaderFields().get("Set-Cookie");
            if (sc != null) r.setCookies.addAll(sc);
            if (r.code != 200) return r;
            try (InputStream in = c.getInputStream(); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                int total = 0;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > 3 * 1024 * 1024) throw new java.io.IOException("manifest too big");
                    bo.write(buf, 0, n);
                }
                r.body = bo.toByteArray();
            }
            return r;
        } finally {
            c.disconnect();
        }
    }
}
