package com.fastlink.browser;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/** Crisp icons drawn on a 24x24 grid with Canvas, so the UI looks the same on every phone (no emoji fonts). */
public class Ic extends Drawable {
    public static final int HOME = 0, BACK = 1, FORWARD = 2, DOWNLOAD = 3, SOUND = 4, MENU = 5, REFRESH = 6,
            PLUS = 7, CLOSE = 8, PAUSE = 9, PLAY = 10, TRASH = 11, SEARCH = 12, CHECK = 13, VIDEO = 14,
            MUSIC = 15, STOP = 16, FILE = 17, GLOBE = 18;

    private final int kind;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF r = new RectF();

    public Ic(int kind, int color) {
        this.kind = kind;
        p.setColor(color);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    public void setColor(int c) {
        p.setColor(c);
        invalidateSelf();
    }

    private void line(Canvas c, float x1, float y1, float x2, float y2) {
        c.drawLine(x1, y1, x2, y2, p);
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float w = b.width(), h = b.height();
        float s = Math.min(w, h);
        if (s <= 0) return;
        c.save();
        c.translate(b.left + (w - s) / 2f, b.top + (h - s) / 2f);
        c.scale(s / 24f, s / 24f);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        path.reset();
        switch (kind) {
            case HOME:
                path.moveTo(4, 11.5f);
                path.lineTo(12, 4.5f);
                path.lineTo(20, 11.5f);
                c.drawPath(path, p);
                path.reset();
                path.moveTo(6.5f, 10f);
                path.lineTo(6.5f, 19.5f);
                path.lineTo(17.5f, 19.5f);
                path.lineTo(17.5f, 10f);
                c.drawPath(path, p);
                path.reset();
                path.moveTo(10f, 19.5f);
                path.lineTo(10f, 14f);
                path.lineTo(14f, 14f);
                path.lineTo(14f, 19.5f);
                c.drawPath(path, p);
                break;
            case BACK:
                path.moveTo(15, 5);
                path.lineTo(8, 12);
                path.lineTo(15, 19);
                c.drawPath(path, p);
                break;
            case FORWARD:
                path.moveTo(9, 5);
                path.lineTo(16, 12);
                path.lineTo(9, 19);
                c.drawPath(path, p);
                break;
            case DOWNLOAD:
                line(c, 12, 4, 12, 15);
                path.moveTo(7, 10.5f);
                path.lineTo(12, 15.5f);
                path.lineTo(17, 10.5f);
                c.drawPath(path, p);
                line(c, 5, 19.5f, 19, 19.5f);
                break;
            case SOUND:
                p.setStrokeWidth(1.8f);
                path.moveTo(3.5f, 9.5f);
                path.lineTo(7.5f, 9.5f);
                path.lineTo(12, 5.5f);
                path.lineTo(12, 18.5f);
                path.lineTo(7.5f, 14.5f);
                path.lineTo(3.5f, 14.5f);
                path.close();
                c.drawPath(path, p);
                r.set(7f, 8f, 17f, 16f);
                c.drawArc(r, -50f, 100f, false, p);
                r.set(4f, 4.5f, 20f, 19.5f);
                c.drawArc(r, -50f, 100f, false, p);
                break;
            case MENU:
                line(c, 5, 7, 19, 7);
                line(c, 5, 12, 19, 12);
                line(c, 5, 17, 19, 17);
                break;
            case REFRESH:
                r.set(5f, 5f, 19f, 19f);
                c.drawArc(r, 50f, 270f, false, p);
                line(c, 17.6f, 4.2f, 17.6f, 8.6f);
                line(c, 17.6f, 8.6f, 13.2f, 8.6f);
                break;
            case PLUS:
                line(c, 12, 5, 12, 19);
                line(c, 5, 12, 19, 12);
                break;
            case CLOSE:
                line(c, 6, 6, 18, 18);
                line(c, 18, 6, 6, 18);
                break;
            case PAUSE:
                p.setStyle(Paint.Style.FILL);
                r.set(6.5f, 5f, 10.5f, 19f);
                c.drawRoundRect(r, 1.4f, 1.4f, p);
                r.set(13.5f, 5f, 17.5f, 19f);
                c.drawRoundRect(r, 1.4f, 1.4f, p);
                break;
            case PLAY:
                p.setStyle(Paint.Style.FILL);
                path.moveTo(8, 5);
                path.lineTo(19, 12);
                path.lineTo(8, 19);
                path.close();
                c.drawPath(path, p);
                break;
            case STOP:
                p.setStyle(Paint.Style.FILL);
                r.set(6f, 6f, 18f, 18f);
                c.drawRoundRect(r, 2.5f, 2.5f, p);
                break;
            case TRASH:
                line(c, 4.5f, 7, 19.5f, 7);
                path.moveTo(9, 7);
                path.lineTo(9, 4);
                path.lineTo(15, 4);
                path.lineTo(15, 7);
                c.drawPath(path, p);
                path.reset();
                path.moveTo(6.5f, 7);
                path.lineTo(7.5f, 20);
                path.lineTo(16.5f, 20);
                path.lineTo(17.5f, 7);
                c.drawPath(path, p);
                line(c, 10.5f, 11, 10.5f, 16);
                line(c, 13.5f, 11, 13.5f, 16);
                break;
            case SEARCH:
                c.drawCircle(10.5f, 10.5f, 6f, p);
                line(c, 15, 15, 20, 20);
                break;
            case CHECK:
                path.moveTo(5, 12.5f);
                path.lineTo(10, 17.5f);
                path.lineTo(19, 7);
                c.drawPath(path, p);
                break;
            case VIDEO:
                r.set(3f, 6.5f, 15f, 17.5f);
                c.drawRoundRect(r, 3f, 3f, p);
                path.moveTo(15, 10.5f);
                path.lineTo(21, 7.5f);
                path.lineTo(21, 16.5f);
                path.lineTo(15, 13.5f);
                c.drawPath(path, p);
                break;
            case MUSIC:
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(8f, 18f, 3f, p);
                p.setStyle(Paint.Style.STROKE);
                line(c, 11, 18, 11, 5);
                path.moveTo(11, 5);
                path.lineTo(19, 7);
                path.lineTo(19, 10.5f);
                path.lineTo(11, 8.5f);
                c.drawPath(path, p);
                break;
            case FILE:
                path.moveTo(7, 3);
                path.lineTo(14, 3);
                path.lineTo(19, 8);
                path.lineTo(19, 21);
                path.lineTo(7, 21);
                path.close();
                c.drawPath(path, p);
                path.reset();
                path.moveTo(14, 3);
                path.lineTo(14, 8);
                path.lineTo(19, 8);
                c.drawPath(path, p);
                break;
            case GLOBE:
                c.drawCircle(12, 12, 8.5f, p);
                r.set(8.5f, 3.5f, 15.5f, 20.5f);
                c.drawOval(r, p);
                line(c, 3.5f, 12, 20.5f, 12);
                break;
            default:
                break;
        }
        c.restore();
    }

    @Override
    public void setAlpha(int alpha) {
        p.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        p.setColorFilter(cf);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
