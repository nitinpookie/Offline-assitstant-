package com.fastlink.browser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Small UI toolkit for the pill-style look: palette, chips, flow layout, bottom sheet, floating button. */
public final class Ui {
    private Ui() {
    }

    public static final int ACCENT = 0xFF0A84FF;
    public static final int INK = 0xFF1C1C1E;
    public static final int SUB = 0xFF8E8E93;
    public static final int BG = 0xFFF2F2F7;
    public static final int LINE = 0xFFE5E5EA;
    public static final int RED = 0xFFFF3B30;
    public static final int GREEN = 0xFF34C759;

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    public static GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    public static GradientDrawable stroked(int fill, float radiusPx, int stroke, int strokePx) {
        GradientDrawable g = round(fill, radiusPx);
        g.setStroke(strokePx, stroke);
        return g;
    }

    public static TextView label(Context c, String text, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    /** Soft "press" effect: the view shrinks slightly while a finger is on it. Clicks still work. */
    public static void press(final View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                x.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                x.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
            }
            return false;
        });
    }

    public static ImageView icon(Context c, int kind, int color) {
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Ic(kind, color));
        return iv;
    }

    public static void styleChip(TextView t, boolean active) {
        t.setTextColor(active ? Color.WHITE : INK);
        t.setBackground(round(active ? ACCENT : BG, dp(t.getContext(), 18)));
    }

    public static TextView chip(Context c, String label, boolean active) {
        TextView t = new TextView(c);
        t.setText(label);
        t.setTextSize(13.5f);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
        styleChip(t, active);
        press(t);
        return t;
    }

    /** Section title used inside sheets. */
    public static TextView section(Context c, String text) {
        TextView t = label(c, text.toUpperCase(), 11.5f, SUB, true);
        t.setLetterSpacing(0.08f);
        t.setPadding(dp(c, 20), dp(c, 14), dp(c, 20), dp(c, 6));
        return t;
    }

    // ---------------------------------------------------------------- flow layout (wrapping chips)

    public static class Flow extends ViewGroup {
        private final int gap;

        public Flow(Context c, int gapPx) {
            super(c);
            gap = gapPx;
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int full = MeasureSpec.getSize(wSpec);
            int maxW = full - getPaddingLeft() - getPaddingRight();
            int x = 0, y = 0, rowH = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View ch = getChildAt(i);
                if (ch.getVisibility() == GONE) continue;
                measureChild(ch, MeasureSpec.makeMeasureSpec(full, MeasureSpec.AT_MOST),
                        MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
                int cw = ch.getMeasuredWidth(), chh = ch.getMeasuredHeight();
                if (x > 0 && x + cw > maxW) {
                    x = 0;
                    y += rowH + gap;
                    rowH = 0;
                }
                x += cw + gap;
                rowH = Math.max(rowH, chh);
            }
            int h = y + rowH + getPaddingTop() + getPaddingBottom();
            setMeasuredDimension(full, resolveSize(h, hSpec));
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int maxW = r - l - getPaddingLeft() - getPaddingRight();
            int x = 0, y = 0, rowH = 0;
            for (int i = 0; i < getChildCount(); i++) {
                View ch = getChildAt(i);
                if (ch.getVisibility() == GONE) continue;
                int cw = ch.getMeasuredWidth(), chh = ch.getMeasuredHeight();
                if (x > 0 && x + cw > maxW) {
                    x = 0;
                    y += rowH + gap;
                    rowH = 0;
                }
                int left = getPaddingLeft() + x, top = getPaddingTop() + y;
                ch.layout(left, top, left + cw, top + chh);
                x += cw + gap;
                rowH = Math.max(rowH, chh);
            }
        }
    }

    /** ScrollView that never grows taller than maxH. */
    public static class MaxScroll extends ScrollView {
        public int maxH = Integer.MAX_VALUE;

        public MaxScroll(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int w, int h) {
            if (maxH != Integer.MAX_VALUE) {
                int mode = MeasureSpec.getMode(h);
                int size = MeasureSpec.getSize(h);
                int lim = mode == MeasureSpec.UNSPECIFIED ? maxH : Math.min(size, maxH);
                h = MeasureSpec.makeMeasureSpec(lim, MeasureSpec.AT_MOST);
            }
            super.onMeasure(w, h);
        }
    }

    // ---------------------------------------------------------------- bottom sheet (drag down to close)

    public static class Sheet {
        private final Context ctx;
        private final FrameLayout host;
        private final View scrim;
        private final LinearLayout panel;
        private final FrameLayout bodyBox;
        private final TextView titleTv;
        private boolean showing;
        private Runnable onHidden, onAnyHidden;

        public Sheet(Context c, FrameLayout parent) {
            ctx = c;
            host = new FrameLayout(c);
            host.setVisibility(View.GONE);

            scrim = new View(c);
            scrim.setBackgroundColor(0x66000000);
            scrim.setAlpha(0f);
            scrim.setOnClickListener(v -> hide());
            host.addView(scrim, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            panel = new LinearLayout(c);
            panel.setOrientation(LinearLayout.VERTICAL);
            float rad = dp(c, 26);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.WHITE);
            bg.setCornerRadii(new float[]{rad, rad, rad, rad, 0, 0, 0, 0});
            panel.setBackground(bg);
            panel.setElevation(dp(c, 16));
            panel.setClickable(true);

            LinearLayout header = new LinearLayout(c);
            header.setOrientation(LinearLayout.VERTICAL);
            header.setGravity(Gravity.CENTER_HORIZONTAL);
            header.setPadding(0, dp(c, 10), 0, dp(c, 4));
            View handle = new View(c);
            handle.setBackground(round(0xFFD1D1D6, dp(c, 3)));
            header.addView(handle, new LinearLayout.LayoutParams(dp(c, 42), dp(c, 5)));
            titleTv = label(c, "", 19, INK, true);
            titleTv.setPadding(dp(c, 20), dp(c, 12), dp(c, 20), dp(c, 4));
            titleTv.setGravity(Gravity.START);
            header.addView(titleTv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            panel.addView(header, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            bodyBox = new FrameLayout(c);
            panel.addView(bodyBox, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            host.addView(panel, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
            parent.addView(host, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            header.setOnTouchListener(new View.OnTouchListener() {
                float downY;
                VelocityTracker vt;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downY = e.getRawY();
                            vt = VelocityTracker.obtain();
                            vt.addMovement(e);
                            return true;
                        case MotionEvent.ACTION_MOVE: {
                            if (vt != null) vt.addMovement(e);
                            float dy = e.getRawY() - downY;
                            float ty = dy > 0 ? dy : dy / 8f;
                            panel.setTranslationY(Math.max(-dp(ctx, 24), ty));
                            float ph = Math.max(1f, panel.getHeight());
                            scrim.setAlpha(1f - Math.min(1f, Math.max(0f, dy) / ph));
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL: {
                            float dy = e.getRawY() - downY;
                            float vy = 0f;
                            if (vt != null) {
                                vt.computeCurrentVelocity(1000);
                                vy = vt.getYVelocity();
                                vt.recycle();
                                vt = null;
                            }
                            if (dy > panel.getHeight() * 0.28f || vy > 1400f) {
                                hide();
                            } else {
                                panel.animate().translationY(0f).setDuration(180).start();
                                scrim.animate().alpha(1f).setDuration(180).start();
                            }
                            return true;
                        }
                        default:
                            return false;
                    }
                }
            });
        }

        public boolean isShowing() {
            return showing;
        }

        public void setOnHidden(Runnable r) {
            onHidden = r;
        }

        /** Unlike setOnHidden this stays set: runs every time the sheet has finished closing. */
        public void setOnAnyHidden(Runnable r) {
            onAnyHidden = r;
        }

        /** scroll = wrap content in a ScrollView (capped height). tall = start near 70% of the screen. */
        public void show(String title, View content, boolean scroll, boolean tall) {
            int screenH = ctx.getResources().getDisplayMetrics().heightPixels;
            bodyBox.removeAllViews();
            titleTv.setText(title == null ? "" : title);
            titleTv.setVisibility(title == null || title.isEmpty() ? View.GONE : View.VISIBLE);
            int maxH = (int) (screenH * (tall ? 0.80f : 0.66f));
            if (scroll) {
                MaxScroll sv = new MaxScroll(ctx);
                sv.maxH = maxH;
                sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
                sv.setVerticalScrollBarEnabled(false);
                sv.addView(content, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                if (tall) sv.setMinimumHeight((int) (screenH * 0.45f));
                bodyBox.addView(sv, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            } else {
                bodyBox.addView(content, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            host.setVisibility(View.VISIBLE);
            if (!showing) {
                showing = true;
                scrim.setAlpha(0f);
                panel.setTranslationY(screenH);
                scrim.animate().alpha(1f).setDuration(200).start();
                panel.animate().translationY(0f).setDuration(280)
                        .setInterpolator(new DecelerateInterpolator(2f)).start();
            } else {
                panel.animate().cancel();
                panel.setTranslationY(0f);
                scrim.setAlpha(1f);
            }
        }

        public void hide() {
            if (!showing) return;
            showing = false;
            int ph = panel.getHeight() > 0 ? panel.getHeight()
                    : ctx.getResources().getDisplayMetrics().heightPixels;
            scrim.animate().alpha(0f).setDuration(180).start();
            panel.animate().translationY(ph).setDuration(210).withEndAction(() -> {
                if (!showing) {
                    host.setVisibility(View.GONE);
                    bodyBox.removeAllViews();
                    Runnable r = onHidden;
                    onHidden = null;
                    if (r != null) r.run();
                    if (onAnyHidden != null) onAnyHidden.run();
                }
            }).start();
        }
    }

    // ---------------------------------------------------------------- floating download button

    public static class Fab extends View {
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ringBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgeP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgeT = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval = new RectF();
        private final Ic icon = new Ic(Ic.DOWNLOAD, Color.WHITE);
        private int badge;
        private float prog = -1f;
        private float sx, sy, dX, dY;
        private boolean moved;

        public Fab(Context c) {
            super(c);
            float d = c.getResources().getDisplayMetrics().density;
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(3f * d);
            ring.setStrokeCap(Paint.Cap.ROUND);
            ring.setColor(Color.WHITE);
            ringBg.setStyle(Paint.Style.STROKE);
            ringBg.setStrokeWidth(3f * d);
            ringBg.setColor(0x55FFFFFF);
            badgeP.setColor(RED);
            badgeT.setColor(Color.WHITE);
            badgeT.setTextSize(11f * d);
            badgeT.setTextAlign(Paint.Align.CENTER);
            badgeT.setFakeBoldText(true);
            setBackground(oval(0xFF8E8E93));
            setElevation(8f * d);
            setClickable(true);
        }

        /** live = media found on this page (button turns blue); badge = number of items; progress 0..1 or -1. */
        public void setState(boolean live, int badgeCount, float progress) {
            boolean changedLook = (badge > 0) != (live);
            badge = badgeCount;
            prog = progress;
            setBackground(oval(live ? ACCENT : 0xFF8E8E93));
            if (changedLook) invalidate();
            invalidate();
        }

        public void bounce() {
            animate().scaleX(1.2f).scaleY(1.2f).setDuration(140)
                    .withEndAction(() -> animate().scaleX(1f).scaleY(1f).setDuration(160).start()).start();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float d = getResources().getDisplayMetrics().density;
            float cx = w / 2f, cy = h / 2f, s = 12f * d;
            icon.setBounds((int) (cx - s), (int) (cy - s), (int) (cx + s), (int) (cy + s));
            icon.draw(c);
            if (prog >= 0f) {
                float rr = Math.min(w, h) / 2f - 5f * d;
                oval.set(cx - rr, cy - rr, cx + rr, cy + rr);
                c.drawArc(oval, 0f, 360f, false, ringBg);
                c.drawArc(oval, -90f, 360f * Math.min(1f, prog), false, ring);
            }
            if (badge > 0) {
                float br = 9f * d;
                float bx = w - br - 1f * d, by = br + 1f * d;
                c.drawCircle(bx, by, br, badgeP);
                c.drawText(badge > 9 ? "9+" : String.valueOf(badge), bx, by + 4f * d, badgeT);
            }
        }

        private void clampToParent() {
            View p = (View) getParent();
            if (p == null) return;
            float minX = -getLeft(), maxX = p.getWidth() - getRight();
            float minY = -getTop(), maxY = p.getHeight() - getBottom();
            setTranslationX(Math.max(minX, Math.min(maxX, getTranslationX())));
            setTranslationY(Math.max(minY, Math.min(maxY, getTranslationY())));
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getRawX();
                    sy = e.getRawY();
                    dX = getTranslationX();
                    dY = getTranslationY();
                    moved = false;
                    animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float mx = e.getRawX() - sx, my = e.getRawY() - sy;
                    if (!moved && Math.hypot(mx, my) > ViewConfiguration.get(getContext()).getScaledTouchSlop()) {
                        moved = true;
                    }
                    if (moved) {
                        setTranslationX(dX + mx);
                        setTranslationY(dY + my);
                        clampToParent();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                    if (!moved) performClick();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                    return true;
                default:
                    return super.onTouchEvent(e);
            }
        }

        @Override
        public boolean performClick() {
            return super.performClick();
        }
    }
}
