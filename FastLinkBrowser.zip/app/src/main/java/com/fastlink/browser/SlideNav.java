package com.fastlink.browser;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * Bottom pill navigation with a draggable "lens" on top of the icons (like the iOS / Instagram tab bar).
 * Touch anywhere on the bar and the lens jumps under your finger; drag left / right to slide over the tabs;
 * lift the finger and the tab under the lens opens. A plain tap works the same way.
 * Each tab is a normal cell (see MainActivity.navItem): its click listener is fired when the finger lifts.
 */
public class SlideNav extends FrameLayout {

    private final LinearLayout row;
    private final View lens;
    private final int pad, gap;
    private float cellW;
    private int rest = 0, hover = -1;
    private boolean dragging;

    public SlideNav(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        pad = (int) (6 * d);
        gap = (int) (5 * d);
        setClipChildren(false);
        lens = new View(c);
        lens.setBackground(Ui.stroked(0x240A84FF, 26 * d, 0x400A84FF, 1));
        addView(lens, new LayoutParams(1, 1, Gravity.START | Gravity.CENTER_VERTICAL));
        row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(pad, 0, pad, 0);
        addView(row, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }

    /** Add the tab cells to this row (MainActivity.navItem does that). */
    public LinearLayout row() {
        return row;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        final int n = row.getChildCount();
        if (n == 0 || w <= 0 || h <= 0) return;
        cellW = (w - 2f * pad) / n;
        final int lw = Math.max(1, (int) cellW - gap);
        final int lh = Math.max(1, h - 2 * gap);
        post(() -> {
            LayoutParams lp = (LayoutParams) lens.getLayoutParams();
            lp.width = lw;
            lp.height = lh;
            lens.setLayoutParams(lp);
            lens.setTranslationX(posFor(rest));
            setHover(rest, false);
        });
    }

    private float posFor(int i) {
        float lw = Math.max(1, cellW - gap);
        return pad + cellW * i + (cellW - lw) / 2f;
    }

    private int indexAt(float x) {
        int n = row.getChildCount();
        if (n == 0 || cellW <= 0) return 0;
        int i = (int) ((x - pad) / cellW);
        return Math.max(0, Math.min(n - 1, i));
    }

    private void setHover(int i, boolean tick) {
        if (i == hover) return;
        hover = i;
        for (int k = 0; k < row.getChildCount(); k++) {
            Object tg = row.getChildAt(k).getTag();
            if (tg instanceof ImageView) {
                Drawable dr = ((ImageView) tg).getDrawable();
                if (dr instanceof Ic) ((Ic) dr).setColor(k == hover ? Ui.ACCENT : Ui.INK);
            }
        }
        if (tick) {
            try {
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            } catch (Throwable ignored) {
            }
        }
    }

    private void snapTo(int i) {
        lens.animate().translationX(posFor(i)).setDuration(190)
                .setInterpolator(new OvershootInterpolator(0.9f)).start();
    }

    private void follow(float x, int ms) {
        float lw = Math.max(1, cellW - gap);
        float min = posFor(0);
        float max = posFor(row.getChildCount() - 1);
        float tx = Math.max(min, Math.min(max, x - lw / 2f));
        lens.animate().translationX(tx).setDuration(ms).setInterpolator(new LinearInterpolator()).start();
        setHover(indexAt(x), true);
    }

    /** The tab that is "current" (Home screen or Web page). The lens returns here after a sheet closes. */
    public void setRest(int i) {
        int old = rest;
        rest = i;
        if (!dragging && hover == old && i != old) {
            setHover(i, false);
            snapTo(i);
        }
    }

    public void backToRest() {
        if (dragging) return;
        setHover(rest, false);
        snapTo(rest);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        return true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int n = row.getChildCount();
        if (n == 0 || cellW <= 0) return false;
        float x = e.getX();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                follow(x, 110);
                lens.animate().scaleX(1.12f).scaleY(1.1f).setDuration(120).start();
                return true;
            case MotionEvent.ACTION_MOVE:
                follow(x, 0);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                dragging = false;
                lens.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
                if (e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                    backToRest();
                    return true;
                }
                int idx = indexAt(x);
                setHover(idx, false);
                snapTo(idx);
                View cell = row.getChildAt(idx);
                if (cell != null) cell.performClick();
                return true;
            }
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}
