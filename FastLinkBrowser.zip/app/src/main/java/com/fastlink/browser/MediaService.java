package com.fastlink.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Keeps the app process alive (and the CPU awake) while a page is playing media with the screen locked,
 * or while files are downloading. Shows a notification with Pause / Stop for the music.
 * The state fields below are set by MainActivity / DownloadCenter, then sync() is called.
 */
public class MediaService extends Service {

    public interface Controller {
        /** cmd: "toggle", "play" or "pause" */
        void command(String cmd);
    }

    public static volatile Controller controller;
    public static volatile boolean hold;        // a media page is (or recently was) playing
    public static volatile boolean playing;
    public static volatile String title = "";
    public static volatile int dlActive;
    public static volatile int dlPercent = -1;

    private static final String CH = "nixu_keep";
    private static final int NID = 4711;
    private static final String A_TOGGLE = "nixu.toggle";
    private static final String A_STOP = "nixu.stop";

    private MediaSession session;
    private PowerManager.WakeLock wl;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable idleStop = () -> {
        hold = false;
        playing = false;
        refresh();
    };

    /** Start / update / stop the service so it matches the static state. Safe to call often. */
    public static void sync(Context c) {
        Context app = c.getApplicationContext();
        Intent i = new Intent(app, MediaService.class);
        try {
            if (hold || dlActive > 0) {
                if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i);
                else app.startService(i);
            } else {
                app.stopService(i);
            }
        } catch (Throwable ignored) {
            // e.g. started from the background on a new Android version: just skip
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? null : intent.getAction();
        if (A_TOGGLE.equals(act)) {
            // explicit command (the page may sit in an iframe, so it cannot decide "toggle" for itself)
            cmd(playing ? "pause" : "play");
        } else if (A_STOP.equals(act)) {
            cmd("pause");
            hold = false;
            playing = false;
        }
        refresh();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(idleStop);
        wake(false);
        if (session != null) {
            try {
                session.setActive(false);
                session.release();
            } catch (Throwable ignored) {
            }
            session = null;
        }
        super.onDestroy();
    }

    private void cmd(String c) {
        Controller k = controller;
        if (k != null) k.command(c);
    }

    private void refresh() {
        boolean needMedia = hold;
        boolean needDl = dlActive > 0;
        updateSession();
        Notification n = build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                int type = 0;
                if (needMedia) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
                if (needDl || !needMedia) type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC;
                startForeground(NID, n, type);
            } else {
                startForeground(NID, n);
            }
        } catch (Throwable t) {
            stopSelf();
            return;
        }
        wake(playing || needDl);
        h.removeCallbacks(idleStop);
        if (needMedia && !playing) h.postDelayed(idleStop, 20L * 60L * 1000L);
        if (!needMedia && !needDl) {
            stopForeground(true);
            stopSelf();
        }
    }

    private void updateSession() {
        try {
            if (hold) {
                if (session == null) {
                    session = new MediaSession(this, "NixuBrowse");
                    session.setCallback(new MediaSession.Callback() {
                        @Override
                        public void onPlay() {
                            cmd("play");
                        }

                        @Override
                        public void onPause() {
                            cmd("pause");
                        }

                        @Override
                        public void onStop() {
                            cmd("pause");
                        }
                    });
                    session.setActive(true);
                }
                session.setMetadata(new MediaMetadata.Builder()
                        .putString(MediaMetadata.METADATA_KEY_TITLE, title == null ? "" : title)
                        .build());
                PlaybackState ps = new PlaybackState.Builder()
                        .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                                | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_STOP)
                        .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                                PlaybackState.PLAYBACK_POSITION_UNKNOWN, playing ? 1f : 0f)
                        .build();
                session.setPlaybackState(ps);
            } else if (session != null) {
                session.setActive(false);
                session.release();
                session = null;
            }
        } catch (Throwable ignored) {
        }
    }

    private PendingIntent svc(String action) {
        Intent i = new Intent(this, MediaService.class).setAction(action);
        return PendingIntent.getService(this, action.hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification build() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "Nixu Browse", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = new Notification.Builder(this, CH);
        b.setSmallIcon(hold ? android.R.drawable.stat_sys_headset : android.R.drawable.stat_sys_download);
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        b.setContentIntent(PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        b.setOnlyAlertOnce(true);
        b.setOngoing(true);
        b.setShowWhen(false);

        StringBuilder text = new StringBuilder();
        if (hold) text.append(playing ? "Playing" : "Paused");
        if (dlActive > 0) {
            if (text.length() > 0) text.append("  \u2022  ");
            text.append("Downloading ").append(dlActive);
            if (dlPercent >= 0) text.append(" (").append(dlPercent).append("%)");
        }
        String t = title == null ? "" : title.trim();
        b.setContentTitle(hold ? (t.isEmpty() ? "Nixu Browse" : t) : "Downloads");
        b.setContentText(text.toString());
        if (dlActive > 0) {
            if (dlPercent >= 0) b.setProgress(100, dlPercent, false);
            else b.setProgress(0, 0, true);
        }
        if (hold) {
            Notification.Action a = new Notification.Action.Builder(
                    Icon.createWithResource(this, playing ? android.R.drawable.ic_media_pause
                            : android.R.drawable.ic_media_play),
                    playing ? "Pause" : "Play", svc(A_TOGGLE)).build();
            Notification.Action s = new Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Stop", svc(A_STOP)).build();
            b.addAction(a);
            b.addAction(s);
            Notification.MediaStyle ms = new Notification.MediaStyle();
            ms.setShowActionsInCompactView(0, 1);
            if (session != null) ms.setMediaSession(session.getSessionToken());
            b.setStyle(ms);
        }
        return b.build();
    }

    private void wake(boolean on) {
        try {
            if (on) {
                if (wl == null) {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nixu:keep");
                    wl.setReferenceCounted(false);
                }
                if (!wl.isHeld()) wl.acquire(4L * 60L * 60L * 1000L);
            } else if (wl != null && wl.isHeld()) {
                wl.release();
            }
        } catch (Throwable ignored) {
        }
    }
}
