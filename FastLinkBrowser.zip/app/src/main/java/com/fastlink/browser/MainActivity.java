package com.fastlink.browser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {

    // speed modes: 0 = off, 1 = smart (speeds up only on pages that look like a link-shortener step), 2 = turbo (always)
    private static final int[] RATES = {1, 10, 25};
    private static final String[] MODE_NAMES = {"Speed OFF", "Smart speed", "Turbo (har page par)"};

    // Ad / popup network domains (sub-resources are answered with harmless stubs, main-frame jumps are blocked)
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "googletagservices.com", "2mdn.net",
            "adnxs.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "pubmatic.com", "rubiconproject.com", "openx.net", "amazon-adsystem.com",
            "adsafeprotected.com", "moatads.com", "advertising.com", "adform.net",
            "smartadserver.com", "casalemedia.com", "indexww.com", "teads.tv",
            "mgid.com", "revcontent.com", "adskeeper.com", "adsrvr.org",
            "serving-sys.com", "lijit.com", "sharethrough.com", "yieldmo.com",
            "media.net", "zedo.com", "adition.com",
            "popads.net", "popcash.net", "propellerads.com", "exoclick.com",
            "exosrv.com", "exdynsrv.com", "realsrv.com", "juicyads.com", "adsterra.com", "hilltopads.net",
            "clickadu.com", "adcash.com", "bidvertiser.com", "onclickads.net",
            "a-ads.com", "ad-maven.com", "admaven.com", "monetag.com",
            "profitablecpmrate.com", "effectivegatecpm.com", "highperformanceformat.com",
            "yllix.com", "trafficjunky.net", "tsyndicate.com", "adtng.com",
            "trafficstars.com", "galaksion.com", "richads.com", "bidgear.com",
            "onclickalgo.com", "onclckmn.com", "pushame.com", "pushsar.com"
    };

    // Hosts that are known link-shortener / gate sites (used only as a hint; page content is checked too)
    private static final String[] SHORT_HOSTS = {
            "ouo.io", "ouo.press", "shrinkme.io", "shrinkearn.com", "shrtfly.com", "exe.io", "exey.io",
            "fc.lc", "fcc.lc", "clk.sh", "gplinks.co", "gplinks.in", "droplink.co", "linkvertise.com",
            "link-to.net", "lootlabs.gg", "loot-link.com", "loot-links.com", "work.ink", "adfoc.us", "za.gl",
            "earnlink.io", "tnlink.in", "tnshort.net", "shortingly.in", "arolinks.com", "ez4short.com",
            "earn4link.in", "adrinolinks.in", "cuty.io", "shorte.st", "sh.st", "bc.vc", "adf.ly",
            "boost.ink", "rekonise.com", "shareus.io", "gyanilinks.com", "indiurl.in", "kpslink.in",
            "linkpays.in", "rocklinks.net", "urlpay.in", "inshorturl.com", "dalink.in", "vplink.in",
            "safelinku.com", "linkshrink.net", "adshrink.it", "short2url.in", "urlshortx.com"
    };

    // Final-destination hosts: a new tab to one of these is opened straight away
    private static final String[] FILE_HOSTS = {
            "drive.google.com", "docs.google.com", "mega.nz", "mediafire.com", "t.me", "telegram.me",
            "dropbox.com", "terabox.com", "1024terabox.com", "github.com", "play.google.com", "gofile.io", "pixeldrain.com"
    };

    // Share / social endpoints that use ?u= or ?url= and must never be treated as redirects
    private static final String[] SOCIAL_HOSTS = {
            "facebook.com", "twitter.com", "x.com", "whatsapp.com", "wa.me", "linkedin.com", "pinterest.com",
            "reddit.com", "t.me", "telegram.me", "tumblr.com", "vk.com"
    };

    private static final String[] REDIR_PARAMS = {
            "r", "u", "url", "link", "go", "goto", "dest", "destination", "target", "to", "out",
            "redirect", "redirect_url", "redir", "next", "l", "d", "href", "q"
    };

    private static final String ADS_STUB =
            "(window.adsbygoogle=window.adsbygoogle||[]);window.adsbygoogle.loaded=true;window.adsbygoogle.push=function(){return 0};";

    private static final String GPT_STUB =
            "(function(){var w=window,g=w.googletag=w.googletag||{};var q=g.cmd||[];"
            + "var ch=new Proxy(function(){},{get:function(t,p){if(p==='then')return undefined;"
            + "if(p===Symbol.toPrimitive)return function(){return ''};return ch},apply:function(){return ch}});"
            + "g.apiReady=true;g.pubadsReady=true;"
            + "g.cmd={push:function(f){try{if(typeof f==='function')f.call(g)}catch(e){}return 1}};"
            + "['defineSlot','defineOutOfPageSlot','pubads','companionAds','content','sizeMapping','enableServices',"
            + "'display','destroySlots','setTargeting','addEventListener'].forEach(function(n){g[n]=function(){return ch}});"
            + "if(q.forEach)q.forEach(function(f){try{f.call(g)}catch(e){}})})();";

    // 1x1 transparent GIF
    private static final byte[] GIF = Base64.decode("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", Base64.DEFAULT);

    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private TextView speedBtn, autoBtn, adBtn, menuBtn, dlBtn;
    private LinearLayout barBox;
    private TextView barMsg, barAct;
    private Runnable hideBar;
    private SharedPreferences prefs;
    private volatile int speedMode;
    private volatile boolean autoOn, adOn;
    private boolean desktop, defaultWide, defaultOverview;
    private ScriptHandler scriptHandler;
    private boolean docStartSupported;
    private String videoUrl;
    private String bridgeName;
    private String mobileUa, desktopUa;
    private String coreJs = "", engineJs = "";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final Set<String> slowHosts = new HashSet<>();
    private final LinkedHashMap<String, String> radar = new LinkedHashMap<>();
    private volatile long trustPopupUntil;
    private String allowOnceUrl, lastDecoded;
    private long lastAnomalyAt;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("fastlink", MODE_PRIVATE);
        speedMode = prefs.getInt("speedMode", 1);
        autoOn = prefs.getBoolean("auto", true);
        adOn = prefs.getBoolean("ads", true);
        slowHosts.addAll(prefs.getStringSet("slow", Collections.<String>emptySet()));
        bridgeName = "_f" + Long.toString(Math.abs(rnd.nextLong()), 36);
        coreJs = asset("flb_core.js");
        engineJs = asset("flb_engine.js");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(4), dp(4), dp(4));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setHint("Search or enter URL");
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                return true;
            }
            return false;
        });
        bar.addView(urlBar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        speedBtn = toggle("\u26A1", v -> {
            speedMode = (speedMode + 1) % 3;
            prefs.edit().putInt("speedMode", speedMode).apply();
            changed(MODE_NAMES[speedMode]);
        });
        autoBtn = toggle("\uD83E\uDD16", v -> {
            autoOn = !autoOn;
            prefs.edit().putBoolean("auto", autoOn).apply();
            changed(autoOn ? "Auto-click ON" : "Auto-click OFF");
        });
        adBtn = toggle("\uD83D\uDEE1", v -> {
            adOn = !adOn;
            prefs.edit().putBoolean("ads", adOn).apply();
            changed(adOn ? "Ad block ON" : "Ad block OFF");
        });
        menuBtn = toggle("\u22EE", v -> showMenu());
        bar.addView(speedBtn);
        bar.addView(autoBtn);
        bar.addView(adBtn);
        bar.addView(menuBtn);
        root.addView(bar);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        FrameLayout content = new FrameLayout(this);
        web = new WebView(this);
        content.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        dlBtn = new TextView(this);
        dlBtn.setText("\u2B07");
        dlBtn.setTextSize(22);
        dlBtn.setTextColor(Color.WHITE);
        dlBtn.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(0, 150, 60));
        dlBtn.setBackground(circle);
        dlBtn.setElevation(dp(6));
        dlBtn.setVisibility(View.GONE);
        dlBtn.setOnClickListener(v -> showDownloadDialog());
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(dp(54), dp(54),
                Gravity.BOTTOM | Gravity.END);
        dlp.setMargins(0, 0, dp(16), dp(72));
        content.addView(dlBtn, dlp);

        // bottom info bar (blocked redirect, hints, "Allow"/"Open" actions)
        barBox = new LinearLayout(this);
        barBox.setOrientation(LinearLayout.HORIZONTAL);
        barBox.setGravity(Gravity.CENTER_VERTICAL);
        barBox.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(235, 30, 30, 34));
        bg.setCornerRadius(dp(12));
        barBox.setBackground(bg);
        barBox.setElevation(dp(8));
        barMsg = new TextView(this);
        barMsg.setTextColor(Color.WHITE);
        barMsg.setTextSize(13);
        barBox.addView(barMsg, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        barAct = new TextView(this);
        barAct.setTextColor(Color.rgb(120, 190, 255));
        barAct.setTextSize(14);
        barAct.setPadding(dp(14), dp(4), dp(4), dp(4));
        barBox.addView(barAct);
        barBox.setVisibility(View.GONE);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        blp.setMargins(dp(10), 0, dp(10), dp(10));
        content.addView(barBox, blp);
        hideBar = () -> barBox.setVisibility(View.GONE);

        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        // true on purpose: every window.open is caught in onCreateWindow and filtered there,
        // so the real "get link" popup is no longer silently dropped.
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        defaultWide = s.getUseWideViewPort();
        defaultOverview = s.getLoadWithOverviewMode();
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        // look like normal Chrome: no "wv" marker, no X-Requested-With header
        String ua = s.getUserAgentString();
        mobileUa = ua.replace("; wv)", ")").replace(" Version/4.0", "");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("Chrome/(\\d+)").matcher(mobileUa);
        String major = m.find() ? m.group(1) : "124";
        desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + major + ".0.0.0 Safari/537.36";
        applyUa();
        try {
            // reflection on purpose: if this androidx.webkit version lacks the API, the build still works
            if (WebViewFeature.isFeatureSupported("REQUESTED_WITH_HEADER_ALLOW_LIST")) {
                WebSettingsCompat.class.getMethod("setRequestedWithHeaderOriginAllowList",
                        WebSettings.class, Set.class).invoke(null, s, Collections.<String>emptySet());
            }
        } catch (Throwable ignored) {
        }

        web.addJavascriptInterface(new Bridge(), bridgeName);
        docStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                // only http/https; blocks intent:// and app-open redirects
                if (!("http".equals(sc) || "https".equals(sc))) return true;
                if (!r.isForMainFrame()) return false;
                final String s = u.toString();
                if (s.equals(allowOnceUrl)) {
                    allowOnceUrl = null;
                    return false;
                }
                if (adOn) {
                    if (isAdUrl(u)) {
                        blockedJump(u);
                        return true;
                    }
                    if (isSearchPage(u) && !isSearchHost(hostOf(v.getUrl()))) {
                        blockedJump(u); // fake "continue" that throws you to a Google search
                        return true;
                    }
                }
                if (autoOn) {
                    final String d = decodeRedirect(u);
                    if (d != null && !d.equals(lastDecoded)) {
                        lastDecoded = d;
                        ui.post(() -> web.loadUrl(d));
                        return true;
                    }
                }
                return false;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (adOn && !r.isForMainFrame() && isAdUrl(r.getUrl())) {
                    return stub(r);
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                urlBar.setText(url);
                videoUrl = null;
                dlBtn.setVisibility(View.GONE);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (!docStartSupported) {
                    v.evaluateJavascript(script(), null);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message m) {
                return capturePopup(m);
            }

            @Override
            public boolean onJsBeforeUnload(WebView v, String url, String message, JsResult result) {
                result.confirm(); // "Leave site?" prompts must never stop an automatic redirect
                return true;
            }
        });

        web.setDownloadListener((url, ua2, cd, mime, len) -> {
            if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                enqueue(url, URLUtil.guessFileName(url, cd, mime), ua2,
                        CookieManager.getInstance().getCookie(url), web.getUrl());
            }
        });

        applyMode();

        Uri data = getIntent() != null ? getIntent().getData() : null;
        if (data != null) {
            web.loadUrl(data.toString());
        } else {
            web.loadUrl("https://www.google.com");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getData() != null) {
            web.loadUrl(intent.getData().toString());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            web.destroy();
        } catch (Exception ignored) {
        }
    }

    // ---------- JS bridge ----------

    private class Bridge {
        @JavascriptInterface
        public void videoFound(String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(() -> {
                videoUrl = url;
                dlBtn.setVisibility(View.VISIBLE);
            });
        }

        @JavascriptInterface
        public void noVideo() {
            runOnUiThread(() -> {
                videoUrl = null;
                dlBtn.setVisibility(View.GONE);
            });
        }

        // a real touch (isTrusted = true) at page coordinates already converted to view pixels
        @JavascriptInterface
        public void tap(final float x, final float y, final int tier) {
            ui.post(() -> {
                if (x < 0 || y < 0 || x > web.getWidth() || y > web.getHeight()) return;
                if (tier >= 2) trustPopupUntil = SystemClock.uptimeMillis() + 5000;
                final long t = SystemClock.uptimeMillis();
                final float jx = x + (rnd.nextFloat() - 0.5f) * 2f;
                final float jy = y + (rnd.nextFloat() - 0.5f) * 2f;
                sendTouch(MotionEvent.ACTION_DOWN, t, t, jx, jy);
                ui.postDelayed(() -> sendTouch(MotionEvent.ACTION_UP, t, SystemClock.uptimeMillis(), jx, jy),
                        55 + rnd.nextInt(60));
            });
        }

        @JavascriptInterface
        public void hint(final String msg) {
            if (msg == null) return;
            ui.post(() -> showBar(msg, null, null));
        }

        @JavascriptInterface
        public void busy(final boolean on) {
            ui.post(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        // the site complained about our speed -> switch that site to real-time and retry
        @JavascriptInterface
        public void anomaly(final String host) {
            ui.post(() -> {
                if (host == null || host.isEmpty()) return;
                long now = SystemClock.uptimeMillis();
                if (slowHosts.contains(host) || now - lastAnomalyAt < 15000) return;
                lastAnomalyAt = now;
                slowHosts.add(host);
                saveSlow();
                applyMode();
                showBar("Is site ne speed pakdi. " + host + " ab real-time mode mein, dobara try", null, null);
                web.reload();
            });
        }
    }

    private void sendTouch(int action, long down, long now, float x, float y) {
        MotionEvent.PointerProperties pp = new MotionEvent.PointerProperties();
        pp.id = 0;
        pp.toolType = MotionEvent.TOOL_TYPE_FINGER;
        MotionEvent.PointerCoords pc = new MotionEvent.PointerCoords();
        pc.x = x;
        pc.y = y;
        pc.pressure = action == MotionEvent.ACTION_UP ? 0f : 0.8f;
        pc.size = 0.6f;
        MotionEvent e = MotionEvent.obtain(down, now, action, 1,
                new MotionEvent.PointerProperties[]{pp}, new MotionEvent.PointerCoords[]{pc},
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
        web.dispatchTouchEvent(e);
        e.recycle();
    }

    // ---------- toggles / scripts ----------

    private TextView toggle(String label, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(20);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        t.setOnClickListener(l);
        return t;
    }

    private void changed(String msg) {
        applyMode();
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        web.reload();
    }

    private void applyMode() {
        speedBtn.setAlpha(speedMode > 0 ? 1f : 0.3f);
        speedBtn.setText(speedMode == 2 ? "\uD83D\uDE80" : "\u26A1");
        autoBtn.setAlpha(autoOn ? 1f : 0.3f);
        adBtn.setAlpha(adOn ? 1f : 0.3f);
        if (docStartSupported) {
            if (scriptHandler != null) {
                scriptHandler.remove();
                scriptHandler = null;
            }
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(
                    web, script(), Collections.singleton("*"));
        }
    }

    private void applyUa() {
        WebSettings s = web.getSettings();
        s.setUserAgentString(desktop ? desktopUa : mobileUa);
        s.setUseWideViewPort(desktop || defaultWide);
        s.setLoadWithOverviewMode(desktop || defaultOverview);
    }

    private String script() {
        JSONObject c = new JSONObject();
        try {
            c.put("n", bridgeName);
            c.put("mode", speedMode);
            c.put("rate", RATES[speedMode]);
            c.put("auto", autoOn);
            c.put("ads", adOn);
            c.put("slow", new JSONArray(new ArrayList<>(slowHosts)));
            c.put("adh", new JSONArray(Arrays.asList(AD_HOSTS)));
            c.put("sh", new JSONArray(Arrays.asList(SHORT_HOSTS)));
        } catch (Exception ignored) {
        }
        return "(function(){var K='" + bridgeName + "x';if(window[K])return;"
                + "Object.defineProperty(window,K,{value:1});\nvar C=" + c + ";\n"
                + coreJs + "\n" + engineJs + "\n})();";
    }

    private String asset(String name) {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            copy(in, bo);
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void saveSlow() {
        prefs.edit().putStringSet("slow", new HashSet<>(slowHosts)).apply();
    }

    // ---------- host helpers ----------

    private static String hostOf(String url) {
        if (url == null) return "";
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? "" : h.toLowerCase();
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean hostIs(String h, String... list) {
        if (h == null) return false;
        for (String d : list) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    private static String rootHost(String h) {
        if (h == null) return "";
        String[] p = h.toLowerCase().split("\\.");
        if (p.length <= 2) return h.toLowerCase();
        String l = p[p.length - 1], s = p[p.length - 2];
        if (l.length() == 2 && s.matches("co|com|org|net|gov|ac|edu|nic")) {
            return p[p.length - 3] + "." + s + "." + l;
        }
        return s + "." + l;
    }

    private boolean isAdUrl(Uri u) {
        String h = u.getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        if (hostIs(h, AD_HOSTS)) return true;
        if (h.equals("youtube.com") || h.endsWith(".youtube.com")) {
            String p = u.getPath();
            if (p != null && (p.startsWith("/pagead/") || p.startsWith("/api/stats/ads")
                    || p.startsWith("/get_midroll_") || p.contains("/ptracking"))) {
                return true;
            }
        }
        return false;
    }

    private static boolean isSearchHost(String h) {
        return h.matches("(.*\\.)?google\\.[a-z.]+") || hostIs(h, "bing.com", "duckduckgo.com", "search.yahoo.com");
    }

    private static boolean isSearchPage(Uri u) {
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        String p = u.getPath() == null ? "" : u.getPath();
        if (h.matches("(.*\\.)?google\\.[a-z.]+") && p.startsWith("/search")) return true;
        if (hostIs(h, "bing.com") && p.startsWith("/search")) return true;
        if (hostIs(h, "duckduckgo.com") && u.getQueryParameter("q") != null) return true;
        return hostIs(h, "search.yahoo.com");
    }

    private void blockedJump(final Uri u) {
        final String s = u.toString();
        ui.post(() -> showBar("Fake redirect roka: " + hostOf(s), "Allow", () -> {
            allowOnceUrl = s;
            web.loadUrl(s);
        }));
    }

    // Reads the real target out of ?r=<base64>, ?url=<encoded url> and similar redirect parameters
    private String decodeRedirect(Uri u) {
        try {
            String host = u.getHost();
            if (host == null) return null;
            host = host.toLowerCase();
            if (hostIs(host, SOCIAL_HOSTS)) return null;
            String path = u.getPath() == null ? "" : u.getPath().toLowerCase();
            boolean googleUrl = host.matches("(.*\\.)?google\\.[a-z.]+") && path.equals("/url");
            boolean ytRedirect = hostIs(host, "youtube.com") && path.equals("/redirect");
            boolean pathHint = path.matches(".*/(go|out|redirect|redir|away|link|l|r|click|safe|skip|exit|jump|bridge|visit)(/.*)?");
            boolean shortHost = hostIs(host, SHORT_HOSTS);
            for (String name : u.getQueryParameterNames()) {
                boolean listed = false;
                for (String p : REDIR_PARAMS) {
                    if (p.equalsIgnoreCase(name)) {
                        listed = true;
                        break;
                    }
                }
                if (!listed) continue;
                String v = u.getQueryParameter(name);
                if (v == null || v.length() < 12) continue;
                String dec = null;
                if (v.startsWith("aHR0")) {
                    dec = b64(v);
                } else if ((v.startsWith("http://") || v.startsWith("https://"))
                        && (pathHint || googleUrl || ytRedirect || shortHost)) {
                    dec = v;
                }
                if (dec == null) continue;
                Uri d = Uri.parse(dec);
                String dh = d.getHost();
                if (dh == null || !dh.contains(".") || dh.equalsIgnoreCase(host)) continue;
                if (isAdUrl(d) || isSearchPage(d)) continue;
                return dec;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String b64(String v) {
        try {
            String s = v.replace('-', '+').replace('_', '/');
            while (s.length() % 4 != 0) s += "=";
            String r = new String(Base64.decode(s, Base64.DEFAULT), "UTF-8").trim();
            return r.startsWith("http://") || r.startsWith("https://") ? r : null;
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- harmless answers for blocked ad requests (so anti-adblock checks pass) ----------

    private WebResourceResponse stub(WebResourceRequest r) {
        Uri u = r.getUrl();
        String p = u.getPath() == null ? "" : u.getPath().toLowerCase();
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        Map<String, String> req = r.getRequestHeaders();
        String accept = req == null ? null : req.get("Accept");
        byte[] body;
        String mime;
        if (p.endsWith("adsbygoogle.js") || p.contains("/show_ads")) {
            body = ADS_STUB.getBytes();
            mime = "application/javascript";
        } else if (p.endsWith("/gpt.js") || p.contains("pubads_impl") || h.contains("googletagservices")) {
            body = GPT_STUB.getBytes();
            mime = "application/javascript";
        } else if (p.matches(".*\\.(gif|png|jpe?g|webp|svg)$") || (accept != null && accept.startsWith("image/"))) {
            body = GIF;
            mime = "image/gif";
        } else if (accept != null && accept.contains("text/html")) {
            body = "<!doctype html><html><body></body></html>".getBytes();
            mime = "text/html";
        } else if (p.endsWith(".css")) {
            body = "/* */".getBytes();
            mime = "text/css";
        } else if (accept != null && accept.contains("application/json")) {
            body = "{}".getBytes();
            mime = "application/json";
        } else {
            body = "/* */".getBytes();
            mime = "application/javascript";
        }
        Map<String, String> hd = new HashMap<>();
        hd.put("Access-Control-Allow-Origin", "*");
        hd.put("Cache-Control", "no-store");
        return new WebResourceResponse(mime, "utf-8", 200, "OK", hd, new ByteArrayInputStream(body));
    }

    // ---------- popups (window.open): ads dropped, the real "get link" popup kept ----------

    private boolean capturePopup(Message m) {
        if (m == null || !(m.obj instanceof WebView.WebViewTransport)) return false;
        final WebView tmp = new WebView(this);
        tmp.setWebViewClient(new WebViewClient() {
            private volatile boolean done;

            private void got(final String url) {
                if (done || url == null || url.startsWith("about:") || url.startsWith("blob:")
                        || url.startsWith("data:") || url.startsWith("javascript:")) return;
                done = true;
                ui.post(() -> {
                    handlePopup(url);
                    try {
                        tmp.stopLoading();
                        tmp.destroy();
                    } catch (Exception ignored) {
                    }
                });
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                got(r.getUrl().toString());
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                got(url);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (r.isForMainFrame()) got(r.getUrl().toString());
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        ui.postDelayed(() -> {
            try {
                tmp.destroy();
            } catch (Exception ignored) {
            }
        }, 12000);
        WebView.WebViewTransport tr = (WebView.WebViewTransport) m.obj;
        tr.setWebView(tmp);
        m.sendToTarget();
        return true;
    }

    private void handlePopup(final String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        Uri u = Uri.parse(url);
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        if (h.isEmpty()) return;
        String curHost = hostOf(web.getUrl());
        if (adOn && (isAdUrl(u) || isSearchPage(u))) {
            showBar("Popup roka: " + h, "Open", () -> web.loadUrl(url));
            return;
        }
        boolean trusted = autoOn && SystemClock.uptimeMillis() < trustPopupUntil;
        boolean sameSite = rootHost(h).equals(rootHost(curHost));
        if (sameSite || trusted || hostIs(h, FILE_HOSTS) || hostIs(h, SHORT_HOSTS)) {
            web.loadUrl(url);
            return;
        }
        addRadar(url, "popup");
        showBar("Naya tab roka: " + h, "Open", () -> web.loadUrl(url));
    }

    private void addRadar(String url, String label) {
        radar.put(url, label);
        while (radar.size() > 30) {
            String first = radar.keySet().iterator().next();
            radar.remove(first);
        }
    }

    // ---------- bottom bar, menu, link radar ----------

    private void showBar(String msg, String action, final Runnable r) {
        barMsg.setText(msg);
        if (action != null && r != null) {
            barAct.setText(action);
            barAct.setVisibility(View.VISIBLE);
            barAct.setOnClickListener(v -> {
                barBox.setVisibility(View.GONE);
                r.run();
            });
        } else {
            barAct.setVisibility(View.GONE);
        }
        barBox.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideBar);
        ui.postDelayed(hideBar, 6000);
    }

    private void showMenu() {
        final String cur = web.getUrl();
        final String root = rootHost(hostOf(cur));
        final boolean slow = slowHosts.contains(root);
        String[] items = {
                "\uD83D\uDD17 Link Radar (mile hue links)",
                "\uD83E\uDDF9 Page unlock (overlay / adblock wall hatao)",
                slow ? "\u23F1 Real-time mode: ON (is site par)" : "\u23F1 Real-time mode: OFF (is site par)",
                desktop ? "\uD83D\uDDA5 Desktop site: ON" : "\uD83D\uDDA5 Desktop site: OFF",
                "\u267B Seekhi hui sites reset",
                "\uD83D\uDCCB URL copy"
        };
        new AlertDialog.Builder(this).setItems(items, (d, which) -> {
            switch (which) {
                case 0:
                    showRadar();
                    break;
                case 1:
                    web.evaluateJavascript("(function(){var f=window['" + bridgeName
                            + "u'];return f?f():-1})()", v -> showBar(
                            "0".equals(v) ? "Hatane layak overlay nahi mila" : "Page unlock kiya", null, null));
                    break;
                case 2:
                    if (root.isEmpty()) break;
                    if (slow) slowHosts.remove(root);
                    else slowHosts.add(root);
                    saveSlow();
                    applyMode();
                    Toast.makeText(this, slow ? "Is site par speed wapas" : "Is site par real-time", Toast.LENGTH_SHORT).show();
                    web.reload();
                    break;
                case 3:
                    desktop = !desktop;
                    applyUa();
                    web.reload();
                    break;
                case 4:
                    slowHosts.clear();
                    saveSlow();
                    applyMode();
                    Toast.makeText(this, "Reset ho gaya", Toast.LENGTH_SHORT).show();
                    break;
                case 5:
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null && cur != null) cm.setPrimaryClip(ClipData.newPlainText("url", cur));
                    Toast.makeText(this, "Copy ho gaya", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }).show();
    }

    private void showRadar() {
        web.evaluateJavascript("(function(){var f=window['" + bridgeName + "h'];return f?f():'[]'})()", value -> {
            final ArrayList<String> urls = new ArrayList<>();
            final ArrayList<String> labels = new ArrayList<>();
            try {
                Object o = new JSONTokener(value == null ? "\"[]\"" : value).nextValue();
                JSONArray arr = new JSONArray(o instanceof String ? (String) o : "[]");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject j = arr.getJSONObject(i);
                    String u = j.getString("u");
                    urls.add(u);
                    labels.add((j.optInt("g") == 1 ? "\u2B50 " : "") + hostOf(u) + shortPath(u)
                            + (j.optString("l").isEmpty() ? "" : "  [" + j.optString("l") + "]"));
                }
            } catch (Exception ignored) {
            }
            for (Map.Entry<String, String> e : radar.entrySet()) {
                if (!urls.contains(e.getKey())) {
                    urls.add(0, e.getKey());
                    labels.add(0, "\uD83D\uDD17 " + hostOf(e.getKey()) + shortPath(e.getKey()) + "  [" + e.getValue() + "]");
                }
            }
            if (urls.isEmpty()) {
                showBar("Abhi koi link nahi mila. Thoda ruk kar dobara dekho", null, null);
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Link Radar")
                    .setItems(labels.toArray(new String[0]), (d, which) -> web.loadUrl(urls.get(which)))
                    .setNegativeButton("Copy all", (d, w) -> {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("links", android.text.TextUtils.join("\n", urls)));
                    })
                    .show();
        });
    }

    private static String shortPath(String url) {
        try {
            String p = Uri.parse(url).getPath();
            if (p == null || p.equals("/")) return "";
            return p.length() > 28 ? p.substring(0, 28) + "\u2026" : p;
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- downloads ----------

    private void showDownloadDialog() {
        final String url = videoUrl;
        if (url == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Download")
                .setItems(new String[]{"\uD83C\uDFAC Video", "\uD83C\uDFB5 Audio only"}, (d, which) -> {
                    if (which == 0) downloadVideo(url);
                    else downloadAudio(url);
                })
                .show();
    }

    private String fileNameFor(String url) {
        String name = URLUtil.guessFileName(url, null, null);
        if (name == null || !name.contains(".") || name.endsWith(".bin")) {
            name = "video_" + System.currentTimeMillis() + ".mp4";
        }
        return name;
    }

    private void downloadVideo(String url) {
        try {
            enqueue(url, fileNameFor(url), web.getSettings().getUserAgentString(),
                    CookieManager.getInstance().getCookie(url), web.getUrl());
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    private void enqueue(String url, String name, String ua, String cookie, String ref) {
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (ref != null) r.addRequestHeader("Referer", ref);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
            toast("Download shuru: " + name);
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    // Audio only: downloads the file, copies out its audio track (no re-encoding) and saves it to Downloads.
    private void downloadAudio(String url) {
        if (url.toLowerCase().matches(".*\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac)(\\?.*)?$")) {
            downloadVideo(url); // already an audio file
            return;
        }
        final String ua = web.getSettings().getUserAgentString();
        final String cookie = CookieManager.getInstance().getCookie(url);
        final String ref = web.getUrl();
        final String baseName = fileNameFor(url).replaceAll("\\.[^.]*$", "");
        toast("Audio ban raha hai, thoda wait karo...");

        new Thread(() -> {
            File tmp = null, out = null;
            try {
                long ts = System.currentTimeMillis();
                tmp = new File(getCacheDir(), "dl_" + ts + ".tmp");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                if (ua != null) c.setRequestProperty("User-Agent", ua);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                if (ref != null) c.setRequestProperty("Referer", ref);
                try (InputStream in = c.getInputStream(); OutputStream fo = new FileOutputStream(tmp)) {
                    copy(in, fo);
                }

                MediaExtractor ex = new MediaExtractor();
                ex.setDataSource(tmp.getAbsolutePath());
                int track = -1;
                MediaFormat fmt = null;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    MediaFormat f = ex.getTrackFormat(i);
                    String m = f.getString(MediaFormat.KEY_MIME);
                    if (m != null && m.startsWith("audio/")) {
                        track = i;
                        fmt = f;
                        break;
                    }
                }
                if (track < 0) throw new Exception("is video mein audio track nahi mila");

                String mime = fmt.getString(MediaFormat.KEY_MIME);
                int muxFmt;
                String ext, outMime;
                if ("audio/mp4a-latm".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4;
                    ext = "m4a";
                    outMime = "audio/mp4";
                } else if ("audio/opus".equals(mime) || "audio/vorbis".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM;
                    ext = "webm";
                    outMime = "audio/webm";
                } else {
                    throw new Exception("audio format (" + mime + ") support nahi hai");
                }

                out = new File(getCacheDir(), "out_" + ts + "." + ext);
                MediaMuxer mux = new MediaMuxer(out.getAbsolutePath(), muxFmt);
                ex.selectTrack(track);
                int outTrack = mux.addTrack(fmt);
                mux.start();
                ByteBuffer buf = ByteBuffer.allocate(1 << 20);
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                while (true) {
                    buf.clear();
                    int n = ex.readSampleData(buf, 0);
                    if (n < 0) break;
                    info.set(0, n, ex.getSampleTime(), ex.getSampleFlags());
                    mux.writeSampleData(outTrack, buf, info);
                    ex.advance();
                }
                mux.stop();
                mux.release();
                ex.release();

                String fileName = baseName + "." + ext;
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, outMime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new Exception("file save nahi ho paayi");
                try (OutputStream os = getContentResolver().openOutputStream(uri);
                     InputStream is = new FileInputStream(out)) {
                    copy(is, os);
                }
                toast("Audio Downloads mein save ho gaya: " + fileName);
            } catch (Exception e) {
                toast("Audio nahi ban paya: " + e.getMessage());
            } finally {
                if (tmp != null) tmp.delete();
                if (out != null) out.delete();
            }
        }).start();
    }

    private static void copy(InputStream in, OutputStream out) throws java.io.IOException {
        byte[] b = new byte[64 * 1024];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
    }

    // ---------- navigation ----------

    private void go(String input) {
        String s = input.trim();
        if (s.isEmpty()) return;
        String url;
        if (s.startsWith("http://") || s.startsWith("https://")) {
            url = s;
        } else if (s.contains(".") && !s.contains(" ")) {
            url = "https://" + s;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(s);
        }
        radar.clear();
        lastDecoded = null;
        web.loadUrl(url);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
