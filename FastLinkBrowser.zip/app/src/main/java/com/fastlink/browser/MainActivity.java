package com.fastlink.browser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.format.DateUtils;
import android.util.Base64;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {

    // speed modes: 0 = off, 1 = smart (speeds up only on pages that look like a link-shortener step), 2 = turbo (always)
    private static final int[] RATES = {1, 10, 25};
    private static final String[] MODE_NAMES = {"Speed OFF", "Smart speed", "Turbo (har page par)"};
    private static final String[] MODE_DONE = {
            "Speed band ho gayi \u2705",
            "Smart speed chalu ho gayi \u26A1",
            "Turbo chalu ho gaya \uD83D\uDE80"};
    // lines shown (in the black pill) after an automatic tap
    private static final String[] TAP_LINES = {
            "Step # complete \u2705",
            "Step # ho gaya, ye bhi ho gaya \u2728",
            "Step # done, aage badh rahe hain \uD83D\uDE80",
            "Step # complete, ek dum smooth \uD83D\uDE0E"};

    // Ad / popup network domains (sub-resources are answered with harmless stubs, main-frame jumps are blocked)
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "googletagservices.com", "2mdn.net",
            "adnxs.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "pubmatic.com", "rubiconproject.com", "openx.net", "amazon-adsystem.com",
            "adsafeprotected.com", "moatads.com", "advertising.com", "adform.net",
            "smartadserver.com", "casalemedia.com", "indexww.com", "teads.tv",
            "mgid.com", "revcontent.com", "adskeeper.com", "adsrvr.org",
            "serving-sys.com", "lijit.com", "sharethrough.com", "yieldmo.com",
            "media.net", "zedo.com", "adition.com",
            "popads.net", "popcash.net", "propellerads.com", "exoclick.com",
            "exosrv.com", "exdynsrv.com", "realsrv.com", "juicyads.com", "adsterra.com", "hilltopads.net",
            "clickadu.com", "adcash.com", "bidvertiser.com", "onclickads.net",
            "a-ads.com", "ad-maven.com", "admaven.com", "monetag.com",
            "profitablecpmrate.com", "effectivegatecpm.com", "highperformanceformat.com",
            "yllix.com", "trafficjunky.net", "tsyndicate.com", "adtng.com",
            "trafficstars.com", "galaksion.com", "richads.com", "bidgear.com",
            "onclickalgo.com", "onclckmn.com", "pushame.com", "pushsar.com",
            "mondiad.com", "adspyglass.com", "clickaine.com", "wpadmngr.com", "adsco.re",
            "kueezrtb.com", "bidswitch.net", "33across.com", "smaato.net"
    };

    // Hosts that are known link-shortener / gate sites (used only as a hint; page content is checked too)
    private static final String[] SHORT_HOSTS = {
            "ouo.io", "ouo.press", "shrinkme.io", "shrinkearn.com", "shrtfly.com", "exe.io", "exey.io",
            "fc.lc", "fcc.lc", "clk.sh", "gplinks.co", "gplinks.in", "droplink.co", "linkvertise.com",
            "link-to.net", "lootlabs.gg", "loot-link.com", "loot-links.com", "work.ink", "adfoc.us", "za.gl",
            "earnlink.io", "tnlink.in", "tnshort.net", "shortingly.in", "arolinks.com", "ez4short.com",
            "earn4link.in", "adrinolinks.in", "cuty.io", "shorte.st", "sh.st", "bc.vc", "adf.ly",
            "boost.ink", "rekonise.com", "shareus.io", "gyanilinks.com", "indiurl.in", "kpslink.in",
            "linkpays.in", "rocklinks.net", "urlpay.in", "inshorturl.com", "dalink.in", "vplink.in",
            "safelinku.com", "linkshrink.net", "adshrink.it", "short2url.in", "urlshortx.com"
    };

    // Final-destination hosts: a new tab to one of these is opened straight away
    private static final String[] FILE_HOSTS = {
            "drive.google.com", "docs.google.com", "mega.nz", "mediafire.com", "t.me", "telegram.me",
            "dropbox.com", "terabox.com", "1024terabox.com", "github.com", "play.google.com", "gofile.io", "pixeldrain.com",
            "workupload.com", "1fichier.com", "krakenfiles.com", "send.cm"
    };

    // Share / social endpoints that use ?u= or ?url= and must never be treated as redirects
    private static final String[] SOCIAL_HOSTS = {
            "facebook.com", "twitter.com", "x.com", "whatsapp.com", "wa.me", "linkedin.com", "pinterest.com",
            "reddit.com", "t.me", "telegram.me", "tumblr.com", "vk.com"
    };

    private static final String[] REDIR_PARAMS = {
            "r", "u", "url", "link", "go", "goto", "dest", "destination", "target", "to", "out",
            "redirect", "redirect_url", "redir", "next", "l", "d", "href", "q"
    };

    private static final String ADS_STUB =
            "(window.adsbygoogle=window.adsbygoogle||[]);window.adsbygoogle.loaded=true;window.adsbygoogle.push=function(){return 0};";

    private static final String GPT_STUB =
            "(function(){var w=window,g=w.googletag=w.googletag||{};var q=g.cmd||[];"
            + "var ch=new Proxy(function(){},{get:function(t,p){if(p==='then')return undefined;"
            + "if(p===Symbol.toPrimitive)return function(){return ''};return ch},apply:function(){return ch}});"
            + "g.apiReady=true;g.pubadsReady=true;"
            + "g.cmd={push:function(f){try{if(typeof f==='function')f.call(g)}catch(e){}return 1}};"
            + "['defineSlot','defineOutOfPageSlot','pubads','companionAds','content','sizeMapping','enableServices',"
            + "'display','destroySlots','setTargeting','addEventListener'].forEach(function(n){g[n]=function(){return ch}});"
            + "if(q.forEach)q.forEach(function(f){try{f.call(g)}catch(e){}})})();";

    // 1x1 transparent GIF
    private static final byte[] GIF = Base64.decode("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", Base64.DEFAULT);

    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private TextView speedBtn, autoBtn, adBtn, menuBtn, dlBtn;
    private LinearLayout barBox;
    private TextView barMsg, barAct;
    private Runnable hideBar;
    private TextView pill;
    private Runnable hidePill;
    private long lastTapMsgAt;
    private int msgIdx;
    private volatile boolean flowActive;
    private volatile int stepCount;
    private boolean copyFinal;
    private String stuckUrl;
    private int linkType;                       // 0 auto, 1 key, 2 file/apk (menu override)
    private volatile int flowKind;              // what the running flow is for: 0 unknown, 1 key, 2 file/apk
    private volatile int hops;
    private volatile String curPage, prevPage, flowOrigin;
    // flow recorder: last steps of the current link flow, copied from the menu
    private final java.util.ArrayDeque<String> flogBuf = new java.util.ArrayDeque<>();
    private long flogT0;
    private volatile long recUntil;
    private final Set<String> freshTried = new HashSet<>();
    private BroadcastReceiver dlReceiver;
    private final Set<Long> myDownloads = new HashSet<>();
    private SharedPreferences prefs;
    private volatile int speedMode;
    private volatile boolean autoOn, adOn;
    private boolean desktop, defaultWide, defaultOverview;
    private ScriptHandler scriptHandler;
    private boolean docStartSupported;
    private String videoUrl;
    private String bridgeName;
    private String mobileUa, desktopUa;
    private String coreJs = "", engineJs = "";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final Set<String> slowHosts = new HashSet<>();
    // per-site speed (learned after an "anomaly" or chosen by hand); 1x lives in slowHosts
    private final Map<String, Integer> hostRate = new HashMap<>();
    private static final int[] LADDER = {25, 10, 5, 3, 2, 1};
    private String chromeMajor = "124";
    private final LinkedHashMap<String, String> radar = new LinkedHashMap<>();
    private volatile long trustPopupUntil;
    private String allowOnceUrl, lastDecoded;
    private long lastAnomalyAt;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("fastlink", MODE_PRIVATE);
        speedMode = prefs.getInt("speedMode", 1);
        autoOn = prefs.getBoolean("auto", true);
        adOn = prefs.getBoolean("ads", true);
        copyFinal = prefs.getBoolean("copyFinal", true);
        linkType = prefs.getInt("linkType", 0);
        slowHosts.addAll(prefs.getStringSet("slow", Collections.<String>emptySet()));
        for (String e : prefs.getStringSet("hr", Collections.<String>emptySet())) {
            int i = e.lastIndexOf('|');
            if (i > 0) {
                try {
                    hostRate.put(e.substring(0, i), Integer.parseInt(e.substring(i + 1)));
                } catch (Exception ignored) {
                }
            }
        }
        bridgeName = "_f" + Long.toString(Math.abs(rnd.nextLong()), 36);
        coreJs = asset("flb_core.js");
        engineJs = asset("flb_engine.js");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(4), dp(4), dp(4));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setHint("Search or enter URL");
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                return true;
            }
            return false;
        });
        bar.addView(urlBar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        speedBtn = toggle("\u26A1", v -> {
            speedMode = (speedMode + 1) % 3;
            prefs.edit().putInt("speedMode", speedMode).apply();
            changed(MODE_DONE[speedMode]);
        });
        autoBtn = toggle("\uD83E\uDD16", v -> {
            autoOn = !autoOn;
            prefs.edit().putBoolean("auto", autoOn).apply();
            changed(autoOn ? "Auto-click chalu ho gaya \uD83E\uDD16" : "Auto-click band ho gaya \u2705");
        });
        adBtn = toggle("\uD83D\uDEE1", v -> {
            adOn = !adOn;
            prefs.edit().putBoolean("ads", adOn).apply();
            changed(adOn ? "Ad block chalu ho gaya \uD83D\uDEE1" : "Ad block band ho gaya \u2705");
        });
        menuBtn = toggle("\u22EE", v -> showMenu());
        bar.addView(speedBtn);
        bar.addView(autoBtn);
        bar.addView(adBtn);
        bar.addView(menuBtn);
        root.addView(bar);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        FrameLayout content = new FrameLayout(this);
        web = new WebView(this);
        content.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        dlBtn = new TextView(this);
        dlBtn.setText("\u2B07");
        dlBtn.setTextSize(22);
        dlBtn.setTextColor(Color.WHITE);
        dlBtn.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(0, 150, 60));
        dlBtn.setBackground(circle);
        dlBtn.setElevation(dp(6));
        dlBtn.setVisibility(View.GONE);
        dlBtn.setOnClickListener(v -> showDownloadDialog());
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(dp(54), dp(54),
                Gravity.BOTTOM | Gravity.END);
        dlp.setMargins(0, 0, dp(16), dp(72));
        content.addView(dlBtn, dlp);

        // bottom info bar (blocked redirect, hints, "Allow"/"Open" actions)
        barBox = new LinearLayout(this);
        barBox.setOrientation(LinearLayout.HORIZONTAL);
        barBox.setGravity(Gravity.CENTER_VERTICAL);
        barBox.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(235, 30, 30, 34));
        bg.setCornerRadius(dp(12));
        barBox.setBackground(bg);
        barBox.setElevation(dp(8));
        barMsg = new TextView(this);
        barMsg.setTextColor(Color.WHITE);
        barMsg.setTextSize(13);
        barBox.addView(barMsg, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        barAct = new TextView(this);
        barAct.setTextColor(Color.rgb(120, 190, 255));
        barAct.setTextSize(14);
        barAct.setPadding(dp(14), dp(4), dp(4), dp(4));
        barBox.addView(barAct);
        barBox.setVisibility(View.GONE);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        blp.setMargins(dp(10), 0, dp(10), dp(10));
        content.addView(barBox, blp);
        hideBar = () -> barBox.setVisibility(View.GONE);

        // toast-style pill: dark rounded bubble, bottom centre, fades in and out
        pill = new TextView(this);
        pill.setTextColor(Color.WHITE);
        pill.setTextSize(15);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxWidth(getResources().getDisplayMetrics().widthPixels - dp(40));
        pill.setPadding(dp(20), dp(12), dp(20), dp(12));
        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(Color.argb(240, 28, 30, 36));
        pbg.setCornerRadius(dp(24));
        pill.setBackground(pbg);
        pill.setElevation(dp(12));
        pill.setVisibility(View.GONE);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        plp.setMargins(dp(20), 0, dp(20), dp(86));
        content.addView(pill, plp);
        hidePill = () -> pill.animate().alpha(0f).setDuration(220)
                .withEndAction(() -> pill.setVisibility(View.GONE)).start();

        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        // true on purpose: every window.open is caught in onCreateWindow and filtered there,
        // so the real "get link" popup is no longer silently dropped.
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        defaultWide = s.getUseWideViewPort();
        defaultOverview = s.getLoadWithOverviewMode();
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        // look like normal Chrome: no "wv" marker, no X-Requested-With header
        String ua = s.getUserAgentString();
        mobileUa = ua.replace("; wv)", ")").replace(" Version/4.0", "");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("Chrome/(\\d+)").matcher(mobileUa);
        String major = m.find() ? m.group(1) : "124";
        chromeMajor = major;
        desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + major + ".0.0.0 Safari/537.36";
        applyUa();
        try {
            // reflection on purpose: if this androidx.webkit version lacks the API, the build still works
            if (WebViewFeature.isFeatureSupported("REQUESTED_WITH_HEADER_ALLOW_LIST")) {
                WebSettingsCompat.class.getMethod("setRequestedWithHeaderOriginAllowList",
                        WebSettings.class, Set.class).invoke(null, s, Collections.<String>emptySet());
            }
        } catch (Throwable ignored) {
        }

        web.addJavascriptInterface(new Bridge(), bridgeName);
        docStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                // only http/https; blocks intent:// and app-open redirects
                if (!("http".equals(sc) || "https".equals(sc))) return true;
                if (!r.isForMainFrame()) return false;
                final String s = u.toString();
                if (s.equals(allowOnceUrl)) {
                    allowOnceUrl = null;
                    return false;
                }
                if (adOn) {
                    if (isAdUrl(u)) {
                        blockedJump(u);
                        return true;
                    }
                    if (isSearchPage(u) && !isSearchHost(hostOf(v.getUrl()))) {
                        blockedJump(u); // fake "continue" that throws you to a Google search
                        return true;
                    }
                }
                if (autoOn) {
                    final String d = decodeRedirect(u);
                    if (d != null && !d.equals(lastDecoded)) {
                        lastDecoded = d;
                        ui.post(() -> web.loadUrl(d));
                        return true;
                    }
                }
                return false;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (adOn && !r.isForMainFrame() && isAdUrl(r.getUrl())) {
                    return stub(r);
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                urlBar.setText(url);
                if (url != null && !url.equals(curPage)) {
                    prevPage = curPage;
                    curPage = url;
                }
                flog("NAV " + url);
                if (flowActive && hostIs(hostOf(url), FILE_HOSTS)) {
                    flog("FINAL file host reached");
                    flowEnded();
                    int n = prefs.getInt("flows", 0) + 1;
                    prefs.edit().putInt("flows", n).apply();
                    boolean copied = false;
                    if (copyFinal) {
                        try {
                            ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            if (cmb != null) {
                                cmb.setPrimaryClip(ClipData.newPlainText("link", url));
                                copied = true;
                            }
                        } catch (Exception ignored) {
                        }
                    }
                    say("Link mil gaya, ye complete ho gaya \uD83C\uDF89 (#" + n + (copied ? ", copy ho gaya" : "") + ")");
                }
                videoUrl = null;
                dlBtn.setVisibility(View.GONE);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (!docStartSupported) {
                    v.evaluateJavascript(script(), null);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message m) {
                return capturePopup(m);
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                result.confirm();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String message, JsResult result) {
                result.confirm();
                return true;
            }

            @Override
            public boolean onJsBeforeUnload(WebView v, String url, String message, JsResult result) {
                result.confirm(); // "Leave site?" prompts must never stop an automatic redirect
                return true;
            }
        });

        web.setDownloadListener((url, ua2, cd, mime, len) -> {
            if (flowActive) {
                flowEnded();
                prefs.edit().putInt("flows", prefs.getInt("flows", 0) + 1).apply();
            }
            if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                enqueue(url, URLUtil.guessFileName(url, cd, mime), ua2,
                        CookieManager.getInstance().getCookie(url), web.getUrl());
            }
        });

        applyMode();

        // tell the user when a download really finished (or failed)
        dlReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                long id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
                if (id < 0 || !myDownloads.remove(id)) return;
                boolean ok = false;
                String name = "";
                long size = 0;
                DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                try {
                    android.database.Cursor cu = dm.query(new DownloadManager.Query().setFilterById(id));
                    if (cu != null) {
                        try {
                            if (cu.moveToFirst()) {
                                ok = cu.getInt(cu.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                                        == DownloadManager.STATUS_SUCCESSFUL;
                                String t = cu.getString(cu.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                                if (t != null) name = t;
                                size = cu.getLong(cu.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                            }
                        } finally {
                            cu.close();
                        }
                    }
                } catch (Exception ignored) {
                }
                if (!ok) {
                    say("Download fail ho gaya, dobara try karo");
                    return;
                }
                final Uri du = dm.getUriForDownloadedFile(id);
                String mt = dm.getMimeTypeForDownloadedFile(id);
                final boolean isApk = name.toLowerCase().endsWith(".apk")
                        || "application/vnd.android.package-archive".equals(mt);
                final String openMime = isApk ? "application/vnd.android.package-archive" : (mt == null ? "*/*" : mt);
                String sz = size > 0 ? " (" + fmtSize(size) + ")" : "";
                if (isApk && size > 0 && size < 200 * 1024) {
                    say("\u26A0 Ye APK bohot chhoti hai" + sz + ", shayad asli file nahi (ad page ho sakta hai)");
                    return;
                }
                if (du == null) {
                    say("Download complete ho gaya \uD83C\uDF89 Downloads mein dekho" + sz);
                    return;
                }
                showBar((isApk ? "APK" : "File") + " download complete ho gaya \uD83C\uDF89" + sz,
                        isApk ? "Install" : "Open", () -> openDownloaded(du, openMime));
            }
        };
        IntentFilter dlf = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlReceiver, dlf, Context.RECEIVER_EXPORTED);
        else registerReceiver(dlReceiver, dlf);

        Uri data = getIntent() != null ? getIntent().getData() : null;
        startRecording();
        flog("START " + (data != null ? data.toString() : "home"));
        if (data != null) {
            web.loadUrl(data.toString());
        } else {
            web.loadUrl("https://www.google.com");
        }
        say("Nixu Browse ready hai \uD83D\uDE80");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getData() != null) {
            startRecording();
            flog("START " + intent.getData());
            web.loadUrl(intent.getData().toString());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (dlReceiver != null) unregisterReceiver(dlReceiver);
        } catch (Exception ignored) {
        }
        try {
            web.destroy();
        } catch (Exception ignored) {
        }
    }

    // ---------- JS bridge ----------

    private class Bridge {
        @JavascriptInterface
        public void videoFound(String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(() -> {
                videoUrl = url;
                dlBtn.setVisibility(View.VISIBLE);
            });
        }

        @JavascriptInterface
        public void noVideo() {
            runOnUiThread(() -> {
                videoUrl = null;
                dlBtn.setVisibility(View.GONE);
            });
        }

        // a real touch (isTrusted = true) at page coordinates already converted to view pixels
        @JavascriptInterface
        public void tap(final float x, final float y, final int tier) {
            ui.post(() -> {
                if (x < 0 || y < 0 || x > web.getWidth() || y > web.getHeight()) return;
                if (tier >= 2) trustPopupUntil = SystemClock.uptimeMillis() + 5000;
                final long t = SystemClock.uptimeMillis();
                final float jx = x + (rnd.nextFloat() - 0.5f) * 2f;
                final float jy = y + (rnd.nextFloat() - 0.5f) * 2f;
                final int dur = 70 + rnd.nextInt(90);
                sendTouch(MotionEvent.ACTION_DOWN, t, t, jx, jy);
                ui.postDelayed(() -> sendTouch(MotionEvent.ACTION_MOVE, t, SystemClock.uptimeMillis(),
                        jx + (rnd.nextFloat() - 0.5f) * 3f, jy + (rnd.nextFloat() - 0.5f) * 3f), dur / 2);
                ui.postDelayed(() -> {
                    sendTouch(MotionEvent.ACTION_UP, t, SystemClock.uptimeMillis(), jx, jy);
                    tapDone();
                }, dur);
            });
        }

        // the engine recognised a link-shortener page and started working on it (kind: 0 unknown, 1 key, 2 file/apk)
        @JavascriptInterface
        public void started(final int rate, final int kind) {
            if (!flowActive) {
                stepCount = 0;
                hops = 0;
                flowOrigin = prevPage;
            }
            flowActive = true;
            flowKind = kind;
            hops++;
            recUntil = SystemClock.elapsedRealtime() + 180000L;
            flog("ENGINE started kind=" + kind + " rate=" + rate + " hop=" + hops);
            ui.post(() -> {
                applyMode();
                String sp = rate > 1 ? ", " + rate + "x speed" : "";
                if (kind == 1) say("Key wala link pakda \uD83D\uDD11 checkpoint " + hops + sp);
                else if (kind == 2) say("File/APK wala link pakda \uD83D\uDCE6 step " + hops + sp);
                else say(rate > 1
                        ? "Link page pakad liya, " + rate + "x speed chalu ho gayi \u26A1"
                        : "Link page pakad liya, ye chalu ho gaya \u26A1");
            });
        }

        // the engine changed its mind about what this flow is for
        @JavascriptInterface
        public void kind(final int k) {
            if (!flowActive || k == flowKind) return;
            flowKind = k;
            flog("KIND changed to " + k);
            ui.post(() -> {
                applyMode();
                if (k == 1) say("Ye key wala link lag raha hai \uD83D\uDD11 key mode chalu");
                else if (k == 2) say("Ye file/APK wala link lag raha hai \uD83D\uDCE6 file mode chalu");
            });
        }

        @JavascriptInterface
        public void cp(final int n, final int of) {
            if (!flowActive) return;
            flog("CHECKPOINT " + n + "/" + of);
            ui.post(() -> say(flowKind == 1 ? "Checkpoint " + n + "/" + of + " \uD83D\uDD11" : "Step " + n + "/" + of));
        }

        // a key was found on the page: save it, copy it, stop the auto-clicking
        @JavascriptInterface
        public void key(final String key, final String host, final String info) {
            if (key == null || key.isEmpty()) return;
            flog("KEY found len=" + key.length() + " host=" + host);
            ui.post(() -> {
                saveKey(key, host);
                boolean copied = false;
                try {
                    ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cmb != null) {
                        cmb.setPrimaryClip(ClipData.newPlainText("key", key));
                        copied = true;
                    }
                } catch (Exception ignored) {
                }
                prefs.edit().putInt("keysDone", prefs.getInt("keysDone", 0) + 1).apply();
                flowEnded();
                String pv = key.length() > 24 ? key.substring(0, 24) + "\u2026" : key;
                say("Key mil gayi \uD83D\uDD11 " + (copied ? "copy ho gayi" : "") + "\n" + pv
                        + (info == null || info.isEmpty() ? "" : "\n(valid: " + info + ")"));
            });
        }

        // page the user came from before this flow started (full URL, the browser Referer is often cut to the origin)
        @JavascriptInterface
        public String origin() {
            String o = flowActive && flowOrigin != null ? flowOrigin : prevPage;
            return o == null ? "" : o;
        }

        @JavascriptInterface
        public void log(final String line) {
            if (line == null) return;
            flog(line.length() > 700 ? line.substring(0, 700) : line);
        }

        @JavascriptInterface
        public boolean recOn() {
            return flowActive || SystemClock.elapsedRealtime() < recUntil;
        }

        // real (trusted) finger drag, eased like a human swipe
        @JavascriptInterface
        public void swipe(final float x, final float y0, final float y1, final int ms) {
            ui.post(() -> {
                if (x < 0 || y0 < 0 || y1 < 0 || x > web.getWidth() || y0 > web.getHeight() || y1 > web.getHeight()) return;
                final long t = SystemClock.uptimeMillis();
                final int steps = Math.max(6, Math.min(30, ms / 16));
                sendTouch(MotionEvent.ACTION_DOWN, t, t, x, y0);
                for (int k = 1; k <= steps; k++) {
                    final float f = k / (float) steps;
                    final float e = f * f * (3f - 2f * f);
                    final boolean last = k == steps;
                    final float yy = y0 + (y1 - y0) * e;
                    final float xx = x + (rnd.nextFloat() - 0.5f) * 3f;
                    ui.postDelayed(() -> sendTouch(last ? MotionEvent.ACTION_UP : MotionEvent.ACTION_MOVE,
                            t, SystemClock.uptimeMillis(), xx, yy), (long) (ms * f));
                }
            });
        }

        // the engine has been idle for a long time: reload once per page, then fall back to a hint
        @JavascriptInterface
        public void stuck() {
            ui.post(() -> {
                String u = web.getUrl();
                if (u == null) return;
                flog("STUCK (30s without progress) url=" + u);
                if (flowKind == 1 || u.equals(stuckUrl)) {
                    say("Auto ruk gaya. \u22EE menu \u2192 Link Radar dekho");
                    return;
                }
                stuckUrl = u;
                say("Atak gaya tha, dobara try kar raha hoon \uD83D\uDD01");
                web.reload();
            });
        }

        @JavascriptInterface
        public void hint(final String msg) {
            if (msg == null) return;
            flog("HINT " + msg);
            ui.post(() -> showBar(msg, null, null));
        }

        @JavascriptInterface
        public void busy(final boolean on) {
            ui.post(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        // the site complained about our speed -> step that site one level slower (25 -> 10 -> 5 -> 3 -> 2 -> real-time) and retry
        @JavascriptInterface
        public void anomaly(final String host) {
            ui.post(() -> {
                if (host == null || host.isEmpty()) return;
                long now = SystemClock.uptimeMillis();
                if (now - lastAnomalyAt < 8000) return;
                lastAnomalyAt = now;
                int cur = effectiveRate(host);
                flog("ANOMALY host=" + host + " rate=" + cur);
                if (cur <= 1) {
                    if (flowKind != 1 && freshTried.add(host)) {
                        freshSession(web.getUrl());
                        say("Real-time par bhi anomaly, fresh session ke saath dobara try \uD83D\uDD01");
                        web.reload();
                    } else {
                        showBar(flowKind == 1
                                ? host + ": real-time par bhi anomaly. Key flow hai, isliye session saaf nahi kiya (checkpoints reset ho jaate)"
                                : host + ": real-time + fresh session par bhi anomaly. Ye server-side check hai", null, null);
                    }
                    return;
                }
                int next = nextLower(cur);
                setHostRate(host, next);
                applyMode();
                showBar("Anomaly: " + host + " " + cur + "x \u2192 " + (next <= 1 ? "real-time" : next + "x") + ", dobara try", null, null);
                web.reload();
            });
        }
    }

    private void sendTouch(int action, long down, long now, float x, float y) {
        MotionEvent.PointerProperties pp = new MotionEvent.PointerProperties();
        pp.id = 0;
        pp.toolType = MotionEvent.TOOL_TYPE_FINGER;
        MotionEvent.PointerCoords pc = new MotionEvent.PointerCoords();
        pc.x = x;
        pc.y = y;
        pc.pressure = action == MotionEvent.ACTION_UP ? 0f : 0.55f + rnd.nextFloat() * 0.3f;
        pc.size = 0.4f + rnd.nextFloat() * 0.3f;
        MotionEvent e = MotionEvent.obtain(down, now, action, 1,
                new MotionEvent.PointerProperties[]{pp}, new MotionEvent.PointerCoords[]{pc},
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
        web.dispatchTouchEvent(e);
        e.recycle();
    }

    // ---------- toggles / scripts ----------

    private TextView toggle(String label, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(20);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        t.setOnClickListener(l);
        return t;
    }

    private void changed(String msg) {
        applyMode();
        say(msg);
        web.reload();
    }

    private void applyMode() {
        speedBtn.setAlpha(speedMode > 0 ? 1f : 0.3f);
        speedBtn.setText(speedMode == 2 ? "\uD83D\uDE80" : "\u26A1");
        autoBtn.setAlpha(autoOn ? 1f : 0.3f);
        adBtn.setAlpha(adOn ? 1f : 0.3f);
        if (docStartSupported) {
            if (scriptHandler != null) {
                scriptHandler.remove();
                scriptHandler = null;
            }
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(
                    web, script(), Collections.singleton("*"));
        }
    }

    private void applyUa() {
        WebSettings s = web.getSettings();
        s.setUserAgentString(desktop ? desktopUa : mobileUa);
        s.setUseWideViewPort(desktop || defaultWide);
        s.setLoadWithOverviewMode(desktop || defaultOverview);
        applyUaMetadata();
    }

    // Sec-CH-UA headers + navigator.userAgentData say "Google Chrome" instead of "Android WebView".
    // Done by reflection so the build still works if this androidx.webkit lacks the API.
    private void applyUaMetadata() {
        try {
            if (!WebViewFeature.isFeatureSupported("USER_AGENT_METADATA")) return;
            Class<?> bvB = Class.forName("androidx.webkit.UserAgentMetadata$BrandVersion$Builder");
            Class<?> umB = Class.forName("androidx.webkit.UserAgentMetadata$Builder");
            Class<?> umC = Class.forName("androidx.webkit.UserAgentMetadata");
            String full = chromeMajor + ".0.0.0";
            String[][] brands = {{"Chromium", chromeMajor, full}, {"Google Chrome", chromeMajor, full},
                    {"Not-A.Brand", "99", "99.0.0.0"}};
            ArrayList<Object> list = new ArrayList<>();
            for (String[] b : brands) {
                Object bb = bvB.getConstructor().newInstance();
                bvB.getMethod("setBrand", String.class).invoke(bb, b[0]);
                bvB.getMethod("setMajorVersion", String.class).invoke(bb, b[1]);
                bvB.getMethod("setFullVersion", String.class).invoke(bb, b[2]);
                list.add(bvB.getMethod("build").invoke(bb));
            }
            Object mb = umB.getConstructor().newInstance();
            umB.getMethod("setBrandVersionList", List.class).invoke(mb, list);
            trySet(mb, "setFullVersion", String.class, full);
            trySet(mb, "setPlatform", String.class, desktop ? "Linux" : "Android");
            trySet(mb, "setMobile", boolean.class, !desktop);
            trySet(mb, "setModel", String.class, desktop ? "" : android.os.Build.MODEL);
            if (!desktop) trySet(mb, "setPlatformVersion", String.class, android.os.Build.VERSION.RELEASE + ".0.0");
            Object md = umB.getMethod("build").invoke(mb);
            WebSettingsCompat.class.getMethod("setUserAgentMetadata", WebSettings.class, umC)
                    .invoke(null, web.getSettings(), md);
        } catch (Throwable ignored) {
        }
    }

    private static void trySet(Object b, String method, Class<?> type, Object value) {
        try {
            b.getClass().getMethod(method, type).invoke(b, value);
        } catch (Throwable ignored) {
        }
    }

    // ---------- per-site speed ----------

    private int effectiveRate(String root) {
        if (speedMode == 0) return 1;
        if (slowHosts.contains(root)) return 1;
        Integer r = hostRate.get(root);
        return r != null ? r : RATES[speedMode];
    }

    private static int nextLower(int r) {
        for (int x : LADDER) {
            if (x < r) return x;
        }
        return 1;
    }

    private void setHostRate(String host, int r) {
        if (r <= 1) {
            hostRate.remove(host);
            slowHosts.add(host);
        } else {
            slowHosts.remove(host);
            hostRate.put(host, r);
        }
        saveSlow();
        saveRates();
    }

    private void saveRates() {
        Set<String> out = new HashSet<>();
        for (Map.Entry<String, Integer> e : hostRate.entrySet()) out.add(e.getKey() + "|" + e.getValue());
        prefs.edit().putStringSet("hr", out).apply();
    }

    private void showSiteSpeed(final String root) {
        if (root.isEmpty()) return;
        final int[] opts = {0, 1, 2, 3, 5, 10, 25};
        String[] names = new String[opts.length];
        for (int i = 0; i < opts.length; i++) {
            names[i] = opts[i] == 0 ? "Auto (app khud seekhegi)" : opts[i] == 1 ? "1x (real-time)" : opts[i] + "x";
        }
        new AlertDialog.Builder(this)
                .setTitle(root + " \u2014 abhi: " + effectiveRate(root) + "x")
                .setItems(names, (d, which) -> {
                    int r = opts[which];
                    slowHosts.remove(root);
                    hostRate.remove(root);
                    if (r == 1) slowHosts.add(root);
                    else if (r > 1) hostRate.put(root, r);
                    saveSlow();
                    saveRates();
                    applyMode();
                    say(r == 0 ? "Auto speed set ho gayi \u2705" : "Is site par " + r + "x set ho gaya \u2705");
                    web.reload();
                })
                .show();
    }

    private String script() {
        JSONObject c = new JSONObject();
        try {
            c.put("n", bridgeName);
            c.put("mode", speedMode);
            c.put("rate", RATES[speedMode]);
            c.put("auto", autoOn);
            c.put("ads", adOn);
            c.put("lt", linkType);
            c.put("fk", flowActive ? flowKind : 0);
            c.put("slow", new JSONArray(new ArrayList<>(slowHosts)));
            JSONObject hr = new JSONObject();
            for (Map.Entry<String, Integer> e : hostRate.entrySet()) hr.put(e.getKey(), e.getValue());
            c.put("hr", hr);
            c.put("adh", new JSONArray(Arrays.asList(AD_HOSTS)));
            c.put("sh", new JSONArray(Arrays.asList(SHORT_HOSTS)));
        } catch (Exception ignored) {
        }
        return "(function(){var K='" + bridgeName + "x';if(window[K])return;"
                + "Object.defineProperty(window,K,{value:1});\nvar C=" + c + ";\n"
                + coreJs + "\n" + engineJs + "\n})();";
    }

    private String asset(String name) {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            copy(in, bo);
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void saveSlow() {
        prefs.edit().putStringSet("slow", new HashSet<>(slowHosts)).apply();
    }

    // ---------- host helpers ----------

    private static String hostOf(String url) {
        if (url == null) return "";
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? "" : h.toLowerCase();
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean hostIs(String h, String... list) {
        if (h == null) return false;
        for (String d : list) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    private static String rootHost(String h) {
        if (h == null) return "";
        String[] p = h.toLowerCase().split("\\.");
        if (p.length <= 2) return h.toLowerCase();
        String l = p[p.length - 1], s = p[p.length - 2];
        if (l.length() == 2 && s.matches("co|com|org|net|gov|ac|edu|nic")) {
            return p[p.length - 3] + "." + s + "." + l;
        }
        return s + "." + l;
    }

    private boolean isAdUrl(Uri u) {
        String h = u.getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        if (hostIs(h, AD_HOSTS)) return true;
        if (h.equals("youtube.com") || h.endsWith(".youtube.com")) {
            String p = u.getPath();
            if (p != null && (p.startsWith("/pagead/") || p.startsWith("/api/stats/ads")
                    || p.startsWith("/get_midroll_") || p.contains("/ptracking"))) {
                return true;
            }
        }
        return false;
    }

    private static boolean isSearchHost(String h) {
        return h.matches("(.*\\.)?google\\.[a-z.]+") || hostIs(h, "bing.com", "duckduckgo.com", "search.yahoo.com");
    }

    private static boolean isSearchPage(Uri u) {
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        String p = u.getPath() == null ? "" : u.getPath();
        if (h.matches("(.*\\.)?google\\.[a-z.]+") && p.startsWith("/search")) return true;
        if (hostIs(h, "bing.com") && p.startsWith("/search")) return true;
        if (hostIs(h, "duckduckgo.com") && u.getQueryParameter("q") != null) return true;
        return hostIs(h, "search.yahoo.com");
    }

    private void blockedJump(final Uri u) {
        final String s = u.toString();
        ui.post(() -> showBar("Fake redirect roka: " + hostOf(s), "Allow", () -> {
            allowOnceUrl = s;
            web.loadUrl(s);
        }));
    }

    // Reads the real target out of ?r=<base64>, ?url=<encoded url> and similar redirect parameters
    private String decodeRedirect(Uri u) {
        try {
            String host = u.getHost();
            if (host == null) return null;
            host = host.toLowerCase();
            if (hostIs(host, SOCIAL_HOSTS)) return null;
            String path = u.getPath() == null ? "" : u.getPath().toLowerCase();
            boolean googleUrl = host.matches("(.*\\.)?google\\.[a-z.]+") && path.equals("/url");
            boolean ytRedirect = hostIs(host, "youtube.com") && path.equals("/redirect");
            boolean pathHint = path.matches(".*/(go|out|redirect|redir|away|link|l|r|click|safe|skip|exit|jump|bridge|visit)(/.*)?");
            boolean shortHost = hostIs(host, SHORT_HOSTS);
            for (String name : u.getQueryParameterNames()) {
                boolean listed = false;
                for (String p : REDIR_PARAMS) {
                    if (p.equalsIgnoreCase(name)) {
                        listed = true;
                        break;
                    }
                }
                if (!listed) continue;
                String v = u.getQueryParameter(name);
                if (v == null || v.length() < 12) continue;
                String dec = null;
                if (v.startsWith("aHR0")) {
                    dec = b64(v);
                } else if ((v.startsWith("http://") || v.startsWith("https://"))
                        && (pathHint || googleUrl || ytRedirect || shortHost)) {
                    dec = v;
                }
                if (dec == null) continue;
                Uri d = Uri.parse(dec);
                String dh = d.getHost();
                if (dh == null || !dh.contains(".") || dh.equalsIgnoreCase(host)) continue;
                if (isAdUrl(d) || isSearchPage(d)) continue;
                return dec;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String b64(String v) {
        try {
            String s = v.replace('-', '+').replace('_', '/');
            while (s.length() % 4 != 0) s += "=";
            String r = new String(Base64.decode(s, Base64.DEFAULT), "UTF-8").trim();
            return r.startsWith("http://") || r.startsWith("https://") ? r : null;
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- harmless answers for blocked ad requests (so anti-adblock checks pass) ----------

    private WebResourceResponse stub(WebResourceRequest r) {
        Uri u = r.getUrl();
        String p = u.getPath() == null ? "" : u.getPath().toLowerCase();
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        Map<String, String> req = r.getRequestHeaders();
        String accept = req == null ? null : req.get("Accept");
        byte[] body;
        String mime;
        if (p.endsWith("adsbygoogle.js") || p.contains("/show_ads")) {
            body = ADS_STUB.getBytes();
            mime = "application/javascript";
        } else if (p.endsWith("/gpt.js") || p.contains("pubads_impl") || h.contains("googletagservices")) {
            body = GPT_STUB.getBytes();
            mime = "application/javascript";
        } else if (p.matches(".*\\.(gif|png|jpe?g|webp|svg)$") || (accept != null && accept.startsWith("image/"))) {
            body = GIF;
            mime = "image/gif";
        } else if (accept != null && accept.contains("text/html")) {
            body = "<!doctype html><html><body></body></html>".getBytes();
            mime = "text/html";
        } else if (p.endsWith(".css")) {
            body = "/* */".getBytes();
            mime = "text/css";
        } else if (accept != null && accept.contains("application/json")) {
            body = "{}".getBytes();
            mime = "application/json";
        } else {
            body = "/* */".getBytes();
            mime = "application/javascript";
        }
        Map<String, String> hd = new HashMap<>();
        hd.put("Access-Control-Allow-Origin", "*");
        hd.put("Cache-Control", "no-store");
        return new WebResourceResponse(mime, "utf-8", 200, "OK", hd, new ByteArrayInputStream(body));
    }

    // ---------- popups (window.open): ads dropped, the real "get link" popup kept ----------

    private boolean capturePopup(Message m) {
        if (m == null || !(m.obj instanceof WebView.WebViewTransport)) return false;
        final WebView tmp = new WebView(this);
        tmp.setWebViewClient(new WebViewClient() {
            private volatile boolean done;

            private void got(final String url) {
                if (done || url == null || url.startsWith("about:") || url.startsWith("blob:")
                        || url.startsWith("data:") || url.startsWith("javascript:")) return;
                done = true;
                ui.post(() -> {
                    handlePopup(url);
                    try {
                        tmp.stopLoading();
                        tmp.destroy();
                    } catch (Exception ignored) {
                    }
                });
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                got(r.getUrl().toString());
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                got(url);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (r.isForMainFrame()) got(r.getUrl().toString());
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        ui.postDelayed(() -> {
            try {
                tmp.destroy();
            } catch (Exception ignored) {
            }
        }, 12000);
        WebView.WebViewTransport tr = (WebView.WebViewTransport) m.obj;
        tr.setWebView(tmp);
        m.sendToTarget();
        return true;
    }

    private void handlePopup(final String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        flog("POPUP " + url);
        Uri u = Uri.parse(url);
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        if (h.isEmpty()) return;
        String curHost = hostOf(web.getUrl());
        if (adOn && (isAdUrl(u) || isSearchPage(u))) {
            showBar("Popup roka: " + h, "Open", () -> web.loadUrl(url));
            return;
        }
        boolean trusted = autoOn && SystemClock.uptimeMillis() < trustPopupUntil;
        boolean sameSite = rootHost(h).equals(rootHost(curHost));
        if (sameSite || trusted || hostIs(h, FILE_HOSTS) || hostIs(h, SHORT_HOSTS)) {
            web.loadUrl(url);
            return;
        }
        addRadar(url, "popup");
        showBar("Naya tab roka: " + h, "Open", () -> web.loadUrl(url));
    }

    private void addRadar(String url, String label) {
        radar.put(url, label);
        while (radar.size() > 30) {
            String first = radar.keySet().iterator().next();
            radar.remove(first);
        }
    }

    // ---------- bottom bar, menu, link radar ----------

    private void showBar(String msg, String action, final Runnable r) {
        if (action == null || r == null) {
            say(msg);
            return;
        }
        barMsg.setText(msg);
        barAct.setText(action);
        barAct.setVisibility(View.VISIBLE);
        barAct.setOnClickListener(v -> {
            barBox.setVisibility(View.GONE);
            r.run();
        });
        barBox.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideBar);
        ui.postDelayed(hideBar, 9000);
    }

    // toast-style message (dark rounded pill at the bottom); safe to call from any thread
    private void say(final String msg) {
        if (msg == null || msg.isEmpty()) return;
        runOnUiThread(() -> {
            pill.animate().cancel();
            ui.removeCallbacks(hidePill);
            pill.setText(msg);
            pill.setAlpha(0f);
            pill.setVisibility(View.VISIBLE);
            pill.animate().alpha(1f).setDuration(160).start();
            ui.postDelayed(hidePill, Math.min(6000, 2200 + 45L * msg.length()));
        });
    }

    // feedback after an automatic tap (not more than one line every 2.5 s)
    private void tapDone() {
        stepCount++;
        flog("TAP landed, step=" + stepCount);
        long now = SystemClock.uptimeMillis();
        if (now - lastTapMsgAt < 1800) return;
        lastTapMsgAt = now;
        say(TAP_LINES[(msgIdx++) % TAP_LINES.length].replace("#", String.valueOf(stepCount)));
    }

    private void flog(String line) {
        if (!flowActive && SystemClock.elapsedRealtime() > recUntil) return;
        synchronized (flogBuf) {
            long now = SystemClock.elapsedRealtime();
            if (flogBuf.isEmpty()) flogT0 = now;
            flogBuf.addLast(String.format(java.util.Locale.US, "[%5.1fs] ", (now - flogT0) / 1000.0) + line);
            while (flogBuf.size() > 300) flogBuf.removeFirst();
        }
    }

    private void startRecording() {
        synchronized (flogBuf) {
            flogBuf.clear();
        }
        recUntil = SystemClock.elapsedRealtime() + 180000L;
    }

    private int flogSize() {
        synchronized (flogBuf) {
            return flogBuf.size();
        }
    }

    private void copyFlowLog() {
        StringBuilder sb = new StringBuilder();
        String wv = "?";
        try {
            android.content.pm.PackageInfo pi = WebView.getCurrentWebViewPackage();
            if (pi != null) wv = pi.versionName;
        } catch (Throwable ignored) {
        }
        sb.append("NixuBrowse v4.2 | speedMode=").append(speedMode).append(" auto=").append(autoOn)
                .append(" ads=").append(adOn).append(" type=").append(linkType)
                .append(" | webview=").append(wv).append(" | android=").append(Build.VERSION.SDK_INT).append("\n");
        synchronized (flogBuf) {
            for (String l : flogBuf) sb.append(l).append("\n");
        }
        try {
            ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cmb != null) cmb.setPrimaryClip(ClipData.newPlainText("flowlog", sb.toString()));
            say("Flow log copy ho gaya \uD83D\uDCDD (" + flogSize() + " lines), ab chat mein paste karo");
        } catch (Exception e) {
            say("Log copy nahi ho paaya");
        }
    }

    private void flowEnded() {
        flowActive = false;
        flowKind = 0;
        hops = 0;
        flowOrigin = null;
        applyMode();
    }

    private void saveKey(String key, String host) {
        try {
            JSONArray old = new JSONArray(prefs.getString("keys", "[]"));
            JSONArray out = new JSONArray();
            JSONObject nj = new JSONObject();
            nj.put("k", key);
            nj.put("h", host == null ? "" : host);
            nj.put("t", System.currentTimeMillis());
            out.put(nj);
            for (int k = 0; k < old.length() && out.length() < 20; k++) {
                JSONObject o = old.getJSONObject(k);
                if (key.equals(o.optString("k"))) continue;
                out.put(o);
            }
            prefs.edit().putString("keys", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private int keyCount() {
        try {
            return new JSONArray(prefs.getString("keys", "[]")).length();
        } catch (Exception e) {
            return 0;
        }
    }

    private void showKeys() {
        final ArrayList<String> keys = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString("keys", "[]"));
            long now = System.currentTimeMillis();
            for (int k = 0; k < arr.length(); k++) {
                JSONObject o = arr.getJSONObject(k);
                keys.add(o.optString("k"));
                CharSequence ago = DateUtils.getRelativeTimeSpanString(o.optLong("t"), now, DateUtils.MINUTE_IN_MILLIS);
                labels.add(o.optString("h") + "  \u2022  " + ago + "\n" + o.optString("k"));
            }
        } catch (Exception ignored) {
        }
        if (keys.isEmpty()) {
            say("Abhi koi key save nahi hui \uD83D\uDD11");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Saved keys (tap = copy)")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("key", keys.get(which)));
                    say("Key copy ho gayi \u2705");
                })
                .setNegativeButton("Sab hatao", (d, w) -> {
                    prefs.edit().remove("keys").apply();
                    say("Saved keys saaf ho gayi \u2728");
                })
                .show();
    }

    private void openDownloaded(Uri uri, String mime) {
        try {
            Intent in = new Intent(Intent.ACTION_VIEW);
            in.setDataAndType(uri, mime);
            in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(in);
        } catch (Exception e) {
            say("Open nahi ho paaya, Downloads mein dekho");
        }
    }

    private static String fmtSize(long b) {
        if (b >= 1073741824L) return String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0);
        if (b >= 1048576L) return String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0);
        return (b / 1024L) + " KB";
    }

    private void freshSession(String url) {
        String host = hostOf(url);
        String root = rootHost(host);
        if (host.isEmpty()) return;
        try {
            CookieManager cm = CookieManager.getInstance();
            for (String u : new String[]{"https://" + host, "https://" + root, "https://www." + root}) {
                String ck = cm.getCookie(u);
                if (ck == null) continue;
                for (String part : ck.split(";")) {
                    String nm = part.trim();
                    int eq = nm.indexOf('=');
                    if (eq <= 0) continue;
                    nm = nm.substring(0, eq);
                    cm.setCookie(u, nm + "=; Max-Age=0; Path=/");
                    cm.setCookie(u, nm + "=; Max-Age=0; Path=/; Domain=" + root);
                    cm.setCookie(u, nm + "=; Max-Age=0; Path=/; Domain=." + root);
                }
            }
            cm.flush();
        } catch (Throwable ignored) {
        }
        try {
            WebStorage ws = WebStorage.getInstance();
            ws.deleteOrigin("https://" + host);
            ws.deleteOrigin("https://" + root);
            ws.deleteOrigin("https://www." + root);
        } catch (Throwable ignored) {
        }
        try {
            web.clearCache(true);
        } catch (Throwable ignored) {
        }
    }

    private void showMenu() {
        final String cur = web.getUrl();
        final String root = rootHost(hostOf(cur));
        final boolean slow = slowHosts.contains(root);
        String[] items = {
                "\uD83D\uDD17 Link Radar (mile hue links)",
                "\uD83E\uDDF9 Page unlock (overlay / adblock wall hatao)",
                slow ? "\u23F1 Real-time mode: ON (is site par)" : "\u23F1 Real-time mode: OFF (is site par)",
                desktop ? "\uD83D\uDDA5 Desktop site: ON" : "\uD83D\uDDA5 Desktop site: OFF",
                "\u267B Seekhi hui sites reset",
                "\uD83D\uDCCB URL copy",
                "\u26A1 Is site ki speed set karo (" + effectiveRate(root) + "x)",
                "\uD83E\uDDFD Fresh session (is site ke cookies + storage saaf)",
                copyFinal ? "\uD83D\uDCCB Final link auto-copy: ON" : "\uD83D\uDCCB Final link auto-copy: OFF",
                "\uD83D\uDCCA Links complete: " + prefs.getInt("flows", 0),
                "\uD83D\uDD11 Saved keys (" + keyCount() + ")",
                "\uD83C\uDFAF Link type: " + (linkType == 1 ? "Key" : linkType == 2 ? "File/APK" : "Auto"),
                "\uD83D\uDCDD Flow log copy (" + flogSize() + " lines)",
                "\uD83E\uDDF9 Flow log saaf karo"
        };
        new AlertDialog.Builder(this).setItems(items, (d, which) -> {
            switch (which) {
                case 0:
                    showRadar();
                    break;
                case 1:
                    web.evaluateJavascript("(function(){var f=window['" + bridgeName
                            + "u'];return f?f():-1})()", v -> showBar(
                            "0".equals(v) ? "Hatane layak overlay nahi mila" : "Overlay hat gaya, page unlock ho gaya \u2705", null, null));
                    break;
                case 2:
                    if (root.isEmpty()) break;
                    if (slow) slowHosts.remove(root);
                    else slowHosts.add(root);
                    saveSlow();
                    applyMode();
                    say(slow ? "Is site par speed wapas chalu ho gayi \u26A1" : "Is site par real-time chalu ho gaya \u23F1");
                    web.reload();
                    break;
                case 3:
                    desktop = !desktop;
                    applyUa();
                    say(desktop ? "Desktop site chalu ho gayi \uD83D\uDDA5" : "Mobile site wapas aa gayi \uD83D\uDCF1");
                    web.reload();
                    break;
                case 4:
                    slowHosts.clear();
                    hostRate.clear();
                    saveSlow();
                    saveRates();
                    applyMode();
                    say("Reset ho gaya, sab saaf \u2728");
                    break;
                case 5:
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null && cur != null) cm.setPrimaryClip(ClipData.newPlainText("url", cur));
                    say("URL copy ho gaya \u2705");
                    break;
                case 6:
                    showSiteSpeed(root);
                    break;
                case 7:
                    freshSession(cur);
                    say("Fresh session ho gayi, is site ke cookies saaf \u2728");
                    web.reload();
                    break;
                case 8:
                    copyFinal = !copyFinal;
                    prefs.edit().putBoolean("copyFinal", copyFinal).apply();
                    say(copyFinal ? "Final link auto-copy chalu ho gaya \u2705" : "Final link auto-copy band ho gaya \u2705");
                    break;
                case 9:
                    say("Ab tak " + prefs.getInt("flows", 0) + " links complete ho chuke \uD83C\uDF89");
                    break;
                case 10:
                    showKeys();
                    break;
                case 11:
                    linkType = (linkType + 1) % 3;
                    prefs.edit().putInt("linkType", linkType).apply();
                    applyMode();
                    say(linkType == 1 ? "Link type: Key \uD83D\uDD11 (key wale links ke hisaab se chalega)"
                            : linkType == 2 ? "Link type: File/APK \uD83D\uDCE6"
                            : "Link type: Auto, khud pehchanega \uD83C\uDFAF");
                    web.reload();
                    break;
                case 12:
                    copyFlowLog();
                    break;
                case 13:
                    startRecording();
                    say("Flow log saaf ho gaya \u2728 ab naya link kholo");
                    break;
                default:
                    break;
            }
        }).show();
    }

    private void showRadar() {
        web.evaluateJavascript("(function(){var f=window['" + bridgeName + "h'];return f?f():'[]'})()", value -> {
            final ArrayList<String> urls = new ArrayList<>();
            final ArrayList<String> labels = new ArrayList<>();
            try {
                Object o = new JSONTokener(value == null ? "\"[]\"" : value).nextValue();
                JSONArray arr = new JSONArray(o instanceof String ? (String) o : "[]");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject j = arr.getJSONObject(i);
                    String u = j.getString("u");
                    urls.add(u);
                    labels.add((j.optInt("g") == 1 ? "\u2B50 " : "") + hostOf(u) + shortPath(u)
                            + (j.optString("l").isEmpty() ? "" : "  [" + j.optString("l") + "]"));
                }
            } catch (Exception ignored) {
            }
            for (Map.Entry<String, String> e : radar.entrySet()) {
                if (!urls.contains(e.getKey())) {
                    urls.add(0, e.getKey());
                    labels.add(0, "\uD83D\uDD17 " + hostOf(e.getKey()) + shortPath(e.getKey()) + "  [" + e.getValue() + "]");
                }
            }
            if (urls.isEmpty()) {
                showBar("Abhi koi link nahi mila. Thoda ruk kar dobara dekho", null, null);
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Link Radar")
                    .setItems(labels.toArray(new String[0]), (d, which) -> web.loadUrl(urls.get(which)))
                    .setNegativeButton("Copy all", (d, w) -> {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("links", android.text.TextUtils.join("\n", urls)));
                    })
                    .show();
        });
    }

    private static String shortPath(String url) {
        try {
            String p = Uri.parse(url).getPath();
            if (p == null || p.equals("/")) return "";
            return p.length() > 28 ? p.substring(0, 28) + "\u2026" : p;
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- downloads ----------

    private void showDownloadDialog() {
        final String url = videoUrl;
        if (url == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Download")
                .setItems(new String[]{"\uD83C\uDFAC Video", "\uD83C\uDFB5 Audio only"}, (d, which) -> {
                    if (which == 0) downloadVideo(url);
                    else downloadAudio(url);
                })
                .show();
    }

    private String fileNameFor(String url) {
        String name = URLUtil.guessFileName(url, null, null);
        if (name == null || !name.contains(".") || name.endsWith(".bin")) {
            name = "video_" + System.currentTimeMillis() + ".mp4";
        }
        return name;
    }

    private void downloadVideo(String url) {
        try {
            enqueue(url, fileNameFor(url), web.getSettings().getUserAgentString(),
                    CookieManager.getInstance().getCookie(url), web.getUrl());
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    private void enqueue(String url, String name, String ua, String cookie, String ref) {
        flog("DOWNLOAD " + name + " <- " + url);
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (ref != null) r.addRequestHeader("Referer", ref);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            long id = ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
            myDownloads.add(id);
            toast("Download shuru ho gaya \u2B07 " + name);
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    // Audio only: downloads the file, copies out its audio track (no re-encoding) and saves it to Downloads.
    private void downloadAudio(String url) {
        if (url.toLowerCase().matches(".*\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac)(\\?.*)?$")) {
            downloadVideo(url); // already an audio file
            return;
        }
        final String ua = web.getSettings().getUserAgentString();
        final String cookie = CookieManager.getInstance().getCookie(url);
        final String ref = web.getUrl();
        final String baseName = fileNameFor(url).replaceAll("\\.[^.]*$", "");
        toast("Audio ban raha hai, thoda ruko \u23F3");

        new Thread(() -> {
            File tmp = null, out = null;
            try {
                long ts = System.currentTimeMillis();
                tmp = new File(getCacheDir(), "dl_" + ts + ".tmp");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                if (ua != null) c.setRequestProperty("User-Agent", ua);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                if (ref != null) c.setRequestProperty("Referer", ref);
                try (InputStream in = c.getInputStream(); OutputStream fo = new FileOutputStream(tmp)) {
                    copy(in, fo);
                }

                MediaExtractor ex = new MediaExtractor();
                ex.setDataSource(tmp.getAbsolutePath());
                int track = -1;
                MediaFormat fmt = null;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    MediaFormat f = ex.getTrackFormat(i);
                    String m = f.getString(MediaFormat.KEY_MIME);
                    if (m != null && m.startsWith("audio/")) {
                        track = i;
                        fmt = f;
                        break;
                    }
                }
                if (track < 0) throw new Exception("is video mein audio track nahi mila");

                String mime = fmt.getString(MediaFormat.KEY_MIME);
                int muxFmt;
                String ext, outMime;
                if ("audio/mp4a-latm".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4;
                    ext = "m4a";
                    outMime = "audio/mp4";
                } else if ("audio/opus".equals(mime) || "audio/vorbis".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM;
                    ext = "webm";
                    outMime = "audio/webm";
                } else {
                    throw new Exception("audio format (" + mime + ") support nahi hai");
                }

                out = new File(getCacheDir(), "out_" + ts + "." + ext);
                MediaMuxer mux = new MediaMuxer(out.getAbsolutePath(), muxFmt);
                ex.selectTrack(track);
                int outTrack = mux.addTrack(fmt);
                mux.start();
                ByteBuffer buf = ByteBuffer.allocate(1 << 20);
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                while (true) {
                    buf.clear();
                    int n = ex.readSampleData(buf, 0);
                    if (n < 0) break;
                    info.set(0, n, ex.getSampleTime(), ex.getSampleFlags());
                    mux.writeSampleData(outTrack, buf, info);
                    ex.advance();
                }
                mux.stop();
                mux.release();
                ex.release();

                String fileName = baseName + "." + ext;
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, outMime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new Exception("file save nahi ho paayi");
                try (OutputStream os = getContentResolver().openOutputStream(uri);
                     InputStream is = new FileInputStream(out)) {
                    copy(is, os);
                }
                toast("Audio complete ho gaya \uD83C\uDF89 Downloads mein save: " + fileName);
            } catch (Exception e) {
                toast("Audio nahi ban paya: " + e.getMessage());
            } finally {
                if (tmp != null) tmp.delete();
                if (out != null) out.delete();
            }
        }).start();
    }

    private static void copy(InputStream in, OutputStream out) throws java.io.IOException {
        byte[] b = new byte[64 * 1024];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }

    private void toast(String msg) {
        say(msg);
    }

    // ---------- navigation ----------

    private void go(String input) {
        String s = input.trim();
        if (s.isEmpty()) return;
        String url;
        if (s.startsWith("http://") || s.startsWith("https://")) {
            url = s;
        } else if (s.contains(".") && !s.contains(" ")) {
            url = "https://" + s;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(s);
        }
        radar.clear();
        lastDecoded = null;
        flowEnded();
        stepCount = 0;
        startRecording();
        flog("START " + url);
        web.loadUrl(url);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
