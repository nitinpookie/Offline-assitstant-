package com.fastlink.browser;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.util.Base64;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {

    // speed modes: 0 = off, 1 = smart (speeds up only on pages that look like a link-shortener step), 2 = turbo (always)
    private static final int[] RATES = {1, 10, 25};
    private static final String[] MODE_NAMES = {"Speed OFF", "Smart speed", "Turbo (har page par)"};
    private static final String[] MODE_DONE = {
            "Speed band ho gayi \u2705",
            "Smart speed chalu ho gayi \u26A1",
            "Turbo chalu ho gaya \uD83D\uDE80"};
    // lines shown (in the black pill) after an automatic tap
    private static final String[] TAP_LINES = {
            "Step # complete \u2705",
            "Step # ho gaya, ye bhi ho gaya \u2728",
            "Step # done, aage badh rahe hain \uD83D\uDE80",
            "Step # complete, ek dum smooth \uD83D\uDE0E"};

    // Ad / popup network domains (sub-resources are answered with harmless stubs, main-frame jumps are blocked)
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "googletagservices.com", "2mdn.net",
            "adnxs.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "pubmatic.com", "rubiconproject.com", "openx.net", "amazon-adsystem.com",
            "adsafeprotected.com", "moatads.com", "advertising.com", "adform.net",
            "smartadserver.com", "casalemedia.com", "indexww.com", "teads.tv",
            "mgid.com", "revcontent.com", "adskeeper.com", "adsrvr.org",
            "serving-sys.com", "lijit.com", "sharethrough.com", "yieldmo.com",
            "media.net", "zedo.com", "adition.com",
            "popads.net", "popcash.net", "propellerads.com", "exoclick.com",
            "exosrv.com", "exdynsrv.com", "realsrv.com", "juicyads.com", "adsterra.com", "hilltopads.net",
            "clickadu.com", "adcash.com", "bidvertiser.com", "onclickads.net",
            "a-ads.com", "ad-maven.com", "admaven.com", "monetag.com",
            "profitablecpmrate.com", "effectivegatecpm.com", "highperformanceformat.com",
            "yllix.com", "trafficjunky.net", "tsyndicate.com", "adtng.com",
            "trafficstars.com", "galaksion.com", "richads.com", "bidgear.com",
            "onclickalgo.com", "onclckmn.com", "pushame.com", "pushsar.com",
            "mondiad.com", "adspyglass.com", "clickaine.com", "wpadmngr.com", "adsco.re",
            "kueezrtb.com", "bidswitch.net", "33across.com", "smaato.net"
    };

    // Hosts that are known link-shortener / gate sites (used only as a hint; page content is checked too)
    private static final String[] SHORT_HOSTS = {
            "ouo.io", "ouo.press", "shrinkme.io", "shrinkearn.com", "shrtfly.com", "exe.io", "exey.io",
            "fc.lc", "fcc.lc", "clk.sh", "gplinks.co", "gplinks.in", "vplinks.in", "earnlinks.in", "droplink.co", "linkvertise.com",
            "link-to.net", "lootlabs.gg", "loot-link.com", "loot-links.com", "work.ink", "adfoc.us", "za.gl",
            "earnlink.io", "tnlink.in", "tnshort.net", "shortingly.in", "arolinks.com", "ez4short.com",
            "earn4link.in", "adrinolinks.in", "cuty.io", "shorte.st", "sh.st", "bc.vc", "adf.ly",
            "boost.ink", "rekonise.com", "shareus.io", "gyanilinks.com", "indiurl.in", "kpslink.in",
            "linkpays.in", "rocklinks.net", "urlpay.in", "inshorturl.com", "dalink.in", "vplink.in",
            "safelinku.com", "linkshrink.net", "adshrink.it", "short2url.in", "urlshortx.com"
    };

    // Final-destination hosts: a new tab to one of these is opened straight away
    private static final String[] FILE_HOSTS = {
            "drive.google.com", "docs.google.com", "mega.nz", "mediafire.com", "t.me", "telegram.me",
            "dropbox.com", "terabox.com", "1024terabox.com", "github.com", "play.google.com", "gofile.io", "pixeldrain.com",
            "workupload.com", "1fichier.com", "krakenfiles.com", "send.cm"
    };

    // Share / social endpoints that use ?u= or ?url= and must never be treated as redirects
    private static final String[] SOCIAL_HOSTS = {
            "facebook.com", "twitter.com", "x.com", "whatsapp.com", "wa.me", "linkedin.com", "pinterest.com",
            "reddit.com", "t.me", "telegram.me", "tumblr.com", "vk.com"
    };

    private static final String[] REDIR_PARAMS = {
            "r", "u", "url", "link", "go", "goto", "dest", "destination", "target", "to", "out",
            "redirect", "redirect_url", "redir", "next", "l", "d", "href", "q"
    };

    private static final String ADS_STUB =
            "(window.adsbygoogle=window.adsbygoogle||[]);window.adsbygoogle.loaded=true;window.adsbygoogle.push=function(){return 0};";

    private static final String GPT_STUB =
            "(function(){var w=window,g=w.googletag=w.googletag||{};var q=g.cmd||[];"
            + "var ch=new Proxy(function(){},{get:function(t,p){if(p==='then')return undefined;"
            + "if(p===Symbol.toPrimitive)return function(){return ''};return ch},apply:function(){return ch}});"
            + "g.apiReady=true;g.pubadsReady=true;"
            + "g.cmd={push:function(f){try{if(typeof f==='function')f.call(g)}catch(e){}return 1}};"
            + "['defineSlot','defineOutOfPageSlot','pubads','companionAds','content','sizeMapping','enableServices',"
            + "'display','destroySlots','setTargeting','addEventListener'].forEach(function(n){g[n]=function(){return ch}});"
            + "if(q.forEach)q.forEach(function(f){try{f.call(g)}catch(e){}})})();";

    // 1x1 transparent GIF
    private static final byte[] GIF = Base64.decode("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", Base64.DEFAULT);

    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private LinearLayout barBox;
    private View topBar;            // url bar row (hidden while a video plays fullscreen)

    // ---- fullscreen video / rotate support ----
    private View fsView;                                   // video view handed over by WebView
    private WebChromeClient.CustomViewCallback fsCb;
    private FrameLayout fsBox;
    private boolean manualLand;                            // user rotated to landscape from the menu
    private boolean landFs;                                // "video only" layout active (no real fullscreen)
    private String rotJs = "";

    // ---- history ----
    private static class Hist {
        final String title, url;
        final long time;

        Hist(String t, String u, long d) {
            title = t;
            url = u;
            time = d;
        }
    }

    private final ArrayList<Hist> hist = new ArrayList<>();
    private boolean histLoaded;
    private TextView barMsg, barAct;
    private Runnable hideBar;
    private TextView pill;
    private Runnable hidePill;
    private long lastTapMsgAt;
    private int msgIdx;
    private volatile boolean flowActive;
    private volatile int stepCount;
    private boolean copyFinal;
    private String stuckUrl;
    private int linkType;                       // 0 auto, 1 key, 2 file/apk (menu override)
    private volatile int flowKind;              // what the running flow is for: 0 unknown, 1 key, 2 file/apk
    private volatile int hops;
    private volatile String curPage, prevPage, flowOrigin;
    // flow recorder: last steps of the current link flow, copied from the menu
    private final java.util.ArrayDeque<String> flogBuf = new java.util.ArrayDeque<>();
    private long flogT0;
    private volatile long recUntil;
    private volatile String xrwStatus = "not-set";
    private final Set<String> seenHosts = new HashSet<>();
    private final Set<String> freshTried = new HashSet<>();
    private BroadcastReceiver dlReceiver;
    private final Set<Long> myDownloads = new HashSet<>();
    private SharedPreferences prefs;
    private volatile int speedMode;
    private volatile boolean autoOn, adOn;
    private boolean desktop, defaultWide, defaultOverview;
    private ScriptHandler scriptHandler;
    private boolean docStartSupported;
    private String videoUrl;
    private String bridgeName;
    private String mobileUa, desktopUa;
    private String coreJs = "", engineJs = "";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final Set<String> slowHosts = new HashSet<>();
    // per-site speed (learned after an "anomaly" or chosen by hand); 1x lives in slowHosts
    private final Map<String, Integer> hostRate = new HashMap<>();
    private static final int[] LADDER = {25, 10, 5, 3, 2, 1};
    private String chromeMajor = "124";
    private final LinkedHashMap<String, String> radar = new LinkedHashMap<>();
    private volatile long trustPopupUntil;
    private String allowOnceUrl, lastDecoded;
    private long lastAnomalyAt;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("fastlink", MODE_PRIVATE);
        speedMode = prefs.getInt("speedMode", 1);
        autoOn = prefs.getBoolean("auto", true);
        adOn = prefs.getBoolean("ads", true);
        copyFinal = prefs.getBoolean("copyFinal", true);
        linkType = prefs.getInt("linkType", 0);
        slowHosts.addAll(prefs.getStringSet("slow", Collections.<String>emptySet()));
        for (String e : prefs.getStringSet("hr", Collections.<String>emptySet())) {
            int i = e.lastIndexOf('|');
            if (i > 0) {
                try {
                    hostRate.put(e.substring(0, i), Integer.parseInt(e.substring(i + 1)));
                } catch (Exception ignored) {
                }
            }
        }
        bridgeName = "_f" + Long.toString(Math.abs(rnd.nextLong()), 36);
        coreJs = asset("flb_core.js");
        bridgeJs = asset("flb_bridge.js");
        mediaJs = asset("flb_media.js");
        engineJs = asset("flb_engine.js");
        rotJs = asset("flb_rotate.js");

        buildUi();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        // true on purpose: every window.open is caught in onCreateWindow and filtered there,
        // so the real "get link" popup is no longer silently dropped.
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        defaultWide = s.getUseWideViewPort();
        defaultOverview = s.getLoadWithOverviewMode();
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        // look like normal Chrome: no "wv" marker, no X-Requested-With header
        String ua = s.getUserAgentString();
        mobileUa = ua.replace("; wv)", ")").replace(" Version/4.0", "");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("Chrome/(\\d+)").matcher(mobileUa);
        String major = m.find() ? m.group(1) : "124";
        chromeMajor = major;
        desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + major + ".0.0.0 Safari/537.36";
        applyUa();
        try {
            // reflection on purpose: if this androidx.webkit version lacks the API, the build still works
            if (WebViewFeature.isFeatureSupported("REQUESTED_WITH_HEADER_ALLOW_LIST")) {
                WebSettingsCompat.class.getMethod("setRequestedWithHeaderOriginAllowList",
                        WebSettings.class, Set.class).invoke(null, s, Collections.<String>emptySet());
                xrwStatus = "off";
            } else {
                xrwStatus = "UNSUPPORTED (header is sent)";
            }
        } catch (Throwable t) {
            xrwStatus = "ERROR " + t.getClass().getSimpleName() + " (header may be sent)";
        }

        web.addJavascriptInterface(new Bridge(), bridgeName);
        docStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                // only http/https; blocks intent:// and app-open redirects
                if (!("http".equals(sc) || "https".equals(sc))) {
                    externalApp(u.toString());
                    return true;
                }
                if (!r.isForMainFrame()) return false;
                final String s = u.toString();
                if (s.equals(allowOnceUrl)) {
                    allowOnceUrl = null;
                    return false;
                }
                if (adOn) {
                    if (isAdUrl(u)) {
                        blockedJump(u);
                        return true;
                    }
                    if (isSearchPage(u) && !isSearchHost(hostOf(v.getUrl()))) {
                        blockedJump(u); // fake "continue" that throws you to a Google search
                        return true;
                    }
                }
                if (autoOn) {
                    final String d = decodeRedirect(u);
                    if (d != null && !d.equals(lastDecoded)) {
                        lastDecoded = d;
                        ui.post(() -> web.loadUrl(d));
                        return true;
                    }
                }
                return false;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                sniffMedia(r.getUrl());
                boolean ad = !r.isForMainFrame() && isAdUrl(r.getUrl());
                boolean relax = flowActive && SystemClock.elapsedRealtime() < recUntil;
                logHostOnce(r.getUrl(), ad, relax);
                if (adOn && ad && !relax) {
                    return stub(r);
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                urlBar.setText(url);
                if (landFs) applyLandFs(false);
                if (url != null && !url.equals(curPage)) {
                    prevPage = curPage;
                    curPage = url;
                }
                flog("NAV " + url);
                if (flowActive && hostIs(hostOf(url), FILE_HOSTS)) {
                    flog("FINAL file host reached");
                    flowEnded();
                    int n = prefs.getInt("flows", 0) + 1;
                    prefs.edit().putInt("flows", n).apply();
                    boolean copied = false;
                    if (copyFinal) {
                        try {
                            ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            if (cmb != null) {
                                cmb.setPrimaryClip(ClipData.newPlainText("link", url));
                                copied = true;
                            }
                        } catch (Exception ignored) {
                        }
                    }
                    say("Link mil gaya, ye complete ho gaya \uD83C\uDF89 (#" + n + (copied ? ", copy ho gaya" : "") + ")");
                }
                mediaItems.clear();
                boostSkipped = false;
                updateFab();
                loadingNow = true;
                reloadIc.setImageDrawable(new Ic(Ic.CLOSE, Ui.SUB));
                web.getSettings().setMediaPlaybackRequiresUserGesture(!isLightHost(hostOf(url)));
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (!docStartSupported) {
                    v.evaluateJavascript(script(), null);
                }
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                loadingNow = false;
                reloadIc.setImageDrawable(new Ic(Ic.REFRESH, Ui.SUB));
                addHistory(url, v.getTitle());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                enterFullscreen(view, cb);
            }

            @Override
            public void onHideCustomView() {
                exitFullscreen();
            }

            @Override
            public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }

            @Override
            public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message m) {
                return capturePopup(m);
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                result.confirm();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String message, JsResult result) {
                result.confirm();
                return true;
            }

            @Override
            public boolean onJsBeforeUnload(WebView v, String url, String message, JsResult result) {
                result.confirm(); // "Leave site?" prompts must never stop an automatic redirect
                return true;
            }
        });

        web.setDownloadListener((url, ua2, cd, mime, len) -> {
            if (flowActive) {
                flowEnded();
                prefs.edit().putInt("flows", prefs.getInt("flows", 0) + 1).apply();
            }
            if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                startDownload(url, URLUtil.guessFileName(url, cd, mime), mime, false, ua2);
            }
        });

        applyMode();


        Uri data = getIntent() != null ? getIntent().getData() : null;
        startRecording();
        flog("START " + (data != null ? data.toString() : "home"));
        if (data != null) {
            showHome(false);
            web.loadUrl(data.toString());
        } else {
            showHome(true);
        }
        askNotifPermission();
        screenRx = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                String a = i == null ? null : i.getAction();
                if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                    screenOff = true;
                    keepBgAlive();
                } else if (Intent.ACTION_SCREEN_ON.equals(a)) {
                    screenOff = false;
                }
            }
        };
        IntentFilter sf = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        sf.addAction(Intent.ACTION_SCREEN_ON);
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenRx, sf, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(screenRx, sf);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getData() != null) {
            startRecording();
            flog("START " + intent.getData());
            showHome(false);
            web.loadUrl(intent.getData().toString());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MediaService.controller = null;
        MediaService.hold = false;
        MediaService.playing = false;
        MediaService.sync(this);
        if (dc != null) dc.setListener(null);
        try {
            if (screenRx != null) unregisterReceiver(screenRx);
        } catch (Exception ignored) {
        }
        try {
            if (dlReceiver != null) unregisterReceiver(dlReceiver);
        } catch (Exception ignored) {
        }
        try {
            web.destroy();
        } catch (Exception ignored) {
        }
    }

    // ---------- JS bridge ----------

    private class Bridge {
        @JavascriptInterface
        public void videoFound(String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(() -> addMedia(url));
        }

        @JavascriptInterface
        public void mediaState(int playing, String title) {
            runOnUiThread(() -> onMediaState(playing == 1, title));
        }

        @JavascriptInterface
        public void boostSkip(int x) {
            runOnUiThread(() -> boostSkipped = true);
        }

        @JavascriptInterface
        public void noVideo() {
        }

        // a real touch (isTrusted = true) at page coordinates already converted to view pixels
        @JavascriptInterface
        public void tap(final float x, final float y, final int tier) {
            ui.post(() -> {
                if (x < 0 || y < 0 || x > web.getWidth() || y > web.getHeight()) return;
                if (tier >= 2) trustPopupUntil = SystemClock.uptimeMillis() + 5000;
                final long t = SystemClock.uptimeMillis();
                final float jx = x + (rnd.nextFloat() - 0.5f) * 2f;
                final float jy = y + (rnd.nextFloat() - 0.5f) * 2f;
                final int dur = 70 + rnd.nextInt(90);
                sendTouch(MotionEvent.ACTION_DOWN, t, t, jx, jy);
                ui.postDelayed(() -> sendTouch(MotionEvent.ACTION_MOVE, t, SystemClock.uptimeMillis(),
                        jx + (rnd.nextFloat() - 0.5f) * 3f, jy + (rnd.nextFloat() - 0.5f) * 3f), dur / 2);
                ui.postDelayed(() -> {
                    sendTouch(MotionEvent.ACTION_UP, t, SystemClock.uptimeMillis(), jx, jy);
                    tapDone();
                }, dur);
            });
        }

        // the engine recognised a link-shortener page and started working on it (kind: 0 unknown, 1 key, 2 file/apk)
        @JavascriptInterface
        public void started(final int rate, final int kind) {
            if (!flowActive) {
                stepCount = 0;
                hops = 0;
                flowOrigin = prevPage;
            }
            flowActive = true;
            flowKind = kind;
            hops++;
            recUntil = SystemClock.elapsedRealtime() + 180000L;
            flog("ENGINE started kind=" + kind + " rate=" + rate + " hop=" + hops);
            ui.post(() -> {
                applyMode();
                String sp = rate > 1 ? ", " + rate + "x speed" : "";
                if (kind == 1) say("Key wala link pakda \uD83D\uDD11 checkpoint " + hops + sp);
                else if (kind == 2) say("File/APK wala link pakda \uD83D\uDCE6 step " + hops + sp);
                else say(rate > 1
                        ? "Link page pakad liya, " + rate + "x speed chalu ho gayi \u26A1"
                        : "Link page pakad liya, ye chalu ho gaya \u26A1");
            });
        }

        // the engine changed its mind about what this flow is for
        @JavascriptInterface
        public void kind(final int k) {
            if (!flowActive || k == flowKind) return;
            flowKind = k;
            flog("KIND changed to " + k);
            ui.post(() -> {
                applyMode();
                if (k == 1) say("Ye key wala link lag raha hai \uD83D\uDD11 key mode chalu");
                else if (k == 2) say("Ye file/APK wala link lag raha hai \uD83D\uDCE6 file mode chalu");
            });
        }

        @JavascriptInterface
        public void cp(final int n, final int of) {
            if (!flowActive) return;
            flog("CHECKPOINT " + n + "/" + of);
            ui.post(() -> say(flowKind == 1 ? "Checkpoint " + n + "/" + of + " \uD83D\uDD11" : "Step " + n + "/" + of));
        }

        // a key was found on the page: save it, copy it, stop the auto-clicking
        @JavascriptInterface
        public void key(final String key, final String host, final String info) {
            if (key == null || key.isEmpty()) return;
            flog("KEY found len=" + key.length() + " host=" + host);
            ui.post(() -> {
                saveKey(key, host);
                boolean copied = false;
                try {
                    ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cmb != null) {
                        cmb.setPrimaryClip(ClipData.newPlainText("key", key));
                        copied = true;
                    }
                } catch (Exception ignored) {
                }
                prefs.edit().putInt("keysDone", prefs.getInt("keysDone", 0) + 1).apply();
                flowEnded();
                String pv = key.length() > 24 ? key.substring(0, 24) + "\u2026" : key;
                say("Key mil gayi \uD83D\uDD11 " + (copied ? "copy ho gayi" : "") + "\n" + pv
                        + (info == null || info.isEmpty() ? "" : "\n(valid: " + info + ")"));
            });
        }

        // page the user came from before this flow started (full URL, the browser Referer is often cut to the origin)
        @JavascriptInterface
        public String origin() {
            String o = flowActive && flowOrigin != null ? flowOrigin : prevPage;
            return o == null ? "" : o;
        }

        @JavascriptInterface
        public void log(final String line) {
            if (line == null) return;
            flog(line.length() > 700 ? line.substring(0, 700) : line);
        }

        @JavascriptInterface
        public boolean recOn() {
            return flowActive || SystemClock.elapsedRealtime() < recUntil;
        }

        // real (trusted) finger drag, eased like a human swipe
        @JavascriptInterface
        public void swipe(final float x, final float y0, final float y1, final int ms) {
            ui.post(() -> {
                if (x < 0 || y0 < 0 || y1 < 0 || x > web.getWidth() || y0 > web.getHeight() || y1 > web.getHeight()) return;
                final long t = SystemClock.uptimeMillis();
                final int steps = Math.max(6, Math.min(30, ms / 16));
                sendTouch(MotionEvent.ACTION_DOWN, t, t, x, y0);
                for (int k = 1; k <= steps; k++) {
                    final float f = k / (float) steps;
                    final float e = f * f * (3f - 2f * f);
                    final boolean last = k == steps;
                    final float yy = y0 + (y1 - y0) * e;
                    final float xx = x + (rnd.nextFloat() - 0.5f) * 3f;
                    ui.postDelayed(() -> sendTouch(last ? MotionEvent.ACTION_UP : MotionEvent.ACTION_MOVE,
                            t, SystemClock.uptimeMillis(), xx, yy), (long) (ms * f));
                }
            });
        }

        // the engine has been idle for a long time: reload once per page, then fall back to a hint
        @JavascriptInterface
        public void stuck() {
            ui.post(() -> {
                String u = web.getUrl();
                if (u == null) return;
                flog("STUCK (30s without progress) url=" + u);
                if (flowKind == 1 || u.equals(stuckUrl)) {
                    say("Auto ruk gaya. \u22EE menu \u2192 Link Radar dekho");
                    return;
                }
                stuckUrl = u;
                say("Atak gaya tha, dobara try kar raha hoon \uD83D\uDD01");
                web.reload();
            });
        }

        @JavascriptInterface
        public void hint(final String msg) {
            if (msg == null) return;
            flog("HINT " + msg);
            ui.post(() -> showBar(msg, null, null));
        }

        @JavascriptInterface
        public void busy(final boolean on) {
            ui.post(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        // the site complained about our speed -> step that site one level slower (25 -> 10 -> 5 -> 3 -> 2 -> real-time) and retry
        @JavascriptInterface
        public void anomaly(final String host) {
            ui.post(() -> {
                if (host == null || host.isEmpty()) return;
                long now = SystemClock.uptimeMillis();
                if (now - lastAnomalyAt < 8000) return;
                lastAnomalyAt = now;
                int cur = effectiveRate(host);
                flog("ANOMALY host=" + host + " rate=" + cur);
                if (cur <= 1) {
                    if (flowKind != 1 && freshTried.add(host)) {
                        freshSession(web.getUrl());
                        say("Real-time par bhi anomaly, fresh session ke saath dobara try \uD83D\uDD01");
                        web.reload();
                    } else {
                        showBar(flowKind == 1
                                ? host + ": real-time par bhi anomaly. Key flow hai, isliye session saaf nahi kiya (checkpoints reset ho jaate)"
                                : host + ": real-time + fresh session par bhi anomaly. Ye server-side check hai", null, null);
                    }
                    return;
                }
                int next = nextLower(cur);
                setHostRate(host, next);
                applyMode();
                showBar("Anomaly: " + host + " " + cur + "x \u2192 " + (next <= 1 ? "real-time" : next + "x") + ", dobara try", null, null);
                web.reload();
            });
        }
    }

    private void sendTouch(int action, long down, long now, float x, float y) {
        MotionEvent.PointerProperties pp = new MotionEvent.PointerProperties();
        pp.id = 0;
        pp.toolType = MotionEvent.TOOL_TYPE_FINGER;
        MotionEvent.PointerCoords pc = new MotionEvent.PointerCoords();
        pc.x = x;
        pc.y = y;
        pc.pressure = action == MotionEvent.ACTION_UP ? 0f : 0.55f + rnd.nextFloat() * 0.3f;
        pc.size = 0.4f + rnd.nextFloat() * 0.3f;
        MotionEvent e = MotionEvent.obtain(down, now, action, 1,
                new MotionEvent.PointerProperties[]{pp}, new MotionEvent.PointerCoords[]{pc},
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
        web.dispatchTouchEvent(e);
        e.recycle();
    }

    // ---------- toggles / scripts ----------

    private TextView toggle(String label, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(20);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        t.setOnClickListener(l);
        return t;
    }

    private void changed(String msg) {
        applyMode();
        say(msg);
        web.reload();
    }

    private void applyMode() {
        if (docStartSupported) {
            if (scriptHandler != null) {
                scriptHandler.remove();
                scriptHandler = null;
            }
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(
                    web, script(), Collections.singleton("*"));
        }
    }

    private void applyUa() {
        WebSettings s = web.getSettings();
        s.setUserAgentString(desktop ? desktopUa : mobileUa);
        s.setUseWideViewPort(desktop || defaultWide);
        s.setLoadWithOverviewMode(desktop || defaultOverview);
        applyUaMetadata();
    }

    // Sec-CH-UA headers + navigator.userAgentData say "Google Chrome" instead of "Android WebView".
    // Done by reflection so the build still works if this androidx.webkit lacks the API.
    private void applyUaMetadata() {
        try {
            if (!WebViewFeature.isFeatureSupported("USER_AGENT_METADATA")) return;
            Class<?> bvB = Class.forName("androidx.webkit.UserAgentMetadata$BrandVersion$Builder");
            Class<?> umB = Class.forName("androidx.webkit.UserAgentMetadata$Builder");
            Class<?> umC = Class.forName("androidx.webkit.UserAgentMetadata");
            String full = chromeMajor + ".0.0.0";
            String[][] brands = {{"Chromium", chromeMajor, full}, {"Google Chrome", chromeMajor, full},
                    {"Not-A.Brand", "99", "99.0.0.0"}};
            ArrayList<Object> list = new ArrayList<>();
            for (String[] b : brands) {
                Object bb = bvB.getConstructor().newInstance();
                bvB.getMethod("setBrand", String.class).invoke(bb, b[0]);
                bvB.getMethod("setMajorVersion", String.class).invoke(bb, b[1]);
                bvB.getMethod("setFullVersion", String.class).invoke(bb, b[2]);
                list.add(bvB.getMethod("build").invoke(bb));
            }
            Object mb = umB.getConstructor().newInstance();
            umB.getMethod("setBrandVersionList", List.class).invoke(mb, list);
            trySet(mb, "setFullVersion", String.class, full);
            trySet(mb, "setPlatform", String.class, desktop ? "Linux" : "Android");
            trySet(mb, "setMobile", boolean.class, !desktop);
            trySet(mb, "setModel", String.class, desktop ? "" : android.os.Build.MODEL);
            if (!desktop) trySet(mb, "setPlatformVersion", String.class, android.os.Build.VERSION.RELEASE + ".0.0");
            Object md = umB.getMethod("build").invoke(mb);
            WebSettingsCompat.class.getMethod("setUserAgentMetadata", WebSettings.class, umC)
                    .invoke(null, web.getSettings(), md);
        } catch (Throwable ignored) {
        }
    }

    private static void trySet(Object b, String method, Class<?> type, Object value) {
        try {
            b.getClass().getMethod(method, type).invoke(b, value);
        } catch (Throwable ignored) {
        }
    }

    // ---------- per-site speed ----------

    private int effectiveRate(String root) {
        if (speedMode == 0) return 1;
        if (slowHosts.contains(root)) return 1;
        Integer r = hostRate.get(root);
        return r != null ? r : RATES[speedMode];
    }

    private static int nextLower(int r) {
        for (int x : LADDER) {
            if (x < r) return x;
        }
        return 1;
    }

    private void setHostRate(String host, int r) {
        if (r <= 1) {
            hostRate.remove(host);
            slowHosts.add(host);
        } else {
            slowHosts.remove(host);
            hostRate.put(host, r);
        }
        saveSlow();
        saveRates();
    }

    private void saveRates() {
        Set<String> out = new HashSet<>();
        for (Map.Entry<String, Integer> e : hostRate.entrySet()) out.add(e.getKey() + "|" + e.getValue());
        prefs.edit().putStringSet("hr", out).apply();
    }

    private void showSiteSpeed(final String root) {
        if (root.isEmpty()) return;
        final int[] opts = {0, 1, 2, 3, 5, 10, 25};
        String[] names = new String[opts.length];
        for (int i = 0; i < opts.length; i++) {
            names[i] = opts[i] == 0 ? "Auto (app khud seekhegi)" : opts[i] == 1 ? "1x (real-time)" : opts[i] + "x";
        }
        new AlertDialog.Builder(this)
                .setTitle(root + " \u2014 abhi: " + effectiveRate(root) + "x")
                .setItems(names, (d, which) -> {
                    int r = opts[which];
                    slowHosts.remove(root);
                    hostRate.remove(root);
                    if (r == 1) slowHosts.add(root);
                    else if (r > 1) hostRate.put(root, r);
                    saveSlow();
                    saveRates();
                    applyMode();
                    say(r == 0 ? "Auto speed set ho gayi \u2705" : "Is site par " + r + "x set ho gaya \u2705");
                    web.reload();
                })
                .show();
    }

    private String script() {
        JSONObject c = new JSONObject();
        try {
            c.put("n", bridgeName);
            c.put("mode", speedMode);
            c.put("rate", RATES[speedMode]);
            c.put("auto", autoOn);
            c.put("ads", adOn);
            c.put("lt", linkType);
            c.put("fk", flowActive ? flowKind : 0);
            c.put("fa", flowActive ? 1 : 0);
            c.put("slow", new JSONArray(new ArrayList<>(slowHosts)));
            JSONObject hr = new JSONObject();
            for (Map.Entry<String, Integer> e : hostRate.entrySet()) hr.put(e.getKey(), e.getValue());
            c.put("hr", hr);
            c.put("adh", new JSONArray(Arrays.asList(AD_HOSTS)));
            c.put("sh", new JSONArray(Arrays.asList(SHORT_HOSTS)));
            c.put("boost", boostPct);
            c.put("lim", limOn);
            c.put("bg", bgOn);
            c.put("hall", hallOn);
            c.put("lh", new JSONArray(Arrays.asList(LIGHT_HOSTS)));
        } catch (Exception ignored) {
        }
        return "(function(){var K='" + bridgeName + "x';if(window[K])return;"
                + "Object.defineProperty(window,K,{value:1});\nvar C=" + c + ";\n"
                + bridgeJs + "\n" + mediaJs + "\n"
                + "var LH=C.lh,HN=location.hostname.toLowerCase();"
                + "for(var li=0;li<LH.length;li++){if(HN===LH[li]||HN.endsWith('.'+LH[li]))return;}\n"
                + coreJs + "\n" + engineJs + "\n})();";
    }

    private String asset(String name) {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            copy(in, bo);
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void saveSlow() {
        prefs.edit().putStringSet("slow", new HashSet<>(slowHosts)).apply();
    }

    // ---------- host helpers ----------

    private static String hostOf(String url) {
        if (url == null) return "";
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? "" : h.toLowerCase();
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean hostIs(String h, String... list) {
        if (h == null) return false;
        for (String d : list) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    private static String rootHost(String h) {
        if (h == null) return "";
        String[] p = h.toLowerCase().split("\\.");
        if (p.length <= 2) return h.toLowerCase();
        String l = p[p.length - 1], s = p[p.length - 2];
        if (l.length() == 2 && s.matches("co|com|org|net|gov|ac|edu|nic")) {
            return p[p.length - 3] + "." + s + "." + l;
        }
        return s + "." + l;
    }

    private boolean isAdUrl(Uri u) {
        String h = u.getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        if (hostIs(h, AD_HOSTS)) return true;
        if (h.equals("youtube.com") || h.endsWith(".youtube.com")) {
            String p = u.getPath();
            if (p != null && (p.startsWith("/pagead/") || p.startsWith("/api/stats/ads")
                    || p.startsWith("/get_midroll_") || p.contains("/ptracking"))) {
                return true;
            }
        }
        return false;
    }

    private static boolean isSearchHost(String h) {
        return h.matches("(.*\\.)?google\\.[a-z.]+") || hostIs(h, "bing.com", "duckduckgo.com", "search.yahoo.com");
    }

    private static boolean isSearchPage(Uri u) {
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        String p = u.getPath() == null ? "" : u.getPath();
        if (h.matches("(.*\\.)?google\\.[a-z.]+") && p.startsWith("/search")) return true;
        if (hostIs(h, "bing.com") && p.startsWith("/search")) return true;
        if (hostIs(h, "duckduckgo.com") && u.getQueryParameter("q") != null) return true;
        return hostIs(h, "search.yahoo.com");
    }

    private void blockedJump(final Uri u) {
        final String s = u.toString();
        ui.post(() -> showBar("Fake redirect roka: " + hostOf(s), "Allow", () -> {
            allowOnceUrl = s;
            web.loadUrl(s);
        }));
    }

    // Reads the real target out of ?r=<base64>, ?url=<encoded url> and similar redirect parameters
    private String decodeRedirect(Uri u) {
        try {
            String host = u.getHost();
            if (host == null) return null;
            host = host.toLowerCase();
            if (hostIs(host, SOCIAL_HOSTS)) return null;
            String path = u.getPath() == null ? "" : u.getPath().toLowerCase();
            boolean googleUrl = host.matches("(.*\\.)?google\\.[a-z.]+") && path.equals("/url");
            boolean ytRedirect = hostIs(host, "youtube.com") && path.equals("/redirect");
            boolean pathHint = path.matches(".*/(go|out|redirect|redir|away|link|l|r|click|safe|skip|exit|jump|bridge|visit)(/.*)?");
            boolean shortHost = hostIs(host, SHORT_HOSTS);
            for (String name : u.getQueryParameterNames()) {
                boolean listed = false;
                for (String p : REDIR_PARAMS) {
                    if (p.equalsIgnoreCase(name)) {
                        listed = true;
                        break;
                    }
                }
                if (!listed) continue;
                String v = u.getQueryParameter(name);
                if (v == null || v.length() < 12) continue;
                String dec = null;
                if (v.startsWith("aHR0")) {
                    dec = b64(v);
                } else if ((v.startsWith("http://") || v.startsWith("https://"))
                        && (pathHint || googleUrl || ytRedirect || shortHost)) {
                    dec = v;
                }
                if (dec == null) continue;
                Uri d = Uri.parse(dec);
                String dh = d.getHost();
                if (dh == null || !dh.contains(".") || dh.equalsIgnoreCase(host)) continue;
                if (isAdUrl(d) || isSearchPage(d)) continue;
                return dec;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String b64(String v) {
        try {
            String s = v.replace('-', '+').replace('_', '/');
            while (s.length() % 4 != 0) s += "=";
            String r = new String(Base64.decode(s, Base64.DEFAULT), "UTF-8").trim();
            return r.startsWith("http://") || r.startsWith("https://") ? r : null;
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- harmless answers for blocked ad requests (so anti-adblock checks pass) ----------

    private WebResourceResponse stub(WebResourceRequest r) {
        Uri u = r.getUrl();
        String p = u.getPath() == null ? "" : u.getPath().toLowerCase();
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        Map<String, String> req = r.getRequestHeaders();
        String accept = req == null ? null : req.get("Accept");
        byte[] body;
        String mime;
        if (p.endsWith("adsbygoogle.js") || p.contains("/show_ads")) {
            body = ADS_STUB.getBytes();
            mime = "application/javascript";
        } else if (p.endsWith("/gpt.js") || p.contains("pubads_impl") || h.contains("googletagservices")) {
            body = GPT_STUB.getBytes();
            mime = "application/javascript";
        } else if (p.matches(".*\\.(gif|png|jpe?g|webp|svg)$") || (accept != null && accept.startsWith("image/"))) {
            body = GIF;
            mime = "image/gif";
        } else if (accept != null && accept.contains("text/html")) {
            body = "<!doctype html><html><body></body></html>".getBytes();
            mime = "text/html";
        } else if (p.endsWith(".css")) {
            body = "/* */".getBytes();
            mime = "text/css";
        } else if (accept != null && accept.contains("application/json")) {
            body = "{}".getBytes();
            mime = "application/json";
        } else {
            body = "/* */".getBytes();
            mime = "application/javascript";
        }
        Map<String, String> hd = new HashMap<>();
        hd.put("Access-Control-Allow-Origin", "*");
        hd.put("Cache-Control", "no-store");
        return new WebResourceResponse(mime, "utf-8", 200, "OK", hd, new ByteArrayInputStream(body));
    }

    // ---------- popups (window.open): ads dropped, the real "get link" popup kept ----------

    private boolean capturePopup(Message m) {
        if (m == null || !(m.obj instanceof WebView.WebViewTransport)) return false;
        final WebView tmp = new WebView(this);
        tmp.setWebViewClient(new WebViewClient() {
            private volatile boolean done;

            private void got(final String url) {
                if (done || url == null || url.startsWith("about:") || url.startsWith("blob:")
                        || url.startsWith("data:") || url.startsWith("javascript:")) return;
                done = true;
                ui.post(() -> {
                    handlePopup(url);
                    try {
                        tmp.stopLoading();
                        tmp.destroy();
                    } catch (Exception ignored) {
                    }
                });
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                got(r.getUrl().toString());
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                got(url);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (r.isForMainFrame()) got(r.getUrl().toString());
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        ui.postDelayed(() -> {
            try {
                tmp.destroy();
            } catch (Exception ignored) {
            }
        }, 12000);
        WebView.WebViewTransport tr = (WebView.WebViewTransport) m.obj;
        tr.setWebView(tmp);
        m.sendToTarget();
        return true;
    }

    private void handlePopup(final String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        flog("POPUP " + url);
        Uri u = Uri.parse(url);
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        if (h.isEmpty()) return;
        String curHost = hostOf(web.getUrl());
        if (adOn && (isAdUrl(u) || isSearchPage(u))) {
            showBar("Popup roka: " + h, "Open", () -> web.loadUrl(url));
            return;
        }
        boolean trusted = autoOn && SystemClock.uptimeMillis() < trustPopupUntil;
        boolean sameSite = rootHost(h).equals(rootHost(curHost));
        if (sameSite || trusted || hostIs(h, FILE_HOSTS) || hostIs(h, SHORT_HOSTS)) {
            web.loadUrl(url);
            return;
        }
        addRadar(url, "popup");
        showBar("Naya tab roka: " + h, "Open", () -> web.loadUrl(url));
    }

    private void addRadar(String url, String label) {
        radar.put(url, label);
        while (radar.size() > 30) {
            String first = radar.keySet().iterator().next();
            radar.remove(first);
        }
    }

    // ---------- bottom bar, menu, link radar ----------

    private void showBar(String msg, String action, final Runnable r) {
        if (action == null || r == null) {
            say(msg);
            return;
        }
        barMsg.setText(msg);
        barAct.setText(action);
        barAct.setVisibility(View.VISIBLE);
        barAct.setOnClickListener(v -> {
            barBox.setVisibility(View.GONE);
            r.run();
        });
        barBox.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideBar);
        ui.postDelayed(hideBar, 9000);
    }

    // toast-style message (dark rounded pill at the bottom); safe to call from any thread
    private void say(final String msg) {
        if (msg == null || msg.isEmpty()) return;
        runOnUiThread(() -> {
            pill.animate().cancel();
            ui.removeCallbacks(hidePill);
            pill.setText(msg);
            pill.setAlpha(0f);
            pill.setVisibility(View.VISIBLE);
            pill.animate().alpha(1f).setDuration(160).start();
            ui.postDelayed(hidePill, Math.min(6000, 2200 + 45L * msg.length()));
        });
    }

    // feedback after an automatic tap (not more than one line every 2.5 s)
    private void tapDone() {
        stepCount++;
        flog("TAP landed, step=" + stepCount);
        long now = SystemClock.uptimeMillis();
        if (now - lastTapMsgAt < 1800) return;
        lastTapMsgAt = now;
        say(TAP_LINES[(msgIdx++) % TAP_LINES.length].replace("#", String.valueOf(stepCount)));
    }

    private void flog(String line) {
        if (!flowActive && SystemClock.elapsedRealtime() > recUntil) return;
        synchronized (flogBuf) {
            long now = SystemClock.elapsedRealtime();
            if (flogBuf.isEmpty()) flogT0 = now;
            flogBuf.addLast(String.format(java.util.Locale.US, "[%5.1fs] ", (now - flogT0) / 1000.0) + line);
            while (flogBuf.size() > 300) flogBuf.removeFirst();
        }
    }

    private void logHostOnce(Uri u, boolean ad, boolean relax) {
        if (!flowActive && SystemClock.elapsedRealtime() > recUntil) return;
        String h = u.getHost();
        if (h == null) return;
        synchronized (flogBuf) {
            if (seenHosts.size() > 80 || !seenHosts.add(h)) return;
        }
        flog("REQ " + h + (ad ? (relax ? " [ad: allowed during flow]" : " [ad: blocked]") : ""));
    }

    private void startRecording() {
        synchronized (flogBuf) {
            flogBuf.clear();
            seenHosts.clear();
        }
        recUntil = SystemClock.elapsedRealtime() + 180000L;
    }

    private int flogSize() {
        synchronized (flogBuf) {
            return flogBuf.size();
        }
    }

    private void copyFlowLog() {
        StringBuilder sb = new StringBuilder();
        String wv = "?";
        try {
            android.content.pm.PackageInfo pi = WebView.getCurrentWebViewPackage();
            if (pi != null) wv = pi.versionName;
        } catch (Throwable ignored) {
        }
        sb.append("NixuBrowse v4.3 | speedMode=").append(speedMode).append(" auto=").append(autoOn)
                .append(" ads=").append(adOn).append(" type=").append(linkType)
                .append(" | webview=").append(wv).append(" | xrw=").append(xrwStatus).append(" | android=").append(Build.VERSION.SDK_INT).append("\n");
        synchronized (flogBuf) {
            for (String l : flogBuf) sb.append(l).append("\n");
        }
        try {
            ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cmb != null) cmb.setPrimaryClip(ClipData.newPlainText("flowlog", sb.toString()));
            say("Flow log copy ho gaya \uD83D\uDCDD (" + flogSize() + " lines), ab chat mein paste karo");
        } catch (Exception e) {
            say("Log copy nahi ho paaya");
        }
    }

    private void flowEnded() {
        flowActive = false;
        flowKind = 0;
        hops = 0;
        flowOrigin = null;
        applyMode();
    }

    private void saveKey(String key, String host) {
        try {
            JSONArray old = new JSONArray(prefs.getString("keys", "[]"));
            JSONArray out = new JSONArray();
            JSONObject nj = new JSONObject();
            nj.put("k", key);
            nj.put("h", host == null ? "" : host);
            nj.put("t", System.currentTimeMillis());
            out.put(nj);
            for (int k = 0; k < old.length() && out.length() < 20; k++) {
                JSONObject o = old.getJSONObject(k);
                if (key.equals(o.optString("k"))) continue;
                out.put(o);
            }
            prefs.edit().putString("keys", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private int keyCount() {
        try {
            return new JSONArray(prefs.getString("keys", "[]")).length();
        } catch (Exception e) {
            return 0;
        }
    }

    // ====================================================================== v5: pill UI, sheets, downloads, sound

    private static final String[] LIGHT_HOSTS = {"youtube.com", "youtu.be", "googlevideo.com", "ytimg.com",
            "instagram.com", "facebook.com", "fb.com", "twitter.com", "x.com", "whatsapp.com", "telegram.org",
            "spotify.com", "soundcloud.com", "jiosaavn.com", "gaana.com", "wynk.in", "netflix.com",
            "primevideo.com", "hotstar.com", "reddit.com", "wikipedia.org", "github.com", "linkedin.com"};

    private boolean isLightHost(String h) {
        return hostIs(h, LIGHT_HOSTS);
    }

    private FrameLayout rootFrame, content, navHomeCell, navDlCell;
    private Ui.Sheet sheet;
    private Ui.Fab fab;
    private View navBox, homeView, strip, stripFill, stripRest;
    private LinearLayout urlPill, homeGrid;
    private ImageView reloadIc, stripPause;
    private TextView navBadge, stripName, stripInfo;
    private DownloadCenter dc;
    private DownloadCenter.Task stripTask, stripShown;
    private final LinkedHashMap<String, String[]> mediaItems = new LinkedHashMap<>();
    private final ArrayList<String[]> homeSites = new ArrayList<>();
    private int boostPct = 100, maxRootH;
    private boolean limOn = true, bgOn = true, fabOn = true, hallOn;
    private volatile boolean userPaused, screenOff;
    private BroadcastReceiver screenRx;
    private FrameLayout navWebCell;
    private boolean homeShown, homeByBack, kbOpen, loadingNow, playingNow, boostSkipped, intentDlgOpen;
    private long lastIntentAt;
    private String lastIntentUrl;
    private String bridgeJs = "", mediaJs = "";

    private static class DlRow {
        LinearLayout card;
        TextView name, info, b1, b2, b3;
        View fill, rest;
    }

    private final HashMap<Integer, DlRow> dlRows = new HashMap<>();
    private final ArrayList<Integer> dlOrder = new ArrayList<>();
    private LinearLayout dlList;

    private void applyBars() {
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    private FrameLayout navItem(LinearLayout row, int kind, View.OnClickListener l) {
        FrameLayout cell = new FrameLayout(this);
        ImageView iv = Ui.icon(this, kind, Ui.INK);
        cell.addView(iv, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        cell.setOnClickListener(l);
        Ui.press(cell);
        cell.setTag(iv);
        row.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        return cell;
    }

    private void buildUi() {
        final int MP = ViewGroup.LayoutParams.MATCH_PARENT, WC = ViewGroup.LayoutParams.WRAP_CONTENT;
        boostPct = prefs.getInt("boost", 100);
        limOn = prefs.getBoolean("lim", true);
        bgOn = prefs.getBoolean("bg", true);
        fabOn = prefs.getBoolean("fab", true);
        hallOn = prefs.getBoolean("hall", false);
        BgWebView.allow = bgOn;
        applyBars();

        rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        rootFrame.addView(root, new FrameLayout.LayoutParams(MP, MP));

        // ---- top: pill url / search field
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setBackgroundColor(Color.WHITE);
        top.setPadding(dp(12), dp(8), dp(12), dp(8));
        urlPill = new LinearLayout(this);
        urlPill.setOrientation(LinearLayout.HORIZONTAL);
        urlPill.setGravity(Gravity.CENTER_VERTICAL);
        urlPill.setBackground(Ui.round(Ui.BG, dp(24)));
        urlPill.setPadding(dp(14), 0, dp(6), 0);
        urlPill.addView(Ui.icon(this, Ic.SEARCH, Ui.SUB), new LinearLayout.LayoutParams(dp(18), dp(18)));
        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setHint("Search or enter URL");
        urlBar.setHintTextColor(Ui.SUB);
        urlBar.setTextColor(Ui.INK);
        urlBar.setTextSize(15);
        urlBar.setBackground(null);
        urlBar.setPadding(dp(10), 0, dp(6), 0);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                return true;
            }
            return false;
        });
        urlPill.addView(urlBar, new LinearLayout.LayoutParams(0, MP, 1f));
        reloadIc = Ui.icon(this, Ic.REFRESH, Ui.SUB);
        reloadIc.setPadding(dp(9), dp(9), dp(9), dp(9));
        reloadIc.setOnClickListener(v -> {
            if (loadingNow) web.stopLoading();
            else if (!homeShown) web.reload();
        });
        urlPill.addView(reloadIc, new LinearLayout.LayoutParams(dp(40), dp(40)));
        top.addView(urlPill, new LinearLayout.LayoutParams(MP, dp(46)));
        root.addView(top);
        topBar = top;

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        root.addView(progress, new LinearLayout.LayoutParams(MP, dp(3)));

        // ---- content: web + home + floating things
        content = new FrameLayout(this);
        web = new BgWebView(this);
        content.addView(web, new FrameLayout.LayoutParams(MP, MP));
        buildHome();
        content.addView(homeView, new FrameLayout.LayoutParams(MP, MP));

        fab = new Ui.Fab(this);
        fab.setOnClickListener(v -> showMediaSheet());
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM | Gravity.END);
        flp.setMargins(0, 0, dp(16), dp(92));
        content.addView(fab, flp);

        // download strip (top): name, speed, progress, pause / cancel
        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.VERTICAL);
        st.setBackground(Ui.round(Color.argb(244, 28, 30, 36), dp(22)));
        st.setElevation(dp(8));
        st.setPadding(dp(16), dp(10), dp(8), dp(12));
        LinearLayout srow = new LinearLayout(this);
        srow.setOrientation(LinearLayout.HORIZONTAL);
        srow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout stxt = new LinearLayout(this);
        stxt.setOrientation(LinearLayout.VERTICAL);
        stripName = Ui.label(this, "", 13.5f, Color.WHITE, true);
        stripName.setSingleLine(true);
        stripName.setEllipsize(TextUtils.TruncateAt.END);
        stripInfo = Ui.label(this, "", 12, 0xFFB0B0B8, false);
        stripInfo.setSingleLine(true);
        stxt.addView(stripName);
        stxt.addView(stripInfo);
        srow.addView(stxt, new LinearLayout.LayoutParams(0, WC, 1f));
        stripPause = Ui.icon(this, Ic.PAUSE, Color.WHITE);
        stripPause.setPadding(dp(9), dp(9), dp(9), dp(9));
        stripPause.setOnClickListener(v -> {
            DownloadCenter.Task t = stripShown;
            if (t == null) return;
            if (t.state == DownloadCenter.RUNNING || t.state == DownloadCenter.QUEUED) dc.pause(t);
            else {
                stripTask = t;
                dc.resume(t);
            }
        });
        srow.addView(stripPause, new LinearLayout.LayoutParams(dp(38), dp(38)));
        ImageView stripX = Ui.icon(this, Ic.CLOSE, Color.WHITE);
        stripX.setPadding(dp(9), dp(9), dp(9), dp(9));
        stripX.setOnClickListener(v -> {
            DownloadCenter.Task t = stripShown;
            if (t != null) {
                dc.cancel(t);
                say("Download cancel ho gaya");
            }
        });
        srow.addView(stripX, new LinearLayout.LayoutParams(dp(38), dp(38)));
        st.addView(srow);
        LinearLayout track = new LinearLayout(this);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setBackground(Ui.round(0x33FFFFFF, dp(3)));
        stripFill = new View(this);
        stripFill.setBackground(Ui.round(Ui.ACCENT, dp(3)));
        stripRest = new View(this);
        track.addView(stripFill, new LinearLayout.LayoutParams(0, MP, 0f));
        track.addView(stripRest, new LinearLayout.LayoutParams(0, MP, 100f));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(MP, dp(5));
        tlp.setMargins(0, dp(8), dp(8), 0);
        st.addView(track, tlp);
        st.setOnClickListener(v -> showDownloads());
        st.setVisibility(View.GONE);
        strip = st;
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(MP, WC, Gravity.TOP);
        slp.setMargins(dp(12), dp(6), dp(12), 0);
        content.addView(st, slp);

        // bottom info bar (blocked redirect, hints, "Allow"/"Open" actions)
        barBox = new LinearLayout(this);
        barBox.setOrientation(LinearLayout.HORIZONTAL);
        barBox.setGravity(Gravity.CENTER_VERTICAL);
        barBox.setPadding(dp(16), dp(10), dp(16), dp(10));
        barBox.setBackground(Ui.round(Color.argb(240, 28, 30, 36), dp(22)));
        barBox.setElevation(dp(8));
        barMsg = new TextView(this);
        barMsg.setTextColor(Color.WHITE);
        barMsg.setTextSize(13);
        barBox.addView(barMsg, new LinearLayout.LayoutParams(0, WC, 1f));
        barAct = new TextView(this);
        barAct.setTextColor(Color.rgb(120, 190, 255));
        barAct.setTextSize(14);
        barAct.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        barAct.setPadding(dp(14), dp(4), dp(4), dp(4));
        barBox.addView(barAct);
        barBox.setVisibility(View.GONE);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(MP, WC, Gravity.BOTTOM);
        blp.setMargins(dp(14), 0, dp(14), dp(86));
        content.addView(barBox, blp);
        hideBar = () -> barBox.setVisibility(View.GONE);

        // toast-style pill
        pill = new TextView(this);
        pill.setTextColor(Color.WHITE);
        pill.setTextSize(14.5f);
        pill.setGravity(Gravity.CENTER);
        pill.setMaxWidth(getResources().getDisplayMetrics().widthPixels - dp(40));
        pill.setPadding(dp(20), dp(12), dp(20), dp(12));
        pill.setBackground(Ui.round(Color.argb(242, 28, 30, 36), dp(24)));
        pill.setElevation(dp(12));
        pill.setVisibility(View.GONE);
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(WC, WC,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        plp.setMargins(dp(20), 0, dp(20), dp(92));
        content.addView(pill, plp);
        hidePill = () -> pill.animate().alpha(0f).setDuration(220)
                .withEndAction(() -> pill.setVisibility(View.GONE)).start();

        // ---- bottom floating pill navigation (Home / Back / Downloads / Sound / Menu)
        final SlideNav nav = new SlideNav(this);
        nav.setBackground(Ui.stroked(Color.argb(248, 255, 255, 255), dp(30), Ui.LINE, 1));
        nav.setElevation(dp(10));
        navHomeCell = navItem(nav.row(), Ic.HOME, v -> {
            homeByBack = false;
            showHome(true);
        });
        navWebCell = navItem(nav.row(), Ic.GLOBE, v -> {
            if (web.getUrl() != null && web.getUrl().startsWith("http")) showHome(false);
            else {
                say("Pehle koi site kholo");
                nav.backToRest();
            }
        });
        navDlCell = navItem(nav.row(), Ic.DOWNLOAD, v -> showDownloads());
        navBadge = Ui.label(this, "", 10, Color.WHITE, true);
        navBadge.setGravity(Gravity.CENTER);
        navBadge.setBackground(Ui.oval(Ui.RED));
        navBadge.setVisibility(View.GONE);
        FrameLayout.LayoutParams nbp = new FrameLayout.LayoutParams(dp(17), dp(17), Gravity.TOP | Gravity.END);
        nbp.setMargins(0, dp(10), dp(20), 0);
        navDlCell.addView(navBadge, nbp);
        navItem(nav.row(), Ic.SOUND, v -> showSound());
        navItem(nav.row(), Ic.MENU, v -> showMenu());
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(MP, dp(60), Gravity.BOTTOM);
        nlp.setMargins(dp(18), 0, dp(18), dp(12));
        content.addView(nav, nlp);
        navBox = nav;

        root.addView(content, new LinearLayout.LayoutParams(MP, 0, 1f));
        sheet = new Ui.Sheet(this, rootFrame);
        sheet.setOnAnyHidden(() -> {
            if (navBox instanceof SlideNav) ((SlideNav) navBox).backToRest();
        });
        setContentView(rootFrame);

        // keyboard open -> hide the floating things
        rootFrame.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            int h = rootFrame.getHeight();
            if (h > maxRootH) maxRootH = h;
            boolean kb = maxRootH > 0 && h < maxRootH * 0.8f;
            if (kb != kbOpen) {
                kbOpen = kb;
                updateChrome();
            }
        });

        dc = DownloadCenter.get(this);
        dc.setListener(new DownloadCenter.Listener() {
            @Override
            public void changed() {
                updateStrip();
                updateFab();
                updateNav();
                renderDownloads();
            }

            @Override
            public void finished(DownloadCenter.Task t) {
                onDownloadDone(t);
            }

            @Override
            public void failed(DownloadCenter.Task t) {
                say("Download fail: " + (t.err == null ? "kuch gadbad" : t.err));
            }
        });
        MediaService.controller = cmd -> ui.post(() -> {
            userPaused = "pause".equals(cmd) || ("toggle".equals(cmd) && playingNow);
            if (web != null) {
                web.evaluateJavascript("(function(){var f=window['" + bridgeName + "m'];return f?f('"
                        + cmd + "'):-1})()", null);
            }
        });
        updateNav();
        updateFab();
        updateChrome();
    }

    private void updateChrome() {
        boolean hide = kbOpen || landFs;
        if (navBox != null) navBox.setVisibility(hide ? View.GONE : View.VISIBLE);
        if (fab != null) fab.setVisibility(hide || homeShown || !fabOn ? View.GONE : View.VISIBLE);
    }

    private void updateNav() {
        if (navBox instanceof SlideNav) ((SlideNav) navBox).setRest(homeShown ? 0 : 1);
        if (navBadge != null && dc != null) {
            int n = dc.activeCount();
            navBadge.setText(String.valueOf(n));
            navBadge.setVisibility(n > 0 ? View.VISIBLE : View.GONE);
        }
    }

    private void updateFab() {
        if (fab == null || dc == null) return;
        fab.setState(!mediaItems.isEmpty() || playingNow, mediaItems.size(), dc.overall());
    }

    private static String two(long v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    private static String fmtEta(long sec) {
        if (sec < 0) return "";
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        return h > 0 ? h + ":" + two(m) + ":" + two(s) : m + ":" + two(s);
    }

    private static void setW(View v, float w) {
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) v.getLayoutParams();
        if (lp.weight != w) {
            lp.weight = w;
            v.setLayoutParams(lp);
        }
    }

    private String infoLine(DownloadCenter.Task t) {
        String sz = t.total > 0 ? fmtSize(t.done) + " / " + fmtSize(t.total) : fmtSize(t.done);
        switch (t.state) {
            case DownloadCenter.RUNNING: {
                if (t.note != null) return t.note;
                String s = sz;
                if (t.speed > 0) {
                    s += "  \u2022  " + fmtSize(t.speed) + "/s";
                    if (t.total > t.done) s += "  \u2022  " + fmtEta((t.total - t.done) / Math.max(1, t.speed)) + " left";
                }
                return s;
            }
            case DownloadCenter.QUEUED:
                return "Line mein...";
            case DownloadCenter.PAUSED:
                return "Paused  \u2022  " + sz;
            case DownloadCenter.DONE:
                return "Complete  \u2022  " + fmtSize(Math.max(t.total, t.done));
            case DownloadCenter.FAILED:
                return "Fail: " + (t.err == null ? "" : t.err);
            default:
                return "";
        }
    }

    private void updateStrip() {
        if (strip == null || dc == null) return;
        DownloadCenter.Task pick = null;
        if (stripTask != null && (stripTask.state == DownloadCenter.RUNNING
                || stripTask.state == DownloadCenter.QUEUED || stripTask.state == DownloadCenter.PAUSED)) {
            pick = stripTask;
        } else {
            for (DownloadCenter.Task t : dc.list()) {
                if (t.state == DownloadCenter.RUNNING || t.state == DownloadCenter.QUEUED) {
                    pick = t;
                    break;
                }
            }
        }
        stripShown = pick;
        if (pick == null || landFs || fsView != null) {
            strip.setVisibility(View.GONE);
            return;
        }
        strip.setVisibility(View.VISIBLE);
        stripName.setText(pick.name == null ? "" : pick.name);
        stripInfo.setText(infoLine(pick));
        int pct = pick.total > 0 ? (int) Math.min(100, pick.done * 100 / pick.total) : 0;
        setW(stripFill, pct);
        setW(stripRest, 100 - pct);
        boolean running = pick.state == DownloadCenter.RUNNING || pick.state == DownloadCenter.QUEUED;
        stripPause.setImageDrawable(new Ic(running ? Ic.PAUSE : Ic.PLAY, Color.WHITE));
    }

    // ---------------------------------------------------------------- home page (favourites)

    private void loadHome() {
        homeSites.clear();
        String raw = prefs.getString("home_sites", null);
        if (raw == null) {
            homeSites.add(new String[]{"YouTube", "https://m.youtube.com"});
            return;
        }
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                homeSites.add(new String[]{o.optString("n"), o.optString("u")});
            }
        } catch (Exception ignored) {
        }
    }

    private void saveHome() {
        try {
            JSONArray a = new JSONArray();
            for (String[] s : homeSites) {
                JSONObject o = new JSONObject();
                o.put("n", s[0]);
                o.put("u", s[1]);
                a.put(o);
            }
            prefs.edit().putString("home_sites", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void buildHome() {
        loadHome();
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.WHITE);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(34), dp(18), dp(120));
        TextView title = Ui.label(this, "Nixu Browse", 32, Ui.INK, true);
        TextView sub = Ui.label(this, "Fast. Clean. Ad-free.", 14, Ui.SUB, false);
        sub.setPadding(0, dp(2), 0, dp(6));
        col.addView(title);
        col.addView(sub);
        TextView fav = Ui.section(this, "Favourites");
        fav.setPadding(dp(2), dp(26), 0, dp(10));
        col.addView(fav);
        homeGrid = new LinearLayout(this);
        homeGrid.setOrientation(LinearLayout.VERTICAL);
        col.addView(homeGrid);
        sv.addView(col);
        homeView = sv;
        refreshHome();
    }

    private static final int[] TILE_COLORS = {0xFF0A84FF, 0xFF34C759, 0xFFFF9F0A, 0xFFAF52DE, 0xFFFF375F, 0xFF30B0C7};

    private void refreshHome() {
        homeGrid.removeAllViews();
        int tileW = (getResources().getDisplayMetrics().widthPixels - dp(36)) / 4;
        Ui.Flow flow = new Ui.Flow(this, 0);
        for (int i = 0; i < homeSites.size(); i++) {
            flow.addView(homeTile(i, tileW), new ViewGroup.LayoutParams(tileW, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        flow.addView(plusTile(), new ViewGroup.LayoutParams(tileW, ViewGroup.LayoutParams.WRAP_CONTENT));
        homeGrid.addView(flow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private View tileBox(View inner, String label) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(dp(4), dp(8), dp(4), dp(8));
        t.addView(inner, new LinearLayout.LayoutParams(dp(60), dp(60)));
        TextView l = Ui.label(this, label, 12, Ui.INK, false);
        l.setSingleLine(true);
        l.setEllipsize(TextUtils.TruncateAt.END);
        l.setGravity(Gravity.CENTER);
        l.setPadding(0, dp(6), 0, 0);
        t.addView(l, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        Ui.press(t);
        return t;
    }

    private View homeTile(final int idx, int tileW) {
        final String[] s = homeSites.get(idx);
        boolean yt = hostIs(hostOf(s[1]), "youtube.com", "youtu.be");
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(Ui.round(yt ? 0xFFFF0033 : TILE_COLORS[Math.abs(s[0].hashCode()) % TILE_COLORS.length],
                dp(18)));
        if (yt) {
            badge.addView(Ui.icon(this, Ic.PLAY, Color.WHITE), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        } else {
            TextView lt = Ui.label(this, s[0].isEmpty() ? "?" : s[0].substring(0, 1).toUpperCase(), 26, Color.WHITE, true);
            lt.setGravity(Gravity.CENTER);
            badge.addView(lt, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
        View t = tileBox(badge, s[0]);
        t.setOnClickListener(v -> go(s[1]));
        t.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this).setTitle(s[0]).setItems(new String[]{"Edit", "Hatao"}, (d, which) -> {
                if (which == 0) {
                    editHomeSite(idx);
                } else {
                    homeSites.remove(idx);
                    saveHome();
                    refreshHome();
                }
            }).show();
            return true;
        });
        return t;
    }

    private View plusTile() {
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(Ui.round(Ui.BG, dp(18)));
        badge.addView(Ui.icon(this, Ic.PLUS, Ui.SUB), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        View t = tileBox(badge, "Add");
        t.setOnClickListener(v -> editHomeSite(-1));
        return t;
    }

    private static String normalizeUrl(String in) {
        String s = in == null ? "" : in.trim();
        if (s.isEmpty() || s.contains(" ")) return null;
        if (s.startsWith("http://") || s.startsWith("https://")) return s;
        return s.contains(".") ? "https://" + s : null;
    }

    private void editHomeSite(final int idx) {
        final EditText n = new EditText(this);
        n.setHint("Name (jaise YouTube)");
        final EditText u = new EditText(this);
        u.setHint("Site link (youtube.com)");
        u.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        if (idx >= 0) {
            n.setText(homeSites.get(idx)[0]);
            u.setText(homeSites.get(idx)[1]);
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(8), dp(22), 0);
        box.addView(n);
        box.addView(u);
        new AlertDialog.Builder(this).setTitle(idx >= 0 ? "Favourite edit karo" : "Favourite site jodo")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    String url = normalizeUrl(u.getText().toString());
                    if (url == null) {
                        say("Sahi link daalo (jaise youtube.com)");
                        return;
                    }
                    String nm = n.getText().toString().trim();
                    if (nm.isEmpty()) nm = hostOf(url).replaceFirst("^www\\.", "");
                    if (idx >= 0) homeSites.set(idx, new String[]{nm, url});
                    else homeSites.add(new String[]{nm, url});
                    saveHome();
                    refreshHome();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showHome(boolean on) {
        homeShown = on;
        if (homeView != null) homeView.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) {
            urlBar.setText("");
            urlBar.clearFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        } else if (web != null && web.getUrl() != null) {
            urlBar.setText(web.getUrl());
        }
        updateNav();
        updateChrome();
    }

    private void navBack() {
        if (homeShown) {
            if (web.getUrl() != null) showHome(false);
            return;
        }
        if (web.canGoBack()) web.goBack();
        else {
            homeByBack = true;
            showHome(true);
        }
    }

    // ---------------------------------------------------------------- menu (chips in a bottom sheet)

    private Ui.Flow chipFlow() {
        Ui.Flow f = new Ui.Flow(this, dp(8));
        f.setPadding(dp(16), 0, dp(16), 0);
        return f;
    }

    private void addChip(Ui.Flow f, String label, boolean active, final Runnable r) {
        TextView c = Ui.chip(this, label, active);
        c.setOnClickListener(v -> {
            sheet.hide();
            r.run();
        });
        f.addView(c, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void showMenu() {
        final String cur = web.getUrl();
        final String root = rootHost(hostOf(cur));
        final boolean slow = slowHosts.contains(root);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(22));

        col.addView(Ui.section(this, "Quick"));
        Ui.Flow q = chipFlow();
        addChip(q, speedMode == 0 ? "Speed OFF" : speedMode == 1 ? "Smart speed" : "Turbo", speedMode > 0, () -> {
            speedMode = (speedMode + 1) % 3;
            prefs.edit().putInt("speedMode", speedMode).apply();
            changed(MODE_DONE[speedMode]);
        });
        addChip(q, "Auto-click", autoOn, () -> {
            autoOn = !autoOn;
            prefs.edit().putBoolean("auto", autoOn).apply();
            changed(autoOn ? "Auto-click chalu ho gaya" : "Auto-click band ho gaya");
        });
        addChip(q, "Ad block", adOn, () -> {
            adOn = !adOn;
            prefs.edit().putBoolean("ads", adOn).apply();
            changed(adOn ? "Ad block chalu ho gaya" : "Ad block band ho gaya");
        });
        addChip(q, "Desktop site", desktop, () -> {
            desktop = !desktop;
            applyUa();
            say(desktop ? "Desktop site chalu ho gayi" : "Mobile site wapas aa gayi");
            web.reload();
        });
        addChip(q, manualLand ? "Rotate: Landscape" : "Rotate screen", manualLand, this::toggleRotate);
        addChip(q, "Background play", bgOn, () -> {
            bgOn = !bgOn;
            prefs.edit().putBoolean("bg", bgOn).apply();
            BgWebView.allow = bgOn;
            changed(bgOn ? "Background play chalu (lock screen par bhi chalega)" : "Background play band");
        });
        addChip(q, hallOn ? "Concert hall: ON" : "Concert hall", hallOn, this::toggleHall);
        addChip(q, "Battery fix", false, this::openBatterySettings);
        addChip(q, "Floating download", fabOn, () -> {
            fabOn = !fabOn;
            prefs.edit().putBoolean("fab", fabOn).apply();
            updateChrome();
            say(fabOn ? "Download button wapas aa gaya" : "Download button chhup gaya");
        });
        col.addView(q);

        col.addView(Ui.section(this, "Browse"));
        Ui.Flow b = chipFlow();
        addChip(b, "History (" + histCount() + ")", false, this::showHistory);
        addChip(b, "Back", false, this::navBack);
        addChip(b, "Forward", false, () -> {
            if (web.canGoForward()) web.goForward();
        });
        addChip(b, "Reload", false, () -> web.reload());
        addChip(b, "Copy URL", false, () -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cur != null) cm.setPrimaryClip(ClipData.newPlainText("url", cur));
            say("URL copy ho gaya");
        });
        addChip(b, "Home mein jodo", false, () -> {
            String u = web.getUrl();
            if (u == null || !u.startsWith("http")) {
                say("Pehle koi site kholo");
                return;
            }
            String t = web.getTitle();
            String nm = t == null || t.trim().isEmpty() ? hostOf(u).replaceFirst("^www\\.", "") : t.trim();
            if (nm.length() > 18) nm = nm.substring(0, 18);
            homeSites.add(new String[]{nm, u});
            saveHome();
            refreshHome();
            say("Home mein jod di");
        });
        col.addView(b);

        col.addView(Ui.section(this, "Link tools"));
        Ui.Flow t = chipFlow();
        addChip(t, "Link Radar", false, this::showRadar);
        addChip(t, "Page unlock", false, () -> web.evaluateJavascript("(function(){var f=window['" + bridgeName
                + "u'];return f?f():-1})()", v -> showBar(
                "0".equals(v) ? "Hatane layak overlay nahi mila" : "Overlay hat gaya, page unlock ho gaya", null, null)));
        addChip(t, slow ? "Real-time: ON" : "Real-time: OFF", slow, () -> {
            if (root.isEmpty()) return;
            if (slow) slowHosts.remove(root);
            else slowHosts.add(root);
            saveSlow();
            applyMode();
            say(slow ? "Is site par speed wapas chalu ho gayi" : "Is site par real-time chalu ho gaya");
            web.reload();
        });
        addChip(t, "Site speed " + effectiveRate(root) + "x", false, () -> showSiteSpeed(root));
        addChip(t, "Fresh session", false, () -> {
            freshSession(cur);
            say("Fresh session ho gayi, is site ke cookies saaf");
            web.reload();
        });
        addChip(t, "Link type: " + (linkType == 1 ? "Key" : linkType == 2 ? "File/APK" : "Auto"), linkType != 0, () -> {
            linkType = (linkType + 1) % 3;
            prefs.edit().putInt("linkType", linkType).apply();
            applyMode();
            say(linkType == 1 ? "Link type: Key" : linkType == 2 ? "Link type: File/APK" : "Link type: Auto");
            web.reload();
        });
        addChip(t, "Final link copy", copyFinal, () -> {
            copyFinal = !copyFinal;
            prefs.edit().putBoolean("copyFinal", copyFinal).apply();
            say(copyFinal ? "Final link auto-copy chalu" : "Final link auto-copy band");
        });
        col.addView(t);

        col.addView(Ui.section(this, "Data"));
        Ui.Flow d = chipFlow();
        addChip(d, "Saved keys (" + keyCount() + ")", false, this::showKeys);
        addChip(d, "Links done: " + prefs.getInt("flows", 0), false, () ->
                say("Ab tak " + prefs.getInt("flows", 0) + " links complete ho chuke"));
        addChip(d, "Flow log copy (" + flogSize() + ")", false, this::copyFlowLog);
        addChip(d, "Flow log saaf", false, () -> {
            startRecording();
            say("Flow log saaf ho gaya, ab naya link kholo");
        });
        addChip(d, "Seekhi sites reset", false, () -> {
            slowHosts.clear();
            hostRate.clear();
            saveSlow();
            saveRates();
            applyMode();
            say("Reset ho gaya, sab saaf");
        });
        col.addView(d);
        sheet.show("Menu", col, true, false);
    }

    // ---------------------------------------------------------------- sound boost

    private void applyBoost(boolean persist) {
        if (persist) {
            prefs.edit().putInt("boost", boostPct).putBoolean("lim", limOn).apply();
            applyMode();    // new page loads start with the same boost
        }
        if (web != null) {
            web.evaluateJavascript("(function(){var f=window['" + bridgeName + "b'];return f?f(" + boostPct + ","
                    + limOn + "):-1})()", null);
        }
    }

    private void showSound() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(4), dp(20), dp(24));
        final TextView val = Ui.label(this, boostPct + "%", 38, Ui.ACCENT, true);
        col.addView(val);
        TextView hint = Ui.label(this, "Bluetooth speaker / DJ par awaaz tez karne ke liye. Limiter ON ho to "
                + "awaaz phat'ti nahi, saaf rehti hai. Pehle 200-250% try karo.", 12.5f, Ui.SUB, false);
        hint.setPadding(0, dp(2), 0, dp(14));
        col.addView(hint);
        final SeekBar sb = new SeekBar(this);
        sb.setMax(250);
        sb.setProgress(Math.max(0, Math.min(250, boostPct - 100)));
        sb.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(Ui.ACCENT));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                boostPct = 100 + p;
                val.setText(boostPct + "%");
                if (fromUser) applyBoost(false);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                applyBoost(true);
            }
        });
        col.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        Ui.Flow pre = new Ui.Flow(this, dp(8));
        pre.setPadding(0, dp(14), 0, 0);
        int[] presets = {100, 150, 200, 250, 300, 350};
        for (final int pv : presets) {
            TextView c = Ui.chip(this, pv + "%", pv == boostPct);
            c.setOnClickListener(v -> {
                boostPct = pv;
                sb.setProgress(pv - 100);
                val.setText(pv + "%");
                applyBoost(true);
            });
            pre.addView(c, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        col.addView(pre);
        Ui.Flow more = new Ui.Flow(this, dp(8));
        more.setPadding(0, dp(12), 0, 0);
        final TextView lim = Ui.chip(this, limOn ? "Limiter: ON (clear awaaz)" : "Limiter: OFF", limOn);
        lim.setOnClickListener(v -> {
            limOn = !limOn;
            Ui.styleChip(lim, limOn);
            lim.setText(limOn ? "Limiter: ON (clear awaaz)" : "Limiter: OFF");
            applyBoost(true);
        });
        more.addView(lim, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView mx = Ui.chip(this, "System volume MAX", false);
        mx.setOnClickListener(v -> {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                        AudioManager.FLAG_SHOW_UI);
            }
        });
        more.addView(mx, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(more);
        if (boostSkipped) {
            TextView w = Ui.label(this, "Note: is page ka player doosri site ka hai, uspar boost nahi lag sakta.",
                    12, Ui.RED, false);
            w.setPadding(0, dp(12), 0, 0);
            col.addView(w);
        }
        sheet.show("Sound boost", col, true, false);
    }

    // ---------------------------------------------------------------- media found on the page + download

    private static final java.util.regex.Pattern MEDIA_EXT = java.util.regex.Pattern.compile(
            ".*\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|mp4|webm|mkv|mov|m3u8)$");

    /** Called from the network thread for every request: remembers direct audio / video file URLs. */
    private void sniffMedia(Uri u) {
        String p = u.getPath();
        if (p == null || !MEDIA_EXT.matcher(p.toLowerCase()).matches()) return;
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        if (hostIs(h, "googlevideo.com", "youtube.com", "ytimg.com", "youtu.be") || hostIs(h, AD_HOSTS)) return;
        final String url = u.toString();
        ui.post(() -> addMedia(url));
    }

    private static String kindOf(String url) {
        String p = url;
        int q = p.indexOf('?');
        if (q >= 0) p = p.substring(0, q);
        p = p.toLowerCase();
        if (p.endsWith(".m3u8")) return "hls";
        if (p.matches(".*\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac)$")) return "audio";
        return "video";
    }

    private String niceName(String url) {
        String g = URLUtil.guessFileName(url, null, null);
        int dot = g.lastIndexOf('.');
        String ext = dot >= 0 ? g.substring(dot + 1) : "";
        String base = dot > 0 ? g.substring(0, dot) : g;
        boolean generic = base.length() < 5
                || base.matches("(?i)(videoplayback|index|playlist|master|stream|media|audio|video|file|download|chunk.*|seg.*)")
                || base.matches("[0-9a-fA-F_\\-]{16,}");
        if (generic && web != null) {
            String t = web.getTitle();
            if (t != null && !t.trim().isEmpty()) {
                String c = t.trim().replaceAll("[\\\\/:*?\"<>|]+", " ");
                if (c.length() > 70) c = c.substring(0, 70);
                return c + (ext.isEmpty() ? "" : "." + ext);
            }
        }
        return g;
    }

    private void addMedia(String url) {
        if (mediaItems.containsKey(url)) return;
        if (hostIs(hostOf(web.getUrl()), "youtube.com", "youtu.be")) return;
        mediaItems.put(url, new String[]{kindOf(url), niceName(url)});
        while (mediaItems.size() > 30) {
            String eldest = mediaItems.keySet().iterator().next();
            mediaItems.remove(eldest);
        }
        updateFab();
        if (fab != null) fab.bounce();
    }

    private void startDownload(String url, String name, String mime, boolean audioOnly, String ua) {
        startDownload(url, name, mime, audioOnly, ua, 0);
    }

    private void startDownload(String url, String name, String mime, boolean audioOnly, String ua, int abr) {
        if (flowActive) {
            flowEnded();
            prefs.edit().putInt("flows", prefs.getInt("flows", 0) + 1).apply();
        }
        stripTask = dc.add(url, name, ua != null ? ua : web.getSettings().getUserAgentString(),
                web.getUrl(), mime, audioOnly, abr);
        say(audioOnly ? (abr > 0 ? "Audio (M4A " + abr + "k) download shuru" : "Audio download shuru")
                : "Download shuru");
    }

    private static String tagName(String name, String tag) {
        if (name == null || name.isEmpty()) return "media [" + tag + "]";
        int dot = name.lastIndexOf('.');
        if (dot > 0 && name.length() - dot <= 6) {
            return name.substring(0, dot) + " [" + tag + "]" + name.substring(dot);
        }
        return name + " [" + tag + "]";
    }

    private TextView dlChip(Ui.Flow f, String label, boolean primary, final Runnable r) {
        TextView c = Ui.chip(this, label, primary);
        c.setOnClickListener(v -> {
            sheet.hide();
            r.run();
        });
        f.addView(c, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return c;
    }

    /** HLS master list: fetch every quality (1080p, 720p ...) in the background and add a chip for each. */
    private void loadVariants(final String url, final Ui.Flow vf, final View wait, final String name) {
        final String ua = web.getSettings().getUserAgentString();
        final String ref = web.getUrl();
        new Thread(() -> {
            final List<String[]> vs = DownloadCenter.hlsVariants(url, ua, ref);
            ui.post(() -> {
                vf.removeView(wait);
                for (final String[] v : vs) {
                    dlChip(vf, v[0], false, () -> startDownload(v[1], tagName(name, v[0]), null, false, null));
                }
            });
        }).start();
    }

    private void addMediaCard(LinearLayout col, final String url, final String[] it) {
        final int MP = ViewGroup.LayoutParams.MATCH_PARENT, WC = ViewGroup.LayoutParams.WRAP_CONTENT;
        final String kind = it[0];
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.round(Ui.BG, dp(18)));
        card.setPadding(dp(14), dp(12), dp(14), dp(14));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(Ui.icon(this, "audio".equals(kind) ? Ic.MUSIC : Ic.VIDEO, Ui.INK),
                new LinearLayout.LayoutParams(dp(24), dp(24)));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setPadding(dp(12), 0, dp(4), 0);
        TextView nm = Ui.label(this, it[1], 14.5f, Ui.INK, true);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        TextView sb = Ui.label(this, ("audio".equals(kind) ? "Audio" : "hls".equals(kind) ? "Stream (HLS)"
                : "Video") + "  \u2022  " + hostOf(url), 12, Ui.SUB, false);
        sb.setSingleLine(true);
        sb.setEllipsize(TextUtils.TruncateAt.END);
        txt.addView(nm);
        txt.addView(sb);
        head.addView(txt, new LinearLayout.LayoutParams(0, WC, 1f));
        card.addView(head);

        if (!"audio".equals(kind)) {
            TextView vs = Ui.label(this, "VIDEO  (MP4)", 11, Ui.SUB, true);
            vs.setPadding(0, dp(12), 0, dp(6));
            card.addView(vs);
            final Ui.Flow vf = new Ui.Flow(this, dp(8));
            card.addView(vf, new LinearLayout.LayoutParams(MP, WC));
            if ("hls".equals(kind)) {
                dlChip(vf, "Best", true, () -> startDownload(url, it[1], null, false, null));
                TextView wait = Ui.label(this, "aur qualities dhoondh rahi hai...", 12, Ui.SUB, false);
                wait.setPadding(dp(4), dp(8), 0, 0);
                vf.addView(wait, new ViewGroup.LayoutParams(WC, WC));
                loadVariants(url, vf, wait, it[1]);
            } else {
                dlChip(vf, "Original", true, () -> startDownload(url, it[1], null, false, null));
            }
        }

        TextView as = Ui.label(this, "AUDIO  (M4A / AAC)", 11, Ui.SUB, true);
        as.setPadding(0, dp(12), 0, dp(6));
        card.addView(as);
        Ui.Flow af = new Ui.Flow(this, dp(8));
        card.addView(af, new LinearLayout.LayoutParams(MP, WC));
        if ("audio".equals(kind)) {
            dlChip(af, "Original", true, () -> startDownload(url, it[1], null, true, null));
        } else {
            dlChip(af, "Original audio", false, () -> startDownload(url, it[1], null, true, null));
        }
        final int[] rates = {64, 128, 192, 256, 320};
        for (final int kb : rates) {
            dlChip(af, kb + " kbps", kb == 128 && !"audio".equals(kind) ? true : false,
                    () -> startDownload(url, tagName(it[1], kb + "k"), null, true, null, kb));
        }

        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(MP, WC);
        clp.setMargins(dp(14), dp(6), dp(14), dp(6));
        col.addView(card, clp);
    }

    private void showMediaSheet() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(22));
        if (playingNow) {
            String pt = MediaService.title;
            if (pt == null || pt.trim().isEmpty()) pt = web.getTitle();
            if (pt != null && !pt.trim().isEmpty()) {
                TextView np = Ui.label(this, "\u25B6  Abhi chal raha: " + pt.trim(), 13, Ui.ACCENT, true);
                np.setSingleLine(true);
                np.setEllipsize(TextUtils.TruncateAt.END);
                np.setPadding(dp(20), dp(2), dp(20), dp(8));
                col.addView(np);
            }
        }
        if (mediaItems.isEmpty()) {
            TextView h = Ui.label(this, "Abhi is page par koi seedhi audio / video file nahi mili.\n\n"
                    + "Song ya video play karo, file mil jayegi to ye button neela ho jayega.\n\n"
                    + "Dhyan rahe: YouTube, Spotify, Netflix jaise protected streams download nahi hote.",
                    13.5f, Ui.SUB, false);
            h.setPadding(dp(20), dp(8), dp(20), dp(6));
            col.addView(h);
        } else {
            ArrayList<String> keys = new ArrayList<>(mediaItems.keySet());
            Collections.reverse(keys);
            int shown = 0;
            for (final String url : keys) {
                if (shown++ >= 6) break;
                addMediaCard(col, url, mediaItems.get(url));
            }
        }
        col.addView(Ui.section(this, "Link se download"));
        LinearLayout pr = new LinearLayout(this);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        pr.setGravity(Gravity.CENTER_VERTICAL);
        pr.setPadding(dp(16), 0, dp(16), 0);
        final EditText pe = new EditText(this);
        pe.setSingleLine(true);
        pe.setHint("Direct file / .m3u8 link paste karo");
        pe.setTextSize(14);
        pe.setBackground(Ui.round(Ui.BG, dp(20)));
        pe.setPadding(dp(16), dp(10), dp(16), dp(10));
        pe.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        pr.addView(pe, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView go = Ui.chip(this, "Download", true);
        go.setOnClickListener(v -> {
            String u = normalizeUrl(pe.getText().toString());
            if (u == null) {
                say("Sahi link paste karo");
                return;
            }
            sheet.hide();
            startDownload(u, null, null, false, null);
        });
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        glp.setMargins(dp(8), 0, 0, 0);
        pr.addView(go, glp);
        col.addView(pr);
        sheet.show("Download", col, true, false);
    }

    private void onDownloadDone(DownloadCenter.Task t) {
        String sz = t.total > 0 ? " (" + fmtSize(t.total) + ")" : "";
        String nm = t.name == null ? "" : t.name.toLowerCase();
        final boolean isApk = nm.endsWith(".apk") || "application/vnd.android.package-archive".equals(t.mime);
        if (isApk && t.total > 0 && t.total < 200 * 1024) {
            say("\u26A0 Ye APK bohot chhoti hai" + sz + ", shayad asli file nahi (ad page ho sakta hai)");
            return;
        }
        if (t.outUri == null) {
            say("Download complete ho gaya" + sz);
            return;
        }
        final Uri u = Uri.parse(t.outUri);
        final String mt = t.mime == null ? "*/*" : t.mime;
        showBar((isApk ? "APK" : "File") + " download complete ho gaya" + sz,
                isApk ? "Install" : "Open", () -> openDownloaded(u, mt));
    }

    // ---------------------------------------------------------------- downloads screen

    private DlRow newRow() {
        final DlRow r = new DlRow();
        r.card = new LinearLayout(this);
        r.card.setOrientation(LinearLayout.VERTICAL);
        r.card.setBackground(Ui.round(Ui.BG, dp(18)));
        r.card.setPadding(dp(16), dp(14), dp(16), dp(12));
        r.name = Ui.label(this, "", 14.5f, Ui.INK, true);
        r.name.setSingleLine(true);
        r.name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        r.card.addView(r.name);
        LinearLayout track = new LinearLayout(this);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setBackground(Ui.round(Ui.LINE, dp(3)));
        r.fill = new View(this);
        r.rest = new View(this);
        track.addView(r.fill, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0f));
        track.addView(r.rest, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 100f));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6));
        tl.setMargins(0, dp(10), 0, dp(8));
        r.card.addView(track, tl);
        r.info = Ui.label(this, "", 12.5f, Ui.SUB, false);
        r.info.setSingleLine(true);
        r.info.setEllipsize(TextUtils.TruncateAt.END);
        r.card.addView(r.info);
        LinearLayout br = new LinearLayout(this);
        br.setOrientation(LinearLayout.HORIZONTAL);
        br.setPadding(0, dp(10), 0, 0);
        r.b1 = Ui.chip(this, "Pause", true);
        r.b2 = Ui.chip(this, "Cancel", false);
        r.b3 = Ui.chip(this, "Delete file", false);
        for (TextView b : new TextView[]{r.b1, r.b2, r.b3}) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, dp(8), 0);
            br.addView(b, lp);
        }
        r.card.addView(br);
        return r;
    }

    private void bindRow(DlRow r, final DownloadCenter.Task t) {
        r.name.setText(t.name == null ? "" : t.name);
        int pct = t.state == DownloadCenter.DONE ? 100
                : t.total > 0 ? (int) Math.min(100, t.done * 100 / t.total) : 0;
        setW(r.fill, pct);
        setW(r.rest, 100 - pct);
        int col = t.state == DownloadCenter.DONE ? Ui.GREEN : t.state == DownloadCenter.FAILED ? Ui.RED
                : t.state == DownloadCenter.PAUSED ? 0xFFFF9F0A : Ui.ACCENT;
        r.fill.setBackground(Ui.round(col, dp(3)));
        r.info.setText(infoLine(t));
        boolean active = t.state == DownloadCenter.RUNNING || t.state == DownloadCenter.QUEUED;
        if (active) {
            r.b1.setText("Pause");
            r.b1.setOnClickListener(v -> dc.pause(t));
            r.b2.setText("Cancel");
            r.b2.setOnClickListener(v -> dc.cancel(t));
            r.b3.setVisibility(View.GONE);
        } else if (t.state == DownloadCenter.PAUSED) {
            r.b1.setText("Resume");
            r.b1.setOnClickListener(v -> {
                stripTask = t;
                dc.resume(t);
            });
            r.b2.setText("Cancel");
            r.b2.setOnClickListener(v -> dc.cancel(t));
            r.b3.setVisibility(View.GONE);
        } else if (t.state == DownloadCenter.FAILED) {
            r.b1.setText("Retry");
            r.b1.setOnClickListener(v -> {
                stripTask = t;
                dc.resume(t);
            });
            r.b2.setText("Hatao");
            r.b2.setOnClickListener(v -> dc.remove(t, false));
            r.b3.setVisibility(View.GONE);
        } else {
            r.b1.setText("Open");
            r.b1.setOnClickListener(v -> {
                if (t.outUri != null) openDownloaded(Uri.parse(t.outUri), t.mime == null ? "*/*" : t.mime);
            });
            r.b2.setText("Hatao");
            r.b2.setOnClickListener(v -> dc.remove(t, false));
            r.b3.setVisibility(View.VISIBLE);
            r.b3.setOnClickListener(v -> {
                dc.remove(t, true);
                say("File delete ho gayi");
            });
        }
    }

    private void showDownloads() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(20));
        Ui.Flow top = chipFlow();
        TextView clr = Ui.chip(this, "Finished saaf karo", false);
        clr.setOnClickListener(v -> dc.clearFinished());
        top.addView(clr, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(top);
        dlList = new LinearLayout(this);
        dlList.setOrientation(LinearLayout.VERTICAL);
        dlList.setPadding(dp(14), dp(8), dp(14), 0);
        col.addView(dlList);
        dlRows.clear();
        dlOrder.clear();
        sheet.setOnHidden(() -> {
            dlList = null;
            dlRows.clear();
            dlOrder.clear();
        });
        sheet.show("Downloads", col, true, true);
        renderDownloads();
    }

    private void renderDownloads() {
        if (dlList == null || dc == null) return;
        List<DownloadCenter.Task> ts = dc.list();
        ArrayList<Integer> ids = new ArrayList<>();
        for (DownloadCenter.Task t : ts) ids.add(t.id);
        if (!ids.equals(dlOrder)) {
            dlList.removeAllViews();
            dlRows.clear();
            dlOrder.clear();
            dlOrder.addAll(ids);
            if (ts.isEmpty()) {
                TextView e = Ui.label(this, "Abhi koi download nahi.\nFloating download button se ya kisi file link se shuru karo.",
                        13.5f, Ui.SUB, false);
                e.setPadding(dp(8), dp(16), dp(8), dp(16));
                dlList.addView(e);
            }
            for (DownloadCenter.Task t : ts) {
                DlRow r = newRow();
                dlRows.put(t.id, r);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, 0, dp(10));
                dlList.addView(r.card, lp);
            }
        }
        for (DownloadCenter.Task t : ts) {
            DlRow r = dlRows.get(t.id);
            if (r != null) bindRow(r, t);
        }
    }

    // ---------------------------------------------------------------- app links (Play Store blocked, others ask)

    private static String friendlyApp(String sc, String pkg) {
        String x = ((sc == null ? "" : sc) + " " + (pkg == null ? "" : pkg)).toLowerCase();
        if (x.contains("whatsapp")) return "WhatsApp";
        if (x.contains("telegram") || x.startsWith("tg ")) return "Telegram";
        if (x.contains("instagram")) return "Instagram";
        if (x.contains("facebook") || x.startsWith("fb ")) return "Facebook";
        if (x.contains("twitter")) return "Twitter / X";
        if (x.contains("youtube")) return "YouTube";
        if (x.contains("snssdk") || x.contains("tiktok")) return "TikTok";
        if (x.contains("spotify")) return "Spotify";
        if (x.contains("mailto")) return "Email";
        if (x.startsWith("tel")) return "Phone";
        if (x.startsWith("sms")) return "Messages";
        if (pkg != null && !pkg.isEmpty()) return pkg;
        return sc == null || sc.isEmpty() ? "ek app" : sc;
    }

    private void externalApp(final String url) {
        if (flowActive || url == null) return;
        long now = SystemClock.elapsedRealtime();
        if (intentDlgOpen || (url.equals(lastIntentUrl) && now - lastIntentAt < 4000)) return;
        lastIntentUrl = url;
        lastIntentAt = now;
        Intent in;
        try {
            if (url.startsWith("intent:")) in = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
            else in = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        } catch (Exception e) {
            return;
        }
        String sc = in.getScheme() == null ? "" : in.getScheme().toLowerCase();
        String pkg = in.getPackage();
        String dsc = in.getData() == null || in.getData().getScheme() == null ? "" : in.getData().getScheme().toLowerCase();
        if (sc.equals("market") || dsc.equals("market") || "com.android.vending".equals(pkg)) {
            say("Play Store ka link roka \uD83D\uDEAB");
            return;
        }
        in.addCategory(Intent.CATEGORY_BROWSABLE);
        in.setComponent(null);
        in.setSelector(null);
        final Intent launch = in;
        final String fb = in.getStringExtra("browser_fallback_url");
        final String app = friendlyApp(dsc.isEmpty() ? sc : dsc, pkg);
        intentDlgOpen = true;
        ui.post(() -> new AlertDialog.Builder(this)
                .setTitle("App mein kholna hai?")
                .setMessage("Ye link " + app + " kholna chahta hai.")
                .setPositiveButton("Kholo", (d, w) -> {
                    try {
                        startActivity(launch);
                    } catch (Exception e) {
                        if (fb != null && (fb.startsWith("http://") || fb.startsWith("https://"))) web.loadUrl(fb);
                        else say(app + " installed nahi hai");
                    }
                })
                .setNegativeButton("Nahi", null)
                .setOnDismissListener(d -> intentDlgOpen = false)
                .show());
    }

    // ---------------------------------------------------------------- media state (lock screen / background)

    private void onMediaState(boolean play, String title) {
        playingNow = play;
        if (play) userPaused = false;
        updateFab();
        if (!bgOn) return;
        if (!play && !MediaService.hold) return;
        if (play) {
            MediaService.hold = true;
            MediaService.playing = true;
        } else {
            MediaService.playing = false;
        }
        if (title != null && !title.isEmpty()) MediaService.title = title;
        MediaService.sync(this);
    }

    // ---------------------------------------------------------------- background play (screen lock)

    private boolean fg = true;

    private void jsCall(String fn, String args) {
        if (web == null) return;
        web.evaluateJavascript("(function(){var f=window['" + bridgeName + fn + "'];return f?f(" + args
                + "):-1})()", null);
    }

    private boolean bgActive() {
        return bgOn && MediaService.hold && !userPaused;
    }

    /** Screen locked / app left while media plays: keep the page alive and nudge the player if it pauses itself. */
    private void keepBgAlive() {
        if (web == null || !bgActive()) return;
        try {
            web.onResume();
            web.resumeTimers();
        } catch (Throwable ignored) {
        }
        jsCall("g", "true");
        long[] delays = {400, 1200, 2500, 5000, 9000};
        for (long ms : delays) {
            ui.postDelayed(() -> {
                if (bgActive() && (!fg || screenOff)) jsCall("r", "");
            }, ms);
        }
    }

    private void toggleHall() {
        hallOn = !hallOn;
        if (hallOn) {
            if (boostPct < 300) prefs.edit().putInt("boostBeforeHall", boostPct).apply();
            boostPct = 330;
            limOn = true;
        } else {
            boostPct = prefs.getInt("boostBeforeHall", 100);
            if (boostPct >= 300) boostPct = 100;
        }
        prefs.edit().putBoolean("hall", hallOn).apply();
        applyBoost(true);
        jsCall("h", String.valueOf(hallOn));
        say(hallOn ? "Concert hall ON \uD83C\uDFB6 awaaz 330% + limiter, phat'ti nahi"
                : "Concert hall band, awaaz normal");
    }

    private void openBatterySettings() {
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            say("Nixu Browse ko \"Don't optimize\" / Unrestricted kar do");
        } catch (Throwable t) {
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null && bgActive()) {
            try {
                web.onResume();
                web.resumeTimers();
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        fg = false;
        keepBgAlive();
    }

    @Override
    protected void onResume() {
        super.onResume();
        fg = true;
        if (web != null) {
            try {
                web.onResume();
                web.resumeTimers();
            } catch (Throwable ignored) {
            }
            jsCall("g", "false");
        }
    }

    private void askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !prefs.getBoolean("notifAsked", false)) {
            prefs.edit().putBoolean("notifAsked", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
        }
    }

    // ---------- history ----------

    private void loadHist() {
        if (histLoaded) return;
        histLoaded = true;
        try {
            JSONArray a = new JSONArray(prefs.getString("history", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String u = o.optString("u");
                if (!u.isEmpty()) hist.add(new Hist(o.optString("t"), u, o.optLong("d")));
            }
        } catch (Exception ignored) {
        }
    }

    private void saveHist() {
        try {
            JSONArray a = new JSONArray();
            for (Hist h : hist) {
                JSONObject o = new JSONObject();
                o.put("t", h.title);
                o.put("u", h.url);
                o.put("d", h.time);
                a.put(o);
            }
            prefs.edit().putString("history", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private int histCount() {
        loadHist();
        return hist.size();
    }

    private void addHistory(String url, String title) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        loadHist();
        for (int i = 0; i < hist.size(); i++) {
            if (hist.get(i).url.equals(url)) {
                hist.remove(i);
                break;
            }
        }
        hist.add(0, new Hist(title == null ? "" : title.trim(), url, System.currentTimeMillis()));
        while (hist.size() > 500) hist.remove(hist.size() - 1);
        saveHist();
    }

    private Button histBtn(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(6), dp(8), dp(6), dp(8));
        return b;
    }

    /** History: tap = open, long-press or "Select" = choose items, then Select all / Delete / Sab hatao. */
    private void showHistory() {
        loadHist();
        if (hist.isEmpty()) {
            say("History abhi khaali hai \uD83D\uDCDC");
            return;
        }
        final boolean[] selMode = {false};
        final HashSet<Hist> sel = new HashSet<>();
        final AlertDialog[] dlg = new AlertDialog[1];
        final Runnable[] refresh = new Runnable[1];

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(4), dp(12), 0);

        final Button bSel = histBtn("\u2611 Select");
        final Button bAll = histBtn("Select all");
        final Button bDel = histBtn("\uD83D\uDDD1 Delete");
        final Button bClr = histBtn("\uD83D\uDDD1 Sab hatao");
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        for (Button x : new Button[]{bSel, bAll, bDel, bClr}) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(2), 0, dp(2), dp(4));
            btns.addView(x, lp);
        }
        box.addView(btns);

        final ListView lv = new ListView(this);
        final BaseAdapter ad = new BaseAdapter() {
            @Override
            public int getCount() {
                return hist.size();
            }

            @Override
            public Object getItem(int i) {
                return hist.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View cv, ViewGroup parent) {
                if (cv == null) {
                    LinearLayout row = new LinearLayout(MainActivity.this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(dp(4), dp(8), dp(4), dp(8));
                    CheckBox cb = new CheckBox(MainActivity.this);
                    cb.setFocusable(false);
                    cb.setClickable(false);
                    row.addView(cb, new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    LinearLayout col = new LinearLayout(MainActivity.this);
                    col.setOrientation(LinearLayout.VERTICAL);
                    TextView t1 = new TextView(MainActivity.this);
                    t1.setTextSize(15);
                    t1.setTextColor(Color.BLACK);
                    t1.setSingleLine(true);
                    t1.setEllipsize(TextUtils.TruncateAt.END);
                    TextView t2 = new TextView(MainActivity.this);
                    t2.setTextSize(12);
                    t2.setTextColor(0xFF666666);
                    t2.setSingleLine(true);
                    t2.setEllipsize(TextUtils.TruncateAt.END);
                    col.addView(t1);
                    col.addView(t2);
                    row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    row.setTag(new View[]{cb, t1, t2});
                    cv = row;
                }
                View[] vs = (View[]) cv.getTag();
                Hist it = hist.get(i);
                CheckBox cb2 = (CheckBox) vs[0];
                cb2.setVisibility(selMode[0] ? View.VISIBLE : View.GONE);
                cb2.setChecked(sel.contains(it));
                ((TextView) vs[1]).setText(it.title.isEmpty() ? it.url : it.title);
                CharSequence ago = DateUtils.getRelativeTimeSpanString(
                        it.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS);
                ((TextView) vs[2]).setText(ago + "  \u2022  " + it.url);
                return cv;
            }
        };
        lv.setAdapter(ad);
        int listH = Math.min(dp(420), getResources().getDisplayMetrics().heightPixels * 55 / 100);
        box.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, listH));

        refresh[0] = () -> {
            bSel.setText(selMode[0] ? "\u2716 Cancel" : "\u2611 Select");
            bAll.setVisibility(selMode[0] ? View.VISIBLE : View.GONE);
            bDel.setVisibility(selMode[0] ? View.VISIBLE : View.GONE);
            bClr.setVisibility(selMode[0] ? View.GONE : View.VISIBLE);
            bAll.setText(!hist.isEmpty() && sel.size() == hist.size() ? "Unselect all" : "Select all");
            bDel.setText("\uD83D\uDDD1 Delete (" + sel.size() + ")");
            bDel.setEnabled(!sel.isEmpty());
            if (dlg[0] != null) dlg[0].setTitle("History (" + hist.size() + ")");
            ad.notifyDataSetChanged();
        };

        lv.setOnItemClickListener((parent, view, pos, id) -> {
            if (pos < 0 || pos >= hist.size()) return;
            Hist it = hist.get(pos);
            if (selMode[0]) {
                if (!sel.remove(it)) sel.add(it);
                refresh[0].run();
            } else {
                dlg[0].dismiss();
                go(it.url);
            }
        });
        lv.setOnItemLongClickListener((parent, view, pos, id) -> {
            if (pos >= 0 && pos < hist.size()) {
                selMode[0] = true;
                sel.add(hist.get(pos));
                refresh[0].run();
            }
            return true;
        });
        bSel.setOnClickListener(x -> {
            selMode[0] = !selMode[0];
            sel.clear();
            refresh[0].run();
        });
        bAll.setOnClickListener(x -> {
            boolean all = sel.size() == hist.size();
            sel.clear();
            if (!all) sel.addAll(hist);
            refresh[0].run();
        });
        bDel.setOnClickListener(x -> {
            if (sel.isEmpty()) return;
            int n = sel.size();
            hist.removeAll(sel);
            saveHist();
            sel.clear();
            selMode[0] = false;
            say(n + " history hata di \u2705");
            if (hist.isEmpty()) {
                dlg[0].dismiss();
                return;
            }
            refresh[0].run();
        });
        bClr.setOnClickListener(x -> new AlertDialog.Builder(this)
                .setTitle("Poori history hata dein?")
                .setMessage(hist.size() + " pages ki history hamesha ke liye hat jaayegi.")
                .setPositiveButton("Haan, sab hatao", (d2, w2) -> {
                    hist.clear();
                    saveHist();
                    say("Poori history saaf ho gayi \u2728");
                    dlg[0].dismiss();
                })
                .setNegativeButton("Nahi", null)
                .show());

        dlg[0] = new AlertDialog.Builder(this)
                .setTitle("History (" + hist.size() + ")")
                .setView(box)
                .setNegativeButton("Band karo", null)
                .create();
        dlg[0].show();
        refresh[0].run();
    }

    private void showKeys() {
        final ArrayList<String> keys = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString("keys", "[]"));
            long now = System.currentTimeMillis();
            for (int k = 0; k < arr.length(); k++) {
                JSONObject o = arr.getJSONObject(k);
                keys.add(o.optString("k"));
                CharSequence ago = DateUtils.getRelativeTimeSpanString(o.optLong("t"), now, DateUtils.MINUTE_IN_MILLIS);
                labels.add(o.optString("h") + "  \u2022  " + ago + "\n" + o.optString("k"));
            }
        } catch (Exception ignored) {
        }
        if (keys.isEmpty()) {
            say("Abhi koi key save nahi hui \uD83D\uDD11");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Saved keys (tap = copy)")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("key", keys.get(which)));
                    say("Key copy ho gayi \u2705");
                })
                .setNegativeButton("Sab hatao", (d, w) -> {
                    prefs.edit().remove("keys").apply();
                    say("Saved keys saaf ho gayi \u2728");
                })
                .show();
    }

    private void openDownloaded(Uri uri, String mime) {
        try {
            Intent in = new Intent(Intent.ACTION_VIEW);
            in.setDataAndType(uri, mime);
            in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(in);
        } catch (Exception e) {
            say("Open nahi ho paaya, Downloads mein dekho");
        }
    }

    private static String fmtSize(long b) {
        if (b >= 1073741824L) return String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0);
        if (b >= 1048576L) return String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0);
        return (b / 1024L) + " KB";
    }

    private void freshSession(String url) {
        String host = hostOf(url);
        String root = rootHost(host);
        if (host.isEmpty()) return;
        try {
            CookieManager cm = CookieManager.getInstance();
            for (String u : new String[]{"https://" + host, "https://" + root, "https://www." + root}) {
                String ck = cm.getCookie(u);
                if (ck == null) continue;
                for (String part : ck.split(";")) {
                    String nm = part.trim();
                    int eq = nm.indexOf('=');
                    if (eq <= 0) continue;
                    nm = nm.substring(0, eq);
                    cm.setCookie(u, nm + "=; Max-Age=0; Path=/");
                    cm.setCookie(u, nm + "=; Max-Age=0; Path=/; Domain=" + root);
                    cm.setCookie(u, nm + "=; Max-Age=0; Path=/; Domain=." + root);
                }
            }
            cm.flush();
        } catch (Throwable ignored) {
        }
        try {
            WebStorage ws = WebStorage.getInstance();
            ws.deleteOrigin("https://" + host);
            ws.deleteOrigin("https://" + root);
            ws.deleteOrigin("https://www." + root);
        } catch (Throwable ignored) {
        }
        try {
            web.clearCache(true);
        } catch (Throwable ignored) {
        }
    }


    private void showRadar() {
        web.evaluateJavascript("(function(){var f=window['" + bridgeName + "h'];return f?f():'[]'})()", value -> {
            final ArrayList<String> urls = new ArrayList<>();
            final ArrayList<String> labels = new ArrayList<>();
            try {
                Object o = new JSONTokener(value == null ? "\"[]\"" : value).nextValue();
                JSONArray arr = new JSONArray(o instanceof String ? (String) o : "[]");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject j = arr.getJSONObject(i);
                    String u = j.getString("u");
                    urls.add(u);
                    labels.add((j.optInt("g") == 1 ? "\u2B50 " : "") + hostOf(u) + shortPath(u)
                            + (j.optString("l").isEmpty() ? "" : "  [" + j.optString("l") + "]"));
                }
            } catch (Exception ignored) {
            }
            for (Map.Entry<String, String> e : radar.entrySet()) {
                if (!urls.contains(e.getKey())) {
                    urls.add(0, e.getKey());
                    labels.add(0, "\uD83D\uDD17 " + hostOf(e.getKey()) + shortPath(e.getKey()) + "  [" + e.getValue() + "]");
                }
            }
            if (urls.isEmpty()) {
                showBar("Abhi koi link nahi mila. Thoda ruk kar dobara dekho", null, null);
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Link Radar")
                    .setItems(labels.toArray(new String[0]), (d, which) -> web.loadUrl(urls.get(which)))
                    .setNegativeButton("Copy all", (d, w) -> {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("links", android.text.TextUtils.join("\n", urls)));
                    })
                    .show();
        });
    }

    private static String shortPath(String url) {
        try {
            String p = Uri.parse(url).getPath();
            if (p == null || p.equals("/")) return "";
            return p.length() > 28 ? p.substring(0, 28) + "\u2026" : p;
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- downloads ----------

    private void showDownloadDialog() {
        final String url = videoUrl;
        if (url == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Download")
                .setItems(new String[]{"\uD83C\uDFAC Video", "\uD83C\uDFB5 Audio only"}, (d, which) -> {
                    if (which == 0) downloadVideo(url);
                    else downloadAudio(url);
                })
                .show();
    }

    private String fileNameFor(String url) {
        String name = URLUtil.guessFileName(url, null, null);
        if (name == null || !name.contains(".") || name.endsWith(".bin")) {
            name = "video_" + System.currentTimeMillis() + ".mp4";
        }
        return name;
    }

    private void downloadVideo(String url) {
        try {
            enqueue(url, fileNameFor(url), web.getSettings().getUserAgentString(),
                    CookieManager.getInstance().getCookie(url), web.getUrl());
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    private void enqueue(String url, String name, String ua, String cookie, String ref) {
        flog("DOWNLOAD " + name + " <- " + url);
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (ref != null) r.addRequestHeader("Referer", ref);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            long id = ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
            myDownloads.add(id);
            toast("Download shuru ho gaya \u2B07 " + name);
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    // Audio only: downloads the file, copies out its audio track (no re-encoding) and saves it to Downloads.
    private void downloadAudio(String url) {
        if (url.toLowerCase().matches(".*\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac)(\\?.*)?$")) {
            downloadVideo(url); // already an audio file
            return;
        }
        final String ua = web.getSettings().getUserAgentString();
        final String cookie = CookieManager.getInstance().getCookie(url);
        final String ref = web.getUrl();
        final String baseName = fileNameFor(url).replaceAll("\\.[^.]*$", "");
        toast("Audio ban raha hai, thoda ruko \u23F3");

        new Thread(() -> {
            File tmp = null, out = null;
            try {
                long ts = System.currentTimeMillis();
                tmp = new File(getCacheDir(), "dl_" + ts + ".tmp");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                if (ua != null) c.setRequestProperty("User-Agent", ua);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                if (ref != null) c.setRequestProperty("Referer", ref);
                try (InputStream in = c.getInputStream(); OutputStream fo = new FileOutputStream(tmp)) {
                    copy(in, fo);
                }

                MediaExtractor ex = new MediaExtractor();
                ex.setDataSource(tmp.getAbsolutePath());
                int track = -1;
                MediaFormat fmt = null;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    MediaFormat f = ex.getTrackFormat(i);
                    String m = f.getString(MediaFormat.KEY_MIME);
                    if (m != null && m.startsWith("audio/")) {
                        track = i;
                        fmt = f;
                        break;
                    }
                }
                if (track < 0) throw new Exception("is video mein audio track nahi mila");

                String mime = fmt.getString(MediaFormat.KEY_MIME);
                int muxFmt;
                String ext, outMime;
                if ("audio/mp4a-latm".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4;
                    ext = "m4a";
                    outMime = "audio/mp4";
                } else if ("audio/opus".equals(mime) || "audio/vorbis".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM;
                    ext = "webm";
                    outMime = "audio/webm";
                } else {
                    throw new Exception("audio format (" + mime + ") support nahi hai");
                }

                out = new File(getCacheDir(), "out_" + ts + "." + ext);
                MediaMuxer mux = new MediaMuxer(out.getAbsolutePath(), muxFmt);
                ex.selectTrack(track);
                int outTrack = mux.addTrack(fmt);
                mux.start();
                ByteBuffer buf = ByteBuffer.allocate(1 << 20);
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                while (true) {
                    buf.clear();
                    int n = ex.readSampleData(buf, 0);
                    if (n < 0) break;
                    info.set(0, n, ex.getSampleTime(), ex.getSampleFlags());
                    mux.writeSampleData(outTrack, buf, info);
                    ex.advance();
                }
                mux.stop();
                mux.release();
                ex.release();

                String fileName = baseName + "." + ext;
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, outMime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new Exception("file save nahi ho paayi");
                try (OutputStream os = getContentResolver().openOutputStream(uri);
                     InputStream is = new FileInputStream(out)) {
                    copy(is, os);
                }
                toast("Audio complete ho gaya \uD83C\uDF89 Downloads mein save: " + fileName);
            } catch (Exception e) {
                toast("Audio nahi ban paya: " + e.getMessage());
            } finally {
                if (tmp != null) tmp.delete();
                if (out != null) out.delete();
            }
        }).start();
    }

    private static void copy(InputStream in, OutputStream out) throws java.io.IOException {
        byte[] b = new byte[64 * 1024];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }

    private void toast(String msg) {
        say(msg);
    }

    // ---------- navigation ----------

    private void go(String input) {
        String s = input.trim();
        if (s.isEmpty()) return;
        showHome(false);
        String url;
        if (s.startsWith("http://") || s.startsWith("https://")) {
            url = s;
        } else if (s.contains(".") && !s.contains(" ")) {
            url = "https://" + s;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(s);
        }
        radar.clear();
        lastDecoded = null;
        flowEnded();
        stepCount = 0;
        startRecording();
        flog("START " + url);
        web.loadUrl(url);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (sheet != null && sheet.isShowing()) {
            sheet.hide();
            return;
        }
        if (fsView != null) {
            exitFullscreen();
            return;
        }
        if (landFs) {
            web.evaluateJavascript("(" + rotJs + ")(false)", null);
            applyLandFs(false);
            manualLand = false;
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            return;
        }
        if (homeShown) {
            if (homeByBack || web.getUrl() == null) super.onBackPressed();
            else showHome(false);
            return;
        }
        if (web.canGoBack()) {
            web.goBack();
        } else {
            homeByBack = true;
            showHome(true);
        }
    }

    // ---------- fullscreen video + rotate ----------

    private void immersive(boolean on) {
        View d = getWindow().getDecorView();
        if (on) {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            applyBars();
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        getWindow().setAttributes(getWindow().getAttributes());
    }

    /** Page asked for fullscreen video (YouTube's fullscreen button, or our rotate trigger). */
    private void enterFullscreen(View view, WebChromeClient.CustomViewCallback cb) {
        if (fsView != null) {
            cb.onCustomViewHidden();
            return;
        }
        if (landFs) applyLandFs(false);
        fsView = view;
        fsCb = cb;
        fsBox = new FrameLayout(this);
        fsBox.setBackgroundColor(Color.BLACK);
        fsBox.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ((ViewGroup) getWindow().getDecorView()).addView(fsBox, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        immersive(true);
        // user tapped fullscreen -> landscape. (App is otherwise locked to portrait: no auto-rotate.)
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }

    private void exitFullscreen() {
        if (fsView == null) return;
        ViewGroup decor = (ViewGroup) getWindow().getDecorView();
        if (fsBox != null) {
            fsBox.removeAllViews();
            decor.removeView(fsBox);
        }
        fsBox = null;
        fsView = null;
        immersive(false);
        // leaving fullscreen -> back to portrait (or stay landscape if it was rotated from the menu)
        setRequestedOrientation(manualLand ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        WebChromeClient.CustomViewCallback cb = fsCb;
        fsCb = null;
        if (cb != null) cb.onCustomViewHidden();
    }

    /** Menu -> Rotate screen: portrait <-> landscape by hand. The sensor never rotates the app. */
    private void toggleRotate() {
        manualLand = !manualLand;
        if (manualLand) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            say("Screen landscape ho gayi \uD83D\uDD04 (wapas portrait: menu mein dobara Rotate)");
        } else {
            if (landFs) {
                web.evaluateJavascript("(" + rotJs + ")(false)", null);
                applyLandFs(false);
            }
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            say("Screen portrait ho gayi \uD83D\uDD04");
        }
    }

    /** "Video only" layout: url bar and system bars hidden, page shows just the player. */
    private void applyLandFs(boolean on) {
        landFs = on;
        topBar.setVisibility(on ? View.GONE : View.VISIBLE);
        progress.setVisibility(on ? View.GONE : View.INVISIBLE);
        immersive(on);
        updateChrome();
        updateStrip();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        maxRootH = 0;
        if (fab != null) {
            fab.setTranslationX(0f);
            fab.setTranslationY(0f);
        }
        if (fsView != null) return; // real fullscreen manages itself
        if (c.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // only when the user chose "Rotate screen" in the menu (never from the phone's sensor):
            // if a video is playing, show it fullscreen
            if (!manualLand) return;
            web.evaluateJavascript("(" + rotJs + ")(true)", v -> {
                if (v == null) return;
                if (v.contains("css")) {
                    applyLandFs(true);
                } else if (v.contains("trying")) {
                    // real fullscreen may still be refused by the page -> check again shortly
                    web.postDelayed(() -> {
                        if (fsView != null || landFs) return;
                        web.evaluateJavascript(
                                "!!document.getElementById('__flb_land_css')", r -> {
                                    if ("true".equals(r) && fsView == null) applyLandFs(true);
                                });
                    }, 700);
                }
            });
        } else if (landFs) {
            // back to portrait: normal browser again
            web.evaluateJavascript("(" + rotJs + ")(false)", null);
            applyLandFs(false);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && (fsView != null || landFs)) immersive(true);
    }
}
