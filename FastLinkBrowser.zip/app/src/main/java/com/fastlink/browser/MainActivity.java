package com.fastlink.browser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.Collections;

public class MainActivity extends Activity {

    // Timers run this many times faster (10 = a 10s countdown takes ~1s)
    private static final int FACTOR = 10;

    // Ad / popup network domains that get blocked (sub-resources only, never the page itself)
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "googletagservices.com", "2mdn.net",
            "adnxs.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
            "pubmatic.com", "rubiconproject.com", "openx.net", "amazon-adsystem.com",
            "adsafeprotected.com", "moatads.com", "advertising.com", "adform.net",
            "smartadserver.com", "casalemedia.com", "indexww.com", "teads.tv",
            "mgid.com", "revcontent.com", "adskeeper.com", "adsrvr.org",
            "serving-sys.com", "lijit.com", "sharethrough.com", "yieldmo.com",
            "media.net", "zedo.com", "adition.com",
            "popads.net", "popcash.net", "propellerads.com", "exoclick.com",
            "exosrv.com", "juicyads.com", "adsterra.com", "hilltopads.net",
            "clickadu.com", "adcash.com", "bidvertiser.com", "onclickads.net",
            "a-ads.com", "ad-maven.com", "admaven.com", "monetag.com",
            "profitablecpmrate.com", "effectivegatecpm.com", "highperformanceformat.com",
            "yllix.com", "trafficjunky.net", "tsyndicate.com", "adtng.com"
    };

    // Hides leftover ad boxes (attribute values unquoted on purpose, see script())
    private static final String AD_CSS =
            ".adsbygoogle,ins.adsbygoogle,[id^=google_ads],[id^=div-gpt-ad],"
            + "iframe[src*=doubleclick],iframe[src*=googlesyndication],"
            + ".ad-banner,.ad-slot,[data-ad-slot],"
            + "ytd-ad-slot-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,"
            + "ytd-banner-promo-renderer,ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,"
            + "ytm-promoted-video-renderer,ytm-ad-slot-renderer,.ytp-ad-module,.ytp-ad-overlay-container,"
            + ".video-ads,#masthead-ad,#player-ads{display:none!important}";

    // YouTube: strips ad data from player responses, and if an ad still starts it is
    // muted and jumped to its end / skipped. YouTube changes things often, so this can break.
    private static final String YT_JS =
            "if(/(^|\\.)youtube\\.com$/.test(location.hostname)){"
            + "var clean=function(r){try{if(r&&typeof r==='object'){"
            + "if(r.adPlacements)r.adPlacements=[];"
            + "if(r.playerAds)r.playerAds=false;"
            + "if(r.adSlots)r.adSlots=[];"
            + "if(r.playerResponse&&typeof r.playerResponse==='object'){"
            + "if(r.playerResponse.adPlacements)r.playerResponse.adPlacements=[];"
            + "if(r.playerResponse.playerAds)r.playerResponse.playerAds=false;"
            + "if(r.playerResponse.adSlots)r.playerResponse.adSlots=[];}}}catch(e){}return r;};"
            + "var jp=JSON.parse;JSON.parse=function(){return clean(jp.apply(this,arguments));};"
            + "var rj=Response.prototype.json;"
            + "Response.prototype.json=function(){return rj.apply(this,arguments).then(clean);};"
            + "var muted=false;"
            + "var skip=function(){var p=document.querySelector('.html5-video-player');"
            + "var v=document.querySelector('video');"
            + "if(p&&v&&p.classList.contains('ad-showing')){"
            + "if(!v.muted){v.muted=true;muted=true;}"
            + "if(isFinite(v.duration)&&v.duration>0)v.currentTime=v.duration;"
            + "}else if(muted&&v){v.muted=false;muted=false;}"
            + "var b=document.querySelectorAll('.ytp-ad-skip-button,.ytp-skip-ad-button,"
            + ".ytp-ad-skip-button-modern,.ytp-ad-overlay-close-button');"
            + "for(var i=0;i<b.length;i++)b[i].click();};"
            + "si.call(window,skip,300);}";

    // Auto mode: every 0.5s looks for "Get Link" / "Continue" style buttons and clicks them.
    // Runs only in the top page (not ad iframes) and never on pages with a password field.
    private static final String AUTO_JS =
            "if(window.top===window){"
            + "var re=/^(get link|get the link|get link now|continue|click here to continue|click to continue|"
            + "continue to (the )?(link|website|destination)|go to link|skip ad|skip|proceed|unlock link)$/i;"
            + "var last=new WeakMap(),n=0;"
            + "var vis=function(e){var r=e.getBoundingClientRect();"
            + "return r.width>0&&r.height>0&&getComputedStyle(e).visibility!=='hidden';};"
            + "var tick=function(){var b=document.body;"
            + "if(!b||document.querySelector('input[type=password]'))return;"
            + "if(n++<12)window.scrollTo(0,b.scrollHeight);"
            + "var els=document.querySelectorAll('a,button,input[type=submit],input[type=button],[role=button]');"
            + "for(var i=0;i<els.length;i++){var e=els[i];"
            + "var t=(e.innerText||e.value||'').replace(/\\s+/g,' ').trim();"
            + "if(t.length>30||e.disabled||!re.test(t)||!vis(e))continue;"
            + "var w=Date.now();if(last.has(e)&&w-last.get(e)<4000)continue;"
            + "last.set(e,w);e.click();return;}};"
            + "si.call(window,tick,500);}";

    // Reports a direct (non-blob, non-HLS) video file URL to the app so the download button can show.
    private static final String VIDEO_JS =
            "var lastV='';"
            + "var scan=function(){var v=document.querySelectorAll('video'),u='';"
            + "for(var i=0;i<v.length;i++){var s=v[i].currentSrc||v[i].src||'';"
            + "if(/^https?:/i.test(s)&&!/\\.m3u8(\\?|$)/i.test(s)&&!/(googlevideo|youtube)\\.com/i.test(s)){u=s;break;}}"
            + "if(u!==lastV){lastV=u;try{if(u)FLB.videoFound(u);else FLB.noVideo();}catch(e){}}};"
            + "si.call(window,scan,1500);";

    private WebView web;
    private EditText urlBar;
    private ProgressBar progress;
    private TextView speedBtn, autoBtn, adBtn, dlBtn;
    private SharedPreferences prefs;
    private volatile boolean speedOn, autoOn, adOn;
    private ScriptHandler scriptHandler;
    private boolean docStartSupported;
    private String videoUrl;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("fastlink", MODE_PRIVATE);
        speedOn = prefs.getBoolean("speed", true);
        autoOn = prefs.getBoolean("auto", true);
        adOn = prefs.getBoolean("ads", true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(4), dp(4), dp(4));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setHint("Search or enter URL");
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_GO
                    || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                return true;
            }
            return false;
        });
        bar.addView(urlBar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        speedBtn = toggle("\u26A1", v -> {
            speedOn = !speedOn;
            prefs.edit().putBoolean("speed", speedOn).apply();
            changed(speedOn ? "Fast timer ON" : "Fast timer OFF");
        });
        autoBtn = toggle("\uD83E\uDD16", v -> {
            autoOn = !autoOn;
            prefs.edit().putBoolean("auto", autoOn).apply();
            changed(autoOn ? "Auto-click ON" : "Auto-click OFF");
        });
        adBtn = toggle("\uD83D\uDEE1", v -> {
            adOn = !adOn;
            prefs.edit().putBoolean("ads", adOn).apply();
            changed(adOn ? "Ad block ON" : "Ad block OFF");
        });
        bar.addView(speedBtn);
        bar.addView(autoBtn);
        bar.addView(adBtn);
        root.addView(bar);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        FrameLayout content = new FrameLayout(this);
        web = new WebView(this);
        content.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        dlBtn = new TextView(this);
        dlBtn.setText("\u2B07");
        dlBtn.setTextSize(22);
        dlBtn.setTextColor(Color.WHITE);
        dlBtn.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(0, 150, 60));
        dlBtn.setBackground(circle);
        dlBtn.setElevation(dp(6));
        dlBtn.setVisibility(View.GONE);
        dlBtn.setOnClickListener(v -> showDownloadDialog());
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(dp(54), dp(54),
                Gravity.BOTTOM | Gravity.END);
        dlp.setMargins(0, 0, dp(16), dp(24));
        content.addView(dlBtn, dlp);

        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        web.addJavascriptInterface(new Bridge(), "FLB");
        docStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                // only http/https; blocks intent:// and app-open redirects
                return !("http".equals(sc) || "https".equals(sc));
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (adOn && !r.isForMainFrame() && isAd(r.getUrl())) {
                    return new WebResourceResponse("text/plain", "utf-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                urlBar.setText(url);
                videoUrl = null;
                dlBtn.setVisibility(View.GONE);
                if (!docStartSupported) {
                    v.evaluateJavascript(script(), null);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message m) {
                return false; // popup blocker
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                enqueue(url, URLUtil.guessFileName(url, cd, mime), ua,
                        CookieManager.getInstance().getCookie(url), web.getUrl());
            }
        });

        applyMode();

        Uri data = getIntent() != null ? getIntent().getData() : null;
        if (data != null) {
            web.loadUrl(data.toString());
        } else {
            web.loadUrl("https://www.google.com");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getData() != null) {
            web.loadUrl(intent.getData().toString());
        }
    }

    // ---------- JS bridge (video detection) ----------

    private class Bridge {
        @JavascriptInterface
        public void videoFound(String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            runOnUiThread(() -> {
                videoUrl = url;
                dlBtn.setVisibility(View.VISIBLE);
            });
        }

        @JavascriptInterface
        public void noVideo() {
            runOnUiThread(() -> {
                videoUrl = null;
                dlBtn.setVisibility(View.GONE);
            });
        }
    }

    // ---------- toggles / scripts ----------

    private TextView toggle(String label, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(20);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        t.setOnClickListener(l);
        return t;
    }

    private void changed(String msg) {
        applyMode();
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        web.reload();
    }

    private void applyMode() {
        speedBtn.setAlpha(speedOn ? 1f : 0.3f);
        autoBtn.setAlpha(autoOn ? 1f : 0.3f);
        adBtn.setAlpha(adOn ? 1f : 0.3f);
        if (docStartSupported) {
            if (scriptHandler != null) {
                scriptHandler.remove();
                scriptHandler = null;
            }
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(
                    web, script(), Collections.singleton("*"));
        }
    }

    private String script() {
        StringBuilder sb = new StringBuilder();
        sb.append("(function(){if(window.__ft)return;window.__ft=1;var F=").append(FACTOR).append(";");
        sb.append("var st=window.setTimeout,si=window.setInterval;");
        if (speedOn) {
            // setTimeout/setInterval run FACTOR times faster so countdowns finish sooner
            // (not on YouTube, where it would only make the player misbehave)
            sb.append("if(!/(^|\\.)youtube\\.com$/.test(location.hostname)){")
              .append("window.setTimeout=function(f,d){var a=[].slice.call(arguments,2);")
              .append("return st.apply(window,[f,(d||0)/F].concat(a));};")
              .append("window.setInterval=function(f,d){var a=[].slice.call(arguments,2);")
              .append("return si.apply(window,[f,Math.max((d||0)/F,4)].concat(a));};}");
        }
        if (adOn) {
            sb.append("var sty=document.createElement('style');sty.textContent='").append(AD_CSS).append("';")
              .append("var addCss=function(){(document.head||document.documentElement).appendChild(sty);};")
              .append("if(document.documentElement)addCss();")
              .append("else document.addEventListener('DOMContentLoaded',addCss);");
            sb.append(YT_JS);
        }
        if (autoOn) {
            sb.append(AUTO_JS);
        }
        sb.append(VIDEO_JS);
        sb.append("})();");
        return sb.toString();
    }

    private boolean isAd(Uri u) {
        String h = u.getHost();
        if (h == null) return false;
        h = h.toLowerCase();
        for (String d : AD_HOSTS) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        if (h.equals("youtube.com") || h.endsWith(".youtube.com")) {
            String p = u.getPath();
            if (p != null && (p.startsWith("/pagead/") || p.startsWith("/api/stats/ads")
                    || p.startsWith("/get_midroll_") || p.contains("/ptracking"))) {
                return true;
            }
        }
        return false;
    }

    // ---------- downloads ----------

    private void showDownloadDialog() {
        final String url = videoUrl;
        if (url == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Download")
                .setItems(new String[]{"\uD83C\uDFAC Video", "\uD83C\uDFB5 Audio only"}, (d, which) -> {
                    if (which == 0) downloadVideo(url);
                    else downloadAudio(url);
                })
                .show();
    }

    private String fileNameFor(String url) {
        String name = URLUtil.guessFileName(url, null, null);
        if (name == null || !name.contains(".") || name.endsWith(".bin")) {
            name = "video_" + System.currentTimeMillis() + ".mp4";
        }
        return name;
    }

    private void downloadVideo(String url) {
        try {
            enqueue(url, fileNameFor(url), web.getSettings().getUserAgentString(),
                    CookieManager.getInstance().getCookie(url), web.getUrl());
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    private void enqueue(String url, String name, String ua, String cookie, String ref) {
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (ref != null) r.addRequestHeader("Referer", ref);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
            toast("Download shuru: " + name);
        } catch (Exception e) {
            toast("Download nahi hua: " + e.getMessage());
        }
    }

    // Audio only: downloads the file, copies out its audio track (no re-encoding) and saves it to Downloads.
    private void downloadAudio(String url) {
        if (url.toLowerCase().matches(".*\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac)(\\?.*)?$")) {
            downloadVideo(url); // already an audio file
            return;
        }
        final String ua = web.getSettings().getUserAgentString();
        final String cookie = CookieManager.getInstance().getCookie(url);
        final String ref = web.getUrl();
        final String baseName = fileNameFor(url).replaceAll("\\.[^.]*$", "");
        toast("Audio ban raha hai, thoda wait karo...");

        new Thread(() -> {
            File tmp = null, out = null;
            try {
                long ts = System.currentTimeMillis();
                tmp = new File(getCacheDir(), "dl_" + ts + ".tmp");
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                if (ua != null) c.setRequestProperty("User-Agent", ua);
                if (cookie != null) c.setRequestProperty("Cookie", cookie);
                if (ref != null) c.setRequestProperty("Referer", ref);
                try (InputStream in = c.getInputStream(); OutputStream fo = new FileOutputStream(tmp)) {
                    copy(in, fo);
                }

                MediaExtractor ex = new MediaExtractor();
                ex.setDataSource(tmp.getAbsolutePath());
                int track = -1;
                MediaFormat fmt = null;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    MediaFormat f = ex.getTrackFormat(i);
                    String m = f.getString(MediaFormat.KEY_MIME);
                    if (m != null && m.startsWith("audio/")) {
                        track = i;
                        fmt = f;
                        break;
                    }
                }
                if (track < 0) throw new Exception("is video mein audio track nahi mila");

                String mime = fmt.getString(MediaFormat.KEY_MIME);
                int muxFmt;
                String ext, outMime;
                if ("audio/mp4a-latm".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4;
                    ext = "m4a";
                    outMime = "audio/mp4";
                } else if ("audio/opus".equals(mime) || "audio/vorbis".equals(mime)) {
                    muxFmt = MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM;
                    ext = "webm";
                    outMime = "audio/webm";
                } else {
                    throw new Exception("audio format (" + mime + ") support nahi hai");
                }

                out = new File(getCacheDir(), "out_" + ts + "." + ext);
                MediaMuxer mux = new MediaMuxer(out.getAbsolutePath(), muxFmt);
                ex.selectTrack(track);
                int outTrack = mux.addTrack(fmt);
                mux.start();
                ByteBuffer buf = ByteBuffer.allocate(1 << 20);
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                while (true) {
                    buf.clear();
                    int n = ex.readSampleData(buf, 0);
                    if (n < 0) break;
                    info.set(0, n, ex.getSampleTime(), ex.getSampleFlags());
                    mux.writeSampleData(outTrack, buf, info);
                    ex.advance();
                }
                mux.stop();
                mux.release();
                ex.release();

                String fileName = baseName + "." + ext;
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, outMime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new Exception("file save nahi ho paayi");
                try (OutputStream os = getContentResolver().openOutputStream(uri);
                     InputStream is = new FileInputStream(out)) {
                    copy(is, os);
                }
                toast("Audio Downloads mein save ho gaya: " + fileName);
            } catch (Exception e) {
                toast("Audio nahi ban paya: " + e.getMessage());
            } finally {
                if (tmp != null) tmp.delete();
                if (out != null) out.delete();
            }
        }).start();
    }

    private static void copy(InputStream in, OutputStream out) throws java.io.IOException {
        byte[] b = new byte[64 * 1024];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
    }

    // ---------- navigation ----------

    private void go(String input) {
        String s = input.trim();
        if (s.isEmpty()) return;
        String url;
        if (s.startsWith("http://") || s.startsWith("https://")) {
            url = s;
        } else if (s.contains(".") && !s.contains(" ")) {
            url = "https://" + s;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(s);
        }
        web.loadUrl(url);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
