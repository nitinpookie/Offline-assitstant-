/* FastLink engine. Uses helpers from flb_core.js (setRate, realNow, realSi, call, expose, mask). */
var isTop = (W.top === W);
var HOST = (location.hostname || '').toLowerCase();
function rootOf(h) {
  h = (h || '').toLowerCase();
  var p = h.split('.');
  if (p.length <= 2) return h;
  var l = p[p.length - 1], s = p[p.length - 2];
  if (l.length === 2 && /^(co|com|org|net|gov|ac|edu|nic)$/.test(s)) return p.slice(-3).join('.');
  return p.slice(-2).join('.');
}
var ROOT = rootOf(HOST);
var IS_YT = /(^|\.)youtube\.com$/.test(HOST);
var HR = C.hr || {};
var HRATE = HR[ROOT] || HR[HOST] || 0;
var SLOW = C.slow.indexOf(ROOT) >= 0 || C.slow.indexOf(HOST) >= 0 || HRATE === 1;
var RATE = HRATE > 1 ? HRATE : C.rate;
/* what is this flow for?  0 unknown, 1 key, 2 file / apk  (menu can force it, or it is carried over from the previous hop) */
var KIND = (C.lt === 1 || C.lt === 2) ? C.lt : (C.fk || 0);
var keyDone = false;
function useRate() { return KIND === 1 ? Math.min(RATE, 5) : RATE; }   // key systems check dwell time per checkpoint: stay gentler
function hostIn(h, list) {
  for (var i = 0; i < list.length; i++) { var d = list[i]; if (h === d || h.slice(-d.length - 1) === '.' + d) return true; }
  return false;
}
function isAdHost(h) { return hostIn((h || '').toLowerCase(), C.adh); }
function isSearchUrl(u) {
  return /(^|\.)google\.[a-z.]+$/.test(u.hostname) && /^\/search/.test(u.pathname) ||
    /(^|\.)bing\.com$/.test(u.hostname) && /^\/search/.test(u.pathname) ||
    /(^|\.)duckduckgo\.com$/.test(u.hostname) && /[?&]q=/.test(u.search) ||
    /(^|\.)search\.yahoo\.com$/.test(u.hostname);
}
function norm(s) { return (s || '').replace(/\s+/g, ' ').replace(/^[^a-z0-9]+|[^a-z0-9.]+$/gi, '').trim(); }
function vis(el) {
  if (!el || !el.isConnected) return false;
  var r = el.getBoundingClientRect();
  if (r.width < 8 || r.height < 8) return false;
  var s = getComputedStyle(el);
  return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity) > 0.2 && s.pointerEvents !== 'none';
}

/* ================= 1. ad blocking: cosmetic + YouTube + anti-adblock wall killer ================= */
var YT_CSS = 'ytd-ad-slot-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,ytd-banner-promo-renderer,' +
  'ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,ytm-promoted-video-renderer,ytm-ad-slot-renderer,' +
  '.ytp-ad-module,.ytp-ad-overlay-container,.video-ads,#masthead-ad,#player-ads{display:none!important}';

function addCss(css) {
  var s = document.createElement('style'); s.textContent = css;
  var put = function () { (document.head || document.documentElement).appendChild(s); };
  if (document.documentElement) put(); else document.addEventListener('DOMContentLoaded', put);
}

if (C.ads && IS_YT) {
  addCss(YT_CSS);
  var clean = function (r) {
    try {
      if (r && typeof r === 'object') {
        if (r.adPlacements) r.adPlacements = [];
        if (r.playerAds) r.playerAds = false;
        if (r.adSlots) r.adSlots = [];
        var pr = r.playerResponse;
        if (pr && typeof pr === 'object') {
          if (pr.adPlacements) pr.adPlacements = [];
          if (pr.playerAds) pr.playerAds = false;
          if (pr.adSlots) pr.adSlots = [];
        }
      }
    } catch (e) {}
    return r;
  };
  var jp = JSON.parse;
  JSON.parse = mask(function parse() { return clean(jp.apply(this, arguments)); }, 'parse');
  var rj = Response.prototype.json;
  Response.prototype.json = mask(function json() { return rj.apply(this, arguments).then(clean); }, 'json');
  var muted = false;
  realSi(function () {
    var p = document.querySelector('.html5-video-player'), v = document.querySelector('video');
    if (p && v && p.classList.contains('ad-showing')) {
      if (!v.muted) { v.muted = true; muted = true; }
      if (isFinite(v.duration) && v.duration > 0) v.currentTime = v.duration;
    } else if (muted && v) { v.muted = false; muted = false; }
    var b = document.querySelectorAll('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern,.ytp-ad-overlay-close-button');
    for (var i = 0; i < b.length; i++) b[i].click();
  }, 300);
}

var WALL_RE = /ad[\s-]?block|ad[\s-]?blocker|ads? (are|is|have been) blocked|disable (your )?(ad|ads)|turn off (your )?(ad|ads)|whitelist (us|this site|our site)|pause (your )?ad|ad[\s-]?shield|ads? (keep|keeps) (us|this site) (free|running)|site is free because of ads/i;
var lastUnlock = 0;
function fixedAncestor(el) {
  for (var e = el; e && e !== document.body && e !== document.documentElement; e = e.parentElement) {
    var p = getComputedStyle(e).position;
    if (p === 'fixed' || p === 'sticky' || p === 'absolute') return e;
  }
  return null;
}
function unlockPage() {
  var removed = 0;
  try {
    var b = document.body; if (!b) return 0;
    var txt = b.innerText || '';
    if (txt.length < 400000 && WALL_RE.test(txt)) {
      var all = b.querySelectorAll('div,section,aside,dialog,form,[role=dialog],[role=alertdialog]');
      var lim = Math.min(all.length, 1500);
      for (var i = lim - 1; i >= 0; i--) {                 // innermost boxes first, so we never hide the whole page
        var el = all[i];
        if (!el.isConnected) continue;
        var t = el.textContent || '';
        if (t.length > 2500 || !WALL_RE.test(t)) continue;
        // keep the smallest box that still holds the message, then go up to its fixed backdrop
        var fx = fixedAncestor(el);
        if (fx) {
          var top = fx;
          while (top.parentElement && top.parentElement !== document.body && fixedAncestor(top.parentElement) &&
                 (top.parentElement.textContent || '').length < 3000) top = top.parentElement;
          top.remove(); removed++;
        } else if (t.length < 600 && el.children.length < 12) {
          el.style.setProperty('display', 'none', 'important'); removed++;
        }
      }
    }
    // click-hijack layers: transparent full-screen fixed elements
    var kids = b.children;
    for (var k = 0; k < kids.length; k++) {
      var c = kids[k], cs = getComputedStyle(c);
      if ((cs.position === 'fixed' || cs.position === 'absolute') && !(c.textContent || '').trim() && c.querySelectorAll('img,video,canvas,iframe,input,button').length === 0) {
        var r = c.getBoundingClientRect();
        var transparent = parseFloat(cs.opacity) < 0.1 || /rgba\(\s*0,\s*0,\s*0,\s*0\)|transparent/.test(cs.backgroundColor);
        if (transparent && r.width > innerWidth * 0.8 && r.height > innerHeight * 0.8 && (parseInt(cs.zIndex, 10) || 0) > 100) { c.remove(); removed++; }
      }
    }
    if (removed) {
      [document.documentElement, b].forEach(function (n) {
        n.style.setProperty('overflow', 'auto', 'important');
        n.style.setProperty('position', 'static', 'important');
        n.style.setProperty('filter', 'none', 'important');
        n.style.setProperty('height', 'auto', 'important');
        n.className = (n.className || '').replace(/\b(no-?scroll|modal-open|overflow-hidden|blur(red)?|locked|adblock\S*|is-blurred)\b/gi, '');
      });
      var bl = b.children;
      for (var j = 0; j < bl.length; j++) { var f = getComputedStyle(bl[j]).filter; if (f && f !== 'none' && /blur/.test(f)) bl[j].style.setProperty('filter', 'none', 'important'); }
    }
  } catch (e) {}
  return removed;
}
expose('u', unlockPage);
if (C.ads && isTop && !IS_YT) {
  var wallRuns = 0;
  var wallTimer = realSi(function () {
    if (!document.body) return;
    if (++wallRuns > 30 && wallRuns % 5) return;      // first ~25s fast, then a light watch
    var n = unlockPage();
    if (n) { call('hint', 'Overlay/ad-block wall hat gaya, ye ho gaya \u2705'); }
  }, 800);
  document.addEventListener('DOMContentLoaded', function () {
    try { new MutationObserver(function () { var t = realNow(); if (t - lastUnlock > 400) { lastUnlock = t; unlockPage(); } }).observe(document.body, { childList: true }); } catch (e) {}
  });
}

/* ================= 2. shortener detection + auto engine ================= */
var SHORT_RE = new RegExp('(^|\\.)(' + C.sh.join('|').replace(/\./g, '\\.') + ')$');
var KNOWN_SEL = '#getlink,#get-link,#btn6,#surl,#tp-snp2,#wpsafe-link a,a#wpsafe-link,#wpsafelink-link,a.get-link,.get-link,#link-btn,#linkbutton,#final-btn,#go_d2,#go-link-btn,a#go-link';
var STRONG = /^(get ?link|get the link|get link now|get download link|generate link|create link|unlock link|go to link|go to (the )?(website|destination|download)|click here to (get link|continue|proceed)|continue to (the )?(link|website|destination|download)|proceed to link|click (here )?to (get|generate|unlock|open|view) (the |your )?link|your link is ready|link is ready|(show|view) link|get your link)$/i;
var WEAK = /^(continue|click to continue|continue now|proceed|next|skip ad|skip|skip now|verify|i am human|i'?m human|open link|visit link|next step|proceed to next( step)?|continue to next( step)?)$/i;
var WAIT_RE = /^(please\s*)?wait\b[^a-z]{0,8}\d{0,3}\s*(s|sec|secs|seconds)?\W*$|^(generating|verifying|checking|loading)[\w\s.\u2026]{0,25}$|^wait \d+|^your link (will be|is) (ready|generating)\b[\w\s.]{0,24}$|^(you.ll be |you will be )?redirect(ed|ing)\b[\w\s.]{0,32}$/i;
var AD_ANC = /(^|[\s_-])(ad|ads|adv|advert|advertisement|adsbygoogle|banner|sponsor|sponsored|promo|popunder|interstitial)([\s_-]|$)/i;
var Q = 'a,button,input[type=submit],input[type=button],[role=button],[onclick],.btn,[class*=btn],[id*=btn],' + KNOWN_SEL;

var engaged = false, engagedAt = 0;
function engage() {
  if (engaged) return;
  engaged = true; engagedAt = realNow();
  try { reclass(); } catch (er) {}
  if (C.mode > 0 && !SLOW && !IS_YT) setRate(useRate());
  call('busy', true);
  call('started', (C.mode > 0 && !SLOW && !IS_YT) ? useRate() : 1, KIND);   // app shows "link page pakad liya" in its pill
}
if (C.mode === 2 && !SLOW && !IS_YT) { setRate(useRate()); engaged = true; engagedAt = realNow(); }

function detect() {
  var s = 0;
  if (SHORT_RE.test(HOST)) s += 2;
  if (document.querySelector(KNOWN_SEL)) s++;
  var els = document.querySelectorAll('button,a,span,div,p,h1,h2,h3,input[type=button],input[type=submit]');
  var n = Math.min(els.length, 700), w = 0, c = 0;
  for (var i = 0; i < n && !(w && c); i++) {
    var el = els[i];
    if (el.children.length > 2) continue;
    var t = norm(el.value || el.textContent);
    if (!t || t.length > 40) continue;
    if (!w && WAIT_RE.test(t) && vis(el)) w = 1;
    if (!c && (STRONG.test(t) || WEAK.test(t)) && vis(el)) c = 1;
  }
  return s + w + c >= 2;
}

function isWaiting() {
  var els = document.querySelectorAll('button,a,span,div,p');
  var n = Math.min(els.length, 700);
  for (var i = 0; i < n; i++) {
    var el = els[i];
    if (el.children.length > 1) continue;
    var t = norm(el.textContent);
    if (t && t.length < 40 && WAIT_RE.test(t) && vis(el)) return true;
  }
  var tm = document.querySelector('#timer,#countdown,.timer,.countdown,#timer_text');
  return !!(tm && vis(tm) && /^\d{1,3}\s*(s|sec|seconds)?$/i.test(norm(tm.textContent)) && norm(tm.textContent) !== '0');
}

function adAncestor(el) {
  var e = el;
  for (var i = 0; i < 6 && e && e !== document.body; i++, e = e.parentElement) {
    var s = (e.id || '') + ' ' + (typeof e.className === 'string' ? e.className : '');
    if (AD_ANC.test(s) || e.tagName === 'INS') return true;
  }
  return false;
}

function score(el, waiting) {
  if (el.disabled || el.getAttribute('aria-disabled') === 'true' || /(^|\s)disabled(\s|$)/.test(typeof el.className === 'string' ? el.className : '')) return 0;
  var t = norm(el.value || el.textContent); if (t.length > 40) t = '';
  var strong = STRONG.test(t), weak = WEAK.test(t), known = false;
  try { known = el.matches(KNOWN_SEL); } catch (e) {}
  if (!strong && !weak && !known) return 0;
  if (waiting) return 0;
  if (!vis(el)) return 0;
  if (adAncestor(el)) return 0;
  var base = strong ? 30 : known ? 25 : 10;
  if (el.tagName === 'A' && el.getAttribute('href')) {
    var hr = el.getAttribute('href');
    if (/^javascript:/i.test(hr) || hr.charAt(0) === '#') { /* fine */ }
    else {
      var u; try { u = new URL(hr, location.href); } catch (e) { return 0; }
      if (!/^https?:$/.test(u.protocol)) return 0;
      if (isSearchUrl(u) || isAdHost(u.hostname)) return 0;        // decoy "continue" that jumps to Google / ad
      if (rootOf(u.hostname) !== ROOT && base < 25) return 0;       // weak text + foreign link = suspicious
    }
  }
  if (el.tagName === 'BUTTON' || /btn|button/i.test(typeof el.className === 'string' ? el.className : '')) base += 3;
  return base;
}

function captchaPending() {
  var f = document.querySelector('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="challenges.cloudflare"],.g-recaptcha,.h-captcha,.cf-turnstile');
  if (!f || f.closest('.grecaptcha-badge') || !vis(f)) return false;
  var r = document.querySelector('textarea[name="g-recaptcha-response"],textarea[name="h-captcha-response"],input[name="cf-turnstile-response"]');
  return !(r && r.value && r.value.length > 20);
}

var hinted = {};
function hintOnce(k, msg) { if (!hinted[k]) { hinted[k] = 1; call('hint', msg); } }

var per = new WeakMap(), seenAt = new WeakMap(), taps = 0, lastTapAt = 0, scrolls = 0, readDone = false;
/* real finger swipe (trusted touch events made by the app); falls back to scrollBy if the page did not move */
function humanSwipe(frac) {
  var vv = W.visualViewport, sc = vv ? vv.scale : 1, ox = vv ? vv.offsetLeft : 0, oy = vv ? vv.offsetTop : 0, dpr = W.devicePixelRatio || 1;
  var x = innerWidth * (0.3 + Math.random() * 0.4), y0 = innerHeight * (0.62 + Math.random() * 0.12);
  var y1 = y0 - innerHeight * frac * (0.85 + Math.random() * 0.3);
  if (y1 < innerHeight * 0.08) y1 = innerHeight * 0.08;
  call('swipe', (x - ox) * sc * dpr, (y0 - oy) * sc * dpr, (y1 - oy) * sc * dpr, 260 + Math.round(Math.random() * 260));
  var y = W.scrollY || 0;
  realSt(function () { if ((W.scrollY || 0) === y) { try { W.scrollBy(0, Math.round(innerHeight * frac)); } catch (er) {} } }, 1100);
}
function tapEl(el, tier) {
  try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}
  var r = el.getBoundingClientRect();
  if (r.width < 4 || r.height < 4) return false;
  var cx = r.left + r.width * (0.3 + Math.random() * 0.4), cy = r.top + r.height * (0.3 + Math.random() * 0.4);
  if (cx < 0 || cy < 0 || cx > innerWidth || cy > innerHeight) return false;
  var hit = document.elementFromPoint(cx, cy);
  if (!hit || !(hit === el || el.contains(hit))) {          // something covers it: remove click-hijack layer, retry next tick
    if (hit && fixedAncestor(hit) && !(hit.textContent || '').trim()) { try { fixedAncestor(hit).remove(); } catch (e) {} }
    return false;
  }
  var vv = W.visualViewport, sc = vv ? vv.scale : 1, ox = vv ? vv.offsetLeft : 0, oy = vv ? vv.offsetTop : 0, dpr = W.devicePixelRatio || 1;
  var got = false;
  var h = function (ev) { if (ev.isTrusted) got = true; };
  el.addEventListener('click', h, true);
  try { call('log', 'tap <' + el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + '> "' + ((el.innerText || el.value || '') + '').replace(/\s+/g, ' ').trim().slice(0, 40) + '" tier=' + tier + ' rate=' + rate); } catch (er) {}
  realSt(function () { snap('after-tap'); }, 2200);
  call('tap', (cx - ox) * sc * dpr, (cy - oy) * sc * dpr, tier);
  realSt(function () {
    el.removeEventListener('click', h, true);
    if (!got) { try { el.click(); } catch (e) {} }          // fallback if the native tap did not land
  }, 900);
  return true;
}

function tick() {
  if (!C.auto || !isTop || IS_YT) return;
  if (!engaged || keyDone) return;
  var b = document.body; if (!b) return;
  if (document.querySelector('input[type=password]')) return;
  if (captchaPending()) { hintOnce('cap', 'Captcha solve karo, baaki main kar lunga \uD83E\uDD1D'); return; }
  var t = realNow();
  if (t - lastTapAt < 1300 || taps >= 30) return;
  var waiting = isWaiting();
  var all = document.querySelectorAll(Q), n = Math.min(all.length, 800), best = null, bs = 0;
  for (var i = 0; i < n; i++) {
    var el = all[i];
    if ((per.get(el) || 0) >= 3) continue;
    var sc = score(el, waiting);
    if (sc > bs) { bs = sc; best = el; }
  }
  if (best) {
    // a real person needs a moment to react: wait 0.6-2s after the button first becomes clickable
    var due = seenAt.get(best);
    if (!due) {
      seenAt.set(best, t + 700 + Math.random() * 1200 + Math.random() * 1200);   // triangular reaction time 0.7-3.1s
      if (!readDone && taps === 0) { readDone = true; humanSwipe(0.22); }    // a short "reading" scroll first
      return;
    }
    if (t < due) return;
    if (tapEl(best, bs >= 25 ? 2 : 1)) { per.set(best, (per.get(best) || 0) + 1); taps++; lastTapAt = t; }
    return;
  }
  if (scrolls < 16 && innerHeight + (W.scrollY || 0) < document.documentElement.scrollHeight - 6) {
    scrolls++; humanSwipe(0.7);
  }
  if (t - engagedAt > 30000 && t - lastTapAt > 20000) if (!hinted.stuck) { hinted.stuck = 1; call('stuck'); }
}

if (isTop && !IS_YT) {
  var dTries = 0;
  var detTimer = realSi(function () {
    if (engaged) { clearDet(); return; }
    if (!document.body) return;
    if (++dTries > 130) { clearDet(); return; }
    try { if (detect()) engage(); } catch (e) {}
  }, 700);
  var clearDet = function () { try { W.clearInterval(detTimer); } catch (e) {} };
  realSi(function () { try { tick(); } catch (e) {} }, 500);
}

/* ================= 3. anomaly watcher (server says "too fast"/"bypass") ================= */
var ANOM_RE = /anomal(y|ies)|bypass(ed|ing)? (detected|attempt)|too (fast|quickly)|suspicious (activity|behaviou?r)|unusual (traffic|activity)|bot (detected|activity)|automat(ed|ion) (detected|traffic)|verification failed|please start over|session (expired|timed out)|invalid (request|session|token)|you (are|were) (too fast|blocked)/i;
if (isTop && !IS_YT) {
  var aDone = false;
  realSi(function () {
    if (aDone || !document.body) return;
    if (!(engaged && (C.mode > 0))) return;
    var t = realNow(); if (t - engagedAt < 1500) return;
    var s = document.body.innerText || '';
    if (s.length < 3000 && ANOM_RE.test(s)) { aDone = true; call('anomaly', ROOT); }   // app steps this site's speed down one level and reloads
  }, 1200);

  // keep CSS / Web-Animations progress bars moving at the same virtual speed
  realSi(function () { if (engaged) animBoost(); }, 600);
}

/* ================= 4. Link Radar (on demand, called by the app menu) ================= */
var JUNK = ['facebook.com', 'twitter.com', 'x.com', 'instagram.com', 'linkedin.com', 'pinterest.com', 'whatsapp.com', 'wa.me', 'reddit.com',
  'schema.org', 'w3.org', 'wordpress.org', 'wordpress.com', 'wp.com', 'gravatar.com', 'creativecommons.org', 'googleapis.com', 'gstatic.com',
  'google-analytics.com', 'googletagmanager.com', 'cloudflare.com', 'jsdelivr.net', 'jquery.com', 'bootstrapcdn.com', 'fontawesome.com',
  'recaptcha.net', 'hcaptcha.com', 'youtube.com', 'youtu.be', 'bing.com', 'apple.com', 'blogger.com', 'blogspot.com'];
var GOOD = ['drive.google.com', 'docs.google.com', 'mega.nz', 'mediafire.com', 't.me', 'telegram.me', 'dropbox.com', 'terabox.com', 'github.com', 'play.google.com', 'gofile.io', 'pixeldrain.com', 'workupload.com', '1fichier.com', 'krakenfiles.com', 'send.cm'];
function b64url(s) {
  try { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; var d = atob(s); return /^https?:\/\//i.test(d) ? d : null; } catch (e) { return null; }
}
function harvest() {
  var seen = {}, out = [];
  function add(u, label, src) {
    if (!u || typeof u !== 'string') return;
    u = u.trim(); if (!/^https?:\/\//i.test(u) || u.length > 700 || seen[u]) return;
    var x; try { x = new URL(u); } catch (e) { return; }
    var h = x.hostname.toLowerCase();
    if (rootOf(h) === ROOT || hostIn(h, JUNK) || isAdHost(h) || isSearchUrl(x)) return;
    if (/\.(js|css|png|jpe?g|gif|svg|webp|ico|woff2?|ttf|map)(\?|$)/i.test(x.pathname)) return;
    seen[u] = 1;
    out.push({ u: u, l: (label || '').slice(0, 40), s: src, g: (hostIn(h, GOOD) || /\.apk(\?|$)/i.test(x.pathname)) ? 1 : 0 });
  }
  var as = document.querySelectorAll('a[href]');
  for (var i = 0; i < Math.min(as.length, 600); i++) {
    var a = as[i], href = a.href;
    add(href, norm(a.textContent), 'link');
    try {
      var u = new URL(href);
      u.searchParams.forEach(function (v) {
        if (/^aHR0/.test(v)) add(b64url(v), norm(a.textContent), 'decoded');
        else if (/^https?:\/\//i.test(v)) add(v, norm(a.textContent), 'param');
      });
    } catch (e) {}
  }
  var ins = document.querySelectorAll('input[type=hidden],input[type=text][readonly],textarea[readonly]');
  for (var k = 0; k < Math.min(ins.length, 100); k++) {
    var v = ins[k].value || '';
    if (/^https?:\/\//i.test(v)) add(v, ins[k].name || 'input', 'input');
    else if (/^aHR0/.test(v)) add(b64url(v), ins[k].name || 'input', 'decoded');
  }
  var sc = document.querySelectorAll('script:not([src])');
  for (var m = 0; m < Math.min(sc.length, 40); m++) {
    var tx = (sc[m].textContent || '').slice(0, 120000), mt, re = /aHR0[A-Za-z0-9+\/_=-]{10,400}/g, re2 = /https?:\/\/[^\s"'<>\\)]{8,300}/g;
    while ((mt = re.exec(tx))) add(b64url(mt[0]), 'script', 'decoded');
    while ((mt = re2.exec(tx))) add(mt[0], 'script', 'script');
  }
  out.sort(function (p, q) { return q.g - p.g; });
  return JSON.stringify(out.slice(0, 40));
}
expose('h', harvest);

/* ================= 5. direct video detection (download button in the app) ================= */
var lastV = '';
realSi(function () {
  var v = document.querySelectorAll('video'), u = '';
  for (var i = 0; i < v.length; i++) {
    var s = v[i].currentSrc || v[i].src || '';
    if (/^https?:/i.test(s) && !/\.m3u8(\?|$)/i.test(s) && !/(googlevideo|youtube)\.com/i.test(s)) { u = s; break; }
  }
  if (u !== lastV) { lastV = u; if (u) call('videoFound', u); else call('noVideo'); }
}, 1500);

/* ================= 6. key or file / apk?  (classifier) ================= */
var KEY_URL = /(^|[\/._?=&-])(get-?key|key-?system|free-?key|keysystem|getkey|keys?|license|activation)([\/._?=&-]|$)/i;
var KEY_STRONG = /(get ?(your |a |the )?key|key ?system|free ?key|generate (a |your )?key|your key|license key|access key|activation key|checkpoint)/i;
var FILE_URL = /\.(apk|zip|rar|7z|obb|mp4|mkv|pdf|exe)(\?|#|$)|[\/._?=&-](apk|mod|download|obb)([\/._?=&-]|$)/i;
var FILE_TXT = /(\bapk\b|mod ?apk|download (apk|file|link)|latest version|installation (guide|steps)|\.apk|\bobb\b)/i;
function origin() {
  var o = '';
  try { var b = B(); if (b && b.origin) o = String(b.origin() || ''); } catch (er) {}
  return o;
}
function classify() {
  if (C.lt === 1 || C.lt === 2) return C.lt;
  var k = 0, f = 0, u = location.pathname + location.search, ou = '';
  try { var ob = new URL(origin()); ou = ob.pathname + ob.search; } catch (er) {}
  if (KEY_URL.test(u)) k += 3;
  if (FILE_URL.test(u)) f += 3;
  if (ou) { if (KEY_URL.test(ou)) k += 3; if (FILE_URL.test(ou)) f += 3; }
  var t = document.title || '', tx = '';
  try { tx = ((document.body && document.body.innerText) || '').slice(0, 3000); } catch (er) {}
  if (KEY_STRONG.test(t) || KEY_STRONG.test(tx)) k += 3;
  if (FILE_TXT.test(t) || FILE_TXT.test(tx)) f += 2;
  if (k >= 3 && k > f) return 1;
  if (f >= 3 && f > k) return 2;
  return 0;
}
function reclass() {
  if (C.lt) return;
  var k = classify();
  if (k && k !== KIND) {
    KIND = k;
    if (KIND === 1 && engaged && C.mode > 0 && !SLOW && rate > 5) setRate(5);
    call('kind', KIND);
  }
}
if (isTop && !IS_YT) realSi(function () { try { reclass(); } catch (er) {} }, 1500);

/* ================= 7. KEY mode: find the key, copy + save it, stop clicking ================= */
var KEY_LBL = /(?:your|the|free|new|generated)?\s*(?:license |access |activation )?key\s*(?:is|:|=|->|\u2192)\s*[:\-]?\s*["'`]?([A-Za-z0-9][A-Za-z0-9_\-\.]{7,90})/i;
function keyLike(v) {
  v = (v || '').trim();
  if (v.length < 8 || v.length > 100 || /\s/.test(v) || /^https?:/i.test(v)) return false;
  if (!/[0-9]/.test(v) && !/[-_]/.test(v) && !/^[A-Z]+$/.test(v)) return false;    // plain lowercase words are not keys
  if (/^(enter|copy|click|verify|continue|checkpoint|loading|generating|expires?|valid)/i.test(v)) return false;
  return true;
}
function findKey(txt) {
  var els = document.querySelectorAll('input,textarea,code,pre,kbd,samp,[id*=key i],[class*=key i],[data-key]');
  for (var i = 0; i < Math.min(els.length, 250); i++) {
    var el = els[i], v;
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      if (!(el.readOnly || el.disabled) || /^(password|email|search|tel|number|hidden)$/.test(el.type)) continue;   // editable boxes are where you ENTER a key
      v = el.value;
    } else {
      if (el.children.length > 2) continue;
      v = el.textContent;
    }
    if (!vis(el)) continue;
    if (keyLike(v)) return v.trim();
  }
  var m = KEY_LBL.exec(txt);
  if (m) { var kv = m[1].replace(/[.\-_]+$/, ''); if (keyLike(kv)) return kv; }
  return null;
}
var keyCand = '';
realSi(function () {
  if (keyDone || !isTop || IS_YT || !document.body || !(C.auto)) return;
  if (!(KIND === 1 || (engaged && KIND === 0))) return;
  var txt = (document.body.innerText || '').slice(0, 20000);
  if (!/\bkey\b/i.test(txt) || isWaiting()) { keyCand = ''; return; }
  var k = null; try { k = findKey(txt); } catch (er) {}
  if (!k) { keyCand = ''; return; }
  if (k !== keyCand) { keyCand = k; return; }           // must be seen twice in a row
  keyDone = true;
  var info = '', mm = /(?:valid|expires?|expiry)[^0-9]{0,30}(\d{1,3})\s*(hours?|hrs?|minutes?|mins?|days?)/i.exec(txt);
  if (mm) info = mm[1] + ' ' + mm[2];
  call('key', k, ROOT, info);
}, 1200);

var CP_RE = /(?:checkpoint|step|stage)\s*#?\s*(\d{1,2})\s*(?:of|\/|out of)\s*(\d{1,2})/i, lastCp = '';
realSi(function () {
  if (!isTop || IS_YT || !document.body || !(KIND === 1 || engaged)) return;
  var m = CP_RE.exec((document.body.innerText || '').slice(0, 6000));
  if (m && m[0] !== lastCp && +m[1] <= +m[2] && +m[2] > 1) { lastCp = m[0]; call('cp', +m[1], +m[2]); }
}, 2000);

/* ================= 8. FILE / APK mode: press the real download button on the usual file hosts ================= */
var FILE_BTN = [
  ['mediafire.com', '#downloadButton'],
  ['drive.google.com', '#uc-download-link'],
  ['drive.usercontent.google.com', '#uc-download-link,form#download-form input[type=submit]']
];
var fbTries = 0;
if (isTop && !IS_YT) {
  realSi(function () {
    if (!C.auto || KIND === 1 || fbTries >= 4 || !document.body) return;
    if (realNow() - lastTapAt < 1500) return;
    for (var i = 0; i < FILE_BTN.length; i++) {
      if (!hostIn(HOST, [FILE_BTN[i][0]])) continue;
      var el = document.querySelector(FILE_BTN[i][1]);
      if (el && vis(el) && !el.disabled && tapEl(el, 1)) { fbTries++; taps++; lastTapAt = realNow(); }
      return;
    }
  }, 1300);
}

/* ================= 9. flow recorder: what does every step page look like? (menu -> Flow log copy) ================= */
function recOn() { try { var b = B(); return !!(b && b.recOn && b.recOn()); } catch (er) { return false; } }
function snap(tag) {
  if (!isTop || IS_YT || !document.body || !recOn()) return;
  var els = document.querySelectorAll('a,button,input[type=button],input[type=submit],[role=button],[onclick]'), out = [], seen = {};
  for (var i = 0; i < els.length && out.length < 10; i++) {
    var el = els[i];
    if (!vis(el)) continue;
    var t = ((el.innerText || el.value || '') + '').replace(/\s+/g, ' ').trim().slice(0, 40);
    if (!t || seen[t]) continue;
    seen[t] = 1;
    out.push(t + (el.disabled ? '(off)' : ''));
  }
  var tx = ((document.body.innerText || '') + '').replace(/\s+/g, ' ').trim().slice(0, 240);
  call('log', tag + ' ' + location.host + location.pathname.slice(0, 40) + ' | ' + (document.title || '').slice(0, 50) +
    ' | rate=' + rate + ' wait=' + (isWaiting() ? 1 : 0) + ' kind=' + KIND + ' eng=' + (engaged ? 1 : 0) +
    ' | text: ' + tx + ' | btn: ' + out.join(' / '));
}
if (isTop && !IS_YT) {
  realSt(function () { snap('page+3s'); }, 3000);
  realSt(function () { snap('page+10s'); }, 10000);
  realSt(function () { snap('page+25s'); }, 25000);
  try { W.addEventListener('error', function (ev) { if (recOn()) call('log', 'JSERR ' + String(ev.message).slice(0, 120)); }, true); } catch (er) {}
}
