/* FastLink core: coherent virtual clock + native-looking timers + bridge helper.
   Runs inside an IIFE where C (config) already exists. */
var W = window;
var NAT = {
  st: W.setTimeout, si: W.setInterval, ct: W.clearTimeout, ci: W.clearInterval,
  dn: W.Date.now.bind(W.Date), pn: W.performance.now.bind(W.performance)
};

/* ---- make patched functions look native ---- */
var fakeStr = new WeakMap();
var origTS = Function.prototype.toString;
var newTS = function toString() {
  var s = fakeStr.get(this);
  return s !== undefined ? s : origTS.call(this);
};
fakeStr.set(newTS, 'function toString() { [native code] }');
try {
  Object.defineProperty(Function.prototype, 'toString', { value: newTS, writable: true, configurable: true, enumerable: false });
} catch (e) {}
function mask(fn, name) {
  fakeStr.set(fn, 'function ' + name + '() { [native code] }');
  try { Object.defineProperty(fn, 'name', { value: name, configurable: true }); } catch (e) {}
  return fn;
}

/* ---- virtual clock (Date, performance.now and timers all move together) ---- */
var rate = 1;
var rP = NAT.pn(), vP = rP;
var rD = NAT.dn(), vD = rD;
function vperf() { return vP + (NAT.pn() - rP) * rate; }
function vdate() { return vD + (NAT.dn() - rD) * rate; }
var dateNow = mask(function now() { return Math.floor(vdate()); }, 'now');
var ND = W.Date;
var PD = new Proxy(ND, {
  construct: function (t, args, nt) {
    if (args.length === 0) return Reflect.construct(t, [Math.floor(vdate())], nt);
    return Reflect.construct(t, args, nt);
  },
  apply: function () { return new ND(Math.floor(vdate())).toString(); },
  get: function (t, p) { return p === 'now' ? dateNow : Reflect.get(t, p, t); }
});
try { Object.defineProperty(ND.prototype, 'constructor', { value: PD, writable: true, configurable: true, enumerable: false }); } catch (e) {}
try { W.Date = PD; } catch (e) {}
try {
  var PP = W.Performance && W.Performance.prototype;
  if (PP && PP.now) {
    Object.defineProperty(PP, 'now', { value: mask(function now() { return vperf(); }, 'now'), writable: true, configurable: true, enumerable: true });
  }
} catch (e) {}

var T = Object.create(null), seq = 0, IDB = 1000000000;
function arm(e) {
  var w = (e.due - vperf()) / rate;
  if (!(w > 0)) w = 0;
  if (e.rep && w < 4) w = 4;
  e.h = NAT.st.call(W, function () { fire(e); }, w);
}
function fire(e) {
  if (!T[e.id]) return;
  if (e.rep) { e.due = vperf() + e.d; arm(e); } else { delete T[e.id]; }
  e.f.apply(W, e.a);
}
function mk(rep) {
  return function (f, d) {
    if (typeof f !== 'function') return (rep ? NAT.si : NAT.st).apply(W, arguments);
    d = +d || 0; if (d < 0) d = 0;
    var e = { id: IDB + (++seq), f: f, d: d, rep: rep, due: vperf() + d, a: Array.prototype.slice.call(arguments, 2), h: 0 };
    T[e.id] = e; arm(e); return e.id;
  };
}
function clr(native) {
  return function (id) {
    var e = T[id];
    if (e) { NAT.ct.call(W, e.h); delete T[id]; } else { native.call(W, id); }
  };
}
W.setTimeout = mask(mk(false), 'setTimeout');
W.setInterval = mask(mk(true), 'setInterval');
W.clearTimeout = mask(clr(NAT.ct), 'clearTimeout');
W.clearInterval = mask(clr(NAT.ci), 'clearInterval');

function setRate(r) {
  if (r === rate) return;
  vP = vperf(); rP = NAT.pn(); vD = vdate(); rD = NAT.dn();
  rate = r;
  for (var id in T) { var e = T[id]; NAT.ct.call(W, e.h); arm(e); }
}
function realNow() { return NAT.pn(); }
function realSt(f, d) { return NAT.st.call(W, f, d); }
function realSi(f, d) { return NAT.si.call(W, f, d); }

/* ---- look like Chrome, not like an embedded WebView ---- */
try {
  var uad = navigator.userAgentData;
  if (uad && uad.brands) {
    var br = uad.brands.map(function (b) { return { brand: /webview/i.test(b.brand) ? 'Google Chrome' : b.brand, version: b.version }; });
    Object.defineProperty(Object.getPrototypeOf(uad), 'brands', { get: mask(function brands() { return br; }, 'brands'), configurable: true });
  }
} catch (e) {}

/* ---- bridge to the app (name is random per launch and removed from window) ---- */
var N = C.n, Bobj = null;
function B() {
  if (!Bobj) { var o = W[N]; if (o) { Bobj = o; try { delete W[N]; } catch (e) {} } }
  return Bobj;
}
function call(m) {
  var b = B(); if (!b) return;
  try { b[m].apply(b, Array.prototype.slice.call(arguments, 1)); } catch (e) {}
}
function expose(suffix, fn) {
  try { Object.defineProperty(W, N + suffix, { value: fn, enumerable: false, configurable: true }); } catch (e) {}
}
