/* FastLink core: coherent virtual clock + native-looking timers + bridge helper.
   Runs inside an IIFE where C (config) already exists. */
var W = window;
var NAT = {
  st: W.setTimeout, si: W.setInterval, ct: W.clearTimeout, ci: W.clearInterval,
  dn: W.Date.now.bind(W.Date), pn: W.performance.now.bind(W.performance)
};

/* ---- make patched functions look native ---- */
var fakeStr = new WeakMap();
var origTS = Function.prototype.toString;
var newTS = function toString() {
  var s = fakeStr.get(this);
  return s !== undefined ? s : origTS.call(this);
};
fakeStr.set(newTS, 'function toString() { [native code] }');
try {
  Object.defineProperty(Function.prototype, 'toString', { value: newTS, writable: true, configurable: true, enumerable: false });
} catch (e) {}
function mask(fn, name, shown) {
  fakeStr.set(fn, 'function ' + (shown || name) + '() { [native code] }');
  try { Object.defineProperty(fn, 'name', { value: name, configurable: true }); } catch (e) {}
  return fn;
}

/* ---- virtual clock (Date, performance.now and timers all move together) ---- */
var rate = 1;
var STAT = { st: 0, si: 0, raf: 0, wk: 0 };   // how the page counts time (shown in the flow log)
var rP = NAT.pn(), vP = rP;
var rD = NAT.dn(), vD = rD;
function vperf() { return vP + (NAT.pn() - rP) * rate; }
function vdate() { return vD + (NAT.dn() - rD) * rate; }
var dateNow = mask(function now() { return Math.floor(vdate()); }, 'now');
var ND = W.Date;
var PD = new Proxy(ND, {
  construct: function (t, args, nt) {
    if (args.length === 0) return Reflect.construct(t, [Math.floor(vdate())], nt);
    return Reflect.construct(t, args, nt);
  },
  apply: function () { return new ND(Math.floor(vdate())).toString(); },
  get: function (t, p) { return p === 'now' ? dateNow : Reflect.get(t, p, t); }
});
try { Object.defineProperty(ND.prototype, 'constructor', { value: PD, writable: true, configurable: true, enumerable: false }); } catch (e) {}
try { W.Date = PD; } catch (e) {}
try {
  var PP = W.Performance && W.Performance.prototype;
  if (PP && PP.now) {
    Object.defineProperty(PP, 'now', { value: mask(function now() { return vperf(); }, 'now'), writable: true, configurable: true, enumerable: true });
  }
} catch (e) {}

var T = Object.create(null), seq = 0, IDB = 1000000000;
function arm(e) {
  var w = (e.due - vperf()) / rate;
  if (!(w > 0)) w = 0;
  if (e.rep && w < 4) w = 4;
  e.h = NAT.st.call(W, function () { fire(e); }, w);
}
function fire(e) {
  if (!T[e.id]) return;
  if (e.rep) { e.due = vperf() + e.d; arm(e); } else { delete T[e.id]; }
  e.f.apply(W, e.a);
}
function mk(rep) {
  return function (f, d) {
    if (typeof f !== 'function') return (rep ? NAT.si : NAT.st).apply(W, arguments);
    if (rep) STAT.si++; else STAT.st++;
    d = +d || 0; if (d < 0) d = 0;
    var e = { id: IDB + (++seq), f: f, d: d, rep: rep, due: vperf() + d, a: Array.prototype.slice.call(arguments, 2), h: 0 };
    T[e.id] = e; arm(e); return e.id;
  };
}
function clr(native) {
  return function (id) {
    var e = T[id];
    if (e) { NAT.ct.call(W, e.h); delete T[id]; } else { native.call(W, id); }
  };
}
W.setTimeout = mask(mk(false), 'setTimeout');
W.setInterval = mask(mk(true), 'setInterval');
W.clearTimeout = mask(clr(NAT.ct), 'clearTimeout');
W.clearInterval = mask(clr(NAT.ci), 'clearInterval');

function setRate(r) {
  if (r === rate) return;
  vP = vperf(); rP = NAT.pn(); vD = vdate(); rD = NAT.dn();
  rate = r;
  for (var id in T) { var e = T[id]; NAT.ct.call(W, e.h); arm(e); }
}
/* ---- v3: keep EVERY clock source consistent with the virtual clock (a mismatch is how sites notice) ---- */
// event.timeStamp must live on the same timeline as performance.now()
try {
  var tsd = Object.getOwnPropertyDescriptor(W.Event.prototype, 'timeStamp');
  if (tsd && tsd.get) {
    var otg = tsd.get;
    Object.defineProperty(W.Event.prototype, 'timeStamp', {
      get: mask(function () { return vP + (otg.call(this) - rP) * rate; }, 'get timeStamp'),
      set: tsd.set, configurable: true, enumerable: true
    });
  }
} catch (e) {}
// requestAnimationFrame timestamp + document.timeline
try {
  var nraf = W.requestAnimationFrame;
  W.requestAnimationFrame = mask(function requestAnimationFrame(cb) {
    if (typeof cb !== 'function') return nraf.call(W, cb);
    STAT.raf++;
    return nraf.call(W, function () { return cb.call(W, vperf()); });
  }, 'requestAnimationFrame');
} catch (e) {}
try {
  var TLP = W.AnimationTimeline && W.AnimationTimeline.prototype;
  var ctd = TLP && Object.getOwnPropertyDescriptor(TLP, 'currentTime');
  if (ctd && ctd.get) {
    var oct = ctd.get;
    Object.defineProperty(TLP, 'currentTime', {
      get: mask(function () { var v = oct.call(this); return v === null ? v : vP + (v - rP) * rate; }, 'get currentTime'),
      set: ctd.set, configurable: true, enumerable: true
    });
  }
} catch (e) {}
// CSS / Web-Animations based progress bars and countdowns
function animBoost() {
  if (rate <= 1) return;
  try {
    var as = document.getAnimations ? document.getAnimations() : [];
    for (var i = 0; i < as.length && i < 200; i++) {
      var a = as[i], it = 1;
      try { it = a.effect.getComputedTiming().iterations; } catch (e) {}
      if (it === Infinity) continue;
      if (a.playbackRate !== rate) a.playbackRate = rate;
    }
  } catch (e) {}
}
// page always looks visible + focused (timers that pause when the tab is hidden keep running)
if (C.mode > 0) {
  try {
    var DP = W.Document.prototype;
    Object.defineProperty(DP, 'hidden', { get: mask(function () { return false; }, 'get hidden'), configurable: true, enumerable: true });
    Object.defineProperty(DP, 'visibilityState', { get: mask(function () { return 'visible'; }, 'get visibilityState'), configurable: true, enumerable: true });
    DP.hasFocus = mask(function hasFocus() { return true; }, 'hasFocus');
    var stop = function (ev) { if (ev.target === W || ev.target === document) ev.stopImmediatePropagation(); };
    ['visibilitychange', 'webkitvisibilitychange'].forEach(function (n) { document.addEventListener(n, stop, true); W.addEventListener(n, stop, true); });
    ['blur', 'pagehide', 'freeze'].forEach(function (n) { W.addEventListener(n, stop, true); });
  } catch (e) {}
}
// a normal Chrome page has window.chrome (WebView does not)
try {
  if (!W.chrome) {
    Object.defineProperty(W, 'chrome', { value: {
      loadTimes: mask(function loadTimes() { return {}; }, 'loadTimes'),
      csi: mask(function csi() { return {}; }, 'csi')
    }, writable: true, configurable: true, enumerable: true });
  }
} catch (e) {}

function realNow() { return NAT.pn(); }
function realSt(f, d) { return NAT.st.call(W, f, d); }
function realSi(f, d) { return NAT.si.call(W, f, d); }

/* ---- look like Chrome, not like an embedded WebView ---- */
try {
  var uad = navigator.userAgentData;
  if (uad && uad.brands) {
    var br = uad.brands.map(function (b) { return { brand: /webview/i.test(b.brand) ? 'Google Chrome' : b.brand, version: b.version }; });
    Object.defineProperty(Object.getPrototypeOf(uad), 'brands', { get: mask(function () { return br; }, 'get brands'), configurable: true });
  }
  if (uad && uad.getHighEntropyValues) {
    var UAP = Object.getPrototypeOf(uad), oge = UAP.getHighEntropyValues;
    UAP.getHighEntropyValues = mask(function getHighEntropyValues(h) {
      return oge.call(this, h).then(function (r) {
        try {
          ['brands', 'fullVersionList'].forEach(function (k) {
            if (r && r[k]) r[k] = r[k].map(function (b) { return { brand: /webview/i.test(b.brand) ? 'Google Chrome' : b.brand, version: b.version }; });
          });
        } catch (e) {}
        return r;
      });
    }, 'getHighEntropyValues');
  }
} catch (e) {}

/* ---- bridge to the app (name is random per launch and removed from window) ---- */
var N = C.n, Bobj = null;
function B() {
  if (!Bobj) { var o = W[N]; if (o) { Bobj = o; try { delete W[N]; } catch (e) {} } }
  return Bobj;
}
function call(m) {
  var b = B(); if (!b) return;
  try { b[m].apply(b, Array.prototype.slice.call(arguments, 1)); } catch (e) {}
}
function expose(suffix, fn) {
  try { Object.defineProperty(W, N + suffix, { value: fn, enumerable: false, configurable: true }); } catch (e) {}
}

/* ---- v4: small realism fixes ---- */
try {
  if (navigator.webdriver !== false) {
    Object.defineProperty(Object.getPrototypeOf(navigator), 'webdriver', { get: mask(function () { return false; }, 'get webdriver'), configurable: true, enumerable: true });
  }
} catch (e) {}
try {
  if (!W.Notification) {
    var Nt = function Notification() {};
    Nt.permission = 'default';
    Nt.maxActions = 2;
    Nt.requestPermission = mask(function requestPermission() { return Promise.resolve('default'); }, 'requestPermission');
    W.Notification = mask(Nt, 'Notification');
  }
} catch (e) {}

/* ---- v4.3: count Web Workers (a countdown running inside a worker never sees the virtual clock) ---- */
try {
  var NWk = W.Worker;
  if (NWk) {
    var PWk = mask(function Worker(u, o) { STAT.wk++; return arguments.length > 1 ? new NWk(u, o) : new NWk(u); }, 'Worker');
    PWk.prototype = NWk.prototype;
    W.Worker = PWk;
  }
} catch (e) {}
