/* FastLink Instagram helper (v5.1). Runs only on instagram.com and only uses the person's OWN login session.
   It finds the post / reel / story that is on screen, asks Instagram's own web API (the same call the website
   makes) for the original files and hands them to the app's blue download button.
   Needs: logged in to Instagram inside this browser. Public + followed-private posts both work. */
var IGH = (function () {
  if (!/(^|\.)instagram\.com$/.test(location.hostname)) return 0;
  var D = document, ABC = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  var cache = {}, busy = {}, failAt = {}, lastKey = '', loginSaid = 0;

  function idOf(code) {                         // shortcode (the part in /p/XXXX/) -> numeric media id
    try {
      if (code.length > 28) code = code.slice(0, code.length - 28);
      var n = BigInt(0), b = BigInt(64);
      for (var i = 0; i < code.length; i++) {
        var k = ABC.indexOf(code.charAt(i));
        if (k < 0) return '';
        n = n * b + BigInt(k);
      }
      return n.toString();
    } catch (e) { return ''; }
  }
  function cookie(n) {
    var m = D.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }

  /* which post is the person looking at right now? */
  function target() {
    var p = location.pathname, m;
    if ((m = p.match(/^\/(?:[\w.]+\/)?(?:p|reel|reels|tv)\/([\w-]+)/))) return { code: m[1], pk: idOf(m[1]) };
    if ((m = p.match(/^\/stories\/[^\/]+\/(\d+)/))) return { code: 's' + m[1], pk: m[1] };
    // home feed: the post that sits closest to the middle of the screen
    var arts = D.querySelectorAll('article'), best = null, bd = 1e9, mid = innerHeight / 2;
    for (var i = 0; i < arts.length; i++) {
      var r = arts[i].getBoundingClientRect();
      if (r.bottom < 0 || r.top > innerHeight) continue;
      var d = Math.abs((r.top + r.bottom) / 2 - mid);
      if (d < bd) { bd = d; best = arts[i]; }
    }
    if (best) {
      var l = best.querySelector('a[href*="/p/"],a[href*="/reel/"]');
      var mm = l && (l.getAttribute('href') || '').match(/\/(?:p|reel)\/([\w-]+)/);
      if (mm) return { code: mm[1], pk: idOf(mm[1]) };
    }
    return null;
  }

  function fetchInfo(t, cb) {
    var claim = '0';
    try { claim = sessionStorage.getItem('www-claim-v2') || '0'; } catch (e) {}
    fetch('/api/v1/media/' + t.pk + '/info/', {
      credentials: 'include',
      headers: {
        'X-IG-App-ID': '936619743392459', 'X-ASBD-ID': '129477', 'X-IG-WWW-Claim': claim,
        'X-CSRFToken': cookie('csrftoken'), 'X-Requested-With': 'XMLHttpRequest', 'Accept': '*/*'
      }
    }).then(function (r) {
      if (r.redirected && r.url.indexOf('/accounts/login') >= 0) { cb('login'); return null; }
      if (r.status === 401 || r.status === 403) { cb('login'); return null; }
      if (!r.ok) { cb('http ' + r.status); return null; }
      return r.json();
    }).then(function (j) { if (j) cb(null, j); })
      .catch(function () { cb('net'); });
  }

  function best(arr) {                           // biggest picture / video of the list
    var b = null;
    for (var i = 0; arr && i < arr.length; i++) {
      if (!b || (arr[i].width || 0) * (arr[i].height || 0) > (b.width || 0) * (b.height || 0)) b = arr[i];
    }
    return b;
  }
  function pick(m, out, base, idx) {
    var sfx = idx ? '_' + idx : '';
    var v = best(m.video_versions);
    var im = m.image_versions2 && best(m.image_versions2.candidates);
    if (v && v.url) out.push({ u: v.url, k: 'video', n: base + sfx + '.mp4' });
    else if (im && im.url) out.push({ u: im.url, k: 'image', n: base + sfx + '.jpg' });
  }
  function extract(j) {
    var it = j && j.items && j.items[0], out = [];
    if (!it) return out;
    var user = (it.user && it.user.username) || 'instagram';
    var base = 'instagram_' + user + '_' + (it.code || it.pk || Date.now());
    if (it.carousel_media && it.carousel_media.length) {
      for (var i = 0; i < it.carousel_media.length; i++) pick(it.carousel_media[i], out, base, i + 1);
    } else pick(it, out, base, 0);
    return out;
  }
  function fail(code, why) {
    failAt[code] = Date.now();
    if (lastKey === code) lastKey = '';           // try again after 20 s (e.g. once the person has logged in)
    if (why === 'login') { if (loginSaid) return; loginSaid = 1; }
    call('igFail', why);
  }
  function send(list) {
    for (var i = 0; i < list.length; i++) call('igMedia', list[i].u, list[i].k, list[i].n);
  }

  function tick() {
    try {
      var t = target();
      if (!t || !t.pk) {
        if (lastKey) { lastKey = ''; call('igReset', 1); }
        return;
      }
      if (t.code === lastKey) return;
      lastKey = t.code;
      call('igReset', 1);
      if (cache[t.code]) { send(cache[t.code]); return; }
      if (busy[t.code]) return;
      if (failAt[t.code] && Date.now() - failAt[t.code] < 20000) return;
      if (!cookie('ds_user_id')) { fail(t.code, 'login'); return; }
      busy[t.code] = 1;
      fetchInfo(t, function (err, j) {
        busy[t.code] = 0;
        if (err) { fail(t.code, err); return; }
        var list = extract(j);
        if (!list.length) { fail(t.code, 'file nahi mili'); return; }
        cache[t.code] = list;
        if (lastKey === t.code) send(list);
      });
    } catch (e) {}
  }
  W.setInterval(tick, 1500);
  W.setTimeout(tick, 800);
  return 1;
})();
