function (on) {
  try {
    var ID = '__flb_land_css';
    var old = document.getElementById(ID);

    function undo() {
      if (old) old.parentNode.removeChild(old);
      var a = document.querySelectorAll('.__flb_fs,.__flb_anc');
      for (var i = 0; i < a.length; i++) a[i].classList.remove('__flb_fs', '__flb_anc');
    }
    if (!on) { undo(); return 'off'; }
    if (document.fullscreenElement || document.webkitFullscreenElement) return 'native';
    if (old) return 'css';

    // pick the video that is really playing and big enough to be "the" video of the page
    var vs = document.querySelectorAll('video'), v = null, i;
    for (i = 0; i < vs.length; i++) {
      var x = vs[i], r = x.getBoundingClientRect();
      if (x.paused || x.ended || !x.videoWidth) continue;
      if (r.width < window.innerWidth * 0.4) continue;
      if (isFinite(x.duration) && x.duration < 45) continue; // skip tiny preview loops
      v = x; break;
    }
    if (!v) return 'novideo';

    var box = document.querySelector('.html5-video-player') || v.parentElement || v;

    function cssMode() {
      if (document.getElementById(ID)) return;
      var st = document.createElement('style');
      st.id = ID;
      st.textContent =
        'html,body{overflow:hidden!important}' +
        '.__flb_anc{transform:none!important;contain:none!important;filter:none!important;' +
        'perspective:none!important;will-change:auto!important;overflow:visible!important}' +
        '.__flb_fs{position:fixed!important;left:0!important;top:0!important;right:0!important;' +
        'bottom:0!important;width:100vw!important;height:100vh!important;max-width:none!important;' +
        'max-height:none!important;margin:0!important;padding:0!important;z-index:2147483647!important;' +
        'background:#000!important}' +
        '.__flb_fs video{width:100%!important;height:100%!important;left:0!important;top:0!important;' +
        'object-fit:contain!important}';
      (document.head || document.documentElement).appendChild(st);
      box.classList.add('__flb_fs');
      for (var p = box.parentElement; p && p !== document.documentElement; p = p.parentElement) {
        p.classList.add('__flb_anc');
      }
    }

    // 1) try the real fullscreen first (goes through the app's native fullscreen view)
    // 2) if the page refuses it (no user gesture), fall back to a "video only" layout
    var fn = box.requestFullscreen || box.webkitRequestFullscreen;
    if (!fn) { cssMode(); return 'css'; }
    try {
      var res = fn.call(box);
      if (res && res.catch) res.catch(cssMode);
    } catch (e) { cssMode(); return 'css'; }
    return 'trying';
  } catch (e) {
    return 'err';
  }
}
