/* FastLink bridge helpers (shared by every script, runs first). C (config) already exists. */
var W = window;
/* ---- bridge to the app (name is random per launch and removed from window) ---- */
var N = C.n, Bobj = null;
function B() {
  if (!Bobj) { var o = W[N]; if (o) { Bobj = o; try { delete W[N]; } catch (e) {} } }
  return Bobj;
}
function call(m) {
  var b = B(); if (!b) return;
  try { b[m].apply(b, Array.prototype.slice.call(arguments, 1)); } catch (e) {}
}
function expose(suffix, fn) {
  try { Object.defineProperty(W, N + suffix, { value: fn, enumerable: false, configurable: true }); } catch (e) {}
}

/* ---- v5.2: live settings. The app calls window[N+'c'](obj) when the user flips a menu option, so the page
   does NOT have to reload. Every script can register a hook to react to the changed values. ---- */
var CFG_HOOKS = [];
expose('c', function (o) {
  var old = {};
  try { for (var k in o) { old[k] = C[k]; C[k] = o[k]; } } catch (e) {}
  for (var i = 0; i < CFG_HOOKS.length; i++) { try { CFG_HOOKS[i](o, old); } catch (e) {} }
  return 1;
});
