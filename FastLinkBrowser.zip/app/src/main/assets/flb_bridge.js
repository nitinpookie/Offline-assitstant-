/* FastLink bridge helpers (shared by every script, runs first). C (config) already exists. */
var W = window;
/* ---- bridge to the app (name is random per launch and removed from window) ---- */
var N = C.n, Bobj = null;
function B() {
  if (!Bobj) { var o = W[N]; if (o) { Bobj = o; try { delete W[N]; } catch (e) {} } }
  return Bobj;
}
function call(m) {
  var b = B(); if (!b) return;
  try { b[m].apply(b, Array.prototype.slice.call(arguments, 1)); } catch (e) {}
}
function expose(suffix, fn) {
  try { Object.defineProperty(W, N + suffix, { value: fn, enumerable: false, configurable: true }); } catch (e) {}
}

