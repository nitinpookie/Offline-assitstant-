/* FastLink media helper. Runs on EVERY page (also on "light" sites where the heavy engine is skipped).
   - tells the app when a page is playing media (lock-screen controls, background play)
   - volume boost up to 350% (Web Audio gain + slow gentle compressor + static soft clipper, no pumping)
   - keeps the page "visible" so music does not stop when the screen locks
   - light YouTube ad skipping (no heavy patches) */
var MEDH = (function () {
  var D = document;
  var nsi = W.setInterval;                       // native timer, captured before any patching
  var nst = W.setTimeout;                        // native timer, captured before core.js patches it
  var boost = Math.max(1, Math.min(3.5, (C.boost || 100) / 100));
  var lim = C.lim !== false;
  var ctx = null, gain = null, comp = null, shaper = null;
  var hooked = new WeakSet(), failed = new WeakSet();
  var lastKey = '', lastEl = null;

  function els() { return D.querySelectorAll('video,audio'); }
  function isPlaying(e) {
    return e && !e.paused && !e.ended && e.readyState >= 2 && !e.muted && e.volume > 0 &&
      (e.tagName === 'AUDIO' || !isFinite(e.duration) || e.duration > 25);
  }
  function playingEl() {
    var l = els();
    for (var i = 0; i < l.length; i++) { if (isPlaying(l[i])) return l[i]; }
    return null;
  }
  function report() {
    var e = playingEl();
    if (e) lastEl = e;
    var title = '';
    try { var md = navigator.mediaSession && navigator.mediaSession.metadata; if (md && md.title) title = md.title; } catch (x) {}
    if (!title) title = D.title || '';
    title = String(title).slice(0, 120);
    var key = (e ? 1 : 0) + '|' + title;
    if (key === lastKey) return;
    lastKey = key;
    call('mediaState', e ? 1 : 0, title);
  }

  /* v5.4: notification Pause / Stop / Play.
     Problems fixed: (1) players such as YouTube resume a video that was paused from outside after a few ms, so the
     pause is now HELD (play() is refused until the user touches the page or presses Play again); (2) every playing
     element is paused, not only one; (3) videos inside iframes get the command too (relayed with postMessage). */
  var heldEls = [], lastTouch = 0, nativePlay = null;
  ['touchstart', 'touchend', 'mousedown', 'keydown'].forEach(function (n) {
    D.addEventListener(n, function (ev) { if (ev.isTrusted) lastTouch = Date.now(); }, true);
  });
  function userNow() { return Date.now() - lastTouch < 1500; }
  function holdIdx(e) { return heldEls.indexOf(e); }
  try {                                           // while an element is held, nobody but the user may start it
    var HP = W.HTMLMediaElement && W.HTMLMediaElement.prototype;
    if (HP && HP.play && !HP.__flbPlay) {
      nativePlay = HP.play;
      HP.play = function () {
        if (holdIdx(this) >= 0) {
          if (userNow()) heldEls.splice(holdIdx(this), 1);        // the user pressed play on the page itself
          else { try { this.pause(); } catch (x) {} return Promise.resolve(); }
        }
        return nativePlay.apply(this, arguments);
      };
      HP.__flbPlay = 1;
    }
  } catch (x) {}
  ['play', 'playing'].forEach(function (n) {      // started without play() (autoplay attribute, MSE): push it back
    D.addEventListener(n, function (ev) {
      var t = ev.target, i = holdIdx(t);
      if (i < 0) return;
      if (userNow()) { heldEls.splice(i, 1); return; }
      try { t.pause(); } catch (x) {}
    }, true);
  });
  function ytApi(fn) {                            // YouTube keeps its own state: pause through its player, not only the <video>
    try {
      var mp = D.getElementById('movie_player') || D.querySelector('.html5-video-player');
      if (mp && typeof mp[fn] === 'function') { mp[fn](); return true; }
    } catch (x) {}
    return false;
  }
  function relayFrames(cmd) {
    var fr = D.querySelectorAll('iframe,frame');
    for (var i = 0; i < fr.length; i++) { try { fr[i].contentWindow.postMessage({ flbm: cmd }, '*'); } catch (x) {} }
  }
  function ctl(cmd) {
    var l = els(), i, e, did = 0;
    if (cmd === 'toggle') cmd = playingEl() ? 'pause' : 'play';
    if (cmd === 'pause') {
      var any = false;
      for (i = 0; i < l.length; i++) {
        e = l[i];
        if (e.paused) continue;
        any = true;
        if (!isPreview(e) && holdIdx(e) < 0) heldEls.push(e);
      }
      if (any) { ytApi('pauseVideo'); did = 1; }
      for (i = 0; i < l.length; i++) { try { if (!l[i].paused) l[i].pause(); } catch (x) {} }
      lastTouch = 0;
    } else {
      var back = heldEls.slice();
      heldEls.length = 0;                         // release the hold first, then start
      if (!back.length) { e = playingEl() || lastEl; if (!e && l.length) e = l[0]; if (e) back.push(e); }
      if (back.length) { ytApi('playVideo'); did = 1; }
      for (i = 0; i < back.length; i++) {
        try { var pr = (nativePlay || back[i].play).call(back[i]); if (pr && pr.catch) pr.catch(function () {}); } catch (x) {}
      }
    }
    relayFrames(cmd);
    nst.call(W, report, 300);
    nst.call(W, report, 1200);
    return did || 1;
  }
  W.addEventListener('message', function (ev) {   // the page above us (or the app) sent Pause / Play: pass it down
    var d = ev.data;
    if (d && typeof d === 'object' && typeof d.flbm === 'string' && W.parent !== W && ev.source === W.parent) {
      try { ctl(d.flbm); } catch (x) {}
    }
  }, true);

  /* ---------- volume boost ----------
     v5.1: "cut cut" fix. The old chain was gain(up to 3.5x) -> hard compressor (threshold -6 dB, ratio 12,
     attack 2 ms) -> tanh. On loud / bass heavy music the compressor clamped EVERY beat and let go again 120 ms
     later = the sound pumped / flickered. New chain has no fast gain changes at all:
       source -> gentle slow compressor (on the original level) -> boost gain -> soft clipper -> speaker
     The soft clipper is a plain static curve (no timing, so nothing can pump) and costs very little CPU.
     Gain changes are smoothed and the nodes are only re-wired when the limiter is switched. */
  var SCALE = 4;                                  // the clipper sees (signal * boost / SCALE)
  var inp = null, wiredMode = '';
  function clipCurve() {
    var n = 4097, c = new Float32Array(n), K = 0.55;
    for (var i = 0; i < n; i++) {
      var u = i * 2 / (n - 1) - 1, x = Math.abs(u) * SCALE;
      var y = x <= K ? x : K + (1 - K) * Math.tanh((x - K) / (1 - K));
      c[i] = u < 0 ? -y : y;
    }
    return c;
  }
  function ensure() {
    if (ctx) return ctx;
    try {
      var AC = W.AudioContext || W.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC({ latencyHint: 'playback' });
      inp = ctx.createGain();
      gain = ctx.createGain();
      comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -20; comp.knee.value = 24; comp.ratio.value = 3;
      comp.attack.value = 0.02; comp.release.value = 0.4;
      shaper = ctx.createWaveShaper();
      shaper.curve = clipCurve();
      ctx.onstatechange = function () {
        if (ctx.state === 'suspended' && playingEl()) { try { ctx.resume(); } catch (x) {} }
      };
    } catch (x) { ctx = null; return null; }
    return ctx;
  }
  function wire() {
    if (!ctx) return;
    var useLim = boost > 1.001 && lim;
    var mode = useLim ? 'lim' : 'plain';
    var target = useLim ? boost / SCALE : boost;
    if (mode !== wiredMode) {
      try { inp.disconnect(); } catch (x) {}
      try { comp.disconnect(); } catch (x) {}
      try { gain.disconnect(); } catch (x) {}
      try { shaper.disconnect(); } catch (x) {}
      if (useLim) { inp.connect(comp); comp.connect(gain); gain.connect(shaper); shaper.connect(ctx.destination); }
      else { inp.connect(gain); gain.connect(ctx.destination); }
      try { gain.gain.cancelScheduledValues(0); } catch (x) {}
      gain.gain.value = target;
      wiredMode = mode;
    } else {
      try { gain.gain.setTargetAtTime(target, ctx.currentTime, 0.05); } catch (x) { gain.gain.value = target; }
    }
  }
  function okOrigin(e) {
    var s = e.currentSrc || e.src || '';
    if (!s || s.indexOf('blob:') === 0) return true;          // MSE / blob media is same-origin
    try { if (new URL(s, location.href).origin === location.origin) return true; } catch (x) {}
    return e.crossOrigin !== null;                              // cross-origin without CORS would turn silent
  }
  function hook(e) {
    if (hooked.has(e) || failed.has(e)) return;
    if (!ensure()) return;
    if (ctx.state !== 'running') { try { ctx.resume(); } catch (x) {} return; }
    if (!okOrigin(e)) { failed.add(e); call('boostSkip', 1); return; }
    try { wire(); var src = ctx.createMediaElementSource(e); src.connect(inp); hooked.add(e); }
    catch (x) { failed.add(e); }
  }
  function hookAll() { var l = els(); for (var i = 0; i < l.length; i++) hook(l[i]); }
  function setBoost(p, l) {
    boost = Math.max(1, Math.min(3.5, p / 100));
    lim = l !== false;
    if (boost > 1.001 || ctx) {
      if (ensure()) { wire(); try { ctx.resume(); } catch (x) {} hookAll(); }
    }
  }

  ['play', 'playing', 'pause', 'ended', 'emptied', 'loadeddata'].forEach(function (n) {
    D.addEventListener(n, function (ev) {
      var t = ev.target;
      if (t && (t.tagName === 'VIDEO' || t.tagName === 'AUDIO')) {
        if (boost > 1.001 && (n === 'play' || n === 'playing' || n === 'loadeddata')) hook(t);
        report();
      }
    }, true);
  });
  ['touchend', 'click', 'keydown'].forEach(function (n) {
    D.addEventListener(n, function () {
      if (ctx && ctx.state !== 'running') { try { ctx.resume().then(hookAll); } catch (x) {} }
      else if (boost > 1.001) hookAll();
    }, true);
  });
  nsi.call(W, report, 4000);

  /* ---------- keep page "visible" while the screen is locked ---------- */
  var bgDone = false;
  function applyBg() {
    if (bgDone) return;
    bgDone = true;
    try {
      var DP = W.Document.prototype;
      Object.defineProperty(DP, 'hidden', { get: function () { return false; }, configurable: true, enumerable: true });
      Object.defineProperty(DP, 'visibilityState', { get: function () { return 'visible'; }, configurable: true, enumerable: true });
      var stopEv = function (ev) { if (ev.target === W || ev.target === D) ev.stopImmediatePropagation(); };
      ['visibilitychange', 'webkitvisibilitychange'].forEach(function (n) { D.addEventListener(n, stopEv, true); W.addEventListener(n, stopEv, true); });
    } catch (x) {}
  }
  if (C.bg) applyBg();

  /* ---------- light YouTube ad skip (no JSON patches, so the player stays fast) ---------- */
  if (C.ads && /(^|\.)youtube\.com$/.test(location.hostname)) {
    try {
      var st = D.createElement('style');
      st.textContent = 'ytd-ad-slot-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,ytd-banner-promo-renderer,' +
        'ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,ytm-promoted-video-renderer,ytm-ad-slot-renderer,' +
        '.ytp-ad-module,.ytp-ad-overlay-container,.video-ads,#masthead-ad,#player-ads{display:none!important}';
      (D.head || D.documentElement).appendChild(st);
    } catch (x) {}
    var ytMuted = false;
    nsi.call(W, function () {
      var p = D.querySelector('.html5-video-player'), v = D.querySelector('video');
      if (p && v && p.classList.contains('ad-showing')) {
        if (!v.muted) { v.muted = true; ytMuted = true; }
        if (isFinite(v.duration) && v.duration > 0) v.currentTime = v.duration;
      } else if (ytMuted && v) { v.muted = false; ytMuted = false; }
      var b = D.querySelectorAll('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern,.ytp-ad-overlay-close-button');
      for (var i = 0; i < b.length; i++) b[i].click();
    }, 500);
  }

  /* ---------- v5.2: data saver / video focus / quality cap ----------
     C.sv = data saver, C.fx = video focus (a video is playing: the app blocks every other request itself),
     C.vq = max video height (0 = no cap), C.io = images off. All of them can change while the page is open. */

  function isPreview(e) {                         // muted + short or looping = hover / thumbnail preview
    return e.muted && (e.loop || (isFinite(e.duration) && e.duration > 0 && e.duration < 25));
  }
  function tame() {                               // previews stay asleep; they would eat data behind the real video
    if (!(C.sv || C.fx)) return;
    var l = els();
    for (var i = 0; i < l.length; i++) {
      var e = l[i];
      if (e.tagName !== 'VIDEO' || e === lastEl || isPlaying(e)) continue;
      try {
        if (!e.paused && isPreview(e)) e.pause();
        if (e.paused && e.preload !== 'none') e.preload = 'none';
        if (e.autoplay) e.autoplay = false;
      } catch (x) {}
    }
  }
  D.addEventListener('play', function (ev) {
    var t = ev.target;
    if (!(C.sv || C.fx) || !t || t.tagName !== 'VIDEO' || t === lastEl) return;
    if (isPreview(t)) { try { t.pause(); } catch (x) {} }
  }, true);

  // sites that read the Network Information API serve lighter media when saveData is on
  try {
    var NC = W.NetworkInformation && W.NetworkInformation.prototype;
    if (NC) {
      [['saveData', true], ['effectiveType', '3g'], ['downlink', 1.5]].forEach(function (pv) {
        var d = Object.getOwnPropertyDescriptor(NC, pv[0]);
        if (d && d.get) {
          var og = d.get;
          Object.defineProperty(NC, pv[0], { get: function () { return C.sv ? pv[1] : og.call(this); }, configurable: true, enumerable: true });
        }
      });
    }
  } catch (x) {}

  // while a video plays: no new sockets / event streams / beacons from the page (installed only when needed)
  var netBlocked = false;
  function blockNet() {
    if (netBlocked) return;
    netBlocked = true;
    try {
      var NWS = W.WebSocket;
      if (NWS) {
        var PWS = function WebSocket(u, p) {
          if (C.fx) throw new DOMException('Blocked while a video plays', 'NetworkError');
          return arguments.length > 1 ? new NWS(u, p) : new NWS(u);
        };
        PWS.prototype = NWS.prototype;
        PWS.CONNECTING = 0; PWS.OPEN = 1; PWS.CLOSING = 2; PWS.CLOSED = 3;
        W.WebSocket = PWS;
      }
    } catch (x) {}
    try {
      var NES = W.EventSource;
      if (NES) {
        var PES = function EventSource(u, o) {
          if (C.fx) throw new DOMException('Blocked while a video plays', 'NetworkError');
          return arguments.length > 1 ? new NES(u, o) : new NES(u);
        };
        PES.prototype = NES.prototype;
        PES.CONNECTING = 0; PES.OPEN = 1; PES.CLOSED = 2;
        W.EventSource = PES;
      }
    } catch (x) {}
    try {
      var nsb = navigator.sendBeacon;
      if (nsb) navigator.sendBeacon = function sendBeacon() { return C.fx ? false : nsb.apply(navigator, arguments); };
    } catch (x) {}
  }

  // safety valve: if the video starves for 9 s while focus is on, the app lets everything through again
  var stallT = 0;
  function stallWatch(ev) {
    var t = ev.target;
    if (!C.fx || stallT || !t || t.tagName !== 'VIDEO') return;
    stallT = nst.call(W, function () {
      stallT = 0;
      try { if (C.fx && !t.paused && !t.ended && t.readyState < 3) call('focusStall'); } catch (x) {}
    }, 9000);
  }
  D.addEventListener('waiting', stallWatch, true);
  D.addEventListener('stalled', stallWatch, true);

  // images come back without a reload when "Images band" is switched off again
  function reloadImages() {
    try {
      var im = D.images;
      for (var i = 0; i < im.length && i < 400; i++) {
        var g = im[i];
        if (g.complete && g.naturalWidth <= 1 && g.currentSrc) { var u = g.currentSrc; g.removeAttribute('src'); g.src = u; }
      }
    } catch (x) {}
  }

  /* quality cap for players that have their own quality list. (HLS / DASH manifests are capped by the app itself,
     this part is for plain MP4 players: JW Player, <source size=..> lists, video.js / plyr menus.) */
  var qDone = new WeakMap(), qTries = 0;
  function hgt(s) {
    s = String(s == null ? '' : s).trim();
    var m = /(?:^|[^0-9])(\d{3,4})\s*p(?![a-z])/i.exec(s) || /^(\d{3,4})$/.exec(s);
    return m ? parseInt(m[1], 10) : 0;
  }
  function pickIdx(hs, cap) {                     // best height <= cap, else the smallest known one
    var best = -1, bh = 0, low = -1, lh = 1e9;
    for (var i = 0; i < hs.length; i++) {
      var h = hs[i];
      if (!h) continue;
      if (h <= cap && h > bh) { bh = h; best = i; }
      if (h < lh) { lh = h; low = i; }
    }
    return best >= 0 ? best : low;
  }
  function doSwap(e, url) {                       // switch a plain video to another file, keep the position
    var t0 = e.currentTime, was = !e.paused;
    e.src = url;
    e.load();
    e.addEventListener('loadedmetadata', function f() {
      e.removeEventListener('loadedmetadata', f);
      try { if (t0 > 0) e.currentTime = t0; } catch (x) {}
      if (was) { var pr = e.play(); if (pr && pr.catch) pr.catch(function () {}); }
    });
  }
  // Many sites write every quality of the SAME video into the page (script / JSON). Two URLs are "the same video"
  // when host + path are equal after the quality number (240 / 360 / 480 / 720 / 1080 ...) is masked out.
  var HK = '(144|240|360|480|540|576|720|1080|1440|2160)';
  var HRE = new RegExp('(?<![0-9])' + HK + '(?![0-9])', 'g');
  function tokH(path) { var m = new RegExp('(?<![0-9])' + HK + '(?![0-9])').exec(path); return m ? parseInt(m[1], 10) : 0; }
  function urlParts(u) { try { var a = new URL(u, location.href); return { host: a.host, path: a.pathname }; } catch (x) { return null; } }
  function pageUrls() {
    var t = '';
    try { t = D.documentElement.innerHTML; } catch (x) {}
    if (t.length > 3000000) t = t.slice(0, 3000000);
    t = t.replace(/\\\//g, '/').replace(/\\u0026/g, '&').replace(/&amp;/g, '&');
    var re = /https?:\/\/[^"'\s<>\\)]+?\.(?:mp4|webm)(?:\?[^"'\s<>\\)]*)?/gi, m, out = [], seen = {};
    while ((m = re.exec(t)) && out.length < 400) { if (!seen[m[0]]) { seen[m[0]] = 1; out.push(m[0]); } }
    return out;
  }
  function swapFromPage(e, cap) {
    var cur = e.currentSrc || e.src;
    if (!cur || cur.indexOf('blob:') === 0) return false;
    var cp = urlParts(cur);
    if (!cp) return false;
    var curH = tokH(cp.path);
    if (!curH) return false;
    if (curH <= cap) return true;                 // already inside the limit
    var sk = cp.host + cp.path.replace(HRE, '#'), cands = [], hs = [], all = pageUrls();
    for (var i = 0; i < all.length; i++) {
      var pp = urlParts(all[i]);
      if (pp && pp.host + pp.path.replace(HRE, '#') === sk && tokH(pp.path)) { cands.push(all[i]); hs.push(tokH(pp.path)); }
    }
    var k = pickIdx(hs, cap);
    if (k < 0) return false;
    if (hs[k] >= curH) return true;               // nothing smaller on offer
    doSwap(e, cands[k]);
    return true;
  }
  /* v5.3: (height, url) pairs written into the page next to each other, whatever the URL looks like:
       {"quality":"480","videoUrl":"https://.../a.mp4"}   "720p":"https://..."   quality_480p = 'https://...'
     Needed for sites whose files do not carry the height in the path. The pairs that sit around the URL of the
     playing video are the other qualities of THAT video. */
  var KH = { 144: 1, 240: 1, 360: 1, 480: 1, 540: 1, 576: 1, 720: 1, 960: 1, 1080: 1, 1440: 1, 2160: 1 };
  var MEDIA_URL = /\.(?:mp4|webm)(?:[?\/#]|$)|\/get_file\//i;
  function bare(u) { return String(u == null ? '' : u).replace(/[?#].*$/, ''); }
  function qPairs() {
    var t = '';
    try { t = D.documentElement.innerHTML; } catch (x) {}
    if (t.length > 3000000) t = t.slice(0, 3000000);
    t = t.replace(/\\\//g, '/').replace(/\\u0026/g, '&').replace(/&amp;/g, '&');
    var out = [], seen = {}, m;
    function add(h, u, pos) {
      h = parseInt(h, 10);
      if (!KH[h] || !MEDIA_URL.test(u)) return;
      var k = h + '|' + u;
      if (seen[k] || out.length > 300) return;
      seen[k] = 1;
      out.push({ h: h, url: u, pos: pos });
    }
    var r1 = /["'](\d{3,4})p?["']\s*:\s*["'](https?:\/\/[^"'\s<>\\)]+)["']/g;
    while ((m = r1.exec(t))) add(m[1], m[2], m.index);
    var r2 = /quality_(\d{3,4})p?["']?\s*[:=]\s*["'](https?:\/\/[^"'\s<>\\)]+)["']/gi;
    while ((m = r2.exec(t))) add(m[1], m[2], m.index);
    var r3 = /\{[^{}]{10,700}\}/g, hk = /["'](?:quality|label|res|resolution|height|size|definition|name|title|text)["']\s*:\s*["']?(\d{3,4})\s*p?(?![0-9])/i,
      uk = /https?:\/\/[^"'\s<>\\)]+/;
    while ((m = r3.exec(t))) {
      var hm = hk.exec(m[0]), um = hm && uk.exec(m[0].replace(/["']?(?:quality|label|res|resolution|height|size|definition|name|title|text)["']\s*:\s*["']?\d{3,4}\s*p?/ig, ''));
      if (hm && um) add(hm[1], um[0], m.index);
    }
    return out;
  }
  function rootDom(u) {
    try { return new URL(u, location.href).hostname.split('.').slice(-2).join('.'); } catch (x) { return ''; }
  }
  function clusterFor(cur) {                      // all qualities listed around the playing file (null = file not found in the page)
    var ps = qPairs(), cb = bare(cur), at = -1, i;
    for (i = 0; i < ps.length; i++) { if (bare(ps[i].url) === cb) { at = i; break; } }
    if (at < 0) return null;
    var base = ps[at].pos, res = [], dom = rootDom(cur);
    for (i = 0; i < ps.length; i++) {
      if (Math.abs(ps[i].pos - base) < 8000 && rootDom(ps[i].url) === dom) res.push(ps[i]);   // same video: nearby + same site / CDN
    }
    return res;
  }
  function swapFromPairs(e, cap) {
    var cur = e.currentSrc || e.src;
    if (!cur || cur.indexOf('blob:') === 0) return false;
    var cl = clusterFor(cur);
    if (!cl || cl.length < 2) return false;
    var cb = bare(cur), curH = 0, hs = [], i;
    for (i = 0; i < cl.length; i++) { hs.push(cl[i].h); if (bare(cl[i].url) === cb) curH = cl[i].h; }
    if (!curH) return false;
    if (curH <= cap) return true;                 // already inside the limit
    var k = pickIdx(hs, cap);
    if (k < 0 || hs[k] >= curH) return true;      // nothing smaller on offer
    doSwap(e, cl[k].url);
    return true;
  }
  function capQuality(e, cap) {
    var ok = false;
    try {                                         // JW Player
      if (W.jwplayer) {
        var jp = W.jwplayer(), q = jp && jp.getQualityLevels ? jp.getQualityLevels() : null;
        if (q && q.length > 1) {
          var hs = [];
          for (var i = 0; i < q.length; i++) hs.push(q[i].height || hgt(q[i].label));
          var ix = pickIdx(hs, cap);
          if (ix >= 0) { if (jp.getCurrentQuality() !== ix) jp.setCurrentQuality(ix); ok = true; }
        }
      }
    } catch (x) {}
    if (!ok) {                                    // <video><source src size=720> ...</video>
      try {
        var srcs = e.querySelectorAll('source[src]');
        if (srcs.length > 1) {
          var hs2 = [], urls = [];
          for (var j = 0; j < srcs.length; j++) {
            var sc = srcs[j];
            hs2.push(hgt(sc.getAttribute('size') || sc.getAttribute('data-res') || sc.getAttribute('res') ||
              sc.getAttribute('data-quality') || sc.getAttribute('label') || sc.getAttribute('title')));
            urls.push(sc.src);
          }
          var k = pickIdx(hs2, cap), cur = e.currentSrc || e.src, ci = urls.indexOf(cur);
          if (k >= 0 && ci >= 0 && hs2[k] && hs2[ci]) {
            ok = true;
            if (hs2[ci] > cap && urls[k] !== cur) doSwap(e, urls[k]);
          }
        }
      } catch (x) {}
    }
    if (!ok) {                                    // video.js / plyr / jw menus that list "720p" style items
      try {
        var items = D.querySelectorAll('.vjs-menu-item,[data-plyr="quality"],.jw-settings-content-item');
        var cand = [], hs3 = [];
        for (var m = 0; m < items.length; m++) {
          var h3 = hgt(items[m].getAttribute('data-plyr-quality') || items[m].getAttribute('value') || items[m].textContent);
          if (h3) { cand.push(items[m]); hs3.push(h3); }
        }
        if (cand.length > 1) {
          var pi = pickIdx(hs3, cap), el = cand[pi];
          var on = el.getAttribute('aria-checked') === 'true' || el.getAttribute('aria-selected') === 'true' ||
            /(^|\s)(vjs-selected|jw-active-option|plyr__control--active)(\s|$)/.test(el.className || '');
          if (!on) el.click();
          ok = true;
        }
      } catch (x) {}
    }
    if (!ok) {                                    // other qualities of this video written into the page
      try { ok = swapFromPage(e, cap); } catch (x) {}
    }
    if (!ok) {                                    // same, but the height is only written beside the URL (JSON / "720p": "url")
      try { ok = swapFromPairs(e, cap); } catch (x) {}
    }
    return ok;
  }
  function qTarget() {                            // the playing video, or (earlier, before it plays) the main-looking one
    if (lastEl && isPlaying(lastEl)) return lastEl;
    var l = els();
    for (var i = 0; i < l.length; i++) {
      var e = l[i];
      if (e.tagName === 'VIDEO' && (e.currentSrc || e.src) && !e.muted && !e.loop) return e;
    }
    return null;
  }
  var qWarned = false;
  function qTick() {
    var cap = C.vq | 0;
    if (!cap) return;
    var e = qTarget();
    if (!e || qDone.get(e) === cap) return;
    qTries++;
    if (qTries > 40) return;
    if (capQuality(e, cap)) { qDone.set(e, cap); return; }
    if (qTries === 10 && !qWarned && isPlaying(e)) { qWarned = true; call('qFail'); }
  }
  ['loadstart', 'loadedmetadata'].forEach(function (n) {
    D.addEventListener(n, function (ev) { if (ev.target && ev.target.tagName === 'VIDEO') { try { qTick(); } catch (x) {} } }, true);
  });
  /* long press on a video -> the app's download sheet (instead of the site's own "download" menu).
     The sheet also gets the other qualities of the same video that are written into the page. */
  if (!/(^|\.)(youtube\.com|youtu\.be)$/.test(location.hostname)) {
    var lpT = 0, lpX = 0, lpY = 0, lpAt = 0;
    var vidAt = function (x, y) {
      var l = els();
      for (var i = 0; i < l.length; i++) {
        if (l[i].tagName !== 'VIDEO') continue;
        var r = l[i].getBoundingClientRect();
        if (r.width > 120 && r.height > 80 && x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return l[i];
      }
      return null;
    };
    var lpCancel = function () { if (lpT) { W.clearTimeout(lpT); lpT = 0; } };
    D.addEventListener('touchstart', function (ev) {
      lpCancel();
      if (!ev.touches || ev.touches.length !== 1) return;
      lpX = ev.touches[0].clientX; lpY = ev.touches[0].clientY;
      if (!vidAt(lpX, lpY)) return;
      lpT = nst.call(W, function () {
        lpT = 0;
        var v = vidAt(lpX, lpY);
        if (!v) return;
        lpAt = Date.now();
        var cur = v.currentSrc || v.src || '';
        if (/^https?:/i.test(cur) && !/\.m3u8(\?|$)/i.test(cur)) {
          call('videoFound', cur);
          try {
            var cp = urlParts(cur);
            if (cp) {
              var sk = cp.host + cp.path.replace(HRE, '#'), all = pageUrls(), n = 0;
              for (var i = 0; i < all.length && n < 6; i++) {
                var pp = urlParts(all[i]);
                if (pp && all[i] !== cur && pp.host + pp.path.replace(HRE, '#') === sk) { call('videoFound', all[i]); n++; }
              }
            }
          } catch (x) {}
        }
        try {                                         // v5.3: qualities listed beside the playing file (JSON style pages)
          if (/^https?:/i.test(cur)) {
            var cl = clusterFor(cur), n2 = 0;
            for (var j = 0; cl && j < cl.length && n2 < 6; j++) {
              if (bare(cl[j].url) !== bare(cur)) { call('videoFound', cl[j].url); n2++; }
            }
          }
        } catch (x) {}
        call('videoHold', cur);
      }, 650);
    }, { capture: true, passive: true });
    D.addEventListener('touchmove', function (ev) {
      if (!lpT || !ev.touches || !ev.touches.length) return;
      if (Math.abs(ev.touches[0].clientX - lpX) > 14 || Math.abs(ev.touches[0].clientY - lpY) > 14) lpCancel();
    }, { capture: true, passive: true });
    ['touchend', 'touchcancel'].forEach(function (n) { D.addEventListener(n, lpCancel, { capture: true, passive: true }); });
    D.addEventListener('contextmenu', function (ev) {
      if (Date.now() - lpAt < 1500 || vidAt(ev.clientX, ev.clientY)) { ev.preventDefault(); ev.stopPropagation(); }
    }, true);
  }

  nsi.call(W, function () { try { tame(); qTick(); } catch (x) {} }, 1500);

  CFG_HOOKS.push(function (o, old) {
    if ('vq' in o) { qTries = 0; qWarned = false; }
    if (o.fx) blockNet();
    if (o.bg) applyBg();
    if ('io' in o && old.io && !o.io) reloadImages();
    try { tame(); } catch (x) {}
  });
  if (C.fx) blockNet();

  expose('m', ctl);
  expose('b', function (p, l) { setBoost(p, l); return 1; });
  if (boost > 1.001) setBoost(boost * 100, lim);
  return 1;
})();
