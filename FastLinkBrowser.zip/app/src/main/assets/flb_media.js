/* FastLink media helper. Runs on EVERY page (also on "light" sites where the heavy engine is skipped).
   - tells the app when a page is playing media (lock-screen controls, background play)
   - volume boost up to 350% (Web Audio gain + soft limiter so the sound does not tear)
   - keeps the page "visible" so music does not stop when the screen locks
   - light YouTube ad skipping (no heavy patches) */
var MEDH = (function () {
  var D = document;
  var nsi = W.setInterval;                       // native timer, captured before any patching
  var boost = Math.max(1, Math.min(3.5, (C.boost || 100) / 100));
  var lim = C.lim !== false;
  var ctx = null, gain = null, comp = null, shaper = null;
  var hooked = new WeakSet(), failed = new WeakSet();
  var lastKey = '', lastEl = null;

  function els() { return D.querySelectorAll('video,audio'); }
  function isPlaying(e) {
    return e && !e.paused && !e.ended && e.readyState >= 2 && !e.muted && e.volume > 0 &&
      (e.tagName === 'AUDIO' || !isFinite(e.duration) || e.duration > 25);
  }
  function playingEl() {
    var l = els();
    for (var i = 0; i < l.length; i++) { if (isPlaying(l[i])) return l[i]; }
    return null;
  }
  function report() {
    var e = playingEl();
    if (e) lastEl = e;
    var title = '';
    try { var md = navigator.mediaSession && navigator.mediaSession.metadata; if (md && md.title) title = md.title; } catch (x) {}
    if (!title) title = D.title || '';
    title = String(title).slice(0, 120);
    var key = (e ? 1 : 0) + '|' + title;
    if (key === lastKey) return;
    lastKey = key;
    call('mediaState', e ? 1 : 0, title);
  }

  function ctl(cmd) {
    var e = playingEl() || lastEl;
    if (!e) { var l = els(); if (l.length) e = l[0]; }
    if (!e) return 0;
    try {
      if (cmd === 'pause' || (cmd === 'toggle' && !e.paused)) e.pause();
      else { var p = e.play(); if (p && p.catch) p.catch(function () {}); }
    } catch (x) {}
    setTimeout(report, 300);
    return 1;
  }

  /* ---------- volume boost ---------- */
  function softCurve() {
    var n = 2048, c = new Float32Array(n), k = 1.4, d = Math.tanh(k);
    for (var i = 0; i < n; i++) { var x = i * 2 / (n - 1) - 1; c[i] = Math.tanh(k * x) / d; }
    return c;
  }
  function ensure() {
    if (ctx) return ctx;
    try {
      var AC = W.AudioContext || W.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC({ latencyHint: 'playback' });
      gain = ctx.createGain();
      comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -6; comp.knee.value = 6; comp.ratio.value = 12;
      comp.attack.value = 0.002; comp.release.value = 0.12;
      shaper = ctx.createWaveShaper();
      shaper.curve = softCurve();
      try { shaper.oversample = '2x'; } catch (x) {}
      ctx.onstatechange = function () {
        if (ctx.state === 'suspended' && playingEl()) { try { ctx.resume(); } catch (x) {} }
      };
    } catch (x) { ctx = null; return null; }
    return ctx;
  }
  function wire() {
    if (!ctx) return;
    try { gain.disconnect(); comp.disconnect(); shaper.disconnect(); } catch (x) {}
    gain.gain.value = boost;
    if (boost > 1.001 && lim) { gain.connect(comp); comp.connect(shaper); shaper.connect(ctx.destination); }
    else gain.connect(ctx.destination);
  }
  function okOrigin(e) {
    var s = e.currentSrc || e.src || '';
    if (!s || s.indexOf('blob:') === 0) return true;          // MSE / blob media is same-origin
    try { if (new URL(s, location.href).origin === location.origin) return true; } catch (x) {}
    return e.crossOrigin !== null;                              // cross-origin without CORS would turn silent
  }
  function hook(e) {
    if (hooked.has(e) || failed.has(e)) return;
    if (!ensure()) return;
    if (ctx.state !== 'running') { try { ctx.resume(); } catch (x) {} return; }
    if (!okOrigin(e)) { failed.add(e); call('boostSkip', 1); return; }
    try { var src = ctx.createMediaElementSource(e); src.connect(gain); hooked.add(e); wire(); }
    catch (x) { failed.add(e); }
  }
  function hookAll() { var l = els(); for (var i = 0; i < l.length; i++) hook(l[i]); }
  function setBoost(p, l) {
    boost = Math.max(1, Math.min(3.5, p / 100));
    lim = l !== false;
    if (boost > 1.001 || ctx) {
      if (ensure()) { wire(); try { ctx.resume(); } catch (x) {} hookAll(); }
    }
  }

  ['play', 'playing', 'pause', 'ended', 'emptied', 'loadeddata'].forEach(function (n) {
    D.addEventListener(n, function (ev) {
      var t = ev.target;
      if (t && (t.tagName === 'VIDEO' || t.tagName === 'AUDIO')) {
        if (boost > 1.001 && (n === 'play' || n === 'playing' || n === 'loadeddata')) hook(t);
        report();
      }
    }, true);
  });
  ['touchend', 'click', 'keydown'].forEach(function (n) {
    D.addEventListener(n, function () {
      if (ctx && ctx.state !== 'running') { try { ctx.resume().then(hookAll); } catch (x) {} }
      else if (boost > 1.001) hookAll();
    }, true);
  });
  nsi.call(W, report, 4000);

  /* ---------- keep page "visible" while the screen is locked ---------- */
  if (C.bg) {
    try {
      var DP = W.Document.prototype;
      Object.defineProperty(DP, 'hidden', { get: function () { return false; }, configurable: true, enumerable: true });
      Object.defineProperty(DP, 'visibilityState', { get: function () { return 'visible'; }, configurable: true, enumerable: true });
      var stopEv = function (ev) { if (ev.target === W || ev.target === D) ev.stopImmediatePropagation(); };
      ['visibilitychange', 'webkitvisibilitychange'].forEach(function (n) { D.addEventListener(n, stopEv, true); W.addEventListener(n, stopEv, true); });
    } catch (x) {}
  }

  /* ---------- light YouTube ad skip (no JSON patches, so the player stays fast) ---------- */
  if (C.ads && /(^|\.)youtube\.com$/.test(location.hostname)) {
    try {
      var st = D.createElement('style');
      st.textContent = 'ytd-ad-slot-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,ytd-banner-promo-renderer,' +
        'ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,ytm-promoted-video-renderer,ytm-ad-slot-renderer,' +
        '.ytp-ad-module,.ytp-ad-overlay-container,.video-ads,#masthead-ad,#player-ads{display:none!important}';
      (D.head || D.documentElement).appendChild(st);
    } catch (x) {}
    var ytMuted = false;
    nsi.call(W, function () {
      var p = D.querySelector('.html5-video-player'), v = D.querySelector('video');
      if (p && v && p.classList.contains('ad-showing')) {
        if (!v.muted) { v.muted = true; ytMuted = true; }
        if (isFinite(v.duration) && v.duration > 0) v.currentTime = v.duration;
      } else if (ytMuted && v) { v.muted = false; ytMuted = false; }
      var b = D.querySelectorAll('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern,.ytp-ad-overlay-close-button');
      for (var i = 0; i < b.length; i++) b[i].click();
    }, 500);
  }

  expose('m', ctl);
  expose('b', function (p, l) { setBoost(p, l); return 1; });
  if (boost > 1.001) setBoost(boost * 100, lim);
  return 1;
})();
