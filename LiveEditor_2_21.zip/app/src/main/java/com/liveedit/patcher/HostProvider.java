package com.liveedit.patcher;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

/**
 * A patched app tells Live Editor "I am on screen" ("fg") or "I left" ("bg"). EVERY app that has the Live Editor engine
 * inside gets the pencil (while the pencil switch of Live Editor is ON), and only that app itself can ask for it.
 */
public final class HostProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        Bundle out = new Bundle();
        out.putBoolean("shown", false);
        try {
            Context c = getContext();
            if (c == null || arg == null) return out;
            Context app = c.getApplicationContext();
            String caller = getCallingPackage();
            if (!arg.equals(caller)) return out;
            if (!PencilPrefs.isOn(app) || !PencilPrefs.hasEngine(app, arg)) {
                PencilHost.leave(arg); // switched off (or not a Live Editor app): nothing to show
                return out;
            }
            if ("fg".equals(method)) {
                int n = extras == null ? -1 : extras.getInt("n", -1);
                out.putBoolean("shown", PencilHost.beat(app, arg, n));
            } else if ("bg".equals(method)) {
                PencilHost.leave(arg);
            }
        } catch (Throwable t) {
            // never let a bad call hurt this app
        }
        return out;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] args) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] args) {
        return 0;
    }
}
