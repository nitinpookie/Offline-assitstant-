package com.liveedit.patcher;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.graphics.drawable.Drawable;
import android.os.Build;

import com.android.apksig.ApkSigner;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** The whole job: look inside an APK (analyze), then apply the chosen options, sign and check it (run). */
final class Patcher {

    interface Log {
        void line(String s);

        void progress(int percent);
    }

    /** What we learned about the picked APK. */
    static final class Analysis {
        File apk;
        long size;
        String label;
        Drawable icon;
        Axml.Info info;
        ApkScan.Result scan;
        boolean alreadyPatched;
        /** Patched by an older Live Editor (before per-item editing): its engine cannot be reused. */
        boolean oldEngine;
        /** The settings text stored inside an already patched APK. */
        String cfgJson;
        boolean split;
        /** The zip had tricks that stop tools from opening it; a repaired copy is used instead. */
        int zipFixed;
    }

    static final class Result {
        File apk;
        boolean live;
        String packageName;
        String label;
        long size;
        final List<String> applied = new ArrayList<String>();
    }

    static final String PROVIDER = "com.liveedit.agent.AgentProvider";
    static final String OVERLAY_PERM = "android.permission.SYSTEM_ALERT_WINDOW";
    static final String QUERY_PERM = "android.permission.QUERY_ALL_PACKAGES";

    private Patcher() {}

    // =======================================================================================
    // analyze
    // =======================================================================================

    static Analysis analyze(Context ctx, File apk) throws Exception {
        Analysis a = new Analysis();
        a.apk = apk;
        a.size = apk.length();
        byte[] man = null;
        boolean zipFailed = false;
        try {
            man = ZipPatcher.readEntry(apk, "AndroidManifest.xml");
        } catch (Throwable ze) {
            // fake "encrypted" flags, a wrong checksum, an odd header, or a bug in the phone's zip code (any error, not
            // only ZipException): repair the zip in a copy and carry on with that copy
            zipFailed = true;
        }
        if (zipFailed) {
            try {
                File repaired = new File(apk.getParentFile(), "repaired.apk");
                ZipPatcher.Info fi = ZipPatcher.rewrite(apk, repaired, null, null, null, null, true);
                apk = repaired;
                a.apk = repaired;
                a.size = repaired.length();
                a.zipFixed = Math.max(1, fi.fixed);
            } catch (Throwable re) {
                // the copy could not be made: keep working on the original with our own zip reader
            }
            man = ZipPatcher.readEntrySafe(apk, "AndroidManifest.xml");
        }
        if (man == null) {
            throw new IOException("No AndroidManifest.xml inside. If this is an XAPK/APKS/bundle, "
                    + "pick the single base APK instead.");
        }
        Axml x = Axml.parse(man);
        a.info = x.info();
        a.alreadyPatched = x.hasString(PROVIDER);
        if (a.alreadyPatched) {
            byte[] cfg = ZipPatcher.readEntrySafe(apk, "assets/liveedit_config.json");
            if (cfg == null) {
                a.oldEngine = true;
            } else {
                a.cfgJson = new String(cfg, StandardCharsets.UTF_8);
                try {
                    a.oldEngine = new JSONObject(a.cfgJson).optInt("v", 0) < 3;
                } catch (Exception e) {
                    a.oldEngine = true;
                }
            }
        }
        try {
            a.scan = ApkScan.scan(apk);
        } catch (Throwable t) {
            // the scan only feeds the "servers" and "timers" lists: an APK must never be refused because of it
            a.scan = new ApkScan.Result();
            try {
                for (String n : ZipPatcher.listNames(apk)) {
                    if (n.matches("classes\\d*\\.dex")) a.scan.dexCount++;
                }
            } catch (Throwable t2) {
                a.scan.dexCount = 1; // the manifest was readable, so this is a real APK
            }
        }
        if (a.scan.dexCount == 0) {
            throw new IOException("This APK has no code inside (common for pre-installed system apps). "
                    + "It cannot be patched.");
        }
        PackageManager pm = ctx.getPackageManager();
        try {
            PackageInfo pi = pm.getPackageArchiveInfo(apk.getAbsolutePath(), 0);
            if (pi != null && pi.applicationInfo != null) {
                ApplicationInfo ai = pi.applicationInfo;
                ai.sourceDir = apk.getAbsolutePath();
                ai.publicSourceDir = apk.getAbsolutePath();
                a.label = String.valueOf(ai.loadLabel(pm));
                a.icon = ai.loadIcon(pm);
            }
        } catch (Throwable t) {
            // name and icon are only for display
        }
        if (a.label == null || a.label.length() == 0) a.label = a.info.pkg != null ? a.info.pkg : "App";
        return a;
    }

    // =======================================================================================
    // run
    // =======================================================================================

    static Result run(Context ctx, Analysis an, Opts o, Log log) throws Exception {
        selfCheck();
        File outDir = new File(ctx.getCacheDir(), "out");
        deleteTree(outDir);
        if (!outDir.mkdirs()) throw new IOException("Cannot create cache folder (storage full?)");
        Result res = new Result();
        res.label = o.appName.trim().length() > 0 ? o.appName.trim() : an.label;

        log.progress(5);
        log.line("1/6 Reading the app manifest...");
        Axml x = Axml.parse(ZipPatcher.readEntrySafe(an.apk, "AndroidManifest.xml"));
        String pkg = x.packageName();
        if (pkg == null) throw new IOException("package name not found in manifest");
        res.packageName = pkg;
        log.line("    package: " + pkg);

        log.progress(15);
        log.line("2/6 Applying your options to the manifest...");
        if (!o.removePerms.isEmpty()) {
            int n = x.removePermissions(o.removePerms);
            res.applied.add("Removed " + n + " permission" + (n == 1 ? "" : "s"));
        }
        if (!o.disableComps.isEmpty()) {
            int n = x.disableComponents(o.disableComps);
            res.applied.add("Disabled " + n + " part" + (n == 1 ? "" : "s") + " of the app");
        }
        if (o.orientation != 0) {
            int[] map = {0, 1, 0, 10, -1};
            x.setOrientation(map[o.orientation]);
            String[] nm = {"", "Locked to portrait", "Locked to landscape", "Auto-rotate always", "Rotation follows phone setting"};
            res.applied.add(nm[o.orientation]);
        }
        if (o.debuggable != 0) {
            x.setAppBool("debuggable", Axml.A_DEBUGGABLE, o.debuggable == 1);
            res.applied.add("Debuggable " + (o.debuggable == 1 ? "on" : "off"));
        }
        if (o.backup != 0) {
            x.setAppBool("allowBackup", Axml.A_ALLOW_BACKUP, o.backup == 1);
            res.applied.add("Backup " + (o.backup == 1 ? "allowed" : "blocked"));
        }
        if (o.cleartext != 0) {
            x.setAppBool("usesCleartextTraffic", Axml.A_CLEARTEXT, o.cleartext == 1);
            res.applied.add("Plain HTTP " + (o.cleartext == 1 ? "allowed" : "blocked"));
        }
        if (o.largeHeap != 0) {
            x.setAppBool("largeHeap", Axml.A_LARGE_HEAP, o.largeHeap == 1);
            res.applied.add("Large memory heap " + (o.largeHeap == 1 ? "on" : "off"));
        }
        if (o.appName.trim().length() > 0) {
            x.setLabel(o.appName.trim());
            res.applied.add("App name: " + o.appName.trim());
        }
        Integer code = null;
        String vname = null;
        if (o.versionCode.trim().length() > 0) {
            try {
                code = Integer.valueOf(Integer.parseInt(o.versionCode.trim()));
            } catch (NumberFormatException e) {
                throw new IOException("Version code must be a whole number (got \"" + o.versionCode.trim() + "\")");
            }
        }
        if (o.versionName.trim().length() > 0) vname = o.versionName.trim();
        if (code != null || vname != null) {
            x.setVersion(code, vname);
            res.applied.add("Version: " + (vname != null ? vname : "same") + (code != null ? " (" + code + ")" : ""));
        }

        // ---- best effort for apps whose native libraries do not fit this phone (ARMv7 only)
        boolean stub = false;
        if (o.armCompat && !an.scan.abis.isEmpty()) {
            boolean fits = false;
            boolean armv7 = false;
            if (Build.SUPPORTED_ABIS != null) {
                for (String abi : Build.SUPPORTED_ABIS) {
                    if (an.scan.abis.contains(abi)) fits = true;
                    if ("armeabi-v7a".equals(abi)) armv7 = true;
                }
            }
            if (fits) {
                log.line("    ARMv7 mode skipped: the app already has libraries for this phone");
            } else if (!armv7) {
                log.line("    ARMv7 mode skipped: this phone is not an ARMv7 (32-bit ARM) phone");
            } else {
                stub = true;
            }
        }
        o.guard = stub;

        log.progress(30);
        byte[] dex = null;
        Map<String, byte[]> extras = new LinkedHashMap<String, byte[]>();
        boolean already = x.hasString(PROVIDER);
        if (already && an.oldEngine) {
            throw new IOException("This APK has an engine from an older Live Editor. "
                    + "Pick the original app instead.");
        }
        res.live = o.live;
        if (o.needsEngine() || already) {
            if (already) {
                log.line("3/6 Updating the settings of the engine already inside the app...");
                if (!o.live) res.applied.add("Normal APK: live editor handle off, your edits are built in");
            } else {
                log.line("3/6 Adding the engine" + (o.live ? " and the live editor handle..." : " (no button, no menu)..."));
                x.addProvider(PROVIDER, pkg + ".liveeditagent");
                dex = readAsset(ctx, "agent.dex");
            }
            extras.put("assets/liveedit_config.json", o.configJson().getBytes(StandardCharsets.UTF_8));
            describeEngine(o, res);
        } else {
            log.line("3/6 No engine needed for these options.");
        }
        if (o.live && !o.removePerms.contains(QUERY_PERM)) {
            // lets the pencil find and open the Live Editor app (Save and patch) on Android 11+
            x.addPermission(QUERY_PERM);
        }
        if (o.live && !o.removePerms.contains(OVERLAY_PERM)) {
            // Android only lets the user allow "Display over other apps" for an app that asks for it in its manifest
            if (x.addPermission(OVERLAY_PERM)) {
                res.applied.add("Added the \"Display over other apps\" permission (the pencil uses it)");
            }
        }

        log.progress(45);
        log.line("4/6 Rebuilding the APK...");
        ZipPatcher.Filter filter = null;
        if (stub) {
            Set<String> libNames = new LinkedHashSet<String>();
            for (String n : ZipPatcher.listNames(an.apk)) {
                if (n.startsWith("lib/") && n.endsWith(".so") && n.lastIndexOf('/') > 3) {
                    libNames.add(n.substring(n.lastIndexOf('/') + 1));
                }
            }
            byte[] elf = StubElf.bytes();
            for (String n : libNames) extras.put("lib/armeabi-v7a/" + n, elf);
            filter = name -> name.startsWith("lib/");
            res.applied.add("ARMv7 best-effort mode: " + libNames.size() + " native libraries ("
                    + join(an.scan.abis) + ") replaced by empty stand-ins. Features that need them will not work.");
        } else if (o.keepAbi != null) {
            if (an.scan.abis.contains(o.keepAbi)) {
                final String keep = "lib/" + o.keepAbi + "/";
                filter = name -> name.startsWith("lib/") && !name.startsWith(keep);
                res.applied.add("Kept only " + o.keepAbi + " libraries");
            } else {
                log.line("    CPU filter skipped: " + o.keepAbi + " is not in this APK");
            }
        }
        // The thickness chosen for the origin lines is written into the app's own code (the number next to
        // Paint.setStrokeWidth), so the line keeps that width without anything drawing or redrawing it.
        Map<String, Long> edits = new LinkedHashMap<String, Long>(o.timerEdits);
        if (o.lineT > 0 && an.scan != null && an.scan.hits != null) {
            int fb = Float.floatToIntBits(o.lineT / 10f);
            int nOrigin = 0;
            for (TimerScan.Hit h : an.scan.hits) {
                if (!h.origin || !h.editable || edits.containsKey(h.key())) continue;
                int bits = fb;
                if (h.op == 0x15) bits = (bits + 0x8000) & 0xFFFF0000; // only the top 16 bits fit here
                if (bits == (int) h.value) continue;
                edits.put(h.key(), Long.valueOf(bits));
                nOrigin++;
            }
            if (nOrigin > 0) log.line("    origin line width " + (o.lineT / 10f) + " written into the code (" + nOrigin + " place"
                    + (nOrigin == 1 ? "" : "s") + ")");
        }
        if (!edits.isEmpty()) {
            log.line("    editing timers in the code...");
            List<String> tdone = new ArrayList<String>();
            List<String> tfail = new ArrayList<String>();
            Map<String, byte[]> changed = TimerPatch.apply(an.apk, edits, tdone, tfail);
            extras.putAll(changed);
            for (String t : tdone) res.applied.add("Timer: " + t);
            for (String t : tfail) {
                log.line("    timer edit skipped: " + t);
                res.applied.add("Timer edit NOT applied: " + t);
            }
        }
        File unsigned = new File(outDir, "unsigned.apk");
        ZipPatcher.Info info = ZipPatcher.rewrite(an.apk, unsigned, x.toBytes(), dex, extras, filter, o.normalize);
        log.line("    copied " + info.copied + " files, left out " + info.filtered + ", dropped "
                + info.dropped + " old signature/manifest entries"
                + (info.addedDex != null ? ", added " + info.addedDex : ""));
        if (o.normalize) {
            res.applied.add("Normal structure: " + info.fixed + " file header" + (info.fixed == 1 ? "" : "s")
                    + " repaired" + (info.unfixed > 0 ? ", " + info.unfixed + " could not be repaired" : ""));
            log.line("    normal structure: repaired " + info.fixed + ", could not repair " + info.unfixed);
        }
        if (an.zipFixed > 0) res.applied.add("The zip had tricks that block tools; they were repaired");

        log.progress(65);
        log.line("5/6 Signing...");
        File signed = new File(outDir, "patched.apk");
        sign(ctx, unsigned, signed);
        unsigned.delete();

        log.progress(85);
        log.line("6/6 Checking the result with Android itself...");
        PackageManager pm = ctx.getPackageManager();
        PackageInfo pi = pm.getPackageArchiveInfo(signed.getAbsolutePath(),
                PackageManager.GET_PROVIDERS | PackageManager.GET_PERMISSIONS);
        if (pi == null) {
            throw new IOException("Android cannot read the patched APK. "
                    + "The original app may use features this phone does not support.");
        }
        if (dex != null) {
            boolean found = false;
            if (pi.providers != null) {
                for (ProviderInfo p : pi.providers) {
                    if (PROVIDER.equals(p.name)) found = true;
                }
            }
            if (!found) throw new IOException("Android did not accept the engine entry in the manifest.");
        }
        if (!o.removePerms.isEmpty() && pi.requestedPermissions != null) {
            Set<String> left = new HashSet<String>();
            Collections.addAll(left, pi.requestedPermissions);
            for (String p : o.removePerms) {
                if (left.contains(p)) throw new IOException("Permission was not removed: " + p);
            }
        }
        res.apk = signed;
        res.size = signed.length();
        log.progress(100);
        log.line("Done: " + (res.size / 1024 / 1024) + " MB");
        return res;
    }

    private static String join(Set<String> items) {
        StringBuilder sb = new StringBuilder();
        for (String i : items) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(i);
        }
        return sb.toString();
    }

    private static void describeEngine(Opts o, Result res) {
        List<String> hosts = o.allHosts();
        if (!hosts.isEmpty()) res.applied.add("Blocked " + hosts.size() + " servers");
        if (o.hideAds) res.applied.add("Hides ad banners");
        if (o.live) res.applied.add("Live Editor inside the app: tap the pencil handle");
        if (o.iconPct != 100) res.applied.add("Menu icon size " + o.iconPct + "%");
        if (o.iconAlpha != 100) res.applied.add("Menu icon opacity " + o.iconAlpha + "%");
        if (o.iconText != 100) res.applied.add("Menu icon text " + o.iconText + "%");
        if (o.btnPct != 100) res.applied.add("Floating buttons size " + o.btnPct + "%");
        if (o.btnAlpha != 100) res.applied.add("Floating buttons opacity " + o.btnAlpha + "%");
        if (o.btnText != 100) res.applied.add("Floating buttons text " + o.btnText + "%");
        if (o.menuPct != 100) res.applied.add("Menu size " + o.menuPct + "%");
        if (o.menuAlpha != 100) res.applied.add("Menu opacity " + o.menuAlpha + "%");
        if (o.menuText != 100) res.applied.add("Menu text " + o.menuText + "%");
        if (o.lineT != 0) res.applied.add("Line thickness " + (o.lineT / 10f) + " dp");
        if (o.iconDp != 0) res.applied.add("Menu icon width " + o.iconDp + " dp");
        if (o.btnDp != 0) res.applied.add("Floating buttons width " + o.btnDp + " dp");
        if (o.menuDp != 0) res.applied.add("Menu width " + o.menuDp + " dp");
        if (o.iconTextDp != 0) res.applied.add("Menu icon text " + o.iconTextDp + " dp");
        if (o.btnTextDp != 0) res.applied.add("Floating buttons text " + o.btnTextDp + " dp");
        if (o.menuTextDp != 0) res.applied.add("Menu text " + o.menuTextDp + " dp");
        if (o.themeOn) res.applied.add("App theme: " + Opts.hexOf(o.themeBg) + " / " + Opts.hexOf(o.themeText)
                + " / " + Opts.hexOf(o.themeAccent));
        if (o.links == 1) res.applied.add("Links that open at app start are blocked");
        if (o.links == 2) res.applied.add("All links that leave the app are blocked");
        if (o.timers == 1) res.applied.add("Timer texts hidden");
        if (o.timers == 2) res.applied.add("Timer texts replaced");
        if (o.ruleCount() > 0) res.applied.add(o.ruleCount() + " single-item edits (size, colour, name ...)");
        if (o.mute) res.applied.add("Click sounds muted");
        if (o.keepOn) res.applied.add("Screen stays on");
        if (o.allowShot) res.applied.add("Screenshots allowed");
        if (o.immersive) res.applied.add("Fullscreen (bars hidden)");
        if (o.anim == 1) res.applied.add("Faster animations");
        if (o.anim == 2) res.applied.add("Animations off");
    }

    /** Makes sure the attribute numbers used by the manifest editor match this Android version's own list. */
    private static void selfCheck() throws IOException {
        String[] names = {"label", "name", "enabled", "debuggable", "exported", "authorities", "initOrder",
                "screenOrientation", "minSdkVersion", "versionCode", "versionName", "targetSdkVersion",
                "allowBackup", "largeHeap", "usesCleartextTraffic"};
        int[] mine = {Axml.A_LABEL, Axml.A_NAME, Axml.A_ENABLED, Axml.A_DEBUGGABLE, Axml.A_EXPORTED,
                Axml.A_AUTHORITIES, Axml.A_INIT_ORDER, Axml.A_ORIENTATION, Axml.A_MIN_SDK, Axml.A_VERSION_CODE,
                Axml.A_VERSION_NAME, Axml.A_TARGET_SDK, Axml.A_ALLOW_BACKUP, Axml.A_LARGE_HEAP, Axml.A_CLEARTEXT};
        try {
            Class<?> c = Class.forName("android.R$attr");
            for (int i = 0; i < names.length; i++) {
                int real;
                try {
                    real = c.getField(names[i]).getInt(null);
                } catch (NoSuchFieldException e) {
                    continue; // not public on this Android version: nothing to compare
                }
                if (real != mine[i]) {
                    throw new IOException("Internal attribute number mismatch for " + names[i]);
                }
            }
        } catch (ClassNotFoundException e) {
            // cannot check, carry on
        } catch (IllegalAccessException e) {
            // cannot check, carry on
        }
    }

    static void sign(Context ctx, File in, File out) throws Exception {
        PrivateKey key = KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(readAsset(ctx, "key.pk8")));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(readAsset(ctx, "cert.der")));
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder(
                "liveeditor", key, Collections.singletonList(cert)).build();
        if (out.exists()) out.delete();
        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in)
                .setOutputApk(out)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(false)
                .build()
                .sign();
    }

    private static byte[] readAsset(Context ctx, String name) throws IOException {
        InputStream is = ctx.getAssets().open(name);
        try {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) o.write(buf, 0, n);
            return o.toByteArray();
        } finally {
            is.close();
        }
    }

    static void copy(InputStream is, File to) throws IOException {
        OutputStream os = new FileOutputStream(to);
        try {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        } finally {
            os.close();
            is.close();
        }
    }

    static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (int i = 0; i < kids.length; i++) deleteTree(kids[i]);
        }
        f.delete();
    }
}
