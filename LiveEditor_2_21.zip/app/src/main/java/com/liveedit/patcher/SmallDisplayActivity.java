package com.liveedit.patcher;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * The "small display": a phone-shaped screen inside Live Editor. A patched app (an app that has the Live Editor engine inside)
 * is started on a display that Live Editor creates for it, its picture is shown here, a finger on this picture is handed to
 * the app's own engine (no special permission is needed because the engine lives inside the app), and the pencil of Live Editor
 * sits on top as usual. "Download edited APK" builds the normal APK with every edit inside and asks where to save it.
 *
 * Honest limit: Android decides whether another app may be started on a display of Live Editor. When it refuses, the app opens
 * on the normal screen instead (the pencil works there exactly as before) and this screen says so plainly.
 */
public class SmallDisplayActivity extends Activity implements SurfaceHolder.Callback {

    static final String EXTRA_PKG = "pkg";

    /** Size of the small display in pixels and its density (360 x 640 dp, a normal phone shape). */
    private static final int DW = 540;
    private static final int DH = 960;
    private static final int DPI = 240;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ArrayList<Bundle> queue = new ArrayList<Bundle>();

    private String pkg = "";
    private String label = "";
    private SurfaceView sv;
    private TextView status;
    private VirtualDisplay vd;
    private boolean surfaceReady;
    private boolean wantRun = true;
    private boolean onSmall;
    private boolean draining;
    private int dispId = -1;
    private int polls;
    private int runId;

    // =======================================================================================
    // screen
    // =======================================================================================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        pkg = getIntent().getStringExtra(EXTRA_PKG);
        if (pkg == null) pkg = "";
        try {
            PackageManager pm = getPackageManager();
            label = String.valueOf(pm.getApplicationInfo(pkg, 0).loadLabel(pm));
        } catch (Throwable t) {
            label = pkg;
        }

        LinearLayout col = Ui.vbox(this);
        col.setBackgroundColor(Ui.BG);
        col.setPadding(Ui.dp(this, 14), Ui.dp(this, 30), Ui.dp(this, 14), Ui.dp(this, 10));

        TextView title = Ui.text(this, "Small display", 22, Ui.TEXT, true);
        col.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView sub = Ui.text(this, label + "  \u2022  " + pkg, 12.5f, Ui.SUB, false);
        col.addView(sub);
        status = Ui.text(this, "Starting...", 12.5f, Ui.WARN, false);
        status.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));
        status.setMaxLines(4);
        col.addView(status);

        // the phone: a dark bezel and the surface that the virtual display draws on
        final FrameLayout area = new FrameLayout(this);
        final FrameLayout bezel = new FrameLayout(this);
        bezel.setBackground(Ui.round(this, 0xFF000000, 14));
        int pad = Ui.dp(this, 5);
        bezel.setPadding(pad, pad, pad, pad);
        sv = new SurfaceView(this);
        sv.getHolder().setFixedSize(DW, DH);
        sv.getHolder().addCallback(this);
        sv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                try {
                    if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                    if (onSmall && vd != null) relay(v, ev);
                } catch (Throwable t) {
                    // a bad touch is dropped
                }
                return true;
            }
        });
        bezel.addView(sv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        area.addView(bezel, new FrameLayout.LayoutParams(Ui.dp(this, 200), Ui.dp(this, 360), Gravity.CENTER));
        // the phone takes the height that is left and keeps the shape of the display
        area.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int l, int t, int r, int bt, int ol, int ot, int or, int ob) {
                int aw = r - l;
                int ah = bt - t;
                if (aw <= 0 || ah <= 0) return;
                int p2 = bezel.getPaddingLeft() * 2;
                int hh = ah;
                int ww = (int) ((hh - p2) * (DW / (float) DH)) + p2;
                if (ww > aw) {
                    ww = aw;
                    hh = (int) ((ww - p2) * (DH / (float) DW)) + p2;
                }
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) bezel.getLayoutParams();
                if (lp.width != ww || lp.height != hh) {
                    lp.width = ww;
                    lp.height = hh;
                    lp.gravity = Gravity.CENTER;
                    bezel.setLayoutParams(lp);
                }
            }
        });
        col.addView(area, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout row1 = Ui.hbox(this);
        row1.addView(button("Restart", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wantRun = true;
                restart();
            }
        }), weight());
        row1.addView(button("Back key", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onSmall) WinRows.call(getApplicationContext(), pkg, "back", null, null);
                else Toast.makeText(SmallDisplayActivity.this, "The app is not on the small display", Toast.LENGTH_SHORT).show();
            }
        }), weight());
        row1.addView(button("Pencil panel", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WinRows.call(getApplicationContext(), pkg, "panel", null, null);
            }
        }), weight());
        Ui.add(col, row1, 6);

        LinearLayout row2 = Ui.hbox(this);
        row2.addView(button("Open normally", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNormally();
            }
        }), weight());
        row2.addView(button("Download edited APK", true, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                download();
            }
        }), weight());
        Ui.add(col, row2, 6);

        setContentView(col);
        if (!PencilPrefs.canOverlay(this)) {
            say("Allow \"Display over other apps\" for Live Editor (home screen > pencil card) to see the pencil on top of the small display.", Ui.WARN);
        }
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        int m = Ui.dp(this, 3);
        lp.setMargins(m, 0, m, 0);
        return lp;
    }

    private Button button(String s, boolean primary, View.OnClickListener l) {
        Button b = Ui.button(this, s, primary);
        b.setTextSize(13);
        b.setPadding(Ui.dp(this, 6), Ui.dp(this, 11), Ui.dp(this, 6), Ui.dp(this, 11));
        b.setOnClickListener(l);
        return b;
    }

    private void say(String s, int color) {
        if (status == null) return;
        status.setText(s);
        status.setTextColor(color);
    }

    // =======================================================================================
    // the display
    // =======================================================================================

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        surfaceReady = true;
        if (wantRun) startDisplay();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // the picture has a fixed size; the view only scales it
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceReady = false;
        releaseDisplay();
    }

    @Override
    protected void onDestroy() {
        runId++;
        releaseDisplay();
        super.onDestroy();
    }

    private void restart() {
        releaseDisplay();
        if (surfaceReady) startDisplay();
    }

    private void releaseDisplay() {
        runId++;
        onSmall = false;
        dispId = -1;
        try {
            if (vd != null) vd.release();
        } catch (Throwable t) {
            // already gone
        }
        vd = null;
        synchronized (queue) {
            queue.clear();
        }
    }

    /** Makes the display, starts the app on it and then asks the app's engine where its screen really is. */
    private void startDisplay() {
        if (vd != null) return;
        if (pkg.length() == 0 || getPackageManager().getLaunchIntentForPackage(pkg) == null) {
            say("This app has no screen to open.", Ui.BAD);
            return;
        }
        try {
            DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
            Surface s = sv.getHolder().getSurface();
            int own = DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY;
            int pub = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC | DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION | own;
            try {
                vd = dm.createVirtualDisplay("LiveEditor small display", DW, DH, DPI, s, pub);
            } catch (Throwable t) {
                vd = null;
            }
            if (vd == null) {
                vd = dm.createVirtualDisplay("LiveEditor small display", DW, DH, DPI, s,
                        own | DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION);
            }
            if (vd == null || vd.getDisplay() == null) {
                releaseDisplay();
                fallback("This phone did not make a small display.");
                return;
            }
            dispId = vd.getDisplay().getDisplayId();
        } catch (Throwable t) {
            releaseDisplay();
            fallback("This phone did not make a small display (" + t.getClass().getSimpleName() + ").");
            return;
        }
        try {
            Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            ActivityOptions ao = ActivityOptions.makeBasic();
            ao.setLaunchDisplayId(dispId);
            startActivity(li, ao.toBundle());
        } catch (Throwable t) {
            releaseDisplay();
            fallback("Android refused to start the app on the small display.");
            return;
        }
        say("Starting " + label + " on the small display...", Ui.WARN);
        polls = 0;
        final int id = ++runId;
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (id == runId) poll(id);
            }
        }, 1200L);
    }

    /** Asks the engine of the app on which display its screen is. */
    private void poll(final int id) {
        polls++;
        new Thread(new Runnable() {
            @Override
            public void run() {
                String json = null;
                try {
                    Bundle b = getContentResolver().call(Uri.parse("content://" + pkg + ".liveeditagent"), "disp", null, null);
                    if (b != null) json = b.getString("json");
                } catch (Throwable t) {
                    json = null;
                }
                final String res = json;
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (id == runId) answer(res, id);
                    }
                });
            }
        }, "small-display-poll").start();
    }

    private void answer(String json, int id) {
        int where = -2;
        boolean old = false;
        if (json != null && json.length() > 0) {
            if (json.startsWith("{")) {
                try {
                    JSONObject o = new JSONObject(json);
                    where = o.optInt("id", -2);
                } catch (Throwable t) {
                    where = -2;
                }
            } else {
                old = true; // "unknown": an engine from before 2.21 does not know this question
            }
        }
        if (where == dispId && where > 0) {
            onSmall = true;
            say(label + " runs on the small display. Touch it here. Edit with the pencil handle, then tap \"Download edited APK\".", Ui.GOOD);
            return;
        }
        if (where == 0) {
            releaseDisplay();
            fallback("Android opened the app on the normal screen: it does not let Live Editor put another app on its own display.");
            return;
        }
        if (old) {
            releaseDisplay();
            fallback("This app has an engine from before 2.21. Patch the original app again with this Live Editor.");
            return;
        }
        if (polls < 14) {
            final int rid = id;
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (rid == runId) poll(rid);
                }
            }, 1000L);
        } else {
            say("The app did not answer. It may still be starting. Tap Restart, or Open normally.", Ui.WARN);
        }
    }

    /** The app is shown on the normal screen instead; the pencil and the download still work. */
    private void fallback(String why) {
        wantRun = false;
        say(why + " The pencil works on the normal screen as always: tap \"Open normally\" if the app is not open.", Ui.WARN);
    }

    private void openNormally() {
        try {
            releaseDisplay();
            Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
            if (li == null) {
                Toast.makeText(this, "This app has no screen to open", Toast.LENGTH_SHORT).show();
                return;
            }
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(li);
        } catch (Throwable t) {
            Toast.makeText(this, "Could not open the app", Toast.LENGTH_SHORT).show();
        }
    }

    private void download() {
        Intent i = new Intent(this, MainActivity.class);
        i.setAction("com.liveedit.patcher.BAKE");
        i.putExtra("pkg", pkg);
        i.putExtra("save", true);
        startActivity(i);
    }

    // =======================================================================================
    // fingers
    // =======================================================================================

    /** Hands a finger on the small picture to the app's engine, in the pixels of the small display. */
    private void relay(View v, MotionEvent ev) {
        int w = v.getWidth();
        int hgt = v.getHeight();
        if (w <= 0 || hgt <= 0) return;
        int n = ev.getPointerCount();
        int[] ids = new int[n];
        float[] xs = new float[n];
        float[] ys = new float[n];
        for (int i = 0; i < n; i++) {
            ids[i] = ev.getPointerId(i);
            xs[i] = ev.getX(i) * DW / w;
            ys[i] = ev.getY(i) * DH / hgt;
        }
        Bundle b = new Bundle();
        b.putInt("act", ev.getActionMasked());
        b.putInt("idx", ev.getActionIndex());
        b.putInt("n", n);
        b.putInt("disp", dispId);
        b.putIntArray("ids", ids);
        b.putFloatArray("xs", xs);
        b.putFloatArray("ys", ys);
        synchronized (queue) {
            int last = queue.size() - 1;
            // a stream of moves only needs the newest position
            if (ev.getActionMasked() == MotionEvent.ACTION_MOVE && last >= 0
                    && queue.get(last).getInt("act") == MotionEvent.ACTION_MOVE) {
                queue.set(last, b);
            } else {
                queue.add(b);
            }
            if (draining) return;
            draining = true;
        }
        final Uri uri = Uri.parse("content://" + pkg + ".liveeditagent");
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    Bundle next;
                    synchronized (queue) {
                        if (queue.isEmpty()) {
                            draining = false;
                            return;
                        }
                        next = queue.remove(0);
                    }
                    try {
                        getContentResolver().call(uri, "touch", null, next);
                    } catch (Throwable t) {
                        // the app is gone: drop it
                    }
                }
            }
        }, "small-display-touch").start();
    }
}
