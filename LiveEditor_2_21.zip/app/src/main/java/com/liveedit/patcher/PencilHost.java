package com.liveedit.patcher;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.HashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * THE pencil: one single pencil for every patched app (every app that has the Live Editor engine inside). It is shown by Live
 * Editor itself as an overlay on top of that app's screen, so the patched app needs no overlay permission of its own. The
 * app reports every 1.5 s that it is on screen; when the reports stop, or it says it left, the pencil goes away. It is
 * switched on and off in Live Editor (PencilPrefs, default ON).
 *
 * Tapping the pencil opens the complete pencil of the app (Items, Windows, Global, Theme, More: the panel of the engine
 * inside the app), tapping it again closes it. The handle can be dragged (it sticks to the nearer screen edge and the place
 * is remembered per app), puts itself on top again when the app adds a floating window, and comes back at once if Android
 * took it away. All view work runs on the main thread.
 */
final class PencilHost {

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final HashMap<String, int[]> POS = new HashMap<String, int[]>();

    private static Context ctx;
    private static Context app;
    private static WindowManager wm;
    private static String pkg;
    private static long lastBeat;
    private static boolean watching;
    private static int lastN = -1;

    private static TextView handle;
    private static WindowManager.LayoutParams hlp;
    private static boolean dragging;

    private PencilHost() {}

    private static final Runnable WATCH = new Runnable() {
        @Override
        public void run() {
            watching = false;
            if (handle == null) return;
            if (SystemClock.uptimeMillis() - lastBeat > 6000L || (app != null && !PencilPrefs.isOn(app))) {
                hideNow();
                return;
            }
            // Android took the pencil away (or it was never attached): put it back at once
            if (!dragging && !handle.isAttachedToWindow()) {
                try {
                    wm.addView(handle, hlp);
                } catch (Throwable t) {
                    // the next beat tries again
                }
            }
            watching = true;
            H.postDelayed(this, 1000L);
        }
    };

    // ---- the heartbeat of a patched app ---------------------------------------------------------

    /** The app is on screen. Returns true when the pencil is showing (then the app hides its own). */
    static boolean beat(final Context application, final String p, final int n) {
        if (!PencilPrefs.canOverlay(application)) return false;
        final boolean[] ok = new boolean[1];
        final CountDownLatch done = new CountDownLatch(1);
        H.post(new Runnable() {
            @Override
            public void run() {
                try {
                    ok[0] = showNow(application, p, n);
                } catch (Throwable t) {
                    ok[0] = false;
                } finally {
                    done.countDown();
                }
            }
        });
        try {
            done.await(2, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // answer what we have
        }
        return ok[0];
    }

    /** The app left the screen. */
    static void leave(final String p) {
        H.post(new Runnable() {
            @Override
            public void run() {
                if (p != null && p.equals(pkg)) hideNow();
            }
        });
    }

    /** The pencil switch of Live Editor went OFF: the pencil goes away at once. */
    static void shutdown() {
        H.post(new Runnable() {
            @Override
            public void run() {
                hideNow();
            }
        });
    }

    private static boolean showNow(Context application, String p, int n) {
        lastBeat = SystemClock.uptimeMillis();
        if (handle != null && p.equals(pkg)) {
            // the app added a floating window of its own: the pencil must stay above it
            if (lastN >= 0 && n > lastN && !dragging) raise();
            lastN = n;
            return true;
        }
        hideNow(); // never two pencils: the one of the other app goes first
        app = application;
        ctx = new ContextThemeWrapper(application, android.R.style.Theme_Material);
        wm = (WindowManager) application.getSystemService(Context.WINDOW_SERVICE);
        pkg = p;
        lastN = n;
        int[] pos = POS.get(p);
        if (pos == null) {
            pos = new int[] {Ui.dp(ctx, 4), Ui.dp(ctx, 140)};
            POS.put(p, pos);
        }
        handle = buildHandle();
        hlp = new WindowManager.LayoutParams(Ui.dp(ctx, 46), Ui.dp(ctx, 46), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        hlp.gravity = Gravity.TOP | Gravity.LEFT;
        hlp.x = pos[0];
        hlp.y = pos[1];
        try {
            wm.addView(handle, hlp);
        } catch (Throwable t) {
            handle = null;
            return false;
        }
        if (!watching) {
            watching = true;
            H.postDelayed(WATCH, 1000L);
        }
        return true;
    }

    private static int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : 2002;
    }

    /** Takes the pencil out and puts it in again, so it is above every window the app added meanwhile. */
    private static void raise() {
        if (handle == null || wm == null) return;
        try {
            wm.removeView(handle);
        } catch (Throwable t) {
            // already gone
        }
        try {
            wm.addView(handle, hlp);
        } catch (Throwable t) {
            handle = null;
        }
    }

    private static void hideNow() {
        if (handle != null) {
            try {
                wm.removeView(handle);
            } catch (Throwable t) {
                // already gone
            }
            handle = null;
        }
        pkg = null;
        lastN = -1;
        dragging = false;
    }

    // ---- the handle ----------------------------------------------------------------------------

    private static TextView buildHandle() {
        final TextView t = new TextView(ctx);
        t.setText("\u270E");
        t.setTextSize(20);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.round(ctx, Ui.ACCENT, 23));
        t.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;
            private int startX;
            private int startY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = hlp.x;
                        startY = hlp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > Ui.dp(ctx, 6) || Math.abs(dy) > Ui.dp(ctx, 6)) moved = true;
                        if (moved) {
                            dragging = true;
                            hlp.x = Math.max(0, startX + Math.round(dx));
                            hlp.y = Math.max(0, startY + Math.round(dy));
                            try {
                                wm.updateViewLayout(t, hlp);
                            } catch (Throwable ex) {
                                // ignore
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        dragging = false;
                        if (!moved) {
                            openFullPencil();
                        } else {
                            snapToEdge(t);
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        dragging = false;
                        return true;
                    default:
                        return true;
                }
            }
        });
        return t;
    }

    /** The one complete pencil of the app (the panel inside it): opens, or closes when it is open. */
    private static void openFullPencil() {
        WinRows.call(app, pkg, "panel", null, null);
    }

    /** After a drag the handle sticks to the nearer side of the screen, and that place is remembered for this app. */
    private static void snapToEdge(View t) {
        try {
            int sw = ctx.getResources().getDisplayMetrics().widthPixels;
            int size = Ui.dp(ctx, 46);
            hlp.x = (hlp.x + size / 2 < sw / 2) ? Ui.dp(ctx, 2) : sw - size - Ui.dp(ctx, 2);
            wm.updateViewLayout(t, hlp);
            int[] pos = POS.get(pkg);
            if (pos != null) {
                pos[0] = hlp.x;
                pos[1] = hlp.y;
            }
        } catch (Throwable ex) {
            // stays where it is
        }
    }
}
