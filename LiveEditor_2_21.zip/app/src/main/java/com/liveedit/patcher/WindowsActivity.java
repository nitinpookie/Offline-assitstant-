package com.liveedit.patcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * "Windows and screens" of one app, with a preview picture of each. For an app that has the Live Editor engine inside, the
 * list is read from the app itself (also windows and screens that are closed right now, with the picture saved earlier) and
 * every window has a Keep switch and an opacity slider. For an app that is not patched yet, the screens found in its
 * manifest are listed (no preview until it is patched with "Live Editor inside the app" and opened once).
 */
public class WindowsActivity extends Activity {

    static final String EXTRA_PKG = "pkg";
    static final String EXTRA_SCREENS = "screens";

    private final Handler h = new Handler(Looper.getMainLooper());
    private String pkg = "";
    private String label = "";
    private String[] manifestScreens = new String[0];
    private boolean engine;
    private boolean resumed;
    private boolean auto;

    private LinearLayout list;
    private TextView status;
    private final java.util.ArrayList<TextView> chips = new java.util.ArrayList<TextView>();
    private int filter;
    private JSONArray lastArr;
    private String lastRaw;

    private final Runnable autoRun = new Runnable() {
        @Override
        public void run() {
            auto = false;
            if (!resumed) return;
            if (!WinRows.touching) refresh();
            auto = true;
            h.postDelayed(this, 3000L);
        }
    };

    private final WinRows.Cmd cmd = new WinRows.Cmd() {
        @Override
        public void run(String method, String arg, Bundle extras) {
            WinRows.call(getApplicationContext(), pkg, method, arg, extras);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        Intent in = getIntent();
        pkg = in == null || in.getStringExtra(EXTRA_PKG) == null ? "" : in.getStringExtra(EXTRA_PKG);
        if (in != null && in.getStringArrayExtra(EXTRA_SCREENS) != null) manifestScreens = in.getStringArrayExtra(EXTRA_SCREENS);
        label = pkg;
        Drawable icon = null;
        try {
            PackageManager pm = getPackageManager();
            label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
            icon = pm.getApplicationIcon(pkg);
        } catch (Throwable t) {
            // not installed: the package name is shown
        }
        engine = PencilPrefs.hasEngine(this, pkg);
        build(icon);
    }

    private LinearLayout.LayoutParams wrap(int rightDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = Ui.dp(this, rightDp);
        return lp;
    }

    private void build(Drawable icon) {
        LinearLayout col = Ui.vbox(this);
        col.setBackgroundColor(Ui.BG);
        col.setPadding(Ui.dp(this, 16), Ui.dp(this, 36), Ui.dp(this, 16), Ui.dp(this, 10));

        LinearLayout head = Ui.hbox(this);
        TextView back = Ui.chip(this, "\u2039 Back");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        head.addView(back, wrap(10));
        if (icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(icon);
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(Ui.dp(this, 32), Ui.dp(this, 32));
            il.rightMargin = Ui.dp(this, 8);
            head.addView(iv, il);
        }
        head.addView(Ui.text(this, label, 19, Ui.TEXT, true), new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(head);
        TextView sub = Ui.text(this, "Windows and screens of this app, each with a preview", 13, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(this, 6), 0, 0);
        col.addView(sub);

        HorizontalScrollView hs1 = new HorizontalScrollView(this);
        hs1.setHorizontalScrollBarEnabled(false);
        LinearLayout row1 = Ui.hbox(this);
        hs1.addView(row1);
        if (engine) {
            TextView refresh = Ui.chip(this, "\u21BB Refresh");
            refresh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    refresh();
                }
            });
            row1.addView(refresh, wrap(8));
            TextView restore = Ui.chip(this, "Restore all removed");
            restore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    WinRows.call(getApplicationContext(), pkg, "restore", null, null);
                    Toast.makeText(WindowsActivity.this, "Bringing back every removed window...", Toast.LENGTH_SHORT)
                            .show();
                    h.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            refresh();
                        }
                    }, 700L);
                }
            });
            row1.addView(restore, wrap(8));
            TextView full = Ui.chip(this, "Full pencil");
            full.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    WinRows.call(getApplicationContext(), pkg, "panel", null, null);
                    openApp(true);
                }
            });
            row1.addView(full, wrap(8));
        }
        TextView open = Ui.chip(this, "Open the app");
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openApp(false);
            }
        });
        row1.addView(open, wrap(8));
        if (engine) {
            TextView bake = Ui.chip(this, "Save and patch");
            bake.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent("com.liveedit.patcher.BAKE");
                    i.setClassName(getPackageName(), MainActivity.class.getName());
                    i.putExtra("pkg", pkg);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                    finish();
                }
            });
            row1.addView(bake, wrap(8));
        }
        Ui.add(col, hs1, 10);

        if (engine) {
            HorizontalScrollView hs2 = new HorizontalScrollView(this);
            hs2.setHorizontalScrollBarEnabled(false);
            LinearLayout row2 = Ui.hbox(this);
            hs2.addView(row2);
            for (int i = 0; i < WinRows.FILTERS.length; i++) {
                final int fi = i;
                TextView c = Ui.chip(this, WinRows.FILTERS[i]);
                WinRows.styleChip(this, c, i == filter);
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        filter = fi;
                        for (int k = 0; k < chips.size(); k++) WinRows.styleChip(WindowsActivity.this, chips.get(k), k == filter);
                        render();
                    }
                });
                chips.add(c);
                row2.addView(c, wrap(8));
            }
            Ui.add(col, hs2, 8);
        }

        status = Ui.text(this, engine ? "Reading the windows..." : "", 12.5f, Ui.SUB, false);
        Ui.add(col, status, 8);

        ScrollView sv = new ScrollView(this);
        list = Ui.vbox(this);
        list.setPadding(0, 0, 0, Ui.dp(this, 30));
        sv.addView(list);
        col.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(col);

        if (!engine) showManifestScreens();
    }

    /** An app without the engine: only the screens from its manifest, no preview yet. */
    private void showManifestScreens() {
        list.removeAllViews();
        if (manifestScreens.length == 0) {
            status.setText("This app has no Live Editor engine inside, so there is no live list. Patch it with \"Live Editor "
                    + "inside the app\", install it and open it: every window and screen then appears here with a preview.");
            return;
        }
        status.setText(manifestScreens.length + " screens found in the app. No preview yet: patch it with \"Live Editor "
                + "inside the app\", open it, and every screen and window gets a picture here.");
        for (int i = 0; i < manifestScreens.length; i++) {
            LinearLayout row = Ui.hbox(this);
            row.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
            row.setBackground(Ui.round(this, Ui.CARD2, 12));
            TextView pic = Ui.text(this, "no preview\nyet", 10, Ui.SUB, false);
            pic.setGravity(Gravity.CENTER);
            pic.setBackground(Ui.round(this, 0xFF22253F, 8));
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(Ui.dp(this, 72), Ui.dp(this, 72));
            pl.rightMargin = Ui.dp(this, 12);
            row.addView(pic, pl);
            String full = manifestScreens[i];
            String shortName = full.substring(full.lastIndexOf('.') + 1);
            LinearLayout c = Ui.vbox(this);
            c.addView(Ui.text(this, "Screen: " + shortName, 14, Ui.TEXT, true));
            c.addView(Ui.text(this, full, 11, Ui.SUB, false));
            row.addView(c, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 8);
            list.addView(row, lp);
        }
    }

    private void openApp(boolean pencilPanelRequested) {
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li != null) {
            startActivity(li);
            if (pencilPanelRequested) {
                Toast.makeText(this, "The full pencil opens inside the app.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "This app has no screen to open", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (engine) {
            refresh();
            if (!auto) {
                auto = true;
                h.postDelayed(autoRun, 3000L);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        h.removeCallbacks(autoRun);
        auto = false;
    }

    private void refresh() {
        if (!engine) return;
        WinRows.fetch(getApplicationContext(), pkg, new WinRows.Result() {
            @Override
            public void got(JSONArray arr, String raw) {
                if (isFinishing() || list == null) return;
                boolean same = raw != null && raw.equals(lastRaw);
                lastArr = arr;
                lastRaw = raw;
                if (!same) render();
            }
        });
    }

    private void render() {
        if (list == null || WinRows.touching) return;
        list.removeAllViews();
        if (lastArr == null) {
            status.setText("Could not read the windows. The app must be patched with Live Editor 2.19 or newer. Tap "
                    + "Open the app once, then Refresh.");
            return;
        }
        int shown = 0;
        for (int i = 0; i < lastArr.length(); i++) {
            JSONObject o = lastArr.optJSONObject(i);
            if (o == null || !WinRows.matches(o, filter)) continue;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 8);
            list.addView(WinRows.row(this, o, cmd), lp);
            shown++;
        }
        if (lastArr.length() == 0) {
            status.setText("No window or screen seen yet. Tap Open the app, use its screens, menus and popups once: they "
                    + "are listed here from then on, even when closed.");
        } else {
            status.setText(shown + " of " + lastArr.length() + " shown. Untick Keep to remove a window (bypassed, never "
                    + "closed). Updates every 3 s.");
        }
    }

    /** Opens the Windows and screens screen of an app. */
    static void open(Activity from, String pkg, String[] manifestScreens) {
        Intent i = new Intent(from, WindowsActivity.class);
        i.putExtra(EXTRA_PKG, pkg);
        if (manifestScreens != null) i.putExtra(EXTRA_SCREENS, manifestScreens);
        from.startActivity(i);
    }

    /** Uri of the app's settings page (used by callers that want to point to it). */
    static Uri appUri(String pkg) {
        return Uri.parse("package:" + pkg);
    }
}
