package com.liveedit.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

/**
 * Per-item choices (size, colour, name, opacity, hidden) for single buttons, menus, icons and texts.
 * "baked" rules come from the APK, "live" rules are the ones edited with the pencil handle.
 * A live rule always wins over a baked rule with the same key.
 */
final class Rules {
    static final int NONE = Integer.MIN_VALUE;

    static final class Rule {
        final String key;
        /** null = automatic; otherwise "menu", "button", "icon" or "line" (window roots only). */
        String kind;
        /** dp. For a window root, "w" is the whole size (width) of that floating window. */
        int w = NONE;
        int h = NONE;
        /** percent 10..100 */
        int alpha = NONE;
        /** text size in dp */
        int text = NONE;
        int textColor = NONE;
        /** background colour (icons: tint) */
        int bgColor = NONE;
        /** thickness in TENTHS of a dp of a thin line (smaller side), may be thinner or thicker than the original */
        int thick = NONE;
        String name;
        boolean hide;
        /** No beep: the sound this item (and what is inside it) makes is switched to volume 0. */
        boolean quiet;
        /** Auto-off timer: never. After this button is touched, the delayed jobs the app starts are cancelled. */
        boolean manual;
        /** A picture (PNG, any size, base64) that replaces the icon of this item. null = keep the app's icon. */
        String icon;

        Rule(String key) {
            this.key = key;
        }

        boolean isEmpty() {
            return kind == null && w == NONE && h == NONE && alpha == NONE && text == NONE
                    && textColor == NONE && bgColor == NONE && thick == NONE && name == null && !hide && !quiet
                    && !manual && icon == null;
        }

        Rule copy() {
            Rule r = new Rule(key);
            r.kind = kind;
            r.w = w;
            r.h = h;
            r.alpha = alpha;
            r.text = text;
            r.textColor = textColor;
            r.bgColor = bgColor;
            r.thick = thick;
            r.name = name;
            r.hide = hide;
            r.quiet = quiet;
            r.manual = manual;
            r.icon = icon;
            return r;
        }

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("k", key);
            if (kind != null) o.put("kd", kind);
            if (w != NONE) o.put("w", w);
            if (h != NONE) o.put("h", h);
            if (alpha != NONE) o.put("a", alpha);
            if (text != NONE) o.put("t", text);
            if (textColor != NONE) o.put("tc", textColor);
            if (bgColor != NONE) o.put("bc", bgColor);
            if (thick != NONE) o.put("tt", thick);
            if (name != null) o.put("n", name);
            if (hide) o.put("hd", true);
            if (quiet) o.put("q", true);
            if (manual) o.put("mn", true);
            if (icon != null) o.put("ic", icon);
            return o;
        }

        static Rule fromJson(JSONObject o) {
            String k = o.optString("k", "");
            if (k.length() == 0) return null;
            Rule r = new Rule(k);
            r.kind = o.has("kd") ? o.optString("kd") : null;
            r.w = o.has("w") ? o.optInt("w") : NONE;
            r.h = o.has("h") ? o.optInt("h") : NONE;
            r.alpha = o.has("a") ? o.optInt("a") : NONE;
            r.text = o.has("t") ? o.optInt("t") : NONE;
            r.textColor = o.has("tc") ? o.optInt("tc") : NONE;
            r.bgColor = o.has("bc") ? o.optInt("bc") : NONE;
            // thickness: "tt" is tenths of a dp, old "th" was whole dp
            r.thick = o.has("tt") ? o.optInt("tt") : (o.has("th") ? o.optInt("th") * 10 : NONE);
            r.name = o.has("n") ? o.optString("n") : null;
            r.hide = o.optBoolean("hd", false);
            r.quiet = o.optBoolean("q", false);
            r.manual = o.optBoolean("mn", false);
            r.icon = o.has("ic") ? o.optString("ic", null) : null;
            if (r.icon != null && r.icon.length() == 0) r.icon = null;
            return r;
        }
    }

    private static final HashMap<String, Rule> baked = new HashMap<String, Rule>();
    private static final HashMap<String, Rule> live = new HashMap<String, Rule>();

    private Rules() {}

    static void loadBaked(JSONArray a) {
        baked.clear();
        fill(baked, a);
    }

    static void loadLive(JSONArray a) {
        live.clear();
        fill(live, a);
    }

    private static void fill(HashMap<String, Rule> into, JSONArray a) {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            Rule r = Rule.fromJson(o);
            if (r != null) into.put(r.key, r);
        }
    }

    static boolean hasAny() {
        return !baked.isEmpty() || !live.isEmpty();
    }

    /** Safety after a crash: every "removed" window / item comes back (the rules stay, only the removal is undone). */
    static void clearHides() {
        for (Rule r : baked.values()) r.hide = false;
        for (Rule r : live.values()) r.hide = false;
    }

    /** Brings back every removed window (also the ones removed in the APK itself: a live rule overrides the baked one). */
    static void showAll() {
        java.util.ArrayList<String> keys = new java.util.ArrayList<String>();
        for (Rule r : baked.values()) {
            if (r.hide) keys.add(r.key);
        }
        for (Rule r : live.values()) r.hide = false;
        for (int i = 0; i < keys.size(); i++) edit(keys.get(i)).hide = false;
    }

    /** The rule that applies to this item, or null when nothing is set for it. */
    static Rule get(String key) {
        Rule r = live.get(key);
        if (r == null) r = baked.get(key);
        return (r == null || r.isEmpty()) ? null : r;
    }

    /** A rule that can be changed (it is stored with the live edits). */
    static Rule edit(String key) {
        Rule r = live.get(key);
        if (r == null) {
            Rule b = baked.get(key);
            r = b == null ? new Rule(key) : b.copy();
            live.put(key, r);
        }
        return r;
    }

    static void clearLive() {
        live.clear();
    }

    /**
     * Lines that start at the same origin must all have the same width, so a thickness is never kept for one single
     * line: the one global line thickness is used, and every per-item thickness is dropped.
     */
    static void clearThick() {
        for (String k : new java.util.ArrayList<String>(baked.keySet())) {
            Rule b = baked.get(k);
            if (b != null && b.thick != NONE) edit(k).thick = NONE;
        }
        for (Rule r : live.values()) r.thick = NONE;
    }

    /** Forget every rule (also the ones from the APK) until the app is restarted. */
    static void resetAll() {
        live.clear();
        for (String k : baked.keySet()) live.put(k, new Rule(k));
    }

    static JSONArray liveArray() throws Exception {
        JSONArray a = new JSONArray();
        for (Rule r : live.values()) a.put(r.toJson());
        return a;
    }

    /** Baked rules with live edits on top, empty ones left out. */
    static JSONArray mergedArray() throws Exception {
        HashMap<String, Rule> m = new HashMap<String, Rule>(baked);
        m.putAll(live);
        JSONArray a = new JSONArray();
        for (Rule r : m.values()) {
            if (!r.isEmpty()) a.put(r.toJson());
        }
        return a;
    }
}
