package com.liveedit.agent;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * The choices made in the Live Editor app while patching. They are stored inside the patched APK
 * as assets/liveedit_config.json. In "live" mode the pencil handle can change them while the app runs;
 * those edits are kept in the app's private folder and can be exported to build a normal APK.
 */
final class Config {
    private static final String LIVE_FILE = "liveedit_live.json";

    static boolean present;
    /** The pencil handle (live editor) is inside this app. */
    static boolean live;

    /**
     * Sizes are percent of each window's own original size: 100 = original, never smaller. Text size is also percent
     * (100 = original). Three separate groups: menu icon (the launcher), floating buttons, menu panels.
     */
    static int iconPct = 100;
    static int iconAlpha = 100;
    static int iconTextPct = 100;
    static int btnPct = 100;
    static int btnAlpha = 100;
    static int btnTextPct = 100;
    static int menuPct = 100;
    static int menuAlpha = 100;
    static int menuTextPct = 100;
    /**
     * Sizes in dp: when not 0, every window of that group gets exactly this width (its height follows the same ratio).
     * 0 = use the percent above (old settings) / keep the original.
     */
    static int iconDp;
    static int btnDp;
    static int menuDp;
    /** Text size change in dp (-20 .. +40) added to the text of every window of the group. 0 = original. */
    static int iconTextDp;
    static int btnTextDp;
    static int menuTextDp;
    /** Thickness of line overlays in TENTHS of a dp (5 = 0.5 dp, 0 = keep). May be thinner or thicker than the original. */
    static int lineT;
    /** Turn off the click sound effect of every view. */
    static boolean mute;
    static boolean keepOn;
    /** Remove the "no screenshots" flag. */
    static boolean allowShot;
    static boolean immersive;
    static boolean hideAds;
    /** Always blocks this app's own Play Store / update-check links and servers, whatever "Links" is set to. */
    static boolean neverUpdate;
    /** 0 normal, 1 faster, 2 off. */
    static int anim;
    /** Servers (and their sub-domains) the app may not reach. */
    static String[] hosts = new String[0];
    /** 0 keep, 1 block links that open at app start (first 30 s), 2 block all links that leave the app. */
    static int links;
    /** 0 keep, 1 hide timer texts, 2 replace timer texts with timerText. */
    static int timers;
    static String timerText = "";
    /** Best-effort mode for apps whose native libraries do not fit this CPU: keep the app alive when they are missing. */
    static boolean guard;

    static boolean themeOn;
    static int themeBg = 0xFF101418;
    static int themeText = 0xFFECEFF4;
    static int themeAccent = 0xFF7C5CFF;

    private Config() {}

    static void resetLook() {
        iconPct = 100;
        iconAlpha = 100;
        iconTextPct = 100;
        btnPct = 100;
        btnAlpha = 100;
        btnTextPct = 100;
        menuPct = 100;
        menuAlpha = 100;
        menuTextPct = 100;
        iconDp = 0;
        btnDp = 0;
        menuDp = 0;
        iconTextDp = 0;
        btnTextDp = 0;
        menuTextDp = 0;
        lineT = 0;
    }

    private static void defaults() {
        live = false;
        resetLook();
        mute = false;
        keepOn = false;
        allowShot = false;
        immersive = false;
        hideAds = false;
        neverUpdate = false;
        anim = 0;
        hosts = new String[0];
        links = 0;
        timers = 0;
        timerText = "";
        guard = false;
        themeOn = false;
        themeBg = 0xFF101418;
        themeText = 0xFFECEFF4;
        themeAccent = 0xFF7C5CFF;
    }

    static void load(Context c) {
        try {
            InputStream in = c.getAssets().open("liveedit_config.json");
            JSONObject o = new JSONObject(new String(readAll(in), StandardCharsets.UTF_8));
            defaults();
            live = o.optBoolean("live", false);
            readLook(o);
            mute = o.optBoolean("mute", false);
            keepOn = o.optBoolean("keepOn", false);
            allowShot = o.optBoolean("allowShot", false);
            immersive = o.optBoolean("immersive", false);
            hideAds = o.optBoolean("hideAds", false);
            neverUpdate = o.optBoolean("neverUpdate", false);
            anim = U.clamp(o.optInt("anim", 0), 0, 2);
            links = U.clamp(o.optInt("links", 0), 0, 2);
            timers = U.clamp(o.optInt("timers", 0), 0, 2);
            timerText = o.optString("timerText", "");
            guard = o.optBoolean("guard", false);
            JSONArray h = o.optJSONArray("block");
            ArrayList<String> list = new ArrayList<String>();
            if (h != null) {
                for (int i = 0; i < h.length(); i++) {
                    String s = h.optString(i, "").trim();
                    if (s.length() > 0) list.add(s);
                }
            }
            hosts = list.toArray(new String[list.size()]);
            Rules.loadBaked(o.optJSONArray("rules"));
            present = true;
        } catch (Throwable t) {
            present = false;
        }
    }

    /** Size, opacity, text size and theme: the part that the pencil handle can change. */
    private static void readLook(JSONObject o) {
        iconPct = U.clamp(o.optInt("iconPct", iconPct), 20, 500);
        iconAlpha = U.clamp(o.optInt("iconAlpha", iconAlpha), 10, 100);
        iconTextPct = U.clamp(o.optInt("iconTextPct", iconTextPct), 50, 400);
        btnPct = U.clamp(o.optInt("btnPct", btnPct), 20, 500);
        btnAlpha = U.clamp(o.optInt("btnAlpha", btnAlpha), 10, 100);
        btnTextPct = U.clamp(o.optInt("btnTextPct", btnTextPct), 50, 400);
        menuPct = U.clamp(o.optInt("menuPct", menuPct), 20, 500);
        menuAlpha = U.clamp(o.optInt("menuAlpha", menuAlpha), 10, 100);
        menuTextPct = U.clamp(o.optInt("menuTextPct", menuTextPct), 50, 400);
        iconDp = U.clamp(o.optInt("iconDp", iconDp), 0, 900);
        btnDp = U.clamp(o.optInt("btnDp", btnDp), 0, 900);
        menuDp = U.clamp(o.optInt("menuDp", menuDp), 0, 1200);
        iconTextDp = U.clamp(o.optInt("iconTextDp", iconTextDp), -20, 60);
        btnTextDp = U.clamp(o.optInt("btnTextDp", btnTextDp), -20, 60);
        menuTextDp = U.clamp(o.optInt("menuTextDp", menuTextDp), -20, 60);
        // thickness: new key in tenths of a dp; old settings had whole dp
        if (o.has("lineT")) lineT = U.clamp(o.optInt("lineT", lineT), 0, 600);
        else if (o.has("lineDp")) lineT = U.clamp(o.optInt("lineDp", 0) * 10, 0, 600);
        JSONObject th = o.optJSONObject("theme");
        if (th != null) {
            themeOn = th.optBoolean("on", themeOn);
            themeBg = th.optInt("bg", themeBg) | 0xFF000000;
            themeText = th.optInt("text", themeText) | 0xFF000000;
            themeAccent = th.optInt("accent", themeAccent) | 0xFF000000;
        }
    }

    private static void writeLook(JSONObject o) throws Exception {
        o.put("iconPct", iconPct);
        o.put("iconAlpha", iconAlpha);
        o.put("iconTextPct", iconTextPct);
        o.put("btnPct", btnPct);
        o.put("btnAlpha", btnAlpha);
        o.put("btnTextPct", btnTextPct);
        o.put("menuPct", menuPct);
        o.put("menuAlpha", menuAlpha);
        o.put("menuTextPct", menuTextPct);
        o.put("iconDp", iconDp);
        o.put("btnDp", btnDp);
        o.put("menuDp", menuDp);
        o.put("iconTextDp", iconTextDp);
        o.put("btnTextDp", btnTextDp);
        o.put("menuTextDp", menuTextDp);
        o.put("lineT", lineT);
        JSONObject th = new JSONObject();
        th.put("on", themeOn);
        th.put("bg", themeBg);
        th.put("text", themeText);
        th.put("accent", themeAccent);
        o.put("theme", th);
    }

    // ---- live edits -------------------------------------------------------------------------

    static void loadLive(Context c) {
        try {
            File f = new File(c.getFilesDir(), LIVE_FILE);
            if (!f.exists()) return;
            JSONObject o = new JSONObject(new String(readAll(new FileInputStream(f)), StandardCharsets.UTF_8));
            JSONObject g = o.optJSONObject("g");
            if (g != null) readLook(g);
            Rules.loadLive(o.optJSONArray("rules"));
            Overlays.loadSeen(o.optJSONArray("seen"));
        } catch (Throwable t) {
            U.err("cannot read live edits", t);
        }
    }

    static void saveLive(Context c) {
        if (!live) return;
        try {
            JSONObject o = new JSONObject();
            JSONObject g = new JSONObject();
            writeLook(g);
            o.put("g", g);
            o.put("rules", Rules.liveArray());
            o.put("seen", Overlays.seenArray());
            FileOutputStream out = new FileOutputStream(new File(c.getFilesDir(), LIVE_FILE));
            try {
                out.write(o.toString().getBytes(StandardCharsets.UTF_8));
            } finally {
                out.close();
            }
        } catch (Throwable t) {
            U.err("cannot save live edits", t);
        }
    }

    /**
     * Applies a pasted settings text (the same text "Copy settings" makes, or just the few keys that should change)
     * to the running app and keeps it. Returns an empty string when it worked, otherwise the reason.
     */
    static String importPasted(Context c, String text) {
        try {
            int fb = text.indexOf('{'), lb = text.lastIndexOf('}');
            if (fb < 0 || lb <= fb) return "no settings found in the clipboard";
            JSONObject o = new JSONObject(text.substring(fb, lb + 1));
            readLook(o);
            if (o.has("mute")) mute = o.optBoolean("mute", mute);
            if (o.has("timers")) timers = U.clamp(o.optInt("timers", timers), 0, 2);
            if (o.has("timerText")) timerText = o.optString("timerText", timerText);
            if (o.has("rules")) Rules.loadLive(o.optJSONArray("rules"));
            saveLive(c);
            return "";
        } catch (Throwable t) {
            return String.valueOf(t);
        }
    }

    /** Forget every live edit and go back to what is baked into the APK. */
    static void resetLive(Context c) {
        try {
            new File(c.getFilesDir(), LIVE_FILE).delete();
        } catch (Throwable t) {
            // ignore
        }
        Rules.clearLive();
        load(c);
    }

    /** All current settings as one JSON text (for "Copy settings", to build a normal APK from it). */
    static String exportJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("v", 3);
            o.put("live", false);
            writeLook(o);
            o.put("mute", mute);
            o.put("keepOn", keepOn);
            o.put("allowShot", allowShot);
            o.put("immersive", immersive);
            o.put("hideAds", hideAds);
            o.put("anim", anim);
            o.put("links", links);
            o.put("timers", timers);
            o.put("timerText", timerText);
            JSONArray b = new JSONArray();
            for (int i = 0; i < hosts.length; i++) b.put(hosts[i]);
            o.put("block", b);
            o.put("rules", Rules.mergedArray());
            return o.toString();
        } catch (Throwable t) {
            U.err("export", t);
            return "{}";
        }
    }

    // ---- what is needed -----------------------------------------------------------------------

    static boolean needsTicker() {
        return live || iconPct != 100 || iconAlpha < 100 || iconTextPct != 100 || btnPct != 100 || btnAlpha < 100
                || btnTextPct != 100 || menuPct != 100 || menuAlpha < 100 || menuTextPct != 100 || lineT != 0
                || iconDp != 0 || btnDp != 0 || menuDp != 0 || iconTextDp != 0 || btnTextDp != 0 || menuTextDp != 0
                || mute || themeOn || timers != 0 || Rules.hasAny();
    }

    static boolean needsActivityHooks() {
        return keepOn || allowShot || immersive || hideAds || themeOn || timers != 0 || Rules.hasAny() || live;
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            in.close();
        }
        return out.toByteArray();
    }
}
