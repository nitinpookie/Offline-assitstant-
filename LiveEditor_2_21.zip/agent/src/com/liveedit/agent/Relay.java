package com.liveedit.agent;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Display;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;

import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.List;

/**
 * The "small display" of the Live Editor app: when this app is started on a display that Live Editor owns, its screen is
 * shown inside Live Editor and the fingers on that small picture come here (the engine lives inside this app, so it can hand
 * a touch to the app's own views without any special permission). Everything runs on the main thread of this app and
 * never throws: a bad touch is dropped.
 */
final class Relay {

    private static long downTime;
    private static WeakReference<View> target;
    private static int targetDisplay = -1;
    private static int offX;
    private static int offY;

    private Relay() {}

    /** On which display is the app's screen right now, and how big is that display ("{}" when no screen is open). */
    static String where() throws Exception {
        JSONObject o = new JSONObject();
        Activity a = Agent.topActivity();
        if (a == null) return o.toString();
        Display d = null;
        try {
            d = a.getWindowManager().getDefaultDisplay();
        } catch (Throwable t) {
            // fall through: no display known
        }
        if (d == null) return o.toString();
        android.graphics.Point p = new android.graphics.Point();
        try {
            d.getRealSize(p);
        } catch (Throwable t) {
            // size stays 0
        }
        o.put("id", d.getDisplayId());
        o.put("w", p.x);
        o.put("h", p.y);
        o.put("act", a.getClass().getName());
        return o.toString();
    }

    /** The Back key of the small display. */
    static String back() {
        Activity a = Agent.topActivity();
        if (a == null) return "no screen";
        try {
            a.onBackPressed();
            return "ok";
        } catch (Throwable t) {
            return "failed";
        }
    }

    /**
     * extras: act (masked action), idx (action index), n (pointer count), ids, xs, ys (pixels of the small display), disp
     * (the display id the fingers are on). The window under the first finger gets the whole gesture.
     */
    static void touch(Bundle e) {
        if (e == null) return;
        int act = e.getInt("act", -1);
        int n = e.getInt("n", 0);
        int idx = e.getInt("idx", 0);
        int disp = e.getInt("disp", 0);
        int[] ids = e.getIntArray("ids");
        float[] xs = e.getFloatArray("xs");
        float[] ys = e.getFloatArray("ys");
        if (act < 0 || n < 1 || ids == null || xs == null || ys == null) return;
        if (ids.length < n || xs.length < n || ys.length < n) return;

        long now = SystemClock.uptimeMillis();
        if (act == MotionEvent.ACTION_DOWN) {
            downTime = now;
            View t = pick(disp, xs[0], ys[0]);
            target = t == null ? null : new WeakReference<View>(t);
            targetDisplay = disp;
            if (t != null) {
                int[] loc = new int[2];
                try {
                    t.getLocationOnScreen(loc);
                } catch (Throwable x) {
                    loc[0] = 0;
                    loc[1] = 0;
                }
                offX = loc[0];
                offY = loc[1];
            }
        }
        View v = target == null ? null : target.get();
        if (v == null || !v.isAttachedToWindow()) return;

        MotionEvent.PointerProperties[] pp = new MotionEvent.PointerProperties[n];
        MotionEvent.PointerCoords[] pc = new MotionEvent.PointerCoords[n];
        for (int i = 0; i < n; i++) {
            pp[i] = new MotionEvent.PointerProperties();
            pp[i].id = ids[i];
            pp[i].toolType = MotionEvent.TOOL_TYPE_FINGER;
            pc[i] = new MotionEvent.PointerCoords();
            pc[i].x = xs[i] - offX;
            pc[i].y = ys[i] - offY;
            pc[i].pressure = 1f;
            pc[i].size = 1f;
        }
        int action = act;
        if (act == MotionEvent.ACTION_POINTER_DOWN || act == MotionEvent.ACTION_POINTER_UP) {
            action = act | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT);
        }
        MotionEvent ev = MotionEvent.obtain(downTime, now, action, n, pp, pc, 0, 0, 1f, 1f, 0, 0,
                InputDevice.SOURCE_TOUCHSCREEN, 0);
        try {
            v.dispatchTouchEvent(ev);
        } finally {
            ev.recycle();
        }
        if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) target = null;
    }

    /** The topmost window of this app on that display that covers the point; else the screen of the app. */
    private static View pick(int disp, float x, float y) {
        View best = null;
        try {
            List<View> all = Overlays.roots();
            for (int i = all.size() - 1; i >= 0; i--) {
                View r = all.get(i);
                if (r == null || !r.isShown() || r.getWidth() <= 0 || r.getHeight() <= 0) continue;
                Display d = r.getDisplay();
                if (d == null || d.getDisplayId() != disp) continue;
                int[] loc = new int[2];
                r.getLocationOnScreen(loc);
                if (x >= loc[0] && x < loc[0] + r.getWidth() && y >= loc[1] && y < loc[1] + r.getHeight()) {
                    if (Overlays.isOverlay(r) && r.getLayoutParams() != null
                            && (((android.view.WindowManager.LayoutParams) r.getLayoutParams()).flags
                            & android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) != 0) {
                        continue; // a window that lets touches through (removed windows, line layers)
                    }
                    return r;
                }
                if (best == null) best = r;
            }
        } catch (Throwable t) {
            // use the screen of the app
        }
        if (best != null) return best;
        return Agent.topDecor();
    }
}
