package com.liveedit.agent;

import android.app.Application;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;

/**
 * Tells the Live Editor app that this (patched) app is on screen, so Live Editor can show its pencil on top of it. There is
 * exactly ONE pencil: the one of Live Editor, on top of every patched app, switched on and off in Live Editor. This app's own
 * pencil is only a fallback for when Live Editor cannot show its pencil (not installed, or no "Display over other apps"
 * permission yet); it never shows together with the Live Editor pencil and never while Live Editor says the pencil is OFF.
 * Runs on its own thread; a missing Live Editor, a refusal or a slow answer never touches the app.
 */
final class HostLink {

    private static final String HOST = "content://com.liveedit.patcher.host";

    /** What Live Editor said last. */
    static final int UNKNOWN = 0;   // no answer yet: no pencil at all for a moment, so two never show together
    static final int SHOWN = 1;     // Live Editor shows its pencil over this app
    static final int OFF = 2;       // the pencil switch of Live Editor is OFF: no pencil
    static final int NO_PERMISSION = 3; // Live Editor is there but may not draw over other apps: use the in-app pencil
    static final int ABSENT = 4;    // Live Editor is not installed (or does not answer): use the in-app pencil

    /** True while the Live Editor app is showing its pencil over this app. */
    static volatile boolean hostShown;
    static volatile int mode = UNKNOWN;

    private static volatile boolean busy;
    private static long lastBeat;
    private static boolean wasFg;
    private static int fails;
    private static long pausedUntil;
    private static long firstTick;

    private HostLink() {}

    /** May this app's own pencil show? Only when Live Editor cannot show the one pencil (never while it is OFF). */
    static boolean ownAllowed() {
        int m = mode;
        if (m == NO_PERMISSION || m == ABSENT) return true;
        // no answer after a few seconds: take it that Live Editor is not there
        return m == UNKNOWN && firstTick != 0 && SystemClock.uptimeMillis() - firstTick > 5000L;
    }

    /** Called from the 0.7 s tick of the engine. fg = an app screen is on screen right now. */
    static void tick(final Application app, boolean fg) {
        long now = SystemClock.uptimeMillis();
        if (firstTick == 0) firstTick = now;
        // while Live Editor shows its pencil, keep a small picture of every window and screen for the previews
        if (fg && hostShown) {
            try {
                Overlays.cacheThumbs(app);
            } catch (Throwable t) {
                // previews are a bonus
            }
        }
        if (busy || now < pausedUntil) return;
        final String method;
        if (fg) {
            if (now - lastBeat < 1500L) return;
            method = "fg";
        } else if (wasFg) {
            method = "bg";
        } else {
            return;
        }
        lastBeat = now;
        wasFg = fg;
        busy = true;
        final String pkg = app.getPackageName();
        // how many floating windows the app has: when it grows, the pencil of Live Editor puts itself on top again
        final Bundle extras = new Bundle();
        try {
            extras.putInt("n", fg ? Overlays.overlayCount() : 0);
        } catch (Throwable t) {
            // the count is a bonus
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Bundle b = app.getContentResolver().call(Uri.parse(HOST), method, pkg, extras);
                    if (b == null) {
                        hostShown = false;
                        noteFail();
                    } else {
                        fails = 0;
                        if ("fg".equals(method)) {
                            boolean shown = b.getBoolean("shown", false);
                            String why = b.getString("why", "");
                            hostShown = shown;
                            mode = shown ? SHOWN : "off".equals(why) ? OFF : "noperm".equals(why) ? NO_PERMISSION
                                    : (mode == UNKNOWN ? NO_PERMISSION : mode);
                        } else {
                            hostShown = false;
                        }
                    }
                } catch (Throwable t) {
                    hostShown = false;
                    noteFail();
                } finally {
                    busy = false;
                }
            }
        }, "liveedit-host").start();
    }

    private static void noteFail() {
        if (++fails >= 2) {
            mode = ABSENT; // Live Editor is gone or does not answer: the in-app pencil takes over
        }
        if (fails >= 3) {
            fails = 0;
            pausedUntil = SystemClock.uptimeMillis() + 20000L; // Live Editor is not there: try again in 20 s
        }
    }
}
