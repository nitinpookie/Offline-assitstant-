package com.liveedit.agent;

import android.app.Application;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;

/**
 * Tells the Live Editor app that this (recently patched) app is on screen, so Live Editor can show its pencil as an
 * overlay above it. Runs on its own thread; a missing Live Editor, a refusal or a slow answer never touches the app.
 * While Live Editor shows the pencil ({@link #hostShown}), this app's own pencil stays away.
 */
final class HostLink {

    private static final String HOST = "content://com.liveedit.patcher.host";

    /** True while the Live Editor app is showing its pencil over this app. */
    static volatile boolean hostShown;

    private static volatile boolean busy;
    private static long lastBeat;
    private static boolean wasFg;
    private static int fails;
    private static long pausedUntil;

    private HostLink() {}

    /** Called from the 0.7 s tick of the engine. fg = an app screen is on screen right now. */
    static void tick(final Application app, boolean fg) {
        long now = SystemClock.uptimeMillis();
        // while Live Editor shows its pencil, keep a small picture of every window and screen for the previews
        if (fg && hostShown) {
            try {
                Overlays.cacheThumbs(app);
            } catch (Throwable t) {
                // previews are a bonus
            }
        }
        if (busy || now < pausedUntil) return;
        final String method;
        if (fg) {
            if (now - lastBeat < 1500L) return;
            method = "fg";
        } else if (wasFg) {
            method = "bg";
        } else {
            return;
        }
        lastBeat = now;
        wasFg = fg;
        busy = true;
        final String pkg = app.getPackageName();
        // how many floating windows the app has: when it grows, the pencil of Live Editor puts itself on top again
        final Bundle extras = new Bundle();
        try {
            extras.putInt("n", fg ? Overlays.overlayCount() : 0);
        } catch (Throwable t) {
            // the count is a bonus
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Bundle b = app.getContentResolver().call(Uri.parse(HOST), method, pkg, extras);
                    if (b == null) {
                        hostShown = false;
                        noteFail();
                    } else {
                        fails = 0;
                        hostShown = "fg".equals(method) && b.getBoolean("shown", false);
                    }
                } catch (Throwable t) {
                    hostShown = false;
                    noteFail();
                } finally {
                    busy = false;
                }
            }
        }, "liveedit-host").start();
    }

    private static void noteFail() {
        if (++fails >= 3) {
            fails = 0;
            pausedUntil = SystemClock.uptimeMillis() + 20000L; // Live Editor is not there: try again in 20 s
        }
    }
}
