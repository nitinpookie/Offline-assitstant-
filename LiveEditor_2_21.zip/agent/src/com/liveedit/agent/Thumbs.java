package com.liveedit.agent;

import android.content.Context;
import android.graphics.Bitmap;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * Small pictures (JPEG) of the windows and screens of this app, kept in the app's own files folder. They let the Live
 * Editor app show a preview of a window or screen that is closed right now. Nothing here may ever throw.
 */
final class Thumbs {

    private static final String DIR = "liveedit_thumbs";

    private Thumbs() {}

    private static File file(Context c, String key) {
        File d = new File(c.getFilesDir(), DIR);
        if (!d.exists()) d.mkdirs();
        return new File(d, Integer.toHexString(key.hashCode()) + "_" + key.length() + ".jpg");
    }

    /** Saves a picture of the window with this list key (at most about 160 px on the long side). */
    static void put(Context c, String key, Bitmap b) {
        if (key == null || key.length() == 0 || b == null || b.isRecycled()) return;
        try {
            byte[] jpg = jpeg(b, 160, 78);
            if (jpg == null || jpg.length > 30000) return;
            FileOutputStream out = new FileOutputStream(file(c, key));
            try {
                out.write(jpg);
            } finally {
                out.close();
            }
        } catch (Throwable t) {
            // no picture for this one
        }
    }

    /** The saved picture (JPEG bytes) of this window, or null. */
    static byte[] get(Context c, String key) {
        if (key == null || key.length() == 0) return null;
        try {
            File f = file(c, key);
            if (!f.exists() || f.length() > 40000) return null;
            byte[] buf = new byte[(int) f.length()];
            FileInputStream in = new FileInputStream(f);
            try {
                int off = 0;
                while (off < buf.length) {
                    int n = in.read(buf, off, buf.length - off);
                    if (n < 0) break;
                    off += n;
                }
            } finally {
                in.close();
            }
            return buf;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Scales a picture down to maxEdge pixels on its long side and makes JPEG bytes of it. */
    static byte[] jpeg(Bitmap b, int maxEdge, int quality) {
        try {
            Bitmap sc = b;
            int mx = Math.max(b.getWidth(), b.getHeight());
            if (mx > maxEdge) {
                float f = (float) maxEdge / mx;
                sc = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * f)),
                        Math.max(1, Math.round(b.getHeight() * f)), true);
            }
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            sc.compress(Bitmap.CompressFormat.JPEG, quality, bo);
            if (sc != b) sc.recycle();
            return bo.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }
}
