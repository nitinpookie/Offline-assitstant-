package com.liveedit.agent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

/**
 * Per-item choices (size, colour, name, opacity, hidden) for single buttons, menus, icons and texts.
 * "baked" rules come from the APK, "live" rules are the ones edited with the pencil handle.
 * A live rule always wins over a baked rule with the same key.
 */
final class Rules {
    static final int NONE = Integer.MIN_VALUE;

    static final class Rule {
        final String key;
        /** null = automatic; otherwise "menu", "button", "icon" or "line" (window roots only). */
        String kind;
        /** dp. For a window root, "w" is the whole size (width) of that floating window. */
        int w = NONE;
        int h = NONE;
        /** percent 10..100 */
        int alpha = NONE;
        /** text size in dp */
        int text = NONE;
        int textColor = NONE;
        /** background colour (icons: tint) */
        int bgColor = NONE;
        /** thickness in TENTHS of a dp of a thin line (smaller side), may be thinner or thicker than the original */
        int thick = NONE;
        String name;
        boolean hide;
        /** Auto on/off timer in ms (both > 0 = active): the item is clicked ON, stays on tOn, clicked OFF, stays off tOff, repeat. */
        int tOn = NONE;
        int tOff = NONE;
        /** The button is already ON when the timer starts (only matters for buttons that are not switches / checkboxes). */
        boolean tIsOn;
        /** Same item without its text (the text of a toggle changes), used by the timer to find the button again. */
        String lk;

        Rule(String key) {
            this.key = key;
        }

        boolean isEmpty() {
            return kind == null && w == NONE && h == NONE && alpha == NONE && text == NONE
                    && textColor == NONE && bgColor == NONE && thick == NONE && name == null && !hide
                    && !timerOn();
        }

        boolean timerOn() {
            return tOn != NONE && tOn > 0 && tOff != NONE && tOff > 0;
        }

        Rule copy() {
            Rule r = new Rule(key);
            r.kind = kind;
            r.w = w;
            r.h = h;
            r.alpha = alpha;
            r.text = text;
            r.textColor = textColor;
            r.bgColor = bgColor;
            r.thick = thick;
            r.name = name;
            r.hide = hide;
            r.tOn = tOn;
            r.tOff = tOff;
            r.tIsOn = tIsOn;
            r.lk = lk;
            return r;
        }

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("k", key);
            if (kind != null) o.put("kd", kind);
            if (w != NONE) o.put("w", w);
            if (h != NONE) o.put("h", h);
            if (alpha != NONE) o.put("a", alpha);
            if (text != NONE) o.put("t", text);
            if (textColor != NONE) o.put("tc", textColor);
            if (bgColor != NONE) o.put("bc", bgColor);
            if (thick != NONE) o.put("tt", thick);
            if (name != null) o.put("n", name);
            if (hide) o.put("hd", true);
            if (tOn != NONE) o.put("ton", tOn);
            if (tOff != NONE) o.put("toff", tOff);
            if (tIsOn) o.put("tio", true);
            if (lk != null) o.put("lk", lk);
            return o;
        }

        static Rule fromJson(JSONObject o) {
            String k = o.optString("k", "");
            if (k.length() == 0) return null;
            Rule r = new Rule(k);
            r.kind = o.has("kd") ? o.optString("kd") : null;
            r.w = o.has("w") ? o.optInt("w") : NONE;
            r.h = o.has("h") ? o.optInt("h") : NONE;
            r.alpha = o.has("a") ? o.optInt("a") : NONE;
            r.text = o.has("t") ? o.optInt("t") : NONE;
            r.textColor = o.has("tc") ? o.optInt("tc") : NONE;
            r.bgColor = o.has("bc") ? o.optInt("bc") : NONE;
            // thickness: "tt" is tenths of a dp, old "th" was whole dp
            r.thick = o.has("tt") ? o.optInt("tt") : (o.has("th") ? o.optInt("th") * 10 : NONE);
            r.name = o.has("n") ? o.optString("n") : null;
            r.hide = o.optBoolean("hd", false);
            r.tOn = o.has("ton") ? o.optInt("ton") : NONE;
            r.tOff = o.has("toff") ? o.optInt("toff") : NONE;
            r.tIsOn = o.optBoolean("tio", false);
            r.lk = o.has("lk") ? o.optString("lk") : null;
            return r;
        }
    }

    private static final HashMap<String, Rule> baked = new HashMap<String, Rule>();
    private static final HashMap<String, Rule> live = new HashMap<String, Rule>();

    private Rules() {}

    static void loadBaked(JSONArray a) {
        baked.clear();
        fill(baked, a);
    }

    static void loadLive(JSONArray a) {
        live.clear();
        fill(live, a);
    }

    private static void fill(HashMap<String, Rule> into, JSONArray a) {
        if (a == null) return;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            Rule r = Rule.fromJson(o);
            if (r != null) into.put(r.key, r);
        }
    }

    static boolean hasAny() {
        return !baked.isEmpty() || !live.isEmpty();
    }

    /** Every rule (live ones win) that has an auto on/off timer. */
    static java.util.List<Rule> timerRules() {
        HashMap<String, Rule> m = new HashMap<String, Rule>(baked);
        m.putAll(live);
        java.util.ArrayList<Rule> out = new java.util.ArrayList<Rule>();
        for (Rule r : m.values()) {
            if (r.timerOn()) out.add(r);
        }
        return out;
    }

    /** Safety after a crash: every "removed" window / item comes back (the rules stay, only the removal is undone). */
    static void clearHides() {
        for (Rule r : baked.values()) r.hide = false;
        for (Rule r : live.values()) r.hide = false;
    }

    /** The rule that applies to this item, or null when nothing is set for it. */
    static Rule get(String key) {
        Rule r = live.get(key);
        if (r == null) r = baked.get(key);
        return (r == null || r.isEmpty()) ? null : r;
    }

    /** A rule that can be changed (it is stored with the live edits). */
    static Rule edit(String key) {
        Rule r = live.get(key);
        if (r == null) {
            Rule b = baked.get(key);
            r = b == null ? new Rule(key) : b.copy();
            live.put(key, r);
        }
        return r;
    }

    static void clearLive() {
        live.clear();
    }

    /** Forget every rule (also the ones from the APK) until the app is restarted. */
    static void resetAll() {
        live.clear();
        for (String k : baked.keySet()) live.put(k, new Rule(k));
    }

    static JSONArray liveArray() throws Exception {
        JSONArray a = new JSONArray();
        for (Rule r : live.values()) a.put(r.toJson());
        return a;
    }

    /** Baked rules with live edits on top, empty ones left out. */
    static JSONArray mergedArray() throws Exception {
        HashMap<String, Rule> m = new HashMap<String, Rule>(baked);
        m.putAll(live);
        JSONArray a = new JSONArray();
        for (Rule r : m.values()) {
            if (!r.isEmpty()) a.put(r.toJson());
        }
        return a;
    }
}
