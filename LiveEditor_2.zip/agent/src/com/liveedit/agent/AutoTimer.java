package com.liveedit.agent;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Switches ONE button on and off by itself: on for a while, off for a while, repeat. Nothing to do with
 * subscriptions or countdown texts. The button is tapped like a finger would (touch down + up), so it works for
 * normal click buttons, switches / checkboxes and the touch-listener buttons that mod menus use.
 *
 * Two ways to name the button:
 * - a per-item rule from the pencil panel (Rules.Rule.tOn / tOff), found by the item's key;
 * - a text from the Live Editor app (Config.autos), found by the text shown on the button.
 */
final class AutoTimer {

    /** A timer chosen in the Live Editor app: the button that shows this text, on for onMs, off for offMs. */
    static final class Spec {
        String text = "";
        int onMs = 5000;
        int offMs = 5000;
        /** The button is already ON when the app starts. */
        boolean isOn;
    }

    private static final class Job {
        boolean on;          // the phase we are in now
        boolean started;
        long nextAt;         // when the current phase ends
        WeakReference<View> view;
        int onMs, offMs;
    }

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final HashMap<String, Job> JOBS = new HashMap<String, Job>();
    private static boolean running;

    private AutoTimer() {}

    static Spec[] fromJson(JSONArray a) {
        ArrayList<Spec> out = new ArrayList<Spec>();
        if (a != null) {
            for (int i = 0; i < a.length() && i < 20; i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                Spec s = new Spec();
                s.text = o.optString("t", "").trim();
                s.onMs = U.clamp(o.optInt("on", 5000), 100, 3600000);
                s.offMs = U.clamp(o.optInt("off", 5000), 100, 3600000);
                s.isOn = o.optBoolean("io", false);
                if (s.text.length() > 0) out.add(s);
            }
        }
        return out.toArray(new Spec[out.size()]);
    }

    static JSONArray toJson(Spec[] specs) {
        JSONArray a = new JSONArray();
        try {
            for (int i = 0; i < specs.length; i++) {
                JSONObject o = new JSONObject();
                o.put("t", specs[i].text);
                o.put("on", specs[i].onMs);
                o.put("off", specs[i].offMs);
                if (specs[i].isOn) o.put("io", true);
                a.put(o);
            }
        } catch (Throwable t) {
            U.err("auto json", t);
        }
        return a;
    }

    /** Starts the timer loop when there is at least one timer. Safe to call again and again. */
    static void ensure() {
        if (running) return;
        if (Config.autos.length == 0 && Rules.timerRules().isEmpty()) return;
        running = true;
        H.postDelayed(LOOP, 1500);
    }

    /** A timer was changed or switched off in the panel: forget the old phase so the new numbers start fresh. */
    static void forget(String key) {
        JOBS.remove(key);
    }

    private static final Runnable LOOP = new Runnable() {
        @Override
        public void run() {
            try {
                step();
            } catch (Throwable t) {
                U.err("auto timer", t);
            }
            H.postDelayed(this, 250);
        }
    };

    private static void step() {
        long now = SystemClock.uptimeMillis();
        List<Rules.Rule> rs = Rules.timerRules();
        ArrayList<String> alive = new ArrayList<String>();
        for (int i = 0; i < rs.size(); i++) {
            Rules.Rule r = rs.get(i);
            String id = "r:" + r.key;
            alive.add(id);
            run(id, now, r.tOn, r.tOff, r.tIsOn, r.key, r.lk, null);
        }
        for (int i = 0; i < Config.autos.length; i++) {
            Spec s = Config.autos[i];
            String id = "t:" + i + ":" + s.text;
            alive.add(id);
            run(id, now, s.onMs, s.offMs, s.isOn, null, null, s.text);
        }
        // timers that were switched off: forget their phase
        ArrayList<String> dead = new ArrayList<String>();
        for (String k : JOBS.keySet()) {
            if (!alive.contains(k)) dead.add(k);
        }
        for (int i = 0; i < dead.size(); i++) JOBS.remove(dead.get(i));
    }

    private static void run(String id, long now, int onMs, int offMs, boolean isOn, String key, String lk,
                            String text) {
        Job j = JOBS.get(id);
        if (j == null) {
            j = new Job();
            JOBS.put(id, j);
        }
        j.onMs = onMs; // new numbers only change the next wait, the current phase goes on
        j.offMs = offMs;
        View v = j.view == null ? null : j.view.get();
        if (v == null || !v.isAttachedToWindow()) {
            v = key != null ? Overlays.findByKey(key, lk) : Overlays.findByText(text);
            j.view = v == null ? null : new WeakReference<View>(v);
        }
        if (v == null) return; // the button is not on screen right now: wait for it
        if (!j.started) {
            j.started = true;
            // the first phase: turn it ON (or, when it is already on, OFF first)
            j.on = isOn;
            j.nextAt = now;
        }
        if (now < j.nextAt) return;
        boolean wantOn = !j.on;
        j.on = wantOn;
        j.nextAt = now + (wantOn ? onMs : offMs);
        act(v, wantOn);
    }

    private static void act(View v, boolean wantOn) {
        try {
            if (v instanceof CompoundButton) {
                // a switch / checkbox knows its state: only tap when it is not already like we want
                if (((CompoundButton) v).isChecked() == wantOn) return;
            }
            tap(v);
        } catch (Throwable t) {
            U.err("auto tap", t);
        }
    }

    /** A finger tap in the middle of the view. Works for click listeners and for touch listeners. */
    private static void tap(View v) {
        float x = Math.max(1, v.getWidth()) / 2f;
        float y = Math.max(1, v.getHeight()) / 2f;
        long t = SystemClock.uptimeMillis();
        MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
        try {
            v.dispatchTouchEvent(d);
        } finally {
            d.recycle();
        }
        MotionEvent u = MotionEvent.obtain(t, t + 40, MotionEvent.ACTION_UP, x, y, 0);
        try {
            v.dispatchTouchEvent(u);
        } finally {
            u.recycle();
        }
    }

    /** The visible text of a button (used to find it by name). */
    static String textOf(View v) {
        if (v instanceof TextView) {
            CharSequence cs = ((TextView) v).getText();
            if (cs != null && cs.toString().trim().length() > 0) return cs.toString().trim();
        }
        CharSequence cd = v.getContentDescription();
        return cd == null ? "" : cd.toString().trim();
    }
}
