package com.liveedit.agent;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.LinkedHashSet;

/**
 * Safety net for removed interfaces. A removed window is only bypassed (see Overlays.hideWindow), but if some app
 * still closes shortly after one was removed, the next start remembers it: that window is then kept visible
 * (never removed again) and the app keeps working. The marks can be cleared in the Windows tab.
 */
final class HideGuard {
    private static final String STAMP = "liveedit_hide_stamp.json";
    private static final String UNSAFE = "liveedit_unsafe.json";
    /** If the app is still alive this long after a removal, the removal was fine. */
    private static final long SAFE_AFTER_MS = 5000L;

    private static Context app;
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static final HashSet<String> unsafe = new HashSet<String>();
    private static final LinkedHashSet<String> recent = new LinkedHashSet<String>();

    private static final Runnable CLEAR = new Runnable() {
        @Override
        public void run() {
            recent.clear();
            delete(STAMP);
        }
    };

    private HideGuard() {}

    /** Called once at start (after the rules are loaded). */
    static void init(Context c) {
        app = c.getApplicationContext() == null ? c : c.getApplicationContext();
        try {
            readSet(UNSAFE, unsafe);
            LinkedHashSet<String> died = new LinkedHashSet<String>();
            readSet(STAMP, died);
            if (!died.isEmpty()) {
                // the app closed within seconds of a removal last time
                unsafe.addAll(died);
                writeSet(UNSAFE, unsafe);
                delete(STAMP);
                H.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Toast.makeText(app, "Live Editor: the app closed after something was removed. "
                                    + "That interface is kept visible now.", Toast.LENGTH_LONG).show();
                        } catch (Throwable t) {
                            // ignore
                        }
                    }
                }, 4000);
            }
            for (String k : unsafe) Rules.edit(k).hide = false;
        } catch (Throwable t) {
            U.err("hide guard init", t);
        }
    }

    /** A removal was just applied: if the app dies in the next seconds, this key is marked unsafe. */
    static void note(String key) {
        if (app == null || key == null) return;
        try {
            recent.add(key);
            writeSet(STAMP, recent);
            H.removeCallbacks(CLEAR);
            H.postDelayed(CLEAR, SAFE_AFTER_MS);
        } catch (Throwable t) {
            U.err("hide guard note", t);
        }
    }

    static void markUnsafe(String key) {
        if (key == null) return;
        unsafe.add(key);
        try {
            writeSet(UNSAFE, unsafe);
        } catch (Throwable t) {
            U.err("hide guard mark", t);
        }
    }

    static boolean isUnsafe(String key) {
        return key != null && unsafe.contains(key);
    }

    static int unsafeCount() {
        return unsafe.size();
    }

    /** Forget every mark, so those windows can be removed again. */
    static void forgetAll() {
        unsafe.clear();
        delete(UNSAFE);
        delete(STAMP);
    }

    // ---- tiny storage -------------------------------------------------------------------------

    private static void readSet(String name, java.util.Set<String> into) {
        try {
            File f = new File(app.getFilesDir(), name);
            if (!f.exists()) return;
            byte[] b = new byte[(int) Math.min(f.length(), 200000L)];
            FileInputStream in = new FileInputStream(f);
            int n = 0;
            try {
                int r;
                while (n < b.length && (r = in.read(b, n, b.length - n)) > 0) n += r;
            } finally {
                in.close();
            }
            JSONArray a = new JSONArray(new String(b, 0, n, StandardCharsets.UTF_8));
            for (int i = 0; i < a.length(); i++) {
                String s = a.optString(i, "");
                if (s.length() > 0) into.add(s);
            }
        } catch (Throwable t) {
            // unreadable: treat as empty
        }
    }

    private static void writeSet(String name, java.util.Set<String> set) throws Exception {
        JSONArray a = new JSONArray();
        for (String s : set) a.put(s);
        FileOutputStream out = new FileOutputStream(new File(app.getFilesDir(), name));
        try {
            out.write(a.toString().getBytes(StandardCharsets.UTF_8));
            out.getFD().sync(); // reaches the disk even if the app is killed a moment later
        } finally {
            out.close();
        }
    }

    private static void delete(String name) {
        try {
            if (app != null) new File(app.getFilesDir(), name).delete();
        } catch (Throwable t) {
            // ignore
        }
    }
}
