package com.liveedit.patcher;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Reads the code (classes.dex) of an APK without changing it and lists the places that start something after a
 * delay: Handler.postDelayed / sendMessageDelayed, Timer.schedule, scheduled executors and CountDownTimer.
 * The delay is a guess taken from the numbers loaded just before the call (milliseconds).
 */
final class TimerScan {

    private static final String[] SKIP = {
            "Landroidx/", "Landroid/", "Lcom/google/android/gms/", "Lcom/google/firebase/", "Lkotlin/", "Lkotlinx/",
            "Lokhttp3/", "Lokio/", "Lcom/squareup/", "Lcom/facebook/", "Lcom/bumptech/", "Lcom/unity3d/ads/",
            "Lcom/applovin/", "Lcom/ironsource/", "Lcom/vungle/", "Lcom/google/ads/", "Lcom/liveedit/"
    };

    private TimerScan() {}

    /** One place in the code that starts something after a delay. */
    static final class Hit {
        String label;
        /** where the delay number is written: dex file, byte offset of its load instruction, its kind and register */
        String dex;
        int off;
        int op;
        int reg;
        /** the delay in ms as written now, or -1 when it is not a plain number (then it cannot be edited) */
        long value = -1;
        boolean editable;
        /**
         * 0 = a delay (timer), 1 = a number near Paint.setStrokeWidth (value = the float bits): line thickness,
         * 2 = a call that makes a sound (beep): off = the call, value = its method number
         */
        int type;
        /** class that holds this place, as written in the dex (for example Lcom/foo/Bar;) */
        String cls = "";

        String key() {
            return dex + ":" + off + ":" + value;
        }

        /** Largest delay that fits in the place where the number is written. */
        long maxMs() {
            return op == 0x16 ? 32767L : 0x7FFFFFFFL;
        }

        float asFloat() {
            return Float.intBitsToFloat((int) value);
        }
    }

    /** Appends findings of one dex file to out (at most 400 in total). */
    static void scan(String dexName, byte[] dex, List<Hit> out) {
        try {
            if (dex.length < 0x70 || dex[0] != 'd' || dex[1] != 'e' || dex[2] != 'x') return;
            new Run(dexName, dex, out).go();
        } catch (Throwable t) {
            // a damaged or packed dex: nothing to list
        }
    }

    /** Dex files need a new SHA-1 and checksum in the header after any change. */
    static void fixHeader(byte[] d) throws Exception {
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-1");
        md.update(d, 32, d.length - 32);
        byte[] sig = md.digest();
        System.arraycopy(sig, 0, d, 12, 20);
        java.util.zip.Adler32 ad = new java.util.zip.Adler32();
        ad.update(d, 12, d.length - 12);
        long v = ad.getValue();
        d[8] = (byte) v;
        d[9] = (byte) (v >> 8);
        d[10] = (byte) (v >> 16);
        d[11] = (byte) (v >> 24);
    }

    /**
     * Writes a new delay (ms; -1 = never fires) into the place found by the scan. Same length as before, so nothing
     * else in the file moves. Returns an empty string when it worked, otherwise why not.
     */
    static String patch(byte[] d, Hit h, long newMs) {
        try {
            int o = h.off;
            if (o < 0x70 || o + 4 > d.length) return "position outside the file";
            int u0 = (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8);
            int op = u0 & 0xFF, reg = (u0 >> 8) & 0xFF;
            if (h.type == 2) { // a sound call: replace the call (3 units) and a move-result after it by nop
                if (!((op >= 0x6e && op <= 0x72) || (op >= 0x74 && op <= 0x78))) return "the code is not the one that was scanned";
                int mi = (d[o + 2] & 0xFF) | ((d[o + 3] & 0xFF) << 8);
                if (mi != (int) h.value) return "the call is not the scanned one";
                if (o + 8 > d.length) return "position outside the file";
                for (int i = 0; i < 6; i++) d[o + i] = 0;
                int nx = d[o + 6] & 0xFF;
                if (nx >= 0x0a && nx <= 0x0c) { // the result of the call is no longer there
                    d[o + 6] = 0;
                    d[o + 7] = 0;
                }
                return "";
            }
            if (op != h.op || reg != h.reg) return "the code is not the one that was scanned";
            if (h.type == 1) { // a float (line thickness): newMs carries the new float bits
                int nb = (int) newMs;
                if (op == 0x15) {
                    if (((d[o + 2] & 0xFF) | ((d[o + 3] & 0xFF) << 8)) != ((int) h.value >>> 16)) return "not the scanned number";
                    nb = (nb + 0x8000) & 0xFFFF0000; // this place holds only the top 16 bits of a float
                    d[o + 2] = (byte) (nb >>> 16);
                    d[o + 3] = (byte) (nb >>> 24);
                } else if (op == 0x14) {
                    int old = (d[o + 2] & 0xFF) | ((d[o + 3] & 0xFF) << 8) | ((d[o + 4] & 0xFF) << 16) | ((d[o + 5] & 0xFF) << 24);
                    if (old != (int) h.value) return "not the scanned number";
                    for (int i = 0; i < 4; i++) d[o + 2 + i] = (byte) (nb >>> (8 * i));
                } else {
                    return "unsupported kind of number";
                }
                return "";
            }
            if (op == 0x16) {
                if (((d[o + 2] & 0xFF) | (d[o + 3] << 8)) != (short) h.value) return "the delay is not the scanned one";
                if (newMs < 0) { // const-wide/high16 0x7fff: the same 2 units, a delay of ~290 million years
                    d[o] = 0x19;
                    d[o + 2] = (byte) 0xFF;
                    d[o + 3] = 0x7F;
                } else {
                    if (newMs > 32767) return "this place only holds up to 32767 ms (or Never)";
                    d[o + 2] = (byte) newMs;
                    d[o + 3] = (byte) (newMs >> 8);
                }
            } else if (op == 0x17) {
                int old = (d[o + 2] & 0xFF) | ((d[o + 3] & 0xFF) << 8) | ((d[o + 4] & 0xFF) << 16) | ((d[o + 5] & 0xFF) << 24);
                if (old != (int) h.value) return "the delay is not the scanned one";
                long n = newMs < 0 ? 0x7FFFFFFFL : Math.min(newMs, 0x7FFFFFFFL);
                for (int i = 0; i < 4; i++) d[o + 2 + i] = (byte) (n >> (8 * i));
            } else if (op == 0x18) {
                long old = 0;
                for (int i = 0; i < 8; i++) old |= (long) (d[o + 2 + i] & 0xFF) << (8 * i);
                if (old != h.value) return "the delay is not the scanned one";
                long n = newMs < 0 ? 0x7FFF000000000000L : newMs;
                for (int i = 0; i < 8; i++) d[o + 2 + i] = (byte) (n >> (8 * i));
            } else {
                return "unsupported kind of number";
            }
            return "";
        } catch (Throwable t) {
            return String.valueOf(t);
        }
    }

    private static final class Run {
        final ByteBuffer b;
        final String dexName;
        final List<Hit> out;
        final int strings, strOff, types, typeOff, methods, methodOff, classes, classOff, protoOff;
        final int[] kind;
        final String[] cache;

        Run(String dexName, byte[] d, List<Hit> out) {
            this.b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
            this.dexName = dexName;
            this.out = out;
            strings = b.getInt(0x38);
            strOff = b.getInt(0x3c);
            types = b.getInt(0x40);
            typeOff = b.getInt(0x44);
            protoOff = b.getInt(0x4c);
            methods = b.getInt(0x58);
            methodOff = b.getInt(0x5c);
            classes = b.getInt(0x60);
            classOff = b.getInt(0x64);
            kind = new int[Math.max(0, methods)];
            cache = new String[Math.max(0, strings)];
        }

        String str(int idx) {
            if (idx < 0 || idx >= strings) return "";
            if (cache[idx] != null) return cache[idx];
            int p = b.getInt(strOff + idx * 4);
            while ((b.get(p) & 0x80) != 0) p++; // skip the length (uleb128)
            p++;
            int e = p;
            while (e < b.limit() && b.get(e) != 0) e++;
            byte[] x = new byte[e - p];
            for (int i = 0; i < x.length; i++) x[i] = b.get(p + i);
            String s = new String(x, java.nio.charset.StandardCharsets.UTF_8);
            cache[idx] = s;
            return s;
        }

        String type(int idx) {
            if (idx < 0 || idx >= types) return "";
            return str(b.getInt(typeOff + idx * 4));
        }

        int uleb(int[] pos) {
            int r = 0, shift = 0;
            while (true) {
                int v = b.get(pos[0]++) & 0xFF;
                r |= (v & 0x7F) << shift;
                if ((v & 0x80) == 0) break;
                shift += 7;
                if (shift > 35) break;
            }
            return r;
        }

        void go() {
            for (int i = 0; i < methods; i++) {
                int o = methodOff + i * 8;
                String cls = type(b.getShort(o) & 0xFFFF);
                String name = str(b.getInt(o + 4));
                kind[i] = classify(cls, name);
            }
            for (int c = 0; c < classes && out.size() < 400; c++) {
                try {
                    oneClass(classOff + c * 32);
                } catch (Throwable t) {
                    // skip this class
                }
            }
        }

        int classify(String cls, String name) {
            // things that make a sound (the auto-off of a button often beeps)
            if (cls.equals("Landroid/media/ToneGenerator;") && name.equals("startTone")) return 10;
            if (cls.equals("Landroid/media/MediaPlayer;") && name.equals("start")) return 11;
            if (cls.equals("Landroid/media/SoundPool;") && name.equals("play")) return 12;
            if (cls.equals("Landroid/media/AudioTrack;") && name.equals("play")) return 13;
            if (cls.equals("Landroid/media/Ringtone;") && name.equals("play")) return 14;
            if (cls.equals("Landroid/media/AudioManager;") && name.equals("playSoundEffect")) return 15;
            if (cls.equals("Landroid/view/View;") && name.equals("playSoundEffect")) return 16;
            // other ways to wait: Kotlin coroutines delay(), Thread.sleep(), View.postDelayed()
            if (cls.equals("Lkotlinx/coroutines/DelayKt;") && name.equals("delay")) return 7;
            if (cls.equals("Ljava/lang/Thread;") && name.equals("sleep")) return 8;
            if (cls.equals("Landroid/view/View;") && name.equals("postDelayed")) return 1;
            if (cls.equals("Landroid/os/Handler;")) {
                if (name.equals("postDelayed") || name.equals("postAtTime")) return 1;
                if (name.equals("sendMessageDelayed") || name.equals("sendEmptyMessageDelayed")) return 4;
            }
            if (cls.equals("Landroid/graphics/Paint;") && name.equals("setStrokeWidth")) return 6;
            if (cls.equals("Ljava/util/Timer;") && name.equals("schedule")) return 2;
            if (cls.equals("Landroid/os/CountDownTimer;") && name.equals("<init>")) return 3;
            if (cls.equals("Ljava/util/concurrent/ScheduledExecutorService;")
                    && (name.equals("schedule") || name.startsWith("scheduleAt"))) return 5;
            return 0;
        }

        boolean skipped(String cls) {
            for (int i = 0; i < SKIP.length; i++) if (cls.startsWith(SKIP[i])) return true;
            return false;
        }

        String fmtF(float f) {
            String s = String.valueOf(Math.round(f * 100f) / 100f);
            return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
        }

        String pretty(String d) {
            if (d.startsWith("L") && d.endsWith(";")) d = d.substring(1, d.length() - 1);
            return d.replace('/', '.');
        }

        void oneClass(int cd) {
            String cls = type(b.getInt(cd));
            if (skipped(cls)) return;
            String sup = type(b.getInt(cd + 8));
            if (sup.equals("Landroid/os/CountDownTimer;")) {
                Hit h = new Hit();
                h.label = pretty(cls) + ": is a CountDownTimer (counts down by itself, see onTick / onFinish)";
                add(h);
            }
            int dataOff = b.getInt(cd + 24);
            if (dataOff == 0) return;
            int[] p = {dataOff};
            int sf = uleb(p), inf = uleb(p), dm = uleb(p), vm = uleb(p);
            for (int i = 0; i < sf + inf; i++) {
                uleb(p);
                uleb(p);
            }
            for (int pass = 0; pass < 2; pass++) {
                int n = pass == 0 ? dm : vm;
                int idx = 0;
                for (int i = 0; i < n; i++) {
                    idx += uleb(p);
                    uleb(p);
                    int code = uleb(p);
                    if (code != 0) method(cls, idx, code);
                }
            }
        }

        void method(String cls, int methodIdx, int code) {
            if (methodIdx < 0 || methodIdx >= methods) return;
            String mname = str(b.getInt(methodOff + methodIdx * 8 + 4));
            int size = b.getInt(code + 12);
            int base = code + 16;
            if (size <= 0 || base + size * 2 > b.limit()) return;
            int[] cOp = new int[256], cPc = new int[256];
            long[] cVal = new long[256];
            int[] cOff = new int[256];
            boolean[] cOk = new boolean[256];
            int[] fOff = new int[6], fOp = new int[6], fBits = new int[6], fReg = new int[6], fPc = new int[6];
            int fn = 0;
            int pc = 0;
            while (pc < size) {
                int u = b.getShort(base + pc * 2) & 0xFFFF;
                int op = u & 0xFF;
                int len = width(op, u, base, pc, size);
                if (len <= 0) return;
                int at = base + pc * 2;
                if (op == 0x14 || op == 0x15) { // a number that may be a float (line thickness)
                    int bits = op == 0x15 ? (b.getShort(at + 2) & 0xFFFF) << 16 : b.getInt(at + 2);
                    float fv = Float.intBitsToFloat(bits);
                    if (fv >= 0.1f && fv <= 100f) {
                        int k = fn++ % 6;
                        fOff[k] = at;
                        fOp[k] = op;
                        fBits[k] = bits;
                        fReg[k] = (u >> 8) & 0xFF;
                        fPc[k] = pc;
                    }
                }
                int dest = (u >> 8) & 0xFF;
                boolean isConst = false;
                long cv = 0;
                switch (op) {
                    case 0x16:
                        cv = b.getShort(at + 2);
                        isConst = true;
                        break;
                    case 0x17:
                        cv = b.getInt(at + 2);
                        isConst = true;
                        break;
                    case 0x18:
                        cv = b.getLong(at + 2);
                        isConst = true;
                        break;
                    case 0x19:
                        cv = (long) b.getShort(at + 2) << 48;
                        isConst = true;
                        break;
                    default:
                        break;
                }
                if (isConst) {
                    cOp[dest] = op;
                    cVal[dest] = cv;
                    cOff[dest] = at;
                    cPc[dest] = pc;
                    cOk[dest] = true;
                    if (dest + 1 < 256) cOk[dest + 1] = false;
                } else if ((op >= 0x6e && op <= 0x72) || (op >= 0x74 && op <= 0x78)) {
                    int mi = b.getShort(at + 2) & 0xFFFF;
                    if (mi < methods && kind[mi] == 6) {
                        for (int k = 0; k < 6 && k < fn; k++) {
                            if (pc - fPc[k] > 40) continue;
                            Hit h = new Hit();
                            h.dex = dexName;
                            h.type = 1;
                            h.cls = cls;
                            h.off = fOff[k];
                            h.op = fOp[k];
                            h.reg = fReg[k];
                            h.value = fBits[k] & 0xFFFFFFFFL;
                            h.editable = true;
                            h.label = "LINE: " + pretty(cls) + "." + mname + "(): Paint.setStrokeWidth, nearby number "
                                    + fmtF(Float.intBitsToFloat(fBits[k])) + " (the line thickness is often this times the screen density)";
                            add(h);
                        }
                    } else if (mi < methods && kind[mi] >= 10) {
                        int bk = kind[mi];
                        Hit h = new Hit();
                        h.dex = dexName;
                        h.type = 2;
                        h.off = at;
                        h.op = op;
                        h.value = mi;
                        h.editable = true;
                        h.cls = cls;
                        String snd = bk == 10 ? "ToneGenerator.startTone" : bk == 11 ? "MediaPlayer.start"
                                : bk == 12 ? "SoundPool.play" : bk == 13 ? "AudioTrack.play" : bk == 14 ? "Ringtone.play"
                                : bk == 15 ? "AudioManager.playSoundEffect" : "View.playSoundEffect";
                        h.label = "BEEP: " + pretty(cls) + "." + mname + "(): " + snd;
                        add(h);
                    } else if (mi < methods && kind[mi] != 0) {
                        int[] regs = argRegs(op, u, at);
                        int k = kind[mi];
                        int idx = (k == 7 || k == 8) ? 0 : k == 3 ? 1 : (k == 1 && regs.length == 5 ? 3 : 2);
                        Hit h = new Hit();
                        h.dex = dexName;
                        h.cls = cls;
                        String what = k == 1 ? "postDelayed" : k == 4 ? "Handler.sendMessageDelayed"
                                : k == 2 ? "Timer.schedule" : k == 3 ? "new CountDownTimer"
                                : k == 7 ? "coroutine delay()" : k == 8 ? "Thread.sleep" : "scheduled task";
                        if (idx < regs.length) {
                            int r = regs[idx];
                            if (r >= 0 && r < 256 && cOk[r] && pc - cPc[r] <= 40 && cOp[r] != 0x19
                                    && cVal[r] >= 100 && cVal[r] <= 3600000L) {
                                h.off = cOff[r];
                                h.op = cOp[r];
                                h.reg = r;
                                h.value = cVal[r];
                                h.editable = true;
                            }
                        }
                        h.label = pretty(cls) + "." + mname + "(): " + what
                                + (h.editable ? " ~ " + h.value + " ms" : " (delay is calculated, cannot be edited)");
                        add(h);
                    }
                } else {
                    int w = writes(op, u, at);
                    if (w >= 0) {
                        cOk[w] = false;
                        if (w + 1 < 256) cOk[w + 1] = false;
                    }
                }
                pc += len;
            }
        }

        /** The register an instruction writes, or -1 (approximate: enough to forget a stale number). */
        int writes(int op, int u, int at) {
            int aa = (u >> 8) & 0xFF, a = (u >> 8) & 0xF;
            if (op == 0x03 || op == 0x06 || op == 0x09) return b.getShort(at + 2) & 0xFFFF;
            if (op >= 0x01 && op <= 0x0d) return (op == 0x01 || op == 0x04 || op == 0x07) ? a : aa;
            if (op >= 0x12 && op <= 0x1c) return op == 0x12 ? a : aa;
            if (op == 0x20 || op == 0x21 || op == 0x23) return a;
            if (op == 0x22 || (op >= 0x2d && op <= 0x31) || (op >= 0x44 && op <= 0x4a)) return aa;
            if (op >= 0x52 && op <= 0x58) return a;
            if (op >= 0x60 && op <= 0x66) return aa;
            if (op >= 0x7b && op <= 0x8f) return a;
            if (op >= 0x90 && op <= 0xaf) return aa;
            if (op >= 0xb0 && op <= 0xd7) return a;
            if (op >= 0xd8 && op <= 0xe2) return aa;
            return -1;
        }

        int[] argRegs(int op, int u, int at) {
            if (op >= 0x74) { // range form: AA registers from CCCC on
                int n = (u >> 8) & 0xFF;
                int first = b.getShort(at + 4) & 0xFFFF;
                int[] r = new int[n];
                for (int i = 0; i < n; i++) r[i] = first + i;
                return r;
            }
            int n = (u >> 12) & 0xF;
            int g = (u >> 8) & 0xF;
            int w = b.getShort(at + 4) & 0xFFFF;
            int[] all = {w & 0xF, (w >> 4) & 0xF, (w >> 8) & 0xF, (w >> 12) & 0xF, g};
            int[] r = new int[Math.min(n, 5)];
            System.arraycopy(all, 0, r, 0, r.length);
            return r;
        }

        void add(Hit h) {
            if (out.size() >= 400) return;
            for (int i = 0; i < out.size(); i++) {
                Hit o = out.get(i);
                if (o.label.equals(h.label) && o.off == h.off && o.value == h.value) return;
            }
            out.add(h);
        }

        /** Length in 16-bit units of the instruction at pc, 0 when it cannot be read. */
        int width(int op, int u, int base, int pc, int size) {
            if (op == 0x00) {
                if (u == 0) return 1;
                int rest = size - pc;
                if (rest < 2) return 0;
                if (u == 0x0100) return b.getShort(base + (pc + 1) * 2) * 2 + 4;
                if (u == 0x0200) return b.getShort(base + (pc + 1) * 2) * 4 + 2;
                if (u == 0x0300) {
                    int w = b.getShort(base + (pc + 1) * 2) & 0xFFFF;
                    long n = b.getInt(base + (pc + 2) * 2) & 0xFFFFFFFFL;
                    return (int) ((w * n + 1) / 2 + 4);
                }
                return 1;
            }
            if (op <= 0x01) return 1;
            if (op == 0x02 || op == 0x05 || op == 0x08) return 2;
            if (op == 0x03 || op == 0x06 || op == 0x09) return 3;
            if (op <= 0x11) return 1;
            if (op == 0x12) return 1;
            if (op == 0x13 || op == 0x15 || op == 0x16 || op == 0x19) return 2;
            if (op == 0x14 || op == 0x17) return 3;
            if (op == 0x18) return 5;
            if (op == 0x1a || op == 0x1c || op == 0x1f || op == 0x20 || op == 0x22 || op == 0x23) return 2;
            if (op == 0x1b || op == 0x24 || op == 0x25 || op == 0x26) return 3;
            if (op == 0x1d || op == 0x1e || op == 0x21 || op == 0x27 || op == 0x28) return 1;
            if (op == 0x29) return 2;
            if (op == 0x2a || op == 0x2b || op == 0x2c) return 3;
            if (op >= 0x2d && op <= 0x3d) return 2;
            if (op >= 0x3e && op <= 0x43) return 1;
            if (op >= 0x44 && op <= 0x6d) return 2;
            if ((op >= 0x6e && op <= 0x72) || (op >= 0x74 && op <= 0x78)) return 3;
            if (op == 0x73 || op == 0x79 || op == 0x7a) return 1;
            if (op >= 0x7b && op <= 0x8f) return 1;
            if (op >= 0x90 && op <= 0xaf) return 2;
            if (op >= 0xb0 && op <= 0xcf) return 1;
            if (op >= 0xd0 && op <= 0xe2) return 2;
            if (op == 0xfa || op == 0xfb) return 4;
            if (op == 0xfc || op == 0xfd) return 3;
            if (op == 0xfe || op == 0xff) return 2;
            return 1;
        }
    }

    /** Delays of 1-10 seconds first: those are the usual "turns itself off" timers. */
    static void sort(List<Hit> hits) {
        java.util.Collections.sort(hits, new java.util.Comparator<Hit>() {
            @Override
            public int compare(Hit a, Hit c) {
                return rank(a) - rank(c);
            }
        });
    }

    private static int rank(Hit h) {
        if (h.type >= 1) return 1;
        if (h.editable) return (h.value >= 1000 && h.value <= 10000) ? 0 : 2;
        return h.label.contains("CountDownTimer") ? 1 : 3;
    }

    /** The class a place belongs to, without an inner-class suffix (Lfoo/Bar$1; and Lfoo/Bar; are the same owner). */
    static String owner(Hit h) {
        String c = h.cls == null ? "" : h.cls;
        int i = c.indexOf('$');
        return i > 0 ? c.substring(0, i) : c;
    }

    /** What the automatic search of "a button that turns itself off, with a beep" proposes. */
    static final class Pick {
        final List<Hit> timers = new java.util.ArrayList<Hit>();
        final List<Hit> beeps = new java.util.ArrayList<Hit>();
        /** pre-ticked in the list shown to the user */
        final java.util.Set<Hit> ticked = new java.util.HashSet<Hit>();
    }

    /**
     * Finds the auto-off timers (a plain delay of about 1-3 seconds) and the beeps of the app. Timers of 1 to 3 seconds
     * are ticked; beeps are ticked when they sit in the same class as a ticked timer, or when the app has only a few.
     */
    static Pick autoPick(List<Hit> hits) {
        Pick p = new Pick();
        for (int i = 0; i < hits.size(); i++) {
            Hit h = hits.get(i);
            if (h.type == 0 && h.editable && h.value >= 800 && h.value <= 3500) p.timers.add(h);
            else if (h.type == 2) p.beeps.add(h);
        }
        java.util.Set<String> owners = new java.util.HashSet<String>();
        for (int i = 0; i < p.timers.size(); i++) {
            Hit h = p.timers.get(i);
            if (h.value >= 1000 && h.value <= 3000) {
                p.ticked.add(h);
                owners.add(owner(h));
            }
        }
        for (int i = 0; i < p.beeps.size(); i++) {
            Hit h = p.beeps.get(i);
            if (owners.contains(owner(h)) || p.beeps.size() <= 5) p.ticked.add(h);
        }
        return p;
    }
}
