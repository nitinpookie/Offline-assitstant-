# VolClicker

Is zip ko repo ke root mein upload karo (`.github/workflows/build.yml` wahi hai jo baaki projects mein hai).
Actions > Build > Artifacts se APK milegi.
