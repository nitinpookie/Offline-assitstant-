package com.volclick;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private SharedPreferences p;
    private LinearLayout root;
    private TextView status;
    private Switch en;
    private int pad;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("s", MODE_PRIVATE);
        pad = (int) (14 * getResources().getDisplayMetrics().density);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        tv("Vol Clicker", 26);
        status = tv("", 15);

        button("1. Turn on service (Accessibility)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        button("2. Show / hide target", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClickService s = ClickService.inst;
                if (s == null) {
                    Toast.makeText(MainActivity.this, "Turn the service on first", Toast.LENGTH_SHORT).show();
                } else {
                    s.toggleMarker();
                }
            }
        });

        en = new Switch(this);
        en.setText("On (same as the Control Center tile)");
        en.setPadding(0, pad, 0, 0);
        en.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean c) {
                if (c == p.getBoolean("on", true)) return;
                ClickService s = ClickService.inst;
                if (s != null) s.setEnabled(c);
                else p.edit().putBoolean("on", c).apply();
            }
        });
        root.addView(en);

        num("Click every (ms)", "int", 100, 1);
        num("Tap length (ms)", "dur", 10, 1);
        num("After you touch the screen, stop in (seconds, 0 = never)", "tstop", 4, 0);
        num("Target size (dp)", "size", 44, 24);
        num("Stop after N clicks (0 = never)", "max", 0, 0);

        tv("How to use\n"
                + "- Volume Up: start / stop clicking\n"
                + "- Volume Down: show / hide the target\n"
                + "- Open your game, press Volume Down, drag the target onto the spot, tap the tick to save\n"
                + "- Add the \"Vol Clicker\" tile: Control Center > pencil icon > drag it in", 13)
                .setPadding(0, pad, 0, 0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        status.setText(ClickService.inst != null
                ? "Service: ON"
                : "Service: OFF - enable \"Vol Clicker\" in Accessibility settings");
        en.setChecked(p.getBoolean("on", true));
    }

    // ---------- tiny UI helpers ----------

    private TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        root.addView(t);
        return t;
    }

    private void button(String s, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(s);
        bt.setAllCaps(false);
        bt.setOnClickListener(l);
        root.addView(bt);
    }

    private void num(String label, final String key, final int def, final int min) {
        tv(label, 16).setPadding(0, pad, 0, 0);
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(p.getInt(key, def)));
        e.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                int v;
                try {
                    v = Math.max(min, Integer.parseInt(s.toString().trim()));
                } catch (Exception x) {
                    v = def;
                }
                p.edit().putInt(key, v).apply();
            }
        });
        root.addView(e);
    }
}
