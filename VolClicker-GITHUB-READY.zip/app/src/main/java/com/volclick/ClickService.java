package com.volclick;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class ClickService extends AccessibilityService {

    static ClickService inst;
    private static final int NONE = Integer.MIN_VALUE;

    private final Handler h = new Handler(Looper.getMainLooper());
    private SharedPreferences p;
    private WindowManager wm;
    private View marker, watcher;
    private WindowManager.LayoutParams mlp;
    private int wl, wt, lastRot, slop;

    private boolean running, armed;
    private int count, max, interval, dur, tstop, ticks, injId = NONE;
    private long t0, injFrom, injUntil;

    @Override
    protected void onServiceConnected() {
        inst = this;
        p = getSharedPreferences("s", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        slop = ViewConfiguration.get(this).getScaledTouchSlop();
        lastRot = rot();
        DisplayManager dm = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        dm.unregisterDisplayListener(dl);
        dm.registerDisplayListener(dl, h);
    }

    // ---------- keys: Vol Up = start/stop clicking, Vol Down = show/hide target ----------

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        if (k != KeyEvent.KEYCODE_VOLUME_UP && k != KeyEvent.KEYCODE_VOLUME_DOWN) return false;
        if (!p.getBoolean("on", true)) return false;
        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            if (k == KeyEvent.KEYCODE_VOLUME_UP) {
                if (running) stop();
                else start();
            } else {
                if (marker != null) hideMarker();
                else showMarker();
            }
        }
        return true; // consume, so the system volume does not change
    }

    // called from the Control Center tile / settings switch
    void setEnabled(boolean on) {
        p.edit().putBoolean("on", on).apply();
        if (!on) {
            stop();
            hideMarker();
        }
    }

    void toggleMarker() {
        if (marker != null) hideMarker();
        else showMarker();
    }

    // ---------- click loop ----------

    private void start() {
        if (running) return;
        interval = Math.max(1, p.getInt("int", 100));
        dur = Math.max(1, p.getInt("dur", 10));
        max = p.getInt("max", 0);
        tstop = p.getInt("tstop", 4);
        count = 0;
        ticks = 0;
        injId = NONE;
        armed = false;
        running = true;
        setMarkerTouchable(false);
        if (tstop > 0) showWatcher();
        h.postDelayed(tick, (marker != null || watcher != null) ? 100 : 0);
    }

    private void stop() {
        if (!running) return;
        running = false;
        armed = false;
        h.removeCallbacks(tick);
        h.removeCallbacks(touchStop);
        hideWatcher();
        setMarkerTouchable(true);
    }

    private final Runnable touchStop = new Runnable() {
        @Override
        public void run() {
            stop();
        }
    };

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            t0 = SystemClock.uptimeMillis();
            injFrom = t0;
            injUntil = Long.MAX_VALUE;
            ticks++;
            float[] c = pos();
            Path path = new Path();
            path.moveTo(Math.max(0f, c[0]), Math.max(0f, c[1]));
            GestureDescription g = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, dur))
                    .build();
            if (!dispatchGesture(g, cb, null)) {
                injUntil = 0;
                h.postDelayed(this, interval);
            }
        }
    };

    private final AccessibilityService.GestureResultCallback cb =
            new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription g) {
                    next();
                }

                @Override
                public void onCancelled(GestureDescription g) {
                    next();
                }
            };

    private void next() {
        if (!running) return;
        injUntil = SystemClock.uptimeMillis() + 40;
        if (max > 0 && ++count >= max) {
            stop();
            return;
        }
        long d = interval - (SystemClock.uptimeMillis() - t0);
        h.removeCallbacks(tick);
        h.postDelayed(tick, d > 0 ? d : 0);
    }

    // ---------- "user touched the screen" watcher ----------
    // A 1x1 invisible window gets one ACTION_OUTSIDE event for every touch anywhere else.
    // Our own injected taps carry a different device id than a real finger, so we learn
    // that id from the first tap and treat every other touch as the user.

    private void showWatcher() {
        if (watcher != null) return;
        View v = new View(this);
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) outside(e);
                return false;
            }
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(1, 1,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        try {
            wm.addView(v, lp);
            watcher = v;
        } catch (Exception ignored) {
        }
    }

    private void hideWatcher() {
        if (watcher == null) return;
        try {
            wm.removeView(watcher);
        } catch (Exception ignored) {
        }
        watcher = null;
    }

    private void outside(MotionEvent e) {
        if (!running || armed) return;
        long now = SystemClock.uptimeMillis();
        int id = e.getDeviceId();
        if (injId == NONE) {
            if (now >= injFrom && now <= injUntil) {
                injId = id; // this is our own tap: remember its device id
                return;
            }
            if (ticks < 3) return;
        } else if (id == injId) {
            return;
        }
        armed = true; // real touch: keep going for tstop seconds, then switch off
        h.postDelayed(touchStop, tstop * 1000L);
    }

    // ---------- position (saved separately for each screen rotation) ----------

    @SuppressWarnings("deprecation")
    private int rot() {
        return wm.getDefaultDisplay().getRotation();
    }

    @SuppressWarnings("deprecation")
    private DisplayMetrics real() {
        DisplayMetrics m = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(m);
        return m;
    }

    private float[] saved() {
        DisplayMetrics m = real();
        int r = rot();
        return new float[]{p.getFloat("x" + r, m.widthPixels / 2f), p.getFloat("y" + r, m.heightPixels / 2f)};
    }

    private float[] pos() {
        if (marker != null) {
            int[] l = new int[2];
            marker.getLocationOnScreen(l);
            return new float[]{l[0] + marker.getWidth() / 2f, l[1] + marker.getHeight() / 2f};
        }
        return saved();
    }

    private void savePos() {
        if (marker == null) return;
        float[] c = pos();
        int r = rot();
        p.edit().putFloat("x" + r, c[0]).putFloat("y" + r, c[1]).apply();
    }

    // ---------- the target ----------

    private void showMarker() {
        if (marker != null) return;
        float d = getResources().getDisplayMetrics().density;
        int sz = Math.round(Math.max(24, p.getInt("size", 44)) * d);
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        if (running) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        mlp = new WindowManager.LayoutParams(sz, sz,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        mlp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            mlp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        setXY();

        Marker mk = new Marker(this);
        mk.setAlpha(running ? 0.35f : 1f);
        mk.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            int sx, sy;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX();
                        dy = e.getRawY();
                        sx = mlp.x;
                        sy = mlp.y;
                        moved = false;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        float ox = e.getRawX() - dx, oy = e.getRawY() - dy;
                        if (!moved && Math.abs(ox) + Math.abs(oy) < slop) break;
                        moved = true;
                        mlp.x = sx + (int) ox;
                        mlp.y = sy + (int) oy;
                        wm.updateViewLayout(v, mlp);
                        break;
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            v.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    savePos();
                                }
                            }, 60);
                        } else {
                            confirm(); // tap on the tick = save + hide
                        }
                        break;
                }
                return true;
            }
        });
        marker = mk;
        try {
            wm.addView(marker, mlp);
        } catch (Exception x) {
            marker = null;
            return;
        }
        nudge();
    }

    private void hideMarker() {
        if (marker == null) return;
        try {
            wm.removeView(marker);
        } catch (Exception ignored) {
        }
        marker = null;
    }

    private void confirm() {
        savePos();
        hideMarker();
        if (!p.getBoolean("saved", false)) {
            p.edit().putBoolean("saved", true).apply();
            Toast.makeText(this,
                    "Saved. Add the \"Vol Clicker\" tile in Control Center (pencil icon) to switch it on/off.",
                    Toast.LENGTH_LONG).show();
        }
    }

    // window position for the saved spot of the current rotation
    private void setXY() {
        DisplayMetrics m = real();
        float[] s = saved();
        wl = Math.max(0, Math.min(Math.round(s[0] - mlp.width / 2f), m.widthPixels - mlp.width));
        wt = Math.max(0, Math.min(Math.round(s[1] - mlp.height / 2f), m.heightPixels - mlp.height));
        mlp.x = wl;
        mlp.y = wt;
    }

    // after rotation: move the target to the spot saved for the new rotation
    private final Runnable placeRun = new Runnable() {
        @Override
        public void run() {
            place();
        }
    };

    private void place() {
        if (marker == null) return;
        setXY();
        try {
            wm.updateViewLayout(marker, mlp);
        } catch (Exception ignored) {
        }
        nudge();
    }

    // if the system shifted the window (notch / bars), shift it back
    private void nudge() {
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (marker == null) return;
                int[] l = new int[2];
                marker.getLocationOnScreen(l);
                if (l[0] != wl || l[1] != wt) {
                    mlp.x += wl - l[0];
                    mlp.y += wt - l[1];
                    try {
                        wm.updateViewLayout(marker, mlp);
                    } catch (Exception ignored) {
                    }
                }
            }
        }, 150);
    }

    private final DisplayManager.DisplayListener dl = new DisplayManager.DisplayListener() {
        @Override
        public void onDisplayAdded(int id) {
        }

        @Override
        public void onDisplayRemoved(int id) {
        }

        @Override
        public void onDisplayChanged(int id) {
            int r = rot();
            if (r != lastRot) {
                lastRot = r;
                h.removeCallbacks(placeRun);
                place();
                h.postDelayed(placeRun, 350);
            }
        }
    };

    // while clicking, taps and the user's own touches pass through the target
    private void setMarkerTouchable(boolean touchable) {
        if (marker == null || mlp == null) return;
        if (touchable) mlp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else mlp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        marker.setAlpha(touchable ? 1f : 0.35f);
        try {
            wm.updateViewLayout(marker, mlp);
        } catch (Exception ignored) {
        }
    }

    private static class Marker extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tk = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path tp = new Path();
        private final float d;

        Marker(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(2f * d);
            ring.setColor(0xE6FFFFFF);
            glow.setStyle(Paint.Style.STROKE);
            glow.setStrokeWidth(3f * d);
            glow.setColor(0x445AB8FF);
            tk.setStyle(Paint.Style.STROKE);
            tk.setStrokeWidth(3f * d);
            tk.setStrokeCap(Paint.Cap.ROUND);
            tk.setStrokeJoin(Paint.Join.ROUND);
            tk.setColor(Color.WHITE);
        }

        @Override
        protected void onSizeChanged(int w, int hh, int ow, int oh) {
            fill.setShader(new RadialGradient(w / 2f, hh / 2f, w / 2f,
                    new int[]{0xE67CC4FF, 0xE62F6BFF}, null, Shader.TileMode.CLAMP));
            tp.reset();
            tp.moveTo(w * 0.30f, hh * 0.52f);
            tp.lineTo(w * 0.44f, hh * 0.66f);
            tp.lineTo(w * 0.71f, hh * 0.36f);
        }

        @Override
        protected void onDraw(Canvas c) {
            float a = getWidth() / 2f, b = getHeight() / 2f, r = a - 4f * d;
            c.drawCircle(a, b, r + 1.5f * d, glow);
            c.drawCircle(a, b, r, fill);
            c.drawCircle(a, b, r, ring);
            c.drawPath(tp, tk);
        }
    }

    // ---------- lifecycle ----------

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
        stop();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    private void cleanup() {
        running = false;
        h.removeCallbacksAndMessages(null);
        try {
            ((DisplayManager) getSystemService(Context.DISPLAY_SERVICE)).unregisterDisplayListener(dl);
        } catch (Exception ignored) {
        }
        hideWatcher();
        hideMarker();
        if (inst == this) inst = null;
    }
}
