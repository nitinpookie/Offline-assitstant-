package com.liveedit.agent;

import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Lives inside the patched app and has no screen of its own. It only carries out the choices that were
 * baked into the APK (assets/liveedit_config.json): blocked servers and links, hidden ad banners, sizes, colours,
 * names and theme of buttons and menus, timers, muted clicks, screen flags and animation speed. In live mode it also
 * shows the pencil handle (Panel). If the config is missing it does nothing.
 */
public final class Agent implements Application.ActivityLifecycleCallbacks {

    /** Version of this engine; shown in the pencil panel so you can see which engine is inside a patched app. */
    static final String ENGINE = "2.16";

    private static Agent inst;
    private static WeakReference<Activity> top;

    private int started;
    private final Application app;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final HashMap<Activity, State> states = new HashMap<Activity, State>();
    private boolean callbacksWork;

    private static final class State {
        View decor;
        boolean pending;
        Runnable run;
        ViewTreeObserver.OnGlobalLayoutListener listener;
    }

    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            try {
                poll();
            } catch (Throwable t) {
                U.err("poll", t);
            }
            if (!callbacksWork) handler.postDelayed(this, 1000);
        }
    };

    /** Overlay windows (floating buttons) live outside activities, so they are handled on a timer. */
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            try {
                Overlays.tick(app);
            } catch (Throwable t) {
                U.err("ticker", t);
            }
            handler.postDelayed(this, 700);
        }
    };

    private Agent(Application app) {
        this.app = app;
    }

    /** The activity that is on screen right now, or null. */
    static Activity topActivity() {
        Activity a = top == null ? null : top.get();
        if (a == null || a.isFinishing() || a.isDestroyed()) return null;
        return a;
    }

    /** The decor view of the activity that is on screen (used when Android hides the window list). */
    static View topDecor() {
        Activity a = top == null ? null : top.get();
        if (a == null || a.isFinishing()) return null;
        Window w = a.getWindow();
        return w == null ? null : w.peekDecorView();
    }

    static synchronized void start(final Application app) {
        if (inst != null) return;
        Config.load(app);
        if (!Config.present) {
            U.log("no Live Editor config, doing nothing");
            return;
        }
        if (Config.live) Config.loadLive(app);
        HideGuard.init(app);
        EditGuard.init(app);
        inst = new Agent(app);
        Hidden.exempt();
        if (Config.needsTicker()) Overlays.watchWindows();
        if (Config.guard) Guard.install();
        if (Config.hosts.length > 0) Net.install(Config.hosts);
        if (Config.links != 0) Links.install(app.getPackageName());
        if (Config.anim != 0) animationScale(Config.anim == 2 ? 0f : 0.5f);
        if (Config.needsActivityHooks()) {
            app.registerActivityLifecycleCallbacks(inst);
            inst.handler.postDelayed(inst.poller, 800);
        }
        if (Config.needsTicker()) inst.handler.postDelayed(inst.ticker, 1500);
        if (Config.live) {
            inst.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Panel.start(app);
                }
            }, 400);
        }
        U.log("Live Editor engine started in " + app.getPackageName());
    }

    private static void animationScale(float f) {
        try {
            Class.forName("android.animation.ValueAnimator")
                    .getMethod("setDurationScale", float.class).invoke(null, Float.valueOf(f));
        } catch (Throwable t) {
            U.err("animation scale", t);
        }
    }

    // ---- lifecycle -------------------------------------------------------------------------

    @Override
    public void onActivityResumed(Activity a) {
        callbacksWork = true;
        top = new WeakReference<Activity>(a);
        try {
            attach(a);
        } catch (Throwable t) {
            U.err("resume", t);
        }
    }

    @Override
    public void onActivityDestroyed(Activity a) {
        states.remove(a);
    }

    @Override
    public void onActivityCreated(Activity a, Bundle b) {}

    @Override
    public void onActivityStarted(Activity a) {
        started++;
    }

    @Override
    public void onActivityPaused(Activity a) {
        // Back / finish: the user closed this screen on purpose, so a process that ends now is not a crash of an edit
        try {
            if (a.isFinishing()) {
                EditGuard.settle();
                HideGuard.settle();
            }
        } catch (Throwable t) {
            U.err("settle on finish", t);
        }
        if (!Config.live) return;
        try {
            Panel.onPause(a);
        } catch (Throwable t) {
            U.err("pause", t);
        }
    }

    @Override
    public void onActivityStopped(Activity a) {
        // the last screen went away (home button, recents): from here on a closing app is not a crash of an edit
        if (--started <= 0) {
            started = 0;
            try {
                EditGuard.settle();
                HideGuard.settle();
            } catch (Throwable t) {
                U.err("settle", t);
            }
        }
    }

    @Override
    public void onActivitySaveInstanceState(Activity a, Bundle b) {}

    // ---- fallback for apps that swap their Application ------------------------------------

    private void poll() throws Exception {
        Iterator<Map.Entry<Activity, State>> it = states.entrySet().iterator();
        while (it.hasNext()) {
            Activity a = it.next().getKey();
            if (a.isDestroyed() || a.isFinishing()) it.remove();
        }
        Class<?> atc = Class.forName("android.app.ActivityThread");
        Object thread = atc.getMethod("currentActivityThread").invoke(null);
        if (thread == null) return;
        Field f = atc.getDeclaredField("mActivities");
        f.setAccessible(true);
        Object map = f.get(thread);
        if (!(map instanceof Map)) return;
        for (Object rec : ((Map<?, ?>) map).values()) {
            Field af = rec.getClass().getDeclaredField("activity");
            af.setAccessible(true);
            Object act = af.get(rec);
            if (act instanceof Activity) {
                Activity a = (Activity) act;
                if (!a.isFinishing() && !a.isDestroyed() && !states.containsKey(a)) attach(a);
            }
        }
    }

    // ---- per-activity work ------------------------------------------------------------------

    private void attach(final Activity a) {
        Window w = a.getWindow();
        if (w == null) return;
        if (top == null || top.get() == null) top = new WeakReference<Activity>(a);
        if (Config.live) Panel.nudge();
        State s = states.get(a);
        if (s == null) {
            s = new State();
            states.put(a, s);
            final State st = s;
            st.run = new Runnable() {
                @Override
                public void run() {
                    st.pending = false;
                    work(a, st);
                }
            };
        }
        work(a, s);

        View dv = w.peekDecorView();
        if (dv != null && (Config.hideAds || Config.allowShot) && s.decor != dv) {
            final State st = s;
            if (st.decor != null && st.listener != null && st.decor.getViewTreeObserver().isAlive()) {
                st.decor.getViewTreeObserver().removeOnGlobalLayoutListener(st.listener);
            }
            st.decor = dv;
            st.listener = new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    if (!st.pending) {
                        st.pending = true;
                        handler.postDelayed(st.run, 250);
                    }
                }
            };
            ViewTreeObserver vto = dv.getViewTreeObserver();
            if (vto.isAlive()) vto.addOnGlobalLayoutListener(st.listener);
        }
        if (Config.immersive) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    immersive(a);
                }
            }, 400);
        }
    }

    private void work(Activity a, State s) {
        try {
            Window w = a.getWindow();
            if (w == null) return;
            WindowManager.LayoutParams lp = w.getAttributes();
            if (Config.keepOn && (lp.flags & WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) == 0) {
                w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
            if (Config.allowShot && (lp.flags & WindowManager.LayoutParams.FLAG_SECURE) != 0) {
                w.clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            }
            if (Config.hideAds) Ads.hide(w.peekDecorView());
        } catch (Throwable t) {
            U.err("work", t);
        }
    }

    private void immersive(Activity a) {
        try {
            Window w = a.getWindow();
            View d = w == null ? null : w.peekDecorView();
            if (d == null) return;
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = d.getWindowInsetsController();
                if (c != null) {
                    c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    c.hide(WindowInsets.Type.systemBars());
                }
            } else {
                d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable t) {
            U.err("immersive", t);
        }
    }
}
