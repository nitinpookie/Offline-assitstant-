package com.liveedit.patcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * The ON / OFF switch of the Live Editor pencil (default: ON), the Accessibility permission it needs, and the list of apps
 * that have the Live Editor engine inside. The pencil (PencilService) shows on the whole phone, over every app.
 */
final class PencilPrefs {

    private static final String FILE = "liveeditor";
    private static final String ON = "pencil_on";
    private static final HashSet<String> ENGINE = new HashSet<String>();

    private PencilPrefs() {}

    /** The pencil switch. It is ON until the user switches it off. */
    static boolean isOn(Context c) {
        try {
            return c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ON, true);
        } catch (Throwable t) {
            return true;
        }
    }

    static void setOn(Context c, boolean on) {
        try {
            c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ON, on).apply();
        } catch (Throwable t) {
            // keep the old value
        }
        PencilService.refresh();
    }

    /** True when the Accessibility permission of the pencil is on (Settings > Accessibility > Live Editor pencil). */
    static boolean accessibilityOn(Context c) {
        try {
            if (Settings.Secure.getInt(c.getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 1) return false;
            String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (s == null) return false;
            ComponentName me = new ComponentName(c, PencilService.class);
            for (String part : s.split(":")) {
                ComponentName cn = ComponentName.unflattenFromString(part);
                if (cn != null && cn.equals(me)) return true;
            }
        } catch (Throwable t) {
            // cannot tell
        }
        return false;
    }

    /** True when this app carries the Live Editor engine (its content provider "package.liveeditagent" exists). */
    static boolean hasEngine(Context c, String pkg) {
        if (pkg == null || pkg.length() == 0) return false;
        synchronized (ENGINE) {
            if (ENGINE.contains(pkg)) return true;
        }
        try {
            if (c.getPackageManager().resolveContentProvider(pkg + ".liveeditagent", 0) != null) {
                synchronized (ENGINE) {
                    ENGINE.add(pkg);
                }
                return true;
            }
        } catch (Throwable t) {
            // not there
        }
        return false;
    }

    /** Every installed app with the engine inside (found through its content provider), sorted by package name. */
    static List<String> scan(Context c) {
        ArrayList<String> out = new ArrayList<String>();
        try {
            PackageManager pm = c.getPackageManager();
            for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                try {
                    if (ai.packageName.equals(c.getPackageName())) continue;
                    if (pm.resolveContentProvider(ai.packageName + ".liveeditagent", 0) == null) continue;
                    out.add(ai.packageName);
                } catch (Throwable t) {
                    // skip this app
                }
            }
        } catch (Throwable t) {
            // empty list
        }
        Collections.sort(out);
        synchronized (ENGINE) {
            ENGINE.clear();
            ENGINE.addAll(out);
        }
        return out;
    }
}
