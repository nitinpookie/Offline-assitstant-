package com.liveedit.patcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The windows and screens of a patched app, read from its engine (content provider "package.liveeditagent") and drawn as
 * rows with a preview picture. Used by the Windows and screens screen
 * (WindowsActivity), so both look and work the same.
 */
final class WinRows {

    static final String[] FILTERS = {"All", "Open now", "Floating", "Popups", "Screens", "Removed"};

    /** True while a slider is being dragged: the list must not be rebuilt under the finger. */
    static volatile boolean touching;

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private WinRows() {}

    interface Result {
        /** arr is null when the app could not be read; raw is the text it was made from (to skip identical lists). */
        void got(JSONArray arr, String raw);
    }

    /** A command for the engine inside the patched app (method, window key, extras). */
    interface Cmd {
        void run(String method, String arg, Bundle extras);
    }

    /** Asks the engine of the app for its windows and screens (worker thread), then calls back on the main thread. */
    static void fetch(final Context app, final String pkg, final Result cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                JSONArray arr = null;
                String json = null;
                try {
                    Bundle b = app.getContentResolver().call(Uri.parse("content://" + pkg + ".liveeditagent"), "windows",
                            null, null);
                    if (b != null) json = b.getString("json");
                    if (json != null && json.length() > 0) arr = new JSONArray(json);
                } catch (Throwable t) {
                    arr = null;
                }
                final JSONArray res = arr;
                final String raw = json;
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        cb.got(res, raw);
                    }
                });
            }
        }, "pencil-windows").start();
    }

    /** Sends a command to the engine of the app from a worker thread. */
    static void call(final Context app, final String pkg, final String method, final String arg, final Bundle extras) {
        if (pkg == null || app == null) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    app.getContentResolver().call(Uri.parse("content://" + pkg + ".liveeditagent"), method, arg, extras);
                } catch (Throwable t) {
                    // the app is gone or too old: nothing to do
                }
            }
        }, "pencil-call").start();
    }

    static boolean matches(JSONObject o, int filter) {
        String kind = o.optString("kind", "");
        switch (filter) {
            case 1:
                return o.optBoolean("open", false);
            case 2:
                return "icon".equals(kind) || "button".equals(kind) || "menu".equals(kind) || "line".equals(kind)
                        || "canvas".equals(kind);
            case 3:
                return "popup".equals(kind);
            case 4:
                return "screen".equals(kind);
            case 5:
                return o.optBoolean("gone", false);
            default:
                return true;
        }
    }

    static void styleChip(Context c, TextView chip, boolean selected) {
        chip.setBackground(Ui.ripple(c, selected ? Ui.ACCENT : Ui.CARD2, 20));
        chip.setTextColor(selected ? 0xFFFFFFFF : Ui.TEXT);
    }

    /** One window or screen: preview, name, open / closed, Keep switch and an opacity slider. */
    static View row(final Context ctx, JSONObject o, final Cmd cmd) {
        final String key = o.optString("k", "");
        final boolean open = o.optBoolean("open", false);
        final boolean locked = o.optBoolean("locked", false);
        LinearLayout row = Ui.hbox(ctx);
        row.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10));
        row.setBackground(Ui.round(ctx, Ui.CARD2, 12));

        FrameLayout picBox = new FrameLayout(ctx);
        picBox.setBackground(Ui.round(ctx, 0xFF22253F, 8));
        ImageView pic = new ImageView(ctx);
        pic.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pic.setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3));
        boolean hasPic = false;
        String p64 = o.optString("p", "");
        if (p64.length() > 0) {
            try {
                byte[] pb = Base64.decode(p64, Base64.DEFAULT);
                Bitmap bm = BitmapFactory.decodeByteArray(pb, 0, pb.length);
                if (bm != null) {
                    pic.setImageBitmap(bm);
                    hasPic = true;
                }
            } catch (Throwable t) {
                hasPic = false;
            }
        }
        picBox.addView(pic, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        if (!hasPic) {
            TextView none = Ui.text(ctx, "no preview yet", 10, Ui.SUB, false);
            none.setGravity(Gravity.CENTER);
            picBox.addView(none, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(Ui.dp(ctx, 88), Ui.dp(ctx, 88));
        pl.rightMargin = Ui.dp(ctx, 12);
        row.addView(picBox, pl);

        LinearLayout col = Ui.vbox(ctx);
        row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(Ui.text(ctx, o.optString("name", "Window"), 14, Ui.TEXT, true));
        LinearLayout st = Ui.hbox(ctx);
        TextView dot = Ui.text(ctx, open ? "\u25CF open now" : "\u25CB closed", 11.5f, open ? Ui.GOOD : Ui.SUB, true);
        st.addView(dot);
        if (o.optBoolean("gone", false)) {
            TextView gone = Ui.text(ctx, "   removed", 11.5f, Ui.WARN, true);
            st.addView(gone);
        }
        col.addView(st);
        col.addView(Ui.text(ctx, o.optString("sub", ""), 11, Ui.SUB, false));

        if (!locked && o.optBoolean("unsafe", false)) {
            col.addView(Ui.text(ctx, "Kept visible: removing it closed the app before.", 11.5f, Ui.SUB, false));
        } else if (!locked && o.optBoolean("unsafeShow", false)) {
            col.addView(Ui.text(ctx, "Kept removed: bringing it back closed the app before.", 11.5f, Ui.SUB, false));
        } else if (!locked) {
            CheckBox keep = new CheckBox(ctx);
            keep.setText("Keep this interface");
            keep.setTextColor(Ui.TEXT);
            keep.setChecked(!o.optBoolean("gone", false));
            keep.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton b, boolean on) {
                    Bundle ex = new Bundle();
                    ex.putBoolean("keep", on);
                    cmd.run("keep", key, ex);
                }
            });
            col.addView(keep);
            if (open && !o.optBoolean("gone", false)) {
                int a0 = Math.max(10, Math.min(100, o.optInt("alpha", 100)));
                final TextView lab = Ui.text(ctx, "Opacity " + a0 + "%", 11.5f, Ui.SUB, false);
                col.addView(lab);
                SeekBar sb = new SeekBar(ctx);
                sb.setMax(90);
                sb.setProgress(a0 - 10);
                sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                        lab.setText("Opacity " + (p + 10) + "%");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar s) {
                        touching = true;
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar s) {
                        touching = false;
                        Bundle ex = new Bundle();
                        ex.putInt("alpha", s.getProgress() + 10);
                        cmd.run("alpha", key, ex);
                    }
                });
                col.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
            }
        } else {
            col.addView(Ui.text(ctx, "A screen is never removed. Style it in Full pencil > Theme.", 11.5f, Ui.SUB,
                    false));
        }
        return row;
    }
}
