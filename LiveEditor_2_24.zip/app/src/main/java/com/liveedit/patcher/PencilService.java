package com.liveedit.patcher;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

/**
 * THE pencil: ONE pencil on the whole phone. It is an accessibility overlay (window type TYPE_ACCESSIBILITY_OVERLAY), so it
 * shows on top of every app, needs no "Display over other apps" permission, and nothing is added to any patched app. It is
 * switched on and off in Live Editor (default ON); Live Editor asks for the Accessibility permission as soon as it is ON.
 *
 * Tap the pencil over ANY app and the full pencil menu opens (Items, Windows, Global, Theme, More):
 *   - over an app that was patched with "Live Editor inside the app": the complete pencil of that app (the panel of the engine
 *     inside it) opens, and everything in it can be edited; tap again to close it;
 *   - over any other app: the same menu is drawn by Live Editor itself. Items and Windows show what is on screen (found through
 *     Accessibility, with a red frame that points at the item), and every editing tab explains that changing an app from outside
 *     is not possible: one tap on "Patch this app" loads it in Live Editor, and once it is patched the pencil edits it.
 * The handle can be dragged (it sticks to the nearer screen edge and the place is remembered), and it is put back at once
 * if Android removes it. All view work runs on the main thread.
 */
public class PencilService extends AccessibilityService {

    private static final int OVERLAY = 2032; // WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY

    private static PencilService inst;

    private final Handler h = new Handler(Looper.getMainLooper());
    private Context ctx;
    private WindowManager wm;
    private TextView handle;
    private WindowManager.LayoutParams hlp;
    private LinearLayout menu;
    private volatile boolean showing;
    private boolean dragging;
    private String cur = "";
    private HashSet<String> ime;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                refreshNow();
                if (handle != null && PencilPrefs.isOn(PencilService.this)) {
                    if (!dragging && !handle.isAttachedToWindow()) {
                        try {
                            wm.addView(handle, hlp); // Android took it away: back at once
                        } catch (Throwable t) {
                            // the next step tries again
                        }
                    }
                    if (!dragging) clamp();
                }
            } catch (Throwable t) {
                // keep running
            }
            h.postDelayed(this, 1000L);
        }
    };

    // ---- called from the rest of Live Editor -------------------------------------------------------

    /** True while the pencil is on screen (Patched apps ask this, so they never show a pencil of their own). */
    static boolean active() {
        PencilService s = inst;
        return s != null && s.showing;
    }

    /** The switch changed: show or hide the pencil now. */
    static void refresh() {
        final PencilService s = inst;
        if (s == null) return;
        s.h.post(new Runnable() {
            @Override
            public void run() {
                s.refreshNow();
            }
        });
    }

    /** A patched app says it is on screen right now. */
    static void hint(final String pkg) {
        final PencilService s = inst;
        if (s == null || pkg == null || pkg.length() == 0) return;
        s.h.post(new Runnable() {
            @Override
            public void run() {
                if (s.cur.length() == 0) s.setCur(pkg);
            }
        });
    }

    // ---- service life --------------------------------------------------------------------------

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        ctx = new ContextThemeWrapper(this, android.R.style.Theme_Material);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        refreshNow();
        h.removeCallbacks(tick);
        h.postDelayed(tick, 1000L);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        h.removeCallbacks(tick);
        hide();
        if (inst == this) inst = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(tick);
        hide();
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override
    public void onInterrupt() {
        // nothing to interrupt
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        try {
            if (e == null || e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
            CharSequence pn = e.getPackageName();
            if (pn == null) return;
            String p = pn.toString();
            CharSequence cn = e.getClassName();
            String c = cn == null ? "" : cn.toString();
            if (p.equals(getPackageName())) {
                // Live Editor's own screens count as "Live Editor"; the pencil's own little menu does not
                if (c.startsWith("com.liveedit.patcher.")) setCur(p);
                return;
            }
            if (isNoise(p)) return;
            setCur(p);
        } catch (Throwable t) {
            // never let an event hurt anything
        }
    }

    /** System bars and keyboards are not "the app on screen". */
    private boolean isNoise(String p) {
        if ("com.android.systemui".equals(p) || "android".equals(p)) return true;
        try {
            if (ime == null) {
                ime = new HashSet<String>();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                List<InputMethodInfo> l = imm == null ? null : imm.getInputMethodList();
                if (l != null) {
                    for (int i = 0; i < l.size(); i++) ime.add(l.get(i).getPackageName());
                }
            }
            return ime.contains(p);
        } catch (Throwable t) {
            return false;
        }
    }

    private void setCur(String p) {
        if (p == null || p.equals(cur)) return;
        cur = p;
        closeMenu();
        updateHandleColor();
    }

    /**
     * The handle shows what the pencil knows about the app on screen: green = patched with "Live Editor inside the app", so
     * everything can be edited; grey = not patched (the menu can only look at it).
     */
    private void updateHandleColor() {
        if (handle == null || ctx == null) return;
        try {
            boolean edit = cur.length() > 0 && !cur.equals(getPackageName()) && PencilPrefs.hasEngine(this, cur);
            handle.setBackground(Ui.round(ctx, edit ? Ui.GOOD : 0xFF6B7088, 23));
        } catch (Throwable t) {
            // the colour is only a hint
        }
    }

    // ---- the handle ----------------------------------------------------------------------------

    private SharedPreferences prefs() {
        return getSharedPreferences("liveeditor", Context.MODE_PRIVATE);
    }

    private void refreshNow() {
        if (ctx == null || wm == null) return;
        if (PencilPrefs.isOn(this)) show();
        else hide();
    }

    private void show() {
        if (handle != null) return;
        SharedPreferences sp = prefs();
        int x = sp.getInt("pencil_x", Ui.dp(ctx, 4));
        int y = sp.getInt("pencil_y", Ui.dp(ctx, 140));
        TextView t = buildHandle();
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(Ui.dp(ctx, 46), Ui.dp(ctx, 46), OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = x;
        lp.y = y;
        try {
            wm.addView(t, lp);
            handle = t;
            hlp = lp;
            showing = true;
            clamp();
            updateHandleColor();
        } catch (Throwable ex) {
            handle = null;
            showing = false;
        }
    }

    private void hide() {
        closeMenu();
        showing = false;
        if (handle != null) {
            try {
                wm.removeView(handle);
            } catch (Throwable t) {
                // already gone
            }
            handle = null;
        }
    }

    /** Keeps the handle on the screen (after a turn of the phone, for example). */
    private void clamp() {
        if (handle == null || hlp == null) return;
        try {
            int sw = ctx.getResources().getDisplayMetrics().widthPixels;
            int sh = ctx.getResources().getDisplayMetrics().heightPixels;
            int size = Ui.dp(ctx, 46);
            int nx = Math.max(0, Math.min(hlp.x, sw - size));
            int ny = Math.max(0, Math.min(hlp.y, sh - size));
            if (nx != hlp.x || ny != hlp.y) {
                hlp.x = nx;
                hlp.y = ny;
                wm.updateViewLayout(handle, hlp);
            }
        } catch (Throwable t) {
            // stays where it is
        }
    }

    private TextView buildHandle() {
        final TextView t = new TextView(ctx);
        t.setText("\u270E");
        t.setTextSize(20);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.round(ctx, Ui.ACCENT, 23));
        t.setOnTouchListener(new View.OnTouchListener() {
            private float downX;
            private float downY;
            private int startX;
            private int startY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (hlp == null) return true;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = hlp.x;
                        startY = hlp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > Ui.dp(ctx, 6) || Math.abs(dy) > Ui.dp(ctx, 6)) moved = true;
                        if (moved) {
                            dragging = true;
                            hlp.x = Math.max(0, startX + Math.round(dx));
                            hlp.y = Math.max(0, startY + Math.round(dy));
                            try {
                                wm.updateViewLayout(t, hlp);
                            } catch (Throwable ex) {
                                // ignore
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        dragging = false;
                        if (!moved) onTap();
                        else snapToEdge(t);
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        dragging = false;
                        return true;
                    default:
                        return true;
                }
            }
        });
        return t;
    }

    /** After a drag the handle sticks to the nearer side of the screen, and the place is remembered. */
    private void snapToEdge(View t) {
        try {
            int sw = ctx.getResources().getDisplayMetrics().widthPixels;
            int size = Ui.dp(ctx, 46);
            hlp.x = (hlp.x + size / 2 < sw / 2) ? Ui.dp(ctx, 2) : sw - size - Ui.dp(ctx, 2);
            wm.updateViewLayout(t, hlp);
            prefs().edit().putInt("pencil_x", hlp.x).putInt("pencil_y", hlp.y).apply();
        } catch (Throwable ex) {
            // stays where it is
        }
    }

    // ---- what a tap does -----------------------------------------------------------------------

    private void onTap() {
        if (menu != null) {
            closeMenu();
            return;
        }
        final String p = foregroundPkg();
        if (p.length() > 0 && !p.equals(getPackageName()) && PencilPrefs.hasEngine(this, p)) {
            // a patched app: its complete pencil opens inside it (or closes if it is open)
            new Thread(new Runnable() {
                @Override
                public void run() {
                    boolean ok = false;
                    try {
                        Bundle b = getContentResolver().call(Uri.parse("content://" + p + ".liveeditagent"), "panel", null,
                                null);
                        ok = b != null;
                    } catch (Throwable t) {
                        ok = false;
                    }
                    final boolean okay = ok;
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!okay) {
                                openFullMenu(p, true);
                                return;
                            }
                            String label = p;
                            try {
                                PackageManager pm = getPackageManager();
                                label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(p, 0)));
                            } catch (Throwable t) {
                                label = p;
                            }
                            Toast.makeText(PencilService.this, "Pencil: " + label + " (patched, editable)",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }, "pencil-open").start();
            return;
        }
        openFullMenu(p, false);
    }

    /** The app that is on screen: the top application window (works even when no event came in yet). */
    private String foregroundPkg() {
        try {
            List<AccessibilityWindowInfo> ws = getWindows();
            AccessibilityWindowInfo best = null;
            if (ws != null) {
                for (int i = 0; i < ws.size(); i++) {
                    AccessibilityWindowInfo w = ws.get(i);
                    if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                    if (best == null || w.getLayer() > best.getLayer()) best = w;
                }
            }
            if (best != null) {
                AccessibilityNodeInfo r = best.getRoot();
                if (r != null && r.getPackageName() != null) return r.getPackageName().toString();
            }
        } catch (Throwable t) {
            // use the last app seen in an event
        }
        return cur;
    }

    /** The root of the top application window of this app, or null. */
    private AccessibilityNodeInfo rootOf(String pkg) {
        try {
            List<AccessibilityWindowInfo> ws = getWindows();
            AccessibilityWindowInfo best = null;
            if (ws != null) {
                for (int i = 0; i < ws.size(); i++) {
                    AccessibilityWindowInfo w = ws.get(i);
                    if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                    AccessibilityNodeInfo r = w.getRoot();
                    if (r == null || r.getPackageName() == null || !pkg.equals(r.getPackageName().toString())) continue;
                    if (best == null || w.getLayer() > best.getLayer()) best = w;
                }
            }
            if (best != null) return best.getRoot();
            AccessibilityNodeInfo a = getRootInActiveWindow();
            if (a != null && a.getPackageName() != null && pkg.equals(a.getPackageName().toString())) return a;
        } catch (Throwable t) {
            // nothing readable
        }
        return null;
    }

    private static final String[] TABS = {"Items", "Windows", "Global", "Theme", "More"};
    private final ArrayList<TextView> tabChips = new ArrayList<TextView>();
    private LinearLayout fmList;
    private TextView fmStatus;
    private String fmPkg = "";
    private String fmLabel = "";
    private boolean fmEngine;
    private boolean fmCanPatch;
    private View hlView;

    private LinearLayout.LayoutParams full(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(ctx, topDp);
        return lp;
    }

    /** The full pencil menu drawn by Live Editor (for every app that has no pencil inside it). */
    private void openFullMenu(final String p, boolean engineWithoutPencil) {
        closeMenu();
        try {
            final boolean own = p.equals(getPackageName());
            boolean real = p.length() > 0 && !own;
            String label = own ? "Live Editor" : "";
            Drawable icon = null;
            if (p.length() > 0) {
                label = p;
                try {
                    PackageManager pm = getPackageManager();
                    label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(p, 0)));
                    icon = pm.getApplicationIcon(p);
                } catch (Throwable t) {
                    real = false;
                }
            }
            fmPkg = p;
            fmLabel = label.length() == 0 ? "Live Editor pencil" : label;
            fmEngine = engineWithoutPencil;
            fmCanPatch = real;

            LinearLayout box = Ui.vbox(ctx);
            box.setBackground(Ui.round(ctx, Ui.CARD, 16));
            box.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 10), Ui.dp(ctx, 12), Ui.dp(ctx, 10));
            LinearLayout head = Ui.hbox(ctx);
            if (icon != null) {
                ImageView iv = new ImageView(ctx);
                iv.setImageDrawable(icon);
                LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(Ui.dp(ctx, 28), Ui.dp(ctx, 28));
                il.rightMargin = Ui.dp(ctx, 8);
                head.addView(iv, il);
            }
            head.addView(Ui.text(ctx, fmLabel, 15, Ui.TEXT, true), new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView close = Ui.chip(ctx, "Close");
            close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closeMenu();
                }
            });
            head.addView(close);
            box.addView(head);
            String note = own ? "This is Live Editor itself."
                    : !real ? "Open an app first: the pencil works on the app that is on screen."
                    : engineWithoutPencil ? "This app is a normal APK (the pencil is not inside it). Patch it again with "
                    + "\"Live Editor inside the app\" to edit it."
                    : "Not patched yet: you can look at everything here, and change it after one tap on Patch this app.";
            TextView n = Ui.text(ctx, note, 12, Ui.SUB, false);
            n.setPadding(0, Ui.dp(ctx, 4), 0, 0);
            box.addView(n);
            if (real) {
                android.widget.Button patch = Ui.button(ctx, "Patch this app to edit it", true);
                patch.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        closeMenu();
                        startLiveEditor("com.liveedit.patcher.PATCH", fmPkg);
                    }
                });
                box.addView(patch, full(8));
            }

            HorizontalScrollView hs = new HorizontalScrollView(ctx);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout row = Ui.hbox(ctx);
            hs.addView(row);
            tabChips.clear();
            for (int i = 0; i < TABS.length; i++) {
                final int ti = i;
                TextView c = Ui.chip(ctx, TABS[i]);
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showTab(ti);
                    }
                });
                tabChips.add(c);
                LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                cl.rightMargin = Ui.dp(ctx, 8);
                row.addView(c, cl);
            }
            box.addView(hs, full(8));
            fmStatus = Ui.text(ctx, "", 12, Ui.SUB, false);
            box.addView(fmStatus, full(8));
            ScrollView sv = new ScrollView(ctx);
            fmList = Ui.vbox(ctx);
            sv.addView(fmList);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            slp.topMargin = Ui.dp(ctx, 6);
            box.addView(sv, slp);

            int sw = ctx.getResources().getDisplayMetrics().widthPixels;
            int sh = ctx.getResources().getDisplayMetrics().heightPixels;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(Math.min(sw - Ui.dp(ctx, 24), Ui.dp(ctx, 440)),
                    Math.round(sh * 0.76f), OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = Ui.dp(ctx, 50);
            wm.addView(box, lp);
            menu = box;
            // the pencil handle stays above the menu
            if (handle != null && hlp != null) {
                try {
                    wm.removeView(handle);
                    wm.addView(handle, hlp);
                } catch (Throwable t) {
                    // the next step puts it back
                }
            }
            showTab(0);
        } catch (Throwable t) {
            menu = null;
        }
    }

    private void showTab(int i) {
        if (fmList == null) return;
        for (int k = 0; k < tabChips.size(); k++) WinRows.styleChip(ctx, tabChips.get(k), k == i);
        fmList.removeAllViews();
        clearHighlight();
        try {
            if (i == 0) fillItems();
            else if (i == 1) fillWindows();
            else if (i == 4) fillMore();
            else fillNeedsPatch(i == 2 ? "Global" : "Theme");
        } catch (Throwable t) {
            fmStatus.setText("Could not read this app's screen.");
        }
    }

    private void addRow(String title, String sub, final Rect frame) {
        LinearLayout r = Ui.vbox(ctx);
        r.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 8), Ui.dp(ctx, 10), Ui.dp(ctx, 8));
        r.setBackground(Ui.round(ctx, Ui.CARD2, 10));
        r.addView(Ui.text(ctx, title, 13.5f, Ui.TEXT, true));
        if (sub.length() > 0) r.addView(Ui.text(ctx, sub, 11, Ui.SUB, false));
        if (frame != null) {
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    highlight(frame);
                }
            });
        }
        fmList.addView(r, full(6));
    }

    private static String shortName(String s) {
        if (s == null) return "";
        int i = Math.max(s.lastIndexOf('.'), s.lastIndexOf('/'));
        return i >= 0 ? s.substring(i + 1) : s;
    }

    private void collect(AccessibilityNodeInfo n, ArrayList<AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 40 || out.size() >= 250) return;
        if (n.isVisibleToUser()) {
            CharSequence t = n.getText();
            CharSequence d = n.getContentDescription();
            if ((t != null && t.length() > 0) || (d != null && d.length() > 0) || n.getViewIdResourceName() != null
                    || n.isClickable()) {
                out.add(n);
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), out, depth + 1);
    }

    /** Items: what is on the screen of the app, tap one to see where it is (red frame). Reading only. */
    private void fillItems() {
        AccessibilityNodeInfo root = fmPkg.length() == 0 ? null : rootOf(fmPkg);
        if (root == null) {
            fmStatus.setText("Cannot read the screen of this app (some apps block it). Open the app and tap the pencil again.");
            return;
        }
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<AccessibilityNodeInfo>();
        collect(root, nodes, 0);
        for (int i = 0; i < nodes.size(); i++) {
            AccessibilityNodeInfo n = nodes.get(i);
            CharSequence t = n.getText();
            CharSequence d = n.getContentDescription();
            String id = n.getViewIdResourceName();
            String title = t != null && t.length() > 0 ? t.toString()
                    : d != null && d.length() > 0 ? d.toString()
                    : id != null ? shortName(id) : shortName(String.valueOf(n.getClassName()));
            String sub = shortName(String.valueOf(n.getClassName())) + (id != null ? "  \u2022  " + shortName(id) : "")
                    + (n.isClickable() ? "  \u2022  tappable" : "");
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            addRow(title.length() > 80 ? title.substring(0, 80) : title, sub, r);
        }
        fmStatus.setText(nodes.size() + " items on screen. Tap one to see where it is. To hide, move or restyle them, "
                + (fmEngine ? "patch the app again." : "patch the app (button above)."));
    }

    /** Windows: every window on screen now (the app, the keyboard, the system bars). Reading only. */
    private void fillWindows() {
        List<AccessibilityWindowInfo> ws;
        try {
            ws = getWindows();
        } catch (Throwable t) {
            ws = null;
        }
        if (ws == null || ws.isEmpty()) {
            fmStatus.setText("No window list available right now.");
            return;
        }
        ArrayList<AccessibilityWindowInfo> list = new ArrayList<AccessibilityWindowInfo>(ws);
        Collections.sort(list, new Comparator<AccessibilityWindowInfo>() {
            @Override
            public int compare(AccessibilityWindowInfo a, AccessibilityWindowInfo b) {
                return b.getLayer() - a.getLayer();
            }
        });
        int shown = 0;
        for (int i = 0; i < list.size(); i++) {
            AccessibilityWindowInfo w = list.get(i);
            if (w.getType() == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue; // the pencil itself
            String type = w.getType() == AccessibilityWindowInfo.TYPE_APPLICATION ? "App window"
                    : w.getType() == AccessibilityWindowInfo.TYPE_INPUT_METHOD ? "Keyboard"
                    : w.getType() == AccessibilityWindowInfo.TYPE_SYSTEM ? "System window"
                    : w.getType() == AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER ? "Split-screen divider" : "Window";
            String pkg = "";
            try {
                AccessibilityNodeInfo r = w.getRoot();
                if (r != null && r.getPackageName() != null) pkg = r.getPackageName().toString();
            } catch (Throwable t) {
                pkg = "";
            }
            CharSequence title = w.getTitle();
            Rect b = new Rect();
            w.getBoundsInScreen(b);
            addRow(type + (title != null && title.length() > 0 ? ": " + title : ""),
                    (pkg.length() > 0 ? pkg + "  \u2022  " : "") + b.width() + " x " + b.height()
                            + (w.isActive() ? "  \u2022  active" : ""), b);
            shown++;
        }
        fmStatus.setText(shown + " windows on screen. Tap one to see where it is. To remove or restyle windows, "
                + (fmEngine ? "patch the app again." : "patch the app (button above)."));
    }

    /** Global and Theme change the app's own code: they need the pencil inside the app. */
    private void fillNeedsPatch(String name) {
        fmStatus.setText(name + " changes the whole app (sizes, colors, fonts of everything).");
        addRow(name + " needs the pencil inside the app",
                "Android does not let one app change another app from outside. Patch " + fmLabel
                        + " with \"Live Editor inside the app\" once: then this tab edits it live, like in every patched app.",
                null);
        if (fmCanPatch) {
            android.widget.Button patch = Ui.button(ctx, "Patch this app", true);
            patch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closeMenu();
                    startLiveEditor("com.liveedit.patcher.PATCH", fmPkg);
                }
            });
            fmList.addView(patch, full(10));
        }
    }

    private void fillMore() {
        fmStatus.setText("Live Editor");
        if (fmCanPatch) {
            TextView patch = Ui.chip(ctx, "Patch this app");
            patch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    closeMenu();
                    startLiveEditor("com.liveedit.patcher.PATCH", fmPkg);
                }
            });
            fmList.addView(patch, full(8));
        }
        TextView open = Ui.chip(ctx, "Open Live Editor");
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeMenu();
                startLiveEditor(null, null);
            }
        });
        fmList.addView(open, full(8));
        TextView off = Ui.chip(ctx, "Pencil OFF (everywhere)");
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PencilPrefs.setOn(PencilService.this, false);
            }
        });
        fmList.addView(off, full(8));
    }

    /** A red frame over a place on the screen for a moment; touches go straight through it. */
    private void highlight(Rect r) {
        clearHighlight();
        try {
            View v = new View(ctx);
            GradientDrawable g = new GradientDrawable();
            g.setColor(0x33FF3B30);
            g.setStroke(Ui.dp(ctx, 3), 0xFFFF3B30);
            v.setBackground(g);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(Math.max(Ui.dp(ctx, 6), r.width()),
                    Math.max(Ui.dp(ctx, 6), r.height()), OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.LEFT;
            lp.x = r.left;
            lp.y = r.top;
            wm.addView(v, lp);
            hlView = v;
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    clearHighlight();
                }
            }, 1800L);
        } catch (Throwable t) {
            hlView = null;
        }
    }

    private void clearHighlight() {
        if (hlView != null) {
            try {
                wm.removeView(hlView);
            } catch (Throwable t) {
                // already gone
            }
            hlView = null;
        }
    }

    private void closeMenu() {
        clearHighlight();
        if (menu != null) {
            try {
                wm.removeView(menu);
            } catch (Throwable t) {
                // already gone
            }
            menu = null;
        }
        fmList = null;
        fmStatus = null;
        tabChips.clear();
    }

    private void startLiveEditor(String action, String pkg) {
        try {
            Intent i = new Intent(this, MainActivity.class);
            if (action != null) i.setAction(action);
            if (pkg != null) i.putExtra("pkg", pkg);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        } catch (Throwable t) {
            // Live Editor can be opened by hand
        }
    }
}
