package com.liveedit.patcher;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

/**
 * A patched app tells Live Editor "I am on screen" ("fg") or "I left" ("bg"). The pencil itself is the accessibility overlay
 * of Live Editor (PencilService), on the whole phone; the answer here only tells the app whether that pencil is showing
 * ("shown") or why not ("off" = the switch is OFF, "noaccess" = the Accessibility permission is missing), so the app never
 * adds a pencil of its own while Live Editor is there.
 */
public final class HostProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        Bundle out = new Bundle();
        out.putBoolean("shown", false);
        try {
            Context c = getContext();
            if (c == null || arg == null) return out;
            Context app = c.getApplicationContext();
            String caller = getCallingPackage();
            if (!arg.equals(caller)) return out;
            if (!PencilPrefs.isOn(app)) {
                out.putString("why", "off"); // the pencil switch of Live Editor is OFF: no pencil anywhere, also not in the app
                return out;
            }
            if (!PencilPrefs.hasEngine(app, arg)) return out;
            if ("fg".equals(method)) {
                PencilService.hint(arg); // this patched app is the one on screen right now
                boolean shown = PencilService.active();
                out.putBoolean("shown", shown);
                if (!shown) out.putString("why", "noaccess"); // the pencil needs the Accessibility permission
            }
        } catch (Throwable t) {
            // never let a bad call hurt this app
        }
        return out;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] args) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] args) {
        return 0;
    }
}
